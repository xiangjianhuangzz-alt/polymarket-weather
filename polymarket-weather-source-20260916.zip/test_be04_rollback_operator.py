import asyncio
import json
import sqlite3
import tempfile
import threading
import unittest
from contextlib import closing
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, patch

import realtime_stream as stream
from test_be04_manifest_v1 import publication_row, v1_member


NOW = datetime(2026, 8, 11, 1, 0, tzinfo=UTC)
CURRENT_HASH = "a" * 64
TARGET_HASH = "b" * 64


def request_payload(**changes):
    values = {
        "schema": "universe_rollback_request.v1",
        "operation_id": "T00:rollback-20260811.1",
        "expected_current_hash": CURRENT_HASH,
        "target_previous_hash": TARGET_HASH,
        "not_before": (NOW - timedelta(minutes=1)).isoformat(),
        "expires_at": (NOW + timedelta(minutes=10)).isoformat(),
        "reason": "controlled health rollback",
    }
    values.update(changes)
    return values


class _Socket:
    def __init__(self, *, fail_at=None, order=None):
        self.closed = False
        self.fail_at = fail_at
        self.order = order
        self.sent = []

    async def send(self, value):
        call = len(self.sent) + 1
        if self.fail_at == call:
            raise ConnectionError("planned send failure")
        self.sent.append(value)
        if self.order is not None:
            self.order.append(json.loads(value)["operation"])


class RollbackRequestFileTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.path = self.root / "request.json"

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, payload=None, *, raw=None):
        if raw is None:
            raw = json.dumps(
                request_payload() if payload is None else payload,
                separators=(",", ":"),
            ).encode("utf-8")
        self.path.write_bytes(raw)

    def read(self):
        return stream.read_rollback_request_file(self.path, NOW)

    def test_missing_empty_oversize_directory_and_symlink_fail_closed(self):
        self.assertEqual(
            stream.ROLLBACK_REQUEST_PATH,
            stream.BASE / "data" / "runtime" / "control"
            / "universe_rollback_request.v1.json",
        )
        self.assertIsNone(self.read())
        self.write(raw=b"")
        with self.assertRaises(stream.RollbackRequestError):
            self.read()
        self.write(raw=b"x" * (stream.ROLLBACK_REQUEST_MAX_BYTES + 1))
        with self.assertRaises(stream.RollbackRequestError):
            self.read()

        directory = self.root / "directory"
        directory.mkdir()
        with self.assertRaises(stream.RollbackRequestError):
            stream.read_rollback_request_file(directory, NOW)

        target = self.root / "target.json"
        target.write_text(json.dumps(request_payload()), encoding="utf-8")
        link = self.root / "link.json"
        try:
            link.symlink_to(target)
        except OSError:
            pass
        else:
            with self.assertRaises(stream.RollbackRequestError):
                stream.read_rollback_request_file(link, NOW)

    def test_utf8_json_duplicate_unknown_and_nonfinite_are_strict(self):
        cases = (
            b"\xff",
            b"{",
            (
                '{"schema":"universe_rollback_request.v1",'
                '"schema":"universe_rollback_request.v1"}'
            ).encode(),
            json.dumps({**request_payload(), "unknown": "x"}).encode(),
            json.dumps({**request_payload(), "reason": float("nan")}).encode(),
            json.dumps({**request_payload(), "reason": float("inf")}).encode(),
        )
        for raw in cases:
            with self.subTest(raw=raw[:40]):
                self.write(raw=raw)
                with self.assertRaises(stream.RollbackRequestError):
                    self.read()

    def test_dto_native_strings_identifiers_hashes_and_reason_are_strict(self):
        cases = (
            {"schema": "wrong"},
            {"operation_id": ""},
            {"operation_id": " bad"},
            {"operation_id": "bad/operator"},
            {"operation_id": "x" * 129},
            {"expected_current_hash": "A" * 64},
            {"expected_current_hash": "a" * 63},
            {"target_previous_hash": CURRENT_HASH},
            {"reason": ""},
            {"reason": " leading"},
            {"reason": "line\nbreak"},
            {"reason": "nul\0byte"},
            {"reason": "x" * 257},
            {"reason": True},
            {"expires_at": 123},
        )
        for changes in cases:
            with self.subTest(changes=changes):
                self.write(request_payload(**changes))
                with self.assertRaises(stream.RollbackRequestError):
                    self.read()

    def test_timezone_activation_expiry_and_fifteen_minute_lifetime_are_strict(self):
        cases = (
            {"not_before": "2026-08-11T00:59:00"},
            {"expires_at": "2026-08-11T01:10:00"},
            {"not_before": (NOW + timedelta(seconds=1)).isoformat()},
            {"expires_at": NOW.isoformat()},
            {
                "not_before": (NOW - timedelta(minutes=1)).isoformat(),
                "expires_at": (NOW + timedelta(minutes=14, seconds=1)).isoformat(),
            },
        )
        for changes in cases:
            with self.subTest(changes=changes):
                self.write(request_payload(**changes))
                with self.assertRaises(stream.RollbackRequestError):
                    self.read()

        self.write(request_payload(
            not_before=(NOW - timedelta(minutes=5)).isoformat(),
            expires_at=(NOW + timedelta(minutes=10)).isoformat(),
        ))
        request = self.read()
        self.assertEqual(request.operation_id, request_payload()["operation_id"])
        self.assertEqual(request.expected_current_hash, CURRENT_HASH)
        self.assertEqual(request.target_previous_hash, TARGET_HASH)


class RollbackRequestReadIsolationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "request.json"
        self.path.write_text(json.dumps(request_payload()), encoding="utf-8")

    async def asyncTearDown(self):
        self.tmp.cleanup()

    async def test_file_read_runs_in_thread_and_nominal_interval_is_five_seconds(self):
        caller_thread = threading.get_ident()
        read_threads = []
        actual = stream.read_rollback_request_file

        def tracked(path, now):
            read_threads.append(threading.get_ident())
            return actual(path, now)

        operator = stream.RollbackRequestOperator(self.path)
        with patch.object(stream, "read_rollback_request_file", side_effect=tracked):
            first = await operator.read_due(now=NOW, monotonic_now=5.0)
            skipped = await operator.read_due(now=NOW, monotonic_now=9.999)
            second = await operator.read_due(now=NOW, monotonic_now=10.0)

        self.assertIsNotNone(first)
        self.assertIsNone(skipped)
        self.assertIsNotNone(second)
        self.assertEqual(stream.ROLLBACK_REQUEST_CHECK_INTERVAL_SECONDS, 5.0)
        self.assertEqual(operator.reader.starts, 2)
        self.assertTrue(all(value != caller_thread for value in read_threads))

    async def test_timed_out_read_is_single_flight_and_event_loop_health_advances(self):
        release = threading.Event()
        entered = threading.Event()
        request = stream.read_rollback_request_file(self.path, NOW)

        def blocked(_path, _now):
            entered.set()
            release.wait(2)
            return request

        operator = stream.RollbackRequestOperator(self.path, read_timeout=0.01)
        with patch.object(stream, "read_rollback_request_file", side_effect=blocked):
            first = asyncio.create_task(
                operator.read_due(now=NOW, monotonic_now=5.0)
            )
            await asyncio.to_thread(entered.wait, 1)

            writer = Mock()
            writer.submit_diagnostic.return_value = True
            progress = Mock()
            state = stream.StreamState(
                None, {"1": "m1"}, writer, stream.LiveStateHub(), "h",
                progress=progress,
            )
            probes = []
            await asyncio.sleep(0)
            probes.append("receive")
            state.heartbeat("rollback read pending", force=True)
            self.assertIsNone(await first)
            self.assertIsNone(
                await operator.read_due(now=NOW, monotonic_now=10.0)
            )
            self.assertEqual(operator.reader.starts, 1)
            self.assertFalse(operator.dynamic_hold)
            self.assertEqual(probes, ["receive"])
            writer.submit_diagnostic.assert_called_once()
            progress.publish.assert_called_once()

            release.set()
            for _ in range(100):
                if operator.reader.done:
                    break
                await asyncio.sleep(0.005)
            consumed = await operator.read_due(now=NOW, monotonic_now=15.0)

        self.assertEqual(consumed, request)
        self.assertEqual(operator.reader.starts, 1)

    async def test_timed_out_result_expired_before_poll_consumption_is_rejected(self):
        expires_at = NOW + timedelta(seconds=1)
        self.path.write_text(
            json.dumps(request_payload(expires_at=expires_at.isoformat())),
            encoding="utf-8",
        )
        release = threading.Event()
        entered = threading.Event()
        request = stream.read_rollback_request_file(self.path, NOW)

        def blocked(_path, _started_at):
            entered.set()
            release.wait(2)
            return request

        writer = Mock()
        writer.submit_diagnostic.return_value = True
        progress = Mock()
        state = stream.StreamState(
            None, {"1": "m1"}, writer, stream.LiveStateHub(), "h",
            progress=progress,
        )
        socket = _Socket()
        operator = stream.RollbackRequestOperator(self.path, read_timeout=0.01)
        with (
            patch.object(stream, "read_rollback_request_file", side_effect=blocked),
            patch.object(stream, "plan_explicit_rollback") as plan,
            patch.object(stream, "apply_explicit_rollback") as apply,
        ):
            first = asyncio.create_task(operator.poll(
                socket, state, writer, now=NOW, monotonic_now=5.0,
            ))
            await asyncio.to_thread(entered.wait, 1)
            receive_probe = []
            await asyncio.sleep(0)
            receive_probe.append("receive")
            state.heartbeat("rollback read pending", force=True)
            self.assertIsNone(await first)
            self.assertIsNone(await operator.poll(
                socket, state, writer,
                now=NOW + timedelta(milliseconds=500), monotonic_now=10.0,
            ))
            self.assertEqual(operator.reader.starts, 1)

            release.set()
            for _ in range(100):
                if operator.reader.done:
                    break
                await asyncio.sleep(0.005)
            result = await operator.poll(
                socket, state, writer,
                now=NOW + timedelta(seconds=2), monotonic_now=15.0,
            )

        self.assertIsNone(result)
        self.assertFalse(operator.dynamic_hold)
        self.assertEqual(operator.reader.starts, 1)
        self.assertEqual(receive_probe, ["receive"])
        writer.submit_diagnostic.assert_called_once()
        progress.publish.assert_called_once()
        plan.assert_not_called()
        apply.assert_not_called()
        self.assertEqual(socket.sent, [])
        writer.submit_connection_event.assert_not_called()

    async def test_consumption_time_revalidation_obeys_exclusive_expiry_boundary(self):
        expires_at = NOW + timedelta(seconds=1)
        request = stream.parse_rollback_request_payload(
            request_payload(expires_at=expires_at.isoformat()), now=NOW,
        )

        before = stream.RollbackRequestOperator(self.path)
        with patch.object(before.reader, "get", return_value=request):
            active = await before.read_due(
                now=expires_at - timedelta(microseconds=1), monotonic_now=5.0,
            )
        self.assertEqual(active, request)
        self.assertTrue(before.dynamic_hold)

        at_expiry = stream.RollbackRequestOperator(self.path)
        with patch.object(at_expiry.reader, "get", return_value=request):
            expired = await at_expiry.read_due(
                now=expires_at, monotonic_now=5.0,
            )
        self.assertIsNone(expired)
        self.assertFalse(at_expiry.dynamic_hold)

    async def test_missing_and_repeated_errors_are_quiet_or_rate_limited(self):
        missing = Path(self.tmp.name) / "missing.json"
        missing_operator = stream.RollbackRequestOperator(missing)
        with patch.object(stream.logging, "warning") as warning:
            self.assertIsNone(await missing_operator.read_due(now=NOW, monotonic_now=5))
            self.assertIsNone(await missing_operator.read_due(now=NOW, monotonic_now=10))
        warning.assert_not_called()

        self.path.write_text("{", encoding="utf-8")
        operator = stream.RollbackRequestOperator(self.path, warning_interval=30)
        with patch.object(stream.logging, "warning") as warning:
            for monotonic_now in (5.0, 10.0, 15.0):
                self.assertIsNone(await operator.read_due(
                    now=NOW, monotonic_now=monotonic_now,
                ))
        warning.assert_called_once()

    async def test_reader_exception_is_isolated_from_caller(self):
        operator = stream.RollbackRequestOperator(self.path)
        with patch.object(
            stream, "read_rollback_request_file", side_effect=OSError("fixture")
        ):
            result = await operator.read_due(now=NOW, monotonic_now=5)
        self.assertIsNone(result)


class RollbackOperatorExecutionTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.research = root / "research.sqlite3"
        self.realtime = root / "realtime.sqlite3"
        self.request_path = root / "rollback.json"
        self.old_research, self.old_db = stream.RESEARCH_DB, stream.DB
        stream.RESEARCH_DB, stream.DB = self.research, self.realtime
        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute("""CREATE TABLE market_universe_publications (
              publication_id TEXT PRIMARY KEY, published_at TEXT, token_hash TEXT,
              token_count INTEGER, members_json TEXT, reason TEXT)""")
        db = stream.connect()
        db.close()

    async def asyncTearDown(self):
        stream.RESEARCH_DB, stream.DB = self.old_research, self.old_db
        self.tmp.cleanup()

    def store(self, members):
        row = publication_row(members)
        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute(
                "INSERT OR IGNORE INTO market_universe_publications VALUES (?,?,?,?,?,?)",
                row,
            )
        return row[2]

    def accepted(self, token_hash, event_at, event_type="universe_changed"):
        with closing(sqlite3.connect(self.realtime)) as db, db:
            db.execute(
                "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                (event_at, event_type, "fixture", token_hash, 1, "[]", "[]"),
            )

    def state_for(self, manifest, writer):
        hub = stream.LiveStateHub()
        hub.set_universe(manifest.token_market)
        return stream.StreamState(
            None, manifest.token_market, writer, hub, manifest.token_hash,
            token_target_date=manifest.token_target_date, manifest=manifest,
        )

    def arm(self, current_hash, target_hash, **changes):
        payload = request_payload(
            expected_current_hash=current_hash,
            target_previous_hash=target_hash,
            **changes,
        )
        self.request_path.write_text(json.dumps(payload), encoding="utf-8")
        return payload

    async def test_valid_asset_change_is_send_then_audit_then_apply_with_context(self):
        previous_hash = self.store([v1_member("100", "market-100")])
        current_hash = self.store([
            v1_member("100", "market-100"),
            v1_member("101", "market-101"),
        ])
        self.accepted(previous_hash, "2026-08-11T00:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-11T00:01:00+00:00")
        payload = self.arm(current_hash, previous_hash)
        request_bytes = self.request_path.read_bytes()
        writer = Mock()
        order = []
        writer.submit_connection_event.side_effect = (
            lambda *args, **kwargs: order.append("audit") or True
        )
        state = self.state_for(
            stream.published_universe_manifest(current_hash), writer
        )
        original_apply = state.apply_universe

        def tracked_apply(manifest):
            order.append("apply")
            original_apply(manifest)

        socket = _Socket(order=order)
        operator = stream.RollbackRequestOperator(self.request_path)
        with patch.object(state, "apply_universe", side_effect=tracked_apply):
            change = await operator.poll(
                socket, state, writer, now=NOW, monotonic_now=5,
            )

        self.assertEqual(order, ["unsubscribe", "audit", "apply"])
        self.assertEqual(change.manifest.token_hash, previous_hash)
        args, kwargs = writer.submit_connection_event.call_args
        detail = args[1]
        self.assertIn(payload["operation_id"], detail)
        self.assertIn(payload["reason"], detail)
        self.assertIn(current_hash, detail)
        self.assertIn(previous_hash, detail)
        self.assertIn("format_transition", detail)
        self.assertEqual(kwargs["universe_hash"], previous_hash)
        self.assertEqual(self.request_path.read_bytes(), request_bytes)

    async def test_plan_rejections_are_zero_operation_and_do_not_reconnect(self):
        current_hash = self.store([v1_member("100", "market-100")])
        historical_hash = self.store([v1_member("099", "market-099")])
        target_hash = self.store([v1_member("098", "market-098")])
        self.accepted(historical_hash, "2026-08-11T00:00:00+00:00", "connected")
        self.accepted(target_hash, "2026-08-11T00:01:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-11T00:02:00+00:00")
        writer = Mock()
        state = self.state_for(
            stream.published_universe_manifest(current_hash), writer
        )
        socket = _Socket()

        self.arm("f" * 64, target_hash)
        operator = stream.RollbackRequestOperator(self.request_path)
        self.assertIsNone(await operator.poll(
            socket, state, writer, now=NOW, monotonic_now=5,
        ))
        self.assertTrue(operator.dynamic_hold)

        self.arm(current_hash, historical_hash, operation_id="T00:historical")
        self.assertIsNone(await operator.poll(
            socket, state, writer, now=NOW, monotonic_now=10,
        ))
        self.assertTrue(operator.dynamic_hold)

        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute(
                "DELETE FROM market_universe_publications WHERE token_hash=?",
                (target_hash,),
            )
        self.arm(current_hash, target_hash, operation_id="T00:missing-target")
        self.assertIsNone(await operator.poll(
            socket, state, writer, now=NOW, monotonic_now=15,
        ))
        self.assertTrue(operator.dynamic_hold)

        self.request_path.unlink()
        self.assertIsNone(await operator.poll(
            socket, state, writer, now=NOW, monotonic_now=20,
        ))
        self.assertFalse(operator.dynamic_hold)
        self.assertEqual(socket.sent, [])
        writer.submit_connection_event.assert_not_called()
        self.assertEqual(state.universe_hash, current_hash)

    async def test_partial_send_audit_rejection_and_apply_failure_pin_current(self):
        scenarios = ("partial", "audit", "apply")
        for index, scenario in enumerate(scenarios):
            with self.subTest(scenario=scenario):
                previous_hash = self.store([
                    v1_member(str(200 + index * 10), f"market-{index}-a"),
                    v1_member(str(202 + index * 10), f"market-{index}-c"),
                ])
                current_hash = self.store([
                    v1_member(str(200 + index * 10), f"market-{index}-a"),
                    v1_member(str(201 + index * 10), f"market-{index}-b"),
                ])
                previous_minute = 10 + index * 10
                self.accepted(
                    previous_hash,
                    f"2026-08-11T00:{previous_minute:02d}:00+00:00",
                    "connected",
                )
                self.accepted(
                    current_hash,
                    f"2026-08-11T00:{previous_minute + 1:02d}:00+00:00",
                )
                self.arm(
                    current_hash, previous_hash,
                    operation_id=f"T00:{scenario}",
                )
                writer = Mock()
                writer.submit_connection_event.return_value = scenario != "audit"
                state = self.state_for(
                    stream.published_universe_manifest(current_hash), writer
                )
                socket = _Socket(fail_at=2 if scenario == "partial" else None)
                operator = stream.RollbackRequestOperator(self.request_path)
                apply_context = (
                    patch.object(state, "apply_universe", side_effect=RuntimeError("apply"))
                    if scenario == "apply" else patch.object(
                        state, "apply_universe", wraps=state.apply_universe
                    )
                )
                with apply_context:
                    with self.assertRaises(stream.UniverseReconnectRequired) as raised:
                        await operator.poll(
                            socket, state, writer, now=NOW, monotonic_now=5,
                        )
                self.assertEqual(raised.exception.recovery_hash, current_hash)
                self.assertEqual(state.universe_hash, current_hash)

    async def test_zero_remote_audit_failure_does_not_reconnect_or_apply(self):
        previous_hash = self.store([v1_member(source_scan_id="scan-1")])
        current_hash = self.store([v1_member(source_scan_id="scan-2")])
        self.accepted(previous_hash, "2026-08-11T00:30:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-11T00:31:00+00:00")
        self.arm(current_hash, previous_hash)
        writer = Mock()
        writer.submit_connection_event.return_value = False
        state = self.state_for(
            stream.published_universe_manifest(current_hash), writer
        )
        socket = _Socket()
        operator = stream.RollbackRequestOperator(self.request_path)

        result = await operator.poll(
            socket, state, writer, now=NOW, monotonic_now=5,
        )

        self.assertIsNone(result)
        self.assertEqual(socket.sent, [])
        self.assertEqual(state.universe_hash, current_hash)

    async def test_same_request_is_idempotent_across_polls_and_restart_chain(self):
        previous_hash = self.store([v1_member("100", "market-100")])
        current_hash = self.store([
            v1_member("100", "market-100"), v1_member("101", "market-101")
        ])
        self.accepted(previous_hash, "2026-08-11T00:40:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-11T00:41:00+00:00")
        self.arm(current_hash, previous_hash)
        writer = Mock()

        def accepted_rollback(*args, **kwargs):
            self.accepted(
                kwargs["universe_hash"], "2026-08-11T00:42:00+00:00",
                "universe_rollback",
            )
            return True

        writer.submit_connection_event.side_effect = accepted_rollback
        state = self.state_for(
            stream.published_universe_manifest(current_hash), writer
        )
        socket = _Socket()
        operator = stream.RollbackRequestOperator(self.request_path)
        first = await operator.poll(
            socket, state, writer, now=NOW, monotonic_now=5,
        )
        second = await operator.poll(
            socket, state, writer, now=NOW, monotonic_now=10,
        )
        restarted = stream.RollbackRequestOperator(self.request_path)
        third = await restarted.poll(
            socket, state, writer, now=NOW, monotonic_now=5,
        )

        self.assertIsNotNone(first)
        self.assertIsNone(second)
        self.assertIsNotNone(third)
        self.assertEqual(len(socket.sent), 1)
        self.assertEqual(writer.submit_connection_event.call_count, 1)

    async def test_same_operation_id_with_different_content_is_rejected(self):
        current_hash = self.store([v1_member("100", "market-100")])
        target_hash = self.store([v1_member("099", "market-099")])
        self.accepted(target_hash, "2026-08-11T00:50:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-11T00:51:00+00:00")
        writer = Mock()
        state = self.state_for(
            stream.published_universe_manifest(current_hash), writer
        )
        socket = _Socket()
        operator = stream.RollbackRequestOperator(self.request_path)

        self.arm("f" * 64, target_hash, operation_id="T00:conflict")
        with patch.object(stream, "plan_explicit_rollback", return_value=None) as plan:
            await operator.poll(socket, state, writer, now=NOW, monotonic_now=5)
            self.arm(
                "e" * 64, target_hash, operation_id="T00:conflict",
                reason="changed content",
            )
            await operator.poll(socket, state, writer, now=NOW, monotonic_now=10)

        self.assertEqual(plan.call_count, 1)
        self.assertEqual(socket.sent, [])
        writer.submit_connection_event.assert_not_called()


if __name__ == "__main__":
    unittest.main()
