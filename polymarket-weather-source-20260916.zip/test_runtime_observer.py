import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import patch

import runtime_observer
from runtime_observer import RuntimeObserver, read_service, read_subscribed_universe


class FakeAudit:
    def __init__(self) -> None:
        self.samples = 0
        self.events = []

    def event(self, *args) -> None:
        self.events.append(args)

    def sample_quotes(self, _database, _tokens, **_kwargs) -> None:
        self.samples += 1


class EmptyLogTail:
    def lock_messages(self, _paths):
        return []

    def restart_messages(self, _paths):
        return []


class OneRestartTail(EmptyLogTail):
    def __init__(self, path: Path) -> None:
        self.path = path

    def restart_messages(self, _paths):
        return [(self.path, "WARNING unit requires restart: worker_exited:1")]


class RuntimeObserverTests(unittest.TestCase):
    def test_missing_database_is_isolated(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            healthy = root / "healthy.sqlite3"
            with closing(sqlite3.connect(healthy)) as db, db:
                db.execute("CREATE TABLE service_heartbeats(service TEXT PRIMARY KEY,updated_at TEXT,detail TEXT)")
                db.execute(
                    "INSERT INTO service_heartbeats VALUES (?,?,?)",
                    ("healthy", datetime.now(UTC).isoformat(), "ok"),
                )
            self.assertEqual(read_service("missing", root / "missing.sqlite3")["state"], "missing_database")
            self.assertEqual(read_service("healthy", healthy)["state"], "healthy")

    def test_latest_dynamic_universe_is_reported_as_current_subscription(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "realtime.sqlite3"
            with closing(sqlite3.connect(database)) as db, db:
                db.execute("""CREATE TABLE stream_connection_events (
                  event_at TEXT,event_type TEXT,detail TEXT,universe_hash TEXT,
                  token_count INTEGER,added_tokens_json TEXT,removed_tokens_json TEXT)""")
                db.execute(
                    "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                    ("2026-07-27T08:00:00+00:00", "connected", "test",
                     "old", 110, "[]", "[]"),
                )
                db.execute(
                    "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                    ("2026-07-27T09:00:00+00:00", "universe_changed", "dynamic",
                     "new", 165, '["added"]', "[]"),
                )

            self.assertEqual(read_subscribed_universe(database), (165, "new"))

    def test_poll_continues_when_one_domain_is_missing(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            healthy = root / "healthy.sqlite3"
            with closing(sqlite3.connect(healthy)) as db, db:
                db.execute("CREATE TABLE service_heartbeats(service TEXT PRIMARY KEY,updated_at TEXT,detail TEXT)")
                db.execute(
                    "INSERT INTO service_heartbeats VALUES (?,?,?)",
                    ("healthy", datetime.now(UTC).isoformat(), "ok"),
                )
            status = root / "observer.json"
            observer = RuntimeObserver(status_path=status, stability_db=root / "audit.sqlite3")
            observer.audit = FakeAudit()
            observer.log_tail = EmptyLogTail()
            observer.guardian_log_tail = EmptyLogTail()
            mapping = {"healthy": healthy, "missing": root / "missing.sqlite3"}
            with patch.dict(runtime_observer.SERVICE_DATABASES, mapping, clear=True), \
                 patch("runtime_observer.active_strategy_universe", return_value=(set(), None)), \
                 patch("runtime_observer.REALTIME_DB", root / "missing-realtime.sqlite3"), \
                 patch("runtime_observer.read_quote_age", return_value=None):
                payload = observer.poll_once()
            self.assertEqual(payload["services"]["healthy"]["state"], "healthy")
            self.assertEqual(payload["services"]["missing"]["state"], "missing_database")
            self.assertEqual(observer.audit.samples, 1)
            self.assertTrue(status.exists())

    def test_observer_has_no_process_control_methods(self) -> None:
        forbidden = {"spawn", "stop_child", "terminate", "restart"}
        self.assertTrue(forbidden.isdisjoint(set(dir(RuntimeObserver))))

    def test_status_file_failure_does_not_break_observation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            observer = RuntimeObserver(
                status_path=root / "observer.json",
                stability_db=root / "audit.sqlite3",
            )
            observer.audit = FakeAudit()
            observer.log_tail = EmptyLogTail()
            observer.guardian_log_tail = EmptyLogTail()
            with patch.dict(runtime_observer.SERVICE_DATABASES, {}, clear=True), \
                 patch("runtime_observer.active_strategy_universe", return_value=(set(), None)), \
                 patch("runtime_observer.REALTIME_DB", root / "missing.sqlite3"), \
                 patch("runtime_observer.read_quote_age", return_value=None), \
                 patch("runtime_observer.atomic_json", side_effect=PermissionError("held")):
                first = observer.poll_once()
                second = observer.poll_once()
            self.assertEqual(first["state"], "observing")
            self.assertEqual(second["state"], "observing")
            self.assertEqual(observer.audit.samples, 2)

    def test_guardian_restart_is_forwarded_to_stability_audit(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            observer = RuntimeObserver(
                status_path=root / "observer.json",
                stability_db=root / "audit.sqlite3",
            )
            audit = FakeAudit()
            observer.audit = audit
            observer.log_tail = EmptyLogTail()
            observer.guardian_log_tail = OneRestartTail(
                root / "realtime_stream_guardian.log"
            )
            with patch.dict(runtime_observer.SERVICE_DATABASES, {}, clear=True), \
                 patch("runtime_observer.active_strategy_universe",
                       return_value=(set(), "expected")), \
                 patch("runtime_observer.REALTIME_DB", root / "missing.sqlite3"), \
                 patch("runtime_observer.read_quote_age", return_value=None):
                observer.poll_once()
            self.assertEqual(len(audit.events), 1)
            self.assertEqual(audit.events[0][0], "realtime_stream")
            self.assertEqual(audit.events[0][1], "worker_restart")


if __name__ == "__main__":
    unittest.main()
