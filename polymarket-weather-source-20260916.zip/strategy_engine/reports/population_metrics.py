"""Pure CD4 M009/M010/M017 population metrics; no qualification threshold is applied."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN, localcontext
from enum import Enum

from strategy_engine.data.evidence import FormalSettlementV1
from strategy_v8.canonical import hash_v1, validate_hash_v1
from strategy_v8.contracts import City
from strategy_v8.errors import ErrorCode, OutcomeClass, outcome_class_for


REASONS = ("SOURCE_FACT_CONFLICT", "SOURCE_IDENTITY_INVALID", "RETENTION_GAP", "PUBLICATION_MISSING")


def _q12_rate(numerator: int, denominator: int) -> Decimal:
    with localcontext() as context:
        context.prec = 34
        context.rounding = ROUND_HALF_EVEN
        return (Decimal(numerator) / Decimal(denominator)).quantize(Decimal("0.000000000001"), rounding=ROUND_HALF_EVEN)


@dataclass(frozen=True, slots=True)
class PreregisteredPopulationV1:
    city: City
    target_dates: tuple[date, ...]
    population_id: str

    @classmethod
    def create(cls, city: City, target_dates: tuple[date, ...]) -> "PreregisteredPopulationV1":
        ordered = tuple(sorted(target_dates))
        if len(ordered) != len(set(ordered)):
            raise ValueError("population target dates must be unique")
        return cls(city, ordered, hash_v1("PWM.CD4.PREREGISTERED_POPULATION.V1", {"schema_version": "PreregisteredPopulationV1", "city": city.value, "ordered_target_dates": [item.isoformat() for item in ordered]}))

    def __post_init__(self) -> None:
        if self.target_dates != tuple(sorted(self.target_dates)) or len(self.target_dates) != len(set(self.target_dates)):
            raise ValueError("population dates must be sorted and unique")
        expected = hash_v1("PWM.CD4.PREREGISTERED_POPULATION.V1", {"schema_version": "PreregisteredPopulationV1", "city": self.city.value, "ordered_target_dates": [item.isoformat() for item in self.target_dates]})
        if self.population_id != expected:
            raise ValueError("population identity mismatch")


@dataclass(frozen=True, slots=True)
class MarketPartitionV1:
    city: City
    target_date: date
    members: tuple[tuple[str, str, str], ...]

    def __post_init__(self) -> None:
        if not self.members or self.members != tuple(sorted(self.members)) or len(self.members) != len(set(self.members)):
            raise ValueError("market partition must be non-empty, sorted, and unique")
        if any(not all(isinstance(value, str) and value for value in member) for member in self.members):
            raise ValueError("market partition member is invalid")


@dataclass(frozen=True, slots=True)
class EligibleEventV1:
    city: City
    target_date: date
    event_seq: int
    event_id: str
    decision_hash: str
    event_hash: str

    @classmethod
    def create(cls, city: City, target_date: date, event_seq: int, event_id: str, decision_hash: str) -> "EligibleEventV1":
        payload = {"schema_version": "EligibleEventV1", "city": city.value, "target_date": target_date.isoformat(), "event_seq": event_seq, "event_id": event_id, "decision_hash": decision_hash}
        return cls(city, target_date, event_seq, event_id, decision_hash, hash_v1("PWM.CD4.ELIGIBLE_EVENT.V1", payload))

    def __post_init__(self) -> None:
        validate_hash_v1(self.decision_hash); validate_hash_v1(self.event_hash)
        if type(self.event_seq) is not int or self.event_seq < 0 or not self.event_id:
            raise ValueError("eligible event identity invalid")
        payload = {"schema_version": "EligibleEventV1", "city": self.city.value, "target_date": self.target_date.isoformat(), "event_seq": self.event_seq, "event_id": self.event_id, "decision_hash": self.decision_hash}
        if self.event_hash != hash_v1("PWM.CD4.ELIGIBLE_EVENT.V1", payload):
            raise ValueError("eligible event hash mismatch")


@dataclass(frozen=True, slots=True)
class FailureDayV1:
    city: City
    target_date: date
    terminal_error: ErrorCode | None
    proved_reasons: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.terminal_error is None:
            if self.proved_reasons:
                raise ValueError("non-terminal day cannot carry source failure reasons")
        else:
            if outcome_class_for(self.terminal_error) is not OutcomeClass.SYSTEM_FAIL_STOP or not self.proved_reasons:
                raise ValueError("source failure must be a terminal fail-closed outcome")
            if any(reason not in REASONS for reason in self.proved_reasons):
                raise ValueError("unclassified source failure reason")


def _result(metric_id: str, population: PreregisteredPopulationV1, numerator: int | None, missing: int, status: str, reasons: tuple[tuple[str, int], ...] = ()) -> dict:
    denominator = len(population.target_dates) if status == "OK" else None
    return {"metric_id": metric_id, "population_id": population.population_id, "numerator": None if numerator is None else Decimal(numerator), "denominator": None if denominator is None else Decimal(denominator), "value": None if denominator in (None, 0) else _q12_rate(numerator, denominator), "missing_count": missing, "status": status, "reason_counts": reasons}


def m009_settlement_identity_rate(population: PreregisteredPopulationV1, partitions: tuple[MarketPartitionV1, ...], settlements: tuple[FormalSettlementV1, ...]) -> dict:
    if not population.target_dates:
        return _result("M009", population, None, 0, "NOT_COMPUTABLE")
    if any(item.city is not population.city or item.target_date not in population.target_dates for item in partitions) or any(item.city is not population.city or item.target_date not in population.target_dates for item in settlements):
        return _result("M009", population, None, len(population.target_dates), "NOT_COMPUTABLE")
    partition_by_day = {(item.city, item.target_date): item for item in partitions}
    if len(partition_by_day) != len(partitions):
        return _result("M009", population, None, len(population.target_dates), "NOT_COMPUTABLE")
    good = missing = 0
    for day in population.target_dates:
        partition = partition_by_day.get((population.city, day))
        matches = [item for item in settlements if item.city is population.city and item.target_date == day]
        if partition is None:
            missing += 1; continue
        observed = [(item.market_id, item.yes_token_id, item.bucket_id) for item in matches]
        if tuple(sorted(observed)) == partition.members and len(observed) == len(set(observed)) and sum(item.outcome_yes for item in matches) == 1:
            good += 1
        else:
            missing += 1
    return _result("M009", population, good, missing, "OK")


def m010_eligible_day_rate(population: PreregisteredPopulationV1, events: tuple[EligibleEventV1, ...]) -> dict:
    if not population.target_dates:
        return _result("M010", population, None, 0, "NOT_COMPUTABLE")
    by_day: dict[date, list[EligibleEventV1]] = {day: [] for day in population.target_dates}
    for event in events:
        if event.city is not population.city or event.target_date not in by_day:
            return _result("M010", population, None, len(population.target_dates), "NOT_COMPUTABLE")
        by_day[event.target_date].append(event)
    for values in by_day.values():
        if values != sorted(values, key=lambda item: (item.event_seq, item.event_id)) or len({item.event_hash for item in values}) != len(values):
            return _result("M010", population, None, len(population.target_dates), "NOT_COMPUTABLE")
    return _result("M010", population, sum(bool(values) for values in by_day.values()), 0, "OK")


def m017_source_failure_rate(population: PreregisteredPopulationV1, days: tuple[FailureDayV1, ...]) -> dict:
    if not population.target_dates:
        return _result("M017", population, None, 0, "NOT_COMPUTABLE")
    by_day = {(item.city, item.target_date): item for item in days}
    if len(by_day) != len(days) or any((population.city, day) not in by_day for day in population.target_dates):
        return _result("M017", population, None, len(population.target_dates), "NOT_COMPUTABLE")
    counts = {reason: 0 for reason in REASONS}
    for day in population.target_dates:
        item = by_day[(population.city, day)]
        if item.terminal_error is not None:
            counts[next(reason for reason in REASONS if reason in item.proved_reasons)] += 1
    return _result("M017", population, sum(counts.values()), 0, "OK", tuple((reason, counts[reason]) for reason in REASONS))
