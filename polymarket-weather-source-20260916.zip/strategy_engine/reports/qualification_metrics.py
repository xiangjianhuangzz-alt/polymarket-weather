"""Isolated CD4 qualification metric computations; no thresholds are applied here."""

from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN, localcontext
from typing import Mapping
from zoneinfo import ZoneInfo

from strategy_engine.data.labels import WeatherLabel
from strategy_engine.data.records import utc_time
from strategy_engine.models.residual import q12
from strategy_v8.canonical import hash_v1, validate_exact_fields, validate_hash_v1


_RAW_SAMPLE_DOMAIN = "PWM.IIC2.RAW_TEMPERATURE_SAMPLE_SET.V1"
_RAW_SAMPLE_FIELDS = (
    "schema_version", "city", "target_date", "evaluation_event_id", "local_second",
    "residual_population_hash", "current_forecast_normalized_fact_id",
    "current_forecast_high_c_milli", "current_observation_set_hash",
    "current_observed_max_c_milli", "bucket_partition_hash", "samples",
    "raw_temperature_sample_hash",
)
_RAW_SAMPLE_HASH_FIELDS = tuple(field for field in _RAW_SAMPLE_FIELDS if field != "raw_temperature_sample_hash")
_RAW_ITEM_FIELDS = (
    "sample_ordinal", "training_target_date", "training_day_ref", "residual_c_milli",
    "x_c_milli", "bucket_id",
)


def _canonical_date(value: object) -> str:
    if type(value) is not str:
        raise ValueError("M008_TARGET_DATE_INVALID")
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError("M008_TARGET_DATE_INVALID") from exc
    if parsed.isoformat() != value:
        raise ValueError("M008_TARGET_DATE_INVALID")
    return value


def _identity_invalid() -> ValueError:
    return ValueError("M008_IDENTITY_INVALID")


def _validate_complete_local_day(label: WeatherLabel) -> None:
    """M008 consumes only the frozen complete local observation-day predicate."""
    if type(label.maximum_gap_seconds) is not int or not 0 <= label.maximum_gap_seconds <= 5400:
        raise _identity_invalid()
    zone = ZoneInfo("Asia/Shanghai")
    first = utc_time(label.first_report_time_utc).astimezone(zone)
    last = utc_time(label.last_report_time_utc).astimezone(zone)
    if (
        first.date() != label.target_date
        or last.date() != label.target_date
        or first.hour * 3600 + first.minute * 60 + first.second > 30 * 60
        or last.hour * 3600 + last.minute * 60 + last.second < 23 * 3600 + 30 * 60
    ):
        raise _identity_invalid()


def _validate_raw_sample_set(city: str, target_date: str, sample: object) -> list[int]:
    """Validate the IIC2 payload and return its canonical ordered x values."""
    if not isinstance(sample, Mapping):
        raise _identity_invalid()
    try:
        validate_exact_fields(sample, _RAW_SAMPLE_FIELDS)
        if (
            sample["schema_version"] != "RawTemperatureSampleSetV1"
            or sample["city"] != city
            or sample["target_date"] != target_date
            or type(sample["evaluation_event_id"]) is not str
            or not sample["evaluation_event_id"]
            or type(sample["local_second"]) is not int
            or not 7 * 3600 <= sample["local_second"] < 16 * 3600
            or type(sample["current_forecast_high_c_milli"]) is not int
            or type(sample["current_observed_max_c_milli"]) is not int
            or not isinstance(sample["samples"], list)
        ):
            raise _identity_invalid()
        for field in (
            "residual_population_hash", "current_forecast_normalized_fact_id",
            "current_observation_set_hash", "bucket_partition_hash", "raw_temperature_sample_hash",
        ):
            validate_hash_v1(sample[field])
        expected_hash = hash_v1(
            _RAW_SAMPLE_DOMAIN, {field: sample[field] for field in _RAW_SAMPLE_HASH_FIELDS}
        )
        if sample["raw_temperature_sample_hash"] != expected_hash:
            raise _identity_invalid()
        values: list[int] = []
        for ordinal, item in enumerate(sample["samples"]):
            validate_exact_fields(item, _RAW_ITEM_FIELDS)
            if (
                type(item["sample_ordinal"]) is not int
                or item["sample_ordinal"] != ordinal
                or _canonical_date(item["training_target_date"]) != item["training_target_date"]
                or type(item["residual_c_milli"]) is not int
                or type(item["x_c_milli"]) is not int
                or type(item["bucket_id"]) is not str
                or not item["bucket_id"]
            ):
                raise _identity_invalid()
            validate_hash_v1(item["training_day_ref"])
            values.append(item["x_c_milli"])
        return values
    except (KeyError, TypeError, ValueError) as exc:
        if isinstance(exc, ValueError) and str(exc) == "M008_IDENTITY_INVALID":
            raise
        raise _identity_invalid() from exc


def m008_weather_mae(city: str, samples: list[Mapping[str, object]]):
    """Return (sum absolute Celsius error, valid count, value, missing count, status)."""
    if type(city) is not str or not city:
        raise _identity_invalid()

    errors: list[Decimal] = []
    missing = 0
    dates: set[str] = set()
    for row in samples:
        if not isinstance(row, Mapping) or row.get("city") != city:
            raise _identity_invalid()
        target_date = _canonical_date(row.get("target_date"))
        if target_date in dates:
            raise ValueError("M008_DUPLICATE_TARGET_DATE")
        dates.add(target_date)

        sample = row.get("sample_payload")
        label = row.get("label")
        if sample is None or label is None:
            missing += 1
            continue
        if not isinstance(label, WeatherLabel):
            raise _identity_invalid()
        _validate_complete_local_day(label)
        values = _validate_raw_sample_set(city, target_date, sample)
        if (
            row.get("sample_identity") != sample["raw_temperature_sample_hash"]
            or row.get("label_identity") != label.label_hash
            or label.city.value != city
            or label.target_date.isoformat() != target_date
        ):
            raise _identity_invalid()
        if "raw_c_milli" in row and row["raw_c_milli"] != values:
            raise _identity_invalid()
        if not values:
            missing += 1
            continue
        with localcontext() as context:
            context.prec = 34
            context.rounding = ROUND_HALF_EVEN
            mean_milli = sum((Decimal(value) for value in values), Decimal(0)) / Decimal(len(values))
            errors.append(abs(mean_milli - label.final_max_c * Decimal(1000)) / Decimal(1000))

    if not errors:
        return None, None, None, missing, "NOT_COMPUTABLE"
    with localcontext() as context:
        context.prec = 34
        context.rounding = ROUND_HALF_EVEN
        total = sum(errors, Decimal(0))
        return (
            q12(total), Decimal(len(errors)), q12(total / Decimal(len(errors))), missing,
            "PARTIAL" if missing else "OK",
        )
