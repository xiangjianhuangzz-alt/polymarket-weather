"""Human- and machine-readable research metrics from walk-forward results."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, localcontext

from strategy_v8.canonical import hash_v1

from strategy_engine.backtest.engine import BacktestReportV1
from strategy_engine.data.records import decimal_text
from strategy_engine.data.records import utc_time
from strategy_engine.decision.engine import DecisionAction
from strategy_engine.models.residual import q12


ZERO = Decimal(0)
ONE = Decimal(1)


@dataclass(frozen=True, slots=True)
class MetricValueV1:
    metric_id: str
    numerator: Decimal | None
    denominator: Decimal | None
    value: Decimal | None
    missing_count: int
    population_id: str
    status: str
    reason_counts: tuple[tuple[str, int], ...]
    details_payload_hash: str


@dataclass(frozen=True, slots=True)
class StrategyReportV1:
    input_days: int
    evaluated_days: int
    buy_decisions: int
    no_action_decisions: int
    correct_direction_count: int
    prediction_accuracy: Decimal | None
    brier_score: Decimal | None
    calibration_absolute_error: Decimal | None
    average_confidence: Decimal | None
    average_conservative_edge: Decimal | None
    positive_edge_decisions: int
    total_cost_adjusted_result: Decimal
    average_cost_adjusted_result_per_buy: Decimal | None
    winning_buys: int
    metric_registry: tuple[MetricValueV1, ...]
    report_version: str
    report_hash: str


class StrategyReportEngineV1:
    """Build the frozen V1 research summary from one walk-forward report."""

    @staticmethod
    def build(backtest: BacktestReportV1) -> StrategyReportV1:
        return build_strategy_report(backtest)


def build_strategy_report(backtest: BacktestReportV1) -> StrategyReportV1:
    selected_bucket_id = backtest.selected_bucket_id
    for item in backtest.results:
        if item.settlement_bucket_id != selected_bucket_id:
            raise ValueError("settlement bucket conflicts with report binding")
        if item.evaluation is not None and item.evaluation.target_bucket_id != selected_bucket_id:
            raise ValueError("backtest decision bucket conflicts with report binding")
    evaluated_by_day = {}
    for item in sorted(backtest.results, key=lambda value: (value.target_date, value.event_seq, value.event_id)):
        if item.evaluation is not None:
            evaluated_by_day.setdefault(item.target_date, item)
    evaluated = tuple(evaluated_by_day[key] for key in sorted(evaluated_by_day))
    buys_by_day = {}
    for item in sorted((value for value in backtest.results if value.evaluation is not None), key=lambda value: (value.target_date, value.event_seq, value.event_id)):
        if item.evaluation.decision.action is DecisionAction.BUY:
            buys_by_day.setdefault(item.target_date, item)
    buys = tuple(buys_by_day[key] for key in sorted(buys_by_day))
    input_day_count = len({item.target_date for item in backtest.results})
    brier_values: list[Decimal] = []
    brier_by_day: dict[object, Decimal] = {}
    climatology_brier_by_day: dict[object, Decimal] = {}
    log_loss_values: list[Decimal] = []
    bin_weight = [ZERO for _ in range(10)]
    bin_probability = [ZERO for _ in range(10)]
    bin_outcome = [ZERO for _ in range(10)]
    confidences: list[Decimal] = []
    edges: list[Decimal] = []
    correct = 0
    for item in evaluated:
        if item.outcome_yes is None or item.true_weather_bucket_id is None:
            raise ValueError("evaluated result must have weather and settlement outcomes")
        vector = item.evaluation.calibrated_probability
        outcomes = tuple(ONE if bucket_id == item.true_weather_bucket_id else ZERO for bucket_id in vector.bucket_ids)
        day_brier = sum(((probability - outcome) ** 2 for probability, outcome in zip(vector.probabilities, outcomes)), ZERO)
        brier_values.append(day_brier)
        brier_by_day[item.target_date] = day_brier
        first_prior_by_day = {}
        for prior in sorted((value for value in backtest.results if value.target_date < item.target_date and value.true_weather_bucket_id is not None and utc_time(value.label_timestamp_utc) <= utc_time(item.evaluation.event_time_utc)), key=lambda value: (value.target_date, value.event_seq, value.event_id)):
            first_prior_by_day.setdefault(prior.target_date, prior.true_weather_bucket_id)
        prior_truths = list(first_prior_by_day.values())
        if prior_truths and all(value in vector.bucket_ids for value in prior_truths):
            denominator = Decimal(len(prior_truths))
            climatology = tuple(Decimal(prior_truths.count(bucket_id)) / denominator for bucket_id in vector.bucket_ids)
            climatology_brier_by_day[item.target_date] = sum(((probability - outcome) ** 2 for probability, outcome in zip(climatology, outcomes)), ZERO)
        true_probability = vector.probability_for(item.true_weather_bucket_id)
        clipped_probability = min(Decimal("0.999999999999"), max(Decimal("0.000000000001"), true_probability))
        with localcontext() as context:
            context.prec = 34
            log_loss_values.append(-clipped_probability.ln())
        per_bucket_weight = ONE / Decimal(len(vector.probabilities))
        for probability, outcome in zip(vector.probabilities, outcomes):
            index = min(9, int(probability * 10))
            bin_weight[index] += per_bucket_weight
            bin_probability[index] += per_bucket_weight * probability
            bin_outcome[index] += per_bucket_weight * outcome
        confidences.append(item.evaluation.confidence.score)
        edges.append(item.evaluation.decision.conservative_edge)
        predicted_bucket = vector.bucket_ids[max(range(len(vector.probabilities)), key=lambda index: vector.probabilities[index])]
        correct += int(predicted_bucket == item.true_weather_bucket_id)
    realized = tuple(item.net_return_per_unit_cost for item in buys if item.net_return_per_unit_cost is not None)
    calibration_gaps = [abs(bin_probability[i] / bin_weight[i] - bin_outcome[i] / bin_weight[i]) for i in range(10) if bin_weight[i] > ZERO]
    ece = None if not evaluated else sum((bin_weight[i] * abs(bin_probability[i] / bin_weight[i] - bin_outcome[i] / bin_weight[i]) for i in range(10) if bin_weight[i] > ZERO), ZERO) / Decimal(len(evaluated))

    def average(values: list[Decimal] | tuple[Decimal, ...]) -> Decimal | None:
        return None if not values else sum(values, ZERO) / Decimal(len(values))

    total = sum(realized, ZERO)
    payload = {
        "backtest_report_hash": backtest.report_hash,
        "selected_bucket_id": selected_bucket_id,
        "input_days": input_day_count,
        "evaluated_days": len(evaluated),
        "buy_decisions": len(buys),
        "no_action_decisions": len(evaluated) - len(buys),
        "correct_direction_count": correct,
        "prediction_accuracy": None if not evaluated else decimal_text(Decimal(correct) / Decimal(len(evaluated))),
        "brier_score": None if not brier_values else decimal_text(average(brier_values)),
        "calibration_absolute_error": None if ece is None else decimal_text(ece),
        "average_confidence": None if not confidences else decimal_text(average(confidences)),
        "average_conservative_edge": None if not edges else decimal_text(average(edges)),
        "positive_edge_decisions": sum(1 for value in edges if value > ZERO),
        "total_cost_adjusted_result": decimal_text(total),
        "average_cost_adjusted_result_per_buy": None if not realized else decimal_text(total / Decimal(len(realized))),
        "winning_buys": sum(1 for item in buys if item.outcome_yes),
        "report_version": "STRATEGY_REPORT_V1",
    }
    def metric(metric_id: str, numerator: Decimal | None, denominator: Decimal | None, value: Decimal | None, missing: int, status: str, reasons: tuple[tuple[str, int], ...] = ()) -> MetricValueV1:
        canonical_value = None if value is None else q12(value)
        population_id = hash_v1("PWM.CD4.METRIC_POPULATION.V1", {"city": backtest.city, "metric_id": metric_id, "backtest_report_hash": backtest.report_hash})
        details_hash = hash_v1("PWM.CD4.METRIC_DETAILS.V1", {"metric_id": metric_id, "population_id": population_id, "status": status, "reason_counts": list(reasons), "value": None if canonical_value is None else decimal_text(canonical_value)})
        return MetricValueV1(metric_id, numerator, denominator, canonical_value, missing, population_id, status, reasons, details_hash)

    metric_values: dict[str, MetricValueV1] = {}
    evaluated_count = Decimal(len(evaluated))
    missing_probability_days = input_day_count - len(evaluated)
    probability_status = "NOT_COMPUTABLE" if not evaluated else ("PARTIAL" if missing_probability_days else "OK")
    metric_values["M001"] = metric("M001", sum(brier_values, ZERO) if evaluated else None, evaluated_count if evaluated else None, average(brier_values), missing_probability_days, probability_status)
    common_climatology_days = tuple(sorted(set(brier_by_day) & set(climatology_brier_by_day)))
    climatology_values = tuple(climatology_brier_by_day[key] for key in common_climatology_days)
    model_common_values = tuple(brier_by_day[key] for key in common_climatology_days)
    climatology_status = "NOT_COMPUTABLE" if not climatology_values else ("PARTIAL" if len(climatology_values) < input_day_count else "OK")
    metric_values["M002"] = metric("M002", sum(climatology_values, ZERO) if climatology_values else None, Decimal(len(climatology_values)) if climatology_values else None, average(climatology_values), input_day_count - len(climatology_values), climatology_status)
    climatology_total = sum(climatology_values, ZERO)
    skill_value = None if not climatology_values or climatology_total == ZERO else ONE - sum(model_common_values, ZERO) / climatology_total
    metric_values["M003"] = metric("M003", sum(model_common_values, ZERO) if model_common_values else None, climatology_total if climatology_values else None, skill_value, input_day_count - len(common_climatology_days), "NOT_COMPUTABLE" if skill_value is None else ("PARTIAL" if len(common_climatology_days) < input_day_count else "OK"))
    metric_values["M004"] = metric("M004", sum(log_loss_values, ZERO) if evaluated else None, evaluated_count if evaluated else None, average(log_loss_values), missing_probability_days, probability_status)
    metric_values["M005"] = metric("M005", None if ece is None else ece * evaluated_count, evaluated_count if evaluated else None, ece, missing_probability_days, probability_status)
    metric_values["M006"] = metric("M006", max(calibration_gaps) if calibration_gaps else None, evaluated_count if evaluated else None, max(calibration_gaps) if calibration_gaps else None, missing_probability_days, probability_status if calibration_gaps else "NOT_COMPUTABLE")
    metric_values["M009"] = metric("M009", None, None, None, input_day_count, "NOT_COMPUTABLE", (("COMPLETE_SETTLEMENT_PARTITION_NOT_IN_REPORT_INPUT", input_day_count),))
    metric_values["M010"] = metric("M010", None, None, None, input_day_count, "NOT_COMPUTABLE", (("PREREGISTERED_POPULATION_IDENTITY_NOT_BOUND", input_day_count),))
    candidate_count = Decimal(len(buys))
    metric_values["M011"] = metric("M011", candidate_count, evaluated_count if evaluated else None, None if not evaluated else candidate_count / evaluated_count, 0, "OK" if evaluated else "NOT_COMPUTABLE")
    wins = Decimal(sum(1 for item in buys if item.outcome_yes))
    metric_values["M012"] = metric("M012", wins if buys else None, candidate_count if buys else None, None if not buys else wins / candidate_count, 0, "OK" if buys else "NOT_COMPUTABLE")
    candidate_edges = [item.evaluation.decision.conservative_edge for item in buys]
    metric_values["M013"] = metric("M013", sum(candidate_edges, ZERO) if buys else None, candidate_count if buys else None, average(candidate_edges), 0, "OK" if buys else "NOT_COMPUTABLE")
    metric_values["M014"] = metric("M014", total if buys else None, candidate_count if buys else None, average(realized), len(buys) - len(realized), "OK" if len(realized) == len(buys) and buys else ("PARTIAL" if buys else "NOT_COMPUTABLE"))
    metric_values["M015"] = metric("M015", min(realized) if realized else None, candidate_count if buys else None, min(realized) if realized else None, len(buys) - len(realized), "OK" if len(realized) == len(buys) and buys else ("PARTIAL" if buys else "NOT_COMPUTABLE"))
    cumulative = ZERO
    peak = ZERO
    drawdown = ZERO
    for value in realized:
        cumulative += value
        peak = max(peak, cumulative)
        drawdown = max(drawdown, peak - cumulative)
    metric_values["M016"] = metric("M016", drawdown if realized else None, candidate_count if buys else None, drawdown if realized else None, len(buys) - len(realized), "OK" if len(realized) == len(buys) and buys else ("PARTIAL" if buys else "NOT_COMPUTABLE"))
    deferred_reasons = {
        "M007": "LCB_ANTI_CONSERVATISM_POLICY_UNFROZEN",
        "M008": "RAW_TEMPERATURE_SAMPLE_SERIES_NOT_IN_REPORT_INPUT",
        "M017": "SOURCE_FAILURE_REASON_REGISTRY_NOT_IN_REPORT_INPUT",
        "M018": "DETERMINISTIC_REPLAY_NOT_EXECUTED",
    }
    for metric_id in (f"M{index:03d}" for index in range(1, 19)):
        if metric_id in metric_values:
            continue
        status = "POLICY_UNFROZEN" if metric_id == "M007" else "NOT_COMPUTABLE"
        reason = deferred_reasons.get(metric_id, "REQUIRES_DEDICATED_VALIDATION_INPUT")
        metric_values[metric_id] = metric(metric_id, None, None, None, input_day_count, status, ((reason, input_day_count),))
    registry = tuple(metric_values[f"M{index:03d}"] for index in range(1, 19))
    payload["metric_registry"] = [
        {
            "metric_id": item.metric_id,
            "numerator": None if item.numerator is None else decimal_text(item.numerator),
            "denominator": None if item.denominator is None else decimal_text(item.denominator),
            "value": None if item.value is None else decimal_text(item.value),
            "missing_count": item.missing_count,
            "population_id": item.population_id,
            "status": item.status,
            "reason_counts": list(item.reason_counts),
            "details_payload_hash": item.details_payload_hash,
        }
        for item in registry
    ]
    return StrategyReportV1(
        input_day_count,
        len(evaluated),
        len(buys),
        len(evaluated) - len(buys),
        correct,
        None if not evaluated else Decimal(correct) / Decimal(len(evaluated)),
        average(brier_values),
        ece,
        average(confidences),
        average(edges),
        sum(1 for value in edges if value > ZERO),
        total,
        None if not realized else total / Decimal(len(realized)),
        sum(1 for item in buys if item.outcome_yes),
        registry,
        "STRATEGY_REPORT_V1",
        hash_v1("PWM.STRATEGY_ENGINE_V1.STRATEGY_REPORT", payload),
    )
