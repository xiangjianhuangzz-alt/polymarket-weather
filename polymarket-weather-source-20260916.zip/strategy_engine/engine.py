"""End-to-end read-only Strategy Engine V1 orchestration."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from strategy_v8.canonical import hash_v1, validate_hash_v1
from strategy_v8.contracts import City

from strategy_engine.calibration.pav import PAVCalibratorV1, PAVPoint
from strategy_engine.data.normalization import NormalizedDay, SOURCE_BINDING_REGISTRY_HASH
from strategy_engine.data.labels import WEATHER_LABEL_POLICY_HASH
from strategy_engine.data.evidence import FeeEvidenceV1, MarketRuleEvidenceV1
from strategy_engine.data.records import MarketBook, decimal_text, decimal_value, utc_time
from strategy_engine.decision.engine import DecisionResult, DeltaPolicyV1, decide_buy_yes
from strategy_engine.features.engine import FeatureBundleV1, build_feature_bundle
from strategy_engine.models.residual import (
    EmpiricalResidualModelV1,
    ProbabilityVector,
    TemperatureBucket,
    TrainingSample,
    validate_bucket_partition,
)
from strategy_engine.risk.confidence import ConfidenceAssessment, confidence_score
from strategy_engine.risk.cost import CostPolicyV1, ExecutableCost, compute_c_executable
from strategy_engine.risk.lcb import BootstrapPolicyV1, PLCBResult, bootstrap_lcb


@dataclass(frozen=True, slots=True)
class ApprovedConfigSetV1:
    """Immutable research configuration binding; not execution authorization."""

    city: City
    selected_bucket_id: str
    market_id: str
    yes_token_id: str
    bucket_partition_hash: str
    delta_policy_hash: str
    lcb_policy_hash: str
    cost_policy_hash: str
    requested_yes_quantity: Decimal
    minimum_training_days: int
    minimum_calibration_days: int
    source_binding_registry_hash: str
    source_normalization_policy_hash: str
    weather_label_policy_hash: str
    model_policy_hash: str
    calibration_policy_hash: str
    metric_registry_hash: str
    qualification_policy_hash: str
    iic2_candidate_hash: str
    config_set_hash: str

    def __post_init__(self) -> None:
        from strategy_v8.canonical import validate_hash_v1
        if not self.selected_bucket_id or not self.market_id or not self.yes_token_id:
            raise ValueError("approved config set identities are required")
        for value in (self.bucket_partition_hash, self.delta_policy_hash, self.lcb_policy_hash, self.cost_policy_hash, self.source_binding_registry_hash, self.source_normalization_policy_hash, self.weather_label_policy_hash, self.model_policy_hash, self.calibration_policy_hash, self.metric_registry_hash, self.qualification_policy_hash, self.iic2_candidate_hash, self.config_set_hash):
            validate_hash_v1(value)
        if self.minimum_training_days < 1 or self.minimum_calibration_days < 1:
            raise ValueError("approved config sample thresholds must be positive")
        object.__setattr__(self, "requested_yes_quantity", decimal_value(self.requested_yes_quantity))
        payload = {
            "schema_version": "RESEARCH_APPROVED_CONFIG_SET_BINDING_V1",
            "city": self.city.value,
            "selected_bucket_id": self.selected_bucket_id,
            "market_id": self.market_id,
            "yes_token_id": self.yes_token_id,
            "bucket_partition_hash": self.bucket_partition_hash,
            "delta_policy_hash": self.delta_policy_hash,
            "lcb_policy_hash": self.lcb_policy_hash,
            "cost_policy_hash": self.cost_policy_hash,
            "requested_yes_quantity": decimal_text(self.requested_yes_quantity),
            "minimum_training_days": self.minimum_training_days,
            "minimum_calibration_days": self.minimum_calibration_days,
            "source_binding_registry_hash": self.source_binding_registry_hash,
            "source_normalization_policy_hash": self.source_normalization_policy_hash,
            "weather_label_policy_hash": self.weather_label_policy_hash,
            "model_policy_hash": self.model_policy_hash,
            "calibration_policy_hash": self.calibration_policy_hash,
            "metric_registry_hash": self.metric_registry_hash,
            "qualification_policy_hash": self.qualification_policy_hash,
            "iic2_candidate_hash": self.iic2_candidate_hash,
        }
        if self.config_set_hash != hash_v1("PWM.STRATEGY_ENGINE_V1.APPROVED_CONFIG_SET_BINDING", payload):
            raise ValueError("approved config set hash mismatch")

    @classmethod
    def create(
        cls,
        city: City,
        buckets: Iterable[TemperatureBucket],
        selected_bucket_id: str,
        market_id: str,
        yes_token_id: str,
        delta_policy: DeltaPolicyV1,
        bootstrap_policy: BootstrapPolicyV1,
        cost_policy: CostPolicyV1,
        minimum_training_days: int,
        minimum_calibration_days: int,
    ) -> "ApprovedConfigSetV1":
        partition = validate_bucket_partition(buckets)
        if selected_bucket_id not in {item.bucket_id for item in partition}:
            raise ValueError("approved config selected bucket is outside the partition")
        partition_hash = hash_v1(
            "PWM.IIC2.BUCKET_PARTITION.V1",
            [
                {
                    "bucket_id": item.bucket_id,
                    "lower_c": None if item.lower_c is None else decimal_text(item.lower_c),
                    "upper_c": None if item.upper_c is None else decimal_text(item.upper_c),
                }
                for item in partition
            ],
        )
        source_normalization_policy_hash = hash_v1("PWM.IIC2.SOURCE_NORMALIZATION_POLICY.V1", {"registry_hash": SOURCE_BINDING_REGISTRY_HASH})
        weather_label_policy_hash = WEATHER_LABEL_POLICY_HASH
        model_policy_hash = hash_v1("PWM.IIC2.EMPIRICAL_RESIDUAL_POLICY.V1", {"model_version": "PER_CITY_EMPIRICAL_RESIDUAL_V1", "feature_version": "WEATHER_FEATURES_V1"})
        calibration_policy_hash = hash_v1("PWM.IIC2.PAV_POLICY.V1", {"algorithm": "LEFTMOST_ADJACENT_VIOLATOR_EQUAL_Q_PREAGGREGATION", "extrapolation": "END_BLOCK", "interpolation": "NONE"})
        metric_registry_hash = hash_v1("PWM.CD4.METRIC_REGISTRY.V1", [f"M{index:03d}" for index in range(1, 19)])
        qualification_policy_hash = hash_v1("PWM.STRATEGY_ENGINE_V1.RESEARCH_QUALIFICATION_POLICY", {"minimum_training_days": minimum_training_days, "minimum_calibration_days": minimum_calibration_days})
        iic2_candidate_hash = "fde2c34c6f8c01e68a176b6c577eead4d931c81ab4f4ea64b41875d4c9629c03"
        payload = {
            "schema_version": "RESEARCH_APPROVED_CONFIG_SET_BINDING_V1",
            "city": city.value,
            "selected_bucket_id": selected_bucket_id,
            "market_id": market_id,
            "yes_token_id": yes_token_id,
            "bucket_partition_hash": partition_hash,
            "delta_policy_hash": delta_policy.policy_hash,
            "lcb_policy_hash": bootstrap_policy.policy_hash,
            "cost_policy_hash": cost_policy.policy_hash,
            "requested_yes_quantity": decimal_text(cost_policy.requested_yes_quantity),
            "minimum_training_days": minimum_training_days,
            "minimum_calibration_days": minimum_calibration_days,
            "source_binding_registry_hash": SOURCE_BINDING_REGISTRY_HASH,
            "source_normalization_policy_hash": source_normalization_policy_hash,
            "weather_label_policy_hash": weather_label_policy_hash,
            "model_policy_hash": model_policy_hash,
            "calibration_policy_hash": calibration_policy_hash,
            "metric_registry_hash": metric_registry_hash,
            "qualification_policy_hash": qualification_policy_hash,
            "iic2_candidate_hash": iic2_candidate_hash,
        }
        return cls(city, selected_bucket_id, market_id, yes_token_id, partition_hash, delta_policy.policy_hash, bootstrap_policy.policy_hash, cost_policy.policy_hash, cost_policy.requested_yes_quantity, minimum_training_days, minimum_calibration_days, SOURCE_BINDING_REGISTRY_HASH, source_normalization_policy_hash, weather_label_policy_hash, model_policy_hash, calibration_policy_hash, metric_registry_hash, qualification_policy_hash, iic2_candidate_hash, hash_v1("PWM.STRATEGY_ENGINE_V1.APPROVED_CONFIG_SET_BINDING", payload))


@dataclass(frozen=True, slots=True)
class StrategyConfigV1:
    city: City
    buckets: tuple[TemperatureBucket, ...]
    selected_bucket_id: str
    market_id: str
    yes_token_id: str
    delta_policy: DeltaPolicyV1
    minimum_training_days: int
    minimum_calibration_days: int
    bootstrap_policy: BootstrapPolicyV1
    cost_policy: CostPolicyV1
    approved_config_set: ApprovedConfigSetV1

    def __post_init__(self) -> None:
        partition = validate_bucket_partition(self.buckets)
        if self.selected_bucket_id not in {item.bucket_id for item in partition}:
            raise ValueError("selected bucket is outside the partition")
        object.__setattr__(self, "buckets", partition)
        if not self.market_id or not self.yes_token_id:
            raise ValueError("selected bucket requires market and YES-token binding")
        if self.delta_policy.city is not self.city:
            raise ValueError("delta policy city mismatch")
        if self.bootstrap_policy.city is not self.city or self.cost_policy.city is not self.city:
            raise ValueError("strategy policies must be city-specific")
        if self.minimum_training_days < 1 or self.minimum_calibration_days < 1:
            raise ValueError("minimum sample requirements must be positive")
        binding = self.approved_config_set
        expected_source_policy = hash_v1("PWM.IIC2.SOURCE_NORMALIZATION_POLICY.V1", {"registry_hash": SOURCE_BINDING_REGISTRY_HASH})
        expected_label_policy = WEATHER_LABEL_POLICY_HASH
        expected_model_policy = hash_v1("PWM.IIC2.EMPIRICAL_RESIDUAL_POLICY.V1", {"model_version": "PER_CITY_EMPIRICAL_RESIDUAL_V1", "feature_version": "WEATHER_FEATURES_V1"})
        expected_calibration_policy = hash_v1("PWM.IIC2.PAV_POLICY.V1", {"algorithm": "LEFTMOST_ADJACENT_VIOLATOR_EQUAL_Q_PREAGGREGATION", "extrapolation": "END_BLOCK", "interpolation": "NONE"})
        expected_metric_registry = hash_v1("PWM.CD4.METRIC_REGISTRY.V1", [f"M{index:03d}" for index in range(1, 19)])
        expected_qualification_policy = hash_v1("PWM.STRATEGY_ENGINE_V1.RESEARCH_QUALIFICATION_POLICY", {"minimum_training_days": self.minimum_training_days, "minimum_calibration_days": self.minimum_calibration_days})
        if not (
            binding.city is self.city
            and binding.selected_bucket_id == self.selected_bucket_id
            and binding.market_id == self.market_id
            and binding.yes_token_id == self.yes_token_id
            and binding.delta_policy_hash == self.delta_policy.policy_hash
            and binding.lcb_policy_hash == self.bootstrap_policy.policy_hash
            and binding.cost_policy_hash == self.cost_policy.policy_hash
            and binding.requested_yes_quantity == self.cost_policy.requested_yes_quantity
            and binding.minimum_training_days == self.minimum_training_days
            and binding.minimum_calibration_days == self.minimum_calibration_days
            and binding.source_binding_registry_hash == SOURCE_BINDING_REGISTRY_HASH
            and binding.source_normalization_policy_hash == expected_source_policy
            and binding.weather_label_policy_hash == expected_label_policy
            and binding.model_policy_hash == expected_model_policy
            and binding.calibration_policy_hash == expected_calibration_policy
            and binding.metric_registry_hash == expected_metric_registry
            and binding.qualification_policy_hash == expected_qualification_policy
            and binding.iic2_candidate_hash == "fde2c34c6f8c01e68a176b6c577eead4d931c81ab4f4ea64b41875d4c9629c03"
        ):
            raise ValueError("approved config set does not bind the strategy configuration")
        expected_partition_hash = hash_v1(
            "PWM.IIC2.BUCKET_PARTITION.V1",
            [
                {"bucket_id": item.bucket_id, "lower_c": None if item.lower_c is None else decimal_text(item.lower_c), "upper_c": None if item.upper_c is None else decimal_text(item.upper_c)}
                for item in partition
            ],
        )
        if binding.bucket_partition_hash != expected_partition_hash:
            raise ValueError("approved config set bucket partition mismatch")


@dataclass(frozen=True, slots=True)
class StrategyEvaluationV1:
    event_id: str
    event_time_utc: str
    target_bucket_id: str
    features: FeatureBundleV1
    model: EmpiricalResidualModelV1
    raw_probability: ProbabilityVector
    raw_temperature_sample_hash: str
    calibrator: PAVCalibratorV1
    calibrated_probability: ProbabilityVector
    confidence: ConfidenceAssessment
    p_lcb: PLCBResult
    executable_cost: ExecutableCost
    decision: DecisionResult
    approved_config_set_hash: str
    city: City
    source_anchor_set_hash: str
    normalized_day_hash: str
    delta_policy_hash: str
    experiment_binding_hash: str

    def __post_init__(self) -> None:
        utc_time(self.event_time_utc)
        for value in (
            self.approved_config_set_hash,
            self.source_anchor_set_hash,
            self.normalized_day_hash,
            self.delta_policy_hash,
            self.experiment_binding_hash,
        ):
            validate_hash_v1(value)
        if (
            self.decision.city is not self.city
            or self.model.city is not self.city
            or self.p_lcb.city is not self.city
            or self.decision.event_id != self.event_id
            or self.decision.bucket_id != self.target_bucket_id
            or self.decision.delta_policy_hash != self.delta_policy_hash
            or self.executable_cost.approved_config_set_hash != self.approved_config_set_hash
        ):
            raise ValueError("strategy evaluation nested identity mismatch")
        expected = hash_v1(
            "PWM.STRATEGY_ENGINE_V1.EXPERIMENT_BINDING",
            {
                "approved_config_set_hash": self.approved_config_set_hash,
                "city": self.city.value,
                "city_waterline": self.event_time_utc,
                "source_anchor_set_hash": self.source_anchor_set_hash,
                "normalized_day_hash": self.normalized_day_hash,
                "model_artifact_hash": self.model.model_artifact_hash,
                "calibration_artifact_hash": self.calibrator.calibration_hash,
                "p_lcb_artifact_hash": self.p_lcb.plcb_hash,
                "cost_artifact_hash": self.executable_cost.cost_hash,
                "delta_policy_hash": self.delta_policy_hash,
                "decision_hash": self.decision.decision_hash,
            },
        )
        if self.experiment_binding_hash != expected:
            raise ValueError("strategy evaluation experiment binding mismatch")


class StrategyEngineV1:
    """Produce a research decision without creating orders or external writes."""

    def __init__(self, config: StrategyConfigV1) -> None:
        self.config = config

    def evaluate(
        self,
        *,
        event_id: str,
        event_seq: int,
        evaluation_ordinal: int,
        day: NormalizedDay,
        book: MarketBook,
        fee_evidence: FeeEvidenceV1,
        rule_evidence: MarketRuleEvidenceV1,
        training_samples: Iterable[TrainingSample],
        calibration_points: Iterable[PAVPoint],
        data_quality: Decimal,
    ) -> StrategyEvaluationV1:
        if not event_id:
            raise ValueError("event_id must be non-empty")
        if event_seq < 1 or evaluation_ordinal < 1:
            raise ValueError("event and evaluation ordinals must be positive")
        if day.city is not self.config.city or book.city is not self.config.city:
            raise ValueError("configuration, weather, and market city must match")
        if day.target_date != book.target_date:
            raise ValueError("weather and market target date must match")
        if book.market_id != self.config.market_id or book.yes_token_id != self.config.yes_token_id:
            raise ValueError("bucket, market, and YES-token binding mismatch")
        if not book.visibility.visible_at(day.as_of_utc) or utc_time(book.captured_at_utc) > utc_time(day.as_of_utc):
            raise ValueError("market book is not visible at decision AS-OF")
        samples = tuple(training_samples)
        if any(sample.target_date >= day.target_date or utc_time(sample.available_at_utc) > utc_time(day.as_of_utc) for sample in samples):
            raise ValueError("training samples must be prior and AS-OF visible")
        model = EmpiricalResidualModelV1.fit(
            self.config.city,
            day.local_second,
            samples,
            minimum_samples=self.config.minimum_training_days,
        )
        features = build_feature_bundle(day, book, model.residuals)
        raw = model.predict(day, features.weather, self.config.buckets)
        raw_temperature_sample_hash = model.raw_temperature_sample_hash(day, features.weather, self.config.buckets, event_id)
        points = tuple(calibration_points)
        if any(point.target_date >= day.target_date or utc_time(point.available_at_utc) > utc_time(day.as_of_utc) for point in points):
            raise ValueError("calibration points must be prior and AS-OF visible")
        if len({point.target_date for point in points}) < self.config.minimum_calibration_days:
            raise ValueError("insufficient prior calibration days")
        calibrator = PAVCalibratorV1.fit(points, model_policy_hash=model.model_policy_hash)
        if calibrator.city is not self.config.city or calibrator.local_second != day.local_second:
            raise ValueError("calibrator identity does not match evaluation")
        calibrated = calibrator.calibrate_vector(raw, self.config.buckets)
        confidence = confidence_score(
            calibrated,
            sample_size=len(samples),
            target_sample_size=self.config.bootstrap_policy.minimum_cluster_days,
            data_quality=data_quality,
        )
        family_id = hash_v1(
            "PWM.IIC2.P_LCB_FAMILY.V1",
            {
                "schema_version": "PLCBFamilyV1",
                "city": self.config.city.value,
                "target_date": day.target_date.isoformat(),
                "model_artifact_hash": model.model_artifact_hash,
                "calibration_hash": calibrator.calibration_hash,
                "lcb_policy_hash": self.config.bootstrap_policy.policy_hash,
                "residual_population_hash": model.residual_population_hash,
                "bucket_partition_hash": self.config.approved_config_set.bucket_partition_hash,
                "bucket_count": len(self.config.buckets),
                "max_evaluations_per_target_day": self.config.bootstrap_policy.max_evaluations_per_target_day,
            },
        )
        lcb = bootstrap_lcb(
            model,
            day,
            features.weather,
            self.config.buckets,
            calibrator,
            self.config.bootstrap_policy,
            evaluation_identity=event_id,
            family_id=family_id,
            evaluation_ordinal=evaluation_ordinal,
            event_seq=event_seq,
            event_at_utc=day.as_of_utc,
        )
        cost = compute_c_executable(
            book,
            fee_evidence,
            rule_evidence,
            self.config.cost_policy,
            as_of_utc=day.as_of_utc,
            approved_config_set_hash=self.config.approved_config_set.config_set_hash,
        )
        delta = self.config.delta_policy.value_at(self.config.city, day.as_of_utc)
        decision = decide_buy_yes(
            city=self.config.city,
            target_date=day.target_date,
            event_id=event_id,
            bucket_id=self.config.selected_bucket_id,
            p_lcb=lcb.lower_bound_for(self.config.selected_bucket_id),
            cost=cost,
            delta=delta,
            delta_policy_hash=self.config.delta_policy.policy_hash,
            confidence_score=confidence.score,
            dependency_hashes=(
                day.normalized_day_hash,
                features.weather.feature_hash,
                features.market.book_hash,
                model.model_artifact_hash,
                raw_temperature_sample_hash,
                calibrator.calibration_hash,
                lcb.plcb_hash,
                cost.cost_hash,
            ),
        )
        experiment_binding_hash = hash_v1("PWM.STRATEGY_ENGINE_V1.EXPERIMENT_BINDING", {"approved_config_set_hash": self.config.approved_config_set.config_set_hash, "city": self.config.city.value, "city_waterline": day.as_of_utc, "source_anchor_set_hash": day.source_anchor_set_hash, "normalized_day_hash": day.normalized_day_hash, "model_artifact_hash": model.model_artifact_hash, "calibration_artifact_hash": calibrator.calibration_hash, "p_lcb_artifact_hash": lcb.plcb_hash, "cost_artifact_hash": cost.cost_hash, "delta_policy_hash": self.config.delta_policy.policy_hash, "decision_hash": decision.decision_hash})
        return StrategyEvaluationV1(
            event_id,
            day.as_of_utc,
            self.config.selected_bucket_id,
            features,
            model,
            raw,
            raw_temperature_sample_hash,
            calibrator,
            calibrated,
            confidence,
            lcb,
            cost,
            decision,
            self.config.approved_config_set.config_set_hash,
            self.config.city,
            day.source_anchor_set_hash,
            day.normalized_day_hash,
            self.config.delta_policy.policy_hash,
            experiment_binding_hash,
        )
