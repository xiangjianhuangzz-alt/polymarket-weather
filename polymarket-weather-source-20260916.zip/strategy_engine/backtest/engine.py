"""Target-day walk-forward backtest with no random split or future labels."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Iterable

from strategy_v8.canonical import hash_v1
from strategy_v8.errors import ErrorCode

from strategy_engine.calibration.pav import PAVPoint, build_oof_prediction
from strategy_engine.data.labels import WeatherLabel
from strategy_engine.data.normalization import NormalizedDay
from strategy_engine.data.records import MarketBook, decimal_text, decimal_value, utc_time
from strategy_engine.data.evidence import FeeEvidenceV1, FormalSettlementV1, MarketRuleEvidenceV1
from strategy_engine.decision.engine import DecisionAction
from strategy_engine.engine import StrategyConfigV1, StrategyEngineV1, StrategyEvaluationV1
from strategy_engine.features.engine import build_feature_bundle
from strategy_engine.models.residual import EmpiricalResidualModelV1, TrainingSample


ZERO = Decimal(0)
ONE = Decimal(1)


@dataclass(frozen=True, slots=True)
class BacktestInputDay:
    event_id: str
    event_seq: int
    day: NormalizedDay
    label: WeatherLabel
    book: MarketBook
    fee_evidence: FeeEvidenceV1
    rule_evidence: MarketRuleEvidenceV1
    settlement: FormalSettlementV1
    data_quality: Decimal

    def __post_init__(self) -> None:
        object.__setattr__(self, "data_quality", decimal_value(self.data_quality))
        if not ZERO <= self.data_quality <= ONE:
            raise ValueError("data_quality must be in [0, 1]")
        if not self.event_id or self.event_seq < 1:
            raise ValueError("event_id must be non-empty")
        if not (
            self.day.city is self.label.city is self.book.city
            and self.day.target_date == self.label.target_date == self.book.target_date
        ):
            raise ValueError("backtest input identities must match")
        if not (
            self.settlement.city is self.day.city
            and self.settlement.target_date == self.day.target_date
            and self.settlement.market_id == self.book.market_id
            and self.settlement.yes_token_id == self.book.yes_token_id
        ):
            raise ValueError("formal settlement identity does not match the event")
        if utc_time(self.label.label_timestamp_utc) <= utc_time(self.day.as_of_utc):
            raise ValueError("evaluation label must not be available at prediction AS-OF")


@dataclass(frozen=True, slots=True)
class BacktestResultDay:
    target_date: date
    event_id: str
    event_seq: int
    status: str
    evaluation: StrategyEvaluationV1 | None
    true_weather_bucket_id: str | None
    outcome_yes: bool | None
    settlement_hash: str | None
    settlement_bucket_id: str
    label_hash: str
    label_timestamp_utc: str
    realized_value_per_share: Decimal | None
    net_return_per_unit_cost: Decimal | None
    error_code: ErrorCode | None


@dataclass(frozen=True, slots=True)
class BacktestReportV1:
    city: str
    split_method: str
    selected_bucket_id: str
    approved_config_set_hash: str
    bucket_partition_hash: str
    results: tuple[BacktestResultDay, ...]
    report_hash: str

    def __post_init__(self) -> None:
        payload = {
            "city": self.city,
            "split_method": self.split_method,
            "selected_bucket_id": self.selected_bucket_id,
            "approved_config_set_hash": self.approved_config_set_hash,
            "bucket_partition_hash": self.bucket_partition_hash,
            "results": [_result_payload(item) for item in self.results],
        }
        if self.report_hash != hash_v1("PWM.STRATEGY_ENGINE_V1.BACKTEST_REPORT", payload):
            raise ValueError("backtest report hash mismatch")


def _result_payload(item: BacktestResultDay) -> dict[str, object]:
    return {
        "target_date": item.target_date.isoformat(),
        "event_id": item.event_id,
        "event_seq": item.event_seq,
        "status": item.status,
        "decision_hash": None if item.evaluation is None else item.evaluation.decision.decision_hash,
        "experiment_binding_hash": None if item.evaluation is None else item.evaluation.experiment_binding_hash,
        "true_weather_bucket_id": item.true_weather_bucket_id,
        "outcome_yes": item.outcome_yes,
        "settlement_hash": item.settlement_hash,
        "settlement_bucket_id": item.settlement_bucket_id,
        "label_hash": item.label_hash,
        "label_timestamp_utc": item.label_timestamp_utc,
        "realized_value_per_share": None if item.realized_value_per_share is None else decimal_text(item.realized_value_per_share),
        "net_return_per_unit_cost": None if item.net_return_per_unit_cost is None else decimal_text(item.net_return_per_unit_cost),
        "error_code": None if item.error_code is None else item.error_code.value,
    }


class WalkForwardBacktestV1:
    def __init__(self, config: StrategyConfigV1) -> None:
        self.config = config
        self.engine = StrategyEngineV1(config)

    def run(self, records: Iterable[BacktestInputDay]) -> BacktestReportV1:
        ordered = tuple(sorted(records, key=lambda item: (item.day.target_date, item.event_seq, item.event_id)))
        if not ordered:
            raise ValueError("backtest requires input days")
        if any(item.day.city is not self.config.city for item in ordered):
            raise ValueError("cross-city backtest input is forbidden")
        if any(item.settlement.bucket_id != self.config.selected_bucket_id for item in ordered):
            raise ValueError("formal settlement bucket does not match configured market")
        event_keys = [(item.day.target_date, item.event_seq, item.event_id) for item in ordered]
        if len(set(event_keys)) != len(event_keys):
            raise ValueError("duplicate dynamic evaluation identity")
        by_day_seq: dict[date, list[int]] = {}
        by_day_seconds: dict[date, list[int]] = {}
        for item in ordered:
            by_day_seq.setdefault(item.day.target_date, []).append(item.event_seq)
            by_day_seconds.setdefault(item.day.target_date, []).append(item.day.local_second)
        if any(values != sorted(set(values)) for values in by_day_seq.values()):
            raise ValueError("event sequence must be unique and ordered per target day")
        if any(values != sorted(set(values)) for values in by_day_seconds.values()):
            raise ValueError("dynamic local seconds must be unique and ordered per target day")
        label_identities_by_day: dict[date, set[tuple[str, str, str]]] = {}
        settlement_identities_by_day: dict[date, set[str]] = {}
        for item in ordered:
            matches = tuple(bucket.bucket_id for bucket in self.config.buckets if bucket.contains(item.label.final_max_c))
            if len(matches) != 1:
                raise ValueError("weather label does not map to one bucket")
            label_identities_by_day.setdefault(item.day.target_date, set()).add((item.label.label_hash, item.label.label_timestamp_utc, matches[0]))
            settlement_identities_by_day.setdefault(item.day.target_date, set()).add(item.settlement.settlement_hash)
        if any(len(values) != 1 for values in label_identities_by_day.values()):
            raise ValueError("conflicting target-day weather label identity")
        if any(len(values) != 1 for values in settlement_identities_by_day.values()):
            raise ValueError("conflicting target-day formal settlement identity")

        historical: dict[tuple[date, int], BacktestInputDay] = {}
        calibration_history: list[tuple[str, tuple[PAVPoint, ...]]] = []
        calibrated_day_slots: set[tuple[date, int]] = set()
        results: list[BacktestResultDay] = []
        for record in ordered:
            evaluation_as_of = utc_time(record.day.as_of_utc)
            true_buckets = [item.bucket_id for item in self.config.buckets if item.contains(record.label.final_max_c)]
            if len(true_buckets) != 1:
                raise ValueError("weather label does not map to one bucket")
            true_bucket_id = true_buckets[0]
            prior = [
                item
                for item in historical.values()
                if item.day.target_date < record.day.target_date
                and utc_time(item.label.label_timestamp_utc) <= evaluation_as_of
                and item.day.local_second == record.day.local_second
            ]
            samples = tuple(self._training_sample(item) for item in prior)
            if len(samples) < self.config.minimum_training_days:
                results.append(BacktestResultDay(record.day.target_date, record.event_id, record.event_seq, "INSUFFICIENT_PRIOR_TRAINING_DAYS", None, true_bucket_id, record.settlement.outcome_yes, record.settlement.settlement_hash, record.settlement.bucket_id, record.label.label_hash, record.label.label_timestamp_utc, None, None, ErrorCode.E_QUALIFICATION_REJECTED))
                historical.setdefault((record.day.target_date, record.day.local_second), record)
                continue

            model = EmpiricalResidualModelV1.fit(
                self.config.city,
                record.day.local_second,
                samples,
                minimum_samples=self.config.minimum_training_days,
            )
            features = build_feature_bundle(record.day, record.book, model.residuals)
            raw = model.predict(record.day, features.weather, self.config.buckets)
            calibration_points = tuple(
                point
                for available_at, points in calibration_history
                if utc_time(available_at) <= evaluation_as_of
                for point in points
                if point.local_second == record.day.local_second
            )
            if len({point.target_date for point in calibration_points}) < self.config.minimum_calibration_days:
                results.append(BacktestResultDay(record.day.target_date, record.event_id, record.event_seq, "INSUFFICIENT_PRIOR_CALIBRATION_DAYS", None, true_bucket_id, record.settlement.outcome_yes, record.settlement.settlement_hash, record.settlement.bucket_id, record.label.label_hash, record.label.label_timestamp_utc, None, None, ErrorCode.E_QUALIFICATION_REJECTED))
            else:
                try:
                    # This V1 backtest admits at most one evaluation into each
                    # family because local_second is part of the model/calibration identity.
                    ordinal = 1
                    evaluation = self.engine.evaluate(
                        event_id=record.event_id,
                        event_seq=record.event_seq,
                        evaluation_ordinal=ordinal,
                        day=record.day,
                        book=record.book,
                        fee_evidence=record.fee_evidence,
                        rule_evidence=record.rule_evidence,
                        training_samples=samples,
                        calibration_points=calibration_points,
                        data_quality=record.data_quality,
                    )
                    outcome = record.settlement.outcome_yes
                    realized = None
                    net_return = None
                    if evaluation.decision.action is DecisionAction.BUY:
                        realized = ONE - evaluation.executable_cost.c_executable if outcome else -evaluation.executable_cost.c_executable
                        net_return = realized / evaluation.executable_cost.c_executable
                    results.append(BacktestResultDay(record.day.target_date, record.event_id, record.event_seq, "EVALUATED", evaluation, true_bucket_id, outcome, record.settlement.settlement_hash, record.settlement.bucket_id, record.label.label_hash, record.label.label_timestamp_utc, realized, net_return, ErrorCode.OK))
                except ValueError:
                    results.append(BacktestResultDay(record.day.target_date, record.event_id, record.event_seq, "FAIL_CLOSED", None, true_bucket_id, record.settlement.outcome_yes, record.settlement.settlement_hash, record.settlement.bucket_id, record.label.label_hash, record.label.label_timestamp_utc, None, None, ErrorCode.E_APPROVAL_INPUT_INVALID))

            day_slot = (record.day.target_date, record.day.local_second)
            if day_slot not in calibrated_day_slots:
                calibration_history.append(
                    (record.label.label_timestamp_utc, self._calibration_points(record, model, features.weather))
                )
                calibrated_day_slots.add(day_slot)
            historical.setdefault(day_slot, record)

        payload = {
            "city": self.config.city.value,
            "split_method": "TARGET_DAY_WALK_FORWARD_STRICT_ASOF_V1",
            "selected_bucket_id": self.config.selected_bucket_id,
            "approved_config_set_hash": self.config.approved_config_set.config_set_hash,
            "bucket_partition_hash": self.config.approved_config_set.bucket_partition_hash,
            "results": [_result_payload(item) for item in results],
        }
        return BacktestReportV1(
            self.config.city.value,
            "TARGET_DAY_WALK_FORWARD_STRICT_ASOF_V1",
            self.config.selected_bucket_id,
            self.config.approved_config_set.config_set_hash,
            self.config.approved_config_set.bucket_partition_hash,
            tuple(results),
            hash_v1("PWM.STRATEGY_ENGINE_V1.BACKTEST_REPORT", payload),
        )

    @staticmethod
    def _training_sample(record: BacktestInputDay) -> TrainingSample:
        return TrainingSample(
            record.day.city,
            record.day.target_date,
            record.day.local_second,
            record.day.forecast_high_c,
            record.day.source_anchor_set,
            record.label,
        )

    def _calibration_points(
        self,
        record: BacktestInputDay,
        model: EmpiricalResidualModelV1,
        weather_features,
    ) -> tuple[PAVPoint, ...]:
        boundary_count = len(self.config.buckets) - 1
        base_weight = ONE / Decimal(boundary_count)
        assigned = ZERO
        points: list[PAVPoint] = []
        for index, bucket in enumerate(self.config.buckets[:-1]):
            if bucket.upper_c is None:
                raise ValueError("finite calibration boundary is required")
            weight = ONE - assigned if index == boundary_count - 1 else base_weight
            points.append(
                PAVPoint(
                    build_oof_prediction(model, record.day, weather_features, self.config.buckets, index, record.label),
                    weight,
                    record.label,
                )
            )
            assigned += weight
        return tuple(points)
