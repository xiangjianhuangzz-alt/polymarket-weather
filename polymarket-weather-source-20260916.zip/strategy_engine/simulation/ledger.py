"""SQLite-backed SIM_USD reservation, FOK fill, and formal-settlement ledger."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN, localcontext
import sqlite3

from strategy_engine.data.evidence import FormalSettlementV1

ZERO = Decimal("0")
_MONEY_QUANTUM = Decimal("0.000000000001")
_CITIES = {"SHANGHAI", "BEIJING", "GUANGZHOU"}


@contextmanager
def _money_context():
    """Use one fixed, sufficiently large context for every ledger calculation."""
    with localcontext() as context:
        context.prec = 34
        context.rounding = ROUND_HALF_EVEN
        yield


def _money(value: object) -> Decimal:
    if isinstance(value, bool) or isinstance(value, float):
        raise ValueError("SIMULATION_AMOUNT_INVALID")
    try:
        with _money_context():
            amount = Decimal(str(value))
            if amount != amount.quantize(_MONEY_QUANTUM):
                raise ValueError("SIMULATION_AMOUNT_INVALID")
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("SIMULATION_AMOUNT_INVALID") from exc
    if not amount.is_finite() or amount.is_signed() or (amount == ZERO and amount.as_tuple().sign):
        raise ValueError("SIMULATION_AMOUNT_INVALID")
    return amount


class SimulationLedger:
    """Pure virtual ledger. Callers must validate qualification/cost evidence upstream."""

    def __init__(self, path: str, *, initial_cash: object = "1000"):
        if _money(initial_cash) != Decimal("1000"):
            raise ValueError("SIMULATION_INITIAL_CASH_INVALID")
        self.db = sqlite3.connect(path, isolation_level=None)
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript(
            "CREATE TABLE IF NOT EXISTS account(k INTEGER PRIMARY KEY CHECK(k=1),cash TEXT NOT NULL);"
            "CREATE TABLE IF NOT EXISTS intent("
            "id TEXT PRIMARY KEY, city TEXT NOT NULL, target_date TEXT NOT NULL, market TEXT NOT NULL, token TEXT NOT NULL,"
            "qty INTEGER NOT NULL CHECK(qty=5), original TEXT NOT NULL, execution TEXT, actual TEXT, unspent TEXT,"
            "payout TEXT, settlement_hash TEXT, state TEXT NOT NULL);"
            "CREATE UNIQUE INDEX IF NOT EXISTS one_unsettled_target ON intent(market,token) WHERE state IN ('PENDING','FILLED');"
        )
        if self.db.execute("SELECT 1 FROM account WHERE k=1").fetchone() is None:
            self.db.execute("INSERT INTO account VALUES(1,'1000')")

    def close(self) -> None:
        self.db.close()

    @contextmanager
    def _tx(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def _totals(self) -> tuple[Decimal, Decimal, Decimal]:
        with _money_context():
            cash = Decimal(self.db.execute("SELECT cash FROM account WHERE k=1").fetchone()[0])
            pending = sum((Decimal(row[0]) for row in self.db.execute("SELECT original FROM intent WHERE state='PENDING'")), ZERO)
            frozen = sum((Decimal(row[0]) for row in self.db.execute("SELECT unspent FROM intent WHERE state='FILLED'")), ZERO)
            return cash, pending, frozen

    def reserve(self, intent_id: str, city: str, target_date: date, market: str, token: str, quantity: int, conservative_debit: object) -> str:
        debit = _money(conservative_debit)
        if not intent_id or city not in _CITIES or type(target_date) is not date or not market or not token or type(quantity) is not int or quantity != 5:
            raise ValueError("SIMULATION_INTENT_INVALID")
        with self._tx(), _money_context():
            old = self.db.execute("SELECT city,target_date,market,token,qty,original,state FROM intent WHERE id=?", (intent_id,)).fetchone()
            if old:
                if old == (city, target_date.isoformat(), market, token, quantity, str(debit), "PENDING"):
                    return "PENDING"
                raise ValueError("SIMULATION_IDENTITY_CONFLICT")
            if self.db.execute("SELECT 1 FROM intent WHERE market=? AND token=? AND state IN ('PENDING','FILLED')", (market, token)).fetchone():
                raise ValueError("DUPLICATE_POSITION_REJECTED")
            cash, pending, frozen = self._totals()
            city_out = sum((Decimal(row[0]) for row in self.db.execute("SELECT COALESCE(execution,original) FROM intent WHERE city=? AND state IN ('PENDING','FILLED')", (city,))), ZERO)
            portfolio = pending + sum((Decimal(row[0]) for row in self.db.execute("SELECT execution FROM intent WHERE state='FILLED'")), ZERO)
            if cash - pending - frozen < debit:
                raise ValueError("CASH_LIMIT_REJECTED")
            if city_out + debit > Decimal("100"):
                raise ValueError("CITY_OUTSTANDING_LIMIT_REJECTED")
            if portfolio + debit > Decimal("250"):
                raise ValueError("PORTFOLIO_OUTSTANDING_LIMIT_REJECTED")
            self.db.execute("INSERT INTO intent(id,city,target_date,market,token,qty,original,state) VALUES(?,?,?,?,?,?,?,'PENDING')", (intent_id, city, target_date.isoformat(), market, token, quantity, str(debit)))
            return "PENDING"

    def fill(self, intent_id: str, quantity: int, execution_total_debit: object, actual_cash_debit: object) -> str:
        execution = _money(execution_total_debit)
        actual = _money(actual_cash_debit)
        if type(quantity) is not int or quantity != 5 or actual > execution:
            raise ValueError("ACTUAL_DEBIT_EXCEEDS_CONSERVATIVE_RESERVE_REJECTED")
        with self._tx(), _money_context():
            row = self.db.execute("SELECT city,original,execution,actual,state FROM intent WHERE id=?", (intent_id,)).fetchone()
            if not row:
                raise ValueError("SIMULATION_INTENT_INVALID")
            city, original, old_execution, old_actual, state = row
            if state == "FILLED":
                if old_execution == str(execution) and old_actual == str(actual):
                    return "FILLED"
                raise ValueError("SIMULATION_IDENTITY_CONFLICT")
            if state != "PENDING":
                raise ValueError("SIMULATION_STATE_INVALID")
            cash, pending, frozen = self._totals()
            original = Decimal(original)
            city_other = sum((Decimal(row[0]) for row in self.db.execute("SELECT COALESCE(execution,original) FROM intent WHERE city=? AND state IN ('PENDING','FILLED') AND id<>?", (city, intent_id))), ZERO)
            portfolio_other = sum((Decimal(row[0]) for row in self.db.execute("SELECT COALESCE(execution,original) FROM intent WHERE state IN ('PENDING','FILLED') AND id<>?", (intent_id,))), ZERO)
            if cash - (pending - original) - frozen - actual - (execution - actual) < ZERO:
                raise ValueError("CASH_LIMIT_REJECTED")
            if city_other + execution > Decimal("100") or portfolio_other + execution > Decimal("250"):
                raise ValueError("PORTFOLIO_OUTSTANDING_LIMIT_REJECTED")
            self.db.execute("UPDATE account SET cash=? WHERE k=1", (str(cash - actual),))
            self.db.execute("UPDATE intent SET execution=?,actual=?,unspent=?,state='FILLED' WHERE id=?", (str(execution), str(actual), str(execution - actual), intent_id))
            return "FILLED"

    def reject(self, intent_id: str) -> str:
        with self._tx():
            row = self.db.execute("SELECT state FROM intent WHERE id=?", (intent_id,)).fetchone()
            if not row:
                raise ValueError("SIMULATION_INTENT_INVALID")
            if row[0] == "REJECTED":
                return "REJECTED"
            if row[0] != "PENDING":
                raise ValueError("SIMULATION_STATE_INVALID")
            self.db.execute("UPDATE intent SET state='REJECTED' WHERE id=?", (intent_id,))
            return "REJECTED"

    def settle(self, intent_id: str, settlement: FormalSettlementV1) -> str:
        if not isinstance(settlement, FormalSettlementV1) or type(settlement.outcome_yes) is not bool:
            raise ValueError("SETTLEMENT_PENDING_OR_INVALID")
        try:
            settlement.__post_init__()
        except (AttributeError, ValueError) as exc:
            raise ValueError("SETTLEMENT_PENDING_OR_INVALID") from exc
        with self._tx(), _money_context():
            row = self.db.execute("SELECT city,target_date,market,token,payout,settlement_hash,state FROM intent WHERE id=?", (intent_id,)).fetchone()
            if not row:
                raise ValueError("SIMULATION_INTENT_INVALID")
            city, target_day, market, token, payout, old_hash, state = row
            if (settlement.city.value, settlement.target_date.isoformat(), settlement.market_id, settlement.yes_token_id) != (city, target_day, market, token):
                raise ValueError("SETTLEMENT_PENDING_OR_INVALID")
            payout_value = Decimal("5") if settlement.outcome_yes else ZERO
            if state == "SETTLED":
                if payout == str(payout_value) and old_hash == settlement.settlement_hash:
                    return "SETTLED"
                raise ValueError("SIMULATION_IDENTITY_CONFLICT")
            if state != "FILLED":
                raise ValueError("SETTLEMENT_PENDING_OR_INVALID")
            cash = Decimal(self.db.execute("SELECT cash FROM account WHERE k=1").fetchone()[0])
            self.db.execute("UPDATE account SET cash=? WHERE k=1", (str(cash + payout_value),))
            self.db.execute("UPDATE intent SET payout=?,settlement_hash=?,state='SETTLED' WHERE id=?", (str(payout_value), settlement.settlement_hash, intent_id))
            return "SETTLED"

    def balances(self) -> dict[str, Decimal]:
        with _money_context():
            cash, pending, frozen = self._totals()
            return {"cash": cash, "pending_reservation": pending, "unspent_filled_reserve": frozen, "available_cash": cash - pending - frozen}
