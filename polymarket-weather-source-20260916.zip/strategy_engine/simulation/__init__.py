"""Isolated virtual simulation primitives; no live execution capability."""
