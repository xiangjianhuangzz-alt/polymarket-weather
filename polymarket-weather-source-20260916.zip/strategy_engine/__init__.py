"""Research-only New Dynamic Strategy Model V1.

The package produces predictions and BUY/NO_ACTION research decisions.  It has
no order, wallet, paper-trading, live-trading, service, or deployment entrypoint.
"""

from .engine import ApprovedConfigSetV1, StrategyConfigV1, StrategyEngineV1, StrategyEvaluationV1

__all__ = ["ApprovedConfigSetV1", "StrategyConfigV1", "StrategyEngineV1", "StrategyEvaluationV1"]
