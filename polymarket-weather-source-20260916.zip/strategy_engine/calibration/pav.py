"""Deterministic, target-day-equal-weight PAV calibration."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Iterable

from strategy_v8.canonical import hash_v1, validate_hash_v1
from strategy_v8.contracts import City

from strategy_engine.data.records import decimal_text, decimal_value
from strategy_engine.data.records import utc_time
from strategy_engine.data.labels import WEATHER_LABEL_POLICY_HASH, WeatherLabel
from strategy_engine.data.normalization import NormalizedDay
from strategy_engine.features.engine import WeatherFeaturesV1
from strategy_engine.models.residual import (
    EmpiricalResidualModelV1,
    ProbabilityVector,
    TemperatureBucket,
    make_probability_vector,
    q12,
    validate_bucket_partition,
)


ZERO = Decimal(0)
ONE = Decimal(1)
E12 = Decimal(1_000_000_000_000)


def scaled_e12(value: Decimal) -> int:
    return int((q12(value) * E12).to_integral_exact())


@dataclass(frozen=True, slots=True, init=False)
class OOFPredictionV1:
    city: City
    validation_target_date: date
    local_second: int
    q: Decimal
    boundary_c: Decimal
    prediction_asof_utc: str
    model_artifact_hash: str
    training_target_dates: tuple[date, ...]
    ordered_training_day_refs: tuple[str, ...]
    weather_label_hash: str
    oof_prediction_hash: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "q", decimal_value(self.q))
        object.__setattr__(self, "boundary_c", decimal_value(self.boundary_c))
        if not ZERO <= self.q <= ONE or any(item >= self.validation_target_date for item in self.training_target_dates):
            raise ValueError("invalid OOF prediction")
        if len(self.training_target_dates) != len(self.ordered_training_day_refs):
            raise ValueError("OOF training identity shape mismatch")
        if self.training_target_dates != tuple(sorted(set(self.training_target_dates))):
            raise ValueError("OOF training days must be unique canonical order")
        validate_hash_v1(self.model_artifact_hash)
        validate_hash_v1(self.weather_label_hash)
        for value in self.ordered_training_day_refs:
            validate_hash_v1(value)
        utc_time(self.prediction_asof_utc)
        payload = {"schema_version": "OOFPredictionV1", "city": self.city.value, "validation_target_date": self.validation_target_date.isoformat(), "local_second": self.local_second, "finite_boundary_c_milli": int(self.boundary_c * 1000), "raw_cdf_q": decimal_text(self.q), "prediction_asof_utc": self.prediction_asof_utc, "model_artifact_hash": self.model_artifact_hash, "training_target_dates": [item.isoformat() for item in self.training_target_dates], "ordered_training_day_refs": list(self.ordered_training_day_refs), "weather_label_hash": self.weather_label_hash}
        if self.oof_prediction_hash != hash_v1("PWM.IIC2.OOF_PREDICTION.V1", payload):
            raise ValueError("OOF prediction hash mismatch")

    @classmethod
    def _from_verified(cls, city: City, validation_target_date: date, local_second: int, q: Decimal, boundary_c: Decimal, prediction_asof_utc: str, model_artifact_hash: str, training_target_dates: tuple[date, ...], ordered_training_day_refs: tuple[str, ...], weather_label_hash: str) -> "OOFPredictionV1":
        payload = {"schema_version": "OOFPredictionV1", "city": city.value, "validation_target_date": validation_target_date.isoformat(), "local_second": local_second, "finite_boundary_c_milli": int(decimal_value(boundary_c) * 1000), "raw_cdf_q": decimal_text(decimal_value(q)), "prediction_asof_utc": prediction_asof_utc, "model_artifact_hash": model_artifact_hash, "training_target_dates": [item.isoformat() for item in training_target_dates], "ordered_training_day_refs": list(ordered_training_day_refs), "weather_label_hash": weather_label_hash}
        candidate = object.__new__(cls)
        values = (city, validation_target_date, local_second, decimal_value(q), decimal_value(boundary_c), prediction_asof_utc, model_artifact_hash, training_target_dates, ordered_training_day_refs, weather_label_hash, hash_v1("PWM.IIC2.OOF_PREDICTION.V1", payload))
        for name, value in zip(cls.__dataclass_fields__, values):
            object.__setattr__(candidate, name, value)
        candidate.__post_init__()
        return candidate


def build_oof_prediction(
    model: EmpiricalResidualModelV1,
    day: NormalizedDay,
    weather_features: WeatherFeaturesV1,
    buckets: Iterable[TemperatureBucket],
    boundary_ordinal: int,
    label: WeatherLabel,
) -> OOFPredictionV1:
    partition = validate_bucket_partition(buckets)
    if not 0 <= boundary_ordinal < len(partition) - 1:
        raise ValueError("OOF boundary ordinal is invalid")
    boundary = partition[boundary_ordinal].upper_c
    if boundary is None:
        raise ValueError("OOF boundary must be finite")
    if label.city is not day.city or label.target_date != day.target_date:
        raise ValueError("OOF validation label identity mismatch")
    vector = model.predict(day, weather_features, partition)
    q = sum(vector.probabilities[: boundary_ordinal + 1], ZERO)
    return OOFPredictionV1._from_verified(model.city, day.target_date, day.local_second, q, boundary, day.as_of_utc, model.model_artifact_hash, tuple(item.target_date for item in model.samples), tuple(item.training_day_ref for item in model.samples), label.label_hash)


@dataclass(frozen=True, slots=True)
class PAVPoint:
    oof_prediction: OOFPredictionV1
    weight: Decimal
    weather_label: WeatherLabel

    def __post_init__(self) -> None:
        object.__setattr__(self, "weight", decimal_value(self.weight))
        if self.weight <= ZERO:
            raise ValueError("invalid PAV point")
        if self.weather_label.city is not self.city or self.weather_label.target_date != self.target_date:
            raise ValueError("PAV label city mismatch")
        if self.weather_label.weather_label_policy_hash != WEATHER_LABEL_POLICY_HASH:
            raise ValueError("PAV point uses a different WeatherLabel policy")
        if self.oof_prediction.weather_label_hash != self.weather_label.label_hash:
            raise ValueError("PAV OOF prediction is not bound to its weather label")
        if utc_time(self.oof_prediction.prediction_asof_utc) >= utc_time(self.available_at_utc):
            raise ValueError("OOF prediction must precede label availability")

    @property
    def city(self) -> City:
        return self.oof_prediction.city

    @property
    def local_second(self) -> int:
        return self.oof_prediction.local_second

    @property
    def q(self) -> Decimal:
        return self.oof_prediction.q

    @property
    def boundary_c(self) -> Decimal:
        return self.oof_prediction.boundary_c

    @property
    def oof_prediction_ref(self) -> str:
        return self.oof_prediction.oof_prediction_hash

    @property
    def outcome(self) -> int:
        return int(self.weather_label.final_max_c < self.boundary_c)

    @property
    def target_date(self) -> date:
        return self.oof_prediction.validation_target_date

    @property
    def available_at_utc(self) -> str:
        return self.weather_label.label_timestamp_utc

    @property
    def point_hash(self) -> str:
        return hash_v1(
            "PWM.IIC2.PAV_POINT.V1",
            {
                "schema_version": "PAVPointV1",
                "city": self.city.value,
                "validation_target_date": self.target_date.isoformat(),
                "local_second": self.local_second,
                "finite_boundary_c_milli": int(self.boundary_c * 1000),
                "raw_cdf_q": decimal_text(self.q),
                "outcome_y": self.outcome,
                "weight": decimal_text(self.weight),
                "oof_prediction_ref": self.oof_prediction_ref,
            },
        )


@dataclass(frozen=True, slots=True)
class PAVBlock:
    block_ordinal: int
    q_min: Decimal
    q_max: Decimal
    total_weight: Decimal
    weighted_outcome: Decimal
    fitted_probability: Decimal
    first_point_ordinal: int
    last_point_ordinal: int
    ordered_member_point_hashes: tuple[str, ...]
    block_hash: str

    def __post_init__(self) -> None:
        payload = {"schema_version": "PAVBlockV1", "block_ordinal": self.block_ordinal, "q_min": scaled_e12(self.q_min), "q_max": scaled_e12(self.q_max), "total_weight": decimal_text(self.total_weight), "weighted_y_sum": decimal_text(self.weighted_outcome), "fitted_probability": scaled_e12(self.fitted_probability), "first_point_ordinal": self.first_point_ordinal, "last_point_ordinal": self.last_point_ordinal, "ordered_member_point_hashes": list(self.ordered_member_point_hashes)}
        if self.block_hash != hash_v1("PWM.IIC2.PAV_BLOCK.V1", payload):
            raise ValueError("PAV block hash mismatch")


@dataclass(frozen=True, slots=True)
class PAVCalibratorV1:
    city: City
    local_second: int
    calibration_version: str
    blocks: tuple[PAVBlock, ...]
    ordered_point_hashes: tuple[str, ...]
    strict_asof_waterline: str
    model_policy_hash: str
    oof_population_hash: str
    pav_policy_hash: str
    calibration_hash: str

    def __post_init__(self) -> None:
        if not self.blocks or tuple(block.block_ordinal for block in self.blocks) != tuple(range(len(self.blocks))):
            raise ValueError("PAV blocks must be non-empty and contiguous")
        payload = {"schema_version": "PAVArtifactV1", "city": self.city.value, "local_second": self.local_second, "strict_asof_waterline": self.strict_asof_waterline, "model_policy_hash": self.model_policy_hash, "oof_population_hash": self.oof_population_hash, "ordered_point_hashes": list(self.ordered_point_hashes), "pav_policy_hash": self.pav_policy_hash, "ordered_blocks": [{"q_min": scaled_e12(block.q_min), "q_max": scaled_e12(block.q_max), "total_weight": decimal_text(block.total_weight), "weighted_y_sum": decimal_text(block.weighted_outcome), "fitted_probability": scaled_e12(block.fitted_probability), "block_ordinal": block.block_ordinal, "first_point_ordinal": block.first_point_ordinal, "last_point_ordinal": block.last_point_ordinal, "ordered_member_point_hashes": list(block.ordered_member_point_hashes), "block_hash": block.block_hash} for block in self.blocks]}
        if self.calibration_hash != hash_v1("PWM.IIC2.PAV_ARTIFACT.V1", payload):
            raise ValueError("PAV artifact hash mismatch")

    @classmethod
    def fit(cls, points: Iterable[PAVPoint], *, model_policy_hash: str) -> "PAVCalibratorV1":
        ordered = sorted(
            points,
            key=lambda point: (
                point.q,
                point.target_date,
                point.boundary_c,
                point.oof_prediction_ref,
                point.point_hash,
            ),
        )
        if not ordered:
            raise ValueError("PAV requires OOF points")
        city = ordered[0].city
        local_second = ordered[0].local_second
        if any(point.city is not city or point.local_second != local_second for point in ordered):
            raise ValueError("PAV cannot combine cities or local_second values")
        weights: dict[date, Decimal] = {}
        for point in ordered:
            weights[point.target_date] = weights.get(point.target_date, ZERO) + point.weight
        if any(total != ONE for total in weights.values()):
            raise ValueError("each target day must have total PAV weight one")

        aggregates: list[dict[str, object]] = []
        for point_ordinal, point in enumerate(ordered):
            if aggregates and aggregates[-1]["q_min"] == point.q:
                aggregates[-1]["weight"] += point.weight
                aggregates[-1]["weighted_y"] += point.weight * Decimal(point.outcome)
                aggregates[-1]["last"] = point_ordinal
                aggregates[-1]["members"].append(point.point_hash)
            else:
                aggregates.append({"q_min": point.q, "q_max": point.q, "weight": point.weight, "weighted_y": point.weight * Decimal(point.outcome), "first": point_ordinal, "last": point_ordinal, "members": [point.point_hash]})
        index = 0
        while index < len(aggregates) - 1:
            left, right = aggregates[index], aggregates[index + 1]
            if left["weighted_y"] / left["weight"] <= right["weighted_y"] / right["weight"]:
                index += 1
                continue
            aggregates[index : index + 2] = [
                {"q_min": left["q_min"], "q_max": right["q_max"], "weight": left["weight"] + right["weight"], "weighted_y": left["weighted_y"] + right["weighted_y"], "first": left["first"], "last": right["last"], "members": left["members"] + right["members"]}
            ]
            index = max(0, index - 1)
        blocks_list = []
        for ordinal, item in enumerate(aggregates):
            block_payload = {"schema_version": "PAVBlockV1", "block_ordinal": ordinal, "q_min": scaled_e12(item["q_min"]), "q_max": scaled_e12(item["q_max"]), "total_weight": decimal_text(item["weight"]), "weighted_y_sum": decimal_text(item["weighted_y"]), "fitted_probability": scaled_e12(item["weighted_y"] / item["weight"]), "first_point_ordinal": item["first"], "last_point_ordinal": item["last"], "ordered_member_point_hashes": item["members"]}
            blocks_list.append(PAVBlock(ordinal, item["q_min"], item["q_max"], item["weight"], item["weighted_y"], q12(item["weighted_y"] / item["weight"]), item["first"], item["last"], tuple(item["members"]), hash_v1("PWM.IIC2.PAV_BLOCK.V1", block_payload)))
        blocks = tuple(blocks_list)
        strict_asof_waterline = max((point.available_at_utc for point in ordered), key=utc_time)
        oof_population_hash = hash_v1("PWM.IIC2.PAV_OOF_POPULATION.V1", [point.point_hash for point in ordered])
        pav_policy_hash = hash_v1("PWM.IIC2.PAV_POLICY.V1", {"algorithm": "LEFTMOST_ADJACENT_VIOLATOR_EQUAL_Q_PREAGGREGATION", "extrapolation": "END_BLOCK", "interpolation": "NONE"})
        payload = {
            "schema_version": "PAVArtifactV1",
            "city": city.value,
            "local_second": local_second,
            "strict_asof_waterline": strict_asof_waterline,
            "model_policy_hash": model_policy_hash,
            "oof_population_hash": oof_population_hash,
            "ordered_point_hashes": [point.point_hash for point in ordered],
            "pav_policy_hash": pav_policy_hash,
            "ordered_blocks": [
                {
                    "q_min": scaled_e12(block.q_min),
                    "q_max": scaled_e12(block.q_max),
                    "total_weight": decimal_text(block.total_weight),
                    "weighted_y_sum": decimal_text(block.weighted_outcome),
                    "fitted_probability": scaled_e12(block.fitted_probability),
                    "block_ordinal": block.block_ordinal,
                    "first_point_ordinal": block.first_point_ordinal,
                    "last_point_ordinal": block.last_point_ordinal,
                    "ordered_member_point_hashes": list(block.ordered_member_point_hashes),
                    "block_hash": block.block_hash,
                }
                for block in blocks
            ],
        }
        return cls(
            city,
            local_second,
            "TARGET_DAY_EQUAL_WEIGHT_PAV_V1",
            blocks,
            tuple(point.point_hash for point in ordered),
            strict_asof_waterline,
            model_policy_hash,
            oof_population_hash,
            pav_policy_hash,
            hash_v1("PWM.IIC2.PAV_ARTIFACT.V1", payload),
        )

    def predict(self, q: Decimal) -> Decimal:
        q = decimal_value(q)
        if not ZERO <= q <= ONE:
            raise ValueError("PAV input must be in [0, 1]")
        if q < self.blocks[0].q_min:
            return self.blocks[0].fitted_probability
        for block in self.blocks:
            if q <= block.q_max:
                return block.fitted_probability
        return self.blocks[-1].fitted_probability

    def calibrate_vector(
        self,
        vector: ProbabilityVector,
        buckets: Iterable[TemperatureBucket],
    ) -> ProbabilityVector:
        partition = validate_bucket_partition(buckets)
        if vector.city is not self.city:
            raise ValueError("calibrator and probability city mismatch")
        if tuple(item.bucket_id for item in partition) != vector.bucket_ids:
            raise ValueError("calibration bucket identity mismatch")
        expected_partition_hash = hash_v1(
            "PWM.IIC2.BUCKET_PARTITION.V1",
            [
                {
                    "bucket_id": item.bucket_id,
                    "lower_c": None if item.lower_c is None else decimal_text(item.lower_c),
                    "upper_c": None if item.upper_c is None else decimal_text(item.upper_c),
                }
                for item in partition
            ],
        )
        if vector.bucket_partition_hash != expected_partition_hash:
            raise ValueError("calibration bucket partition hash mismatch")
        running = ZERO
        cdf: list[Decimal] = []
        for probability in vector.probabilities[:-1]:
            running += probability
            calibrated = self.predict(running)
            cdf.append(max(cdf[-1] if cdf else ZERO, min(ONE, calibrated)))
        probabilities: list[Decimal] = []
        previous = ZERO
        for value in cdf:
            probabilities.append(value - previous)
            previous = value
        probabilities.append(ONE - previous)
        return make_probability_vector(vector.city, vector.target_date, partition, probabilities)
