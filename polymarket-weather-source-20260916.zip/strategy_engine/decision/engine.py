"""Strict BUY-YES candidate gate; no execution side effect."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from enum import Enum
from typing import Iterable

from strategy_v8.canonical import hash_v1, validate_hash_v1
from strategy_v8.contracts import City

from strategy_engine.data.records import decimal_text, decimal_value, utc_time
from strategy_engine.risk.cost import ExecutableCost


ZERO = Decimal(0)
ONE = Decimal(1)


class DecisionAction(str, Enum):
    BUY = "BUY"
    NO_ACTION = "NO_ACTION"


@dataclass(frozen=True, slots=True)
class DeltaPolicyV1:
    city: City
    delta_value: Decimal
    validation_evidence_hash: str
    effective_from_utc: str
    expires_at_utc: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "delta_value", decimal_value(self.delta_value))
        if not ZERO <= self.delta_value <= ONE:
            raise ValueError("delta must be in [0, 1]")
        if not self.validation_evidence_hash:
            raise ValueError("validated delta requires evidence")
        validate_hash_v1(self.validation_evidence_hash)
        if utc_time(self.effective_from_utc) >= utc_time(self.expires_at_utc):
            raise ValueError("delta policy interval is invalid")

    @property
    def policy_hash(self) -> str:
        return hash_v1(
            "PWM.IIC2.DELTA_GATE_POLICY.V1",
            {
                "schema_version": "DeltaGatePolicyV1",
                "city": self.city.value,
                "side": "BUY_YES_ONLY",
                "formula_id": "P_LCB_MINUS_C_EXECUTABLE",
                "delta_value": decimal_text(self.delta_value),
                "delta_unit": "PROBABILITY_POINTS",
                "validation_status": "VALIDATED",
                "validation_evidence_hash": self.validation_evidence_hash,
                "effective_from_utc": self.effective_from_utc,
                "expires_at_utc": self.expires_at_utc,
                "comparison": "STRICT_GREATER_THAN",
            },
        )

    def value_at(self, city: City, as_of_utc: str) -> Decimal:
        if city is not self.city:
            raise ValueError("cross-city delta policy is forbidden")
        point = utc_time(as_of_utc)
        if not utc_time(self.effective_from_utc) <= point < utc_time(self.expires_at_utc):
            raise ValueError("delta policy is not valid at decision AS-OF")
        return self.delta_value


@dataclass(frozen=True, slots=True)
class DecisionResult:
    city: City
    target_date: date
    event_id: str
    bucket_id: str
    side: str
    action: DecisionAction
    p_lcb: Decimal
    c_executable: Decimal
    delta: Decimal
    delta_policy_hash: str
    conservative_edge: Decimal
    confidence_score: Decimal
    reason: str
    dependency_hashes: tuple[str, ...]
    decision_hash: str

    def __post_init__(self) -> None:
        payload = {"city": self.city.value, "target_date": self.target_date.isoformat(), "event_id": self.event_id, "bucket_id": self.bucket_id, "side": self.side, "action": self.action.value, "p_lcb": decimal_text(self.p_lcb), "c_executable": decimal_text(self.c_executable), "delta": decimal_text(self.delta), "delta_policy_hash": self.delta_policy_hash, "conservative_edge": decimal_text(self.conservative_edge), "confidence_score": decimal_text(self.confidence_score), "reason": self.reason, "dependency_hashes": list(self.dependency_hashes)}
        if self.decision_hash != hash_v1("PWM.STRATEGY_ENGINE_V1.DECISION", payload):
            raise ValueError("decision hash mismatch")


def decide_buy_yes(
    *,
    city: City,
    target_date: date,
    event_id: str,
    bucket_id: str,
    p_lcb: Decimal,
    cost: ExecutableCost,
    delta: Decimal,
    delta_policy_hash: str,
    confidence_score: Decimal,
    dependency_hashes: Iterable[str],
) -> DecisionResult:
    if not event_id or not bucket_id or not delta_policy_hash:
        raise ValueError("event and bucket identities are required")
    p_lcb = decimal_value(p_lcb)
    delta = decimal_value(delta)
    confidence_score = decimal_value(confidence_score)
    if not ZERO <= p_lcb <= ONE or not ZERO <= cost.c_executable <= ONE:
        raise ValueError("decision probability and cost must be in [0, 1]")
    if not ZERO <= delta <= ONE or not ZERO <= confidence_score <= ONE:
        raise ValueError("delta and confidence must be in [0, 1]")
    dependencies = tuple(dependency_hashes)
    if not dependencies or any(not value for value in dependencies):
        raise ValueError("decision dependencies must be explicit")
    edge = p_lcb - cost.c_executable
    action = DecisionAction.BUY if edge > delta else DecisionAction.NO_ACTION
    reason = "EDGE_STRICTLY_ABOVE_DELTA" if action is DecisionAction.BUY else (
        "EDGE_EQUALS_DELTA" if edge == delta else "EDGE_BELOW_DELTA"
    )
    payload = {
        "city": city.value,
        "target_date": target_date.isoformat(),
        "event_id": event_id,
        "bucket_id": bucket_id,
        "side": "BUY_YES_ONLY",
        "action": action.value,
        "p_lcb": decimal_text(p_lcb),
        "c_executable": decimal_text(cost.c_executable),
        "delta": decimal_text(delta),
        "delta_policy_hash": delta_policy_hash,
        "conservative_edge": decimal_text(edge),
        "confidence_score": decimal_text(confidence_score),
        "reason": reason,
        "dependency_hashes": list(dependencies),
    }
    return DecisionResult(
        city,
        target_date,
        event_id,
        bucket_id,
        "BUY_YES_ONLY",
        action,
        p_lcb,
        cost.c_executable,
        delta,
        delta_policy_hash,
        edge,
        confidence_score,
        reason,
        dependencies,
        hash_v1("PWM.STRATEGY_ENGINE_V1.DECISION", payload),
    )
