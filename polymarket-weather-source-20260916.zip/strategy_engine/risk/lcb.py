"""Deterministic target-day cluster bootstrap lower confidence bounds."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_CEILING, localcontext
import hashlib
from typing import Iterable

from strategy_v8.canonical import hash_v1
from strategy_v8.contracts import City

from strategy_engine.calibration.pav import PAVCalibratorV1
from strategy_engine.data.normalization import NormalizedDay
from strategy_engine.data.records import decimal_text, decimal_value
from strategy_engine.features.engine import WeatherFeaturesV1
from strategy_engine.models.residual import (
    EmpiricalResidualModelV1,
    TemperatureBucket,
    q12,
    validate_bucket_partition,
)


ONE = Decimal(1)
E12 = Decimal(1_000_000_000_000)


def _e12(value: Decimal) -> int:
    return int((q12(value) * E12).to_integral_exact())


@dataclass(frozen=True, slots=True)
class BootstrapPolicyV1:
    city: City
    confidence: Decimal
    replicates: int
    minimum_cluster_days: int
    max_evaluations_per_target_day: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "confidence", decimal_value(self.confidence))
        if not Decimal(0) < self.confidence < ONE:
            raise ValueError("confidence must be in (0, 1)")
        counts = (self.replicates, self.minimum_cluster_days, self.max_evaluations_per_target_day)
        if any(isinstance(value, bool) or not isinstance(value, int) for value in counts):
            raise ValueError("bootstrap counts must be integers")
        if self.replicates < 2 or self.minimum_cluster_days < 1:
            raise ValueError("bootstrap sample policy is invalid")
        if self.max_evaluations_per_target_day < 1:
            raise ValueError("max evaluations must be positive")

    @property
    def policy_hash(self) -> str:
        city_value = getattr(self.city, "value", None)
        if city_value is None:
            raise ValueError("bootstrap policy city is required")
        return hash_v1(
            "PWM.IIC2.P_LCB_POLICY.V1",
            {
                "schema_version": "PLCBPolicyV1",
                "city": city_value,
                "family_confidence": decimal_text(self.confidence),
                "bootstrap_replicates": self.replicates,
                "minimum_cluster_days": self.minimum_cluster_days,
                "max_evaluations_per_target_day": self.max_evaluations_per_target_day,
                "rng_id": "SHA256_COUNTER_REJECTION_UINT64_BE_V1",
                "quantile_id": "ONE_SIDED_NEAREST_RANK_V1",
                "simultaneous_correction_id": "BONFERRONI_BUCKET_X_EVALUATION_V1",
            },
        )


@dataclass(frozen=True, slots=True)
class PLCBBucketResultV1:
    family_id: str
    evaluation_event_id: str
    evaluation_ordinal: int
    bucket_ordinal: int
    bucket_id: str
    bootstrap_replicates: int
    alpha_adjusted: Decimal
    quantile_rank: int
    ordered_replicate_probabilities: tuple[Decimal, ...]
    p_lcb: Decimal
    bucket_result_hash: str

    def __post_init__(self) -> None:
        sequence = [{"replicate_ordinal": ordinal, "probability_e12": _e12(value)} for ordinal, value in enumerate(self.ordered_replicate_probabilities)]
        sequence_hash = hash_v1("PWM.IIC2.P_LCB_REPLICATE_SEQUENCE.V1", {"family_id": self.family_id, "evaluation_event_id": self.evaluation_event_id, "evaluation_ordinal": self.evaluation_ordinal, "bucket_ordinal": self.bucket_ordinal, "bucket_id": self.bucket_id, "ordered_replicate_probabilities": sequence})
        payload = {"schema_version": "PLCBResultBucketV1", "family_id": self.family_id, "evaluation_event_id": self.evaluation_event_id, "evaluation_ordinal": self.evaluation_ordinal, "bucket_ordinal": self.bucket_ordinal, "bucket_id": self.bucket_id, "bootstrap_replicates": self.bootstrap_replicates, "alpha_adjusted_e12": _e12(self.alpha_adjusted), "quantile_rank_k": self.quantile_rank, "ordered_replicate_probability_hash": sequence_hash, "p_lcb_e12": _e12(self.p_lcb)}
        if len(self.ordered_replicate_probabilities) != self.bootstrap_replicates or self.bucket_result_hash != hash_v1("PWM.IIC2.P_LCB_BUCKET_RESULT.V1", payload):
            raise ValueError("P_LCB bucket result hash mismatch")


@dataclass(frozen=True, slots=True)
class PLCBResult:
    city: City
    target_date: date
    evaluation_event_id: str
    event_seq: int
    event_at_utc: str
    local_second: int
    bucket_ids: tuple[str, ...]
    lower_bounds: tuple[Decimal, ...]
    bootstrap_seed: str
    quantile_rank: int
    confidence: Decimal
    family_id: str
    evaluation_ordinal: int
    policy_hash: str
    model_artifact_hash: str
    calibration_hash: str
    residual_population_hash: str
    bucket_partition_hash: str
    bootstrap_replicates: int
    alpha_family: Decimal
    alpha_adjusted: Decimal
    bucket_results: tuple[PLCBBucketResultV1, ...]
    ordered_bucket_result_hashes: tuple[str, ...]
    plcb_hash: str

    def __post_init__(self) -> None:
        if self.ordered_bucket_result_hashes != tuple(item.bucket_result_hash for item in self.bucket_results):
            raise ValueError("P_LCB bucket result identity mismatch")
        payload = {"schema_version": "PLCBArtifactV1", "family_id": self.family_id, "city": self.city.value, "target_date": self.target_date.isoformat(), "evaluation_event_id": self.evaluation_event_id, "evaluation_ordinal": self.evaluation_ordinal, "event_seq": self.event_seq, "event_at_utc": self.event_at_utc, "local_second": self.local_second, "model_artifact_hash": self.model_artifact_hash, "calibration_hash": self.calibration_hash, "lcb_policy_hash": self.policy_hash, "residual_population_hash": self.residual_population_hash, "bucket_partition_hash": self.bucket_partition_hash, "bootstrap_seed": self.bootstrap_seed, "bootstrap_replicates": self.bootstrap_replicates, "alpha_family_e12": _e12(self.alpha_family), "alpha_adjusted_e12": _e12(self.alpha_adjusted), "quantile_rank_k": self.quantile_rank, "ordered_bucket_result_hashes": list(self.ordered_bucket_result_hashes), "ordered_p_lcb": [{"bucket_ordinal": ordinal, "bucket_id": bucket_id, "p_lcb_e12": _e12(value)} for ordinal, (bucket_id, value) in enumerate(zip(self.bucket_ids, self.lower_bounds))]}
        if self.plcb_hash != hash_v1("PWM.IIC2.P_LCB_ARTIFACT.V1", payload):
            raise ValueError("P_LCB artifact hash mismatch")

    def lower_bound_for(self, bucket_id: str) -> Decimal:
        try:
            return self.lower_bounds[self.bucket_ids.index(bucket_id)]
        except ValueError as exc:
            raise KeyError(bucket_id) from exc


def _sample_index(seed: bytes, replicate: int, draw: int, population: int) -> int:
    limit = (1 << 256) // population * population
    counter = 0
    while True:
        digest = hashlib.sha256(
            seed
            + replicate.to_bytes(8, "big")
            + draw.to_bytes(8, "big")
            + counter.to_bytes(8, "big")
        ).digest()
        candidate = int.from_bytes(digest, "big")
        if candidate < limit:
            return candidate % population
        counter += 1


def bootstrap_lcb(
    model: EmpiricalResidualModelV1,
    day: NormalizedDay,
    weather_features: WeatherFeaturesV1,
    buckets: Iterable[TemperatureBucket],
    calibrator: PAVCalibratorV1,
    policy: BootstrapPolicyV1,
    *,
    evaluation_identity: str,
    family_id: str,
    evaluation_ordinal: int,
    event_seq: int,
    event_at_utc: str,
) -> PLCBResult:
    partition = validate_bucket_partition(buckets)
    if len(model.samples) < policy.minimum_cluster_days:
        raise ValueError("insufficient target-day clusters for P_LCB")
    if getattr(policy.city, "value", None) != model.city.value:
        raise ValueError("bootstrap policy city mismatch")
    if not family_id or not 1 <= evaluation_ordinal <= policy.max_evaluations_per_target_day:
        raise ValueError("invalid family admission identity")
    bucket_partition_hash = hash_v1(
        "PWM.IIC2.BUCKET_PARTITION.V1",
        [
            {
                "bucket_id": item.bucket_id,
                "lower_c": None if item.lower_c is None else decimal_text(item.lower_c),
                "upper_c": None if item.upper_c is None else decimal_text(item.upper_c),
            }
            for item in partition
        ],
    )
    seed_hex = hash_v1(
        "PWM.IIC2.P_LCB_SEED.V1",
        {
            "city": model.city.value,
            "target_date": day.target_date.isoformat(),
            "evaluation_event_id": evaluation_identity,
            "family_id": family_id,
            "evaluation_ordinal": evaluation_ordinal,
            "model_artifact_hash": model.model_artifact_hash,
            "calibration_hash": calibrator.calibration_hash,
            "lcb_policy_hash": policy.policy_hash,
            "residual_population_hash": model.residual_population_hash,
            "bucket_partition_hash": bucket_partition_hash,
        },
    )
    seed = bytes.fromhex(seed_hex)
    residuals = model.residuals
    by_bucket: list[list[Decimal]] = [[] for _ in partition]
    for replicate in range(policy.replicates):
        sampled = tuple(
            residuals[_sample_index(seed, replicate, draw, len(residuals))]
            for draw in range(len(residuals))
        )
        raw = model.predict(day, weather_features, partition, residuals=sampled)
        calibrated = calibrator.calibrate_vector(raw, partition)
        for index, value in enumerate(calibrated.probabilities):
            by_bucket[index].append(value)
    with localcontext() as context:
        context.prec = 34
        alpha_adjusted = (ONE - policy.confidence) / Decimal(
            len(partition) * policy.max_evaluations_per_target_day
        )
        rank = int(
            (alpha_adjusted * Decimal(policy.replicates)).to_integral_value(
                rounding=ROUND_CEILING
            )
        )
    if not 1 <= rank <= policy.replicates:
        raise ValueError("illegal P_LCB quantile rank")
    lower = tuple(sorted(values)[rank - 1] for values in by_bucket)
    alpha_family = ONE - policy.confidence
    bucket_results = []
    for bucket_ordinal, (bucket, values, lower_bound) in enumerate(zip(partition, by_bucket, lower)):
        sequence = [{"replicate_ordinal": ordinal, "probability_e12": _e12(value)} for ordinal, value in enumerate(values)]
        sequence_hash = hash_v1("PWM.IIC2.P_LCB_REPLICATE_SEQUENCE.V1", {"family_id": family_id, "evaluation_event_id": evaluation_identity, "evaluation_ordinal": evaluation_ordinal, "bucket_ordinal": bucket_ordinal, "bucket_id": bucket.bucket_id, "ordered_replicate_probabilities": sequence})
        bucket_payload = {"schema_version": "PLCBResultBucketV1", "family_id": family_id, "evaluation_event_id": evaluation_identity, "evaluation_ordinal": evaluation_ordinal, "bucket_ordinal": bucket_ordinal, "bucket_id": bucket.bucket_id, "bootstrap_replicates": policy.replicates, "alpha_adjusted_e12": _e12(alpha_adjusted), "quantile_rank_k": rank, "ordered_replicate_probability_hash": sequence_hash, "p_lcb_e12": _e12(lower_bound)}
        bucket_results.append(PLCBBucketResultV1(family_id, evaluation_identity, evaluation_ordinal, bucket_ordinal, bucket.bucket_id, policy.replicates, alpha_adjusted, rank, tuple(values), lower_bound, hash_v1("PWM.IIC2.P_LCB_BUCKET_RESULT.V1", bucket_payload)))
    bucket_result_hashes = tuple(item.bucket_result_hash for item in bucket_results)
    payload = {
        "schema_version": "PLCBArtifactV1",
        "family_id": family_id,
        "city": model.city.value,
        "target_date": day.target_date.isoformat(),
        "evaluation_event_id": evaluation_identity,
        "evaluation_ordinal": evaluation_ordinal,
        "event_seq": event_seq,
        "event_at_utc": event_at_utc,
        "local_second": day.local_second,
        "model_artifact_hash": model.model_artifact_hash,
        "calibration_hash": calibrator.calibration_hash,
        "lcb_policy_hash": policy.policy_hash,
        "residual_population_hash": model.residual_population_hash,
        "bucket_partition_hash": bucket_partition_hash,
        "bootstrap_seed": seed_hex,
        "bootstrap_replicates": policy.replicates,
        "alpha_family_e12": _e12(alpha_family),
        "alpha_adjusted_e12": _e12(alpha_adjusted),
        "quantile_rank_k": rank,
        "ordered_bucket_result_hashes": bucket_result_hashes,
        "ordered_p_lcb": [{"bucket_ordinal": ordinal, "bucket_id": bucket.bucket_id, "p_lcb_e12": _e12(value)} for ordinal, (bucket, value) in enumerate(zip(partition, lower))],
    }
    return PLCBResult(
        model.city,
        day.target_date,
        evaluation_identity,
        event_seq,
        event_at_utc,
        day.local_second,
        tuple(item.bucket_id for item in partition),
        lower,
        seed_hex,
        rank,
        policy.confidence,
        family_id,
        evaluation_ordinal,
        policy.policy_hash,
        model.model_artifact_hash,
        calibrator.calibration_hash,
        model.residual_population_hash,
        bucket_partition_hash,
        policy.replicates,
        alpha_family,
        alpha_adjusted,
        tuple(bucket_results),
        bucket_result_hashes,
        hash_v1("PWM.IIC2.P_LCB_ARTIFACT.V1", payload),
    )
