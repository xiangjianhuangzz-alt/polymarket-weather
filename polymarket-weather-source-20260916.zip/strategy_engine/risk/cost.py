"""Conservative BUY-YES executable cost from visible ask depth."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING

from strategy_v8.canonical import hash_v1
from strategy_v8.contracts import City

from strategy_engine.data.evidence import FeeEvidenceV1, MarketRuleEvidenceV1
from strategy_engine.data.records import MarketBook, decimal_text, decimal_value, utc_time


ZERO = Decimal(0)
ONE = Decimal(1)


def _ceil_to(value: Decimal, quantum: Decimal) -> Decimal:
    return (value / quantum).to_integral_value(rounding=ROUND_CEILING) * quantum


@dataclass(frozen=True, slots=True)
class CostPolicyV1:
    city: City
    policy_id: str
    policy_version: str
    requested_yes_quantity: Decimal
    adverse_slippage_ticks: int
    rule_reserve_per_share: Decimal
    settlement_reserve_per_share: Decimal
    allow_explicit_fee_disabled: bool
    max_book_age_ms: int
    max_rule_age_ms: int
    max_fee_age_ms: int
    fee_mode: str = "FROZEN_EVIDENCE_ONLY"
    allowed_fee_formula_ids: tuple[str, ...] = ("BINARY_TAKER_PER_MERGED_LEVEL_V1", "DISABLED_V1")
    allowed_fee_rounding_modes: tuple[str, ...] = ("CEILING",)

    def __post_init__(self) -> None:
        object.__setattr__(self, "requested_yes_quantity", decimal_value(self.requested_yes_quantity))
        object.__setattr__(self, "rule_reserve_per_share", decimal_value(self.rule_reserve_per_share))
        object.__setattr__(self, "settlement_reserve_per_share", decimal_value(self.settlement_reserve_per_share))
        if not self.policy_id or not self.policy_version:
            raise ValueError("cost policy identity is required")
        if self.requested_yes_quantity <= ZERO or isinstance(self.adverse_slippage_ticks, bool) or not isinstance(self.adverse_slippage_ticks, int) or not 0 <= self.adverse_slippage_ticks <= 1_000_000:
            raise ValueError("invalid quantity or slippage")
        if min(self.rule_reserve_per_share, self.settlement_reserve_per_share) < ZERO:
            raise ValueError("reserves cannot be negative")
        ages = (self.max_book_age_ms, self.max_rule_age_ms, self.max_fee_age_ms)
        if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in ages):
            raise ValueError("maximum evidence ages must be non-negative")
        if self.fee_mode != "FROZEN_EVIDENCE_ONLY":
            raise ValueError("unsupported fee mode")
        if tuple(self.allowed_fee_formula_ids) != ("BINARY_TAKER_PER_MERGED_LEVEL_V1", "DISABLED_V1"):
            raise ValueError("fee formula registry mismatch")
        if tuple(self.allowed_fee_rounding_modes) != ("CEILING",):
            raise ValueError("fee rounding registry mismatch")

    @property
    def policy_hash(self) -> str:
        return hash_v1(
            "PWM.IIC2.COST_POLICY.V1",
            {
                "schema_version": "CostPolicyV1",
                "city": self.city.value,
                "cost_policy_id": self.policy_id,
                "cost_policy_version": self.policy_version,
                "side": "BUY_YES_ONLY",
                "fee_mode": self.fee_mode,
                "allowed_fee_formula_ids": list(self.allowed_fee_formula_ids),
                "allowed_fee_rounding_modes": list(self.allowed_fee_rounding_modes),
                "fee_reserve_rule": "CEILING_PER_COMPONENT",
                "adverse_slippage_ticks": self.adverse_slippage_ticks,
                "rule_reserve_per_share": decimal_text(self.rule_reserve_per_share),
                "settlement_reserve_per_share": decimal_text(self.settlement_reserve_per_share),
                "allow_explicit_fee_disabled": self.allow_explicit_fee_disabled,
                "max_book_age_ms": self.max_book_age_ms,
                "max_rule_age_ms": self.max_rule_age_ms,
                "max_fee_age_ms": self.max_fee_age_ms,
                "payout_per_yes_share": "1",
                "max_c_executable": "1",
            },
        )


@dataclass(frozen=True, slots=True)
class ExecutableCost:
    approved_config_set_hash: str
    decision_asof_identity: str
    market_id: str
    yes_token_id: str
    side: str
    requested_quantity: Decimal
    filled_quantity: Decimal
    vwap: Decimal
    spread_per_share: Decimal | None
    liquidity_cost: Decimal
    slippage_reserve: Decimal
    fee: Decimal
    total_debit: Decimal
    c_executable: Decimal
    book_hash: str
    fee_evidence_hash: str
    rule_evidence_hash: str
    policy_hash: str
    merged_fill_plan_hash: str
    depth_notional: Decimal
    book_impact: Decimal
    price_cap: Decimal
    fee_assessed: Decimal
    fee_reserve: Decimal
    rule_reserve: Decimal
    settlement_reserve: Decimal
    rounding_reserve: Decimal
    c_executable_e12: int
    cost_hash: str

    def __post_init__(self) -> None:
        payload = {"schema_version": "COST_ARTIFACT_V1", "approved_config_set_hash": self.approved_config_set_hash, "decision_asof_identity": self.decision_asof_identity, "market_id": self.market_id, "yes_token_id": self.yes_token_id, "side": self.side, "book_hash": self.book_hash, "market_rule_evidence_hash": self.rule_evidence_hash, "fee_evidence_hash": self.fee_evidence_hash, "cost_policy_hash": self.policy_hash, "merged_fill_plan_hash": self.merged_fill_plan_hash, "requested_yes_quantity": decimal_text(self.requested_quantity), "filled_yes_quantity": decimal_text(self.filled_quantity), "depth_notional": decimal_text(self.depth_notional), "vwap_exact": decimal_text(self.vwap), "book_impact": decimal_text(self.book_impact), "price_cap": decimal_text(self.price_cap), "slippage_reserve": decimal_text(self.slippage_reserve), "fee_assessed": decimal_text(self.fee_assessed), "fee_reserve": decimal_text(self.fee_reserve), "rule_reserve": decimal_text(self.rule_reserve), "settlement_reserve": decimal_text(self.settlement_reserve), "rounding_reserve": decimal_text(self.rounding_reserve), "total_debit": decimal_text(self.total_debit), "c_executable_e12": self.c_executable_e12}
        if self.cost_hash != hash_v1("PWM.IIC2.COST_ARTIFACT.V1", payload):
            raise ValueError("cost artifact hash mismatch")


def _age_ms(as_of_utc: str, value_utc: str) -> int:
    return int((utc_time(as_of_utc) - utc_time(value_utc)).total_seconds() * 1000)


def compute_c_executable(
    book: MarketBook,
    fee_evidence: FeeEvidenceV1,
    rule_evidence: MarketRuleEvidenceV1,
    policy: CostPolicyV1,
    *,
    as_of_utc: str,
    approved_config_set_hash: str,
) -> ExecutableCost:
    from strategy_v8.canonical import validate_hash_v1
    validate_hash_v1(approved_config_set_hash)
    if book.city is not policy.city:
        raise ValueError("cost policy city mismatch")
    identities = {(book.market_id, book.yes_token_id), (fee_evidence.market_id, fee_evidence.yes_token_id), (rule_evidence.market_id, rule_evidence.yes_token_id)}
    if len(identities) != 1:
        raise ValueError("book, fee, and rule identities conflict")
    if rule_evidence.source_book_hash != book.source_book_hash:
        raise ValueError("market rule evidence is not bound to this book")
    if not book.visibility.visible_at(as_of_utc) or not fee_evidence.valid_at(as_of_utc) or not rule_evidence.valid_at(as_of_utc):
        raise ValueError("cost evidence is not visible at decision AS-OF")
    ages = (
        _age_ms(as_of_utc, book.visibility.committed_at_utc),
        _age_ms(as_of_utc, rule_evidence.visibility.committed_at_utc),
        _age_ms(as_of_utc, fee_evidence.visibility.committed_at_utc),
    )
    if any(age < 0 for age in ages) or ages[0] > policy.max_book_age_ms or ages[1] > policy.max_rule_age_ms or ages[2] > policy.max_fee_age_ms:
        raise ValueError("cost evidence is stale")
    if not fee_evidence.fee_enabled and not policy.allow_explicit_fee_disabled:
        raise ValueError("disabled fees are not permitted by policy")
    if fee_evidence.fee_formula_id not in policy.allowed_fee_formula_ids:
        raise ValueError("fee formula is not allowed by policy")
    if fee_evidence.rounding_mode is not None and fee_evidence.rounding_mode not in policy.allowed_fee_rounding_modes:
        raise ValueError("fee rounding mode is not allowed by policy")
    if policy.requested_yes_quantity < rule_evidence.min_order_size:
        raise ValueError("requested quantity is below market minimum")
    merged: dict[Decimal, Decimal] = {}
    source_ids: dict[Decimal, list[str]] = {}
    for level in book.ask_levels:
        merged[level.price] = merged.get(level.price, ZERO) + level.available_yes_quantity
        source_ids.setdefault(level.price, []).append(level.source_level_id)
    remaining = policy.requested_yes_quantity
    depth_notional = ZERO
    fills: list[tuple[Decimal, Decimal]] = []
    for price in sorted(merged):
        fill = min(remaining, merged[price])
        if fill > ZERO:
            fills.append((price, fill))
            depth_notional += price * fill
            remaining -= fill
        if remaining == ZERO:
            break
    if remaining != ZERO:
        raise ValueError("insufficient executable YES liquidity")
    best_ask = min(merged)
    vwap = depth_notional / policy.requested_yes_quantity
    liquidity_cost = depth_notional - policy.requested_yes_quantity * best_ask
    spread = None
    if book.best_bid is not None:
        spread = max(ZERO, vwap - (book.best_bid + best_ask) / Decimal(2))
    price_cap = _ceil_to(
        vwap + Decimal(policy.adverse_slippage_ticks) * rule_evidence.tick_size,
        rule_evidence.tick_size,
    )
    if price_cap > ONE:
        raise ValueError("slippage price cap exceeds payout")
    slippage = policy.requested_yes_quantity * (price_cap - vwap)
    fee = ZERO
    fee_reserve = ZERO
    if fee_evidence.fee_enabled:
        assert fee_evidence.platform_rate is not None
        assert fee_evidence.builder_bps is not None
        assert fee_evidence.fee_quantum is not None
        for price, quantity in fills:
            platform = quantity * fee_evidence.platform_rate * price * (ONE - price)
            builder = quantity * price * fee_evidence.builder_bps / Decimal(10_000)
            fee += _ceil_to(platform, fee_evidence.fee_quantum)
            fee += _ceil_to(builder, fee_evidence.fee_quantum)
            fee_reserve += _ceil_to(platform, fee_evidence.fee_quantum)
            fee_reserve += _ceil_to(builder, fee_evidence.fee_quantum)
    rule_reserve = policy.requested_yes_quantity * policy.rule_reserve_per_share
    settlement_reserve = policy.requested_yes_quantity * policy.settlement_reserve_per_share
    pre_round_total = depth_notional + slippage + fee_reserve + rule_reserve + settlement_reserve
    total = _ceil_to(pre_round_total, rule_evidence.cash_quantum)
    rounding_reserve = total - pre_round_total
    per_share = _ceil_to(total / policy.requested_yes_quantity, Decimal("0.000000000001"))
    if per_share > ONE:
        raise ValueError("C_executable exceeds YES payout")
    merged_fill_plan = [
        {
            "fill_index": index,
            "price": decimal_text(price),
            "available_yes_quantity": decimal_text(merged[price]),
            "filled_yes_quantity": decimal_text(quantity),
            "source_level_ids": sorted(source_ids[price]),
        }
        for index, (price, quantity) in enumerate(fills, start=1)
    ]
    merged_fill_plan_hash = hash_v1("PWM.IIC2.MERGED_FILL_PLAN.V1", merged_fill_plan)
    decision_asof_identity = hash_v1(
        "PWM.IIC2.DECISION_ASOF_IDENTITY.V1",
        {
            "city": book.city.value,
            "target_date": book.target_date.isoformat(),
            "decision_asof_utc": as_of_utc,
            "book_hash": book.book_hash,
            "fee_evidence_hash": fee_evidence.fee_evidence_hash,
            "market_rule_evidence_hash": rule_evidence.rule_evidence_hash,
            "approved_config_set_hash": approved_config_set_hash,
        },
    )
    c_executable_e12 = int((per_share * Decimal(1_000_000_000_000)).to_integral_exact())
    payload = {
        "schema_version": "COST_ARTIFACT_V1",
        "approved_config_set_hash": approved_config_set_hash,
        "decision_asof_identity": decision_asof_identity,
        "market_id": book.market_id,
        "yes_token_id": book.yes_token_id,
        "side": "BUY_YES_ONLY",
        "book_hash": book.book_hash,
        "market_rule_evidence_hash": rule_evidence.rule_evidence_hash,
        "fee_evidence_hash": fee_evidence.fee_evidence_hash,
        "cost_policy_hash": policy.policy_hash,
        "merged_fill_plan_hash": merged_fill_plan_hash,
        "requested_yes_quantity": decimal_text(policy.requested_yes_quantity),
        "filled_yes_quantity": decimal_text(policy.requested_yes_quantity),
        "depth_notional": decimal_text(depth_notional),
        "vwap_exact": decimal_text(vwap),
        "book_impact": decimal_text(liquidity_cost),
        "price_cap": decimal_text(price_cap),
        "slippage_reserve": decimal_text(slippage),
        "fee_assessed": decimal_text(fee),
        "fee_reserve": decimal_text(fee_reserve),
        "rule_reserve": decimal_text(rule_reserve),
        "settlement_reserve": decimal_text(settlement_reserve),
        "rounding_reserve": decimal_text(rounding_reserve),
        "total_debit": decimal_text(total),
        "c_executable_e12": c_executable_e12,
    }
    return ExecutableCost(
        approved_config_set_hash,
        decision_asof_identity,
        book.market_id,
        book.yes_token_id,
        "BUY_YES_ONLY",
        policy.requested_yes_quantity,
        policy.requested_yes_quantity,
        vwap,
        spread,
        liquidity_cost,
        slippage,
        fee,
        total,
        per_share,
        book.book_hash,
        fee_evidence.fee_evidence_hash,
        rule_evidence.rule_evidence_hash,
        policy.policy_hash,
        merged_fill_plan_hash,
        depth_notional,
        liquidity_cost,
        price_cap,
        fee,
        fee_reserve,
        rule_reserve,
        settlement_reserve,
        rounding_reserve,
        c_executable_e12,
        hash_v1("PWM.IIC2.COST_ARTIFACT.V1", payload),
    )
