"""Explainable research confidence score."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, localcontext

from strategy_engine.data.records import decimal_value
from strategy_engine.models.residual import ProbabilityVector, q12


ZERO = Decimal(0)
ONE = Decimal(1)


@dataclass(frozen=True, slots=True)
class ConfidenceAssessment:
    score: Decimal
    sample_size: int
    sample_factor: Decimal
    data_quality: Decimal
    normalized_entropy: Decimal
    confidence_version: str = "SAMPLE_QUALITY_ENTROPY_V1"


def confidence_score(
    vector: ProbabilityVector,
    *,
    sample_size: int,
    target_sample_size: int,
    data_quality: Decimal,
) -> ConfidenceAssessment:
    quality = decimal_value(data_quality)
    if sample_size < 1 or target_sample_size < 1 or not ZERO <= quality <= ONE:
        raise ValueError("invalid confidence inputs")
    with localcontext() as context:
        context.prec = 34
        entropy = -sum(
            (value * value.ln() for value in vector.probabilities if value > ZERO), ZERO
        ) / Decimal(len(vector.probabilities)).ln()
    sample_factor = min(ONE, Decimal(sample_size) / Decimal(target_sample_size))
    score = q12(sample_factor * quality * (ONE - entropy))
    return ConfidenceAssessment(score, sample_size, q12(sample_factor), quality, q12(entropy))
