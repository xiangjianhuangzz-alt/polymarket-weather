"""Per-city empirical residual probability model V1."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN
from typing import Iterable

from strategy_v8.canonical import hash_v1, validate_hash_v1
from strategy_v8.contracts import City

from strategy_engine.data.normalization import NormalizedDay, SourceAnchorSetV1
from strategy_engine.data.labels import WEATHER_LABEL_POLICY_HASH, WeatherLabel
from strategy_engine.data.records import SOURCE_BINDING, decimal_text, decimal_value, utc_time
from strategy_engine.features.engine import WeatherFeaturesV1


ZERO = Decimal(0)
ONE = Decimal(1)
QUANTUM = Decimal("0.000000000001")


def q12(value: Decimal) -> Decimal:
    return decimal_value(value).quantize(QUANTUM, rounding=ROUND_HALF_EVEN)


@dataclass(frozen=True, slots=True)
class TemperatureBucket:
    bucket_id: str
    lower_c: Decimal | None
    upper_c: Decimal | None

    def __post_init__(self) -> None:
        if not self.bucket_id:
            raise ValueError("bucket_id must be non-empty")
        if self.lower_c is not None:
            object.__setattr__(self, "lower_c", decimal_value(self.lower_c))
        if self.upper_c is not None:
            object.__setattr__(self, "upper_c", decimal_value(self.upper_c))
        if self.lower_c is not None and self.upper_c is not None and self.lower_c >= self.upper_c:
            raise ValueError("bucket lower bound must be below upper bound")

    def contains(self, value: Decimal) -> bool:
        value = decimal_value(value)
        return (self.lower_c is None or value >= self.lower_c) and (
            self.upper_c is None or value < self.upper_c
        )


def validate_bucket_partition(buckets: Iterable[TemperatureBucket]) -> tuple[TemperatureBucket, ...]:
    result = tuple(buckets)
    if len(result) < 2:
        raise ValueError("at least two exhaustive buckets are required")
    if len({bucket.bucket_id for bucket in result}) != len(result):
        raise ValueError("bucket IDs must be unique")
    if result[0].lower_c is not None or result[-1].upper_c is not None:
        raise ValueError("outer bucket bounds must be open")
    for left, right in zip(result, result[1:]):
        if left.upper_c is None or right.lower_c is None or left.upper_c != right.lower_c:
            raise ValueError("buckets must be ordered, contiguous, and non-overlapping")
    return result


@dataclass(frozen=True, slots=True)
class TrainingSample:
    city: City
    target_date: date
    local_second: int
    forecast_high_c: Decimal
    source_anchor_set: SourceAnchorSetV1
    weather_label: WeatherLabel

    def __post_init__(self) -> None:
        if not 7 * 3600 <= self.local_second < 16 * 3600:
            raise ValueError("training local_second is outside the dynamic window")
        object.__setattr__(self, "forecast_high_c", decimal_value(self.forecast_high_c))
        if self.forecast_high_c * Decimal(1000) != (self.forecast_high_c * Decimal(1000)).to_integral_value():
            raise ValueError("training forecast must have exact milli-Celsius precision")
        if self.source_anchor_set.city is not self.city or self.source_anchor_set.target_date != self.target_date:
            raise ValueError("training sample source anchor identity mismatch")
        if self.weather_label.city is not self.city or self.weather_label.target_date != self.target_date:
            raise ValueError("training sample label identity mismatch")
        if self.weather_label.weather_label_policy_hash != WEATHER_LABEL_POLICY_HASH:
            raise ValueError("training sample uses a different WeatherLabel policy")
        forecast_milli = int(self.forecast_high_c * Decimal(1000))
        expected_projection = hash_v1(
            "PWM.IIC2.NORMALIZED_PROJECTION.V1",
            {
                "projection_kind": "FORECAST_HIGH_C_MILLI",
                "canonical_projection": {
                    "city": self.city.value,
                    "target_date": self.target_date.isoformat(),
                    "local_second": self.local_second,
                    "forecast_high_c_milli": forecast_milli,
                },
            },
        )
        if self.forecast_anchor.canonical_projection_hash != expected_projection:
            raise ValueError("training forecast value does not match its source projection")
        available = utc_time(self.available_at_utc)
        if utc_time(self.source_anchor_set.as_of_utc) > available or any(
            max(
                utc_time(anchor.effective_at_utc),
                utc_time(anchor.observed_at_utc),
                utc_time(anchor.committed_at_utc),
            ) > available
            for anchor in self.source_anchor_set.anchors
        ):
            raise ValueError("training source anchor is not visible when the label becomes available")

    @property
    def forecast_anchor(self):
        matches = tuple(item for item in self.source_anchor_set.anchors if item.source_binding_id == SOURCE_BINDING[self.city])
        if len(matches) != 1:
            raise ValueError("training sample requires one forecast anchor")
        return matches[0]

    @property
    def forecast_fact_id(self) -> str:
        return self.forecast_anchor.normalized_fact_id

    @property
    def source_anchor_set_hash(self) -> str:
        return self.source_anchor_set.source_anchor_set_hash

    @property
    def final_max_c(self) -> Decimal:
        return self.weather_label.final_max_c

    @property
    def weather_label_hash(self) -> str:
        return self.weather_label.label_hash

    @property
    def available_at_utc(self) -> str:
        return self.weather_label.label_timestamp_utc

    @property
    def residual_c(self) -> Decimal:
        return self.final_max_c - self.forecast_high_c

    @property
    def training_input_hash(self) -> str:
        return hash_v1(
            "PWM.IIC2.TRAINING_INPUT.V1",
            {
                "schema_version": "TrainingDayInputV1",
                "city": self.city.value,
                "target_date": self.target_date.isoformat(),
                "local_second": self.local_second,
                "fold_asof_utc": self.available_at_utc,
                "source_binding_id": self.forecast_anchor.source_binding_id,
                "forecast_normalized_fact_id": self.forecast_anchor.normalized_fact_id,
                "canonical_projection_hash": self.forecast_anchor.canonical_projection_hash,
                "source_revision_id": self.forecast_anchor.source_revision_id,
                "source_revision_rank": self.forecast_anchor.source_revision_rank,
                "forecast_high_c_milli": int(self.forecast_high_c * 1000),
                "weather_label_id": self.weather_label.weather_label_id,
                "weather_label_hash": self.weather_label_hash,
                "final_max_c_milli": int(self.final_max_c * 1000),
                "weather_label_visible_at_utc": self.available_at_utc,
            },
        )

    @property
    def training_day_ref(self) -> str:
        return hash_v1("PWM.IIC2.TRAINING_DAY_REF.V1", {"city": self.city.value, "target_date": self.target_date.isoformat(), "local_second": self.local_second, "training_input_hash": self.training_input_hash})

    @property
    def sample_hash(self) -> str:
        return self.training_day_ref


@dataclass(frozen=True, slots=True)
class ProbabilityVector:
    city: City
    target_date: date
    bucket_ids: tuple[str, ...]
    probabilities: tuple[Decimal, ...]
    bucket_partition_hash: str
    probability_hash: str

    def __post_init__(self) -> None:
        if len(self.bucket_ids) != len(self.probabilities) or len(set(self.bucket_ids)) != len(self.bucket_ids):
            raise ValueError("probability vector shape is invalid")
        values = tuple(decimal_value(value) for value in self.probabilities)
        object.__setattr__(self, "probabilities", values)
        if any(value < ZERO or value > ONE for value in values) or sum(values, ZERO) != ONE:
            raise ValueError("probability vector values are invalid")
        validate_hash_v1(self.bucket_partition_hash)
        validate_hash_v1(self.probability_hash)
        expected = hash_v1(
            "PWM.STRATEGY_ENGINE_V1.PROBABILITY_VECTOR",
            {
                "city": self.city.value,
                "target_date": self.target_date.isoformat(),
                "bucket_ids": list(self.bucket_ids),
                "probabilities": [decimal_text(value) for value in values],
                "bucket_partition_hash": self.bucket_partition_hash,
            },
        )
        if self.probability_hash != expected:
            raise ValueError("probability vector hash mismatch")

    def probability_for(self, bucket_id: str) -> Decimal:
        try:
            return self.probabilities[self.bucket_ids.index(bucket_id)]
        except ValueError as exc:
            raise KeyError(bucket_id) from exc


def make_probability_vector(
    city: City,
    target_date: date,
    buckets: Iterable[TemperatureBucket],
    probabilities: Iterable[Decimal],
) -> ProbabilityVector:
    partition = validate_bucket_partition(buckets)
    values = tuple(decimal_value(value) for value in probabilities)
    if len(values) != len(partition) or any(value < ZERO or value > ONE for value in values):
        raise ValueError("invalid probability vector")
    if sum(values, ZERO) != ONE:
        raise ValueError("probabilities must sum exactly to one")
    partition_payload = [
        {
            "bucket_id": item.bucket_id,
            "lower_c": None if item.lower_c is None else decimal_text(item.lower_c),
            "upper_c": None if item.upper_c is None else decimal_text(item.upper_c),
        }
        for item in partition
    ]
    partition_hash = hash_v1("PWM.IIC2.BUCKET_PARTITION.V1", partition_payload)
    payload = {
        "city": city.value,
        "target_date": target_date.isoformat(),
        "bucket_ids": [item.bucket_id for item in partition],
        "probabilities": [decimal_text(value) for value in values],
        "bucket_partition_hash": partition_hash,
    }
    return ProbabilityVector(
        city,
        target_date,
        tuple(item.bucket_id for item in partition),
        values,
        partition_hash,
        hash_v1("PWM.STRATEGY_ENGINE_V1.PROBABILITY_VECTOR", payload),
    )


@dataclass(frozen=True, slots=True)
class EmpiricalResidualModelV1:
    city: City
    local_second: int
    model_version: str
    training_period_start: date
    training_period_end: date
    feature_version: str
    samples: tuple[TrainingSample, ...]
    model_artifact_hash: str

    def __post_init__(self) -> None:
        if not self.samples:
            raise ValueError("model samples are required")
        payload = {
            "schema_version": "EmpiricalResidualArtifactV1",
            "city": self.city.value,
            "local_second": self.local_second,
            "training_cutoff_asof_utc": max(item.available_at_utc for item in self.samples),
            "ordered_training_day_refs": [item.training_day_ref for item in self.samples],
            "residual_population_hash": self.residual_population_hash,
            "model_policy_hash": self.model_policy_hash,
        }
        if self.model_artifact_hash != hash_v1("PWM.IIC2.EMPIRICAL_RESIDUAL_ARTIFACT.V1", payload):
            raise ValueError("model artifact hash mismatch")

    @property
    def model_policy_hash(self) -> str:
        return hash_v1(
            "PWM.IIC2.EMPIRICAL_RESIDUAL_POLICY.V1",
            {"model_version": self.model_version, "feature_version": self.feature_version},
        )

    @classmethod
    def fit(
        cls,
        city: City,
        local_second: int,
        samples: Iterable[TrainingSample],
        *,
        minimum_samples: int,
    ) -> "EmpiricalResidualModelV1":
        ordered = tuple(sorted(samples, key=lambda item: (item.target_date, item.sample_hash)))
        if minimum_samples < 1 or len(ordered) < minimum_samples:
            raise ValueError("insufficient city-specific samples")
        if any(item.city is not city for item in ordered):
            raise ValueError("cross-city training is forbidden")
        if any(item.local_second != local_second for item in ordered):
            raise ValueError("all training samples must match local_second")
        if len({item.target_date for item in ordered}) != len(ordered):
            raise ValueError("one training sample per target day is required")
        payload = {
            "schema_version": "EmpiricalResidualArtifactV1",
            "city": city.value,
            "local_second": local_second,
            "training_cutoff_asof_utc": max(item.available_at_utc for item in ordered),
            "ordered_training_day_refs": [item.training_day_ref for item in ordered],
            "residual_population_hash": hash_v1(
                "PWM.IIC2.RESIDUAL_POPULATION.V1",
                {"schema_version": "ResidualPopulationV1", "city": city.value, "local_second": local_second, "training_cutoff_asof_utc": max(item.available_at_utc for item in ordered), "items": [{"target_date": item.target_date.isoformat(), "training_day_ref": item.training_day_ref, "training_input_hash": item.training_input_hash, "residual_c_milli": int(item.residual_c * 1000)} for item in ordered]},
            ),
            "model_policy_hash": hash_v1("PWM.IIC2.EMPIRICAL_RESIDUAL_POLICY.V1", {"model_version": "PER_CITY_EMPIRICAL_RESIDUAL_V1", "feature_version": "WEATHER_FEATURES_V1"}),
        }
        return cls(
            city,
            local_second,
            "PER_CITY_EMPIRICAL_RESIDUAL_V1",
            ordered[0].target_date,
            ordered[-1].target_date,
            "WEATHER_FEATURES_V1",
            ordered,
            hash_v1("PWM.IIC2.EMPIRICAL_RESIDUAL_ARTIFACT.V1", payload),
        )

    @property
    def residuals(self) -> tuple[Decimal, ...]:
        return tuple(item.residual_c for item in self.samples)

    @property
    def residual_population_hash(self) -> str:
        return hash_v1(
            "PWM.IIC2.RESIDUAL_POPULATION.V1",
            {
                "schema_version": "ResidualPopulationV1",
                "city": self.city.value,
                "local_second": self.local_second,
                "training_cutoff_asof_utc": max(item.available_at_utc for item in self.samples),
                "items": [{"target_date": item.target_date.isoformat(), "training_day_ref": item.training_day_ref, "training_input_hash": item.training_input_hash, "residual_c_milli": int(item.residual_c * 1000)} for item in self.samples],
            },
        )

    def predict(
        self,
        day: NormalizedDay,
        weather_features: WeatherFeaturesV1,
        buckets: Iterable[TemperatureBucket],
        *,
        residuals: Iterable[Decimal] | None = None,
    ) -> ProbabilityVector:
        if day.city is not self.city or day.local_second != self.local_second:
            raise ValueError("model identity does not match evaluation day")
        if weather_features.feature_version != self.feature_version:
            raise ValueError("weather feature version mismatch")
        if weather_features.city is not day.city or weather_features.as_of_utc != day.as_of_utc:
            raise ValueError("weather feature identity mismatch")
        partition = validate_bucket_partition(buckets)
        population = tuple(self.residuals if residuals is None else map(decimal_value, residuals))
        if not population:
            raise ValueError("residual population must be non-empty")
        counts = [0 for _ in partition]
        for residual in population:
            estimate = max(day.current_observed_max_c, day.forecast_high_c + residual)
            matches = [index for index, bucket in enumerate(partition) if bucket.contains(estimate)]
            if len(matches) != 1:
                raise ValueError("temperature must map to exactly one bucket")
            counts[matches[0]] += 1
        total = sum(counts)
        values = [q12(Decimal(count) / Decimal(total)) for count in counts[:-1]]
        values.append(ONE - sum(values, ZERO))
        return make_probability_vector(day.city, day.target_date, partition, values)

    def raw_temperature_sample_hash(
        self,
        day: NormalizedDay,
        weather_features: WeatherFeaturesV1,
        buckets: Iterable[TemperatureBucket],
        evaluation_event_id: str,
    ) -> str:
        partition = validate_bucket_partition(buckets)
        if not evaluation_event_id or day.city is not self.city or day.local_second != self.local_second:
            raise ValueError("raw sample evaluation identity mismatch")
        items = []
        for ordinal, sample in enumerate(self.samples):
            value = max(day.current_observed_max_c, day.forecast_high_c + sample.residual_c)
            matches = tuple(bucket.bucket_id for bucket in partition if bucket.contains(value))
            if len(matches) != 1:
                raise ValueError("raw temperature sample must map to one bucket")
            items.append({"sample_ordinal": ordinal, "training_target_date": sample.target_date.isoformat(), "training_day_ref": sample.training_day_ref, "residual_c_milli": int(sample.residual_c * 1000), "x_c_milli": int(value * 1000), "bucket_id": matches[0]})
        partition_hash = hash_v1("PWM.IIC2.BUCKET_PARTITION.V1", [{"bucket_id": item.bucket_id, "lower_c": None if item.lower_c is None else decimal_text(item.lower_c), "upper_c": None if item.upper_c is None else decimal_text(item.upper_c)} for item in partition])
        return hash_v1("PWM.IIC2.RAW_TEMPERATURE_SAMPLE_SET.V1", {"schema_version": "RawTemperatureSampleSetV1", "city": self.city.value, "target_date": day.target_date.isoformat(), "evaluation_event_id": evaluation_event_id, "local_second": day.local_second, "residual_population_hash": self.residual_population_hash, "current_forecast_normalized_fact_id": day.forecast_fact_id, "current_forecast_high_c_milli": int(day.forecast_high_c * 1000), "current_observation_set_hash": hash_v1("PWM.IIC2.CURRENT_OBSERVATION_SET.V1", list(day.observation_fact_ids)), "current_observed_max_c_milli": int(day.current_observed_max_c * 1000), "bucket_partition_hash": partition_hash, "samples": items})
