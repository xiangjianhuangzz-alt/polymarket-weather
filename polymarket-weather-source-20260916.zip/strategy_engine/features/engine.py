"""Versioned weather and market feature views.

Market features are deliberately separated from weather features.  The
probability model accepts only WeatherFeaturesV1; MarketFeaturesV1 is consumed
by the cost and reporting layers.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from strategy_v8.canonical import hash_v1
from strategy_v8.contracts import City

from strategy_engine.data.normalization import NormalizedDay
from strategy_engine.data.records import MarketBook, decimal_text, decimal_value


ZERO = Decimal(0)


@dataclass(frozen=True, slots=True)
class WeatherFeaturesV1:
    city: City
    target_date: str
    as_of_utc: str
    current_observation_c: Decimal
    forecast_high_c: Decimal
    forecast_deviation_c: Decimal
    historical_residual_mean_c: Decimal
    historical_residual_std_c: Decimal
    forecast_uncertainty_c: Decimal
    feature_version: str
    feature_hash: str


@dataclass(frozen=True, slots=True)
class MarketFeaturesV1:
    market_id: str
    yes_token_id: str
    best_bid: Decimal | None
    best_ask: Decimal
    spread: Decimal | None
    total_ask_liquidity: Decimal
    book_hash: str


@dataclass(frozen=True, slots=True)
class FeatureBundleV1:
    weather: WeatherFeaturesV1
    market: MarketFeaturesV1


def build_feature_bundle(
    day: NormalizedDay,
    book: MarketBook,
    historical_residuals: Iterable[Decimal],
) -> FeatureBundleV1:
    if day.city is not book.city or day.target_date != book.target_date:
        raise ValueError("weather and market feature identities must match")
    values = tuple(decimal_value(value) for value in historical_residuals)
    if not values:
        raise ValueError("historical residuals are required")
    count = Decimal(len(values))
    mean = sum(values, ZERO) / count
    variance = sum(((value - mean) ** 2 for value in values), ZERO) / count
    std = variance.sqrt()
    weather_payload = {
        "city": day.city.value,
        "target_date": day.target_date.isoformat(),
        "as_of_utc": day.as_of_utc,
        "current_observation_c": decimal_text(day.current_observed_max_c),
        "forecast_high_c": decimal_text(day.forecast_high_c),
        "forecast_deviation_c": decimal_text(day.current_observed_max_c - day.forecast_high_c),
        "historical_residual_mean_c": decimal_text(mean),
        "historical_residual_std_c": decimal_text(std),
        "forecast_uncertainty_c": decimal_text(std),
        "feature_version": "WEATHER_FEATURES_V1",
    }
    weather = WeatherFeaturesV1(
        day.city,
        day.target_date.isoformat(),
        day.as_of_utc,
        day.current_observed_max_c,
        day.forecast_high_c,
        day.current_observed_max_c - day.forecast_high_c,
        mean,
        std,
        std,
        "WEATHER_FEATURES_V1",
        hash_v1("PWM.STRATEGY_ENGINE_V1.WEATHER_FEATURES", weather_payload),
    )
    best_ask = min(level.price for level in book.ask_levels)
    spread = None if book.best_bid is None else best_ask - book.best_bid
    market = MarketFeaturesV1(
        book.market_id,
        book.yes_token_id,
        book.best_bid,
        best_ask,
        spread,
        sum((level.available_yes_quantity for level in book.ask_levels), ZERO),
        book.book_hash,
    )
    return FeatureBundleV1(weather, market)
