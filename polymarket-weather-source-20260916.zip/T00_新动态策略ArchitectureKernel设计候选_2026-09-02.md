# T00｜新动态策略Architecture Kernel设计候选｜2026-09-02

状态：`ARCHITECTURE_KERNEL_CANDIDATE_FROZEN_AWAITING_INDEPENDENT_AUDIT_AUTHORIZATION`  
候选ID：`T00-weather-strategy-architecture-kernel/ak1`  
Schema版本：`architecture-kernel.v1`  
基线HEAD：`13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac`  
性质：关闭V8.2-R1终审B01—B15的最小规范内核；不是完整端到端设计或实现规范

## 1. 规范边界和优先级

本候选只回答四类问题：规则如何获得唯一权威；逐城数据库如何拒绝跨城污染和历史改写；批准、模型检查及事件如何只有一种解释；未来部署对象如何具备精确身份。

优先级固定为：

```text
当前明确用户指令与项目安全边界
→ 新动态策略设计输入基线
→ V3唯一保留公式和Strict AS-OF原则
→ R1独立终审B01—B15
→ 本Kernel规范
```

V8、V8.1、R2、V8.2和R1只能作为历史及反例来源，不得补齐本Kernel未定义语义。本Kernel没有定义的完整代码、字段或部署细节必须标记`DEFERRED_TO_COMPLETE_DESIGN`，不得由实现者猜测。

## 2. 冻结业务不变量

```text
SIDE=BUY_YES_ONLY
WINDOW=Asia/Shanghai [07:00:00,16:00:00)
DECISION_FORMULA=E_conservative(B,t)=P_LCB(B|I_t)-C_executable(B,t)
MARKET_PRICE_IN_WEATHER_MODEL=NO
INDEPENDENT_UNIT=city+target_date
CITIES=SHANGHAI,BEIJING,GUANGZHOU
SHANGHAI_FORECAST=weatherol_shanghai/weatherol_d0
STATIONS=SHANGHAI:ZSPD,BEIJING:ZBAA,GUANGZHOU:ZGGG
SHADOW/PAPER/LIVE=DISABLED_NOT_IMPLEMENTED
ORDER/WALLET/FUNDS_CAPABILITY=NONE
```

三城不得共享Evidence行、TrainingDay、校准器、Bootstrap样本、Artifact、Qualification、Candidate、Decision、cursor、lease或breaker。共享只允许纯代码、不可变公共policy和包含三份逐城引用的ApprovedConfigSet。

## 3. Canonical Registry

### 3.1 唯一规范对象

完整替代设计必须首先生成一个机器可读`CanonicalRegistry`，其根字段唯一为：

```text
schema_version: const 1
candidate_id: non-empty string
baseline:
  branch: non-empty string
  head: H40
  source_hashes: map[path,H64]
entries: map[StableId,RegistryEntry]
registry_hash: H64
```

`registry_hash`定义为：

```text
SHA256(
  UTF8("V8_CANONICAL_REGISTRY\0")
  + canonical_json(CanonicalRegistry excluding registry_hash)
)
```

Canonical JSON固定为UTF-8、对象键按Unicode code point升序、数组保序、无多余空白、整数十进制、禁止float/NaN/Infinity。nullable必须显式写入类型，缺失与null不得等价。

### 3.2 稳定ID

`StableId`必须匹配：

```text
^[A-Z][A-Z0-9_]*(\.[A-Z][A-Z0-9_]*)+$
```

规范示例：

```text
FILE.DEPLOY.PREFLIGHT
OBJECT.APPROVED_CONFIG_SET
TABLE.EVIDENCE.RECORD
TX.EVIDENCE.COMMIT_RANGE
CLI.RUNTIME.GUARDIAN
ERROR.CROSS_CITY
TEST.CITY.REJECT_FOREIGN_ROW
```

禁止以`F046`、`O11`、`TX04`等可因插入或排序改变含义的连续位置编号作为规范身份。展示编号允许存在，但不得被任何引用、hash、Schema、DDL、测试或代码消费。

### 3.3 RegistryEntry

每个条目必须恰好包含：

```text
stable_id: StableId，且等于map key
kind: FILE|OBJECT|FIELD|SCHEMA|TABLE|COLUMN|CONSTRAINT|TRANSACTION|
      CLI|EXIT_CODE|TASK|ACL_TARGET|CAPABILITY|ERROR|METRIC|TEST
canonical_name: non-empty string
normative_owner: StableId|null
normative_payload: object|null
depends_on: unique sorted StableId[]
generated_targets: unique sorted StableId[]
required_tests: unique sorted StableId[]
status: NORMATIVE|DERIVED|DEFERRED
```

规则：

1. `NORMATIVE`必须有`normative_payload`且`normative_owner=null`；
2. `DERIVED`必须有一个`normative_owner`且`normative_payload=null`；
3. `DEFERRED`不得进入实现、Schema、DDL、Manifest或部署；
4. 一个业务规则只能有一个`NORMATIVE` owner；
5. 所有引用必须存在，不允许循环依赖；
6. 所有NORMATIVE条目至少被一个生成目标或测试消费；
7. 所有生成目标必须反向引用其owner和`registry_hash`；
8. Markdown说明不得成为第二个normative owner。

### 3.4 生成和漂移规则

JSON Schema、DDL、配置、CLI矩阵、任务、ACL矩阵、错误表和测试目录都必须是Registry的`DERIVED`表现形式。每个生成物携带：

```text
source_registry_hash
source_entry_ids[]
generator_id
generated_payload_hash
```

双向检查必须拒绝：重复稳定ID、未知引用、未消费NORMATIVE、无owner DERIVED、两个owner定义同一规则、生成物额外字段、生成物缺字段或hash不符。由此关闭B01。

## 4. 逐城数据库身份

### 4.1 每库唯一身份

未来每一个SQLite文件必须包含且仅包含一行：

```text
DatabaseIdentity:
  identity_key: const 1
  city: SHANGHAI|BEIJING|GUANGZHOU|SYSTEM
  database_role: SYSTEM|EVIDENCE|REGISTRY|RUNTIME
  database_uid: H64
  schema_registry_hash: H64
  deployment_ref: H64
  created_at: RFC3339 UTC
```

合法组合只有：

```text
SYSTEM+SYSTEM
SHANGHAI+EVIDENCE/REGISTRY/RUNTIME
BEIJING+EVIDENCE/REGISTRY/RUNTIME
GUANGZHOU+EVIDENCE/REGISTRY/RUNTIME
```

因此数据库总数固定为10：一个SYSTEM和三城各三个城市数据库。

`database_uid`定义为：

```text
SHA256("V8_DATABASE_IDENTITY\0" + deployment_ref + "\0" + city + "\0" + database_role)
```

DatabaseIdentity在初始化提交后禁止UPDATE和DELETE；复制文件不会产生新合法身份。路径、文件identity、Manifest或内容身份不匹配时拒绝连接。

### 4.2 行级城市栅栏

每个城市业务表都必须携带：

```text
identity_key INTEGER NOT NULL DEFAULT 1 CHECK(identity_key=1)
city TEXT NOT NULL
FOREIGN KEY(identity_key,city)
  REFERENCES database_identity(identity_key,city)
```

DatabaseIdentity必须有`UNIQUE(identity_key,city)`。此外，每个城市表都有`BEFORE INSERT`触发器，执行：

```text
NEW.city == SELECT city FROM database_identity WHERE identity_key=1
```

不相等时`RAISE(ABORT,'E_CROSS_CITY')`。同时使用外键与触发器，是为了既获得关系完整性又避免连接错误关闭foreign_keys后静默接受跨城行；正式连接仍必须验证`PRAGMA foreign_keys=ON`和`foreign_key_check`。

### 4.3 跨表城市一致性

所有同城引用都使用包含city的复合键，例如：

```text
metrics_report(artifact_ref,city)
  → model_artifact(artifact_ref,city)

qualification(metrics_ref,city)
  → metrics_report(metrics_ref,city)

config_candidate(qualification_ref,city)
  → qualification(qualification_ref,city)

decision(city)
  → database_identity(city)
```

Repository构造时必须取得单个`expected_city`、`expected_database_role`和`expected_database_uid`；每个公开写API再次比较输入城市。跨城企图在任何写入前或同一事务内失败并全部回滚，错误为`ERROR.CROSS_CITY`，处置为`SYSTEM_FAIL_STOP`。普通缺报、陈旧或城市来源失败只关闭该城市，不影响另外两城。由此关闭B05。

`Decision`中的`artifact_ref`和`config_set_hash`来自同一进程已验证并固定的`ApprovedConfigSet`。该文件不与Runtime DB构成同库关系，因此不得伪造跨库外键或不存在的`approved_model`表；Repository必须在事务开始前重新验证文件hash、城市绑定和artifact hash，并将验证后的引用写入Decision。

## 5. Append-only和Decision失效

### 5.1 不可变集合

以下对象及对应表属于`IMMUTABLE_AFTER_INSERT`：

```text
DatabaseIdentity
SourcePublication及完整payload
SourceAnchor
EvidenceRecord
BookPublicationHeader
BookPublicationLevel
WeatherLabel
TrainingDay
ModelArtifact
MetricsReport
Qualification
ConfigCandidate
RuntimeEvent
Decision
DecisionInvalidation
OperationReceipt
```

每张表必须同时有`BEFORE UPDATE`和`BEFORE DELETE`触发器，无条件`RAISE(ABORT,'E_IMMUTABLE')`。`ON DELETE RESTRICT`不能替代不可变trigger。完整设计的DDL必须从同一个`CONSTRAINT.IMMUTABLE.<TABLE>`条目生成，且为每张表生成UPDATE/DELETE反例。由此关闭B04。

允许更新的运行协调对象仅限cursor、lease、breaker、health、city/system current state；它们必须在Registry中逐项声明`MUTABLE_OPERATIONAL`、唯一writer和事务，不得因未登记而获得UPDATE权限。

### 5.2 Book不可变性

一个Book publication由header和全部levels在同一事务提交。levels主键包含`publication_seq+side+price+ordinal`，禁止使用可被UPSERT覆盖的`captured_at+token`历史行。旧publication和levels永不UPDATE/DELETE；header的count/hash/BBO必须从同事务levels重算匹配。

### 5.3 Decision失效对象

不再通过修改旧Decision或让一个新Decision同时承担“失效旧候选”和“表达当前评价”两个含义。唯一采用独立追加对象：

```text
DecisionInvalidation:
  invalidation_id: H64
  city: InternalCity
  invalidated_decision_id: H64
  superseding_event_id: H64
  reason: SUPERSEDED_BY_NEW_FACT|INPUT_BECAME_STALE|IDENTITY_CHANGED|
          WINDOW_CLOSED|SYSTEM_FAIL_STOP
  created_at: RFC3339 UTC
```

`UNIQUE(invalidated_decision_id)`保证一条Decision至多被失效一次。当前有效YES候选定义为：

```text
Decision.state=YES_CANDIDATE
AND NOT EXISTS DecisionInvalidation(invalidated_decision_id=Decision.decision_id)
```

每个城市Runtime DB另有一个非Evidence、允许事务内更新的运行态表：

```text
CurrentCandidateSlot:
  singleton_key: literal 1, PRIMARY KEY, CHECK(singleton_key=1)
  city: InternalCity
  current_decision_id: H64|null
  config_set_hash: H64
  updated_at_utc: RFC3339
```

处理新事实时，同一城市事务必须：读取逻辑单例slot；若slot指向旧候选则插入恰好一条DecisionInvalidation；插入当前事件Decision；将slot更新为新的YES候选或NULL；更新cursor/health并写receipt。任一步失败全部回滚。slot更新不改变历史证据，只提供唯一当前指针；Observer必须同时验证slot所指Decision存在、城市一致、未失效且config hash一致。启动恢复时，从append-only事件链重建期望slot并与存储值比较，不一致即`SYSTEM_FAIL_STOP`。若事务开始时发现零个slot、多个逻辑有效候选或slot/历史不一致，也必须fail-stop，禁止猜测修复。一个新事件可以产生当前Decision和零或一条失效记录，两者不是同一对象。由此关闭B11。

## 6. 单文件批准权威

### 6.1 唯一对象

`ApprovedConfigSet`是唯一全局批准提交点：

```text
schema_version: const 1
source_registry_hash: H64
code_ref: H64
common_policy_hash: H64
models:
  SHANGHAI: ApprovedModelRef with city const SHANGHAI
  BEIJING:  ApprovedModelRef with city const BEIJING
  GUANGZHOU: ApprovedModelRef with city const GUANGZHOU
approved_by_sid: non-empty SID
approval_ref: H64
approved_at: RFC3339 UTC
config_set_hash: H64
```

每个ApprovedModelRef必须包含：

```text
city
registry_database_uid
artifact_ref
qualification_ref
candidate_ref
policy_ref
qualification_payload_hash
candidate_payload_hash
```

`models`是固定三键对象，不是数组，因此不能漏城、重复城市或产生城市与引用的笛卡尔组合。

`config_set_hash`定义为：

```text
SHA256("V8_APPROVED_CONFIG_SET\0" + canonical_json(object excluding config_set_hash))
```

### 6.2 权限和提交点

Approval能力固定为`READ_THREE_CITY_REGISTRIES + CREATE_ONE_CONFIG_FILE`。它没有任何Registry写权限。Registry DDL不得出现`approved_config_set`或`approved_model`表，不存在跨库批准事务、三份approval receipt或`ATTACH`。

提交过程唯一为：

1. 从Deployment/Path policy取得三个固定Registry路径和config目录；
2. 分别打开三城只读事务，验证DatabaseIdentity、Artifact、Qualification=APPROVED、Candidate=UNAPPROVED及全部内容hash；
3. 验证三城code_ref、common policy和source registry一致；
4. 生成canonical bytes和config_set_hash；
5. 在最终config目录同一卷创建唯一临时文件，写入、flush、关闭并重新读取验证；
6. 使用同卷、no-replace发布到`<config_dir>/<config_set_hash>.json`；禁止copy fallback和replace-existing；
7. 重新读取最终文件，验证Schema、字节hash、文件名hash和三城引用；
8. 返回成功。

最终批准事实不是“路径存在”，而是：

```text
final file schema valid
AND recomputed config_set_hash == filename
AND config_set_hash == DeploymentManifest.config_set_hash
AND all three fixed city keys and content hashes valid
```

临时文件永远不被Runtime读取。发布前崩溃只留下非权威临时文件；发布后确认前崩溃由重试读取相同最终字节后幂等成功；最终路径存在但字节不同或无效时失败关闭，禁止覆盖和自动删除。目标文件系统、同卷rename及断电持久保证必须在完整部署设计和实现验证中证明；证明不足时保持`FILESYSTEM_PUBLICATION_UNPROVEN`并禁止部署。由此关闭B02、B03。

## 7. Schema失败关闭

### 7.1 Metrics集合

Metrics对象必须使用固定properties并恰好required：

```text
M001,M002,M003,M004,M005,M006,M007,M008,M009,
M010,M011,M012,M013,M014,M015,M016,M017,M018
```

`additionalProperties=false`。不能用`minProperties=18/maxProperties=18`替代固定名称。由此关闭B06。

### 7.2 Preflight与Verification

Preflight检查集固定为：

```text
PF001 SID
PF002 CODE_IDENTITY
PF003 RELEASE_MEMBERSHIP
PF004 APPROVED_CONFIG
PF005 PYTHON_IDENTITY
PF006 PATH_IDENTITY
PF007 CAPACITY
PF008 UPSTREAM_PUBLICATIONS
PF009 SOURCE_AND_MARKET_IDENTITY
PF010 TASK_XML
PF011 ACL_PLAN
PF012 NETWORK_CAPABILITY
PF013 EMPTY_DATABASE_TARGETS_10
PF014 LEGACY_DEPENDENCY_ABSENCE
PF015 OFFLINE_TEST_RESULT
PF016 NO_ACTIVE_CANDIDATE_PROCESS
```

部署后Verification检查集固定为：

```text
DV001 RELEASE_BYTES
DV002 CONFIG_BYTES
DV003 SCHEMA_DDL_BYTES
DV004 DATABASE_IDENTITIES_10
DV005 ACL_APPLIED
DV006 TASKS_INSTALLED_DISABLED
DV007 NETWORK_POLICY_APPLIED
DV008 NO_CANDIDATE_PROCESS
```

每个集合必须恰好包含全部ID、顺序按ID升序、`uniqueItems=true`、不得额外或缺失。`passed`是派生值：仅当所有必需检查均为PASS时为true；UNKNOWN、SKIP、空数组或任一FAIL都必须为false。Schema校验后仍须执行跨字段派生不变量。由此关闭B07。

### 7.3 三任务

任务对象固定为map而不是任意数组：

```text
EVIDENCE: URI=\PolymarketWeather\PWM-Strategy-Evidence,
          start=06:50, absolute_stop=16:10, limit=PT9H20M
RUNTIME:  URI=\PolymarketWeather\PWM-Strategy-Runtime,
          start=06:55, business_close=16:00, absolute_stop=16:05, limit=PT9H10M
OBSERVER: URI=\PolymarketWeather\PWM-Strategy-Observer,
          start=06:55, absolute_stop=16:15, limit=PT9H20M
```

三项均固定`Enabled=false`、`LogonType=InteractiveToken`、`RunLevel=LeastPrivilege`、`MultipleInstances=IgnoreNew`、`StartWhenAvailable=false`。key、URI、入口、时间或limit交叉错绑必须失败。由此关闭B08任务部分。

### 7.4 ACL目标集合

ACL target inventory恰好包含：

```text
release_root
runtime_root
runtime_root/system
runtime_root/cities
runtime_root/cities/SHANGHAI
runtime_root/cities/BEIJING
runtime_root/cities/GUANGZHOU
runtime_root/config
runtime_root/status
runtime_root/locks
system.db
SHANGHAI/evidence.db
SHANGHAI/registry.db
SHANGHAI/runtime.db
BEIJING/evidence.db
BEIJING/registry.db
BEIJING/runtime.db
GUANGZHOU/evidence.db
GUANGZHOU/registry.db
GUANGZHOU/runtime.db
```

即10个目录目标和10个数据库文件目标。不得缺父目录、增加“第12个城市DB”或用单个ACE冒充完整矩阵。完整rights/owner/inheritance将在完整设计中从该固定target inventory派生，但不得改变目标集合。由此关闭B08 ACL部分和B14。

## 8. M007和事件语义

### 8.1 非恒真M007

废除“真bucket满足`p_lcb<=1`”定义。M007唯一改为`LCB_EMPIRICAL_SHORTFALL_UCB`：

对每个forward target-day d和每个bucket b定义：

```text
z[d,b] = p_lcb[d,b] - y[d,b]
y[d,b] ∈ {0,1}
```

以`city+target_date`为cluster，对预注册bucket/lead group分别计算`mean(z)`，再用固定target-day cluster bootstrap得到其单侧上置信界。M007为所有预注册group上界的最大值：

```text
M007 = max_group UCB_alpha(mean(p_lcb-y))
```

M007越小越保守；完全错误且给非真实bucket高下界的模型会产生正shortfall并可失败。样本不足、group未预注册、alpha/replicate/seed/阈值为空时M007=null且Qualification=`BLOCKED_UNQUALIFIED`。具体alpha、replicate和通过阈值必须由未来前向资格阶段冻结，本Kernel不伪造数值。由此关闭B09的恒真语义。

### 8.2 事件和30秒安全核对

只有以下状态变化生成RuntimeEvent和新的event_id：

```text
FACT_PUBLICATION_CHANGED
FRESHNESS_STATE_CHANGED
IDENTITY_STATE_CHANGED
SYSTEM_EVENT
WINDOW_OPENED
WINDOW_CLOSED
```

每30秒安全核对只重新读取head、Clock和freshness状态：

- 若归一化状态没有变化，只追加/替换运行health，不生成event_id、不重算模型、不写Decision、不增加daily family count；
- 若freshness或identity状态发生变化，生成一个状态转换事件并重算；
- 同一转换由`city+transition_kind+before_state_hash+after_state_hash+effective_at`内容寻址，重复检测幂等；
- 不是整点、15分钟或30秒预测锚。

Bootstrap seed继续包含真实evaluation event_id。`daily_evaluation_family_count`只在一个事件通过输入准入并实际调用模型时增加一次；健康核对、重复事件、窗口外事件和在模型前失败的事件均不增加。统计独立单位仍为`city+target_date`，事件数量不得扩大资格样本n。由此关闭B10。

## 9. CLI、子进程和恢复身份

### 9.1 唯一退出码

所有CLI只允许：

```text
0 = SUCCESS_OR_NORMAL_ABSOLUTE_STOP
2 = DECLARED_VALIDATION_OR_BUSINESS_REJECTION
3 = UNEXPECTED_OR_UNCLASSIFIED_FAILURE
```

城市失败、lease冲突、未资格、Schema失败和可重试来源失败均通过结构化ErrorCode、scope、retryable和health表达，不新增退出码4—7。Guardian不得根据不存在的退出码恢复。由此关闭B12。

### 9.2 固定子进程能力

只有两个入口拥有`FIXED_CHILD_CONTROL`：

```text
ENTRY.EVIDENCE.GUARDIAN → 恰好三个逐城Evidence Worker模块
ENTRY.RUNTIME.GUARDIAN  → 恰好三个逐城Runtime Worker模块
```

共享生命周期、Evidence Worker、Runtime Worker、Observer、模型、资格和部署模块均无spawn能力。固定解释器、固定`-m`模块、固定城市参数、parent PID和DeploymentManifest由Registry生成；任何额外argv、shell、自由模块或孙进程失败。由此关闭B13。

### 9.3 恢复名称唯一

Canonical Registry必须只登记：

```text
TABLE.EVIDENCE.HEALTH = evidence_health
FIELD.SOURCE_CURSOR.BREAKER_STATE = CLOSED|OPEN|HALF_OPEN
TX.EVIDENCE.COMMIT_RANGE
TX.MODEL.PUBLISH_ARTIFACT
TX.QUALIFICATION.RECORD
TX.RUNTIME.COMMIT_EVENT
TX.SYSTEM.APPEND_EVENT
POLICY.PATHS
```

禁止并存`worker_health/evidence_health`、`TX01/TX02`位置编号或以文件展示编号引用PathPolicy。所有恢复、错误注入和测试只能引用稳定ID。由此关闭B15。

## 10. B01—B15关闭矩阵

| R1阻断 | Kernel唯一处置 | 强制反例 |
|---|---|---|
| B01 | 稳定ID、单owner、生成物反向绑定Registry | CE-K01 |
| B02 | 一个ApprovedConfigSet文件，Registry只读 | CE-K02 |
| B03 | 删除ATTACH批准；单文件no-replace发布 | CE-K03 |
| B04 | 不可变表UPDATE/DELETE triggers | CE-K04 |
| B05 | DatabaseIdentity、复合FK和城市trigger | CE-K05 |
| B06 | 固定M001—M018 properties/required | CE-K06 |
| B07 | 固定PF/DV集合，passed派生 | CE-K07 |
| B08 | 三任务fixed map和精确ACL target inventory | CE-K08 |
| B09 | M007=经验shortfall单侧UCB | CE-K09 |
| B10 | 无变化safe recheck不产生evaluation event | CE-K10 |
| B11 | 独立append-only DecisionInvalidation | CE-K11 |
| B12 | CLI仅0/2/3 | CE-K12 |
| B13 | 仅两个Guardian拥有固定spawn能力 | CE-K13 |
| B14 | 10目录+10 DB ACL目标；DB总数10 | CE-K14 |
| B15 | stable transaction/table/policy IDs及HALF_OPEN | CE-K15 |

## 11. 失败关闭和未决边界

下列内容尚未被本Kernel证明，必须保留为阻断而不是默认值：

```text
FILESYSTEM_PUBLICATION_UNPROVEN
M007_ALPHA_UNFROZEN
M007_THRESHOLD_UNFROZEN
MODEL_PARAMETERS_UNQUALIFIED
FEE_EVIDENCE_NOT_IMPLEMENTED
COMPLETE_FILE_MODULE_CLASS_FUNCTION_REGISTRY_NOT_DESIGNED
ACL_RIGHTS_MATRIX_NOT_DESIGNED
DEPLOYMENT_NOT_AUTHORIZED
```

这些未决项不使Kernel本身自动FAIL，前提是Kernel独立审查确认其边界明确且不会产生两个实现答案；它们必须在完整替代设计或以后资格阶段按各自责任关闭。任何实现者不得用默认值补齐。

## 12. Kernel与完整替代设计的关系

本Kernel独立审查PASS只证明B01—B15已有唯一架构约束，不证明完整V8设计通过。完整替代设计必须在新的独立授权下：

- 继承本Kernel精确hash，不得重写Kernel规范；
- 补齐每个未来文件、模块、类、函数、Schema、字段、事务、CLI、任务、ACL、错误和测试；
- 从Canonical Registry机械生成或核对全部表现形式；
- 完成作者自检、Manifest和一次完整端到端独立终审。

任何后续设计若需要改变Kernel NORMATIVE条目，当前Kernel验收立即失效，必须停止并重新进行路线决策，不能静默修改。

## 13. 当前状态和停止点

```text
ARCHITECTURE_KERNEL_CANDIDATE_FROZEN=YES
ARCHITECTURE_KERNEL_INDEPENDENT_AUDIT=NOT_AUTHORIZED/NOT_RUN
ARCHITECTURE_KERNEL_ACCEPTED=NO
COMPLETE_REPLACEMENT_DESIGN=NO
IMPLEMENTATION/TEST/GIT/DEPLOYMENT=NO
SHADOW/PAPER/LIVE=NO
```

本候选完成后只允许形成作者自检和Manifest，然后停止等待独立Kernel审查授权。
