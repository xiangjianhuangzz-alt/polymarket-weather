"""Event-driven desktop dashboard.  It only reads the research database."""
from __future__ import annotations

import json
import logging
import threading
import time

import webview

from dashboard_modern import Api, BASE, DB, PAPER_DB
from db_paths import OBSERVATIONS_DB, REALTIME_DB
from live_state_client import StateHubClient
from ui_events import domain_revision, high_water, read_after


PUSH_ERROR_LOG_INTERVAL_SECONDS = 60.0


class LiveDashboard:
    def __init__(self) -> None:
        self.state_hub = StateHubClient()
        self.api = Api(self.state_hub.view)
        self.window = webview.create_window(
            "温度市场实时看板", (BASE / "ui" / "live.html").as_uri(), js_api=self.api,
            width=1500, height=940, min_size=(1100, 720), background_color="#f7f9fc",
        )
        self.window.events.loaded += self.start_push
        self._started = False
        self._last_pushed_revision = -1
        self._last_domains: dict[str, str] = {}
        self._last_quotes: dict[str, tuple] = {}
        self._last_hub_health = ""
        self._next_paper_refresh = 0.0
        self._event_cursors = {"research": 0, "realtime": 0, "paper": 0, "observations": 0}
        self._quote_revision = 0
        self._next_push_error_log = 0.0
        self._suppressed_push_errors = 0

    @staticmethod
    def _fingerprint(value: object) -> str:
        """Stable, cheap comparison for independently refreshed UI domains."""
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)

    @staticmethod
    def _market_metadata(markets: list[dict]) -> list[dict]:
        """Exclude live quote fields: they belong to the quote patch only."""
        dynamic = {"bid", "ask", "bid_size", "ask_size", "book_time",
                   "quote_captured_at", "quote_health", "exchange_at",
                   "received_at", "published_at", "source_to_receive_ms",
                   "source_to_hub_ms", "quote_sequence", "quote_stream_id",
                   "levels"}
        return [{key: value for key, value in item.items() if key not in dynamic} for item in markets]

    def _quote_changes(self, frame: dict) -> list[dict]:
        changes: list[dict] = []
        active: set[str] = set()
        for item in frame.get("markets", []):
            ident = str(item.get("id"))
            active.add(ident)
            quote = {key: item.get(key) for key in
                     ("id", "bid", "ask", "bid_size", "ask_size", "book_time",
                      "quote_captured_at", "quote_health", "exchange_at",
                      "received_at", "published_at", "source_to_receive_ms",
                      "source_to_hub_ms", "quote_sequence", "quote_stream_id",
                      "levels")}
            signature = tuple(json.dumps(quote.get(key), ensure_ascii=False, sort_keys=True, default=str)
                              for key in quote if key != "id")
            if self._last_quotes.get(ident) != signature:
                self._last_quotes[ident] = signature
                changes.append(quote)
        for ident in set(self._last_quotes) - active:
            self._last_quotes.pop(ident, None)
        return changes

    def _send(self, name: str, payload: dict) -> None:
        self.window.evaluate_js(f"window.{name}(" + json.dumps(payload, ensure_ascii=False) + ")")

    def _record_push_error(self, exc: Exception, *,
                           monotonic_now: float | None = None) -> None:
        """Rate-limit UI diagnostics without making logging a push dependency."""
        now = time.monotonic() if monotonic_now is None else monotonic_now
        if now < self._next_push_error_log:
            self._suppressed_push_errors += 1
            return
        suppressed = self._suppressed_push_errors
        self._suppressed_push_errors = 0
        self._next_push_error_log = now + PUSH_ERROR_LOG_INTERVAL_SECONDS
        try:
            logging.warning(
                "dashboard push failed; loop continues; suppressed=%s: %s: %s",
                suppressed, type(exc).__name__, exc,
            )
        except Exception:
            # Diagnostics must never become a dependency of the UI push loop.
            return

    def _send_refresh_deltas(self, frame: dict, *, requested: set[str] | None = None) -> None:
        """Push only the UI domains justified by a committed source event.

        ``requested`` is deliberately narrower than a database snapshot.  The
        snapshot query is a read-consistency mechanism; it must never become a
        reason to re-render unrelated browser pages.  A lost event cursor uses
        ``None`` as the explicit recovery-only full-domain path.
        """
        domains = {
            "markets": self._market_metadata(frame.get("markets", [])),
            "forecasts": frame.get("forecasts", []),
            "validations": frame.get("validations", []),
        }
        names = set(domains) if requested is None else (set(requested) & set(domains))
        changed = {name: domains[name] for name in names
                   if self._last_domains.get(name) != self._fingerprint(domains[name])}
        for name in names:
            value = domains[name]
            self._last_domains[name] = self._fingerprint(value)
        # Health is deliberately tiny and can change without touching data panels.
        payload = {"type": "snapshot", "now": frame.get("now"),
                   "services": frame.get("services", {}), **changed}
        if changed:
            self._send("dashboardPatch", payload)

    def _bootstrap_event_cursors(self) -> None:
        """Initial page data is already a full state; ignore older events."""
        self._event_cursors = {"research": high_water(DB), "realtime": high_water(REALTIME_DB),
                               "paper": high_water(PAPER_DB), "observations": high_water(OBSERVATIONS_DB)}
        self._quote_revision = domain_revision(REALTIME_DB, "quotes")

    def _read_domain_events(self) -> tuple[set[str], bool]:
        domains: set[str] = set()
        gap = False
        for source, path in (("research", DB), ("realtime", REALTIME_DB), ("paper", PAPER_DB),
                             ("observations", OBSERVATIONS_DB)):
            rows, missed = read_after(path, self._event_cursors[source])
            gap = gap or missed
            if rows:
                self._event_cursors[source] = rows[-1][0]
                domains.update(domain for _, domain in rows)
        return domains, gap

    def start_push(self) -> None:
        if self._started:
            return
        self._started = True
        self.state_hub.start()
        threading.Thread(target=self.push_loop, name="dashboard-state-push", daemon=True).start()

    def push_loop(self) -> None:
        frame = None
        next_event_poll = 0.0
        next_quote_fallback = 0.0
        while True:
            try:
                now = time.monotonic()
                hub = self.state_hub.view()
                if frame is None:
                    frame = self.api.snapshot()
                    self._quote_changes(frame)
                    self._last_domains = {
                        "markets": self._fingerprint(self._market_metadata(frame.get("markets", []))),
                        "forecasts": self._fingerprint(frame.get("forecasts", [])),
                        "validations": self._fingerprint(frame.get("validations", [])),
                    }
                    self._bootstrap_event_cursors()
                    self._send("dashboardInit", frame)

                # Quote traffic is served from the local hub and never queries
                # SQLite while the hub remains fresh.
                revision = hub.get("revision", -1)
                if revision != self._last_pushed_revision:
                    frame = self.api.apply_live_quotes(frame)
                    quotes = self._quote_changes(frame)
                    hub_health = self._fingerprint(
                        frame.get("services", {}).get("state_hub", {})
                    )
                    if quotes or hub_health != self._last_hub_health:
                        self._send("dashboardPatch", {"type": "quotes", "now": frame.get("now"),
                                                       "services": frame.get("services", {}), "quotes": quotes})
                    self._last_hub_health = hub_health
                    self._last_pushed_revision = revision

                # Durable outbox events are read in small batches.  A commit
                # can refresh only its own UI domain; no timer creates normal
                # full-page snapshots.
                if now >= next_event_poll:
                    domains, gap = self._read_domain_events()
                    next_event_poll = now + 0.5
                    research_domains = domains & {"markets", "forecasts", "settlements"}
                    if gap or research_domains:
                        frame = self.api.snapshot()
                        self._quote_revision = domain_revision(REALTIME_DB, "quotes")
                        # A forecast/D0 change may alter both the forecast page
                        # and its validation row.  A settlement may alter only
                        # validation.  Market metadata stays isolated.
                        requested: set[str] | None
                        if gap:
                            requested = None
                        else:
                            requested = set()
                            if "markets" in research_domains:
                                requested.add("markets")
                            if "forecasts" in research_domains:
                                requested.update({"forecasts", "validations"})
                            if "settlements" in research_domains:
                                requested.add("validations")
                        self._send_refresh_deltas(frame, requested=requested)
                    elif "health" in domains:
                        health = self.api.health_snapshot()
                        frame["now"] = health.get("now", frame.get("now"))
                        frame["services"] = health.get("services", frame.get("services", {}))
                        self._send("dashboardPatch", health)
                    if "paper" in domains:
                        self._send("dashboardPatch", {"type": "paper", "paper_refresh": True})
                    if "actuals" in domains:
                        actuals = self.api.actual_snapshot()
                        frame["actuals"] = actuals
                        self._send("dashboardPatch", {"type": "actuals", "actuals": actuals})

                # If the hub is disconnected, use only the durable quote
                # revision as a two-second fallback trigger.  This is a
                # recovery path, not a normal periodic snapshot.
                if hub.get("state") != "healthy" and now >= next_quote_fallback:
                    next_quote_fallback = now + 2.0
                    durable_quote_revision = domain_revision(REALTIME_DB, "quotes")
                    if durable_quote_revision > self._quote_revision:
                        self._quote_revision = durable_quote_revision
                        frame = self.api.snapshot()
                        # The state hub is unavailable: this is recovery only.
                        # Send quote changes, not a database-domain repaint.
                        quote_changes = self._quote_changes(frame)
                        if quote_changes:
                            self._send("dashboardPatch", {"type": "quotes", "now": frame.get("now"),
                                                           "services": frame.get("services", {}), "quotes": quote_changes})
            except Exception as exc:
                self._record_push_error(exc)
            # Wait on the local hub condition, not a quote polling timer.
            # The half-second timeout exists only for durable domain events.
            timeout = max(0.01, min(0.5, next_event_poll - time.monotonic()))
            self.state_hub.wait_for_revision(
                self._last_pushed_revision, timeout=timeout
            )


if __name__ == "__main__":
    app = LiveDashboard()
    webview.start()
