"""End-to-end research POC. Reads live evidence and records no real order."""
from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path


BASE = Path(__file__).resolve().parent
DB = BASE / "data" / "research.sqlite3"
TICK_SIZE = 0.01
POC_SHARES = 5.0


def main() -> None:
    db = sqlite3.connect(DB, timeout=10)
    db.execute("PRAGMA busy_timeout=10000")
    try:
        quote = db.execute("""SELECT b.captured_at,b.market_id,b.token_id,b.best_bid,b.best_ask,
          b.bid_size,b.ask_size,b.event_reason,b.depth_fresh,
          COALESCE(m.city,''),COALESCE(m.bucket_label,m.question),m.question
          FROM book_snapshots b
          LEFT JOIN market_snapshots m ON m.market_id=b.market_id AND m.captured_at=(
            SELECT MAX(m2.captured_at) FROM market_snapshots m2 WHERE m2.market_id=b.market_id)
          WHERE b.best_bid IS NOT NULL AND b.best_ask IS NOT NULL
            AND b.best_bid>0.001 AND b.best_ask<0.999
          ORDER BY b.captured_at DESC LIMIT 1""").fetchone()
        if not quote:
            raise RuntimeError("no recent valid two-sided BBO")
        (captured_at, market, token, bid, ask, bid_size, ask_size, reason,
         depth_fresh, city, bucket, question) = quote
        captured_dt = datetime.fromisoformat(captured_at.replace("Z", "+00:00"))
        age_seconds = max(0.0, (datetime.now(UTC) - captured_dt.astimezone(UTC)).total_seconds())
        if age_seconds > 120:
            raise RuntimeError(f"latest quote is stale: {age_seconds:.1f}s")

        depth_at = captured_at if depth_fresh else db.execute(
            "SELECT MAX(captured_at) FROM orderbook_levels WHERE token_id=? AND captured_at<=?",
            (token, captured_at)).fetchone()[0]
        depth_rows = db.execute("""SELECT side,price,size FROM orderbook_levels
          WHERE token_id=? AND captured_at=?
          ORDER BY side,CASE side WHEN 'ask' THEN price END ASC,
            CASE side WHEN 'bid' THEN price END DESC""", (token, depth_at)).fetchall() if depth_at else []
        depth = [{"side": side, "price": price, "size": size} for side, price, size in depth_rows]

        proposed_limit = round(min(float(ask), float(bid) + TICK_SIZE), 4)
        immediately_marketable = proposed_limit >= float(ask)
        top_ask_fillable = bool(immediately_marketable and ask_size is not None and float(ask_size) >= POC_SHARES)
        assessment = "immediate_fill_possible" if top_ask_fillable else (
            "marketable_but_top_size_insufficient" if immediately_marketable else "resting_limit_order")

        bar_counts = dict(db.execute("""SELECT interval_seconds,COUNT(1) FROM book_price_bars
          WHERE token_id=? AND last_event_at<=? GROUP BY interval_seconds""",
          (token, captured_at)).fetchall())
        if not bar_counts.get(60) or not bar_counts.get(300):
            raise RuntimeError("compact price bars missing for selected token")

        checkpoint_id = f"poc-{uuid.uuid4()}"
        metadata = {
            "poc": True,
            "real_order_submitted": False,
            "shares": POC_SHARES,
            "tick_size": TICK_SIZE,
            "proposed_limit": proposed_limit,
            "assessment": assessment,
            "quote_age_seconds": round(age_seconds, 3),
            "event_reason": reason,
            "depth_fresh": bool(depth_fresh),
            "minute_bar_count": int(bar_counts.get(60, 0)),
            "five_minute_bar_count": int(bar_counts.get(300, 0)),
        }
        now = datetime.now(UTC).isoformat()
        db.execute("""INSERT INTO strategy_checkpoints
          (checkpoint_id,created_at,market_id,token_id,action,reason,best_bid,best_ask,
           bid_size,ask_size,depth_json,quote_captured_at,metadata_json)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (checkpoint_id,now,market,token,"poc_simulated_entry","pipeline_validation",
           bid,ask,bid_size,ask_size,json.dumps(depth,ensure_ascii=False),captured_at,
           json.dumps(metadata,ensure_ascii=False)))
        db.commit()
        stored = db.execute("SELECT action,quote_captured_at,metadata_json FROM strategy_checkpoints WHERE checkpoint_id=?",
                            (checkpoint_id,)).fetchone()
        if not stored:
            raise RuntimeError("strategy checkpoint was not persisted")

        print(json.dumps({
            "result": "PASS",
            "checkpoint_id": checkpoint_id,
            "city": city,
            "bucket": bucket,
            "question": question,
            "quote": {"captured_at": captured_at, "age_seconds": round(age_seconds, 3),
                      "bid": bid, "ask": ask, "bid_size": bid_size, "ask_size": ask_size,
                      "event_reason": reason, "depth_fresh": bool(depth_fresh)},
            "depth_levels": len(depth),
            "simulated_order": {"side": "BUY YES", "shares": POC_SHARES,
                                "limit_price": proposed_limit, "assessment": assessment,
                                "real_order_submitted": False},
            "history": {"minute_bars": int(bar_counts[60]), "five_minute_bars": int(bar_counts[300])},
            "checkpoint_verified": True,
        }, ensure_ascii=False, indent=2))
    finally:
        db.close()


if __name__ == "__main__":
    main()
