"""Research-only bridge from Research Dataset V1 to weather model inputs."""

from __future__ import annotations

from dataclasses import dataclass, fields
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, InvalidOperation
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Mapping


SHANGHAI = timezone(timedelta(hours=8), "Asia/Shanghai")
UTC = timezone.utc
EXPECTED_DATES = tuple(date(2026, 8, 22) + timedelta(days=offset) for offset in range(12))
RETAINED_STATUSES = frozenset({"AVAILABLE", "MISSING", "CONFLICT", "UNPROVABLE"})
INSUFFICIENT_MATURE_TRAINING_DATA = "INSUFFICIENT_MATURE_TRAINING_DATA"
READY = "READY"


def _text(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a non-empty string")
    return value


def _integer(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    return value


def _decimal(value: Any, name: str) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise ValueError(f"{name} must be a JSON number or decimal string")
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise ValueError(f"{name} is not decimal") from exc
    if not result.is_finite():
        raise ValueError(f"{name} must be finite")
    return result


def _utc(value: Any, name: str) -> datetime:
    text = _text(value, name)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{name} must be ISO-8601") from exc
    if parsed.tzinfo is None or parsed.utcoffset() != timedelta(0):
        raise ValueError(f"{name} must be UTC")
    return parsed.astimezone(UTC)


def _mapping(value: Any, name: str) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be an object")
    return value


@dataclass(frozen=True, slots=True)
class ResearchWeatherLabelV1:
    target_date: date
    station: str
    final_max_c: Decimal
    label_freeze_at_utc: str
    label_hash: str


@dataclass(frozen=True, slots=True)
class ResearchWeatherModelInputV1:
    city: str
    target_date: date
    decision_as_of_utc: str
    local_second: int
    forecast_high_c: Decimal
    current_observed_max_c: Decimal
    forecast_source_fact_id: str
    observation_fact_ids: tuple[str, ...]
    weather_label: ResearchWeatherLabelV1


@dataclass(frozen=True, slots=True)
class RetainedResearchDayV1:
    target_date: date
    status: str
    reason: str | None
    weather_input: ResearchWeatherModelInputV1 | None


@dataclass(frozen=True, slots=True)
class ResearchWeatherDatasetV1:
    days: tuple[RetainedResearchDayV1, ...]

    def weather_model_inputs(self) -> tuple[ResearchWeatherModelInputV1, ...]:
        return tuple(day.weather_input for day in self.days if day.weather_input is not None)

    def training_readiness(self, minimum_mature_days: int) -> str:
        if isinstance(minimum_mature_days, bool) or not isinstance(minimum_mature_days, int) or minimum_mature_days < 1:
            raise ValueError("minimum_mature_days must be a positive integer")
        return READY if len(self.weather_model_inputs()) >= minimum_mature_days else INSUFFICIENT_MATURE_TRAINING_DATA

    def deterministic_hash(self) -> str:
        payload = [
            {
                "target_date": day.target_date.isoformat(),
                "status": day.status,
                "reason": day.reason,
                "weather_input": None if day.weather_input is None else {
                    field.name: str(getattr(day.weather_input, field.name))
                    for field in fields(ResearchWeatherModelInputV1)
                },
            }
            for day in self.days
        ]
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return sha256(encoded).hexdigest()


def parse_research_dataset(payload: Any, *, validation_as_of_utc: str) -> ResearchWeatherDatasetV1:
    root = _mapping(payload, "dataset")
    if root.get("schema_version") != "research_dataset_v1" or root.get("dataset_version") != "P_SH_RESEARCH_0800_V1":
        raise ValueError("unexpected Research Dataset V1 identity")
    if root.get("city") != "Shanghai" or root.get("decision_anchor") != {"local_time": "08:00:00", "timezone": "Asia/Shanghai"}:
        raise ValueError("dataset must be Shanghai at 08:00 Asia/Shanghai")
    rows = root.get("days")
    if not isinstance(rows, list) or len(rows) != len(EXPECTED_DATES):
        raise ValueError("all 12 research dates must be retained")
    validation_as_of = _utc(validation_as_of_utc, "validation_as_of_utc")
    retained: list[RetainedResearchDayV1] = []
    for expected_date, value in zip(EXPECTED_DATES, rows):
        row = _mapping(value, "day")
        try:
            target = date.fromisoformat(_text(row.get("target_date"), "target_date"))
        except ValueError as exc:
            raise ValueError("target_date is invalid") from exc
        if target != expected_date:
            raise ValueError("research dates must be complete, unique, and ordered")
        status = _text(row.get("overall_status"), "overall_status")
        if status not in RETAINED_STATUSES:
            raise ValueError("unknown retained status")
        weather = _mapping(row.get("weather_prediction_track"), "weather_prediction_track")
        if weather.get("status") != status:
            raise ValueError("overall and weather status must agree")
        reason = weather.get("forecast_reason") or weather.get("observation_reason") or weather.get("weather_label_reason")
        if reason is not None and not isinstance(reason, str):
            raise ValueError("retained reason must be a string or null")
        if status != "AVAILABLE":
            retained.append(RetainedResearchDayV1(target, status, reason, None))
            continue
        decision_text = _text(row.get("decision_as_of_utc"), "decision_as_of_utc")
        decision = _utc(decision_text, "decision_as_of_utc")
        expected_decision = datetime.combine(target, time(8), SHANGHAI).astimezone(UTC)
        local_anchor = datetime.fromisoformat(_text(row.get("decision_anchor_local"), "decision_anchor_local"))
        if decision != expected_decision or local_anchor != datetime.combine(target, time(8), SHANGHAI):
            raise ValueError("day decision anchor is not 08:00 Asia/Shanghai")
        forecast = _mapping(weather.get("forecast"), "forecast")
        if forecast.get("city") != "Shanghai" or forecast.get("station") != "ZSPD" or forecast.get("source") != "weatherol_shanghai":
            raise ValueError("forecast identity must be Shanghai/weatherol_shanghai/ZSPD")
        if forecast.get("target_date") != target.isoformat() or forecast.get("decision_as_of_utc") != decision_text:
            raise ValueError("forecast target or AS-OF conflicts with day")
        if _integer(forecast.get("candidate_revision_count"), "candidate_revision_count") < 1:
            raise ValueError("forecast revision set is empty")
        if _utc(forecast.get("observed_at_utc"), "forecast observed_at_utc") > decision:
            raise ValueError("forecast revision was not observed by the decision anchor")
        if weather.get("future_leakage_status") != "PASS":
            raise ValueError("weather input future-leakage status is not PASS")
        observation_ids = weather.get("observation_fact_ids_at_anchor")
        if not isinstance(observation_ids, list) or not observation_ids or not all(isinstance(item, str) and item for item in observation_ids):
            raise ValueError("anchor observations must be a non-empty string list")
        if len(set(observation_ids)) != len(observation_ids) or _integer(weather.get("observation_count_at_anchor"), "observation_count_at_anchor") != len(observation_ids):
            raise ValueError("anchor observation identities are duplicate or inconsistent")
        label = _mapping(weather.get("weather_label"), "weather_label")
        if label.get("city") != "Shanghai" or label.get("station") != "ZSPD" or label.get("target_date") != target.isoformat():
            raise ValueError("weather label identity must be Shanghai/ZSPD/target_date")
        freeze_text = _text(label.get("label_freeze_at_utc"), "label_freeze_at_utc")
        expected_freeze = datetime.combine(target + timedelta(days=2), time.min, SHANGHAI).astimezone(UTC)
        freeze = _utc(freeze_text, "label_freeze_at_utc")
        if freeze != expected_freeze or freeze > validation_as_of:
            raise ValueError("weather label is not mature under the D+2 contract")
        label_value = ResearchWeatherLabelV1(target, "ZSPD", _decimal(label.get("final_max_c"), "final_max_c"), freeze_text, _text(label.get("label_hash"), "label_hash"))
        model_input = ResearchWeatherModelInputV1(
            "Shanghai", target, decision_text, 8 * 3600,
            _decimal(forecast.get("forecast_high_c"), "forecast_high_c"),
            _decimal(weather.get("current_observed_max_c"), "current_observed_max_c"),
            _text(forecast.get("source_fact_id"), "forecast source_fact_id"),
            tuple(observation_ids), label_value,
        )
        retained.append(RetainedResearchDayV1(target, status, reason, model_input))
    return ResearchWeatherDatasetV1(tuple(retained))


def load_research_dataset(path: str | Path, *, validation_as_of_utc: str) -> ResearchWeatherDatasetV1:
    with Path(path).open("r", encoding="utf-8") as stream:
        return parse_research_dataset(json.load(stream), validation_as_of_utc=validation_as_of_utc)
