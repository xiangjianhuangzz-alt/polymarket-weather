"""Research-only Stage1A weather validation helpers."""
