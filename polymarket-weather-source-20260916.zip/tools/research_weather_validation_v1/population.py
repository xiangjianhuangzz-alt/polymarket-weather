"""Build the Shanghai Stage1A research-only weather population.

This tool is deliberately offline and read-only with respect to all source
databases.  It writes only the three declared artefacts in its output folder.
It does not create an IIC2 dataset, infer market Edge, or select a subset of
days for a strategy result.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
from collections import Counter
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo


CITY = "Shanghai"
STATION = "ZSPD"
SOURCE = "weatherol_shanghai"
SHANGHAI = ZoneInfo("Asia/Shanghai")
GAP_LIMIT_SECONDS = 5400
STATUSES = ("AVAILABLE", "MISSING", "CONFLICT", "UNPROVABLE")


def canonical(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value: object) -> str:
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def parse_utc(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def iso_z(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def decimal_text(value: object | None) -> str | None:
    if value is None:
        return None
    return format(Decimal(str(value)), "f")


def utc_for_local(day: date, clock: time) -> datetime:
    return datetime.combine(day, clock, tzinfo=SHANGHAI).astimezone(timezone.utc)


def local_day_window(target: date) -> tuple[datetime, datetime, datetime]:
    start = utc_for_local(target, time.min)
    anchor = utc_for_local(target, time(8))
    end = utc_for_local(target + timedelta(days=1), time.min)
    return start, anchor, end


def label_freeze(target: date) -> datetime:
    return utc_for_local(target + timedelta(days=2), time.min)


def read_only_connection(path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path.resolve().as_posix()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def source_waterline(connection: sqlite3.Connection) -> str | None:
    value = connection.execute("SELECT MAX(received_at) FROM metar_observations WHERE station = ? AND city = ?", (STATION, CITY)).fetchone()[0]
    return value


def source_registry_row(connection: sqlite3.Connection, target: str) -> tuple[sqlite3.Row | None, str | None]:
    rows = connection.execute(
        """
        SELECT source, city, station, target_date, grid_version, status, forecast_high_c,
               source_reported_at, first_captured_at, content_hash, reason, frozen_at,
               latest_checked_at
        FROM forecast_d0_registry
        WHERE source = ? AND city = ? AND station = ? AND target_date = ? AND status = 'valid_d0'
        ORDER BY grid_version ASC
        """,
        (SOURCE, CITY, STATION, target),
    ).fetchall()
    if not rows:
        return None, "FORECAST_D0_MISSING"
    identities = {(row["grid_version"], row["content_hash"], row["forecast_high_c"]) for row in rows}
    if len(identities) != 1:
        return None, "FORECAST_D0_CONFLICT"
    return rows[0], None


def observations(connection: sqlite3.Connection, start: datetime, end: datetime, visible_by: datetime) -> list[sqlite3.Row]:
    return connection.execute(
        """
        SELECT observation_id, report_time, received_at, report_type, temperature_c, raw_hash, source
        FROM metar_observations
        WHERE station = ? AND city = ?
          AND report_time >= ? AND report_time < ? AND received_at <= ?
          AND temperature_c IS NOT NULL
        ORDER BY report_time ASC, observation_id ASC
        """,
        (STATION, CITY, iso_z(start), iso_z(end), iso_z(visible_by)),
    ).fetchall()


def observation_identity(rows: list[sqlite3.Row]) -> tuple[list[str], str]:
    identities = [f"metar_observation:{row['observation_id']}:{row['raw_hash']}" for row in rows]
    return identities, digest(identities)


def coverage_complete(rows: list[sqlite3.Row], start: datetime, end: datetime) -> tuple[bool, int | None]:
    if not rows:
        return False, None
    instants = [parse_utc(row["report_time"]) for row in rows]
    gap = max((int((right - left).total_seconds()) for left, right in zip(instants, instants[1:])), default=0)
    return instants[0] <= start + timedelta(minutes=30) and instants[-1] >= end - timedelta(minutes=30) and gap <= GAP_LIMIT_SECONDS, gap


def row_ref(database: str, row: sqlite3.Row) -> dict[str, object]:
    return {
        "database": database,
        "table": "forecast_d0_registry",
        "source": row["source"],
        "city": row["city"],
        "station": row["station"],
        "target_date": row["target_date"],
        "grid_version": row["grid_version"],
        "status": row["status"],
        "forecast_high_c": decimal_text(row["forecast_high_c"]),
        "source_reported_at": row["source_reported_at"],
        "first_captured_at": row["first_captured_at"],
        "content_hash": row["content_hash"],
        "frozen_at": row["frozen_at"],
    }


def load_existing_days(path: Path) -> tuple[dict[str, dict[str, object]], dict[str, object]]:
    source = json.loads(path.read_text(encoding="utf-8"))
    if source["city"] != CITY or source["purpose"] != "RESEARCH_VALIDATION_ONLY" or source["production_iic2_unchanged"] is not True:
        raise ValueError("frozen research dataset identity does not match the Stage1A contract")
    return {entry["target_date"]: entry for entry in source["days"]}, source


def frozen_entry(target: str, entry: dict[str, object], dataset_path: Path, manifest_hash: str) -> dict[str, object]:
    weather = entry["weather_prediction_track"]
    forecast = weather["forecast"]
    label = weather["weather_label"]
    label_freeze_text = label["label_freeze_at_utc"] if label else iso_z(label_freeze(date.fromisoformat(target)))
    return {
        "target_date": target,
        "status": entry["overall_status"],
        "reason": "FROZEN_RESEARCH_DATASET_DAY",
        "decision_as_of_utc": entry["decision_as_of_utc"],
        "forecast_high_c": decimal_text(forecast["forecast_high_c"]) if forecast else None,
        "current_observed_max_c": decimal_text(weather["current_observed_max_c"]),
        "label_final_max_c": decimal_text(label["final_max_c"]) if label else None,
        "label_available_at_utc": label_freeze_text,
        "source_refs": [
            {
                "kind": "frozen_research_dataset_day",
                "path": str(dataset_path.as_posix()),
                "dataset_day_record_hash": entry["day_record_hash"],
                "dataset_manifest_hash": manifest_hash,
                "forecast_source_fact_id": forecast["source_fact_id"] if forecast else None,
                "forecast_source_payload_hash": forecast["source_payload_hash"] if forecast else None,
                "weather_label_hash": label["label_hash"] if label else None,
                "observation_set_hash_at_anchor": weather["observation_set_hash_at_anchor"],
            }
        ],
        "asof_checks": {
            "source_kind": "FROZEN_RESEARCH_DATASET_V1",
            "forecast_status": weather["forecast_status"],
            "observation_status": weather["observation_status"],
            "weather_label_status": weather["weather_label_status"],
            "future_leakage_status": weather["future_leakage_status"],
            "dataset_day_record_hash": entry["day_record_hash"],
        },
    }


def recovered_entry(
    target: date,
    source_name: str,
    research: sqlite3.Connection,
    observation_db: sqlite3.Connection,
    source_cutoff: datetime,
    builder_as_of: datetime,
) -> dict[str, object]:
    target_text = target.isoformat()
    start, anchor, end = local_day_window(target)
    freeze = label_freeze(target)
    forecast, forecast_error = source_registry_row(research, target_text)
    base = {
        "target_date": target_text,
        "status": "UNPROVABLE",
        "reason": None,
        "decision_as_of_utc": iso_z(anchor),
        "forecast_high_c": None,
        "current_observed_max_c": None,
        "label_final_max_c": None,
        "label_available_at_utc": iso_z(freeze),
        "source_refs": [],
        "asof_checks": {
            "source_kind": source_name,
            "source_data_waterline_utc": iso_z(source_cutoff),
            "anchor_observation_visible_by_utc": iso_z(anchor),
            "label_freeze_at_utc": iso_z(freeze),
            "gap_limit_seconds": GAP_LIMIT_SECONDS,
        },
    }
    if forecast_error == "FORECAST_D0_CONFLICT":
        base.update(status="CONFLICT", reason=forecast_error)
        return base
    if forecast is None:
        base.update(status="MISSING", reason=forecast_error)
        return base
    base["forecast_high_c"] = decimal_text(forecast["forecast_high_c"])
    base["source_refs"].append(row_ref(source_name, forecast))
    captured = parse_utc(forecast["first_captured_at"])
    if captured > anchor:
        base.update(status="UNPROVABLE", reason="FORECAST_NOT_VISIBLE_BY_DECISION_ASOF")
        return base
    anchor_rows = observations(observation_db, start, anchor, anchor)
    anchor_ids, anchor_hash = observation_identity(anchor_rows)
    base["asof_checks"].update(
        anchor_observation_count=len(anchor_rows),
        anchor_observation_fact_ids=anchor_ids,
        anchor_observation_set_hash=anchor_hash,
        forecast_first_captured_at=forecast["first_captured_at"],
    )
    if not anchor_rows:
        base.update(status="MISSING", reason="CURRENT_OBSERVATION_AT_ANCHOR_MISSING")
        return base
    base["current_observed_max_c"] = decimal_text(max(row["temperature_c"] for row in anchor_rows))
    if freeze > builder_as_of:
        base.update(status="UNPROVABLE", reason="LABEL_NOT_MATURE_AT_BUILDER_ASOF")
        return base
    label_rows = observations(observation_db, start, end, freeze)
    complete, gap = coverage_complete(label_rows, start, end)
    label_ids, label_hash = observation_identity(label_rows)
    base["asof_checks"].update(
        label_observation_count=len(label_rows),
        label_observation_fact_ids=label_ids,
        label_observation_set_hash=label_hash,
        label_maximum_gap_seconds=gap,
    )
    if not complete:
        base.update(status="MISSING", reason="LABEL_OBSERVATION_COVERAGE_INCOMPLETE")
        return base
    base.update(
        status="AVAILABLE",
        reason="RECOVERED_RESEARCH_WEATHER_FACTS",
        label_final_max_c=decimal_text(max(row["temperature_c"] for row in label_rows)),
    )
    return base


def evidence_snapshot_path(root: Path, snapshot_day: date) -> Path | None:
    stamp = snapshot_day.isoformat()
    if stamp in {"2026-08-14", "2026-08-15"}:
        path = root / "data" / "evidence_capture" / f"be05_v3_asof_{stamp.replace('-', '')}" / "evidence.sqlite3"
    else:
        path = root / "data" / "evidence_capture" / "be05_v3_asof" / stamp / "evidence.sqlite3"
    return path if path.is_file() else None


def evidence_forecast(connection: sqlite3.Connection, target: date, anchor: datetime) -> tuple[dict[str, object] | None, str | None]:
    layout = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    if "evidence_events" in layout:
        rows = connection.execute(
        """
        SELECT e.source_reported_at, e.upstream_captured_at, e.recorder_first_observed_at,
               e.raw_payload_hash, r.payload_json
        FROM evidence_events e JOIN raw_payloads r ON r.payload_hash = e.raw_payload_hash
        WHERE e.dimension = 'weather' AND e.source = ? AND e.city = ? AND e.station = ?
          AND e.target_date = ? AND e.grade = 'native_strict_asof'
        """,
            (SOURCE, CITY, STATION, target.isoformat()),
        ).fetchall()
        raw = [
            {"source_reported_at": row["source_reported_at"], "upstream_captured_at": row["upstream_captured_at"], "recorder_first_observed_at": row["recorder_first_observed_at"], "raw_payload_hash": row["raw_payload_hash"], "payload_json": row["payload_json"]}
            for row in rows
        ]
    else:
        rows = connection.execute("SELECT source_event_time, observed_at_utc, content_sha256, payload_json FROM evidence_records WHERE source_table = 'forecast_versions'").fetchall()
        raw = [
            {"source_reported_at": row["source_event_time"], "upstream_captured_at": None, "recorder_first_observed_at": row["observed_at_utc"], "raw_payload_hash": row["content_sha256"], "payload_json": row["payload_json"]}
            for row in rows
        ]
    parsed: list[dict[str, object]] = []
    for row in raw:
        payload = json.loads(row["payload_json"])
        first_seen = payload.get("first_seen_at")
        if payload.get("source") != SOURCE or payload.get("city") != CITY or payload.get("station") != STATION or payload.get("target_date") != target.isoformat() or payload.get("forecast_high_c") is None or not isinstance(first_seen, str) or parse_utc(first_seen) > anchor:
            continue
        parsed.append({"row": row, "payload": payload})
    if not parsed:
        return None, "FORECAST_D0_MISSING"
    rank = max(
        (item["payload"]["first_seen_at"], item["row"]["upstream_captured_at"] or "", item["row"]["raw_payload_hash"])
        for item in parsed
    )
    winners = [
        item for item in parsed
        if (item["payload"]["first_seen_at"], item["row"]["upstream_captured_at"] or "", item["row"]["raw_payload_hash"]) == rank
    ]
    if len({canonical(item["payload"]) for item in winners}) != 1:
        return None, "FORECAST_D0_CONFLICT"
    return winners[0], None


def evidence_observations(connection: sqlite3.Connection, start: datetime, end: datetime, visible_by: datetime) -> list[dict[str, object]]:
    layout = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    if "evidence_events" in layout:
        rows = connection.execute(
        """
        SELECT e.event_at, e.recorder_first_observed_at, e.raw_payload_hash, r.payload_json
        FROM evidence_events e JOIN raw_payloads r ON r.payload_hash = e.raw_payload_hash
        WHERE e.dimension = 'metar_path' AND e.source = 'aviationweather_metar'
          AND e.city = ? AND e.station = ? AND e.grade = 'native_strict_asof'
          AND e.event_at >= ? AND e.event_at < ?
        ORDER BY e.event_at ASC, e.raw_payload_hash ASC
        """,
            (CITY, STATION, iso_z(start), iso_z(end)),
        ).fetchall()
        raw = [{"event_at": row["event_at"], "recorder_first_observed_at": row["recorder_first_observed_at"], "raw_payload_hash": row["raw_payload_hash"], "payload_json": row["payload_json"]} for row in rows]
    else:
        rows = connection.execute("SELECT source_event_time, observed_at_utc, content_sha256, payload_json FROM evidence_records WHERE source_table = 'metar_observations'").fetchall()
        raw = [{"event_at": row["source_event_time"], "recorder_first_observed_at": row["observed_at_utc"], "raw_payload_hash": row["content_sha256"], "payload_json": row["payload_json"]} for row in rows]
    unique: dict[str, dict[str, object]] = {}
    for row in raw:
        payload = json.loads(row["payload_json"])
        received_at = payload.get("received_at")
        report_time = payload.get("report_time")
        if payload.get("city") != CITY or payload.get("station") != STATION or not isinstance(report_time, str) or parse_utc(report_time) != parse_utc(row["event_at"]) or payload.get("temperature_c") is None or not isinstance(received_at, str) or parse_utc(report_time) < start or parse_utc(report_time) >= end or parse_utc(received_at) > visible_by:
            continue
        raw_hash = payload.get("raw_hash")
        if not isinstance(raw_hash, str):
            continue
        unique.setdefault(
            raw_hash,
            {
                "observation_id": payload.get("observation_id"),
                "report_time": payload["report_time"],
                "received_at": received_at,
                "temperature_c": payload["temperature_c"],
                "raw_hash": raw_hash,
                "recorder_first_observed_at": row["recorder_first_observed_at"],
            },
        )
    return [unique[key] for key in sorted(unique, key=lambda key: (unique[key]["report_time"], key))]


def recovered_evidence_entry(root: Path, target: date) -> dict[str, object]:
    start, anchor, end = local_day_window(target)
    freeze = label_freeze(target)
    anchor_path = evidence_snapshot_path(root, target)
    label_path = evidence_snapshot_path(root, target + timedelta(days=2))
    base = {
        "target_date": target.isoformat(),
        "status": "UNPROVABLE",
        "reason": None,
        "decision_as_of_utc": iso_z(anchor),
        "forecast_high_c": None,
        "current_observed_max_c": None,
        "label_final_max_c": None,
        "label_available_at_utc": iso_z(freeze),
        "source_refs": [],
        "asof_checks": {
            "source_kind": "ASOF_EVIDENCE_CAPTURE",
            "anchor_snapshot_path": str(anchor_path.relative_to(root).as_posix()) if anchor_path else None,
            "label_snapshot_path": str(label_path.relative_to(root).as_posix()) if label_path else None,
            "anchor_observation_visible_by_utc": iso_z(anchor),
            "label_freeze_at_utc": iso_z(freeze),
            "gap_limit_seconds": GAP_LIMIT_SECONDS,
        },
    }
    if not anchor_path:
        base.update(status="MISSING", reason="ASOF_ANCHOR_SNAPSHOT_MISSING")
        return base
    if not label_path:
        base.update(status="UNPROVABLE", reason="LABEL_FREEZE_SNAPSHOT_MISSING")
        return base
    with read_only_connection(anchor_path) as anchor_db, read_only_connection(label_path) as label_db:
        forecast, forecast_error = evidence_forecast(anchor_db, target, anchor)
        if forecast_error == "FORECAST_D0_CONFLICT":
            base.update(status="CONFLICT", reason=forecast_error)
            return base
        if forecast is None:
            base.update(status="MISSING", reason=forecast_error)
            return base
        row, payload = forecast["row"], forecast["payload"]
        base["forecast_high_c"] = decimal_text(payload["forecast_high_c"])
        base["source_refs"].append(
            {
                "kind": "asof_evidence_forecast",
                "path": str(anchor_path.relative_to(root).as_posix()),
                "source": SOURCE,
                "city": CITY,
                "station": STATION,
                "target_date": target.isoformat(),
                "source_reported_at": row["source_reported_at"],
                "upstream_captured_at": row["upstream_captured_at"],
                "recorder_first_observed_at": row["recorder_first_observed_at"],
                "raw_payload_hash": row["raw_payload_hash"],
                "source_revision_id": payload.get("version_id"),
                "source_content_hash": payload.get("content_hash"),
            }
        )
        anchor_rows = evidence_observations(anchor_db, start, anchor, anchor)
        anchor_ids, anchor_hash = observation_identity(anchor_rows)
        base["asof_checks"].update(
            forecast_source_first_seen_at=payload["first_seen_at"],
            anchor_observation_count=len(anchor_rows),
            anchor_observation_fact_ids=anchor_ids,
            anchor_observation_set_hash=anchor_hash,
        )
        if not anchor_rows:
            base.update(status="MISSING", reason="CURRENT_OBSERVATION_AT_ANCHOR_MISSING")
            return base
        base["current_observed_max_c"] = decimal_text(max(Decimal(str(item["temperature_c"])) for item in anchor_rows))
        label_rows = evidence_observations(label_db, start, end, freeze)
    complete, gap = coverage_complete(label_rows, start, end)
    label_ids, label_hash = observation_identity(label_rows)
    base["asof_checks"].update(
        label_observation_count=len(label_rows),
        label_observation_fact_ids=label_ids,
        label_observation_set_hash=label_hash,
        label_maximum_gap_seconds=gap,
    )
    if not complete:
        base.update(status="MISSING", reason="LABEL_OBSERVATION_COVERAGE_INCOMPLETE")
        return base
    base.update(status="AVAILABLE", reason="RECOVERED_ASOF_WEATHER_FACTS", label_final_max_c=decimal_text(max(Decimal(str(item["temperature_c"])) for item in label_rows)))
    return base


def choose_sources(root: Path, target: date, archive_cutoff: datetime, active_cutoff: datetime) -> tuple[str, Path, Path, datetime]:
    archive_root = root / "data" / "evidence_archive" / "be05_historical_rescue_20260731_20260813_v1"
    if target <= date(2026, 8, 14):
        return "ARCHIVE_BE05_HISTORICAL_RESCUE", archive_root / "research.sqlite3", archive_root / "observations.sqlite3", archive_cutoff
    return "ACTIVE_RESEARCH_STORE", root / "data" / "research.sqlite3", root / "data" / "observations.sqlite3", active_cutoff


def build(root: Path, output: Path) -> dict[str, object]:
    dataset_path = root / "data" / "strategy_analysis" / "wp03_stage0_5_research_dataset_v1" / "research_dataset_v1.json"
    manifest_path = dataset_path.with_name("DATASET_MANIFEST_V1.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest_hash = manifest["dataset_manifest_hash"]
    frozen, frozen_document = load_existing_days(dataset_path)
    archive_root = root / "data" / "evidence_archive" / "be05_historical_rescue_20260731_20260813_v1"
    builder_as_of = datetime.now(timezone.utc)
    with read_only_connection(archive_root / "observations.sqlite3") as archive_obs, read_only_connection(root / "data" / "observations.sqlite3") as active_obs:
        archive_waterline_text = source_waterline(archive_obs)
        active_waterline_text = source_waterline(active_obs)
    if not archive_waterline_text or not active_waterline_text:
        raise ValueError("required source waterline is missing")
    archive_cutoff = parse_utc(archive_waterline_text)
    active_cutoff = parse_utc(active_waterline_text)
    with read_only_connection(root / "data" / "research.sqlite3") as active_research:
        bounds = active_research.execute(
            """
            SELECT MIN(target_date), MAX(target_date)
            FROM forecast_d0_registry
            WHERE source = ? AND city = ? AND station = ? AND status = 'valid_d0'
            """,
            (SOURCE, CITY, STATION),
        ).fetchone()
    if not bounds[0] or not bounds[1]:
        raise ValueError("no active weatherol valid_d0 range")
    first, last = date.fromisoformat(bounds[0]), date.fromisoformat(bounds[1])
    candidate_days: list[dict[str, object]] = []
    target = first
    while target <= last:
        target_text = target.isoformat()
        if target_text in frozen:
            entry = frozen_entry(target_text, frozen[target_text], dataset_path.relative_to(root), manifest_hash)
        elif date(2026, 8, 14) <= target <= date(2026, 8, 21):
            entry = recovered_evidence_entry(root, target)
        else:
            source_name, research_path, observations_path, source_cutoff = choose_sources(root, target, archive_cutoff, active_cutoff)
            with read_only_connection(research_path) as research, read_only_connection(observations_path) as obs:
                entry = recovered_entry(target, source_name, research, obs, source_cutoff, builder_as_of)
        if entry["status"] not in STATUSES:
            raise ValueError(f"invalid population status for {target_text}")
        candidate_days.append(entry)
        target += timedelta(days=1)
    counts = Counter(entry["status"] for entry in candidate_days)
    result = {
        "schema_version": "WP03_STAGE1A_FAST_WEATHER_POPULATION_V1",
        "population_id": "P_SH_STAGE1A_FAST_WEATHER_0800_V1",
        "purpose": "RESEARCH_VALIDATION_ONLY",
        "production_iic2_unchanged": True,
        "city": CITY,
        "station": STATION,
        "decision_anchor": "08:00 Asia/Shanghai",
        "builder_as_of_utc": iso_z(builder_as_of),
        "source_waterlines": {
            "ARCHIVE_BE05_HISTORICAL_RESCUE": {
                "path": "data/evidence_archive/be05_historical_rescue_20260731_20260813_v1/observations.sqlite3",
                "visible_record_waterline_utc": archive_waterline_text,
                "scope": "preservation_only_not_v3_eligibility",
            },
            "ACTIVE_RESEARCH_STORE": {
                "path": "data/observations.sqlite3",
                "visible_record_waterline_utc": active_waterline_text,
                "scope": "current_store_read_only_snapshot",
            },
        },
        "frozen_input": {
            "path": str(dataset_path.relative_to(root).as_posix()),
            "population_id": frozen_document["population_id"],
            "dataset_manifest_hash": manifest_hash,
            "date_range": frozen_document["date_range"],
        },
        "candidate_date_range": {"start": first.isoformat(), "end": last.isoformat()},
        "candidate_days": candidate_days,
        "counts": {status: counts.get(status, 0) for status in STATUSES},
    }
    result["population_payload_hash"] = digest({key: value for key, value in result.items() if key != "builder_as_of_utc"})
    return result


def write_artifacts(result: dict[str, object], output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    (output / "population.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    fields = [
        "target_date", "status", "reason", "decision_as_of_utc", "forecast_high_c", "current_observed_max_c",
        "label_final_max_c", "label_available_at_utc", "source_refs", "asof_checks",
    ]
    with (output / "population.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for entry in result["candidate_days"]:
            writer.writerow({**entry, "source_refs": canonical(entry["source_refs"]), "asof_checks": canonical(entry["asof_checks"])})
    counts = result["counts"]
    lines = [
        "# Stage1A Shanghai fast-weather population",
        "",
        f"- population: `{result['population_id']}`",
        "- purpose: `RESEARCH_VALIDATION_ONLY`; not IIC2, Edge, return, or trading evidence.",
        f"- decision anchor: `{result['decision_anchor']}`",
        f"- candidate range: `{result['candidate_date_range']['start']}` .. `{result['candidate_date_range']['end']}`",
        f"- builder AS-OF: `{result['builder_as_of_utc']}`",
        f"- payload hash (excludes builder clock): `{result['population_payload_hash']}`",
        "",
        "| status | days |",
        "|---|---:|",
    ]
    lines.extend(f"| {status} | {counts[status]} |" for status in STATUSES)
    lines.extend([
        "",
        "Each candidate remains in `population.json` and `population.csv`. `null` means unknown; no unknown weather value is replaced with zero.",
        "Archive record times are retained as source facts. Archive recovery time is not used as historical visibility proof.",
    ])
    (output / "data_population_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    default_output = root / "data" / "strategy_analysis" / "wp03_stage1a_fast_weather_signal_v1" / "20260905T165620+0800"
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=default_output)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    allowed = (root / "data" / "strategy_analysis" / "wp03_stage1a_fast_weather_signal_v1" / "20260905T165620+0800").resolve()
    if output != allowed:
        raise ValueError("output_dir must be the authorized Stage1A run directory")
    write_artifacts(build(root, output), output)
    print(canonical({"output_dir": str(output), "status": "BUILT"}))


if __name__ == "__main__":
    main()
