from __future__ import annotations

from decimal import Decimal
from fractions import Fraction
from typing import Sequence


ZERO = Decimal("0")
ONE = Decimal("1")
TOTAL_TICKS = 10**12
RESEARCH_QUANTIZATION_POLICY = "STAGE1A_LARGEST_REMAINDER_E12_V1"


def largest_remainder_e12(raw: Sequence[Fraction]) -> tuple[tuple[Decimal, ...], dict[str, object]]:
    if len(raw) != 52 or any(not isinstance(value, Fraction) for value in raw) or any(value < 0 for value in raw) or sum(raw, Fraction(0, 1)) != Fraction(1, 1):
        raise ValueError("raw probability vector must be nonnegative and sum exactly to one")
    scaled = [value * TOTAL_TICKS for value in raw]
    ticks = [value.numerator // value.denominator for value in scaled]
    remaining = TOTAL_TICKS - sum(ticks)
    for ordinal in sorted(range(len(raw)), key=lambda index: (-(scaled[index] - ticks[index]), index))[:remaining]:
        ticks[ordinal] += 1
    if sum(ticks) != TOTAL_TICKS or any(value < 0 for value in ticks):
        raise ValueError("quantized probability vector is invalid")
    values = tuple(Decimal(value) / Decimal(TOTAL_TICKS) for value in ticks)
    return values, {
        "research_quantization_policy_id": RESEARCH_QUANTIZATION_POLICY,
        "total_ticks": TOTAL_TICKS,
        "per_bucket_ticks": ticks,
        "raw_probability_vector": [{"numerator": value.numerator, "denominator": value.denominator} for value in raw],
        "research_quantized_probability_vector": [str(value) for value in values],
        "quantization_delta_per_bucket": [{"numerator": ticks[index] * raw[index].denominator - TOTAL_TICKS * raw[index].numerator, "denominator": TOTAL_TICKS * raw[index].denominator} for index in range(len(raw))],
    }


def mean(values: Sequence[Decimal]) -> Decimal:
    if not values:
        raise ValueError("mean requires at least one value")
    return sum(values, ZERO) / Decimal(len(values))


def brier_score(probabilities: Sequence[Decimal], target_index: int) -> Decimal:
    if not 0 <= target_index < len(probabilities):
        raise ValueError("target index is outside the probability vector")
    if any(value < ZERO or value > ONE for value in probabilities) or sum(probabilities, ZERO) != ONE:
        raise ValueError("probability vector is invalid")
    return sum((value - (ONE if index == target_index else ZERO)) ** 2 for index, value in enumerate(probabilities))


def removal_mean(improvements: Sequence[tuple[str, Decimal]], removed: int, *, largest: bool) -> Decimal | None:
    if len(improvements) <= removed:
        return None
    ordered = sorted(improvements, key=lambda item: ((-item[1]) if largest else item[1], item[0]))
    return mean([value for _, value in ordered[removed:]])
