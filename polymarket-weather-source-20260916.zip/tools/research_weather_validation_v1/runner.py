from __future__ import annotations

import argparse
import csv
import json
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from decimal import Decimal, InvalidOperation
from fractions import Fraction
from pathlib import Path
from typing import Any, Iterable, Sequence

from strategy_engine.models.residual import TemperatureBucket, TrainingSample, validate_bucket_partition
from strategy_engine.data.records import decimal_text
from strategy_v8.contracts import City
from zoneinfo import ZoneInfo

from .metrics import brier_score, largest_remainder_e12, mean, removal_mean


RUN_ROOT = Path("data/strategy_analysis/wp03_stage1a_fast_weather_signal_v1/20260905T165620+0800/implementation").resolve()
RUN_SCOPE = RUN_ROOT.parent
ZERO = Decimal("0")
ONE = Decimal("1")


@dataclass(frozen=True)
class ResearchTrainingRecord:
    target_date: date
    forecast_high_c: Decimal
    label_final_max_c: Decimal
    label_available_at_utc: datetime
    city: City = City.SHANGHAI
    local_second: int = 28_800

    @property
    def final_max_c(self) -> Decimal:
        return self.label_final_max_c

    @property
    def residual_c(self) -> Decimal:
        return TrainingSample.residual_c.fget(self)  # type: ignore[arg-type]


@dataclass(frozen=True)
class ResearchPredictionInputs:
    target_date: date
    forecast_high_c: Decimal
    current_observed_max_c: Decimal
    decision_as_of_utc: str
    city: City = City.SHANGHAI
    local_second: int = 28_800


@dataclass(frozen=True)
class ResearchModelState:
    city: City
    local_second: int
    feature_version: str
    residuals: tuple[Decimal, ...]


@dataclass(frozen=True)
class ResearchPredictionDay:
    city: City
    target_date: date
    local_second: int
    forecast_high_c: Decimal
    current_observed_max_c: Decimal
    as_of_utc: str


@dataclass(frozen=True)
class ResearchWeatherFeatures:
    city: City
    as_of_utc: str
    feature_version: str


def research_weather_buckets() -> tuple[TemperatureBucket, ...]:
    buckets = [TemperatureBucket("LT_0", None, Decimal("0"))]
    buckets.extend(TemperatureBucket(f"C_{value}_{value + 1}", Decimal(value), Decimal(value + 1)) for value in range(50))
    buckets.append(TemperatureBucket("GTE_50", Decimal("50"), None))
    return validate_bucket_partition(buckets)


def bucket_index(value: Decimal, buckets: Sequence[TemperatureBucket]) -> int:
    matches = [index for index, bucket in enumerate(buckets) if bucket.contains(value)]
    if len(matches) != 1:
        raise ValueError("temperature must map to exactly one research bucket")
    return matches[0]


def research_probability_from_samples(samples: Iterable[Decimal], buckets: Sequence[TemperatureBucket]) -> tuple[tuple[Decimal, ...], dict[str, object]]:
    values = tuple(samples)
    if not values:
        raise ValueError("at least one sample is required")
    counts = [0] * len(buckets)
    for value in values:
        counts[bucket_index(value, buckets)] += 1
    return largest_remainder_e12(tuple(Fraction(count, len(values)) for count in counts))


def probability_from_samples(samples: Iterable[Decimal], buckets: Sequence[TemperatureBucket]) -> tuple[Decimal, ...]:
    return research_probability_from_samples(samples, buckets)[0]


def predict_research_weather(
    inputs: ResearchPredictionInputs,
    residuals: Iterable[Decimal],
    buckets: Sequence[TemperatureBucket],
) -> tuple[tuple[Decimal, ...], Decimal]:
    """Adapt research-only fields to the existing pure candidate calculation."""
    temperature_samples = tuple(max(inputs.current_observed_max_c, inputs.forecast_high_c + residual) for residual in residuals)
    return probability_from_samples(temperature_samples, buckets), mean(temperature_samples)


def _utc(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _decimal(value: Any, field: str) -> Decimal:
    if isinstance(value, bool) or value is None:
        raise ValueError(f"{field} is required")
    result = Decimal(str(value))
    if not result.is_finite() or result * Decimal(1000) != (result * Decimal(1000)).to_integral_value():
        raise ValueError(f"{field} must be finite with milli-Celsius precision")
    return result


def _finite_decimal(value: Any, field: str) -> Decimal:
    if isinstance(value, bool) or value is None:
        raise ValueError(f"{field} is required")
    result = Decimal(str(value))
    if not result.is_finite():
        raise ValueError(f"{field} must be finite")
    return result


def _row_to_training(row: dict[str, Any]) -> ResearchTrainingRecord:
    return ResearchTrainingRecord(
        target_date=date.fromisoformat(row["target_date"]),
        forecast_high_c=_decimal(row.get("forecast_high_c"), "forecast_high_c"),
        label_final_max_c=_decimal(row.get("label_final_max_c"), "label_final_max_c"),
        label_available_at_utc=_utc(row["label_available_at_utc"]),
    )


def _d_plus_2_freeze(target: date) -> datetime:
    return datetime.combine(target + timedelta(days=2), time.min, tzinfo=ZoneInfo("Asia/Shanghai"))


def _validate_research_identity(row: dict[str, Any], target: date, decision_asof: datetime) -> None:
    local = decision_asof.astimezone(ZoneInfo("Asia/Shanghai"))
    if local.date() != target or local.time() != time(8, 0):
        raise ValueError("decision_as_of_utc must be target-date 08:00 Asia/Shanghai")
    if row.get("city") not in (None, "Shanghai") or row.get("station") not in (None, "ZSPD"):
        raise ValueError("research input city/station must be Shanghai/ZSPD")


def _validate_population(payload: dict[str, Any]) -> tuple[dict[str, Any], ...]:
    if not isinstance(payload.get("candidate_days"), list):
        raise ValueError("population candidate_days must be a list")
    rows = tuple(payload["candidate_days"])
    if any(not isinstance(row, dict) for row in rows):
        raise ValueError("population candidate must be an object")
    dates = [row.get("target_date") for row in rows]
    if any(not isinstance(value, str) for value in dates) or len(set(dates)) != len(dates):
        raise ValueError("population requires one unique target_date per candidate")
    return tuple(sorted(rows, key=lambda row: row["target_date"]))


def _output_row(row: dict[str, Any], training_dates: Sequence[str], status: str, reason: str | None) -> dict[str, Any]:
    return {
        "target_date": row["target_date"],
        "source_status": row.get("status"),
        "status": status,
        "reason": reason,
        "decision_as_of_utc": row.get("decision_as_of_utc"),
        "training_dates": list(training_dates),
        "training_count": len(training_dates),
        "research_semantics": "RESEARCH_ONLY_NOT_IIC2",
        "iic2_identity_validated": False,
        "log_loss": "NOT_PRE_REGISTERED",
    }


def _summary(candidate_count: int, scored: Sequence[tuple[str, Decimal, Decimal, Decimal, Decimal]], invalid_rows: bool, failure_dates: Iterable[str] = ()) -> dict[str, Any]:
    improvements = [(target, baseline - model) for target, model, baseline, _, _ in scored]
    summary: dict[str, Any] = {
        "candidate_count": candidate_count,
        "scored_count": len(scored),
        "log_loss": "NOT_PRE_REGISTERED",
        "brier_mean_model": None,
        "brier_mean_baseline": None,
        "brier_mean_difference": None,
        "brier_mean_after_remove_largest_improvement_1": None,
        "brier_mean_after_remove_largest_improvement_2": None,
        "brier_mean_after_remove_worst_improvement_1": None,
        "brier_mean_after_remove_worst_improvement_2": None,
        "mae_model": None,
        "mae_baseline": None,
        "early_signal": "INCONCLUSIVE_EARLY_SIGNAL",
        "computation_failure_days": sorted(set(failure_dates)),
        "computation_failure_day_count": len(set(failure_dates)),
    }
    if not scored:
        return summary
    model_briers = [item[1] for item in scored]
    baseline_briers = [item[2] for item in scored]
    model_maes = [item[3] for item in scored]
    baseline_maes = [item[4] for item in scored]
    difference = mean([baseline - model for model, baseline in zip(model_briers, baseline_briers)])
    top_1 = removal_mean(improvements, 1, largest=True)
    top_2 = removal_mean(improvements, 2, largest=True)
    worst_1 = removal_mean(improvements, 1, largest=False)
    worst_2 = removal_mean(improvements, 2, largest=False)
    summary.update(
        {
            "brier_mean_model": decimal_text(mean(model_briers)),
            "brier_mean_baseline": decimal_text(mean(baseline_briers)),
            "brier_mean_difference": decimal_text(difference),
            "brier_mean_after_remove_largest_improvement_1": None if top_1 is None else decimal_text(top_1),
            "brier_mean_after_remove_largest_improvement_2": None if top_2 is None else decimal_text(top_2),
            "brier_mean_after_remove_worst_improvement_1": None if worst_1 is None else decimal_text(worst_1),
            "brier_mean_after_remove_worst_improvement_2": None if worst_2 is None else decimal_text(worst_2),
            "mae_model": decimal_text(mean(model_maes)),
            "mae_baseline": decimal_text(mean(baseline_maes)),
        }
    )
    mae_difference = mean(baseline_maes) - mean(model_maes)
    if not invalid_rows and len(scored) >= 3 and difference > ZERO and top_1 is not None and top_2 is not None and top_1 > ZERO and top_2 > ZERO and mae_difference > ZERO:
        summary["early_signal"] = "POSITIVE_EARLY_SIGNAL"
    elif not invalid_rows and len(scored) >= 3 and difference < ZERO and worst_1 is not None and worst_2 is not None and worst_1 < ZERO and worst_2 < ZERO and mae_difference < ZERO:
        summary["early_signal"] = "NEGATIVE_EARLY_SIGNAL"
    return summary


def run_population(payload: dict[str, Any], *, connect_labels: bool = True) -> dict[str, Any]:
    """Produce all candidate rows before connecting a target label for scoring."""
    rows = _validate_population(payload)
    buckets = research_weather_buckets()
    output_rows: list[dict[str, Any]] = []
    scored: list[tuple[str, Decimal, Decimal, Decimal, Decimal]] = []

    for row in rows:
        target_date = date.fromisoformat(row["target_date"])
        source_status = row.get("status")
        if source_status != "AVAILABLE":
            output_rows.append(_output_row(row, (), source_status or "UNPROVABLE", row.get("reason") or "source status is not AVAILABLE"))
            continue
        result: dict[str, Any] | None = None
        try:
            decision_asof = _utc(row["decision_as_of_utc"])
            _validate_research_identity(row, target_date, decision_asof)
            training = tuple(
                _row_to_training(previous)
                for previous in rows
                if previous.get("status") == "AVAILABLE"
                and date.fromisoformat(previous["target_date"]) < target_date
                and previous.get("label_available_at_utc") is not None
                and _utc(previous["label_available_at_utc"]) <= decision_asof
                and _d_plus_2_freeze(date.fromisoformat(previous["target_date"])) <= decision_asof
            )
            training_dates = tuple(item.target_date.isoformat() for item in training)
            result = _output_row(row, training_dates, "INSUFFICIENT_PRIOR_TRAINING_DATA", None)
            if not training:
                output_rows.append(result)
                continue

            inputs = ResearchPredictionInputs(
                target_date=target_date,
                forecast_high_c=_decimal(row.get("forecast_high_c"), "forecast_high_c"),
                current_observed_max_c=_decimal(row.get("current_observed_max_c"), "current_observed_max_c"),
                decision_as_of_utc=row["decision_as_of_utc"],
            )
            model_samples = tuple(max(inputs.current_observed_max_c, inputs.forecast_high_c + item.residual_c) for item in training)
            model_probabilities, model_quantization = research_probability_from_samples(model_samples, buckets)
            model_mean = mean(model_samples)
            result.update(
                {
                    "status": "PREDICTION_SAVED_AWAITING_LABEL",
                    "model_probabilities": [decimal_text(value) for value in model_probabilities],
                    "model_temperature_mean_c": decimal_text(model_mean),
                    "bucket_ids": [bucket.bucket_id for bucket in buckets],
                    "candidate_calculation": "RESEARCH_RESIDUAL_SAMPLE_COUNTING",
                    "model_quantization": model_quantization,
                }
            )

            baseline_probabilities, baseline_quantization = research_probability_from_samples((item.label_final_max_c for item in training), buckets)
            baseline_mean = mean([item.label_final_max_c for item in training])
            result.update(
                {
                    "baseline_probabilities": [decimal_text(value) for value in baseline_probabilities],
                    "baseline_temperature_mean_c": decimal_text(baseline_mean),
                    "baseline_quantization": baseline_quantization,
                }
            )

            if not connect_labels:
                output_rows.append(result)
                continue
            label = _decimal(row.get("label_final_max_c"), "label_final_max_c")
            target_index = bucket_index(label, buckets)
            model_brier = brier_score(model_probabilities, target_index)
            baseline_brier = brier_score(baseline_probabilities, target_index)
            result.update(
                {
                    "status": "SCORED",
                    "model_brier": decimal_text(model_brier),
                    "baseline_brier": decimal_text(baseline_brier),
                    "model_absolute_error": decimal_text(abs(model_mean - label)),
                    "baseline_absolute_error": decimal_text(abs(baseline_mean - label)),
                    "actual_label_final_max_c": decimal_text(label),
                    "candidate_prediction_probabilities": [decimal_text(value) for value in model_probabilities],
                    "baseline_prediction_probabilities": [decimal_text(value) for value in baseline_probabilities],
                    "candidate_prediction_mean_c": decimal_text(model_mean),
                    "baseline_prediction_mean_c": decimal_text(baseline_mean),
                    "candidate_loss_brier": decimal_text(model_brier),
                    "baseline_loss_brier": decimal_text(baseline_brier),
                }
            )
            scored.append((row["target_date"], model_brier, baseline_brier, abs(model_mean - label), abs(baseline_mean - label)))
            output_rows.append(result)
        except (InvalidOperation, KeyError, ValueError, TypeError) as exc:
            if result is not None:
                if result.get("status") == "PREDICTION_SAVED_AWAITING_LABEL":
                    result.update({"reason": str(exc), "evaluation_status": "INPUT_OR_COMPUTATION_FAILURE", "evaluation_error": str(exc)})
                else:
                    result.update({"status": "INPUT_OR_COMPUTATION_FAILURE", "reason": str(exc), "evaluation_status": "INPUT_OR_COMPUTATION_FAILURE", "evaluation_error": str(exc)})
                output_rows.append(result)
            else:
                output_rows.append(_output_row(row, (), "INPUT_OR_COMPUTATION_FAILURE", str(exc)))

    failures = {item["target_date"] for item in output_rows if item.get("status") == "INPUT_OR_COMPUTATION_FAILURE" or item.get("evaluation_status") == "INPUT_OR_COMPUTATION_FAILURE"}
    summary = _summary(len(rows), scored, bool(failures), failures)
    return {"research_semantics": "RESEARCH_ONLY_NOT_IIC2", "bucket_ids": [bucket.bucket_id for bucket in buckets], "rows": output_rows, "summary": summary}


def _stored_probabilities(row: dict[str, Any], field: str, bucket_count: int) -> tuple[Decimal, ...]:
    raw_values = row.get(field)
    if not isinstance(raw_values, list) or len(raw_values) != bucket_count:
        raise ValueError(f"{field} is missing or has an invalid length")
    values = tuple(Decimal(str(value)) for value in raw_values)
    if any(not value.is_finite() for value in values):
        raise ValueError(f"{field} contains a non-finite value")
    return values


def score_saved_predictions(predictions: dict[str, Any], population: dict[str, Any]) -> dict[str, Any]:
    """Read saved predictions and append evaluation fields without predicting again."""
    saved_rows = predictions.get("rows")
    if not isinstance(saved_rows, list):
        raise ValueError("saved predictions rows must be a list")
    labels = {row["target_date"]: row for row in _validate_population(population)}
    buckets = research_weather_buckets()
    output_rows: list[dict[str, Any]] = []
    scored_count = 0
    scored: list[tuple[str, Decimal, Decimal, Decimal, Decimal]] = []
    for saved in saved_rows:
        if not isinstance(saved, dict):
            raise ValueError("saved prediction row must be an object")
        output = dict(saved)
        if saved.get("evaluation_status") == "INPUT_OR_COMPUTATION_FAILURE":
            output_rows.append(output)
            continue
        if saved.get("status") != "PREDICTION_SAVED_AWAITING_LABEL":
            if saved.get("status") not in {"INSUFFICIENT_PRIOR_TRAINING_DATA", "MISSING", "CONFLICT", "UNPROVABLE", "INPUT_OR_COMPUTATION_FAILURE"}:
                output.update({"evaluation_status": "INPUT_OR_COMPUTATION_FAILURE", "evaluation_error": "saved prediction status is missing or unsupported"})
            output_rows.append(output)
            continue
        try:
            source = labels[saved["target_date"]]
            label = _decimal(source.get("label_final_max_c"), "label_final_max_c")
            model = _stored_probabilities(saved, "model_probabilities", len(buckets))
            baseline = _stored_probabilities(saved, "baseline_probabilities", len(buckets))
            target_index = bucket_index(label, buckets)
            model_brier = brier_score(model, target_index)
            baseline_brier = brier_score(baseline, target_index)
            model_mean = _finite_decimal(saved.get("model_temperature_mean_c"), "model_temperature_mean_c")
            baseline_mean = _finite_decimal(saved.get("baseline_temperature_mean_c"), "baseline_temperature_mean_c")
            output.update(
                {
                    "evaluation_status": "SCORED",
                    "actual_label_final_max_c": decimal_text(label),
                    "candidate_loss_brier": decimal_text(model_brier),
                    "baseline_loss_brier": decimal_text(baseline_brier),
                    "candidate_absolute_error": decimal_text(abs(model_mean - label)),
                    "baseline_absolute_error": decimal_text(abs(baseline_mean - label)),
                }
            )
            scored_count += 1
            scored.append((saved["target_date"], model_brier, baseline_brier, abs(model_mean - label), abs(baseline_mean - label)))
        except (InvalidOperation, KeyError, TypeError, ValueError) as exc:
            output.update({"evaluation_status": "INPUT_OR_COMPUTATION_FAILURE", "evaluation_error": str(exc)})
        output_rows.append(output)
    return {
        "research_semantics": predictions.get("research_semantics"),
        "bucket_ids": predictions.get("bucket_ids"),
        "rows": output_rows,
        "summary": _summary(len(saved_rows), scored, any(item.get("status") == "INPUT_OR_COMPUTATION_FAILURE" or item.get("evaluation_status") == "INPUT_OR_COMPUTATION_FAILURE" for item in output_rows), {item["target_date"] for item in output_rows if item.get("status") == "INPUT_OR_COMPUTATION_FAILURE" or item.get("evaluation_status") == "INPUT_OR_COMPUTATION_FAILURE"}),
        "evaluation_summary": {"scored_count": scored_count, "log_loss": "NOT_PRE_REGISTERED"},
    }


def score_saved_prediction_file(predictions_path: Path, population: dict[str, Any]) -> dict[str, Any]:
    return score_saved_predictions(json.loads(predictions_path.read_text(encoding="utf-8")), population)


def write_run(payload: dict[str, Any], output_dir: Path) -> dict[str, Any]:
    output_dir = output_dir.resolve()
    if RUN_SCOPE not in output_dir.parents and output_dir != RUN_SCOPE:
        raise ValueError("output directory must remain within the authorized run scope")
    output_dir.mkdir(parents=True, exist_ok=True)
    predictions = run_population(payload, connect_labels=False)
    predictions_path = output_dir / "predictions.json"
    predictions_path.write_text(json.dumps(predictions, ensure_ascii=False, indent=2), encoding="utf-8")
    result = score_saved_prediction_file(predictions_path, payload)
    (output_dir / "stage1a_results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with (output_dir / "stage1a_daily.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["target_date", "source_status", "status", "reason", "training_count", "training_dates", "model_probabilities", "baseline_probabilities", "model_temperature_mean_c", "baseline_temperature_mean_c", "actual_label_final_max_c", "evaluation_status", "evaluation_error", "candidate_loss_brier", "baseline_loss_brier", "candidate_absolute_error", "baseline_absolute_error"])
        writer.writeheader()
        for row in result["rows"]:
            writer.writerow({key: json.dumps(value) if isinstance(value, list) else row.get(key) for key, value in ((key, row.get(key)) for key in writer.fieldnames)})
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Research-only Stage1A weather validation runner")
    parser.add_argument("population_json", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    payload = json.loads(args.population_json.read_text(encoding="utf-8"))
    write_run(payload, args.output_dir)


if __name__ == "__main__":
    main()
