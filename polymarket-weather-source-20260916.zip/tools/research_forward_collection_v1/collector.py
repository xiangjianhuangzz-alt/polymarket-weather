"""Append-only, offline-only complete YES-ladder capture records.

This module deliberately has no network client, scheduler, service entrypoint,
database dependency, or automatic retention/deletion behavior.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, InvalidOperation
from enum import Enum
from hashlib import sha256
import json
from pathlib import Path
from typing import Iterable


UTC = timezone.utc
SHANGHAI = timezone(timedelta(hours=8), "Asia/Shanghai")
EXPECTED_CITY = "Shanghai"
EXPECTED_MARKET_FAMILY = "POLYMARKET_TEMPERATURE"
EXPECTED_PARTITION_SOURCE = "PUBLISHED_UNIVERSE_V1"


class CaptureMode(str, Enum):
    OFFLINE_TEST = "OFFLINE_TEST"
    CAPTURE_ONCE = "CAPTURE_ONCE"
    CONTINUOUS_COLLECTION = "CONTINUOUS_COLLECTION"


class CaptureStatus(str, Enum):
    ACCEPTED = "ACCEPTED"
    REJECTED_MODE = "REJECTED_MODE"
    REJECTED_BBO = "REJECTED_BBO"
    REJECTED_HEARTBEAT = "REJECTED_HEARTBEAT"
    REJECTED_PARTIAL = "REJECTED_PARTIAL"
    REJECTED_INCONSISTENT = "REJECTED_INCONSISTENT"
    REJECTED_MISSING = "REJECTED_MISSING"
    REJECTED_FUTURE = "REJECTED_FUTURE"
    REJECTED_STALE = "REJECTED_STALE"
    DUPLICATE_SAME_PAYLOAD = "DUPLICATE_SAME_PAYLOAD"
    DUPLICATE_DIFFERENT_PAYLOAD = "DUPLICATE_DIFFERENT_PAYLOAD"


@dataclass(frozen=True, slots=True)
class YesAsk:
    price: str
    size: str


@dataclass(frozen=True, slots=True)
class FrameInput:
    source_frame_id: str
    raw_frame_bytes: bytes
    city: str
    target_date: str
    market_family: str
    partition_source: str
    market_id: str | None
    yes_token_id: str | None
    rule_hash: str | None
    captured_at_utc: str | None
    received_at_utc: str | None
    source_timestamp_utc: str | None
    first_visible_at_utc: str | None
    frame_kind: str
    complete: bool
    upstream_truncated: bool
    yes_asks: tuple[YesAsk, ...]
    requested_yes_quantity: str | None


def _utc(value: str | None) -> datetime | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError("timestamp must be an ISO UTC string or null")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() != timedelta(0):
        raise ValueError("timestamp must be UTC")
    return parsed.astimezone(UTC)


def _anchor(target_date: str) -> datetime:
    try:
        local_day = date.fromisoformat(target_date)
    except (TypeError, ValueError) as exc:
        raise ValueError("target_date must be ISO date") from exc
    return datetime.combine(local_day, time(8), SHANGHAI).astimezone(UTC)


def _json_bytes(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _execution_metrics(frame: FrameInput) -> dict[str, object]:
    """Compute requested-quantity feasibility without changing the ladder."""
    if frame.requested_yes_quantity is None:
        return {"requested_yes_quantity": None, "fillable": None, "vwap": None}
    try:
        requested = Decimal(frame.requested_yes_quantity)
        levels = tuple((Decimal(level.price), Decimal(level.size)) for level in frame.yes_asks)
    except (InvalidOperation, TypeError, ValueError):
        return {"requested_yes_quantity": frame.requested_yes_quantity, "fillable": False, "vwap": None}
    if not requested.is_finite() or requested <= 0:
        return {"requested_yes_quantity": frame.requested_yes_quantity, "fillable": False, "vwap": None}
    remaining = requested
    cost = Decimal(0)
    for price, available in levels:
        take = min(remaining, available)
        cost += take * price
        remaining -= take
        if remaining == 0:
            return {"requested_yes_quantity": str(requested), "fillable": True, "vwap": str(cost / requested)}
    return {"requested_yes_quantity": str(requested), "fillable": False, "vwap": None}


def _validation_status(frame: FrameInput) -> CaptureStatus:
    if frame.frame_kind == "BBO":
        return CaptureStatus.REJECTED_BBO
    if frame.frame_kind == "HEARTBEAT":
        return CaptureStatus.REJECTED_HEARTBEAT
    required = (frame.source_frame_id, frame.raw_frame_bytes, frame.market_id, frame.yes_token_id, frame.rule_hash, frame.captured_at_utc, frame.received_at_utc)
    if any(value is None or value == "" or value == b"" for value in required):
        return CaptureStatus.REJECTED_MISSING
    if frame.city != EXPECTED_CITY or frame.market_family != EXPECTED_MARKET_FAMILY or frame.partition_source != EXPECTED_PARTITION_SOURCE:
        return CaptureStatus.REJECTED_INCONSISTENT
    try:
        captured = _utc(frame.captured_at_utc)
        received = _utc(frame.received_at_utc)
        source = _utc(frame.source_timestamp_utc)
        first_visible = _utc(frame.first_visible_at_utc)
        anchor = _anchor(frame.target_date)
    except ValueError:
        return CaptureStatus.REJECTED_INCONSISTENT
    if captured is None or received is None:
        return CaptureStatus.REJECTED_MISSING
    if source is not None and source > received:
        return CaptureStatus.REJECTED_INCONSISTENT
    if first_visible is not None and first_visible > received:
        return CaptureStatus.REJECTED_INCONSISTENT
    if captured > anchor:
        return CaptureStatus.REJECTED_FUTURE
    if anchor - captured > timedelta(seconds=60):
        return CaptureStatus.REJECTED_STALE
    if not frame.complete or frame.upstream_truncated or frame.frame_kind != "FULL_DEPTH":
        return CaptureStatus.REJECTED_PARTIAL
    if not frame.yes_asks:
        return CaptureStatus.REJECTED_PARTIAL
    try:
        prices = [Decimal(level.price) for level in frame.yes_asks]
        sizes = [Decimal(level.size) for level in frame.yes_asks]
    except (InvalidOperation, TypeError, ValueError):
        return CaptureStatus.REJECTED_INCONSISTENT
    if any(not price.is_finite() or not size.is_finite() or price <= 0 or size <= 0 for price, size in zip(prices, sizes)) or prices != sorted(prices) or len(set(prices)) != len(prices):
        return CaptureStatus.REJECTED_INCONSISTENT
    return CaptureStatus.ACCEPTED


class CaptureStore:
    """Append-only research-file store; it contains no deletion operation."""

    def __init__(self, root: Path) -> None:
        self.root = root
        self.frames = root / "frames"
        self.frames.mkdir(parents=True, exist_ok=True)

    def append(self, frame: FrameInput, status: CaptureStatus) -> dict[str, object]:
        raw_hash = sha256(frame.raw_frame_bytes).hexdigest()
        frame_id = sha256(_json_bytes({"source_frame_id": frame.source_frame_id, "raw_payload_sha256": raw_hash})).hexdigest()
        metadata = {
            "schema_version": "ForwardResearchFrameV1",
            "frame_id": frame_id,
            "source_frame_id": frame.source_frame_id,
            "raw_payload_sha256": raw_hash,
            "city": frame.city,
            "target_date": frame.target_date,
            "market_family": frame.market_family,
            "partition_source": frame.partition_source,
            "market_id": frame.market_id,
            "yes_token_id": frame.yes_token_id,
            "rule_hash": frame.rule_hash,
            "captured_at_utc": frame.captured_at_utc,
            "received_at_utc": frame.received_at_utc,
            "source_timestamp_utc": frame.source_timestamp_utc,
            "first_visible_at_utc": frame.first_visible_at_utc,
            "frame_kind": frame.frame_kind,
            "complete": frame.complete,
            "upstream_truncated": frame.upstream_truncated,
            "yes_asks": [asdict(level) for level in frame.yes_asks],
            "execution_feasibility": _execution_metrics(frame),
            "capture_status": status.value,
            "automatic_deletion": False,
        }
        raw_path = self.frames / f"{frame_id}.raw"
        record_path = self.frames / f"{frame_id}.json"
        if record_path.exists():
            return {"frame_id": frame_id, "capture_status": CaptureStatus.DUPLICATE_SAME_PAYLOAD.value, "record_path": str(record_path)}
        same_source = list(self.frames.glob(f"*.json"))
        for prior_path in same_source:
            prior = json.loads(prior_path.read_text(encoding="utf-8"))
            if prior["source_frame_id"] == frame.source_frame_id and prior["raw_payload_sha256"] != raw_hash:
                metadata["capture_status"] = CaptureStatus.DUPLICATE_DIFFERENT_PAYLOAD.value
                break
        raw_path.write_bytes(frame.raw_frame_bytes)
        record_path.write_bytes(_json_bytes(metadata))
        with (self.root / "manifest.jsonl").open("a", encoding="utf-8", newline="\n") as manifest:
            manifest.write(json.dumps({"frame_id": frame_id, "capture_status": metadata["capture_status"], "raw_payload_sha256": raw_hash}, sort_keys=True, separators=(",", ":")) + "\n")
        return {"frame_id": frame_id, "capture_status": metadata["capture_status"], "record_path": str(record_path)}


def capture_once(mode: CaptureMode, store: CaptureStore, frames: Iterable[FrameInput]) -> tuple[dict[str, object], ...]:
    """Process supplied frames exactly once; only OFFLINE_TEST is executable."""
    if mode is not CaptureMode.OFFLINE_TEST:
        raise RuntimeError("only OFFLINE_TEST may execute capture_once")
    return tuple(store.append(frame, _validation_status(frame)) for frame in frames)
