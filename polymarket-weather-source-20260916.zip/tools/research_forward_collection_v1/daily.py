"""One bounded research invocation; public reads only, never trading or scheduling."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal
import hashlib
import importlib.metadata
import json
from pathlib import Path
import time as wall_time
import sys
from types import SimpleNamespace
from urllib.error import HTTPError
from urllib.parse import urlencode, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener
import uuid
from zoneinfo import ZoneInfo

from .collector import CaptureStore, CaptureStatus, FrameInput, YesAsk, _validation_status
from .weather_inputs import snapshot_weather, mature_label
from tools.research_weather_validation_v1 import runner

ROOT = Path(__file__).resolve().parents[2]
RESEARCH = ROOT / "data/strategy_analysis"
SHANGHAI, UTC = ZoneInfo("Asia/Shanghai"), timezone.utc
FIRST_DAY = date(2026, 9, 6)
MONTHS = "january february march april may june july august september october november december".split()


def utcnow():
    return datetime.now(UTC)


def stamp(value):
    return value.astimezone(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")


def parsed(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("TIMEZONE_REQUIRED")
    return result.astimezone(UTC)


def anchor(target):
    return datetime.combine(target, time(8), SHANGHAI).astimezone(UTC)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    """Research exclusive first write plus a separate byte-identity sidecar."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode("utf-8")
    with path.open("xb") as stream:
        stream.write(raw)
    identity = hashlib.sha256(raw).hexdigest()
    with path.with_suffix(path.suffix + ".sha256").open("x", encoding="ascii") as stream:
        stream.write(identity + "\n")
    return identity


def verified_load(path):
    path = Path(path)
    if sha(path) != path.with_suffix(path.suffix + ".sha256").read_text().strip():
        raise ValueError("SAVED_EVIDENCE_HASH_MISMATCH")
    return load(path)


def validate_config(config):
    root = Path(config["output_root"]).resolve()
    if RESEARCH not in root.parents or "backups" in {p.lower() for p in root.parts}:
        raise ValueError("OUTPUT_OUTSIDE_RESEARCH_ROOT")
    if config["market"] != {"gamma_host": "gamma-api.polymarket.com", "clob_host": "clob.polymarket.com",
                            "request_timeout_seconds": 8, "max_workers": 4,
                            "freshness_seconds": 60, "requested_yes_quantity": "5"}:
        raise ValueError("FROZEN_MARKET_CONFIG_MISMATCH")
    if sha(config["freeze_path"]) != config["freeze_sha256"]:
        raise ValueError("FREEZE_IDENTITY_MISMATCH")
    freeze = load(config["freeze_path"])
    for name, identity in freeze["model_source_hashes"].items():
        if sha(ROOT / name) != identity:
            raise ValueError("FROZEN_MODEL_SOURCE_CHANGED: " + name)
    for name in ("population", "execution_protocol", "research_quantization_policy"):
        if sha(freeze[name + "_path"]) != freeze[name + "_sha256"]:
            raise ValueError("FROZEN_INPUT_CHANGED: " + name)
    for name in ("research_db_path", "observation_db_path"):
        path = Path(config[name]).resolve()
        if ROOT not in path.parents or "backups" in {p.lower() for p in path.parts}:
            raise ValueError("UNAUTHORIZED_SOURCE_PATH")
    if config.get("runtime_identity_path"):
        binding = load(config["runtime_identity_path"])
        config_identity = hashlib.sha256(json.dumps(config, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
        if config_identity != binding["config_sha256"]:
            raise ValueError("FROZEN_FORWARD_CONFIG_CHANGED")
        for name, identity in binding["source_hashes"].items():
            if sha(ROOT / name) != identity:
                raise ValueError("FROZEN_FORWARD_ADAPTER_CHANGED: " + name)
        if sha(config["protocol_path"]) != binding["protocol_sha256"]:
            raise ValueError("FORWARD_PROTOCOL_CHANGED")
    return root, freeze


def make_prediction(weather, training_rows, freeze, created_at):
    target = date.fromisoformat(weather.target_date)
    cutoff = anchor(target)
    training = []
    for row in sorted(training_rows, key=lambda item: item["target_date"]):
        prior = date.fromisoformat(row["target_date"])
        if row["status"] == "AVAILABLE" and prior < target and parsed(row["label_available_at_utc"]) <= cutoff and runner._d_plus_2_freeze(prior) <= cutoff:
            training.append(runner._row_to_training(row))
    dates = [item.target_date.isoformat() for item in training]
    if len(set(dates)) != len(dates):
        raise ValueError("DUPLICATE_TRAINING_DAY")
    record = {"target_date": weather.target_date, "decision_as_of_utc": weather.decision_as_of_utc,
              "prediction_created_at": stamp(created_at), "training_dates": dates, "training_count": len(dates),
              "status": "INPUT_OR_COMPUTATION_FAILURE", "source_status": "AVAILABLE", "reason": None,
              "model_version_hashes": freeze["model_source_hashes"], "freeze_id": freeze["freeze_id"],
              "research_semantics": "RESEARCH_ONLY_NOT_IIC2"}
    try:
        if created_at < cutoff or created_at >= runner._d_plus_2_freeze(target):
            raise ValueError("PREDICTION_NOT_WITHIN_PRELABEL_EXECUTION_WINDOW")
        if not training:
            raise ValueError("INSUFFICIENT_PRIOR_TRAINING_DATA")
        forecast = runner._decimal(weather.forecast.forecast_high_c, "forecast_high_c")
        observed = runner._decimal(weather.current_observed_max_c, "current_observed_max_c")
        buckets = runner.research_weather_buckets()
        samples = tuple(max(observed, forecast + item.residual_c) for item in training)
        candidate, candidate_meta = runner.research_probability_from_samples(samples, buckets)
        record.update(model_probabilities=[str(v) for v in candidate], model_quantization=candidate_meta,
                      model_temperature_mean_c=str(runner.mean(samples)), bucket_ids=[b.bucket_id for b in buckets])
        baseline_samples = tuple(item.label_final_max_c for item in training)
        baseline, baseline_meta = runner.research_probability_from_samples(baseline_samples, buckets)
        record.update(baseline_probabilities=[str(v) for v in baseline], baseline_quantization=baseline_meta,
                      baseline_temperature_mean_c=str(runner.mean(baseline_samples)), status="PREDICTION_SAVED_AWAITING_LABEL")
    except Exception as exc:
        record.update(reason=type(exc).__name__ + ": " + str(exc))
    return record


def score_record(prediction, label, now):
    available = parsed(label.label_available_at_utc)
    if now < available or parsed(prediction["prediction_created_at"]) >= available:
        raise ValueError("BLIND_PREDICTION_LABEL_ORDER_FAILED")
    if label.target_date != prediction["target_date"]:
        raise ValueError("LABEL_DATE_MISMATCH")
    result = runner.score_saved_predictions({"rows": [prediction]}, {"candidate_days": [
        {"target_date": label.target_date, "label_final_max_c": str(label.final_max_c)}]})["rows"][0]
    result.update(label_available_at=label.label_available_at_utc, score_created_at=stamp(now))
    if result.get("evaluation_status") == "SCORED":
        difference = Decimal(result["baseline_loss_brier"]) - Decimal(result["candidate_loss_brier"])
        result["daily_winner"] = "CANDIDATE" if difference > 0 else "BASELINE" if difference < 0 else "TIE"
    return result


def append_mature_scores(root, observation_db, now, attempt, label_reader=mature_label):
    training_rows, errors = [], []
    for day in sorted((root / "days").glob("????-??-??")):
        target = date.fromisoformat(day.name)
        if runner._d_plus_2_freeze(target) > now or not (day / "weather_input.json").exists():
            continue
        try:
            weather = verified_load(day / "weather_input.json")
            label_path = day / "label.json"
            if not label_path.exists():
                save(label_path, asdict(label_reader(target, observation_db, now)))
            label = verified_load(label_path)
            if parsed(label["label_available_at_utc"]) > now:
                raise ValueError("LABEL_NOT_MATURE")
            training_rows.append({"target_date": day.name, "status": "AVAILABLE",
                                  "forecast_high_c": str(weather["forecast"]["forecast_high_c"]),
                                  "label_final_max_c": str(label["final_max_c"]),
                                  "label_available_at_utc": label["label_available_at_utc"]})
            pred_path, score_path = day / "prediction.json", day / "score.json"
            if pred_path.exists() and not score_path.exists():
                result = score_record(verified_load(pred_path), SimpleNamespace(**label), now)
                result.update(prediction_sha256=sha(pred_path), label_sha256=sha(label_path))
                save(score_path, result)
        except Exception as exc:
            errors.append({"target_date": day.name, "status": "LABEL_OR_SCORE_FAILURE", "reason": str(exc)})
    save(attempt / "mature_processing.json", {"errors": errors, "available_training_dates": [r["target_date"] for r in training_rows]})
    return training_rows


def forward_metrics(root, limit=None):
    scores = [verified_load(p) for p in sorted((root / "days").glob("????-??-??/score.json"))]
    scored = sorted([r for r in scores if r.get("evaluation_status") == "SCORED"],
                    key=lambda r: (r["score_created_at"], r["target_date"]))
    if limit is not None:
        scored = scored[:limit]
    result = {"FORWARD_BLIND_SCORING_DAYS": len(scored), "EXPLORATORY_SCORING_DAYS": 23,
              "scoring_dates": [r["target_date"] for r in scored], "PREDICTIVE_SKILL_PROVEN": "NO"}
    if scored:
        for name in ("candidate_loss_brier", "baseline_loss_brier", "candidate_absolute_error", "baseline_absolute_error"):
            result["mean_" + name] = str(runner.mean([Decimal(r[name]) for r in scored]))
        result["brier_difference"] = str(Decimal(result["mean_baseline_loss_brier"]) - Decimal(result["mean_candidate_loss_brier"]))
        result["candidate_better_days"] = sum(r["daily_winner"] == "CANDIDATE" for r in scored)
        result["baseline_better_days"] = sum(r["daily_winner"] == "BASELINE" for r in scored)
        result["ties"] = sum(r["daily_winner"] == "TIE" for r in scored)
    return result


def event_slug(target):
    return f"highest-temperature-in-shanghai-on-{MONTHS[target.month - 1]}-{target.day}-{target.year}"


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("REDIRECT_DISABLED_BEFORE_FOLLOWING")


@dataclass(frozen=True)
class PublicResponse:
    url: str
    requested_at: str
    received_at: str
    status: int
    body: bytes
    error: str | None = None


def public_get(url):
    parts = urlparse(url)
    permitted = ((parts.hostname == "gamma-api.polymarket.com" and parts.path.startswith("/events/slug/")) or
                 (parts.hostname == "clob.polymarket.com" and parts.path == "/book"))
    if parts.scheme != "https" or not permitted or parts.port not in (None, 443) or parts.username:
        raise ValueError("PUBLIC_READ_ENDPOINT_NOT_ALLOWED")
    requested = stamp(utcnow())
    try:
        request = Request(url, headers={"Accept": "application/json", "User-Agent": "WeatherResearchV1"}, method="GET")
        with build_opener(NoRedirect()).open(request, timeout=8) as response:
            body = response.read()
            return PublicResponse(url, requested, stamp(utcnow()), response.status, body)
    except HTTPError as exc:
        body = exc.read()
        return PublicResponse(url, requested, stamp(utcnow()), exc.code, body, str(exc))
    except Exception as exc:
        return PublicResponse(url, requested, stamp(utcnow()), 0, b"", type(exc).__name__ + ": " + str(exc))


def save_response(directory, response):
    directory.mkdir(parents=True, exist_ok=False)
    with (directory / "response.raw").open("xb") as stream:
        stream.write(response.body)
    metadata = {key: value for key, value in asdict(response).items() if key != "body"}
    metadata["raw_sha256"] = sha(directory / "response.raw")
    save(directory / "response.json", metadata)
    if response.status != 200:
        raise ValueError("HTTP_READ_FAILED: " + str(response.status) + " " + str(response.error))
    return json.loads(response.body)


def discover_markets(event, target):
    if event.get("slug") != event_slug(target) or not event.get("id"):
        raise ValueError("EVENT_TARGET_IDENTITY_MISMATCH")
    markets = event.get("markets")
    if not isinstance(markets, list) or not markets:
        raise ValueError("EVENT_MARKETS_MISSING")
    result, tokens, conditions, market_ids = [], set(), set(), set()
    for ordinal, market in enumerate(markets):
        if not isinstance(market, dict):
            result.append({"ordinal": ordinal, "identity_error": "MARKET_NOT_OBJECT"})
            continue
        item = {"ordinal": ordinal, "market_id": str(market.get("id") or ""),
                "condition_id": str(market.get("conditionId") or ""),
                "bucket": market.get("groupItemTitle"), "question": market.get("question"),
                "rule": market.get("description"), "event_id": str(event["id"]),
                "partition_source": "PUBLIC_GAMMA_EVENT", "yes_token_id": None}
        try:
            outcomes, ids = market["outcomes"], market["clobTokenIds"]
            outcomes = json.loads(outcomes) if isinstance(outcomes, str) else outcomes
            ids = json.loads(ids) if isinstance(ids, str) else ids
            if not isinstance(outcomes, list) or not isinstance(ids, list) or len(outcomes) != len(ids):
                raise ValueError("OUTCOME_TOKEN_LENGTH")
            yes = [i for i, value in enumerate(outcomes) if str(value).lower() == "yes"]
            if len(yes) != 1 or not str(ids[yes[0]]).isdigit():
                raise ValueError("UNIQUE_YES_TOKEN_REQUIRED")
            token = str(ids[yes[0]])
            if not item["market_id"] or not item["condition_id"] or not item["rule"] or item["bucket"] is None:
                raise ValueError("MARKET_IDENTITY_OR_RULE_MISSING")
            if token in tokens or item["condition_id"] in conditions or item["market_id"] in market_ids:
                raise ValueError("DUPLICATE_MARKET_IDENTITY")
            tokens.add(token)
            conditions.add(item["condition_id"])
            market_ids.add(item["market_id"])
            item["yes_token_id"] = token
        except (KeyError, ValueError, TypeError, IndexError) as exc:
            item["identity_error"] = str(exc)
        result.append(item)
    if any(item.get("identity_error") == "DUPLICATE_MARKET_IDENTITY" for item in result):
        for item in result:
            item["identity_error"] = "POPULATION_DUPLICATE_IDENTITY"
    return result


def save_book(directory, member, response, target, partition_hash):
    record = dict(member, status="ERROR", snapshot_sha256=hashlib.sha256(response.body).hexdigest(),
                  capture_at=response.requested_at, observed_at=response.received_at, effective_at=None,
                  freshness_seconds=None, partition_sha256=partition_hash)
    try:
        book = save_response(directory / "http", response)
        if str(book.get("asset_id")) != member["yes_token_id"] or str(book.get("market")) != member["condition_id"]:
            raise ValueError("BOOK_MARKET_TOKEN_MISMATCH")
        milliseconds = Decimal(str(book["timestamp"]))
        if not milliseconds.is_finite() or milliseconds != milliseconds.to_integral_value():
            raise ValueError("INVALID_BOOK_TIMESTAMP")
        effective = datetime.fromtimestamp(int(milliseconds) // 1000, UTC) + timedelta(milliseconds=int(milliseconds) % 1000)
        received, requested, cutoff = parsed(response.received_at), parsed(response.requested_at), anchor(target)
        record.update(effective_at=stamp(effective), source_timestamp_original=book["timestamp"],
                      freshness_seconds=str(Decimal(str((cutoff - effective).total_seconds()))))
        asks = book["asks"]
        if not isinstance(asks, list):
            raise ValueError("FULL_ASK_ARRAY_REQUIRED")
        levels = tuple(sorted((YesAsk(str(item["price"]), str(item["size"])) for item in asks), key=lambda x: Decimal(x.price)))
        frame = FrameInput(source_frame_id=record["snapshot_sha256"], raw_frame_bytes=response.body,
                           city="Shanghai", target_date=target.isoformat(), market_family="POLYMARKET_TEMPERATURE",
                           partition_source="PUBLISHED_UNIVERSE_V1", market_id=member["market_id"],
                           yes_token_id=member["yes_token_id"], rule_hash=hashlib.sha256(member["rule"].encode()).hexdigest(),
                           captured_at_utc=response.requested_at, received_at_utc=response.received_at,
                           source_timestamp_utc=stamp(effective), first_visible_at_utc=None,
                           frame_kind="FULL_DEPTH", complete=True, upstream_truncated=False,
                           yes_asks=levels, requested_yes_quantity="5")
        status = _validation_status(frame)
        if effective > cutoff or requested > cutoff or received > cutoff:
            status = CaptureStatus.REJECTED_FUTURE
        elif cutoff - effective > timedelta(seconds=60) or cutoff - requested > timedelta(seconds=60):
            status = CaptureStatus.REJECTED_STALE
        if received < requested or any(not Decimal(x.price).is_finite() or Decimal(x.price) > 1 for x in levels):
            status = CaptureStatus.REJECTED_INCONSISTENT
        saved = CaptureStore(directory / "store").append(frame, status)
        metadata = load(saved["record_path"])
        feasible = metadata["execution_feasibility"]
        record.update(frame=saved, best_ask=levels[0].price if levels else None,
                      ladder_levels=len(levels), ladder_quantity=str(sum((Decimal(x.size) for x in levels), Decimal(0))),
                      execution_feasibility=feasible, capture_status=status.value,
                      completeness_basis="Untruncated GET /book asks array; live API compatibility unverified")
        if status == CaptureStatus.ACCEPTED:
            record["status"] = "AVAILABLE" if feasible.get("fillable") else "UNFILLABLE"
        elif status in (CaptureStatus.REJECTED_STALE, CaptureStatus.REJECTED_FUTURE):
            record["status"] = "STALE"
        elif not levels:
            record["status"] = "UNFILLABLE"
    except Exception as exc:
        record["reason"] = type(exc).__name__ + ": " + str(exc)
    save(directory / "record.json", record)
    return record


def wait_until(moment, clock=utcnow, sleep=wall_time.sleep):
    while clock() < moment:
        sleep(max(0, min(60, (moment - clock()).total_seconds())))


def capture_market(day, target, fetch=public_get, clock=utcnow, sleep=wall_time.sleep):
    market_root = day / "market"
    market_root.mkdir()
    try:
        response = fetch("https://gamma-api.polymarket.com/events/slug/" + event_slug(target))
        event = save_response(market_root / "event", response)
        members = discover_markets(event, target)
        partition_hash = sha(market_root / "event/response.raw")
        save(market_root / "population.json", {"target_date": target.isoformat(), "members": members,
                                                "event_raw_sha256": partition_hash, "observed_at": response.received_at})
        wait_until(anchor(target) - timedelta(seconds=60), clock, sleep)

        def one(member):
            location = market_root / f"member_{member['ordinal']:04d}"
            if member.get("identity_error") or clock() >= anchor(target):
                value = dict(member, status="ERROR" if member.get("identity_error") else "MISSING",
                             reason=member.get("identity_error", "ANCHOR_PASSED_BEFORE_REQUEST"))
                save(location / "record.json", value)
                return value
            try:
                response = fetch("https://clob.polymarket.com/book?" + urlencode({"token_id": member["yes_token_id"]}))
                return save_book(location, member, response, target, partition_hash)
            except Exception as exc:
                value = dict(member, status="ERROR", reason=str(exc))
                save(location / "request_error.json", value)
                return value

        with ThreadPoolExecutor(max_workers=4) as pool:
            records = list(pool.map(one, members))
        available = sum(item["status"] == "AVAILABLE" for item in records)
        result = {"status": "MARKET_COMPLETE" if available == len(records) else "MARKET_PARTIAL",
                  "expected_markets": len(records), "available_markets": available, "members": records}
    except Exception as exc:
        result = {"status": "MARKET_MISSING", "reason": type(exc).__name__ + ": " + str(exc)}
    save(market_root / "result.json", result)
    return result


def run_daily(config, target, clock=utcnow, sleep=wall_time.sleep, fetch=public_get,
              weather_reader=snapshot_weather, label_reader=mature_label):
    root, freeze = validate_config(config)
    attempt = root / "attempts" / (stamp(clock()).replace(":", "") + "_" + uuid.uuid4().hex)
    runtime = attempt / "runtime"
    runtime.mkdir(parents=True, exist_ok=False)
    probe = runtime / "cwrd"
    probe.mkdir()
    sentinel = probe / "sentinel.txt"
    with sentinel.open("x", encoding="utf-8") as stream:
        stream.write("forward-v1")
    if sentinel.read_text(encoding="utf-8") != "forward-v1":
        raise ValueError("RUNTIME_READ_CHECK_FAILED")
    sentinel.unlink()
    probe.rmdir()
    save(attempt / "environment.json", {"PYTHON_EXECUTABLE": sys.executable, "PYTHON_VERSION": sys.version,
         "TEST_ENVIRONMENT": sys.prefix, "QA_RUNTIME_ROOT": str(runtime), "WORKSPACE_PERMISSION_MODE": "WORKSPACE_WRITE",
         "permission_mode_basis": "Declared authorization; actual write permission verified by CWRD, not inferred from app settings",
         "CREATE": "PASS", "WRITE": "PASS", "READ": "PASS", "DELETE": "PASS",
         "dependencies": {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()},
         "command": sys.argv, "working_directory": str(Path.cwd())})
    save(attempt / "start.json", {"target_date": target.isoformat(), "created_at": stamp(clock()),
                                  "mode": "RESEARCH_LIVE_READ_ONCE", "config": config})
    local = clock().astimezone(SHANGHAI)
    if target != local.date() or target < FIRST_DAY or not time(7, 58) <= local.time() < time(8):
        result = {"status": "CAPTURE_FAILURE", "reason": "OUTSIDE_DAILY_PREANCHOR_START_WINDOW", "target_date": target.isoformat()}
        save(attempt / "result.json", result)
        return result
    day = root / "days" / target.isoformat()
    try:
        day.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        result = {"status": "CAPTURE_FAILURE", "reason": "DAY_ALREADY_RESERVED_NO_REPREDICTION", "target_date": target.isoformat()}
        save(attempt / "result.json", result)
        return result
    save(day / "claim.json", {"attempt": str(attempt), "created_at": stamp(clock()), "target_date": target.isoformat()})
    missed = FIRST_DAY
    while missed < target:
        missing_day = root / "days" / missed.isoformat()
        if not missing_day.exists():
            save(missing_day / "result.json", {"target_date": missed.isoformat(), "status": "CAPTURE_FAILURE", "reason": "NO_RECORDED_INVOCATION", "recorded_at": stamp(clock())})
        missed += timedelta(days=1)
    result = {"target_date": target.isoformat(), "weather_status": "WEATHER_INPUT_FAILURE"}
    # Market I/O is independent of the main thread's 08:00 weather snapshot.
    with ThreadPoolExecutor(max_workers=1) as pool:
        market_task = pool.submit(capture_market, day, target, fetch, clock, sleep)
        try:
            future_training = append_mature_scores(root, Path(config["observation_db_path"]), clock(), attempt, label_reader)
            initial = [r for r in load(freeze["population_path"])["candidate_days"] if r["status"] == "AVAILABLE"]
            if clock() >= anchor(target):
                raise ValueError("PREPARATION_MISSED_WEATHER_ANCHOR")
            wait_until(anchor(target), clock, sleep)
            validate_config(config)
            weather = weather_reader(target, Path(config["research_db_path"]), Path(config["observation_db_path"]))
            weather_hash = save(day / "weather_input.json", asdict(weather))
            saved_at = clock()
            prediction = make_prediction(weather, initial + future_training, freeze, saved_at)
            prediction.update(source_hashes={"weather_snapshot": weather_hash,
                                            "forecast_content": weather.forecast.content_hash,
                                            "observation_set": weather.observation_set_hash},
                              forecast_identity=asdict(weather.forecast),
                              anchor_observation_identity=[fact.source_fact_id for fact in weather.observations],
                              freeze_sha256=config["freeze_sha256"], execution_timestamp=stamp(clock()),
                              snapshot_execution_lag_seconds=(saved_at - anchor(target)).total_seconds())
            prediction["prediction_created_at"] = stamp(clock())
            if clock() >= runner._d_plus_2_freeze(target):
                raise ValueError("LABEL_MATURE_BEFORE_PREDICTION_SAVE")
            save(day / "prediction.json", prediction)
            result["weather_status"] = "PREDICTION_COMPLETE" if prediction["status"] == "PREDICTION_SAVED_AWAITING_LABEL" else "CAPTURE_FAILURE"
        except Exception as exc:
            result["weather_error"] = type(exc).__name__ + ": " + str(exc)
            save(day / "weather_failure.json", result)
        try:
            result["market"] = market_task.result()
        except Exception as exc:
            result["market"] = {"status": "MARKET_MISSING", "reason": str(exc)}
    try:
        metrics = forward_metrics(root)
        save(attempt / "forward_metrics.json", metrics)
        count = metrics["FORWARD_BLIND_SCORING_DAYS"]
        for threshold in (5, 10, 20, 30):
            checkpoint = root / "checkpoints" / f"{threshold:02d}.json"
            if count >= threshold and not checkpoint.exists():
                value = forward_metrics(root, threshold)
                value.update(checkpoint=threshold, selection="First N successfully registered blind scores; not selected by loss", created_at=stamp(clock()))
                save(checkpoint, value)
        result["FORWARD_BLIND_SCORING_DAYS"] = count
    except Exception as exc:
        result["metrics_error"] = str(exc)
    result.update(status=result["weather_status"], completed_at=stamp(clock()), attempt=str(attempt),
                  FORWARD_COLLECTION_RUNNING="NO")
    save(day / "result.json", result)
    save(attempt / "result.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--target-date", type=date.fromisoformat)
    parser.add_argument("--research-live-read", action="store_true")
    parser.add_argument("--check-only", action="store_true", help="Hash/config only; no network, model execution or source snapshot")
    args = parser.parse_args()
    config = load(args.config)
    validate_config(config)
    if args.check_only:
        print(json.dumps({"CONFIG_AND_FREEZE": "PASS", "REAL_CAPTURE_EXECUTED": "NO"}))
        return
    if not args.research_live_read:
        parser.error("--research-live-read is required")
    result = run_daily(config, args.target_date or utcnow().astimezone(SHANGHAI).date())
    print(json.dumps(result, ensure_ascii=False))
    if result["status"] != "PREDICTION_COMPLETE":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
