"""Read-only Shanghai weather inputs for forward research collection.

The module never imports a collector, makes a network request, or writes a
database.  Its caller supplies existing SQLite paths whose source data must
already have arrived through an independently authorised process.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from typing import Iterator
from zoneinfo import ZoneInfo

from tools.research_weather_validation_v1.population import (
    coverage_complete as population_coverage_complete,
    label_freeze as population_label_freeze,
    local_day_window,
    source_registry_row,
)


UTC = timezone.utc
SHANGHAI = ZoneInfo("Asia/Shanghai")
CITY = "Shanghai"
STATION = "ZSPD"
FORECAST_SOURCE = "weatherol_shanghai"
LABEL_GAP_LIMIT_SECONDS = 5400


def _canonical(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def _hash(value: object) -> str:
    return sha256(_canonical(value).encode("utf-8")).hexdigest()


def _utc(value: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError("timestamp_invalid")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("timestamp_invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() != timedelta(0):
        raise ValueError("timestamp_not_utc")
    return parsed.astimezone(UTC)


def _text(value: datetime) -> str:
    return value.isoformat(timespec="microseconds").replace("+00:00", "Z")


def _target(value: date) -> date:
    if not isinstance(value, date) or isinstance(value, datetime):
        raise ValueError("target_date_invalid")
    return value


@contextmanager
def _ro(path: Path) -> Iterator[sqlite3.Connection]:
    if not isinstance(path, Path) or not path.is_file():
        raise ValueError("sqlite_path_missing")
    try:
        connection = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only=ON")
        try:
            yield connection
        finally:
            connection.close()
    except sqlite3.Error as exc:
        raise ValueError("sqlite_readonly_open_failed") from exc


@dataclass(frozen=True, slots=True)
class ObservationFact:
    observation_id: int
    report_time_utc: str
    received_at_utc: str
    report_type: str
    temperature_c: float
    raw_observation: str
    raw_hash: str
    source: str
    source_fact_id: str


@dataclass(frozen=True, slots=True)
class ForecastInput:
    city: str
    station: str
    source: str
    target_date: str
    grid_version: str
    forecast_high_c: float
    source_reported_at: str | None
    effective_at_utc: None
    first_captured_at_utc: str
    observed_at_utc: str
    content_hash: str
    source_fact_id: str


@dataclass(frozen=True, slots=True)
class WeatherSnapshot:
    target_date: str
    decision_as_of_utc: str
    forecast: ForecastInput
    current_observed_max_c: float | None
    observations: tuple[ObservationFact, ...]
    observation_set_hash: str
    actual_maximum_gap_seconds: int | None
    coverage_first_within_30m: bool
    coverage_last_within_30m: bool
    coverage_gap_within_5400s: bool


@dataclass(frozen=True, slots=True)
class MatureWeatherLabel:
    target_date: str
    label_available_at_utc: str
    final_max_c: float
    observations: tuple[ObservationFact, ...]
    observation_set_hash: str
    first_report_time_utc: str
    last_report_time_utc: str
    maximum_gap_seconds: int


def _facts(connection: sqlite3.Connection, start: datetime, end: datetime, visible_by: datetime) -> tuple[ObservationFact, ...]:
    try:
        rows = connection.execute(
            """
            SELECT observation_id,report_time,received_at,report_type,temperature_c,
                   raw_observation,raw_hash,source
            FROM metar_observations
            WHERE station=? AND city=? AND temperature_c IS NOT NULL
            ORDER BY report_time ASC, observation_id ASC
            """,
            (STATION, CITY),
        ).fetchall()
    except sqlite3.Error as exc:
        raise ValueError("observation_schema_unavailable") from exc
    facts: list[ObservationFact] = []
    for row in rows:
        record = {
            "observation_id": row["observation_id"], "station": STATION, "city": CITY,
            "report_time_utc": row["report_time"], "received_at_utc": row["received_at"],
            "report_type": row["report_type"], "temperature_c": row["temperature_c"],
            "raw_observation": row["raw_observation"], "raw_hash": row["raw_hash"], "source": row["source"],
        }
        report_time = _utc(record["report_time_utc"])
        received_at = _utc(record["received_at_utc"])
        if not start <= report_time < end or received_at > visible_by:
            continue
        facts.append(ObservationFact(
            observation_id=record["observation_id"], report_time_utc=record["report_time_utc"],
            received_at_utc=record["received_at_utc"], report_type=record["report_type"],
            temperature_c=record["temperature_c"], raw_observation=record["raw_observation"],
            raw_hash=record["raw_hash"], source=record["source"], source_fact_id=_hash(record),
        ))
    return tuple(facts)


def _coverage(facts: tuple[ObservationFact, ...], start: datetime, end: datetime) -> tuple[int | None, bool, bool, bool]:
    if not facts:
        return None, False, False, False
    times = [_utc(fact.report_time_utc) for fact in facts]
    coverage, gap = population_coverage_complete([{"report_time": fact.report_time_utc} for fact in facts], start, end)
    first = times[0] <= start + timedelta(minutes=30)
    last = times[-1] >= end - timedelta(minutes=30)
    return gap, first, last, coverage


def _forecast(connection: sqlite3.Connection, target_date: date, anchor: datetime) -> ForecastInput:
    try:
        row, error = source_registry_row(connection, target_date.isoformat())
    except sqlite3.Error as exc:
        raise ValueError("forecast_schema_unavailable") from exc
    if error == "FORECAST_D0_MISSING":
        raise ValueError("forecast_d0_missing")
    if error == "FORECAST_D0_CONFLICT":
        raise ValueError("forecast_d0_conflict")
    if row is None:
        raise ValueError("forecast_d0_missing")
    first = _utc(row["first_captured_at"])
    if first > anchor:
        raise ValueError("forecast_not_visible_by_decision_asof")
    if row["forecast_high_c"] is None or not isinstance(row["content_hash"], str) or not row["content_hash"]:
        raise ValueError("forecast_d0_identity_incomplete")
    record = {
        "source": row["source"], "city": row["city"], "station": row["station"],
        "target_date": row["target_date"], "grid_version": row["grid_version"],
        "forecast_high_c": row["forecast_high_c"], "source_reported_at": row["source_reported_at"],
        "effective_at_utc": None, "first_captured_at_utc": row["first_captured_at"],
        "observed_at_utc": row["first_captured_at"], "content_hash": row["content_hash"],
    }
    return ForecastInput(**record, source_fact_id=_hash(record))


def snapshot_weather(target_date: date, research_db: Path, observation_db: Path) -> WeatherSnapshot:
    """Return only the 08:00 prediction inputs; no label is computed here."""
    target = _target(target_date)
    start, anchor, _end = local_day_window(target)
    with _ro(research_db) as forecast_db, _ro(observation_db) as observations_db:
        forecast = _forecast(forecast_db, target, anchor)
        facts = _facts(observations_db, start, anchor, anchor)
    if not facts:
        raise ValueError("current_observation_at_anchor_missing")
    gap, first, last, within = _coverage(facts, start, anchor)
    fact_ids = [fact.source_fact_id for fact in facts]
    return WeatherSnapshot(
        target_date=target.isoformat(), decision_as_of_utc=_text(anchor), forecast=forecast,
        current_observed_max_c=max((fact.temperature_c for fact in facts), default=None), observations=facts,
        observation_set_hash=_hash(fact_ids), actual_maximum_gap_seconds=gap,
        coverage_first_within_30m=first, coverage_last_within_30m=last,
        coverage_gap_within_5400s=within,
    )


def mature_label(target_date: date, observation_db: Path, now: datetime) -> MatureWeatherLabel:
    """Return a fail-closed D+2 WeatherLabel reconstruction from raw facts."""
    target = _target(target_date)
    if now.tzinfo is None or now.utcoffset() != timedelta(0):
        raise ValueError("now_not_utc")
    start, _anchor, end = local_day_window(target)
    freeze = population_label_freeze(target)
    if now.astimezone(UTC) < freeze:
        raise ValueError("label_not_mature")
    with _ro(observation_db) as observations_db:
        facts = _facts(observations_db, start, end, freeze)
    gap, first, last, within = _coverage(facts, start, end)
    if not facts:
        raise ValueError("label_observation_missing")
    if not (first and last and within):
        raise ValueError("label_coverage_incomplete")
    fact_ids = [fact.source_fact_id for fact in facts]
    return MatureWeatherLabel(
        target_date=target.isoformat(), label_available_at_utc=_text(freeze),
        final_max_c=max(fact.temperature_c for fact in facts), observations=facts,
        observation_set_hash=_hash(fact_ids), first_report_time_utc=facts[0].report_time_utc,
        last_report_time_utc=facts[-1].report_time_utc, maximum_gap_seconds=gap or 0,
    )
