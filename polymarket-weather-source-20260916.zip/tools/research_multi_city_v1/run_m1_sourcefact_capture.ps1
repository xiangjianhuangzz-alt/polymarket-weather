$ErrorActionPreference = 'Stop'

$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$pythonExecutable = Join-Path $projectRoot '.venv-strategy-tests-v1\Scripts\python.exe'
$evidenceRoot = Join-Path $projectRoot 'data\strategy_analysis\m1_sourcefact_capture_v1\20260906T070442+0800'
$sourceFactRoot = Join-Path $evidenceRoot 'forward_sourcefacts'
$logRoot = Join-Path $evidenceRoot 'scheduled_logs'
New-Item -ItemType Directory -Force -Path $logRoot | Out-Null
$stamp = Get-Date -Format 'yyyyMMddTHHmmssK'
$stamp = $stamp.Replace(':', '')
$captureLog = Join-Path $logRoot ($stamp + '_capture.log')
$verifyLog = Join-Path $logRoot ($stamp + '_verify.log')

$command = if ((Get-Date).Hour -eq 6) { 'capture' } else { 'observe' }
& $pythonExecutable -X utf8 -B -m tools.research_multi_city_v1.m1_sourcefact_capture $command --root $sourceFactRoot --cities Shanghai Beijing Guangzhou *> $captureLog
$captureExit = $LASTEXITCODE
if ($captureExit -ne 0) {
    exit $captureExit
}
& $pythonExecutable -X utf8 -B -m tools.research_multi_city_v1.m1_sourcefact_capture verify --root $sourceFactRoot *> $verifyLog
exit $LASTEXITCODE
