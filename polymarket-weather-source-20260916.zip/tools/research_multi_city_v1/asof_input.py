"""Research dynamic input boundary. Missing historical time evidence is not repaired."""
from dataclasses import dataclass
from datetime import datetime, date, time, timedelta
from decimal import Decimal
from .dynamic_event_router import CITIES, LOCAL
from .population import parse
from .dynamic_forward import normalized
from strategy_v8.canonical import hash_v1

@dataclass(frozen=True)
class WeatherFact:
    city: str; local_second: str; effective_at: datetime | None; observed_at: datetime | None; received_at: datetime | None; available_at: datetime | None; committed_at: datetime | None

def strict_asof(fact: WeatherFact, city: str, local_second: str, at: datetime) -> WeatherFact:
    if at.tzinfo is None or fact.city != city or fact.local_second != local_second: raise ValueError("ASOF_IDENTITY_INVALID")
    required=(fact.effective_at,fact.observed_at,fact.committed_at)
    if any(value is None or value.tzinfo is None or value.utcoffset() is None or value > at for value in required): raise ValueError("STRICT_ASOF_UNPROVEN")
    if any(value is not None and (value.tzinfo is None or value.utcoffset() is None or value > at) for value in (fact.received_at,fact.available_at)):
        raise ValueError("STRICT_ASOF_UNPROVEN")
    return fact

TIMES = ('effective', 'observed', 'received', 'available', 'committed')
REQUIRED_TIMES = ('effective', 'observed', 'committed')

def fact_hash(fact):
    return hash_v1('PWM.DYNAMIC.WEATHER_FACT.V1', normalized({k:v for k,v in fact.items() if k != 'hash'}))

def seal_fact(fact):
    result = dict(fact)
    result['hash'] = fact_hash(result)
    return result

def validate_fact(fact, city, station):
    if fact.get('city') != city or fact.get('station') != station or CITIES.get(city) != station:
        raise ValueError('CITY_STATION_IDENTITY_INVALID')
    if fact.get('hash') != fact_hash(fact): raise ValueError('SOURCE_FACT_HASH_MISMATCH')
    if not fact.get('identity') or not fact.get('source_identity'):
        raise ValueError('SOURCE_IDENTITY_MISSING')
    if {'market_id','book','price','fee','edge','settlement','best_ask','token_id'} & set(fact):
        raise ValueError('MARKET_INPUT_FORBIDDEN')
    for key in TIMES:
        if fact.get(key) is not None: parse(fact[key])
    return fact

def visible(fact, cutoff):
    # IIC2 M06 WeatherLabel is not a RawSourceFact: its visibility is its
    # immutable label commit, not invented effective/observed timestamps.
    required = ('committed',) if fact.get('fact_type') == 'LABEL' else REQUIRED_TIMES
    if any(fact.get(key) is None for key in required):
        raise ValueError('STRICT_ASOF_TIME_UNPROVABLE:' + ','.join(k for k in required if fact.get(k) is None))
    return all(parse(fact[key]) <= cutoff for key in TIMES if fact.get(key) is not None)


def bind_source_event(event, asof, facts):
    if event.cause_type != 'SourceFactV1':
        return None
    kinds = {'LEGAL_FORECAST_REVISION': {'FORECAST'}, 'LEGAL_METAR_OR_SPECI': {'METAR', 'SPECI'}}
    if event.transition_kind not in kinds:
        raise ValueError('EVENT_SOURCE_TYPE_INVALID')
    matches = [f for f in facts if f.get('identity') == event.cause_object_id]
    if not matches:
        raise ValueError('EVENT_SOURCEFACT_MISSING')
    if len({f.get('hash') for f in matches}) != 1:
        raise ValueError('EVENT_SOURCEFACT_CONFLICT')
    fact = matches[0]
    validate_fact(fact, event.city, CITIES[event.city])
    if fact.get('target_date') != asof.astimezone(LOCAL).date().isoformat() or fact.get('fact_type') not in kinds[event.transition_kind]:
        raise ValueError('EVENT_SOURCE_IDENTITY_INVALID')
    expected = ('weatherol_shanghai' if event.city == 'Shanghai' else 'aviationweather_taf') if fact['fact_type'] == 'FORECAST' else 'aviationweather_metar'
    if fact.get('source_identity') != expected:
        raise ValueError('EVENT_SOURCE_BINDING_INVALID')
    if not visible(fact, asof):
        raise ValueError('EVENT_SOURCEFACT_FUTURE')
    if parse(fact['effective']) != event.effective_at_utc:
        raise ValueError('EVENT_EFFECTIVE_TIME_MISMATCH')
    return {'identity': fact['identity'], 'hash': fact['hash'], 'city': event.city,
            'target_date': fact['target_date'], 'fact_type': fact['fact_type']}

def number(value):
    if isinstance(value, bool) or value is None: raise ValueError('TEMPERATURE_MISSING')
    result = Decimal(str(value))
    if not result.is_finite() or result*1000 != (result*1000).to_integral_value():
        raise ValueError('TEMPERATURE_INVALID')
    return result

def select_forecast(facts, city, station, target, cutoff):
    candidates = []
    for fact in facts:
        validate_fact(fact, city, station)
        if fact['target_date'] != target or fact['fact_type'] != 'FORECAST': continue
        if visible(fact, cutoff): candidates.append(fact)
    if not candidates: raise ValueError('FORECAST_MISSING_AT_ASOF')
    distinct = {fact['identity']: fact for fact in candidates}
    if len(distinct) != len({(f['identity'],f['hash']) for f in candidates}):
        raise ValueError('FORECAST_REVISION_IDENTITY_CONFLICT')
    candidates = list(distinct.values())
    if any(f.get('revision_rank') is None for f in candidates):
        if len(candidates) != 1: raise ValueError('FORECAST_RANK_UNPROVABLE_MULTIPLE_REVISIONS')
    else:
        for fact in candidates:
            rank = fact['revision_rank']
            if type(rank) is not int or not 0 <= rank < 2**64: raise ValueError('REVISION_RANK_INVALID')
        by_rank = {}
        for fact in candidates:
            rank = fact['revision_rank']
            if rank in by_rank and by_rank[rank]['identity'] != fact['identity']:
                raise ValueError('FORECAST_SAME_RANK_CONFLICT')
            by_rank[rank] = fact
        candidates = [by_rank[max(by_rank)]]
    chosen = candidates[0]
    if not chosen.get('revision'): raise ValueError('REVISION_IDENTITY_MISSING')
    number(chosen.get('value_c'))
    return chosen

def build_input(city, target_date, decision_as_of, facts, labels, freeze_identity, training_dates):
    cutoff = parse(decision_as_of)
    local = cutoff.astimezone(LOCAL)
    if local.date().isoformat() != target_date or not time(7) <= local.time() < time(16):
        raise ValueError('DYNAMIC_WINDOW_INVALID')
    station = CITIES[city]
    for fact in facts: validate_fact(fact, city, station)
    forecast = select_forecast(facts, city, station, target_date, cutoff)
    observations = []
    for fact in facts:
        if fact['target_date'] != target_date or fact['fact_type'] not in ('METAR','SPECI'): continue
        if visible(fact, cutoff):
            number(fact.get('value_c')); observations.append(fact)
    if not observations: raise ValueError('OBSERVATION_MISSING_AT_ASOF')
    training = []
    for label in labels:
        validate_fact(label, city, station)
        day = date.fromisoformat(label['target_date'])
        if str(day) not in training_dates or day >= local.date(): continue
        mature = datetime.combine(day+timedelta(days=2),time.min,LOCAL)
        if mature > cutoff: continue
        if label.get('label_available_at') is None: raise ValueError('LABEL_AVAILABILITY_UNPROVABLE')
        available = parse(label['label_available_at'])
        if available < mature: raise ValueError('LABEL_PREMATURE')
        if available > cutoff: continue
        if label.get('committed') is None: raise ValueError('LABEL_COMMIT_UNPROVABLE')
        if parse(label['committed']) < mature or available != parse(label['committed']):
            raise ValueError('LABEL_COMMIT_VISIBILITY_MISMATCH')
        if not visible(label, cutoff): continue
        fold = datetime.combine(day,local.time(),LOCAL)
        previous = select_forecast(facts,city,station,str(day),fold)
        training.append({'target_date':str(day),'forecast':previous,'label':label,
                         'forecast_high_c':str(number(previous['value_c'])),
                         'label_final_max_c':str(number(label['value_c'])),
                         'local_second':local.strftime('%H:%M:%S')})
    if not training: raise ValueError('INSUFFICIENT_PROVEN_DYNAMIC_TRAINING')
    if len({x['target_date'] for x in training}) != len(training): raise ValueError('DUPLICATE_TRAINING_LABEL')
    result = {'schema_version':'DYNAMIC_ASOF_WEATHER_INPUT_V1','city':city,'station':station,
              'target_date':target_date,'decision_as_of':decision_as_of,'candidate_freeze_identity':freeze_identity,
              'forecast':forecast,'observations':observations,
              'O_t':str(max(number(x['value_c']) for x in observations)),
              'training':sorted(training,key=lambda x:x['target_date'])}
    result['input_hash'] = hash_v1('PWM.DYNAMIC.ASOF_INPUT.V1',result)
    return result
