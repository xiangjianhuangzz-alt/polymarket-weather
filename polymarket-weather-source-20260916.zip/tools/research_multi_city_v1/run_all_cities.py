"""Bounded concurrent launcher for the three research-city entrypoints."""
from __future__ import annotations

import argparse
import json
import subprocess
import uuid
from datetime import datetime, time, timezone
from pathlib import Path
from typing import Callable
from zoneinfo import ZoneInfo

CITIES = ("Shanghai", "Beijing", "Guangzhou")
ENTRYPOINTS = {"Shanghai": "tools.research_forward_collection_v1.daily", "Beijing": "tools.research_multi_city_v1.forward", "Guangzhou": "tools.research_multi_city_v1.forward"}
PROJECT_ROOT = Path("D:/polymarket天气")
PYTHON_EXECUTABLE = PROJECT_ROOT / ".venv-strategy-tests-v1/Scripts/python.exe"
RUN_SCOPE = Path("D:/polymarket天气/data/strategy_analysis/wp03_multi_city_p1_closeout_fast_signal_v1/20260905T203601+0800").resolve()
SHANGHAI_CONFIG = Path("D:/polymarket天气/data/strategy_analysis/wp03_forward_blind_accumulation_v1/20260905T184548+0800/forward_config.json").resolve()
SHANGHAI = ZoneInfo("Asia/Shanghai")
UTC = timezone.utc


def _aware_utc_text(value: datetime) -> str:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("aware_utc_required")
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _within_window(now: datetime) -> bool:
    _aware_utc_text(now)
    local = now.astimezone(SHANGHAI).time()
    return time(7, 58) <= local < time(8, 0)


def _clock() -> datetime:
    return datetime.now(UTC)


def _load(configs: Path, city: str) -> dict:
    value = json.loads((configs / f"{city.lower()}.json").read_text(encoding="utf-8"))
    if value.get("city") != city or value.get("entrypoint") != ENTRYPOINTS[city] or not isinstance(value.get("config_path"), str):
        raise ValueError(f"invalid_{city}_wrapper")
    return value


def _record(city: str, requested_at: str, stdout: Path, stderr: Path, status: str, **extra: object) -> dict:
    return {"city": city, "pid": None, "requested_at": requested_at, "started_at": None, "ended_at": None, "exit_code": None, "stdout": str(stdout), "stderr": str(stderr), "status": status, **extra}


def _config_path(wrapper: dict, city: str, output_roots: set[Path]) -> Path:
    path = Path(wrapper["config_path"]).resolve()
    if city == "Shanghai":
        if path != SHANGHAI_CONFIG:
            raise ValueError("shanghai_config_binding_invalid")
        return path
    config = json.loads(path.read_text(encoding="utf-8"))
    root = config.get("output_root")
    if config.get("city") != city or not isinstance(root, str):
        raise ValueError("city_config_identity_invalid")
    output_root = Path(root).resolve()
    if RUN_SCOPE not in output_root.parents or output_root in output_roots:
        raise ValueError("city_output_root_invalid")
    output_roots.add(output_root)
    return path


def run_all(configs: Path, output_root: Path, now: datetime, popen: Callable = subprocess.Popen, clock: Callable[[], datetime] = _clock) -> dict:
    requested_at = _aware_utc_text(clock())
    if not _within_window(now):
        raise ValueError("outside_start_window")
    output_root = output_root.resolve()
    if RUN_SCOPE not in output_root.parents and output_root != RUN_SCOPE:
        raise ValueError("output_root_outside_run_scope")
    attempt = output_root / str(uuid.uuid4())
    attempt.mkdir(parents=True, exist_ok=False)
    launched, results, output_roots = [], {}, set()
    for city in CITIES:
        stdout_path, stderr_path = attempt / f"{city.lower()}.stdout.log", attempt / f"{city.lower()}.stderr.log"
        stdout = stderr = None
        started_at = None
        try:
            stdout, stderr = stdout_path.open("xb"), stderr_path.open("xb")
            wrapper = _load(configs, city)
            config_path = _config_path(wrapper, city, output_roots)
            if not config_path.is_file():
                raise ValueError("city_config_missing")
            command = [str(PYTHON_EXECUTABLE), "-X", "utf8", "-B", "-m", wrapper["entrypoint"], "--config", str(config_path), "--research-live-read"]
            started_at = _aware_utc_text(clock())
            launched.append((city, popen(command, cwd=PROJECT_ROOT, stdout=stdout, stderr=stderr), stdout, stderr, command, stdout_path, stderr_path, started_at))
        except (OSError, ValueError, KeyError, FileNotFoundError, json.JSONDecodeError) as exc:
            if stdout is not None:
                stdout.close()
            if stderr is not None:
                stderr.close()
            results[city] = _record(city, requested_at, stdout_path, stderr_path, "START_ERROR", started_at=started_at, ended_at=_aware_utc_text(clock()), start_error=str(exc))
    for city, process, stdout, stderr, command, stdout_path, stderr_path, started_at in launched:
        try:
            exit_code = process.wait()
            results[city] = _record(city, requested_at, stdout_path, stderr_path, "EXIT_0" if exit_code == 0 else "EXIT_NONZERO", pid=getattr(process, "pid", None), started_at=started_at, ended_at=_aware_utc_text(clock()), exit_code=exit_code, command=command)
        except OSError as exc:
            results[city] = _record(city, requested_at, stdout_path, stderr_path, "WAIT_ERROR", pid=getattr(process, "pid", None), started_at=started_at, ended_at=_aware_utc_text(clock()), wait_error=str(exc), command=command)
        finally:
            stdout.close()
            stderr.close()
    (attempt / "invocation.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    return {"attempt": str(attempt), "cities": results}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--configs", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--research-live-read", action="store_true")
    args = parser.parse_args()
    if not args.research_live_read:
        raise SystemExit("--research-live-read is required")
    print(json.dumps(run_all(args.configs, args.output_root, datetime.now(UTC))))


if __name__ == "__main__":
    main()
