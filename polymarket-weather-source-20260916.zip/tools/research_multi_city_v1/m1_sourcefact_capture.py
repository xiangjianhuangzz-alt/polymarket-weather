"""Bounded, append-only M1 SourceFact capture for AviationWeather TAF/METAR."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from strategy_v8.canonical import canonical_encode, canonical_time_v1, hash_v1

UTC = timezone.utc
LOCAL = ZoneInfo("Asia/Shanghai")
API = "https://aviationweather.gov/api/data"
USER_AGENT = "polymarket-weather-strategy-research/1.0"
CITIES = {"Shanghai": "ZSPD", "Beijing": "ZBAA", "Guangzhou": "ZGGG"}
WEATHEROL_SHANGHAI = "https://weatherol.cn/api/getData?aid=JCCN100117"


def _now() -> datetime:
    return datetime.now(UTC)


def _parse_time(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("SOURCE_TIME_NAIVE")
    return parsed.astimezone(UTC)


def _epoch_microseconds(value: datetime) -> int:
    delta = value - datetime(1970, 1, 1, tzinfo=UTC)
    return delta.days * 86_400_000_000 + delta.seconds * 1_000_000 + delta.microseconds


def _get(path: str, params: dict[str, str]) -> tuple[bytes, datetime]:
    url = f"{API}/{path}?{urllib.parse.urlencode(params)}"
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=20) as response:
        if response.status != 200:
            raise ValueError(f"SOURCE_HTTP_STATUS:{response.status}")
        raw = response.read()
    observed = _now()
    if not raw:
        raise ValueError("SOURCE_EMPTY_RESPONSE")
    return raw, observed


def _get_url(url: str) -> tuple[bytes, datetime]:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=20) as response:
        if response.status != 200:
            raise ValueError(f"SOURCE_HTTP_STATUS:{response.status}")
        raw = response.read()
    observed = _now()
    if not raw:
        raise ValueError("SOURCE_EMPTY_RESPONSE")
    return raw, observed


def _one_json(raw: bytes, station: str) -> dict:
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("SOURCE_JSON_INVALID") from exc
    if not isinstance(value, list) or len(value) != 1 or not isinstance(value[0], dict):
        raise ValueError("SOURCE_CARDINALITY_NOT_ONE")
    if value[0].get("icaoId") != station:
        raise ValueError("SOURCE_STATION_MISMATCH")
    return value[0]


def _taf_high(report: dict, target_date: str) -> int:
    raw = report.get("rawTAF")
    valid_from = report.get("validTimeFrom")
    if not isinstance(raw, str) or not raw or isinstance(valid_from, bool):
        raise ValueError("TAF_REQUIRED_FIELD_MISSING")
    anchor = datetime.fromtimestamp(float(valid_from), UTC)
    values: list[int] = []
    for encoded, day_text, hour_text in re.findall(r"\bTX(M?\d{2})/(\d{2})(\d{2})Z", raw):
        temperature = -int(encoded[1:]) if encoded.startswith("M") else int(encoded)
        for offset in (-1, 0, 1):
            month = anchor.month + offset
            year = anchor.year
            if month < 1:
                month += 12
                year -= 1
            elif month > 12:
                month -= 12
                year += 1
            try:
                instant = datetime(year, month, int(day_text), int(hour_text), tzinfo=UTC)
            except ValueError:
                continue
            if abs((instant - anchor).total_seconds()) <= 4 * 86400 and instant.astimezone(LOCAL).date().isoformat() == target_date:
                values.append(temperature)
    if not values:
        raise ValueError("TAF_D0_TX_MISSING")
    return max(values) * 1000


def _publication_id(payload: dict) -> str:
    return hash_v1("PWM.IIC2.SOURCE_PUBLICATION.V1", payload)


def _revision_id(rank_scheme_id: str, rank: int, token: str, source_time: str) -> str:
    return hash_v1("V8_SOURCE_REVISION_ID_V1", {
        "schema_version": "SOURCE_REVISION_IDENTITY_V1",
        "rank_scheme_id": rank_scheme_id,
        "source_revision_rank": rank,
        "provider_revision_token": token,
        "source_time": source_time,
    })


def _source_fact_id(city: str, binding: str, publication: str, revision: str, canonical_hash: str) -> str:
    natural = {"city": city, "source_binding_id": binding,
               "source_publication_id": publication, "source_revision_id": revision}
    return hashlib.sha256(b"V8_SOURCE_FACT_V1\x00" + canonical_encode(natural) + bytes.fromhex(canonical_hash)).hexdigest()


def _atomic_new(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() == payload:
            return
        raise FileExistsError(f"IMMUTABLE_PATH_CONFLICT:{path}")
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _commit(root: Path, city: str, target_date: str, raw: bytes, draft: dict, projection: dict) -> dict:
    raw_hash = hashlib.sha256(raw).hexdigest()
    parsed = json.loads(raw.decode("utf-8"))
    canonical_hash = hashlib.sha256(canonical_encode(parsed)).hexdigest()
    fact = dict(draft)
    fact["raw_payload_hash"] = raw_hash
    fact["canonical_payload_hash"] = canonical_hash
    fact["committed_at_utc"] = canonical_time_v1(_now())
    fact["source_fact_id"] = _source_fact_id(city, fact["source_binding_id"], fact["source_publication_id"], fact["source_revision_id"], canonical_hash)
    normalized = {
        "schema_version": "NORMALIZED_SOURCE_FACT_V1",
        "source_fact_id": fact["source_fact_id"],
        "normalization_contract_hash": hash_v1("V8_NORMALIZATION_CONTRACT_V1", {
            "source_binding_id": fact["source_binding_id"], "projection_kind": projection["projection_kind"],
            "parser_id": "M1_AVIATIONWEATHER_JSON_PARSER_V1"}),
        "projection_kind": projection["projection_kind"],
        "canonical_projection": projection["value"],
        "canonical_projection_hash": hash_v1("PWM.IIC2.NORMALIZED_PROJECTION.V1", projection),
    }
    normalized["normalized_fact_id"] = hash_v1("PWM.IIC2.NORMALIZED_SOURCE_FACT.V1", {
        key: normalized[key] for key in ("source_fact_id", "normalization_contract_hash", "projection_kind", "canonical_projection_hash")})
    day = root / city / target_date
    commits = day / "commits"
    commits.mkdir(parents=True, exist_ok=True)
    existing = sorted(commits.glob("*.json"))
    for path in existing:
        prior = json.loads(path.read_text(encoding="utf-8"))
        old = prior["raw_source_fact"]
        if (old["source_binding_id"], old["source_publication_id"], old["source_revision_id"]) == (fact["source_binding_id"], fact["source_publication_id"], fact["source_revision_id"]):
            if old["canonical_payload_hash"] != canonical_hash:
                raise ValueError("E_SOURCE_FACT_ID_CONFLICT")
            return prior
    _atomic_new(root / "raw_blobs" / f"{raw_hash}.bin", raw)
    sequence = len(existing) + 1
    bundle = {"schema_version": "M1_SOURCEFACT_COMMIT_BUNDLE_V1", "sequence": sequence,
              "raw_blob_relative_path": f"raw_blobs/{raw_hash}.bin",
              "raw_source_fact": fact, "normalized_source_fact": normalized}
    bundle["bundle_hash"] = hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", bundle)
    _atomic_new(commits / f"{sequence:020d}.json", canonical_encode(bundle))
    return bundle


def capture_taf(root: Path, city: str, station: str, target_date: str) -> dict:
    raw, observed = _get("taf", {"ids": station, "format": "json"})
    report = _one_json(raw, station)
    issue = _parse_time(report.get("issueTime", ""))
    issue_text = canonical_time_v1(issue)
    rank = _epoch_microseconds(issue)
    binding = f"aviationweather_taf_{station.lower()}"
    publication_payload = {"schema_version": "AVIATIONWEATHER_TAF_TARGET_DATE_PUBLICATION_V1",
                           "city": city, "source_binding_id": binding, "station": station,
                           "product": "TAF", "target_date": target_date}
    draft = {"schema_version": "RAW_SOURCE_FACT_V1", "city": city, "source_binding_id": binding,
             "source_publication_id": _publication_id(publication_payload),
             "source_revision_id": _revision_id("AVIATIONWEATHER_TAF_ISSUE_TIME_V1", rank, issue_text, issue_text),
             "source_revision_rank": rank, "raw_payload_encoding": "UTF8_JSON",
             "effective_at_utc": issue_text, "observed_at_utc": canonical_time_v1(observed)}
    projection = {"projection_kind": "FORECAST_HIGH_C_MILLI", "value": {
        "city": city, "target_date": target_date,
        "local_second": observed.astimezone(LOCAL).strftime("%H:%M:%S"),
        "forecast_high_c_milli": _taf_high(report, target_date)}}
    return _commit(root, city, target_date, raw, draft, projection)


def capture_weatherol_shanghai(root: Path, target_date: str) -> dict:
    raw, observed = _get_url(WEATHEROL_SHANGHAI)
    try:
        payload = json.loads(raw.decode("utf-8"))
        current = payload["data"]["current"]["current"]
        forecasts = payload["data"]["forecast15d"]
    except (UnicodeDecodeError, json.JSONDecodeError, KeyError, TypeError) as exc:
        raise ValueError("WEATHEROL_JSON_INVALID") from exc
    if payload.get("code") != 200 or current.get("jcid") != "JCCN100117" or current.get("airportname") != "上海浦东国际机场":
        raise ValueError("WEATHEROL_SOURCE_IDENTITY_INVALID")
    match = re.fullmatch(r"([01]\d|2[0-3]):([0-5]\d)", str(current.get("reporttime", "")))
    if match is None:
        raise ValueError("WEATHEROL_REPORT_MINUTE_INVALID")
    local_observed = observed.astimezone(LOCAL)
    effective = local_observed.replace(hour=int(match.group(1)), minute=int(match.group(2)), second=0, microsecond=0)
    if effective > local_observed + timedelta(minutes=5):
        effective -= timedelta(days=1)
    target = datetime.fromisoformat(target_date).date()
    matches = []
    for item in forecasts if isinstance(forecasts, list) else []:
        try:
            month, day = (int(part) for part in str(item["forecasttime"]).split("/"))
            candidate = target.replace(month=month, day=day)
            if (candidate - target).days < -180:
                candidate = candidate.replace(year=candidate.year + 1)
            if candidate == target:
                matches.append(int(str(item["temperature_am"])) * 1000)
        except (KeyError, TypeError, ValueError):
            continue
    if len(matches) != 1:
        raise ValueError("WEATHEROL_D0_TARGET_NOT_UNIQUE")
    report_minute = match.group(0)
    rank = int(match.group(1)) * 60 + int(match.group(2))
    binding = "weatherol_shanghai_weatherol_d0"
    publication_payload = {"schema_version": "WEATHEROL_D0_TARGET_DATE_PUBLICATION_V1",
                           "city": "Shanghai", "source_binding_id": binding,
                           "station": "ZSPD", "provider_airport_id": "JCCN100117",
                           "product": "WEATHEROL_D0", "target_date": target_date}
    revision = hash_v1("V8_SOURCE_REVISION_ID_V1", {
        "schema_version": "SOURCE_REVISION_IDENTITY_V1",
        "rank_scheme_id": "WEATHEROL_D0_LOCAL_REPORT_MINUTE_V1",
        "source_revision_rank": rank,
        "provider_revision_token": f"{target_date}T{report_minute}",
        "source_time": None})
    draft = {"schema_version": "RAW_SOURCE_FACT_V1", "city": "Shanghai", "source_binding_id": binding,
             "source_publication_id": _publication_id(publication_payload), "source_revision_id": revision,
             "source_revision_rank": rank, "raw_payload_encoding": "UTF8_JSON",
             "effective_at_utc": canonical_time_v1(effective), "observed_at_utc": canonical_time_v1(observed)}
    projection = {"projection_kind": "FORECAST_HIGH_C_MILLI", "value": {
        "city": "Shanghai", "target_date": target_date,
        "local_second": observed.astimezone(LOCAL).strftime("%H:%M:%S"),
        "forecast_high_c_milli": matches[0]}}
    return _commit(root, "Shanghai", target_date, raw, draft, projection)


def _capture_metar_at(root: Path, city: str, station: str, target_date: str, source_report_time: str) -> dict:
    raw, observed = _get("metar", {"ids": station, "format": "json", "date": source_report_time})
    report = _one_json(raw, station)
    report_time = _parse_time(report.get("reportTime", ""))
    report_text = canonical_time_v1(report_time)
    report_type = report.get("metarType")
    if report_type not in ("METAR", "SPECI") or isinstance(report.get("temp"), bool) or not isinstance(report.get("temp"), (int, float)):
        raise ValueError("METAR_REQUIRED_FIELD_INVALID")
    rank_scheme = f"AVIATIONWEATHER_{report_type}_REPORT_TIME_V1"
    token = f"{station}:{report_type}:{report_text}"
    rank = _epoch_microseconds(report_time)
    binding = f"aviationweather_{report_type.lower()}_{station.lower()}"
    publication_payload = {"schema_version": "AVIATIONWEATHER_METAR_REPORT_PUBLICATION_V1",
                           "city": city, "source_binding_id": binding, "station": station,
                           "report_type": report_type, "report_time_utc": report_text}
    draft = {"schema_version": "RAW_SOURCE_FACT_V1", "city": city, "source_binding_id": binding,
             "source_publication_id": _publication_id(publication_payload),
             "source_revision_id": _revision_id(rank_scheme, rank, token, report_text),
             "source_revision_rank": rank, "raw_payload_encoding": "UTF8_JSON",
             "effective_at_utc": report_text, "observed_at_utc": canonical_time_v1(observed)}
    projection = {"projection_kind": "METAR_SPECI_TEMPERATURE_C_MILLI", "value": {
        "city": city, "station": station, "report_type": report_type,
        "report_time_utc": report_text, "temperature_c_milli": int(round(float(report["temp"]) * 1000))}}
    return _commit(root, city, target_date, raw, draft, projection)


def _metar_discovery(station: str, hours: int) -> list[dict]:
    discovery, _ = _get("metar", {"ids": station, "format": "json", "hours": str(hours)})
    reports = json.loads(discovery.decode("utf-8"))
    return [item for item in reports if isinstance(item, dict) and item.get("icaoId") == station
            and item.get("metarType") in ("METAR", "SPECI")]


def capture_latest_metar(root: Path, city: str, station: str, target_date: str) -> dict:
    eligible = _metar_discovery(station, 2)
    if not eligible:
        raise ValueError("METAR_REPORT_MISSING")
    latest = max(eligible, key=lambda item: _parse_time(item["reportTime"]))
    return _capture_metar_at(root, city, station, target_date, latest["reportTime"])


def sweep_metar_day(root: Path, city: str, station: str, target_date: str, hours: int = 24) -> list[dict]:
    reports = _metar_discovery(station, hours)
    times = sorted({item["reportTime"] for item in reports
                    if _parse_time(item["reportTime"]).astimezone(LOCAL).date().isoformat() == target_date})
    if not times:
        raise ValueError("METAR_TARGET_DAY_REPORTS_MISSING")
    return [_capture_metar_at(root, city, station, target_date, report_time) for report_time in times]


def capture(root: Path, cities: list[str]) -> dict:
    now = _now()
    target = now.astimezone(LOCAL).date().isoformat()
    result = {"schema_version": "M1_BOUNDED_CAPTURE_RESULT_V1", "started_at_utc": canonical_time_v1(now),
              "target_date": target, "results": [], "failures": []}
    for city in cities:
        station = CITIES[city]
        operations = (("WEATHEROL_D0", lambda a, b, c, d: capture_weatherol_shanghai(a, d)),
                      ("METAR", capture_latest_metar)) if city == "Shanghai" else (("TAF", capture_taf), ("METAR", capture_latest_metar))
        for kind, operation in operations:
            try:
                bundle = operation(root, city, station, target)
                result["results"].append({"city": city, "kind": kind,
                                          "source_fact_id": bundle["raw_source_fact"]["source_fact_id"],
                                          "bundle_hash": bundle["bundle_hash"]})
            except Exception as exc:
                result["failures"].append({"city": city, "kind": kind,
                                           "error_type": type(exc).__name__, "error_reason": str(exc)})
    result["completed_at_utc"] = canonical_time_v1(_now())
    result["status"] = "PASS" if not result["failures"] else "PARTIAL"
    return result


def sweep(root: Path, cities: list[str]) -> dict:
    target = _now().astimezone(LOCAL).date().isoformat()
    result = {"schema_version": "M1_BOUNDED_METAR_SWEEP_RESULT_V1", "target_date": target,
              "started_at_utc": canonical_time_v1(_now()), "results": [], "failures": []}
    for city in cities:
        try:
            bundles = sweep_metar_day(root, city, CITIES[city], target)
            result["results"].append({"city": city, "committed_report_count": len(bundles),
                                      "source_fact_ids": [item["raw_source_fact"]["source_fact_id"] for item in bundles]})
        except Exception as exc:
            result["failures"].append({"city": city, "error_type": type(exc).__name__, "error_reason": str(exc)})
    result["completed_at_utc"] = canonical_time_v1(_now())
    result["status"] = "PASS" if not result["failures"] else "PARTIAL"
    return result


def observe(root: Path, cities: list[str]) -> dict:
    target = _now().astimezone(LOCAL).date().isoformat()
    result = {"schema_version": "M1_BOUNDED_OBSERVATION_RESULT_V1", "target_date": target,
              "started_at_utc": canonical_time_v1(_now()), "results": [], "failures": []}
    for city in cities:
        try:
            bundle = capture_latest_metar(root, city, CITIES[city], target)
            result["results"].append({"city": city, "source_fact_id": bundle["raw_source_fact"]["source_fact_id"]})
        except Exception as exc:
            result["failures"].append({"city": city, "error_type": type(exc).__name__, "error_reason": str(exc)})
    result["completed_at_utc"] = canonical_time_v1(_now())
    result["status"] = "PASS" if not result["failures"] else "PARTIAL"
    return result


def verify_store(root: Path) -> dict:
    bundles = 0
    facts: list[str] = []
    for city in CITIES:
        city_root = root / city
        if not city_root.exists():
            continue
        for day in sorted(path for path in city_root.iterdir() if path.is_dir()):
            paths = sorted((day / "commits").glob("*.json"))
            if [path.name for path in paths] != [f"{index:020d}.json" for index in range(1, len(paths) + 1)]:
                raise ValueError("COMMIT_WATERLINE_NOT_CONTIGUOUS")
            natural: dict[tuple[str, str, str], str] = {}
            for index, path in enumerate(paths, 1):
                bundle = json.loads(path.read_text(encoding="utf-8"))
                claimed = bundle.pop("bundle_hash")
                if bundle.get("sequence") != index or hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", bundle) != claimed:
                    raise ValueError("COMMIT_BUNDLE_HASH_INVALID")
                fact = bundle["raw_source_fact"]
                raw_path = root / bundle["raw_blob_relative_path"]
                raw = raw_path.read_bytes()
                if hashlib.sha256(raw).hexdigest() != fact["raw_payload_hash"]:
                    raise ValueError("RAW_PAYLOAD_HASH_INVALID")
                canonical_hash = hashlib.sha256(canonical_encode(json.loads(raw.decode("utf-8")))).hexdigest()
                if canonical_hash != fact["canonical_payload_hash"]:
                    raise ValueError("CANONICAL_PAYLOAD_HASH_INVALID")
                expected = _source_fact_id(fact["city"], fact["source_binding_id"], fact["source_publication_id"], fact["source_revision_id"], canonical_hash)
                if expected != fact["source_fact_id"]:
                    raise ValueError("SOURCE_FACT_ID_INVALID")
                if any(_parse_time(fact[key]) > _parse_time(fact["committed_at_utc"])
                       for key in ("effective_at_utc", "observed_at_utc")):
                    raise ValueError("SOURCE_FACT_TIME_ORDER_INVALID")
                key = (fact["source_binding_id"], fact["source_publication_id"], fact["source_revision_id"])
                if key in natural and natural[key] != canonical_hash:
                    raise ValueError("E_SOURCE_FACT_ID_CONFLICT")
                natural[key] = canonical_hash
                bundles += 1
                facts.append(fact["source_fact_id"])
    return {"schema_version": "M1_SOURCEFACT_STORE_VERIFICATION_V1", "status": "PASS",
            "bundle_count": bundles, "source_fact_ids": sorted(facts)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("capture", "observe", "sweep", "verify"))
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--cities", nargs="+", choices=tuple(CITIES), default=list(CITIES))
    args = parser.parse_args()
    if args.command == "capture":
        outcome = capture(args.root.resolve(), args.cities)
    elif args.command == "observe":
        outcome = observe(args.root.resolve(), args.cities)
    elif args.command == "sweep":
        outcome = sweep(args.root.resolve(), args.cities)
    else:
        outcome = verify_store(args.root.resolve())
    print(json.dumps(outcome, ensure_ascii=False, sort_keys=True))
    return 0 if outcome["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
