"""Pure routing for the user-frozen dynamic actions; no model or I/O."""
from dataclasses import dataclass
from datetime import datetime, time
from zoneinfo import ZoneInfo

LOCAL = ZoneInfo('Asia/Shanghai')
CITIES = {'Shanghai': 'ZSPD', 'Beijing': 'ZBAA', 'Guangzhou': 'ZGGG'}
ROUTES = {
    ('WindowBoundaryV1', 'OPEN'): 'INITIAL_WEATHER_EVALUATION',
    ('SourceFactV1', 'LEGAL_FORECAST_REVISION'): 'WEATHER_RECOMPUTE',
    ('SourceFactV1', 'LEGAL_METAR_OR_SPECI'): 'WEATHER_RECOMPUTE',
    ('SourceFactV1', 'MARKET_SOURCE_FACT'): 'MARKET_ONLY_REEVALUATION_REQUEST',
    ('FreshnessBoundaryV1', 'WEATHER_FRESH_TO_STALE'): 'WEATHER_CANDIDATE_INVALIDATE',
    ('FreshnessBoundaryV1', 'MARKET_FRESH_TO_STALE'): 'MARKET_CANDIDATE_INVALIDATE',
    ('ConfigIdentityChangeV1', 'CONFIG_CHANGE'): 'FAIL_CLOSED_VERSION_MISMATCH',
    ('SystemFailureTransitionV1', 'SYSTEM_FAILURE'): 'FAIL_CLOSED',
    ('SystemFailureTransitionV1', 'RECOVERY'): 'HEALTH_RECOVERED',
    ('WindowBoundaryV1', 'CLOSE'): 'WINDOW_CLOSE_NO_NEW_DECISION',
}
WEATHER_ACTIONS = {'INITIAL_WEATHER_EVALUATION', 'WEATHER_RECOMPUTE'}

def aware(value):
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError('AWARE_TIME_REQUIRED')
    return value

@dataclass(frozen=True)
class DynamicEvent:
    city: str
    cause_type: str
    cause_object_id: str
    transition_kind: str
    effective_at_utc: datetime

    def key(self):
        return [self.city, self.cause_type, self.cause_object_id, self.transition_kind]

def route(event, asof):
    aware(asof); aware(event.effective_at_utc)
    if event.city not in CITIES or not event.cause_object_id:
        raise ValueError('EVENT_IDENTITY_INVALID')
    if event.effective_at_utc > asof:
        raise ValueError('FUTURE_FACT_REJECTED')
    if event.cause_type == 'NO_NEW_CAUSE_OR_STATE':
        return None
    action = ROUTES.get((event.cause_type, event.transition_kind), 'FAIL_CLOSED')
    local = asof.astimezone(LOCAL)
    within = time(7) <= local.time() < time(16)
    if event.cause_type == 'WindowBoundaryV1':
        effective = event.effective_at_utc.astimezone(LOCAL)
        expected = time(7) if event.transition_kind == 'OPEN' else time(16)
        if effective.date() != local.date() or effective.time() != expected:
            raise ValueError('WINDOW_BOUNDARY_IDENTITY_INVALID')
    if not within and action in WEATHER_ACTIONS | {'MARKET_ONLY_REEVALUATION_REQUEST'}:
        return 'FAIL_CLOSED'
    return action
