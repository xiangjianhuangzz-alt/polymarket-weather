"""Beijing/Guangzhou public market read adapter; no weather-model inputs."""
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta, datetime
from decimal import Decimal
import hashlib
import json
from urllib.parse import urlencode

from tools.research_forward_collection_v1.collector import CaptureStore, CaptureStatus, FrameInput, YesAsk
from tools.research_forward_collection_v1.daily import (MONTHS, UTC, anchor, load, parsed, public_get,
    save, save_response, sha, stamp, utcnow, wait_until)


def slug(city, target):
    if city not in ("Beijing", "Guangzhou"):
        raise ValueError("NEW_TRACK_CITY_REQUIRED")
    return f"highest-temperature-in-{city.lower()}-on-{MONTHS[target.month-1]}-{target.day}-{target.year}"


def members(event, city, target):
    if event.get("slug") != slug(city, target) or not event.get("id") or not isinstance(event.get("markets"), list) or not event["markets"]:
        raise ValueError("EVENT_CITY_DATE_OR_POPULATION_MISMATCH")
    result, identities = [], set()
    for ordinal, market in enumerate(event["markets"]):
        item = {"city": city, "target_date": target.isoformat(), "ordinal": ordinal, "event_id": event["id"]}
        try:
            outcomes, tokens = market["outcomes"], market["clobTokenIds"]
            outcomes = json.loads(outcomes) if isinstance(outcomes, str) else outcomes
            tokens = json.loads(tokens) if isinstance(tokens, str) else tokens
            if not isinstance(outcomes, list) or not isinstance(tokens, list) or len(outcomes) != len(tokens):
                raise ValueError("OUTCOME_TOKEN_LENGTH")
            yes = [i for i, value in enumerate(outcomes) if str(value).lower() == "yes"]
            if len(yes) != 1 or not str(tokens[yes[0]]).isdigit():
                raise ValueError("UNIQUE_YES_TOKEN_REQUIRED")
            item.update(market_id=str(market["id"]), condition_id=market["conditionId"], yes_token_id=str(tokens[yes[0]]),
                        bucket=market["groupItemTitle"], rule=market["description"])
            if any(item[k] in (None, "") for k in ("market_id", "condition_id", "bucket", "rule")):
                raise ValueError("IDENTITY_OR_RULE_MISSING")
            for kind in ("market_id", "condition_id", "yes_token_id"):
                key = (kind, item[kind])
                if key in identities:
                    raise ValueError("DUPLICATE_POPULATION_IDENTITY")
                identities.add(key)
        except (KeyError, TypeError, ValueError, IndexError) as exc:
            item["identity_error"] = str(exc)
        result.append(item)
    if any(r.get("identity_error") == "DUPLICATE_POPULATION_IDENTITY" for r in result):
        for item in result:
            item["identity_error"] = "DUPLICATE_POPULATION_IDENTITY"
    return result


def book_record(directory, member, response, target, partition_hash):
    record = dict(member, status="ERROR", capture_at=response.requested_at, observed_at=response.received_at,
                  snapshot_sha256=hashlib.sha256(response.body).hexdigest(), partition_sha256=partition_hash,
                  effective_at=None, freshness_seconds=None)
    try:
        book = save_response(directory / "http", response)
        if str(book.get("asset_id")) != member["yes_token_id"] or str(book.get("market")) != member["condition_id"]:
            raise ValueError("BOOK_MARKET_TOKEN_MISMATCH")
        millis = Decimal(str(book["timestamp"]))
        if not millis.is_finite() or millis != millis.to_integral_value():
            raise ValueError("INVALID_SOURCE_TIMESTAMP")
        effective = datetime.fromtimestamp(int(millis)//1000, UTC) + timedelta(milliseconds=int(millis)%1000)
        requested, received, cutoff = parsed(response.requested_at), parsed(response.received_at), anchor(target)
        record.update(effective_at=stamp(effective), freshness_seconds=str((cutoff-effective).total_seconds()))
        if not isinstance(book.get("asks"), list):
            raise ValueError("FULL_ASK_ARRAY_REQUIRED")
        levels = tuple(sorted((YesAsk(str(r["price"]), str(r["size"])) for r in book["asks"]), key=lambda r: Decimal(r.price)))
        status = CaptureStatus.ACCEPTED
        values = [(Decimal(r.price), Decimal(r.size)) for r in levels]
        if any(not p.is_finite() or not q.is_finite() or not 0 < p <= 1 or q <= 0 for p,q in values) or len({p for p,q in values}) != len(values) or received < requested or effective > received:
            status = CaptureStatus.REJECTED_INCONSISTENT
        elif max(effective, requested, received) > cutoff:
            status = CaptureStatus.REJECTED_FUTURE
        elif cutoff-min(effective, requested) > timedelta(seconds=60):
            status = CaptureStatus.REJECTED_STALE
        frame = FrameInput(record["snapshot_sha256"], response.body, member["city"], target.isoformat(),
            "POLYMARKET_TEMPERATURE", "PUBLISHED_UNIVERSE_V1", member["market_id"], member["yes_token_id"],
            hashlib.sha256(member["rule"].encode()).hexdigest(), response.requested_at, response.received_at,
            stamp(effective), None, "FULL_DEPTH", True, False, levels, "5")
        saved = CaptureStore(directory / "store").append(frame, status)
        feasibility = load(saved["record_path"])["execution_feasibility"]
        record.update(frame=saved, capture_status=status.value, execution_feasibility=feasibility,
                      ladder_levels=len(levels), ladder_quantity=str(sum((q for p,q in values), Decimal(0))),
                      best_ask=levels[0].price if levels else None,
                      completeness_basis="Public GET /book complete asks array; live compatibility unverified")
        if status == CaptureStatus.ACCEPTED:
            record["status"] = "AVAILABLE" if feasibility["fillable"] else "UNFILLABLE"
        elif status in (CaptureStatus.REJECTED_STALE, CaptureStatus.REJECTED_FUTURE):
            record["status"] = "STALE"
    except Exception as exc:
        record["reason"] = type(exc).__name__ + ": " + str(exc)
    save(directory / "record.json", record)
    return record


def capture(day, city, target, fetch=public_get, clock=utcnow, sleep=None):
    root = day / "market"
    root.mkdir()
    try:
        response = fetch("https://gamma-api.polymarket.com/events/slug/" + slug(city, target))
        population = members(save_response(root / "event", response), city, target)
        identity = sha(root / "event/response.raw")
        save(root / "population.json", {"city": city, "target_date": target.isoformat(), "members": population, "event_raw_sha256": identity})
        if sleep is None:
            wait_until(anchor(target)-timedelta(seconds=60), clock)
        else:
            wait_until(anchor(target)-timedelta(seconds=60), clock, sleep)
        def one(member):
            directory = root / f"member_{member['ordinal']:04d}"
            if member.get("identity_error") or clock() >= anchor(target):
                value = dict(member, status="ERROR" if member.get("identity_error") else "MISSING", reason=member.get("identity_error", "ANCHOR_PASSED"))
                save(directory / "record.json", value)
                return value
            try:
                return book_record(directory, member, fetch("https://clob.polymarket.com/book?" + urlencode({"token_id": member["yes_token_id"]})), target, identity)
            except Exception as exc:
                value = dict(member, status="ERROR", reason=str(exc))
                save(directory / "request_error.json", value)
                return value
        with ThreadPoolExecutor(max_workers=4) as pool:
            records = list(pool.map(one, population))
        result = {"status": "MARKET_COMPLETE" if all(r["status"] == "AVAILABLE" for r in records) else "MARKET_PARTIAL", "city": city, "members": records}
    except Exception as exc:
        result = {"status": "MARKET_MISSING", "city": city, "reason": str(exc)}
    save(root / "result.json", result)
    return result
