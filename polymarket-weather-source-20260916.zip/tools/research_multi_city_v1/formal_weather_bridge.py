"""Pure bridge from verified M1 capture bundles to formal weather inputs.

The bridge deliberately stops before SourceAnchorSetV1 and NormalizedDay.  A
caller must provide a previously persisted receipt that covers exactly the
capture bytes being converted; validating a fixture receipt is not evidence of
an actual historical read boundary.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path
from zoneinfo import ZoneInfo

from strategy_v8.canonical import canonical_encode, canonical_time_v1, hash_v1, parse_canonical_time_v1
from strategy_v8.contracts import City
from strategy_engine.data.normalization import SOURCE_BINDING_REGISTRY_BY_ID, SOURCE_BINDING_REGISTRY_HASH
from strategy_engine.data.records import (
    OBSERVATION_STATION,
    OBSERVATION_SOURCE_BINDINGS,
    SOURCE_BINDING,
    ForecastInput,
    ObservationInput,
    TemperatureUnit,
    Visibility,
    normalized_fact_id_v1,
    source_fact_id_v1,
)

from .m1_bundle_adapter import _derived_projection
from .m1_sourcefact_capture import _epoch_microseconds, _parse_time, _revision_id, _source_fact_id, _taf_high


_LOCAL = ZoneInfo("Asia/Shanghai")
_CAPTURE_BINDINGS = {
    ("Shanghai", "FORECAST"): "weatherol_shanghai_weatherol_d0",
    ("Beijing", "FORECAST"): "aviationweather_taf_zbaa",
    ("Guangzhou", "FORECAST"): "aviationweather_taf_zggg",
    ("Shanghai", "METAR"): "aviationweather_metar_zspd",
    ("Beijing", "METAR"): "aviationweather_metar_zbaa",
    ("Guangzhou", "METAR"): "aviationweather_metar_zggg",
    ("Shanghai", "SPECI"): "aviationweather_speci_zspd",
    ("Beijing", "SPECI"): "aviationweather_speci_zbaa",
    ("Guangzhou", "SPECI"): "aviationweather_speci_zggg",
}
_CAPTURE_CITY = {
    City.SHANGHAI: "Shanghai",
    City.BEIJING: "Beijing",
    City.GUANGZHOU: "Guangzhou",
}
_FORMAL_CITY = {value: key for key, value in _CAPTURE_CITY.items()}


@dataclass(frozen=True, slots=True)
class FormalWeatherBridgeResult:
    forecasts: tuple[ForecastInput, ...]
    observations: tuple[ObservationInput, ...]
    provenance: tuple[dict[str, object], ...]


def receipt_payload(city: str, target_date: str, read_completed_at_utc: str, entries: tuple[dict[str, object], ...]) -> dict[str, object]:
    """Return the canonical receipt payload; callers persist it outside this bridge."""
    return {
        "schema_version": "FORMAL_WEATHER_CAPTURE_READ_RECEIPT_V1",
        "city": city,
        "target_date": target_date,
        "read_completed_at_utc": read_completed_at_utc,
        "entries": list(entries),
    }


def receipt_hash(payload: dict[str, object]) -> str:
    return hash_v1("PWM.FORMAL_WEATHER_CAPTURE_READ_RECEIPT.V1", payload)


def _utc(value: object):
    if not isinstance(value, str):
        raise ValueError("BRIDGE_TIME_INVALID")
    return parse_canonical_time_v1(value)


def _safe_root(root: Path) -> Path:
    resolved = Path(root).resolve()
    if not resolved.is_dir():
        raise ValueError("BRIDGE_ROOT_MISSING")
    return resolved


def _read_bundle(root: Path, path: Path, sequence: int) -> tuple[dict[str, object], bytes]:
    if path.name != f"{sequence:020d}.json":
        raise ValueError("BRIDGE_SEQUENCE_INVALID")
    try:
        bundle = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("BRIDGE_BUNDLE_INVALID") from exc
    claimed = bundle.pop("bundle_hash", None)
    if bundle.get("schema_version") != "M1_SOURCEFACT_COMMIT_BUNDLE_V1" or bundle.get("sequence") != sequence:
        raise ValueError("BRIDGE_BUNDLE_IDENTITY_INVALID")
    if not isinstance(claimed, str) or hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", bundle) != claimed:
        raise ValueError("BRIDGE_BUNDLE_HASH_INVALID")
    relative = bundle.get("raw_blob_relative_path")
    raw_fact = bundle.get("raw_source_fact")
    if not isinstance(relative, str) or not isinstance(raw_fact, dict):
        raise ValueError("BRIDGE_BUNDLE_FIELDS_INVALID")
    raw_hash = raw_fact.get("raw_payload_hash")
    if raw_fact.get("schema_version") != "RAW_SOURCE_FACT_V1" or raw_fact.get("raw_payload_encoding") != "UTF8_JSON":
        raise ValueError("BRIDGE_CAPTURE_SCHEMA_INVALID")
    normalized = bundle.get("normalized_source_fact")
    if not isinstance(normalized, dict) or normalized.get("schema_version") != "NORMALIZED_SOURCE_FACT_V1":
        raise ValueError("BRIDGE_CAPTURE_SCHEMA_INVALID")
    if not isinstance(raw_hash, str) or relative != f"raw_blobs/{raw_hash}.bin":
        raise ValueError("BRIDGE_RAW_PATH_INVALID")
    raw_path = (root / relative).resolve()
    if not raw_path.is_relative_to(root / "raw_blobs") or not raw_path.is_file():
        raise ValueError("BRIDGE_RAW_PATH_INVALID")
    raw = raw_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != raw_hash:
        raise ValueError("BRIDGE_RAW_HASH_INVALID")
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("BRIDGE_RAW_JSON_INVALID") from exc
    canonical_hash = hashlib.sha256(canonical_encode(parsed)).hexdigest()
    if canonical_hash != raw_fact.get("canonical_payload_hash"):
        raise ValueError("BRIDGE_CANONICAL_HASH_INVALID")
    bundle["bundle_hash"] = claimed
    return bundle, raw


def _observation_milli(value: object) -> int:
    """Validate the capture number before adapter float coercion can see it."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("BRIDGE_OBSERVATION_TEMPERATURE_INVALID")
    try:
        with localcontext() as context:
            context.prec = 80
            scaled = Decimal(str(value)) * Decimal(1000)
            if not scaled.is_finite() or scaled != scaled.to_integral_value():
                raise ValueError("BRIDGE_OBSERVATION_TEMPERATURE_INVALID")
            return int(scaled)
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("BRIDGE_OBSERVATION_TEMPERATURE_INVALID") from exc


def _capture_revision(raw_fact: dict[str, object], city: str, fact_type: str, raw: object, target_date: str) -> None:
    rank = raw_fact.get("source_revision_rank")
    if isinstance(rank, bool) or not isinstance(rank, int):
        raise ValueError("BRIDGE_CAPTURE_RANK_INVALID")
    if fact_type == "FORECAST" and city == "Shanghai":
        current = raw["data"]["current"]["current"]
        text = current.get("reporttime")
        if not isinstance(text, str) or len(text) != 5 or text[2] != ":":
            raise ValueError("BRIDGE_WEATHEROL_REPORT_MINUTE_INVALID")
        try:
            hour, minute = int(text[:2]), int(text[3:])
        except ValueError as exc:
            raise ValueError("BRIDGE_WEATHEROL_REPORT_MINUTE_INVALID") from exc
        if not 0 <= hour <= 23 or not 0 <= minute <= 59:
            raise ValueError("BRIDGE_WEATHEROL_REPORT_MINUTE_INVALID")
        scheme, token, source_time = "WEATHEROL_D0_LOCAL_REPORT_MINUTE_V1", f"{target_date}T{text}", None
        expected_rank = hour * 60 + minute
        expected = hash_v1("V8_SOURCE_REVISION_ID_V1", {"schema_version": "SOURCE_REVISION_IDENTITY_V1", "rank_scheme_id": scheme,
                                                           "source_revision_rank": expected_rank, "provider_revision_token": token, "source_time": source_time})
    else:
        report = raw[0]
        source_time = canonical_time_v1(_parse_time(report["issueTime"] if fact_type == "FORECAST" else report["reportTime"]))
        if fact_type == "FORECAST":
            scheme, token = "AVIATIONWEATHER_TAF_ISSUE_TIME_V1", source_time
        else:
            scheme, token = f"AVIATIONWEATHER_{fact_type}_REPORT_TIME_V1", f"{OBSERVATION_STATION[_FORMAL_CITY[city]]}:{fact_type}:{source_time}"
        expected_rank = _epoch_microseconds(_parse_time(source_time))
        expected = _revision_id(scheme, expected_rank, token, source_time)
    if rank != expected_rank or raw_fact.get("source_revision_id") != expected:
        raise ValueError("BRIDGE_CAPTURE_REVISION_INVALID")


def _capture_publication(raw_fact: dict[str, object], fact_type: str, raw: object, target_date: str) -> dict[str, object]:
    city = raw_fact["city"]
    binding = raw_fact["source_binding_id"]
    station = OBSERVATION_STATION[_FORMAL_CITY[city]]
    if fact_type == "FORECAST" and city == "Shanghai":
        payload = raw["data"]["current"]["current"]
        if raw.get("code") != 200 or payload.get("jcid") != "JCCN100117" or payload.get("airportname") != "上海浦东国际机场":
            raise ValueError("BRIDGE_WEATHEROL_IDENTITY_INVALID")
        return {"schema_version": "WEATHEROL_D0_TARGET_DATE_PUBLICATION_V1", "city": city, "source_binding_id": binding,
                "station": station, "provider_airport_id": "JCCN100117", "product": "WEATHEROL_D0", "target_date": target_date}
    if fact_type == "FORECAST":
        return {"schema_version": "AVIATIONWEATHER_TAF_TARGET_DATE_PUBLICATION_V1", "city": city, "source_binding_id": binding,
                "station": station, "product": "TAF", "target_date": target_date}
    report = raw[0]
    report_time = canonical_time_v1(_parse_time(report["reportTime"]))
    return {"schema_version": "AVIATIONWEATHER_METAR_REPORT_PUBLICATION_V1", "city": city, "source_binding_id": binding,
            "station": station, "report_type": fact_type, "report_time_utc": report_time}


def _fact_type(city: str, normalized: dict[str, object]) -> str:
    kind = normalized.get("projection_kind")
    projection = normalized.get("canonical_projection")
    if not isinstance(projection, dict):
        raise ValueError("BRIDGE_CAPTURE_PROJECTION_INVALID")
    if kind == "FORECAST_HIGH_C_MILLI":
        return "FORECAST"
    if kind == "METAR_SPECI_TEMPERATURE_C_MILLI" and projection.get("report_type") in {"METAR", "SPECI"}:
        return projection["report_type"]
    raise ValueError("BRIDGE_CAPTURE_TYPE_INVALID")


def _verify_capture_normalized(raw_fact: dict[str, object], normalized: dict[str, object], raw: object, city: str, target_date: str) -> None:
    canonical_hash = raw_fact.get("canonical_payload_hash")
    expected_source = _source_fact_id(city, raw_fact.get("source_binding_id"), raw_fact.get("source_publication_id"), raw_fact.get("source_revision_id"), canonical_hash)
    if raw_fact.get("source_fact_id") != expected_source or normalized.get("source_fact_id") != expected_source:
        raise ValueError("BRIDGE_CAPTURE_SOURCE_FACT_INVALID")
    kind = normalized.get("projection_kind")
    projection = normalized.get("canonical_projection")
    if not isinstance(kind, str) or not isinstance(projection, dict):
        raise ValueError("BRIDGE_CAPTURE_PROJECTION_INVALID")
    if kind == "METAR_SPECI_TEMPERATURE_C_MILLI":
        if not isinstance(raw, list) or len(raw) != 1 or not isinstance(raw[0], dict):
            raise ValueError("BRIDGE_OBSERVATION_PAYLOAD_INVALID")
        _observation_milli(raw[0].get("temp"))
    derived = _derived_projection({"payload": raw}, city, target_date, kind)
    if kind == "FORECAST_HIGH_C_MILLI":
        matches = projection.get("city") == city and projection.get("target_date") == target_date and projection.get("forecast_high_c_milli") == derived
    else:
        report_type, report_time, temperature = derived
        matches = (projection.get("city") == city and projection.get("station") == OBSERVATION_STATION[_FORMAL_CITY[city]] and
                   projection.get("report_type") == report_type and projection.get("report_time_utc") == report_time and
                   projection.get("temperature_c_milli") == temperature)
    if not matches:
        raise ValueError("BRIDGE_CAPTURE_PROJECTION_INVALID")
    projection_hash = hash_v1("PWM.IIC2.NORMALIZED_PROJECTION.V1", {"projection_kind": kind, "value": projection})
    contract_hash = hash_v1("V8_NORMALIZATION_CONTRACT_V1", {"source_binding_id": raw_fact.get("source_binding_id"),
                                                               "projection_kind": kind, "parser_id": "M1_AVIATIONWEATHER_JSON_PARSER_V1"})
    expected_normalized = hash_v1("PWM.IIC2.NORMALIZED_SOURCE_FACT.V1", {"source_fact_id": expected_source,
                                                                            "normalization_contract_hash": contract_hash,
                                                                            "projection_kind": kind,
                                                                            "canonical_projection_hash": projection_hash})
    if (normalized.get("canonical_projection_hash") != projection_hash or normalized.get("normalization_contract_hash") != contract_hash or
            normalized.get("normalized_fact_id") != expected_normalized):
        raise ValueError("BRIDGE_CAPTURE_NORMALIZED_INVALID")


def _formal_revision(city: City, fact_type: str, raw: object, target_date: date, rank: int) -> tuple[str, str, str | None]:
    if fact_type == "FORECAST" and city is City.SHANGHAI:
        current = raw["data"]["current"]["current"]
        text = current.get("reporttime")
        if not isinstance(text, str) or len(text) != 5 or text[2] != ":":
            raise ValueError("BRIDGE_WEATHEROL_REPORT_MINUTE_INVALID")
        expected_rank = int(text[:2]) * 60 + int(text[3:])
        if rank != expected_rank:
            raise ValueError("BRIDGE_WEATHEROL_RANK_INVALID")
        return "WEATHEROL_D0_LOCAL_REPORT_MINUTE_V1", f"{target_date.isoformat()}T{text}", None
    if fact_type == "FORECAST":
        report = raw[0]
        issue = canonical_time_v1(_parse_time(report["issueTime"]))
        return "AVIATIONWEATHER_TAF_ISSUE_TIME_V1", issue, issue
    report = raw[0]
    report_time = canonical_time_v1(_parse_time(report["reportTime"]))
    expected_type = report.get("metarType")
    if expected_type != fact_type:
        raise ValueError("BRIDGE_OBSERVATION_TYPE_INVALID")
    return f"AVIATIONWEATHER_{fact_type}_REPORT_TIME_V1", f"{OBSERVATION_STATION[city]}:{fact_type}:{report_time}", report_time


def _formal_revision_id(rank_scheme_id: str, rank: int, token: str, source_time: str | None) -> str:
    return hash_v1("V8_SOURCE_REVISION_ID_V1", {"schema_version": "SourceRevisionIdentityV1", "rank_scheme_id": rank_scheme_id,
                                                     "source_revision_rank": rank, "provider_revision_token": token, "source_time": source_time})


def _verify_receipt(receipt: dict[str, object], city: str, target_date: str, entries: tuple[dict[str, object], ...], decision_as_of_utc: str,
                    bundles: list[tuple[dict[str, object], bytes]]) -> str:
    claimed = receipt.get("receipt_hash")
    payload = {key: value for key, value in receipt.items() if key != "receipt_hash"}
    if not isinstance(claimed, str) or receipt_hash(payload) != claimed:
        raise ValueError("BRIDGE_RECEIPT_HASH_INVALID")
    if payload.get("schema_version") != "FORMAL_WEATHER_CAPTURE_READ_RECEIPT_V1" or payload.get("city") != city or payload.get("target_date") != target_date:
        raise ValueError("BRIDGE_RECEIPT_SCOPE_INVALID")
    completed = _utc(payload.get("read_completed_at_utc"))
    if completed > _utc(decision_as_of_utc):
        raise ValueError("BRIDGE_RECEIPT_AFTER_DECISION")
    supplied = payload.get("entries")
    if not isinstance(supplied, list) or tuple(supplied) != entries:
        raise ValueError("BRIDGE_RECEIPT_READ_SET_INVALID")
    for bundle, _ in bundles:
        raw_fact = bundle["raw_source_fact"]
        if completed < _utc(raw_fact.get("observed_at_utc")) or completed < _utc(raw_fact.get("committed_at_utc")):
            raise ValueError("BRIDGE_RECEIPT_PRECEDES_CAPTURE")
    return claimed


def bridge_city_day(root: Path, city: City, target_date: date, decision_as_of_utc: str, receipt: dict[str, object]) -> FormalWeatherBridgeResult:
    """Create formal input records only; it never creates an anchor, day, or receipt."""
    decision = _utc(decision_as_of_utc)
    local = decision.astimezone(_LOCAL)
    if local.date() != target_date or not 7 * 3600 <= local.hour * 3600 + local.minute * 60 + local.second < 16 * 3600:
        raise ValueError("BRIDGE_DECISION_WINDOW_INVALID")
    root_path = _safe_root(root)
    capture_city = _CAPTURE_CITY[city]
    commits = root_path / capture_city / target_date.isoformat() / "commits"
    paths = sorted(commits.glob("*.json")) if commits.is_dir() else []
    if not paths:
        raise ValueError("BRIDGE_COMMIT_PARTITION_MISSING")
    bundles = [_read_bundle(root_path, path, sequence) for sequence, path in enumerate(paths, 1)]
    receipt_entries = tuple({"sequence": index, "bundle_hash": bundle["bundle_hash"],
                             "raw_payload_hash": bundle["raw_source_fact"]["raw_payload_hash"],
                             "canonical_payload_hash": bundle["raw_source_fact"]["canonical_payload_hash"]}
                            for index, (bundle, _) in enumerate(bundles, 1))
    receipt_id = _verify_receipt(receipt, capture_city, target_date.isoformat(), receipt_entries, decision_as_of_utc, bundles)
    forecasts: list[ForecastInput] = []
    observations: list[ObservationInput] = []
    provenance: list[dict[str, object]] = []
    natural: set[tuple[object, object, object]] = set()
    for sequence, (bundle, raw_bytes) in enumerate(bundles, 1):
        raw_fact = bundle["raw_source_fact"]
        normalized = bundle["normalized_source_fact"]
        raw = json.loads(raw_bytes.decode("utf-8"))
        if raw_fact.get("city") != capture_city or not isinstance(normalized, dict):
            raise ValueError("BRIDGE_CITY_INVALID")
        _verify_capture_normalized(raw_fact, normalized, raw, capture_city, target_date.isoformat())
        fact_type = _fact_type(capture_city, normalized)
        if raw_fact.get("source_binding_id") != _CAPTURE_BINDINGS[(capture_city, fact_type)]:
            raise ValueError("BRIDGE_CAPTURE_BINDING_INVALID")
        _capture_revision(raw_fact, capture_city, fact_type, raw, target_date.isoformat())
        key = (raw_fact.get("source_binding_id"), raw_fact.get("source_publication_id"), raw_fact.get("source_revision_id"))
        if key in natural:
            raise ValueError("BRIDGE_CAPTURE_NATURAL_DUPLICATE")
        natural.add(key)
        capture_publication = _capture_publication(raw_fact, fact_type, raw, target_date.isoformat())
        if hash_v1("PWM.IIC2.SOURCE_PUBLICATION.V1", capture_publication) != raw_fact.get("source_publication_id"):
            raise ValueError("BRIDGE_CAPTURE_PUBLICATION_INVALID")
        rank = raw_fact.get("source_revision_rank")
        if isinstance(rank, bool) or not isinstance(rank, int):
            raise ValueError("BRIDGE_CAPTURE_RANK_INVALID")
        rank_scheme, token, source_time = _formal_revision(city, fact_type, raw, target_date, rank)
        if source_time is not None:
            if raw_fact.get("effective_at_utc") != source_time:
                raise ValueError("BRIDGE_CAPTURE_EFFECTIVE_INVALID")
            if _utc(source_time) > decision:
                raise ValueError("BRIDGE_SOURCE_TIME_AFTER_DECISION")
            if fact_type != "FORECAST" and _utc(source_time).astimezone(_LOCAL).date() != target_date:
                raise ValueError("BRIDGE_OBSERVATION_TARGET_DATE_INVALID")
        formal_binding = SOURCE_BINDING[city] if fact_type == "FORECAST" else OBSERVATION_SOURCE_BINDINGS[(city, fact_type)]
        registered = SOURCE_BINDING_REGISTRY_BY_ID.get((city.value, formal_binding))
        if registered is None or registered["rank_scheme_id"] != rank_scheme:
            raise ValueError("BRIDGE_FORMAL_REGISTRY_INVALID")
        visibility = Visibility(raw_fact["effective_at_utc"], raw_fact["observed_at_utc"], raw_fact["committed_at_utc"])
        if not visibility.visible_at(decision_as_of_utc):
            raise ValueError("BRIDGE_SOURCE_NOT_VISIBLE")
        canonical_hash = raw_fact["canonical_payload_hash"]
        formal_revision = _formal_revision_id(rank_scheme, rank, token, source_time)
        formal_source = source_fact_id_v1(city, formal_binding, raw_fact["source_publication_id"], formal_revision, canonical_hash)
        local_second = local.hour * 3600 + local.minute * 60 + local.second
        if fact_type == "FORECAST":
            if city is City.SHANGHAI:
                entries = [item for item in raw["data"]["forecast15d"] if item.get("forecasttime") == target_date.strftime("%m/%d")]
                if len(entries) != 1:
                    raise ValueError("BRIDGE_WEATHEROL_TARGET_INVALID")
                milli = int(entries[0]["temperature_am"]) * 1000
            else:
                if not isinstance(raw, list) or len(raw) != 1:
                    raise ValueError("BRIDGE_TAF_PAYLOAD_INVALID")
                milli = _taf_high(raw[0], target_date.isoformat())
            projection = {"city": city.value, "target_date": target_date.isoformat(), "local_second": local_second, "forecast_high_c_milli": milli}
            projection_hash = hash_v1("PWM.IIC2.NORMALIZED_PROJECTION.V1", {"projection_kind": "FORECAST_HIGH_C_MILLI", "canonical_projection": projection})
            with localcontext() as context:
                context.prec = 80
                fact = ForecastInput(city, target_date, local_second, formal_binding, raw_fact["source_publication_id"], formal_revision, rank,
                                     Decimal(milli).scaleb(-3), TemperatureUnit.CELSIUS, raw_fact["raw_payload_hash"], visibility, rank_scheme, token,
                                     source_time, formal_source, canonical_hash, registered["normalization_contract_hash"], projection_hash)
            forecasts.append(fact)
        else:
            if not isinstance(raw, list) or len(raw) != 1 or raw[0].get("icaoId") != OBSERVATION_STATION[city]:
                raise ValueError("BRIDGE_OBSERVATION_PAYLOAD_INVALID")
            report_time = canonical_time_v1(_parse_time(raw[0]["reportTime"]))
            if raw[0].get("metarType") != fact_type:
                raise ValueError("BRIDGE_OBSERVATION_TYPE_INVALID")
            milli = _observation_milli(raw[0].get("temp"))
            projection = {"city": city.value, "station": OBSERVATION_STATION[city], "report_type": fact_type,
                          "report_time_utc": report_time, "temperature_c_milli": milli}
            projection_hash = hash_v1("PWM.IIC2.NORMALIZED_PROJECTION.V1", {"projection_kind": "METAR_SPECI_TEMPERATURE_C_MILLI", "canonical_projection": projection})
            with localcontext() as context:
                context.prec = 80
                fact = ObservationInput(city, OBSERVATION_STATION[city], fact_type, report_time, Decimal(milli).scaleb(-3), TemperatureUnit.CELSIUS,
                                        formal_source, visibility, formal_binding, raw_fact["source_publication_id"], formal_revision, rank,
                                        raw_fact["raw_payload_hash"], canonical_hash, registered["normalization_contract_hash"], projection_hash)
            observations.append(fact)
        formal_normalized = normalized_fact_id_v1(formal_source, registered["normalization_contract_hash"],
                                                   "FORECAST_HIGH_C_MILLI" if fact_type == "FORECAST" else "METAR_SPECI_TEMPERATURE_C_MILLI", projection_hash)
        provenance.append({"sequence": sequence, "bundle_hash": bundle["bundle_hash"], "receipt_hash": receipt_id,
                           "capture_source_publication_id": raw_fact["source_publication_id"], "capture_source_revision_id": raw_fact["source_revision_id"],
                           "capture_source_fact_id": raw_fact["source_fact_id"], "capture_normalized_fact_id": normalized.get("normalized_fact_id"),
                           "raw_payload_hash": raw_fact["raw_payload_hash"], "canonical_payload_hash": canonical_hash,
                           "effective_at_utc": raw_fact["effective_at_utc"], "observed_at_utc": raw_fact["observed_at_utc"], "committed_at_utc": raw_fact["committed_at_utc"],
                           "formal_source_binding_id": formal_binding, "formal_source_publication_id": raw_fact["source_publication_id"],
                           "formal_source_revision_id": formal_revision, "formal_source_fact_id": formal_source,
                           "formal_normalized_fact_id": formal_normalized, "source_binding_registry_hash": SOURCE_BINDING_REGISTRY_HASH})
    return FormalWeatherBridgeResult(tuple(forecasts), tuple(observations), tuple(provenance))
