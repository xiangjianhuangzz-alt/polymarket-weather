"""Read saved research SQLite rows only; never promote absent source times."""
import hashlib
import json
from datetime import date
from pathlib import Path
from .inputs import read_rows
from .population import parse
from .dynamic_event_router import CITIES, LOCAL
from .asof_input import seal_fact, validate_fact

def row_hash(row):
    return hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def source_times(row, kind):
    """Project proved fields only; no first-seen/receive -> commit aliases.

    IIC2 M06 raw_source_fact and AK2 section 7 require three times. Received
    and available remain independent, conditional constraints when present.
    Existing registry rows cannot be promoted into a formal SourceFact here.
    """
    times = {key: row.get(key + '_at_utc') for key in ('effective','observed','received','available','committed')}
    if kind in ('METAR','SPECI'):
        times['received'] = times['received'] or row.get('received_at')
    for value in times.values():
        if value is not None: parse(value)
    return times

def observation_fact(row, city, source_path):
    if row['city'] != city or row['station'] != CITIES[city]: raise ValueError('CROSS_CITY_SOURCE')
    report = parse(row['report_time']); parse(row['received_at'])
    if row['report_type'] not in ('METAR','SPECI'): raise ValueError('OBSERVATION_TYPE_INVALID')
    if hashlib.sha256(row['raw_observation'].encode()).hexdigest() != row['raw_hash']:
        raise ValueError('RAW_OBSERVATION_HASH_MISMATCH')
    return seal_fact({'city':city,'station':CITIES[city], 'target_date':report.astimezone(LOCAL).date().isoformat(),
        'fact_type':row['report_type'],'identity':row_hash(row),'revision':row['raw_hash'],
        'source_identity':row['source'],'value_c':str(row['temperature_c']),
        **source_times(row, row['report_type']),
        'source_path':str(source_path),'source_table':'metar_observations','source_row':row,
        'source_row_hash':row_hash(row),'raw_payload_hash':row['raw_hash'],
        'event_time':row['report_time'],'replay_visible_record_time':row['received_at'],
        'time_status':'PARTIAL_RESEARCH_TIMESTAMPS_NOT_FORMAL_SOURCEFACT'})

def forecast_fact(row, city, source_path):
    if row['city'] != city or row['station'] != CITIES[city]: raise ValueError('CROSS_CITY_SOURCE')
    expected = 'weatherol_shanghai' if city == 'Shanghai' else 'aviationweather_taf'
    if row['source'] != expected: raise ValueError('FORECAST_SOURCE_BINDING_INVALID')
    parse(row['first_seen_at']); date.fromisoformat(row['target_date'])
    return seal_fact({'city':city,'station':CITIES[city], 'target_date':row['target_date'],'fact_type':'FORECAST',
        'identity':row_hash(row),'revision':str(row['version_id']),'revision_rank':None,
        'source_identity':row['source'],'value_c':str(row['forecast_high_c']),
        **source_times(row, 'FORECAST'),
        'registry_first_seen_at':row['first_seen_at'],
        'source_path':str(source_path),'source_table':'forecast_versions','source_row':row,
        'source_row_hash':row_hash(row),'advertised_content_hash':row['content_hash'],
        'event_time':row['first_seen_at'],'replay_visible_record_time':row['first_seen_at'],
        'time_status':'PARTIAL_RESEARCH_TIMESTAMPS_NOT_FORMAL_SOURCEFACT'})

def load_saved_city(city, target_date, research_db, observations_db, training_dates):
    station = CITIES[city]
    allowed = set(training_dates) | {target_date}
    source = 'weatherol_shanghai' if city == 'Shanghai' else 'aviationweather_taf'
    forecasts = read_rows(research_db,
        'SELECT * FROM forecast_versions WHERE city=? AND station=? AND source=? ORDER BY version_id', (city,station,source))
    observations = read_rows(observations_db,
        'SELECT * FROM metar_observations WHERE city=? AND station=? ORDER BY observation_id',(city,station))
    facts, failures = [], []
    for kind, rows in (('FORECAST',forecasts),('OBSERVATION',observations)):
        for row in rows:
            try:
                target = row['target_date'] if kind == 'FORECAST' else parse(row['report_time']).astimezone(LOCAL).date().isoformat()
                if target not in allowed: continue
                fact = forecast_fact(row,city,research_db) if kind == 'FORECAST' else observation_fact(row,city,observations_db)
                validate_fact(fact,city,station); facts.append(fact)
            except (ValueError,TypeError,KeyError) as exc:
                failures.append({'city':city,'source_kind':kind,'row':row,'error_type':type(exc).__name__,'error_reason':str(exc)})
    return {'schema_version':'DYNAMIC_WEATHER_SOURCE_ADAPTER_V1','city':city,'station':station,
            'target_date':target_date,'facts':facts,'failures':failures,
            'formal_sourcefact_complete':False,'network_used':False}
