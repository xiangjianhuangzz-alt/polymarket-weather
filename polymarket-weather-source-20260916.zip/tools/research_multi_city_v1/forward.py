"""One city, one pre-anchor invocation. No scheduling or service activation."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import date, time
import importlib.metadata
from pathlib import Path
import sys
import uuid

from tools.research_forward_collection_v1.daily import (ROOT, SHANGHAI, anchor, load, save, sha,
    stamp, parsed, utcnow, verified_load, wait_until)
from . import inputs, market, model

PYTHON = ROOT / ".venv-strategy-tests-v1/Scripts/python.exe"
RESEARCH = ROOT / "data/strategy_analysis"


def validate_config(config):
    inputs.identity(config["city"], config["station"])
    root = Path(config["output_root"]).resolve()
    if RESEARCH not in root.parents or root.name != "forward" or root.parent.name != config["city"].lower() or "backups" in {p.lower() for p in root.parts}:
        raise ValueError("CITY_OUTPUT_ROOT_MISMATCH")
    if config["anchor"] != "08:00 Asia/Shanghai" or config["requested_yes_quantity"] != "5" or config["freshness_seconds"] != 60:
        raise ValueError("FROZEN_PARAMETERS_CHANGED")
    if sha(config["freeze_path"]) != config["freeze_sha256"]:
        raise ValueError("CITY_FREEZE_CHANGED")
    freeze = load(config["freeze_path"])
    if freeze["city"] != config["city"] or freeze["station"] != config["station"]:
        raise ValueError("CITY_FREEZE_IDENTITY_MISMATCH")
    for path, identity in freeze["source_hashes"].items():
        if sha(ROOT / path) != identity:
            raise ValueError("FROZEN_SOURCE_CHANGED: " + path)
    for key in ("population", "protocol"):
        if sha(freeze[key + "_path"]) != freeze[key + "_sha256"]:
            raise ValueError("FROZEN_INPUT_CHANGED: " + key)
    for key in ("research_db_path", "observation_db_path"):
        path = Path(config[key]).resolve()
        if ROOT not in path.parents or "backups" in {p.lower() for p in path.parts}:
            raise ValueError("SOURCE_PATH_NOT_ALLOWED")
    return root, freeze


def runtime_check(root):
    root.mkdir(parents=True, exist_ok=False)
    probe = root / "cwrd"
    probe.mkdir()
    path = probe / "sentinel.txt"
    with path.open("x", encoding="utf-8") as stream:
        stream.write("multi-city-v1")
    if path.read_text(encoding="utf-8") != "multi-city-v1":
        raise ValueError("CWRD_READ_FAILURE")
    path.unlink()
    probe.rmdir()
    return {"CREATE": "PASS", "WRITE": "PASS", "READ": "PASS", "DELETE": "PASS"}


def append_scores(root, config, now, attempt, label_reader=inputs.label):
    training, failures = [], []
    for day in sorted((root / "days").glob("????-??-??")):
        target = date.fromisoformat(day.name)
        if inputs.window(target)[3] > now or not (day / "weather_input.json").is_file():
            continue
        try:
            weather = verified_load(day / "weather_input.json")
            inputs.identity(weather["city"], weather["station"])
            if weather["city"] != config["city"]:
                raise ValueError("CROSS_CITY_SAVED_WEATHER")
            label_path = day / "label.json"
            if not label_path.exists():
                save(label_path, label_reader(config["city"], config["station"], target, Path(config["observation_db_path"]), now))
            actual = verified_load(label_path)
            if now < parsed(actual["label_available_at_utc"]) or actual["city"] != weather["city"] or actual["station"] != weather["station"] or actual["target_date"] != day.name:
                raise ValueError("LABEL_IDENTITY_OR_MATURITY_MISMATCH")
            row = {k: weather[k] for k in ("city", "station", "source", "target_date", "decision_as_of_utc", "forecast_high_c", "current_observed_max_c")}
            row.update(status="AVAILABLE", label_final_max_c=actual["label_final_max_c"], label_available_at_utc=actual["label_available_at_utc"])
            training.append(row)
            prediction_path, score_path = day / "prediction.json", day / "score.json"
            if prediction_path.exists() and not score_path.exists():
                prediction = verified_load(prediction_path)
                if prediction.get("execution_mode") != "FORWARD_BLIND" or parsed(prediction["prediction_created_at_utc"]) >= parsed(actual["label_available_at_utc"]):
                    raise ValueError("BLIND_PREDICTION_LABEL_ORDER_FAILED")
                score = model.score_prediction(prediction, actual)
                score.update(score_created_at=stamp(now), prediction_sha256=sha(prediction_path), label_sha256=sha(label_path))
                save(score_path, score)
        except Exception as exc:
            failures.append({"city": config["city"], "target_date": day.name, "reason": str(exc)})
    save(attempt / "mature_processing.json", {"training_dates": [r["target_date"] for r in training], "failures": failures})
    return training


def run_daily(config, target, clock=utcnow, sleep=None, weather_reader=inputs.snapshot,
              label_reader=inputs.label, market_capture=market.capture):
    root, freeze = validate_config(config)
    attempt = root / "attempts" / uuid.uuid4().hex
    runtime = attempt / "runtime"
    checks = runtime_check(runtime)
    save(attempt / "environment.json", dict(checks, PYTHON_EXECUTABLE=sys.executable, PYTHON_VERSION=sys.version,
        TEST_ENVIRONMENT=sys.prefix, QA_RUNTIME_ROOT=str(runtime), WORKSPACE_PERMISSION_MODE="WORKSPACE_WRITE",
        dependency_identity={d.metadata["Name"]: d.version for d in importlib.metadata.distributions()}, command=sys.argv))
    local = clock().astimezone(SHANGHAI)
    if target != local.date() or target < date.fromisoformat(config["first_target_date"]) or not time(7,58) <= local.time() < time(8):
        result = {"city": config["city"], "status": "CAPTURE_FAILURE", "reason": "OUTSIDE_PREANCHOR_WINDOW"}
        save(attempt / "result.json", result)
        return result
    day = root / "days" / target.isoformat()
    try:
        day.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        result = {"city": config["city"], "status": "CAPTURE_FAILURE", "reason": "DAY_ALREADY_RESERVED_NO_REPREDICTION"}
        save(attempt / "result.json", result)
        return result
    save(day / "claim.json", {"city": config["city"], "station": config["station"], "target_date": target.isoformat(), "created_at": stamp(clock())})
    result = {"city": config["city"], "target_date": target.isoformat(), "status": "WEATHER_INPUT_FAILURE"}
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(market_capture, day, config["city"], target)
        try:
            prior = append_scores(root, config, clock(), attempt, label_reader)
            population = load(freeze["population_path"])
            initial = [r for r in population["candidate_days"] if r["status"] == "AVAILABLE"]
            training = [r for r in initial + prior if date.fromisoformat(r["target_date"]) < target and inputs.window(date.fromisoformat(r["target_date"]))[3] <= anchor(target) and parsed(r["label_available_at_utc"]) <= anchor(target)]
            if clock() >= anchor(target):
                raise ValueError("PREPARATION_MISSED_WEATHER_ANCHOR")
            if sleep is None:
                wait_until(anchor(target), clock)
            else:
                wait_until(anchor(target), clock, sleep)
            validate_config(config)
            weather = weather_reader(config["city"], config["station"], target, Path(config["research_db_path"]), Path(config["observation_db_path"]))
            source_identity = save(day / "weather_input.json", weather)
            saved = {"city": config["city"], "station": config["station"], "target_date": target.isoformat(),
                     "status": "INPUT_OR_COMPUTATION_FAILURE", "training_dates": [r["target_date"] for r in training], "training_count": len(training)}
            try:
                saved.update(model.predict(config["city"], config["station"], weather, training))
            except Exception as exc:
                saved["reason"] = type(exc).__name__ + ": " + str(exc)
            saved.update(execution_mode="FORWARD_BLIND", prediction_created_at_utc=stamp(clock()),
                model_version_hashes=freeze["source_hashes"], freeze_sha256=config["freeze_sha256"],
                source_hashes=weather["source_hashes"], weather_input_sha256=source_identity,
                forecast_identity=weather["forecast_identity"], observation_identity=[r["source_fact_id"] for r in weather["observations"]])
            if clock() >= inputs.window(target)[3]:
                raise ValueError("LABEL_MATURE_BEFORE_PREDICTION_SAVE")
            save(day / "prediction.json", saved)
            result["status"] = "PREDICTION_COMPLETE" if saved["status"] == "PREDICTION_SAVED_AWAITING_LABEL" else "CAPTURE_FAILURE"
        except Exception as exc:
            result["weather_error"] = str(exc)
            save(day / "weather_failure.json", result)
        try:
            result["market"] = future.result()
        except Exception as exc:
            result["market"] = {"status": "MARKET_MISSING", "reason": str(exc)}
    result.update(completed_at=stamp(clock()), FORWARD_COLLECTION_RUNNING="NO")
    save(day / "result.json", result)
    save(attempt / "result.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--target-date", type=date.fromisoformat)
    parser.add_argument("--research-live-read", action="store_true")
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    if Path(sys.executable).resolve() != PYTHON.resolve() or Path.cwd().resolve() != ROOT.resolve():
        parser.error("FIXED_PROJECT_PYTHON_AND_CWD_REQUIRED")
    config = load(args.config)
    validate_config(config)
    if args.check_only:
        print("CONFIG_AND_FREEZE=PASS; REAL_CAPTURE_EXECUTED=NO")
        return
    if not args.research_live_read:
        parser.error("explicit --research-live-read required")
    result = run_daily(config, args.target_date or utcnow().astimezone(SHANGHAI).date())
    print(result)
    raise SystemExit(0 if result["status"] == "PREDICTION_COMPLETE" else 1)


if __name__ == "__main__":
    main()
