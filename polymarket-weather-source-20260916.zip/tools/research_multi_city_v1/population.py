"""Offline, read-only Beijing and Guangzhou TAF/METAR research populations."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import sys
import re
from collections import Counter
from functools import lru_cache
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

UTC = timezone.utc
CHINA = ZoneInfo("Asia/Shanghai")
CITIES = {"Beijing": "ZBAA", "Guangzhou": "ZGGG"}
SOURCE = "aviationweather_taf"
GAP_LIMIT = 5400


def canon(value): return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
def sha(value): return hashlib.sha256(canon(value).encode("utf-8")).hexdigest()
def z(value): return value.astimezone(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")
RFC3339_OFFSET = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$")


def parse(value):
    """Parse only explicit RFC3339 instants; never attach a timezone by guess."""
    original = str(value)
    if not RFC3339_OFFSET.fullmatch(original):
        raise ValueError("TIME_NOT_RFC3339_WITH_EXPLICIT_OFFSET")
    parsed = datetime.fromisoformat(original.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("TIME_NAIVE_OR_OFFSET_MISSING")
    return parsed.astimezone(UTC)


def time_record(field, original, error=None):
    return {"field":field,"original_value":original,"parse_status":"OK" if error is None else "INVALID","parse_reason":None if error is None else str(error)}
def dec(value): return None if value is None else format(Decimal(str(value)), "f")


def ro(path):
    conn = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    return conn


def window(day):
    start = datetime.combine(day, time.min, CHINA).astimezone(UTC)
    return start, start + timedelta(hours=8), start + timedelta(days=1), start + timedelta(days=2)


def table_names(path):
    conn = ro(path)
    try: return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    finally: conn.close()


def stores(root):
    archive = root / "data/evidence_archive/be05_historical_rescue_20260731_20260813_v1"
    candidates = (("ARCHIVE_RESCUE", archive / "research.sqlite3", archive / "observations.sqlite3"), ("ACTIVE_STORE", root / "data/research.sqlite3", root / "data/observations.sqlite3"))
    return [(kind, rdb, odb) for kind, rdb, odb in candidates if rdb.exists() and odb.exists()]


def evidence_paths(root):
    base = root / "data/evidence_capture"
    paths = list((base / "be05_v3_asof").glob("????-??-??/evidence.sqlite3")) + list(base.glob("be05_v3_asof_????????/evidence.sqlite3"))
    return sorted({p for p in paths if "rejected-preflight" not in str(p).lower()})


def evidence_date(path):
    """Return the immutable capture calendar date encoded by this snapshot path."""
    for part in reversed(path.parts):
        try: return date.fromisoformat(part)
        except ValueError: continue
    stem = path.parent.name.removeprefix("be05_v3_asof_")
    if len(stem) == 8 and stem.isdigit(): return date(int(stem[:4]), int(stem[4:6]), int(stem[6:]))
    return None


def evidence_index(root):
    index = {}
    for path in evidence_paths(root):
        day = evidence_date(path)
        if day is not None: index.setdefault(day, []).append(path)
    return index


def registry_dates(path, city, station):
    names=table_names(path); conn = ro(path); found=set()
    try:
        if "forecast_d0_registry" in names:
            rows = conn.execute("SELECT DISTINCT target_date FROM forecast_d0_registry WHERE source=? AND city=? AND station=?", (SOURCE, city, station))
            found |= {date.fromisoformat(r[0]) for r in rows if r[0]}
        if "forecast_versions" in names:
            rows = conn.execute("SELECT DISTINCT target_date FROM forecast_versions WHERE source=? AND city=? AND station=?", (SOURCE, city, station))
            found |= {date.fromisoformat(r[0]) for r in rows if r[0]}
        return found
    finally: conn.close()


def observation_dates(path, city, station, errors):
    conn = ro(path); found=set()
    try:
        rows=conn.execute("SELECT report_time FROM metar_observations WHERE city=? AND station=?", (city,station))
        for row in rows:
            try: found.add(parse(row[0]).astimezone(CHINA).date())
            except (ValueError,TypeError) as error:
                errors.append({"source_kind":"registry","database":str(path),"field":"report_time","original_value":row[0],"parse_status":"INVALID","parse_reason":str(error)})
    finally: conn.close()
    return found


def evidence_dates(path, city, station, errors):
    names, found = table_names(path), set(); conn = ro(path)
    try:
        if "evidence_events" in names:
            rows = conn.execute("SELECT target_date FROM evidence_events WHERE dimension='weather' AND source=? AND city=? AND station=?", (SOURCE, city, station))
            found |= {date.fromisoformat(r[0]) for r in rows if r[0]}
        if "evidence_records" in names:
            for r in conn.execute("SELECT payload_json FROM evidence_records WHERE source_table='forecast_versions'"):
                try:
                    payload = json.loads(r[0])
                    if payload.get("city") == city and payload.get("station") == station and payload.get("target_date"):
                        found.add(date.fromisoformat(payload["target_date"]))
                except (ValueError, TypeError, json.JSONDecodeError) as error:
                    errors.append({"source_kind":"asof_evidence","database":str(path),"field":"target_date","original_value":r[0],"parse_status":"INVALID","parse_reason":str(error)})
    finally: conn.close()
    return found


def evidence_observation_dates(path, city, station, errors):
    names, found = table_names(path), set(); conn=ro(path)
    try:
        if "evidence_events" in names and "raw_payloads" in names:
            query="SELECT p.payload_json FROM evidence_events e JOIN raw_payloads p ON p.payload_hash=e.raw_payload_hash WHERE e.dimension='metar_path' AND e.city=? AND e.station=?"
            rows=conn.execute(query,(city,station))
        elif "evidence_records" in names:
            rows=conn.execute("SELECT payload_json FROM evidence_records WHERE source_table='metar_observations'")
        else: rows=[]
        for row in rows:
            try:
                payload=json.loads(row[0])
                if payload.get("city") == city and payload.get("station") == station:
                    found.add(parse(payload["report_time"]).astimezone(CHINA).date())
            except (KeyError,ValueError,TypeError,json.JSONDecodeError) as error:
                errors.append({"source_kind":"asof_evidence","database":str(path),"field":"report_time","original_value":row[0],"parse_status":"INVALID","parse_reason":str(error)})
    finally: conn.close()
    return found


def date_set_payload(date_sets):
    union=set().union(*date_sets.values())
    return {"sets":{name:[day.isoformat() for day in sorted(days)] for name,days in date_sets.items()},"union":[day.isoformat() for day in sorted(union)],"differences_from_union":{name:[day.isoformat() for day in sorted(union-days)] for name,days in date_sets.items()}}


@lru_cache(maxsize=8)
def registry_forecast_rows(path_text, city, station):
    conn = ro(Path(path_text))
    try:
        rows = conn.execute("SELECT target_date,grid_version,forecast_high_c,source_reported_at,first_captured_at,content_hash FROM forecast_d0_registry WHERE source=? AND city=? AND station=? AND status='valid_d0' ORDER BY target_date,grid_version,content_hash", (SOURCE, city, station))
        return tuple(dict(r) for r in rows)
    finally: conn.close()


def registry_forecast(path, city, station, target, anchor):
    rows = [r for r in registry_forecast_rows(str(Path(path).resolve()), city, station) if r["target_date"] == target.isoformat()]
    if not rows: return None, "MISSING", "FORECAST_D0_MISSING"
    if len({(r["grid_version"], r["content_hash"], r["forecast_high_c"]) for r in rows}) != 1: return None, "CONFLICT", "FORECAST_D0_CONFLICT"
    row = rows[0]
    audit=[]
    try: reported=parse(row["source_reported_at"]); audit.append(time_record("source_reported_at",row["source_reported_at"]))
    except (ValueError, TypeError) as error: audit.append(time_record("source_reported_at",row["source_reported_at"],error)); reported=None
    try: first=parse(row["first_captured_at"]); audit.append(time_record("first_captured_at",row["first_captured_at"]))
    except (ValueError, TypeError) as error: audit.append(time_record("first_captured_at",row["first_captured_at"],error)); first=None
    if reported is None or first is None: return {"time_parse_records":audit}, "UNPROVABLE", "FORECAST_TIME_MISSING_OR_INVALID"
    if reported > anchor or first > anchor: return None, "UNPROVABLE", "FORECAST_NOT_VISIBLE_BY_DECISION_ASOF"
    return {"forecast": dec(row["forecast_high_c"]), "refs": [{"source_kind":"registry","database":str(path),"table":"forecast_d0_registry","grid_version":row["grid_version"],"content_hash":row["content_hash"],"source_reported_at":row["source_reported_at"],"first_observed_at":row["first_captured_at"]}]}, None, None


@lru_cache(maxsize=8)
def registry_rows(path_text, city, station):
    conn = ro(Path(path_text))
    try:
        return tuple(dict(r) for r in conn.execute("SELECT observation_id,decision_scope,report_time,received_at,report_type,temperature_c,raw_hash,source FROM metar_observations WHERE city=? AND station=? AND temperature_c IS NOT NULL ORDER BY report_time,observation_id", (city, station)))
    finally: conn.close()


def registry_facts(path, city, station, start, end, visible):
    rows = registry_rows(str(Path(path).resolve()), city, station)
    result = []
    target = start.astimezone(CHINA).date().isoformat()
    for r in rows:
        audit=[]
        try: report = parse(r["report_time"]); audit.append(time_record("report_time",r["report_time"]))
        except (ValueError, TypeError) as error:
            if r.get("decision_scope") == target:
                result.append({"source_fact_id":sha({"observation_id":r["observation_id"],"raw_hash":r["raw_hash"],"field":"report_time"}),"time_parse_records":[time_record("report_time",r["report_time"],error)]})
            continue
        try: received = parse(r["received_at"]); audit.append(time_record("received_at",r["received_at"]))
        except (ValueError, TypeError) as error:
            if report.astimezone(CHINA).date().isoformat() == target:
                result.append({"source_fact_id":sha({"observation_id":r["observation_id"],"raw_hash":r["raw_hash"],"field":"received_at"}),"time_parse_records":audit+[time_record("received_at",r["received_at"],error)]})
            continue
        if start <= report < end and received <= visible:
            item={"observation_id":r["observation_id"],"report_time_utc":r["report_time"],"received_at_utc":r["received_at"],"report_type":r["report_type"],"temperature_c":dec(r["temperature_c"]),"raw_hash":r["raw_hash"],"source":r["source"],"source_kind":"registry","database":str(path),"table":"metar_observations","time_parse_records":audit}
            item["source_fact_id"] = sha(item); result.append(item)
    return result


def evidence_forecast(path, city, station, target, anchor):
    names = table_names(path); conn = ro(path); rows=[]
    try:
        if "evidence_events" in names and "raw_payloads" in names:
            query = "SELECT e.rowid AS source_rowid,e.source_reported_at,e.recorder_first_observed_at,e.raw_payload_hash,p.payload_json FROM evidence_events e JOIN raw_payloads p ON p.payload_hash=e.raw_payload_hash WHERE e.dimension='weather' AND e.source=? AND e.city=? AND e.station=? AND e.target_date=?"
            rows += [(dict(r), "evidence_events") for r in conn.execute(query, (SOURCE, city, station, target.isoformat()))]
        if "evidence_records" in names:
            query = "SELECT rowid AS source_rowid,source_event_time AS source_reported_at,observed_at_utc AS recorder_first_observed_at,content_sha256 AS raw_payload_hash,payload_json FROM evidence_records WHERE source_table='forecast_versions'"
            rows += [(dict(r), "evidence_records") for r in conn.execute(query)]
    finally: conn.close()
    valid=[]; malformed=False; late=False
    for row, table in rows:
        try:
            payload=json.loads(row["payload_json"])
            if table == "evidence_records":
                identity=(payload.get("city"),payload.get("station"),payload.get("target_date"))
                if all(value is not None for value in identity) and identity != (city,station,target.isoformat()): continue
                if payload.get("source") != SOURCE or any(value is None for value in identity): malformed=True; continue
            issued=row.get("source_reported_at") or payload.get("issue_time")
            first=row.get("recorder_first_observed_at") or payload.get("first_seen_at")
            high=payload.get("forecast_high_c")
            if issued is None or first is None or high is None: malformed=True; continue
            if parse(issued)>anchor or parse(first)>anchor: late=True; continue
            ref={"source_kind":"asof_evidence","database":str(path),"table":table,"source_rowid":row["source_rowid"],"raw_payload_hash":row["raw_payload_hash"],"source_reported_at":issued,"first_observed_at":first,"payload":payload}
            valid.append({"forecast":dec(high),"rank":(z(parse(first)),z(parse(issued)),row["raw_payload_hash"]),"refs":[ref]})
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            malformed=True
            row["time_parse_records"]=[time_record("forecast_time",row.get("source_reported_at"),error)]
    if malformed:
        return {"time_parse_records":[record for row,_ in rows for record in row.get("time_parse_records",[])]}, "UNPROVABLE", "EVIDENCE_FORECAST_EFFECTIVE_OR_FIRST_OBSERVED_MISSING"
    if not valid:
        if late: return None, "UNPROVABLE", "FORECAST_NOT_VISIBLE_BY_DECISION_ASOF"
        return None, "MISSING", "EVIDENCE_FORECAST_MISSING"
    if len({v["forecast"] for v in valid}) > 1: return None, "CONFLICT", "EVIDENCE_FORECAST_CONFLICT"
    return max(valid, key=lambda v:v["rank"]), None, None


def evidence_facts(path, city, station, start, end, visible):
    names=table_names(path); conn=ro(path); rows=[]
    try:
        if "evidence_events" in names and "raw_payloads" in names:
            query="SELECT e.rowid AS source_rowid,e.raw_payload_hash,p.payload_json FROM evidence_events e JOIN raw_payloads p ON p.payload_hash=e.raw_payload_hash WHERE e.dimension='metar_path' AND e.city=? AND e.station=?"
            rows += [(dict(r),"evidence_events") for r in conn.execute(query,(city,station))]
        if "evidence_records" in names:
            rows += [(dict(r),"evidence_records") for r in conn.execute("SELECT rowid AS source_rowid,content_sha256 AS raw_payload_hash,payload_json FROM evidence_records WHERE source_table='metar_observations'")]
    finally: conn.close()
    result=[]
    for row,table in rows:
        try:
            payload=json.loads(row["payload_json"])
            if table == "evidence_records":
                identity=(payload.get("city"),payload.get("station"))
                if all(value is not None for value in identity) and identity != (city,station): continue
                if payload.get("source") != "aviationweather_metar" or any(value is None for value in identity):
                    if payload.get("target_date") == start.astimezone(CHINA).date().isoformat():
                        result.append({"source_fact_id":sha({"source_rowid":row["source_rowid"],"raw_payload_hash":row["raw_payload_hash"],"error":"EVIDENCE_SOURCE_IDENTITY_MISSING_OR_MISMATCH"}),"time_parse_records":[time_record("source",payload.get("source"),"EVIDENCE_SOURCE_IDENTITY_MISSING_OR_MISMATCH")]})
                    continue
            report,received=parse(payload["report_time"]),parse(payload["received_at"])
            if payload.get("temperature_c") is None or not (start <= report < end and received <= visible): continue
            item={"observation_id":payload.get("observation_id"),"report_time_utc":payload["report_time"],"received_at_utc":payload["received_at"],"report_type":payload.get("report_type"),"temperature_c":dec(payload["temperature_c"]),"raw_hash":payload.get("raw_hash") or row["raw_payload_hash"],"source":"aviationweather_metar","source_kind":"asof_evidence","database":str(path),"table":table,"source_rowid":row["source_rowid"],"time_parse_records":[time_record("report_time",payload["report_time"]),time_record("received_at",payload["received_at"])]}
            item["source_fact_id"]=sha(item); result.append(item)
        except (KeyError, ValueError, TypeError, json.JSONDecodeError) as error:
            result.append({"source_fact_id":sha({"source_rowid":row["source_rowid"],"raw_payload_hash":row["raw_payload_hash"],"error":str(error)}),"time_parse_records":[time_record("payload_time",row.get("payload_json"),error)]})
    return result


def coverage(rows, start, end):
    if not rows: return False, None
    times=sorted(parse(r["report_time_utc"]) for r in rows); gap=max((int((b-a).total_seconds()) for a,b in zip(times,times[1:])),default=0)
    return times[0] <= start+timedelta(minutes=30) and times[-1] >= end-timedelta(minutes=30) and gap <= GAP_LIMIT, gap


def candidate(kind, forecast_result, current, label, start, end, builder):
    value,status,reason=forecast_result
    parse_records=[record for row in current+label for record in row.get("time_parse_records",[]) if record["parse_status"] == "INVALID"]
    current=[row for row in current if "temperature_c" in row]
    label=[row for row in label if "temperature_c" in row]
    base={"status":"UNPROVABLE","reason":None,"forecast_high_c":None,"current_observed_max_c":None,"label_final_max_c":None,"source_refs":[],"asof_checks":{"source_kind":kind,"gap_limit_seconds":GAP_LIMIT,"time_parse_records":parse_records}}
    if parse_records:
        base.update(status="UNPROVABLE",reason="RELEVANT_OBSERVATION_TIME_PARSE_INVALID")
        return base
    if status:
        if value: base["asof_checks"]["time_parse_records"] += value.get("time_parse_records",[])
        base.update(status=status,reason=reason); return base
    base["forecast_high_c"]=value["forecast"]; base["source_refs"] += value["refs"]
    base["asof_checks"]["current_observation_fact_ids"]=[x["source_fact_id"] for x in current]
    if not current: base.update(status="MISSING",reason="CURRENT_OBSERVATION_AT_ANCHOR_MISSING"); return base
    base["current_observed_max_c"]=dec(max(Decimal(x["temperature_c"]) for x in current))
    if builder < end+timedelta(days=1): base.update(status="UNPROVABLE",reason="LABEL_NOT_MATURE_AT_BUILDER_ASOF"); return base
    complete,gap=coverage(label,start,end); base["asof_checks"].update(label_observation_fact_ids=[x["source_fact_id"] for x in label],label_maximum_gap_seconds=gap)
    if not complete: base.update(status="MISSING",reason="LABEL_OBSERVATION_COVERAGE_INCOMPLETE"); return base
    base.update(status="AVAILABLE",reason="RECOVERED_TAF_METAR_FACTS",label_final_max_c=dec(max(Decimal(x["temperature_c"]) for x in label)))
    base["source_refs"] += [{k:x[k] for k in ("source_kind","database","table","source_rowid","observation_id","raw_hash","report_time_utc","received_at_utc") if k in x} for x in label]
    return base


def entry(root, city, station, target, builder, evidence):
    start,anchor,end,freeze=window(target); outcomes=[]
    for kind,rdb,odb in stores(root):
        outcomes.append(candidate(kind,registry_forecast(rdb,city,station,target,anchor),registry_facts(odb,city,station,start,anchor,anchor),registry_facts(odb,city,station,start,end,freeze),start,end,builder))
    # A snapshot can only prove visibility at its own capture date.  Consume the
    # target-date snapshot for the decision, and the D+2 snapshot for the label.
    # Missing either snapshot remains an explicit non-AVAILABLE outcome.
    for forecast_path in evidence.get(target, []):
        label_paths = evidence.get(target + timedelta(days=2), [])
        if not label_paths:
            outcomes.append(candidate("ASOF_EVIDENCE", evidence_forecast(forecast_path,city,station,target,anchor), evidence_facts(forecast_path,city,station,start,anchor,anchor), [], start,end,builder))
        for label_path in label_paths:
            outcomes.append(candidate("ASOF_EVIDENCE",evidence_forecast(forecast_path,city,station,target,anchor),evidence_facts(forecast_path,city,station,start,anchor,anchor),evidence_facts(label_path,city,station,start,end,freeze),start,end,builder))
    base={"city":city,"station":station,"target_date":target.isoformat(),"decision_as_of_utc":z(anchor),"label_available_at_utc":z(freeze),"status":"UNPROVABLE","reason":None,"forecast_high_c":None,"current_observed_max_c":None,"label_final_max_c":None,"source_refs":[],"asof_checks":{"recovery_candidates":len(outcomes),"gap_limit_seconds":GAP_LIMIT}}
    available=[x for x in outcomes if x["status"] == "AVAILABLE"]
    if available:
        if len({(x["forecast_high_c"],x["current_observed_max_c"],x["label_final_max_c"]) for x in available}) != 1: base.update(status="CONFLICT",reason="RECOVERY_SOURCE_VALUE_CONFLICT"); return base
        chosen=available[0]; base.update({k:chosen[k] for k in ("status","reason","forecast_high_c","current_observed_max_c","label_final_max_c","source_refs")}); base["asof_checks"].update(chosen["asof_checks"]); return base
    priority={"CONFLICT":3,"UNPROVABLE":2,"MISSING":1}; chosen=max(outcomes,key=lambda x:priority[x["status"]],default={"status":"MISSING","reason":"NO_LOCATABLE_SOURCE"})
    base.update(status=chosen["status"],reason=chosen["reason"],source_refs=chosen.get("source_refs",[])); base["asof_checks"].update(chosen.get("asof_checks",{})); return base


def build(root, output, cities=None):
    builder=datetime.now(UTC); data={}; source_stores=stores(root); evidence=evidence_index(root)
    selected = CITIES if cities is None else {city:CITIES[city] for city in cities}
    for city,station in selected.items():
        discovery_errors=[]
        date_sets={"forecast":set(),"observation":set(),"label":set(),"evidence":set()}
        for _,rdb,odb in source_stores:
            date_sets["forecast"] |= registry_dates(rdb,city,station)
            observations=observation_dates(odb,city,station,discovery_errors)
            date_sets["observation"] |= observations; date_sets["label"] |= observations
        for paths in evidence.values():
            for path in paths:
                evidence_forecast_days=evidence_dates(path,city,station,discovery_errors)
                date_sets["forecast"] |= evidence_forecast_days
                observations=evidence_observation_dates(path,city,station,discovery_errors)
                date_sets["observation"] |= observations; date_sets["label"] |= observations
                # Evidence dates are only dates carried by this city's actual
                # forecast or observation payloads, never snapshot directory names.
                date_sets["evidence"] |= evidence_forecast_days | observations
        days=set().union(*date_sets.values())
        docs=[entry(root,city,station,day,builder,evidence) for day in sorted(days)]; count=Counter(x["status"] for x in docs)
        data[city]={"schema_version":"WP03_MULTI_CITY_TAF_POPULATION_V3","city":city,"station":station,"source":SOURCE,"builder_as_of_utc":z(builder),"source_date_sets":date_set_payload(date_sets),"label_date_basis":"observation_report_dates_reconstructed; no persisted_weather_label_table","date_discovery_time_parse_records":discovery_errors,"candidate_days":docs,"counts":{"TOTAL_CANDIDATE_DAYS":len(docs),"AVAILABLE_MATURE_DAYS":count["AVAILABLE"],"MISSING_DAYS":count["MISSING"],"CONFLICT_DAYS":count["CONFLICT"],"UNPROVABLE_DAYS":count["UNPROVABLE"]}}
    for city,doc in data.items():
        path=output/city.lower()/"population.json"; path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for city in data:
        recovery={"source":SOURCE,"city":city,"station":CITIES[city],"candidate_date_rule":"union(forecast,observation,label,evidence)","label_date_basis":"observation_report_dates_reconstructed; no persisted_weather_label_table","all_source_combinations_attempted":True,"asof_evidence_payloads_consumed":True,"evidence_paths":[str(p.relative_to(root)).replace("\\","/") for paths in evidence.values() for p in paths]}
        recovery_path=output/city.lower()/"data_recovery"/"source_registry.json"; recovery_path.parent.mkdir(parents=True,exist_ok=True); recovery_path.write_text(json.dumps(recovery,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return data


if __name__ == "__main__":
    if len(sys.argv) != 5 or sys.argv[1] != "--city" or sys.argv[3] != "--output-root":
        raise SystemExit("usage: population.py --city Beijing|Guangzhou --output-root <new-run-root>")
    city, out = sys.argv[2], Path(sys.argv[4]).resolve()
    if city not in CITIES: raise SystemExit("city must be Beijing or Guangzhou")
    root=Path(__file__).resolve().parents[2]
    if out == root / "data/strategy_analysis/wp03_multi_city_validation_v1/20260905T194807+0800": raise SystemExit("refusing prior provisional output root")
    result=build(root,out,[city]); print(canon({k:v["counts"] for k,v in result.items()}))
