"""Bounded offline saved-row replay. This is not a live daily capture command."""
import argparse
import json
import socket
from datetime import datetime, date, time
from pathlib import Path
from unittest.mock import patch
from .dynamic_event_router import CITIES, LOCAL, DynamicEvent
from .dynamic_forward import DynamicForward, verify_snapshot
from .dynamic_evaluator import FrozenEvaluator, load_bindings, sha
from .dynamic_source_adapter import load_saved_city
from .population import parse
from .asof_input import seal_fact

def save(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream: json.dump(value,stream,ensure_ascii=False,indent=2,default=str)


def classify_failure(error, error_type=None):
    reason = str(error).upper()
    kind = error_type or type(error).__name__
    if 'NO_LEGAL' in reason or 'COVERAGE' in reason:
        return 'COVERAGE_INSUFFICIENT'
    if any(x in reason for x in ('FREEZE','FROZEN_MODEL','CANDIDATE_BINDING','CANDIDATE_REFERENCE')):
        return 'FREEZE_IDENTITY_FAILURE'
    if any(x in reason for x in ('SNAPSHOT','SAVED_HASH','CLAIM','INCOMPLETE_PRIOR','EVENT_CHAIN','STATE_INTEGRITY','RESTART_EVENT')):
        return 'STATE_INTEGRITY_FAILURE'
    if any(x in reason for x in ('SOURCE_FACT_HASH','RAW_OBSERVATION_HASH','SOURCE_IDENTITY','SOURCE_BINDING','CITY_STATION','CROSS_CITY','REVISION_IDENTITY','SAME_RANK','EVENT_SOURCEFACT_CONFLICT','EVENT_SOURCE_TYPE')):
        return 'SOURCE_IDENTITY_FAILURE'
    if any(x in reason for x in ('FUTURE','PREMATURE','IMMATURE','ASOF_INVALID','ASOF_CONTRACT','WINDOW_INVALID','AWARE','TIMEZONE','COMMIT_VISIBILITY_MISMATCH','EVENT_EFFECTIVE')):
        return 'ASOF_CONTRACT_FAILURE'
    if any(x in reason for x in ('UNPROVABLE','UNPROVEN','MISSING_AT_ASOF','EVENT_SOURCEFACT_MISSING','INSUFFICIENT_PROVEN','AVAILABILITY_UNPROVABLE')):
        return 'DATA_EVIDENCE_INSUFFICIENT'
    if kind in ('PermissionError','FileNotFoundError','OSError','OperationalError'):
        return 'ENVIRONMENT_FAILURE'
    if 'COVERAGE' in reason or 'NO_LEGAL' in reason:
        return 'COVERAGE_INSUFFICIENT'
    return 'IMPLEMENTATION_FAILURE'


def replay_verdict(rows, adapter_failures):
    failures = [r.get('failure_class') or classify_failure(r.get('error_reason',''),r.get('error_type'))
                for r in rows if r.get('status')=='FAILURE']
    failures += [classify_failure(r.get('error_reason',''),r.get('error_type')) for r in adapter_failures]
    legal = sum(r.get('legal_dynamic_snapshot',False) for r in rows)
    if not legal and not failures: failures.append('COVERAGE_INSUFFICIENT')
    return {'status':'PASS' if legal >= 1 and not failures else 'BLOCKED',
            'legal_dynamic_weather_snapshot_count':legal,
            'failure_classes':sorted(set(failures)), 'adapter_failure_count':len(adapter_failures)}

def timeline(city, target, facts):
    opening = datetime.combine(date.fromisoformat(target),time(7),LOCAL)
    closing = datetime.combine(date.fromisoformat(target),time(16),LOCAL)
    result = [(opening,DynamicEvent(city,'WindowBoundaryV1',city+target+'OPEN','OPEN',opening),'PROTOCOL_BOUNDARY')]
    for fact in facts:
        if fact['target_date'] != target: continue
        at = parse(fact['replay_visible_record_time'])
        if not opening <= at < closing: continue
        transition = 'LEGAL_FORECAST_REVISION' if fact['fact_type']=='FORECAST' else 'LEGAL_METAR_OR_SPECI'
        result.append((at,DynamicEvent(city,'SourceFactV1',fact['identity'],transition,parse(fact['event_time'])),
                       'SAVED_RESEARCH_ROW_REQUIRES_STRICT_INPUT_CHECK'))
    checkpoint = datetime.combine(date.fromisoformat(target),time(8),LOCAL)
    result.append((checkpoint,DynamicEvent(city,'NO_NEW_CAUSE_OR_STATE',city+target+'CHECKPOINT','UNCHANGED',checkpoint),'PROTOCOL_CHECKPOINT'))
    result.append((closing,DynamicEvent(city,'WindowBoundaryV1',city+target+'CLOSE','CLOSE',closing),'PROTOCOL_BOUNDARY'))
    # Processing uses the saved receive/first-seen time, never report time before arrival.
    return sorted(result,key=lambda x:(x[0],x[1].cause_type,x[1].cause_object_id))

def replay_city(city,target,adapter,evaluator,store,output):
    rows=[]; model_before=evaluator.model_count
    ordered=timeline(city,target,adapter['facts'])
    for at,event,origin in ordered:
        before=evaluator.model_count; called_before=evaluator.call_count
        try:
            record=store.inject(event,at,evaluator)
            legal = False
            if record.get('snapshot_path'):
                snap=verify_snapshot(record['snapshot_path'],store.root/city/target,city,store.bindings[city])
                legal = (snap.get('execution_mode')=='OFFLINE_DYNAMIC_REPLAY' and
                         snap.get('event_sourcefact_binding') is not None and
                         origin.startswith('SAVED') and isinstance(evaluator,FrozenEvaluator))
        except Exception as exc:
            record={'status':'FAILURE','error_type':type(exc).__name__,'error_reason':str(exc)}
            legal=False
        rows.append({'event_time':event.effective_at_utc.isoformat(),'processed_as_of':at.isoformat(),
            'event_identity':event.key(),'origin':origin,'action':record.get('action','NO_EVENT'),
            'model_called':evaluator.model_count>before,'evaluator_called':evaluator.call_count>called_before,
            'weather_snapshot_id':record.get('snapshot_hash'),'market_snapshot_reference':record.get('weather_snapshot_hash'),
            'status':record.get('status','HEALTH_ONLY'),'error_reason':record.get('error_reason'),
            'error_type':record.get('error_type'),'legal_dynamic_snapshot':legal,
            'failure_class':(record.get('failure_class') or classify_failure(record.get('error_reason',''),record.get('error_type'))) if record.get('status')=='FAILURE' else None})
    save(output/'ordered_event_timeline.json',rows)
    save(output/'weather_inputs.json',evaluator.inputs)
    # Reopening the same state and re-reading each event must not call the evaluator.
    reopened=DynamicForward(store.root,store.bindings); duplicate_before=evaluator.call_count
    duplicates=[reopened.inject(event,at,evaluator) for at,event,_ in ordered]
    if evaluator.call_count != duplicate_before: raise ValueError('RESTART_EVENT_IDEMPOTENCY_FAILED')
    save(output/'restart_duplicates.json',duplicates)
    models=evaluator.model_count-model_before
    summary={'city':city,'target_date':target,'event_count':len(rows),
        'saved_source_event_count':sum(r['origin'].startswith('SAVED') for r in rows),
        'weather_evaluation_count':models,'evaluator_attempt_count':sum(r['evaluator_called'] for r in rows),
        'failure_count':sum(r['status']=='FAILURE' for r in rows),
        'market_only_event_count':sum(r['action']=='MARKET_ONLY_REEVALUATION_REQUEST' for r in rows),
        'market_only_weather_model_call_count':sum(r['model_called'] for r in rows if r['action']=='MARKET_ONLY_REEVALUATION_REQUEST'),
        'restart_idempotency':'PASS',**replay_verdict(rows,adapter.get('failures',[])),
        'blind_scoring_days_added':0,'real_capture_executed':False}
    save(output/'summary.json',summary)
    return summary

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--references',type=Path,required=True)
    parser.add_argument('--research-db',type=Path,required=True)
    parser.add_argument('--observations-db',type=Path,required=True)
    parser.add_argument('--target-date',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    references=load_bindings(args.references)
    if args.output.exists(): raise ValueError('REPLAY_OUTPUT_EXISTS')
    # Validate research-root boundary before creating output or opening sources.
    store=DynamicForward(args.output/'state',{c:x['candidate_freeze_identity'] for c,x in references.items()})
    def forbidden(*a,**kw): raise RuntimeError('NETWORK_FORBIDDEN')
    results=[]
    with patch.object(socket,'create_connection',forbidden),patch.object(socket.socket,'connect',forbidden):
        for city,item in references.items():
            out=args.output/city
            try:
                freeze=json.loads(Path(item['referenced_benchmark_freeze_path']).read_text(encoding='utf-8'))
                population_path=Path(freeze.get('population_path',''))
                if city=='Shanghai' and sha(freeze['existing_freeze']['path']) != freeze['existing_freeze']['sha256']:
                    raise ValueError('SHANGHAI_ORIGINAL_FREEZE_MISMATCH')
                # Freeze layout-specific population reference is supplied by the existing freeze.
                if not population_path.is_file(): raise ValueError('FROZEN_TRAINING_POPULATION_PATH_UNRESOLVED')
                expected=freeze.get('population_sha256')
                if expected is None or sha(population_path)!=expected: raise ValueError('FROZEN_POPULATION_HASH_MISMATCH')
                population=json.loads(population_path.read_text(encoding='utf-8'))
                days=[r for r in population['candidate_days'] if r['status']=='AVAILABLE']
                dates=[r['target_date'] for r in days]
                adapter=load_saved_city(city,args.target_date,args.research_db,args.observations_db,dates)
                save(out/'source_records.json',adapter)
                labels=[seal_fact({'city':city,'station':CITIES[city],'target_date':r['target_date'],'fact_type':'LABEL',
                    'identity':str(population_path)+':'+r['target_date'],'source_identity':'FROZEN_RESEARCH_POPULATION',
                    'value_c':r.get('label_final_max_c'),'label_available_at':r.get('label_available_at_utc'),
                    'effective':None,'observed':None,'received':None,'available':None,'committed':None,
                    'population_hash':expected}) for r in days]
                evaluator=FrozenEvaluator(args.references,{city:adapter['facts']},{city:labels},{city:dates})
                results.append(replay_city(city,args.target_date,adapter,evaluator,store,out))
            except Exception as exc:
                result={'city':city,'status':'BLOCKED','error_type':type(exc).__name__,'error_reason':str(exc),
                    'failure_class':classify_failure(exc), 'legal_dynamic_weather_snapshot_count':0,
                    'event_count':0,'weather_evaluation_count':0,'real_capture_executed':False}
                save(out/'city_failure.json',result); results.append(result)
    save(args.output/'replay_summary.json',results)
    print(json.dumps(results,ensure_ascii=False))

if __name__=='__main__': main()
