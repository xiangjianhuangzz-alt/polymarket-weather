"""Frozen pure-kernel integration; no source acquisition, scoring or model changes."""
import hashlib
import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from strategy_v8.contracts import City
from strategy_v8.canonical import hash_v1
from tools.research_weather_validation_v1.runner import (
    ResearchTrainingRecord, ResearchPredictionInputs, predict_research_weather,
    research_weather_buckets, research_probability_from_samples)
from tools.research_weather_validation_v1.metrics import mean
from .asof_input import build_input, number, bind_source_event
from .population import parse
from .dynamic_event_router import LOCAL, CITIES

PROJECT = Path('D:/polymarket天气')

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_bindings(reference_path):
    refs = json.loads(Path(reference_path).read_text(encoding='utf-8'))
    if set(refs['candidates']) != set(CITIES): raise ValueError('THREE_CITY_BINDINGS_REQUIRED')
    for city, item in refs['candidates'].items():
        payload = item['identity_payload']
        if item['city'] != city or item['station'] != CITIES[city]: raise ValueError('CITY_BINDING_INVALID')
        if hash_v1('PWM.DYNAMIC_CANDIDATE_REFERENCE.V1',payload) != item['candidate_freeze_identity']:
            raise ValueError('CANDIDATE_REFERENCE_MISMATCH')
        if sha(item['referenced_benchmark_freeze_path']) != payload['referenced_candidate_freeze_sha256']:
            raise ValueError('CANDIDATE_FREEZE_HASH_MISMATCH')
        for path, expected in payload['model_source_hashes'].items():
            if sha(PROJECT/path) != expected: raise ValueError('FROZEN_MODEL_SOURCE_MISMATCH:'+path)
    return refs['candidates']

def evaluate_input(inputs):
    expected = hash_v1('PWM.DYNAMIC.ASOF_INPUT.V1',{k:v for k,v in inputs.items() if k != 'input_hash'})
    if inputs.get('input_hash') != expected: raise ValueError('DYNAMIC_INPUT_HASH_MISMATCH')
    city = inputs['city']; asof = parse(inputs['decision_as_of']); local = asof.astimezone(LOCAL)
    second = local.hour*3600+local.minute*60+local.second
    checked = build_input(city,inputs['target_date'],inputs['decision_as_of'],
        [inputs['forecast'],*inputs['observations'],*(r['forecast'] for r in inputs['training'])],
        [r['label'] for r in inputs['training']],inputs['candidate_freeze_identity'],
        [r['target_date'] for r in inputs['training']])
    if checked != inputs: raise ValueError('DYNAMIC_INPUT_REVALIDATION_MISMATCH')
    records = [ResearchTrainingRecord(date.fromisoformat(r['target_date']),number(r['forecast_high_c']),
        number(r['label_final_max_c']),parse(r['label']['label_available_at']),City[city.upper()],second) for r in inputs['training']]
    model_input = ResearchPredictionInputs(date.fromisoformat(inputs['target_date']),number(inputs['forecast']['value_c']),
        number(inputs['O_t']),inputs['decision_as_of'],City[city.upper()],second)
    buckets = research_weather_buckets()
    residuals = [r.residual_c for r in records]
    probabilities, candidate_mean = predict_research_weather(model_input,residuals,buckets)
    # Obtain raw sample evidence through the same frozen kernel, not a second formula.
    samples = [predict_research_weather(model_input,[residual],buckets)[1] for residual in residuals]
    raw_values, quant = research_probability_from_samples(samples,buckets)
    if raw_values != probabilities: raise ValueError('FROZEN_KERNEL_REPRESENTATION_MISMATCH')
    baseline_values, baseline_quant = research_probability_from_samples([r.final_max_c for r in records],buckets)
    def raw(meta):
        return [str(Decimal(x['numerator'])/Decimal(x['denominator'])) for x in meta['raw_probability_vector']]
    def fact(value):
        result = dict(value)
        for key in ('effective','observed','received','available','committed'):
            result[key] = parse(value[key]) if value.get(key) is not None else None
        return result
    training = []
    for row in inputs['training']:
        item = fact(row['forecast'])
        item.update(target_date=row['target_date'],local_second=row['local_second'],
                    label_available_at=parse(row['label']['label_available_at']),label_identity=row['label']['identity'],
                    label_hash=row['label']['hash'])
        training.append(item)
    return {'target_date':inputs['target_date'],'candidate_freeze_identity':inputs['candidate_freeze_identity'],
        'forecast':fact(inputs['forecast']),'observations':[fact(x) for x in inputs['observations']], 'training':training,
        'raw_candidate_probabilities':raw(quant),'quantized_candidate_probabilities_e12':quant['per_bucket_ticks'],
        'candidate_mean':str(candidate_mean),'baseline_output':{'raw_probabilities':raw(baseline_quant),
        'ticks':baseline_quant['per_bucket_ticks'],'mean':str(mean([r.final_max_c for r in records]))},
        'research_quantization_evidence':{'candidate':quant,'baseline':baseline_quant},
        'pure_kernel_call_count':len(records)+1,'execution_mode':'OFFLINE_DYNAMIC_REPLAY'}

class FrozenEvaluator:
    def __init__(self, references, facts_by_city, labels_by_city, training_dates_by_city):
        self.references = references
        self.bindings = load_bindings(references)
        self.facts = facts_by_city; self.labels = labels_by_city; self.dates = training_dates_by_city
        self.call_count = 0; self.model_count = 0; self.inputs = []

    def validate_event(self, event, asof):
        return bind_source_event(event, asof, self.facts[event.city])

    def __call__(self,event,asof):
        trigger = self.validate_event(event, asof)
        self.call_count += 1
        bindings = load_bindings(self.references)
        if bindings != self.bindings: raise ValueError('CANDIDATE_BINDING_CHANGED')
        city = event.city
        value = build_input(city,asof.astimezone(LOCAL).date().isoformat(),asof.isoformat(),
            self.facts[city],self.labels[city],bindings[city]['candidate_freeze_identity'],self.dates[city])
        self.inputs.append(value)
        result = evaluate_input(value)
        self.model_count += 1
        result['runtime_event_id'] = hash_v1('PWM.DYNAMIC.EVENT.KEY.V1',event.key())
        result['event_sourcefact_binding'] = trigger
        return result
