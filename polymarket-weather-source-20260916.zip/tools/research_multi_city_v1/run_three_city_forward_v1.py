"""Hash-bound, check-only launcher for the three independent forward candidates."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import uuid
from decimal import Decimal, InvalidOperation
from datetime import datetime, time, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

PROJECT = Path("D:/polymarket天气").resolve()
RUN = PROJECT / "data/strategy_analysis/wp03_three_city_candidate_freeze_forward_v1/20260905T222830+0800"
PYTHON = PROJECT / ".venv-strategy-tests-v1/Scripts/python.exe"
SHANGHAI_CONFIG = PROJECT / "data/strategy_analysis/wp03_forward_blind_accumulation_v1/20260905T184548+0800/forward_config.json"
CANDIDATES = {"Shanghai": "tools.research_forward_collection_v1.daily", "Beijing": "tools.research_multi_city_v1.forward", "Guangzhou": "tools.research_multi_city_v1.forward"}
STATIONS = {"Shanghai": "ZSPD", "Beijing": "ZBAA", "Guangzhou": "ZGGG"}
LOCAL = ZoneInfo("Asia/Shanghai")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def load_manifest(path: Path) -> dict:
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if Path(manifest.get("run_root", "")).resolve() != RUN or set(manifest.get("candidates", {})) != set(CANDIDATES):
        raise ValueError("MANIFEST_IDENTITY_INVALID")
    for city, module in CANDIDATES.items():
        item = manifest["candidates"][city]
        freeze, config = Path(item.get("freeze_path", "")).resolve(), Path(item.get("config_path", "")).resolve()
        if item.get("entrypoint") != module or sha(freeze) != item.get("freeze_sha256") or sha(config) != item.get("config_sha256"):
            raise ValueError("CANDIDATE_HASH_INVALID:" + city)
        frozen = json.loads(freeze.read_text(encoding="utf-8"))
        if frozen.get("city") != city or frozen.get("station") != STATIONS[city] or sha(Path(frozen["population_path"])) != frozen.get("population_sha256") or sha(Path(frozen["protocol_path"])) != frozen.get("protocol_sha256"):
            raise ValueError("FREEZE_IDENTITY_INVALID:" + city)
        for source, expected in frozen.get("source_hashes", {}).items():
            if sha(PROJECT / source) != expected:
                raise ValueError("FREEZE_SOURCE_CHANGED:" + source)
        if city != "Shanghai":
            for name in ("population_acceptance", "evidence_recovery_provenance", "recovered_snapshot"):
                ref = frozen.get(name, {})
                if not isinstance(ref, dict) or sha(Path(ref.get("path", ""))) != ref.get("sha256"):
                    raise ValueError("FREEZE_RECOVERY_INVALID:" + city)
            configured = json.loads(config.read_text(encoding="utf-8"))
            if configured.get("freeze_path") != str(freeze) or configured.get("freeze_sha256") != item["freeze_sha256"]:
                raise ValueError("CONFIG_FREEZE_MISMATCH:" + city)
        if city == "Shanghai":
            if config != SHANGHAI_CONFIG:
                raise ValueError("SHANGHAI_CONFIG_NOT_FROZEN")
            alias = frozen.get("existing_freeze", {})
            if sha(Path(alias.get("path", ""))) != alias.get("sha256"):
                raise ValueError("SHANGHAI_ALIAS_FREEZE_INVALID")
        elif RUN not in config.parents or config.parent.name != "forward_configs":
            raise ValueError("CITY_CONFIG_OUTSIDE_RUN:" + city)
    return manifest


def _bound_prediction(city, item, config_path, config, root, prediction):
    freeze_path = Path(item['freeze_path']).resolve()
    frozen = json.loads(freeze_path.read_text(encoding='utf-8'))
    if sha(config_path) != item['config_sha256'] or sha(freeze_path) != item['freeze_sha256']:
        return False
    if frozen.get('city') != city or frozen.get('station') != STATIONS[city]:
        return False
    if city == 'Shanghai':
        ref = frozen['existing_freeze']
        source = Path(ref['path']).resolve()
        alias = json.loads(source.read_text(encoding='utf-8'))
        if sha(source) != ref['sha256'] or config.get('freeze_sha256') != ref['sha256']:
            return False
        if Path(config['freeze_path']).resolve() != source or root.resolve() != source.parent:
            return False
        return prediction.get('freeze_id') == alias.get('freeze_id') and prediction.get('freeze_sha256') == ref['sha256']
    return (config.get('city') == city and config.get('station') == STATIONS[city]
            and Path(config['freeze_path']).resolve() == freeze_path
            and config.get('freeze_sha256') == item['freeze_sha256']
            and root.resolve() == freeze_path.parent / city.lower() / 'forward'
            and prediction.get('freeze_sha256') == item['freeze_sha256']
            and prediction.get('city') == city and prediction.get('station') == STATIONS[city]
            and prediction.get('execution_mode') == 'FORWARD_BLIND')


def counters(manifest: dict) -> dict:
    result = {}
    for city, item in manifest["candidates"].items():
        config_path = Path(item["config_path"])
        config = json.loads(config_path.read_text(encoding="utf-8"))
        root = Path(config.get("output_root", ""))
        days = root / "days"
        targets = {path.name: path for path in days.glob("????-??-??") if any((path / name).exists() for name in ("claim.json", "attempt.json", "result.json", "prediction.json", "score.json", "weather_failure.json"))} if days.is_dir() else {}
        prediction_days = scored_days = failure_days = 0
        for path in targets.values():
            prediction_path = path / "prediction.json"
            try:
                prediction = json.loads(prediction_path.read_text(encoding="utf-8"))
                sidecar = prediction_path.with_suffix(".json.sha256").read_text(encoding="ascii").strip()
                hash_ok = sidecar == sha(prediction_path)
            except (FileNotFoundError, UnicodeDecodeError, json.JSONDecodeError): prediction, hash_ok = None, False
            required = {"target_date", "status", "training_dates", "training_count", "model_probabilities", "baseline_probabilities", "model_temperature_mean_c", "baseline_temperature_mean_c"}
            def finite(value):
                try: return Decimal(str(value)).is_finite()
                except (InvalidOperation, ValueError, TypeError): return False
            vectors_ok = isinstance(prediction, dict) and all(isinstance(prediction.get(key), list) and len(prediction[key]) == 52 and all(finite(value) for value in prediction[key]) for key in ("model_probabilities", "baseline_probabilities"))
            created_ok = isinstance(prediction, dict) and isinstance(prediction.get("prediction_created_at_utc", prediction.get("prediction_created_at")), str)
            try:
                city_identity_ok = isinstance(prediction, dict) and _bound_prediction(city, item, config_path, config, root, prediction)
            except (KeyError, OSError, UnicodeError, ValueError, TypeError):
                city_identity_ok = False
            success = isinstance(prediction, dict) and required <= set(prediction) and city_identity_ok and prediction.get("target_date") == path.name and prediction.get("status") == "PREDICTION_SAVED_AWAITING_LABEL" and isinstance(prediction["training_dates"], list) and prediction["training_count"] == len(prediction["training_dates"]) and vectors_ok and finite(prediction["model_temperature_mean_c"]) and finite(prediction["baseline_temperature_mean_c"]) and created_ok and hash_ok
            try:
                score_path = path / "score.json"; score = json.loads(score_path.read_text(encoding="utf-8"))
                score_hash_ok = score_path.with_suffix(".json.sha256").read_text(encoding="ascii").strip() == sha(score_path)
            except (FileNotFoundError, UnicodeDecodeError, json.JSONDecodeError): score, score_hash_ok = None, False
            prediction_days += bool(success)
            score_valid = success and isinstance(score, dict) and score_hash_ok and score.get("evaluation_status") == "SCORED" and score.get("prediction_sha256") == sha(prediction_path)
            scored_days += bool(score_valid)
            try:
                result_text = (path / "result.json").read_text(encoding="utf-8")
                day_result = json.loads(result_text)
            except (FileNotFoundError, json.JSONDecodeError): day_result = {}
            result_failure = isinstance(day_result, dict) and (day_result.get("status") == "CAPTURE_FAILURE" or day_result.get("weather_status") == "CAPTURE_FAILURE" or isinstance(day_result.get("market"), dict) and day_result["market"].get("status") in ("MARKET_PARTIAL", "MARKET_MISSING"))
            attempted = any((path / name).exists() for name in ('claim.json', 'attempt.json', 'result.json', 'weather_failure.json'))
            failure_days += bool((prediction_path.exists() or attempted) and not success or score_path.exists() and not score_valid or result_failure)
        result[city] = {"attempted_days": len(targets), "prediction_days": prediction_days, "scored_days": scored_days, "failure_days": failure_days, "historical_exploratory_days_excluded": True}
    return result


def launch(manifest: dict, popen=subprocess.Popen, attempt_root: Path | None = None, research_live_read: bool = False, target_date: str | None = None, now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("AWARE_NOW_REQUIRED")
    if research_live_read and not (time(7, 58) <= now.astimezone(LOCAL).time() < time(8, 0)):
        raise ValueError("LIVE_READ_OUTSIDE_WINDOW")
    target_date = target_date or now.astimezone(LOCAL).date().isoformat()
    attempt = (attempt_root or RUN / "launcher_attempts") / uuid.uuid4().hex
    attempt.mkdir(parents=True, exist_ok=False)
    started, results = [], {}
    for city in CANDIDATES:
        item = manifest["candidates"][city]
        stdout, stderr = attempt / f"{city.lower()}.stdout.log", attempt / f"{city.lower()}.stderr.log"
        command = [str(PYTHON), "-X", "utf8", "-B", "-m", item["entrypoint"], "--config", item["config_path"], "--research-live-read", "--target-date", target_date] if research_live_read else [str(PYTHON), "-X", "utf8", "-B", "-m", item["entrypoint"], "--config", item["config_path"], "--check-only"]
        out = err = None
        try:
            out, err = stdout.open("x", encoding="utf-8"), stderr.open("x", encoding="utf-8")
            process = popen(command, cwd=PROJECT, stdout=out, stderr=err)
            started.append((city, process, out, err, command, stdout, stderr, utc()))
        except OSError as error:
            if out is not None: out.close()
            if err is not None: err.close()
            results[city] = {"status": "START_ERROR", "pid": None, "started_at": None, "ended_at": utc(), "exit_code": None, "stdout": str(stdout), "stderr": str(stderr), "error": str(error)}
    for city, process, out, err, command, stdout, stderr, started_at in started:
        try:
            code = process.wait()
            results[city] = {"status": "CHECK_PASS" if code == 0 else "CHECK_FAIL", "pid": getattr(process, "pid", None), "started_at": started_at, "ended_at": utc(), "exit_code": code, "stdout": str(stdout), "stderr": str(stderr), "command": command}
        except OSError as error:
            results[city] = {"status": "WAIT_ERROR", "pid": getattr(process, "pid", None), "started_at": started_at, "ended_at": utc(), "exit_code": None, "stdout": str(stdout), "stderr": str(stderr), "command": command, "error": str(error)}
        finally:
            out.close(); err.close()
    result = {"mode": "RESEARCH_LIVE_READ" if research_live_read else "CHECK_ONLY", "real_capture_executed": "NO" if not research_live_read else "CAPTURE_ATTEMPTED_UNVERIFIED", "cities": results, "blind_counters": counters(manifest)}
    (attempt / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--research-live-read", action="store_true")
    parser.add_argument("--target-date")
    args = parser.parse_args()
    if args.check_only == args.research_live_read or Path(sys.executable).resolve() != PYTHON or Path.cwd().resolve() != PROJECT:
        raise SystemExit("CHECK_ONLY_FIXED_PYTHON_CWD_REQUIRED")
    result = launch(load_manifest(args.manifest), research_live_read=args.research_live_read, target_date=args.target_date)
    print(json.dumps(result, ensure_ascii=False))
    if not all(value["status"] == "CHECK_PASS" for value in result["cities"].values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
