"""Read and verify M1 SourceFact bundles without creating a snapshot or model input."""
from __future__ import annotations

import hashlib
import json
from datetime import date, datetime, timezone
from pathlib import Path

from strategy_v8.canonical import canonical_encode, canonical_time_v1, hash_v1

from .asof_input import seal_fact, validate_fact
from .dynamic_event_router import CITIES, LOCAL
from .m1_sourcefact_capture import _source_fact_id, _taf_high
from .population import parse


UTC = timezone.utc
_BINDINGS = {
    ("Shanghai", "FORECAST"): ("weatherol_shanghai_weatherol_d0", "weatherol_shanghai", "ZSPD"),
    ("Beijing", "FORECAST"): ("aviationweather_taf_zbaa", "aviationweather_taf", "ZBAA"),
    ("Guangzhou", "FORECAST"): ("aviationweather_taf_zggg", "aviationweather_taf", "ZGGG"),
    ("Shanghai", "METAR"): ("aviationweather_metar_zspd", "aviationweather_metar", "ZSPD"),
    ("Beijing", "METAR"): ("aviationweather_metar_zbaa", "aviationweather_metar", "ZBAA"),
    ("Guangzhou", "METAR"): ("aviationweather_metar_zggg", "aviationweather_metar", "ZGGG"),
    ("Shanghai", "SPECI"): ("aviationweather_speci_zspd", "aviationweather_metar", "ZSPD"),
    ("Beijing", "SPECI"): ("aviationweather_speci_zbaa", "aviationweather_metar", "ZBAA"),
    ("Guangzhou", "SPECI"): ("aviationweather_speci_zggg", "aviationweather_metar", "ZGGG"),
}


def _utc_text(value: datetime) -> str:
    if value.tzinfo is None or value.utcoffset() != timezone.utc.utcoffset(value):
        raise ValueError("ADAPTER_TIME_NOT_UTC")
    return canonical_time_v1(value.astimezone(UTC))


def _safe_root(root: Path) -> Path:
    resolved = Path(root).resolve()
    if not resolved.is_dir():
        raise ValueError("BUNDLE_ROOT_MISSING")
    return resolved


def _safe_raw(root: Path, relative: object, expected_hash: str) -> bytes:
    if not isinstance(relative, str) or relative != f"raw_blobs/{expected_hash}.bin":
        raise ValueError("RAW_BLOB_PATH_INVALID")
    path = (root / relative).resolve()
    if not path.is_relative_to(root / "raw_blobs"):
        raise ValueError("RAW_BLOB_PATH_ESCAPE")
    if not path.is_file():
        raise ValueError("RAW_BLOB_MISSING")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_hash:
        raise ValueError("RAW_PAYLOAD_HASH_INVALID")
    return raw


def _milli(value: object) -> str:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("NORMALIZED_MILLI_INVALID")
    sign = "-" if value < 0 else ""
    whole, fraction = divmod(abs(value), 1000)
    return (f"{sign}{whole}.{fraction:03d}").rstrip("0").rstrip(".")


def _derived_projection(raw: dict, city: str, target_date: str, kind: str) -> int | tuple[str, str, int]:
    if kind == "FORECAST_HIGH_C_MILLI":
        if city != "Shanghai":
            payload = raw["payload"]
            if not isinstance(payload, list) or len(payload) != 1 or not isinstance(payload[0], dict) or payload[0].get("icaoId") != CITIES[city]:
                raise ValueError("TAF_PAYLOAD_CARDINALITY_INVALID")
            return _taf_high(payload[0], target_date)
        payload = raw["payload"]
        current = payload["data"]["current"]["current"]
        if payload.get("code") != 200 or current.get("jcid") != "JCCN100117" or current.get("airportname") != "上海浦东国际机场":
            raise ValueError("WEATHEROL_IDENTITY_INVALID")
        match = next((item for item in payload["data"]["forecast15d"] if item.get("forecasttime") == target_date[5:].replace("-", "/")), None)
        if not isinstance(match, dict):
            raise ValueError("WEATHEROL_TARGET_MISSING")
        return int(match["temperature_am"]) * 1000
    payload = raw["payload"]
    if not isinstance(payload, list) or len(payload) != 1 or not isinstance(payload[0], dict):
        raise ValueError("METAR_PAYLOAD_CARDINALITY_INVALID")
    report = payload[0]
    if report.get("icaoId") != CITIES[city] or report.get("metarType") not in ("METAR", "SPECI"):
        raise ValueError("METAR_PAYLOAD_IDENTITY_INVALID")
    return report["metarType"], canonical_time_v1(parse(report["reportTime"])), int(round(float(report["temp"]) * 1000))


def _kind(city: str, normalized: dict) -> tuple[str, str, str]:
    projection = normalized.get("canonical_projection")
    if not isinstance(projection, dict):
        raise ValueError("NORMALIZED_PROJECTION_INVALID")
    kind = normalized.get("projection_kind")
    if kind == "FORECAST_HIGH_C_MILLI":
        return "FORECAST", "forecast_high_c_milli", projection.get("target_date")
    if kind == "METAR_SPECI_TEMPERATURE_C_MILLI":
        fact_type = projection.get("report_type")
        if fact_type not in ("METAR", "SPECI") or projection.get("station") != CITIES[city]:
            raise ValueError("NORMALIZED_OBSERVATION_IDENTITY_INVALID")
        report_at = parse(projection.get("report_time_utc"))
        return fact_type, "temperature_c_milli", report_at.astimezone(LOCAL).date().isoformat()
    raise ValueError("NORMALIZED_PROJECTION_KIND_INVALID")


def _verify_bundle(root: Path, city: str, target_date: str, path: Path, sequence: int) -> tuple[dict, dict]:
    expected_name = f"{sequence:020d}.json"
    if path.name != expected_name:
        raise ValueError("COMMIT_WATERLINE_NOT_CONTIGUOUS")
    try:
        bundle = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("COMMIT_BUNDLE_INVALID_JSON") from exc
    claimed_hash = bundle.pop("bundle_hash", None)
    if bundle.get("schema_version") != "M1_SOURCEFACT_COMMIT_BUNDLE_V1" or bundle.get("sequence") != sequence:
        raise ValueError("COMMIT_BUNDLE_IDENTITY_INVALID")
    if not isinstance(claimed_hash, str) or hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", bundle) != claimed_hash:
        raise ValueError("COMMIT_BUNDLE_HASH_INVALID")
    raw_fact = bundle.get("raw_source_fact")
    normalized = bundle.get("normalized_source_fact")
    if not isinstance(raw_fact, dict) or not isinstance(normalized, dict):
        raise ValueError("COMMIT_BUNDLE_FIELDS_INVALID")
    if raw_fact.get("schema_version") != "RAW_SOURCE_FACT_V1" or raw_fact.get("city") != city:
        raise ValueError("RAW_SOURCE_IDENTITY_INVALID")
    if normalized.get("schema_version") != "NORMALIZED_SOURCE_FACT_V1":
        raise ValueError("NORMALIZED_SCHEMA_INVALID")
    raw_hash = raw_fact.get("raw_payload_hash")
    canonical_hash = raw_fact.get("canonical_payload_hash")
    if not isinstance(raw_hash, str) or not isinstance(canonical_hash, str):
        raise ValueError("RAW_HASH_MISSING")
    raw = _safe_raw(root, bundle.get("raw_blob_relative_path"), raw_hash)
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("RAW_PAYLOAD_INVALID_JSON") from exc
    if hashlib.sha256(canonical_encode(parsed)).hexdigest() != canonical_hash:
        raise ValueError("CANONICAL_PAYLOAD_HASH_INVALID")
    source_id = _source_fact_id(city, raw_fact.get("source_binding_id"), raw_fact.get("source_publication_id"), raw_fact.get("source_revision_id"), canonical_hash)
    if raw_fact.get("source_fact_id") != source_id or normalized.get("source_fact_id") != source_id:
        raise ValueError("SOURCE_FACT_ID_INVALID")
    projection = normalized.get("canonical_projection")
    expected_projection_hash = hash_v1("PWM.IIC2.NORMALIZED_PROJECTION.V1", {
        "projection_kind": normalized.get("projection_kind"), "value": projection,
    })
    if normalized.get("canonical_projection_hash") != expected_projection_hash:
        raise ValueError("NORMALIZED_PROJECTION_HASH_INVALID")
    expected_contract = hash_v1("V8_NORMALIZATION_CONTRACT_V1", {
        "source_binding_id": raw_fact.get("source_binding_id"), "projection_kind": normalized.get("projection_kind"),
        "parser_id": "M1_AVIATIONWEATHER_JSON_PARSER_V1"})
    if normalized.get("normalization_contract_hash") != expected_contract:
        raise ValueError("NORMALIZATION_CONTRACT_HASH_INVALID")
    expected_normalized_id = hash_v1("PWM.IIC2.NORMALIZED_SOURCE_FACT.V1", {
        key: normalized.get(key) for key in ("source_fact_id", "normalization_contract_hash", "projection_kind", "canonical_projection_hash")
    })
    if normalized.get("normalized_fact_id") != expected_normalized_id:
        raise ValueError("NORMALIZED_FACT_ID_INVALID")
    fact_type, value_key, projection_date = _kind(city, normalized)
    binding, source_identity, station = _BINDINGS[(city, fact_type)]
    if raw_fact.get("source_binding_id") != binding or projection_date != target_date:
        raise ValueError("BUNDLE_PARTITION_IDENTITY_INVALID")
    derived = _derived_projection({"payload": parsed, "normalized_source_fact": normalized}, city, target_date, normalized["projection_kind"])
    if fact_type == "FORECAST":
        projection_matches = projection.get("city") == city and projection.get("target_date") == target_date and projection.get("forecast_high_c_milli") == derived
    else:
        report_type, report_time, temperature = derived
        projection_matches = (projection.get("city") == city and projection.get("station") == station and
                              projection.get("report_type") == report_type and projection.get("report_time_utc") == report_time and
                              projection.get("temperature_c_milli") == temperature)
    if not projection_matches:
        raise ValueError("RAW_PROJECTION_MISMATCH")
    for key in ("effective_at_utc", "observed_at_utc", "committed_at_utc"):
        if not isinstance(raw_fact.get(key), str):
            raise ValueError("SOURCE_TIME_MISSING")
    effective, observed, committed = (parse(raw_fact[key]) for key in ("effective_at_utc", "observed_at_utc", "committed_at_utc"))
    if not effective <= observed <= committed:
        raise ValueError("SOURCE_TIME_ORDER_INVALID")
    fact = seal_fact({
        "city": city, "station": station, "target_date": target_date, "fact_type": fact_type,
        "identity": source_id, "source_identity": source_identity,
        "revision": raw_fact["source_revision_id"], "revision_rank": raw_fact.get("source_revision_rank"),
        "value_c": _milli(projection.get(value_key)),
        "effective": raw_fact["effective_at_utc"], "observed": raw_fact["observed_at_utc"],
        "received": None, "available": None, "committed": raw_fact["committed_at_utc"],
        "bundle_hash": claimed_hash, "raw_payload_hash": raw_hash,
        "normalized_fact_id": normalized["normalized_fact_id"],
    })
    validate_fact(fact, city, station)
    return fact, {"sequence": sequence, "source_fact_id": source_id, "bundle_hash": claimed_hash}


def load_city_day(root: Path, city: str, target_date: str, decision_as_of: datetime | None = None) -> dict:
    """Return verified source facts and an actual local read-completion boundary.

    The returned boundary is evidence of this file read only. It does not claim
    that the bundles were visible at their writer-assigned committed timestamps.
    """
    if city not in CITIES:
        raise ValueError("CITY_INVALID")
    try:
        date.fromisoformat(target_date)
    except (TypeError, ValueError) as exc:
        raise ValueError("TARGET_DATE_INVALID") from exc
    root_path = _safe_root(root)
    commits = root_path / city / target_date / "commits"
    if not commits.is_dir():
        raise ValueError("COMMIT_PARTITION_MISSING")
    paths = sorted(commits.glob("*.json"))
    if not paths:
        raise ValueError("COMMIT_PARTITION_EMPTY")
    facts, selected, natural, source_ids = [], [], set(), set()
    for sequence, path in enumerate(paths, start=1):
        fact, evidence = _verify_bundle(root_path, city, target_date, path, sequence)
        raw = path.read_text(encoding="utf-8")
        raw_fact = json.loads(raw)["raw_source_fact"]
        key = (raw_fact["source_binding_id"], raw_fact["source_publication_id"], raw_fact["source_revision_id"])
        if key in natural:
            raise ValueError("SOURCE_NATURAL_IDENTITY_DUPLICATE")
        if fact["identity"] in source_ids:
            raise ValueError("SOURCE_FACT_ID_DUPLICATE")
        natural.add(key)
        source_ids.add(fact["identity"])
        facts.append(fact)
        selected.append(evidence)
    read_completed_at = datetime.now(UTC)
    if decision_as_of is not None:
        if decision_as_of.tzinfo is None:
            raise ValueError("DECISION_ASOF_NAIVE")
        decision = decision_as_of.astimezone(UTC)
        if decision < read_completed_at:
            raise ValueError("READ_BOUNDARY_AFTER_DECISION_ASOF")
        if any(parse(fact[key]) > decision for fact in facts for key in ("effective", "observed", "committed")):
            raise ValueError("SOURCE_FACT_FUTURE_AT_DECISION_ASOF")
    return {
        "schema_version": "M1_BUNDLE_ADAPTER_RESULT_V1", "city": city, "station": CITIES[city],
        "target_date": target_date, "facts": facts, "selected_bundles": selected,
        "read_completed_at_utc": _utc_text(read_completed_at),
        "decision_as_of_utc": _utc_text(decision_as_of.astimezone(UTC)) if decision_as_of is not None else None,
    }
