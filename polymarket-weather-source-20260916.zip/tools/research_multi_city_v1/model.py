"""Research-only, city-local empirical-residual validation for Beijing and Guangzhou."""

from __future__ import annotations

from datetime import date, datetime, time, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Sequence
from zoneinfo import ZoneInfo

from strategy_engine.data.records import decimal_text
from tools.research_weather_validation_v1.metrics import brier_score, mean
from tools.research_weather_validation_v1.runner import (
    _summary,
    bucket_index,
    research_probability_from_samples,
    research_weather_buckets,
)


CITY_STATIONS = {"Beijing": "ZBAA", "Guangzhou": "ZGGG"}
SOURCE = "aviationweather_taf"
ANCHOR_SECOND = 8 * 3600
ZERO = Decimal("0")
MARKET_FIELDS = frozenset({"market_id", "yes_token_id", "token_id", "yes_price", "orderbook", "book", "fee", "fees", "cost", "edge", "delta", "decision"})


def _utc(value: object, field: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError(f"{field} is required")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError(f"{field} must include timezone")
    return parsed


def _decimal(value: object, field: str) -> Decimal:
    if isinstance(value, bool) or value is None:
        raise ValueError(f"{field} is required")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{field} must be decimal") from exc
    if not result.is_finite() or result * 1000 != (result * 1000).to_integral_value():
        raise ValueError(f"{field} must be finite with milli-Celsius precision")
    return result


def _finite_decimal(value: object, field: str) -> Decimal:
    if isinstance(value, bool) or value is None:
        raise ValueError(f"{field} is required")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{field} must be decimal") from exc
    if not result.is_finite():
        raise ValueError(f"{field} must be finite")
    return result


def _target_date(row: dict[str, object]) -> date:
    value = row.get("target_date")
    if not isinstance(value, str):
        raise ValueError("target_date is required")
    return date.fromisoformat(value)


def _assert_city_station(city: str, station: str) -> None:
    if CITY_STATIONS.get(city) != station:
        raise ValueError("city/station mapping is not an authorized research binding")


def _assert_row_identity(row: dict[str, object], city: str, station: str) -> None:
    if row.get("city") != city or row.get("station") != station:
        raise ValueError("cross-city or cross-station row is forbidden")


def _assert_no_market_fields(row: dict[str, object]) -> None:
    present = sorted(MARKET_FIELDS.intersection(row))
    if present:
        raise ValueError(f"market input is forbidden: {present[0]}")


def _d_plus_2_freeze(target: date) -> datetime:
    return datetime.combine(target + timedelta(days=2), time.min, tzinfo=ZoneInfo("Asia/Shanghai"))


def _validate_anchor(target: date, decision_asof: datetime) -> None:
    local = decision_asof.astimezone(ZoneInfo("Asia/Shanghai"))
    if local.date() != target or local.time() != time(8, 0):
        raise ValueError("decision_as_of_utc must be target-date 08:00 Asia/Shanghai")


def _training_values(row: dict[str, object], city: str, station: str, target: date, anchor: datetime) -> tuple[date, Decimal, Decimal, datetime]:
    _assert_row_identity(row, city, station)
    _assert_no_market_fields(row)
    if row.get("status") != "AVAILABLE":
        raise ValueError("training row must be AVAILABLE")
    training_target = _target_date(row)
    label_available = _utc(row.get("label_available_at_utc"), "label_available_at_utc")
    if training_target >= target:
        raise ValueError("training target must precede prediction target")
    if _d_plus_2_freeze(training_target) > anchor or label_available > anchor:
        raise ValueError("training label is not mature at prediction AS-OF")
    return (
        training_target,
        _decimal(row.get("forecast_high_c"), "forecast_high_c"),
        _decimal(row.get("label_final_max_c"), "label_final_max_c"),
        label_available,
    )


def _raw_counts(samples: Sequence[Decimal]) -> list[int]:
    buckets = research_weather_buckets()
    counts = [0] * len(buckets)
    for sample in samples:
        counts[bucket_index(sample, buckets)] += 1
    return counts


def _prediction_row(city: str, station: str, target_row: dict[str, object], training_rows: Sequence[dict[str, object]]) -> dict[str, object]:
    _assert_city_station(city, station)
    _assert_row_identity(target_row, city, station)
    _assert_no_market_fields(target_row)
    target = _target_date(target_row)
    decision_asof = _utc(target_row.get("decision_as_of_utc"), "decision_as_of_utc")
    _validate_anchor(target, decision_asof)
    if target_row.get("status") != "AVAILABLE":
        raise ValueError("target row must be AVAILABLE")
    forecast = _decimal(target_row.get("forecast_high_c"), "forecast_high_c")
    observed = _decimal(target_row.get("current_observed_max_c"), "current_observed_max_c")
    parsed_training = [_training_values(row, city, station, target, decision_asof) for row in training_rows]
    if not parsed_training:
        raise ValueError("at least one city-local training row is required")
    if len({training_target for training_target, _, _, _ in parsed_training}) != len(parsed_training):
        raise ValueError("training target dates must be unique")

    ordered = sorted(parsed_training, key=lambda item: item[0])
    residuals = tuple(label - training_forecast for _, training_forecast, label, _ in ordered)
    model_samples = tuple(max(observed, forecast + residual) for residual in residuals)
    baseline_samples = tuple(label for _, _, label, _ in ordered)
    buckets = research_weather_buckets()
    model_probabilities, model_quantization = research_probability_from_samples(model_samples, buckets)
    baseline_probabilities, baseline_quantization = research_probability_from_samples(baseline_samples, buckets)
    return {
        "city": city,
        "station": station,
        "source": SOURCE,
        "target_date": target.isoformat(),
        "source_status": target_row.get("status"),
        "status": "PREDICTION_SAVED_AWAITING_LABEL",
        "reason": None,
        "decision_as_of_utc": target_row["decision_as_of_utc"],
        "training_dates": [item[0].isoformat() for item in ordered],
        "training_count": len(ordered),
        "research_semantics": "RESEARCH_ONLY_NOT_IIC2",
        "model_formula": "PER_CITY_EMPIRICAL_RESIDUAL_V1",
        "candidate_calculation": "max(O_t,F_t+(Y_d-F_d))",
        "baseline_calculation": "same-prior-mature-Y_d",
        "bucket_ids": [bucket.bucket_id for bucket in buckets],
        "candidate_raw_counts": _raw_counts(model_samples),
        "candidate_raw_count_total": len(model_samples),
        "candidate_quantization": model_quantization,
        "model_probabilities": [decimal_text(value) for value in model_probabilities],
        "model_temperature_mean_c": decimal_text(mean(model_samples)),
        "baseline_raw_counts": _raw_counts(baseline_samples),
        "baseline_raw_count_total": len(baseline_samples),
        "baseline_quantization": baseline_quantization,
        "baseline_probabilities": [decimal_text(value) for value in baseline_probabilities],
        "baseline_temperature_mean_c": decimal_text(mean(baseline_samples)),
    }


def predict(city: str, station: str, target_row: dict[str, object], training_rows: Sequence[dict[str, object]]) -> dict[str, object]:
    """Create one immutable research-only prediction from city-local mature rows."""
    return _prediction_row(city, station, target_row, training_rows)


def _eligible_training(rows: Iterable[dict[str, object]], city: str, station: str, target: date, anchor: datetime) -> tuple[dict[str, object], ...]:
    eligible: list[dict[str, object]] = []
    for row in rows:
        _assert_row_identity(row, city, station)
        if row.get("status") != "AVAILABLE":
            continue
        previous = _target_date(row)
        if previous >= target:
            continue
        label_available = _utc(row.get("label_available_at_utc"), "label_available_at_utc")
        if _d_plus_2_freeze(previous) <= anchor and label_available <= anchor:
            eligible.append(row)
    return tuple(sorted(eligible, key=_target_date))


def _append_score(saved: dict[str, object], label_row: dict[str, object], *, mode: str, require_created_before_label: bool) -> dict[str, object]:
    output = dict(saved)
    try:
        city = saved.get("city")
        station = saved.get("station")
        if not isinstance(city, str) or not isinstance(station, str):
            raise ValueError("saved prediction city/station is required")
        _assert_city_station(city, station)
        if saved.get("status") != "PREDICTION_SAVED_AWAITING_LABEL":
            raise ValueError("saved prediction is not awaiting a label")
        _assert_row_identity(label_row, city, station)
        _assert_no_market_fields(label_row)
        target = _target_date(label_row)
        if saved.get("target_date") != target.isoformat():
            raise ValueError("label target date does not match saved prediction")
        label_available = _utc(label_row.get("label_available_at_utc"), "label_available_at_utc")
        if label_available < _d_plus_2_freeze(target):
            raise ValueError("label is not mature under D+2")
        if require_created_before_label:
            created = _utc(saved.get("prediction_created_at_utc"), "prediction_created_at_utc")
            if created >= label_available:
                raise ValueError("prediction was not created before label availability")
        bucket_ids = saved.get("bucket_ids")
        model_values = saved.get("model_probabilities")
        baseline_values = saved.get("baseline_probabilities")
        if not isinstance(bucket_ids, list) or not isinstance(model_values, list) or not isinstance(baseline_values, list) or len(bucket_ids) != 52:
            raise ValueError("saved probability vector is incomplete")
        model = tuple(Decimal(str(value)) for value in model_values)
        baseline = tuple(Decimal(str(value)) for value in baseline_values)
        label = _decimal(label_row.get("label_final_max_c"), "label_final_max_c")
        target_index = bucket_index(label, research_weather_buckets())
        model_mean = _finite_decimal(saved.get("model_temperature_mean_c"), "model_temperature_mean_c")
        baseline_mean = _finite_decimal(saved.get("baseline_temperature_mean_c"), "baseline_temperature_mean_c")
        output.update(
            {
                "evaluation_status": "SCORED",
                "evaluation_mode": mode,
                "actual_label_final_max_c": decimal_text(label),
                "candidate_loss_brier": decimal_text(brier_score(model, target_index)),
                "baseline_loss_brier": decimal_text(brier_score(baseline, target_index)),
                "candidate_absolute_error": decimal_text(abs(model_mean - label)),
                "baseline_absolute_error": decimal_text(abs(baseline_mean - label)),
            }
        )
    except (InvalidOperation, KeyError, TypeError, ValueError) as exc:
        output.update({"evaluation_status": "INPUT_OR_COMPUTATION_FAILURE", "evaluation_mode": mode, "evaluation_error": str(exc)})
    return output


def score_prediction(saved: dict[str, object], label_row: dict[str, object]) -> dict[str, object]:
    """Forward-only scoring: append fields after proving prediction preceded label availability."""
    return _append_score(saved, label_row, mode="FORWARD_BLIND", require_created_before_label=True)


def _score_retrospective_prediction(saved: dict[str, object], label_row: dict[str, object]) -> dict[str, object]:
    """Historical evaluation only; it never represents a blind forward prediction."""
    return _append_score(saved, label_row, mode="EXPLORATORY_RETROSPECTIVE", require_created_before_label=False)


def _failed_row(
    row: dict[str, object],
    city: str,
    station: str,
    reason: str,
    *,
    training_dates: Sequence[str] | None = None,
    saved_prediction: dict[str, object] | None = None,
) -> dict[str, object]:
    if saved_prediction is not None:
        output = dict(saved_prediction)
        output.update({"evaluation_status": "INPUT_OR_COMPUTATION_FAILURE", "evaluation_error": reason})
        return output
    return {
        "city": city,
        "station": station,
        "source": SOURCE,
        "target_date": row.get("target_date"),
        "source_status": row.get("status"),
        "status": "INPUT_OR_COMPUTATION_FAILURE",
        "reason": reason,
        "decision_as_of_utc": row.get("decision_as_of_utc"),
        "training_dates": None if training_dates is None else list(training_dates),
        "training_count": None if training_dates is None else len(training_dates),
        "research_semantics": "RESEARCH_ONLY_NOT_IIC2",
        "evaluation_status": "INPUT_OR_COMPUTATION_FAILURE",
        "evaluation_error": reason,
    }


def _validate_available_scoring_identity_and_label(row: dict[str, object], city: str, station: str) -> None:
    """Validate the fields needed to determine an eligible training population."""
    _assert_row_identity(row, city, station)
    _assert_no_market_fields(row)
    target = _target_date(row)
    anchor = _utc(row.get("decision_as_of_utc"), "decision_as_of_utc")
    _validate_anchor(target, anchor)
    _decimal(row.get("label_final_max_c"), "label_final_max_c")
    if _utc(row.get("label_available_at_utc"), "label_available_at_utc") < _d_plus_2_freeze(target):
        raise ValueError("label is not mature under D+2")


def _validate_prediction_inputs(row: dict[str, object]) -> None:
    _decimal(row.get("forecast_high_c"), "forecast_high_c")
    _decimal(row.get("current_observed_max_c"), "current_observed_max_c")


def evaluate_population(payload: dict[str, object]) -> dict[str, object]:
    """Evaluate a single Beijing or Guangzhou population without cross-city pooling."""
    city = payload.get("city")
    station = payload.get("station")
    if not isinstance(city, str) or not isinstance(station, str):
        raise ValueError("payload city and station are required")
    _assert_city_station(city, station)
    if payload.get("source") != SOURCE:
        raise ValueError("payload source must be aviationweather_taf")
    raw_rows = payload.get("candidate_days")
    if not isinstance(raw_rows, list) or any(not isinstance(row, dict) for row in raw_rows):
        raise ValueError("candidate_days must be an object list")
    rows = tuple(raw_rows)
    dates = [_target_date(row) for row in rows]
    if len(set(dates)) != len(dates):
        raise ValueError("population requires one unique target_date per city")
    for row in rows:
        _assert_row_identity(row, city, station)

    output_rows: list[dict[str, object]] = []
    scored: list[tuple[str, Decimal, Decimal, Decimal, Decimal]] = []
    failure_dates: set[str] = set()
    for row in sorted(rows, key=_target_date):
        if row.get("status") != "AVAILABLE":
            output_rows.append(
                {
                    "city": city, "station": station, "source": SOURCE, "target_date": row.get("target_date"),
                    "source_status": row.get("status"), "status": row.get("status") or "UNPROVABLE", "reason": row.get("reason"),
                    "decision_as_of_utc": row.get("decision_as_of_utc"), "training_dates": [], "training_count": 0,
                    "research_semantics": "RESEARCH_ONLY_NOT_IIC2",
                }
            )
            continue
        target_text = row.get("target_date")
        training_dates: tuple[str, ...] | None = None
        saved: dict[str, object] | None = None
        try:
            _validate_available_scoring_identity_and_label(row, city, station)
            target = _target_date(row)
            anchor = _utc(row.get("decision_as_of_utc"), "decision_as_of_utc")
            training = _eligible_training(rows, city, station, target, anchor)
            training_dates = tuple(_target_date(item).isoformat() for item in training)
            _validate_prediction_inputs(row)
            if not training:
                output_rows.append(
                    {
                        "city": city, "station": station, "source": SOURCE, "target_date": target.isoformat(),
                        "source_status": "AVAILABLE", "status": "INSUFFICIENT_PRIOR_TRAINING_DATA", "reason": None,
                        "decision_as_of_utc": row.get("decision_as_of_utc"), "training_dates": [], "training_count": 0,
                        "research_semantics": "RESEARCH_ONLY_NOT_IIC2",
                    }
                )
                continue
            saved = predict(city, station, row, training)
            scored_row = _score_retrospective_prediction(saved, row)
            if scored_row.get("evaluation_status") != "SCORED":
                output_rows.append(scored_row)
                failure_dates.add(target.isoformat())
                continue
            score_values = (
                target.isoformat(),
                Decimal(str(scored_row["candidate_loss_brier"])),
                Decimal(str(scored_row["baseline_loss_brier"])),
                Decimal(str(scored_row["candidate_absolute_error"])),
                Decimal(str(scored_row["baseline_absolute_error"])),
            )
            output_rows.append(scored_row)
            scored.append(score_values)
        except (InvalidOperation, KeyError, TypeError, ValueError) as exc:
            output_rows.append(_failed_row(row, city, station, str(exc), training_dates=training_dates, saved_prediction=saved))
            if isinstance(target_text, str):
                failure_dates.add(target_text)

    summary = _summary(len(rows), scored, bool(failure_dates), sorted(failure_dates))
    early = summary["early_signal"]
    summary["early_signal"] = {
        "POSITIVE_EARLY_SIGNAL": "POSITIVE",
        "NEGATIVE_EARLY_SIGNAL": "NEGATIVE",
    }.get(str(early), "INCONCLUSIVE")
    return {
        "research_semantics": "RESEARCH_ONLY_NOT_IIC2",
        "city": city,
        "station": station,
        "source": SOURCE,
        "rows": output_rows,
        "metrics": summary,
    }
