"""Offline dynamic skeleton with injected evaluator; no live source/Decision wiring."""
import argparse
import copy
import hashlib
import json
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from strategy_v8.canonical import canonical_encode, canonical_time_v1, hash_v1, validate_hash_v1
from .dynamic_event_router import CITIES, LOCAL, WEATHER_ACTIONS, aware, route

STRATEGY_ID = 'FORMAL_DYNAMIC_ASOF_STRATEGY_V1'
TIMES = ('effective', 'observed', 'received', 'available', 'committed')
RESEARCH = Path('D:/polymarket天气/data/strategy_analysis').resolve()

def normalized(value):
    if isinstance(value, datetime): return canonical_time_v1(aware(value))
    if isinstance(value, dict): return {k: normalized(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [normalized(v) for v in value]
    return value

def write_once(path, value):
    raw = canonical_encode(normalized(value))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f: f.write(raw)
    with path.with_suffix('.json.sha256').open('x', encoding='ascii') as f:
        f.write(hashlib.sha256(raw).hexdigest())

def verified(path):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != path.with_suffix('.json.sha256').read_text(encoding='ascii').strip():
        raise ValueError('SAVED_HASH_MISMATCH')
    return json.loads(raw)

def decision_window_id(city, target_date, candidate_freeze_identity):
    if city not in CITIES: raise ValueError('CITY_INVALID')
    date.fromisoformat(target_date); validate_hash_v1(candidate_freeze_identity)
    return hash_v1('PWM.DYNAMIC_WINDOW_ID.V1', {
        'strategy_id': STRATEGY_ID, 'city': city, 'target_date': target_date,
        'window_start_local': '07:00:00 Asia/Shanghai', 'window_end_local_exclusive': '16:00:00 Asia/Shanghai',
        'candidate_freeze_identity': candidate_freeze_identity})

def _distribution(raw, ticks):
    if not isinstance(raw, list) or not isinstance(ticks, list) or len(raw) != 52 or len(ticks) != 52:
        raise ValueError('52_BUCKETS_REQUIRED')
    values = [Decimal(str(x)) for x in raw]
    if any(not x.is_finite() or x < 0 or x > 1 for x in values) or abs(sum(values)-1) > Decimal('1e-24'):
        raise ValueError('RAW_PROBABILITY_INVALID')
    if any(type(x) is not int or x < 0 for x in ticks) or sum(ticks) != 10**12:
        raise ValueError('RESEARCH_TICKS_INVALID')

def _visible(fact, city, cutoff):
    if not isinstance(fact, dict) or fact.get('city') != city or not fact.get('identity'):
        raise ValueError('FACT_IDENTITY_INVALID')
    if {'price','book','fee','edge','settlement','best_ask','market_id','token_id'} & set(fact):
        raise ValueError('MARKET_INPUT_FORBIDDEN')
    validate_hash_v1(fact['hash'])
    for key in TIMES:
        value = fact.get(key)
        if value is None and key in ('received', 'available'): continue
        if aware(value) > cutoff: raise ValueError('SOURCE_TIME_ASOF_INVALID')

def _snapshot(event, asof, identity, seq, draft):
    target = asof.astimezone(LOCAL).date()
    second = asof.astimezone(LOCAL).strftime('%H:%M:%S')
    if draft['target_date'] != str(target) or draft['candidate_freeze_identity'] != identity:
        raise ValueError('SNAPSHOT_BINDING_INVALID')
    forecast, observations, training = draft['forecast'], draft['observations'], draft['training']
    _visible(forecast, event.city, asof)
    if not forecast.get('revision') or not observations or not training:
        raise ValueError('WEATHER_INPUT_INCOMPLETE')
    for fact in observations: _visible(fact, event.city, asof)
    if len({row['target_date'] for row in training}) != len(training):
        raise ValueError('DUPLICATE_TRAINING_DAY')
    for row in training:
        day = date.fromisoformat(row['target_date'])
        if day >= target or row['local_second'] != second:
            raise ValueError('CITY_LOCAL_TIME_TRAINING_REQUIRED')
        historical_asof = datetime.combine(day, asof.astimezone(LOCAL).time(), LOCAL)
        _visible(row, event.city, historical_asof)
        if datetime.combine(day + timedelta(days=2), time.min, LOCAL) > asof or aware(row['label_available_at']) > asof:
            raise ValueError('IMMATURE_TRAINING_LABEL')
    _distribution(draft['raw_candidate_probabilities'], draft['quantized_candidate_probabilities_e12'])
    baseline = draft['baseline_output']
    _distribution(baseline['raw_probabilities'], baseline['ticks'])
    for mean in (draft['candidate_mean'], baseline['mean']):
        if not Decimal(str(mean)).is_finite(): raise ValueError('FINITE_MEAN_REQUIRED')
    inputs = normalized({'forecast': forecast, 'observations': observations, 'training': training})
    prediction = {k: draft[k] for k in ('raw_candidate_probabilities', 'quantized_candidate_probabilities_e12', 'candidate_mean', 'baseline_output')}
    snapshot = {
        'schema_version': 'WEATHER_ASOF_SNAPSHOT_V1', 'strategy_id': STRATEGY_ID, 'city': event.city,
        'target_date': str(target), 'decision_window_id': decision_window_id(event.city, str(target), identity),
        'candidate_freeze_identity': identity, 'cause_type': event.cause_type, 'cause_object_id': event.cause_object_id,
        'transition_kind': event.transition_kind, 'runtime_event_id': draft['runtime_event_id'], 'runtime_event_seq': seq,
        'effective_at_utc': canonical_time_v1(event.effective_at_utc), 'evaluation_asof_utc': canonical_time_v1(asof),
        'local_second': second, 'forecast_identity': forecast['identity'], 'forecast_revision_identity': forecast['revision'],
        'observation_identities': [x['identity'] for x in observations], 'source_anchor_set_hash': hash_v1('PWM.DYNAMIC.INPUTS.V1', inputs),
        'training_cutoff_asof_utc': canonical_time_v1(asof), 'training_identities': [x['identity'] for x in training],
        **prediction, 'input_hash': hash_v1('PWM.DYNAMIC.INPUTS.V1', inputs),
        'prediction_hash': hash_v1('PWM.DYNAMIC.PREDICTION.V1', prediction), 'created_at_utc': canonical_time_v1(datetime.now(timezone.utc)),
        'execution_mode': draft.get('execution_mode', 'SYNTHETIC_INJECTED'),
        'training_dates': [x['target_date'] for x in training],
        'research_quantization_evidence': draft.get('research_quantization_evidence'),
        'event_sourcefact_binding': draft.get('event_sourcefact_binding'),
        'action': route(event, asof)}
    validate_hash_v1(snapshot['runtime_event_id'])
    snapshot['snapshot_hash'] = hash_v1('PWM.WEATHER_ASOF_SNAPSHOT.V1', snapshot)
    return snapshot, inputs


def verify_snapshot(path, day, city, identity):
    path = Path(path).resolve()
    if path.parent != (day/'snapshots').resolve():
        raise ValueError('SNAPSHOT_PATH_BINDING_INVALID')
    value = verified(path)
    required = {'schema_version','city','target_date','decision_window_id','candidate_freeze_identity',
                'evaluation_asof_utc','forecast_identity','forecast_revision_identity','observation_identities',
                'training_dates','training_identities','input_hash','prediction_hash','snapshot_hash',
                'raw_candidate_probabilities','quantized_candidate_probabilities_e12','candidate_mean','baseline_output'}
    if not isinstance(value, dict) or not required <= value.keys():
        raise ValueError('SNAPSHOT_REQUIRED_FIELDS_MISSING')
    if (value['schema_version'] != 'WEATHER_ASOF_SNAPSHOT_V1' or value['city'] != city or
        value['target_date'] != day.name or value['candidate_freeze_identity'] != identity or
        value['decision_window_id'] != decision_window_id(city,day.name,identity)):
        raise ValueError('SNAPSHOT_BINDING_INVALID')
    instant = datetime.fromisoformat(value['evaluation_asof_utc'].replace('Z','+00:00'))
    local = aware(instant).astimezone(LOCAL)
    if local.date().isoformat() != day.name or not time(7) <= local.time() < time(16):
        raise ValueError('SNAPSHOT_ASOF_INVALID')
    if hash_v1('PWM.WEATHER_ASOF_SNAPSHOT.V1',{k:v for k,v in value.items() if k != 'snapshot_hash'}) != value['snapshot_hash']:
        raise ValueError('SNAPSHOT_CONTENT_HASH_MISMATCH')
    prediction = {k:value[k] for k in ('raw_candidate_probabilities','quantized_candidate_probabilities_e12','candidate_mean','baseline_output')}
    if hash_v1('PWM.DYNAMIC.PREDICTION.V1',prediction) != value['prediction_hash']:
        raise ValueError('SNAPSHOT_PREDICTION_HASH_MISMATCH')
    inputs = verified(day/'inputs'/path.name)
    if hash_v1('PWM.DYNAMIC.INPUTS.V1',inputs) != value['input_hash']:
        raise ValueError('SNAPSHOT_INPUT_HASH_MISMATCH')
    if not value['forecast_identity'] or not value['forecast_revision_identity'] or not value['observation_identities'] or not value['training_dates'] or not value['training_identities']:
        raise ValueError('SNAPSHOT_REQUIRED_FIELDS_EMPTY')
    _distribution(value['raw_candidate_probabilities'],value['quantized_candidate_probabilities_e12'])
    _distribution(value['baseline_output']['raw_probabilities'],value['baseline_output']['ticks'])
    return value

class DynamicForward:
    """One caller per city/window. Claims fail closed after interrupted evaluation."""
    def __init__(self, root, candidate_bindings):
        self.root = Path(root).resolve()
        if RESEARCH not in self.root.parents or 'backups' in {x.lower() for x in self.root.parts}:
            raise ValueError('RESEARCH_OUTPUT_REQUIRED')
        self.bindings = dict(candidate_bindings)
        if set(self.bindings) != set(CITIES): raise ValueError('THREE_CITY_BINDINGS_REQUIRED')
        for identity in self.bindings.values(): validate_hash_v1(identity)

    def _state(self, day):
        state = {'latest': None, 'version_blocked': False, 'system_blocked': False, 'closed': False}
        records = sorted((day/'events').glob('*.json'))
        event_keys = set()
        for path in records:
            record = verified(path)
            event_keys.add(record['event_key'])
            action = record['action']
            if action == 'FAIL_CLOSED_VERSION_MISMATCH': state['version_blocked'] = True
            if action == 'FAIL_CLOSED': state['system_blocked'] = True
            if action == 'HEALTH_RECOVERED': state['system_blocked'] = False
            if action == 'WINDOW_CLOSE_NO_NEW_DECISION': state['closed'] = True
            if action in ('WEATHER_CANDIDATE_INVALIDATE', 'FAIL_CLOSED_VERSION_MISMATCH', 'FAIL_CLOSED', 'WINDOW_CLOSE_NO_NEW_DECISION') or record['status'] != 'OK':
                state['latest'] = None
            if record.get('snapshot_path') and record['status'] == 'OK':
                snapshot = verify_snapshot(record['snapshot_path'],day,day.parent.name,self.bindings[day.parent.name])
                if snapshot['snapshot_hash'] != record.get('snapshot_hash'):
                    raise ValueError('SNAPSHOT_EVENT_HASH_MISMATCH')
                state['latest'] = record['snapshot_path']
        claims = list((day/'claims').glob('*.json'))
        if len(event_keys) != len(records) or {p.stem for p in claims} != event_keys:
            raise ValueError('INCOMPLETE_PRIOR_ATTEMPT')
        for path in claims:
            claim = verified(path)
            if claim.get('state') == 'CLAIMED':
                processing = verified(day/'lifecycle'/f'{path.stem}_processing.json')
                if processing != {'event_key':path.stem,'state':'PROCESSING'}:
                    raise ValueError('CLAIM_PROCESSING_INVALID')
                terminal_path = day/'lifecycle'/f'{path.stem}_terminal.json'
                if not terminal_path.is_file(): raise ValueError('INCOMPLETE_PRIOR_ATTEMPT')
                terminal = verified(terminal_path)
                if terminal.get('state') not in ('COMPLETED','FAILED') or terminal.get('event_key') != path.stem:
                    raise ValueError('CLAIM_TERMINAL_INVALID')
                record_path = Path(terminal['event_path'])
                if record_path.parent.resolve() != (day/'events').resolve() or hashlib.sha256(record_path.read_bytes()).hexdigest() != terminal['event_file_sha256']:
                    raise ValueError('CLAIM_TERMINAL_EVENT_MISMATCH')
                expected_state = 'COMPLETED' if verified(record_path)['status']=='OK' else 'FAILED'
                if terminal['state'] != expected_state: raise ValueError('CLAIM_TERMINAL_STATUS_MISMATCH')
        # A crash between the global and day claim must not evade the day count.
        for path in (self.root/day.parent.name/'event_keys').glob('*.json'):
            claim = verified(path)
            claimed_day = claim.get('target_date')
            if claimed_day is None:
                claimed_day = datetime.fromisoformat(claim['as_of'].replace('Z','+00:00')).astimezone(LOCAL).date().isoformat()
            if claimed_day == day.name and path.stem not in event_keys:
                raise ValueError('INCOMPLETE_PRIOR_ATTEMPT')
        return state, len(records)

    def inject(self, event, asof, evaluator=None):
        action = route(event, asof)
        target = asof.astimezone(LOCAL).date().isoformat()
        day = self.root/event.city/target
        checkpoint = day/'BENCHMARK_CHECKPOINT_0800.json'
        if time(8) <= asof.astimezone(LOCAL).time() < time(16) and not checkpoint.exists():
            write_once(checkpoint, {'benchmark': 'FIXED_0800_RESEARCH_BENCHMARK_V1', 'observed_at': asof,
                'fixed_0800_prediction_generated': False, 'note': 'Checkpoint only; no missed-08:00 prediction reconstructed'})
        identity = self.bindings[event.city]
        try:
            state, count = self._state(day)
        except (ValueError, KeyError, TypeError, OSError) as exc:
            return {'status':'FAILURE','action':action,'event_created':False,'model_call':False,
                    'error_type':type(exc).__name__,'error_reason':str(exc),'failure_class':'STATE_INTEGRITY_FAILURE'}
        if action is None: return {'event_created': False, 'model_call': False, 'health_only': True}
        window = decision_window_id(event.city, target, identity)
        binding_file = day/'window.json'
        binding = {'decision_window_id': window, 'candidate_freeze_identity': identity}
        if binding_file.exists():
            if verified(binding_file) != binding: raise ValueError('FAIL_CLOSED_VERSION_MISMATCH')
        else: write_once(binding_file, binding)
        key = hash_v1('PWM.DYNAMIC.EVENT.KEY.V1', event.key())
        claim = day/'claims'/f'{key}.json'
        global_claim = self.root/event.city/'event_keys'/f'{key}.json'
        if global_claim.exists():
            prior = verified(global_claim)
            prior_target = prior.get('target_date') or datetime.fromisoformat(prior['as_of'].replace('Z','+00:00')).astimezone(LOCAL).date().isoformat()
            prior_day = self.root/event.city/prior_target
            try:
                self._state(prior_day)
                matches = list((prior_day/'events').glob(f'*_{key}.json'))
                if len(matches) != 1: raise ValueError('INCOMPLETE_PRIOR_ATTEMPT')
                previous = verified(matches[0])
                if previous.get('event_key') != key: raise ValueError('CLAIM_EVENT_BINDING_INVALID')
            except (ValueError, KeyError, TypeError, OSError) as exc:
                return {'status':'FAILURE','action':action,'event_created':False,'model_call':False,
                        'error_type':type(exc).__name__,'error_reason':str(exc),'failure_class':'STATE_INTEGRITY_FAILURE'}
            return {'event_created': False, 'model_call': False, 'duplicate': True,
                    'claim_status':'ALREADY_COMPLETED' if previous['status']=='OK' else 'ALREADY_FAILED'}
        if state['version_blocked']: action = 'FAIL_CLOSED_VERSION_MISMATCH'
        elif state['closed']: action = 'WINDOW_CLOSE_NO_NEW_DECISION'
        elif state['system_blocked'] and action in WEATHER_ACTIONS | {'MARKET_ONLY_REEVALUATION_REQUEST'}: action = 'FAIL_CLOSED'
        record = {'action': action, 'event_key': key, 'decision_window_id': window, 'event_created': True,
                  'model_call': False, 'status': 'OK', 'created_at': canonical_time_v1(asof)}
        claim_record = {'key': event.key(), 'effective_at': event.effective_at_utc, 'as_of': asof,
                        'target_date':target,'state':'CLAIMED'}
        write_once(global_claim, claim_record)
        write_once(claim, claim_record)
        write_once(day/'lifecycle'/f'{key}_processing.json',{'event_key':key,'state':'PROCESSING'})
        try:
            if action in WEATHER_ACTIONS:
                if evaluator is None: raise ValueError('OFFLINE_EVALUATOR_REQUIRED')
                # The actual saved-source evaluator validates before any model call.
                # Plain callbacks remain synthetic skeleton fixtures, never real evidence.
                if hasattr(evaluator, 'validate_event'): evaluator.validate_event(event,asof)
                record['model_call'] = True
                snapshot, inputs = _snapshot(event, asof, identity, count+1, dict(evaluator(event, asof)))
                file = day/'snapshots'/f'{key}.json'
                write_once(day/'inputs'/f'{key}.json', inputs)
                write_once(file, snapshot)
                record['snapshot_path'] = str(file)
                record['snapshot_hash'] = snapshot['snapshot_hash']
            elif action == 'MARKET_ONLY_REEVALUATION_REQUEST':
                latest = verified(Path(state['latest'])) if state['latest'] else None
                record['weather_snapshot_hash'] = latest['snapshot_hash'] if latest else None
                record['request_executable'] = False
        except Exception as exc:
            record.update(status='FAILURE', error_type=type(exc).__name__, error_reason=str(exc))
        event_path = day/'events'/f'{count+1:08d}_{key}.json'
        write_once(event_path, record)
        write_once(day/'lifecycle'/f'{key}_terminal.json',{'event_key':key,
                   'state':'COMPLETED' if record['status']=='OK' else 'FAILED',
                   'event_path':str(event_path),'event_file_sha256':hashlib.sha256(event_path.read_bytes()).hexdigest()})
        return copy.deepcopy(record)

def main():
    parser = argparse.ArgumentParser(description='Offline dynamic skeleton readiness check, not a capture command')
    parser.add_argument('--candidate-references', required=True, type=Path)
    parser.add_argument('--check-only', required=True, action='store_true')
    args = parser.parse_args()
    value = json.loads(args.candidate_references.read_text(encoding='utf-8'))
    if set(value['candidates']) != set(CITIES): raise ValueError('THREE_CITY_BINDINGS_REQUIRED')
    for city, item in value['candidates'].items():
        if item['city'] != city or item['station'] != CITIES[city]: raise ValueError('CITY_BINDING_INVALID')
        validate_hash_v1(item['candidate_freeze_identity'])
        if hash_v1('PWM.DYNAMIC_CANDIDATE_REFERENCE.V1', item['identity_payload']) != item['candidate_freeze_identity']:
            raise ValueError('REFERENCE_IDENTITY_INVALID')
    print(json.dumps({'mode':'CHECK_ONLY','cities':list(CITIES),'live_source_wiring':False,'real_capture_executed':False}))

if __name__ == '__main__': main()
