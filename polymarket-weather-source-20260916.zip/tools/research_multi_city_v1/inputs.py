"""City-bound, read-only TAF/METAR forward snapshots; no live source collector."""
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sqlite3
from zoneinfo import ZoneInfo

from strategy_engine.data.records import City, OBSERVATION_STATION, SOURCE_BINDING

UTC = timezone.utc
LOCAL = ZoneInfo("Asia/Shanghai")


def identity(city, station):
    member = City[city.upper()]
    if city not in ("Beijing", "Guangzhou") or OBSERVATION_STATION[member] != station or SOURCE_BINDING[member] != "aviationweather_taf/" + station:
        raise ValueError("CITY_STATION_MAPPING_CONFLICT")


def parsed(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("TIMEZONE_REQUIRED")
    return result.astimezone(UTC)


def window(target):
    start = datetime.combine(target, time.min, LOCAL).astimezone(UTC)
    return start, start + timedelta(hours=8), start + timedelta(days=1), start + timedelta(days=2)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def read_rows(path, sql, parameters):
    path = Path(path).resolve()
    if "backups" in {p.lower() for p in path.parts} or not path.is_file():
        raise ValueError("SOURCE_PATH_NOT_ALLOWED_OR_MISSING")
    connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA query_only=ON")
        return [dict(r) for r in connection.execute(sql, parameters)]
    finally:
        connection.close()


def observation_rows(path, city, station, start, end, visible):
    identity(city, station)
    rows = read_rows(path, "SELECT observation_id,report_time,received_at,report_type,temperature_c,raw_observation,raw_hash,source FROM metar_observations WHERE city=? AND station=? AND temperature_c IS NOT NULL ORDER BY report_time,observation_id", (city, station))
    result = []
    for row in rows:
        report, received = parsed(row["report_time"]), parsed(row["received_at"])
        if not start <= report < end or received > visible:
            continue
        temperature = Decimal(str(row["temperature_c"]))
        if not temperature.is_finite() or not row["raw_hash"] or not row["raw_observation"] or row["report_type"] not in ("METAR", "SPECI"):
            raise ValueError("OBSERVATION_FACT_INVALID")
        row.update(city=city, station=station, temperature_c=str(temperature))
        row["source_fact_id"] = digest(row)
        result.append(row)
    return result


def snapshot(city, station, target, research_db, observation_db):
    identity(city, station)
    start, cutoff, _, _ = window(target)
    rows = read_rows(research_db, "SELECT source,city,station,target_date,grid_version,forecast_high_c,source_reported_at,first_captured_at,content_hash FROM forecast_d0_registry WHERE source='aviationweather_taf' AND city=? AND station=? AND target_date=? AND status='valid_d0'", (city, station, target.isoformat()))
    if not rows:
        raise ValueError("FORECAST_D0_MISSING")
    visible = [r for r in rows if r["source_reported_at"] and r["first_captured_at"] and parsed(r["source_reported_at"]) <= cutoff and parsed(r["first_captured_at"]) <= cutoff]
    if not visible:
        raise ValueError("FORECAST_ASOF_UNPROVABLE")
    if len({(r["grid_version"], r["content_hash"], str(r["forecast_high_c"])) for r in visible}) != 1:
        raise ValueError("FORECAST_D0_CONFLICT")
    forecast = min(visible, key=lambda r: parsed(r["first_captured_at"]))
    high = Decimal(str(forecast["forecast_high_c"]))
    if not high.is_finite() or not forecast["content_hash"]:
        raise ValueError("FORECAST_IDENTITY_INVALID")
    observations = observation_rows(observation_db, city, station, start, cutoff, cutoff)
    if not observations:
        raise ValueError("ANCHOR_OBSERVATION_MISSING")
    return {"city": city, "station": station, "source": "aviationweather_taf", "target_date": target.isoformat(),
            "status": "AVAILABLE", "decision_as_of_utc": cutoff.isoformat(), "forecast_high_c": str(high),
            "current_observed_max_c": str(max(Decimal(r["temperature_c"]) for r in observations)),
            "forecast_identity": forecast, "observations": observations,
            "source_hashes": {"forecast": digest(forecast), "observation_set": digest(observations)},
            "source_paths": [str(research_db), str(observation_db)]}


def label(city, station, target, observation_db, now):
    identity(city, station)
    start, _, end, maturity = window(target)
    if now < maturity:
        raise ValueError("LABEL_NOT_MATURE")
    observations = observation_rows(observation_db, city, station, start, end, maturity)
    times = sorted({parsed(r["report_time"]) for r in observations})
    if not times or times[0] > start + timedelta(minutes=30) or times[-1] < end - timedelta(minutes=30) or any(b-a > timedelta(seconds=5400) for a,b in zip(times, times[1:])):
        raise ValueError("LABEL_COVERAGE_INCOMPLETE")
    return {"city": city, "station": station, "source": "aviationweather_taf", "target_date": target.isoformat(),
            "label_available_at_utc": maturity.isoformat(), "label_final_max_c": str(max(Decimal(r["temperature_c"]) for r in observations)),
            "observations": observations, "source_hashes": {"label_observations": digest(observations)}}
