"""Pure execution-evidence calculations for paper research.

This module deliberately has no network, database, dashboard, or order side
effects.  It converts already captured order-book evidence into deterministic
calculations and fails closed when the evidence cannot support a conclusion.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP
from enum import Enum
from types import MappingProxyType
from typing import Iterable, Mapping, Sequence


class EvidenceError(ValueError):
    """Raised when a calculation request or evidence value is invalid."""


def _decimal(value: Decimal | int | str) -> Decimal:
    try:
        result = value if isinstance(value, Decimal) else Decimal(value)
    except Exception as exc:
        raise EvidenceError(f"invalid decimal value: {value!r}") from exc
    if not result.is_finite():
        raise EvidenceError(f"non-finite decimal value: {value!r}")
    return result


def _positive(value: Decimal | int | str, name: str) -> Decimal:
    result = _decimal(value)
    if result <= 0:
        raise EvidenceError(f"{name} must be positive")
    return result


def _price(value: Decimal | int | str, name: str = "price") -> Decimal:
    result = _decimal(value)
    if result < 0 or result > 1:
        raise EvidenceError(f"{name} must be between 0 and 1")
    return result


@dataclass(frozen=True)
class ExecutionFill:
    quantity: Decimal
    vwap: Decimal
    worst_price: Decimal
    notional: Decimal
    levels_used: int


@dataclass(frozen=True)
class ExecutionCurve:
    quantities: tuple[Decimal, ...]
    buy: Mapping[Decimal, ExecutionFill | None]
    sell: Mapping[Decimal, ExecutionFill | None]


def executable_vwap(
    levels: Iterable[tuple[Decimal | int | str, Decimal | int | str]],
    *,
    side: str,
    quantity: Decimal | int | str,
) -> ExecutionFill | None:
    """Return a full-fill VWAP or ``None`` when visible depth is insufficient.

    ``side="buy"`` consumes asks from low to high. ``side="sell"`` consumes
    bids from high to low. Duplicate prices are aggregated before consumption.
    Partial fills are never returned as if they were executable full fills.
    """

    normalized_side = side.strip().lower()
    if normalized_side not in {"buy", "sell"}:
        raise EvidenceError("side must be 'buy' or 'sell'")
    requested = _positive(quantity, "quantity")

    aggregated: dict[Decimal, Decimal] = {}
    for raw_price, raw_size in levels:
        price = _price(raw_price)
        size = _decimal(raw_size)
        if size < 0:
            raise EvidenceError("level size cannot be negative")
        if size == 0:
            continue
        aggregated[price] = aggregated.get(price, Decimal("0")) + size

    ordered = sorted(
        aggregated.items(),
        key=lambda item: item[0],
        reverse=normalized_side == "sell",
    )

    remaining = requested
    notional = Decimal("0")
    worst_price: Decimal | None = None
    levels_used = 0
    for price, available in ordered:
        if remaining <= 0:
            break
        taken = min(available, remaining)
        if taken <= 0:
            continue
        notional += price * taken
        remaining -= taken
        worst_price = price
        levels_used += 1

    if remaining > 0 or worst_price is None:
        return None

    return ExecutionFill(
        quantity=requested,
        vwap=notional / requested,
        worst_price=worst_price,
        notional=notional,
        levels_used=levels_used,
    )


def execution_curve(
    *,
    bids: Iterable[tuple[Decimal | int | str, Decimal | int | str]],
    asks: Iterable[tuple[Decimal | int | str, Decimal | int | str]],
    quantities: Sequence[Decimal | int | str] = (5, 10, 15, 20, 25),
) -> ExecutionCurve:
    """Calculate executable buy and sell VWAPs for each requested size.

    Each side is normalized and sorted once.  This matters for the shadow
    observer, which may receive large full books and must not repeat the same
    aggregation work once per requested quantity.
    """

    normalized_quantities = tuple(_positive(value, "quantity") for value in quantities)
    if not normalized_quantities:
        raise EvidenceError("at least one quantity is required")
    if len(set(normalized_quantities)) != len(normalized_quantities):
        raise EvidenceError("quantities must be unique")

    def side_curve(
        levels: Iterable[tuple[Decimal | int | str, Decimal | int | str]],
        *,
        side: str,
    ) -> dict[Decimal, ExecutionFill | None]:
        aggregated: dict[Decimal, Decimal] = {}
        for raw_price, raw_size in levels:
            price = _price(raw_price)
            size = _decimal(raw_size)
            if size < 0:
                raise EvidenceError("level size cannot be negative")
            if size == 0:
                continue
            aggregated[price] = aggregated.get(price, Decimal("0")) + size
        ordered = sorted(
            aggregated.items(),
            key=lambda item: item[0],
            reverse=side == "sell",
        )
        sorted_targets = sorted(normalized_quantities)
        fills: dict[Decimal, ExecutionFill | None] = {
            quantity: None for quantity in normalized_quantities
        }
        cumulative_quantity = Decimal("0")
        cumulative_notional = Decimal("0")
        target_index = 0
        levels_used = 0
        for price, available in ordered:
            quantity_before = cumulative_quantity
            notional_before = cumulative_notional
            cumulative_quantity += available
            cumulative_notional += price * available
            levels_used += 1
            while (
                target_index < len(sorted_targets)
                and sorted_targets[target_index] <= cumulative_quantity
            ):
                target = sorted_targets[target_index]
                target_notional = (
                    notional_before + price * (target - quantity_before)
                )
                fills[target] = ExecutionFill(
                    quantity=target,
                    vwap=target_notional / target,
                    worst_price=price,
                    notional=target_notional,
                    levels_used=levels_used,
                )
                target_index += 1
            if target_index == len(sorted_targets):
                break
        return fills

    buy = side_curve(asks, side="buy")
    sell = side_curve(bids, side="sell")
    return ExecutionCurve(
        quantities=normalized_quantities,
        buy=MappingProxyType(buy),
        sell=MappingProxyType(sell),
    )


@dataclass(frozen=True)
class TargetPlan:
    raw_target: Decimal
    rounded_target: Decimal
    entry_allowed: bool


def round_up_to_tick(
    value: Decimal | int | str,
    tick: Decimal | int | str,
) -> Decimal:
    amount = _decimal(value)
    tick_size = _positive(tick, "tick")
    return (amount / tick_size).to_integral_value(rounding=ROUND_CEILING) * tick_size


def target_for_entry(
    entry_vwap: Decimal | int | str,
    tick: Decimal | int | str,
) -> TargetPlan:
    """Calculate the confirmed price-door target for an executable entry VWAP."""

    entry = _price(entry_vwap, "entry_vwap")
    raw_target = entry + max(Decimal("0.03"), entry * Decimal("0.20"))
    rounded_target = round_up_to_tick(raw_target, tick)
    return TargetPlan(
        raw_target=raw_target,
        rounded_target=rounded_target,
        entry_allowed=rounded_target <= Decimal("0.90"),
    )


def stop_for_entry(entry_vwap: Decimal | int | str) -> Decimal:
    """Return the confirmed 50% cost-price stop threshold."""

    return _price(entry_vwap, "entry_vwap") * Decimal("0.50")


class LiquidityRole(str, Enum):
    MAKER = "maker"
    TAKER = "taker"


@dataclass(frozen=True)
class FeeSchedule:
    """Versioned fee parameters supplied by the caller.

    No market-specific rate is hardcoded here.  A captured schedule version is
    mandatory so later replay can identify exactly which fee evidence was used.
    """

    version_id: str
    platform_rate: Decimal
    platform_taker_only: bool = True
    maker_builder_bps: int = 0
    taker_builder_bps: int = 0
    rounding_quantum: Decimal = Decimal("0.00001")

    def __post_init__(self) -> None:
        if not self.version_id.strip():
            raise EvidenceError("fee schedule version_id is required")
        rate = _decimal(self.platform_rate)
        if rate < 0 or rate > 1:
            raise EvidenceError("platform_rate must be between 0 and 1")
        if not isinstance(self.maker_builder_bps, int) or not 0 <= self.maker_builder_bps <= 10000:
            raise EvidenceError("maker_builder_bps must be an integer from 0 to 10000")
        if not isinstance(self.taker_builder_bps, int) or not 0 <= self.taker_builder_bps <= 10000:
            raise EvidenceError("taker_builder_bps must be an integer from 0 to 10000")
        quantum = _positive(self.rounding_quantum, "rounding_quantum")
        object.__setattr__(self, "platform_rate", rate)
        object.__setattr__(self, "rounding_quantum", quantum)


@dataclass(frozen=True)
class TradeFee:
    schedule_version: str
    platform_fee: Decimal
    builder_fee: Decimal
    total_fee: Decimal


def fee_for_trade(
    *,
    shares: Decimal | int | str,
    price: Decimal | int | str,
    role: LiquidityRole | str,
    schedule: FeeSchedule,
) -> TradeFee:
    """Calculate a trade fee from an explicit, versioned fee schedule."""

    quantity = _positive(shares, "shares")
    execution_price = _price(price)
    try:
        liquidity_role = role if isinstance(role, LiquidityRole) else LiquidityRole(role)
    except ValueError as exc:
        raise EvidenceError("role must be maker or taker") from exc

    platform_applies = (
        liquidity_role is LiquidityRole.TAKER or not schedule.platform_taker_only
    )
    platform_raw = (
        quantity
        * schedule.platform_rate
        * execution_price
        * (Decimal("1") - execution_price)
        if platform_applies
        else Decimal("0")
    )
    builder_bps = (
        schedule.taker_builder_bps
        if liquidity_role is LiquidityRole.TAKER
        else schedule.maker_builder_bps
    )
    builder_raw = (
        quantity
        * execution_price
        * Decimal(builder_bps)
        / Decimal("10000")
    )
    platform_fee = platform_raw.quantize(
        schedule.rounding_quantum,
        rounding=ROUND_HALF_UP,
    )
    builder_fee = builder_raw.quantize(
        schedule.rounding_quantum,
        rounding=ROUND_HALF_UP,
    )
    return TradeFee(
        schedule_version=schedule.version_id,
        platform_fee=platform_fee,
        builder_fee=builder_fee,
        total_fee=platform_fee + builder_fee,
    )


class PathOutcome(str, Enum):
    TARGET_FIRST = "target_first"
    STOP_FIRST = "stop_first"
    NO_HIT = "no_hit"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class ExecutablePathPoint:
    sequence: int
    received_at: datetime
    sell_vwap: Decimal | None
    coverage_ok: bool = True
    reason: str = ""


@dataclass(frozen=True)
class PathResult:
    outcome: PathOutcome
    first_target_sequence: int | None = None
    first_stop_sequence: int | None = None
    reason: str = ""


def classify_exit_path(
    points: Sequence[ExecutablePathPoint],
    *,
    target: Decimal | int | str,
    stop: Decimal | int | str,
) -> PathResult:
    """Classify an ordered executable exit path without inventing evidence."""

    target_price = _price(target, "target")
    stop_price = _price(stop, "stop")
    if target_price <= stop_price:
        raise EvidenceError("target must be above stop")
    if not points:
        return PathResult(PathOutcome.UNKNOWN, reason="empty_path")

    previous_sequence: int | None = None
    grouped: list[list[ExecutablePathPoint]] = []
    for point in points:
        if not isinstance(point.sequence, int) or point.sequence < 0:
            return PathResult(PathOutcome.UNKNOWN, reason="invalid_sequence")
        if previous_sequence is not None and point.sequence < previous_sequence:
            return PathResult(PathOutcome.UNKNOWN, reason="non_monotonic_sequence")
        if previous_sequence != point.sequence:
            grouped.append([])
        grouped[-1].append(point)
        previous_sequence = point.sequence

    for group in grouped:
        sequence = group[0].sequence
        if any(not point.coverage_ok for point in group):
            return PathResult(
                PathOutcome.UNKNOWN,
                reason="coverage_gap_before_exit",
            )
        if any(point.sell_vwap is None for point in group):
            return PathResult(
                PathOutcome.UNKNOWN,
                reason="missing_executable_depth",
            )

        prices = [_price(point.sell_vwap, "sell_vwap") for point in group]
        target_hit = any(price >= target_price for price in prices)
        stop_hit = any(price <= stop_price for price in prices)
        if target_hit and stop_hit:
            return PathResult(
                PathOutcome.UNKNOWN,
                first_target_sequence=sequence,
                first_stop_sequence=sequence,
                reason="same_sequence_ambiguous",
            )
        if target_hit:
            return PathResult(
                PathOutcome.TARGET_FIRST,
                first_target_sequence=sequence,
            )
        if stop_hit:
            return PathResult(
                PathOutcome.STOP_FIRST,
                first_stop_sequence=sequence,
            )

    return PathResult(PathOutcome.NO_HIT, reason="complete_path_no_hit")
