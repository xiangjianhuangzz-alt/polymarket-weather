import fs from "node:fs/promises";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const base = "D:/polymarket天气";
const inputDir = `${base}/outputs/forecast_fetches`;
const outputPath = `${inputDir}/气象在线预报拉取明细_2026-07-17至18.xlsx`;

function parseCsv(text) {
  return text.trim().split(/\r?\n/).map(line => line.split(",").map(value => value.replace(/^"|"$/g, "")));
}

const detailRows = parseCsv(await fs.readFile(`${inputDir}/拉取明细.csv`, "utf8"));
const summaryRows = parseCsv(await fs.readFile(`${inputDir}/预报变化汇总.csv`, "utf8"));
const workbook = Workbook.create();
const detail = workbook.worksheets.add("拉取明细");
const summary = workbook.worksheets.add("预报变化汇总");

for (const [sheet, rows, title] of [[detail, detailRows, "气象在线三天预报 · 拉取明细"], [summary, summaryRows, "气象在线三天预报 · 变化汇总"]]) {
  sheet.showGridLines = false;
  const endColumn = sheet === detail ? "Q" : "G";
  sheet.getRange(`A1:${endColumn}1`).merge();
  sheet.getRange("A1").values = [[title]];
  sheet.getRange("A1").format = {fill: "#1F4E78", font: {bold: true, color: "#FFFFFF", size: 16}, horizontalAlignment: "left"};
  sheet.getRange(`A3:${endColumn}${rows.length + 2}`).values = rows;
  sheet.getRange(`A3:${endColumn}3`).format = {fill: "#D9EAF7", font: {bold: true, color: "#17365D"}, wrapText: true};
  sheet.getRange(`A3:${endColumn}${rows.length + 2}`).format.borders = {preset: "insideHorizontal", style: "thin", color: "#D9E2F3"};
  sheet.getRange(`A3:${endColumn}${rows.length + 2}`).format.verticalAlignment = "center";
  sheet.getRange(`A3:${endColumn}${rows.length + 2}`).format.autofitColumns();
  sheet.getRange(`A3:${endColumn}${rows.length + 2}`).format.autofitRows();
  sheet.freezePanes.freezeRows(3);
}

detail.getRange("A:A").format.columnWidth = 22;
detail.getRange("B:B").format.columnWidth = 22;
detail.getRange("C:Q").format.columnWidth = 14;
summary.getRange("A:A").format.columnWidth = 25;
summary.getRange("B:C").format.columnWidth = 15;
summary.getRange("D:D").format.columnWidth = 16;
summary.getRange("E:F").format.columnWidth = 23;
summary.getRange("G:G").format.columnWidth = 12;
detail.getRange(`C4:Q${detailRows.length + 2}`).format.numberFormat = "0.0";
summary.getRange(`D4:D${summaryRows.length + 2}`).format.numberFormat = "0.0";

const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(outputPath);
const preview = await workbook.render({sheetName: "拉取明细", range: "A1:Q14", scale: 1.5, format: "png"});
await fs.writeFile(`${inputDir}/preview.png`, new Uint8Array(await preview.arrayBuffer()));
console.log(outputPath);
