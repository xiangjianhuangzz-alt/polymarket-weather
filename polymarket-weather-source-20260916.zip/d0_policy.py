"""Shared, read-only D0 settlement policy.

Polymarket's winning bucket is the settlement truth.  Exact buckets and the
two outer range buckets are all deterministic market categories, while their
raw labels and category kinds remain distinct for audit purposes.
"""
from __future__ import annotations

import re
import sqlite3
from typing import Any


SETTLEMENT_BUCKET_PATTERN = re.compile(
    r"\s*(-?\d+(?:\.0+)?)°C(?:\s+or\s+(higher|below))?\s*",
    re.IGNORECASE,
)


def parse_settlement_bucket(label: str) -> dict[str, Any] | None:
    """Parse one deterministic Polymarket settlement category.

    The numeric bucket is the market-category boundary, not a claim about an
    unknown physical temperature inside an outer range.
    """
    text = str(label).strip()
    match = SETTLEMENT_BUCKET_PATTERN.fullmatch(text)
    if not match:
        return None
    suffix = str(match.group(2) or "").lower()
    kind = {
        "": "exact",
        "higher": "or_higher",
        "below": "or_below",
    }[suffix]
    return {
        "bucket": int(float(match.group(1))),
        "kind": kind,
        "label": text,
    }


def strict_qxzx_settled_window(
    db: sqlite3.Connection,
    city: str,
    *,
    limit: int = 7,
) -> list[dict[str, Any]]:
    """Return the latest strict QXZX D0/settlement-category pairs.

    Invalid or unparseable winners do not satisfy the sample gate.  TAF and
    other sources are excluded before the rolling window is built.
    """
    rows = db.execute(
        """SELECT d.target_date,d.forecast_bucket,r.bucket_label
          FROM forecast_d0_registry d
          JOIN market_resolutions r
            ON r.city=d.city AND r.target_date=d.target_date
           AND r.yes_resolved=1
          WHERE d.city=? AND d.status='valid_d0'
            AND d.source GLOB 'weatherol_*'
          ORDER BY d.target_date DESC,d.first_captured_at ASC""",
        (city,),
    ).fetchall()
    result: list[dict[str, Any]] = []
    seen_dates: set[str] = set()
    for target_date, forecast_bucket, settlement_label in rows:
        target = str(target_date)
        if target in seen_dates:
            continue
        settlement = parse_settlement_bucket(str(settlement_label))
        if forecast_bucket is None or settlement is None:
            continue
        seen_dates.add(target)
        settled_bucket = int(settlement["bucket"])
        result.append(
            {
                "target_date": target,
                "forecast_bucket": int(forecast_bucket),
                "settlement_bucket": settled_bucket,
                "settlement_kind": str(settlement["kind"]),
                "settlement_label": str(settlement["label"]),
                "deviation": settled_bucket - int(forecast_bucket),
            }
        )
        if len(result) >= int(limit):
            break
    return result
