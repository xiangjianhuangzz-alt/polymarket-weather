# V8 Implementation Input Closure iic2｜受限修订任务合同

状态：`CANDIDATE_FROZEN_AWAITING_INDEPENDENT_QA`  
日期：2026-09-03（Asia/Shanghai）  
当前阶段：`IMPLEMENTATION_INPUT_CLOSURE_DESIGN`

## 1. 唯一目标

本轮仅关闭IIC1独立QA确认的七个当前阶段阻断：`MISSING-01`至`MISSING-07`。`ak2`、`cd4`与`iic1`保持冻结；不得创建`ak3`、`cd5`，不得引入第八项Requirement。

## 2. 唯一规范源

本任务合同只记录范围、授权、交付物和停止点，不定义业务算法。唯一机器可读规范源为：

`T00_新动态策略ImplementationInputClosure规范_iic2_2026-09-03.json`

Manifest只登记冻结身份和成员Hash，不构成第二套业务规范。任何语义必须从上述JSON读取；无法消解的上游冲突必须失败关闭。

## 3. 上游绑定

- branch：`codex/handoff-baseline-20260809`
- HEAD：`13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac`
- AGENTS SHA256：`19f561c33b28ccd5cbad7c115955e739d9141ba56058a9cce791f2e7ff3e99e0`
- ak2 SHA256：`e01d30534b8b1de77ac4c426d925dda222a0c772540fb09b6425d39fab11308d`
- cd4 canonical SHA256：`5d510e91b5950767bd0550b8870bce02a50456aa882d606d24db776417509742`
- cd4 candidate hash：`74503f27d0b91d583c42936f0fa9c1be3dc319f461bba80330a450f38af185c4`
- iic1 candidate hash：`d67d81d75a455c7264929605e2f2f82c4345db29611c0d1d0b0d5f0887429f9d`

## 4. 允许与禁止

允许：必要只读事实核对、T01/DATA/STRATEGY/BE设计输入、形成并冻结iic2三件套、冻结后QA独立只读审查。

禁止：修改任何冻结对象；业务代码、DDL、数据库、测试、故障注入、Replay、Backtest、部署、服务启停、Git写入、Shadow、Paper、Live、订单、钱包、资金或`backups/`操作。

## 5. 停止点

候选冻结后，T00、T01、DATA、STRATEGY和BE不得修改。QA若FAIL，立即停止，不得自动创建`iic3`；QA若PASS，也不得自动进入Implementation Planning。

以下状态始终保持：

```text
IMPLEMENTATION_AUTHORIZED=NO
TEST_EXECUTION_AUTHORIZED=NO
GIT_WRITE_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
SHADOW_AUTHORIZED=NO
PAPER_AUTHORIZED=NO
LIVE_TRADING_AUTHORIZED=NO
```

`READY_FOR_IMPLEMENTATION_PLANNING != IMPLEMENTATION_AUTHORIZED`
