# T00｜新动态策略真实上游Truth Table与Canonical Contract｜V8.2候选｜2026-09-01

状态：`CANDIDATE_DESIGN_ONLY`  
规则：本文是V8.2底层事实和字段映射权威；正文不得覆盖。所有未来实现名称必须逐字一致。

## 1. 真实上游Truth Table

| 域/现表 | 当前唯一writer | 当前键与行为 | 可直接作单调cursor | V8.2裁决 |
|---|---|---|---|---|
| `forecast_versions` | Collector | TEXT PK；同content冲突时UPDATE last_seen/display；初始化路径可DELETE全表 | 否 | 不直接消费；未来Collector同事务追加`strategy_forecast_publications.publication_seq` |
| `forecast_events` | Collector | `event_id AUTOINCREMENT`；forecast变化INSERT、确认UPDATE | 仅归一值变化 | 作为交叉证据，不代替raw publication |
| `forecast_raw_payloads` | Collector | 复合时间PK；内容变化INSERT OR REPLACE；可retention/delete | 否 | publication必须包含raw payload/hash，不再以时间key推进 |
| `forecast_snapshots` | Collector | 复合PK；INSERT OR REPLACE；可全表重建 | 否 | 仅用于Collector生成北京/广州TAF publication，不供策略直接cursor |
| `market_snapshots/rules` | Collector | snapshots可replace/update active；rules UPSERT | 否 | 未来完整scan同事务追加`strategy_market_publications` |
| `market_resolutions/evidence` | Collector | resolution replace；evidence独立 | 否 | final成立时同事务追加`strategy_settlement_publications` |
| `metar_observations` | METAR | `observation_id AUTOINCREMENT`、INSERT OR IGNORE；只删除14日前旧行 | 是（保留期内） | 直接以observation_id推进；若cursor落后于最小ID则CITY fail-stop，不猜测补齐 |
| `book_snapshots` | Realtime | `(captured_at,token)` UPSERT；含`depth_fresh`；按时间retention delete | 否 | 作为完整header事实，但cursor来自未来book publication_seq |
| `orderbook_levels` | Realtime | 同captured/token整组在同一事务写；可能UPSERT；retention delete | 否 | future publication绑定同captured/token整组count/hash |
| `market_rule_snapshots` | Realtime | 规则变化时INSERT；book_hash不随每次book保存 | 否 | publication必须同时复制当时有效tick/min_order/neg_risk，不用旧book_hash冒充快照hash |

当前三个数据库都可能发生UPDATE、REPLACE、DELETE或retention；除METAR observation_id外，业务时间和SQLite rowid均不得作为无遗漏cursor。`rowid`不进入规范。

## 2. 最小上游publication合同

这些是未来独立实现/部署前置，不属于策略Release：

### 2.1 Collector forecast publication

```text
strategy_forecast_publications
publication_seq INTEGER PRIMARY KEY AUTOINCREMENT
committed_at TEXT NOT NULL RFC3339
upstream_city TEXT NOT NULL
source TEXT NOT NULL
station TEXT NOT NULL
target_date TEXT NOT NULL Date
forecast_high_c_milli INTEGER NOT NULL divisible-by-1000
source_reported_at TEXT NULL RFC3339
raw_kind TEXT NOT NULL
raw_payload_json TEXT NOT NULL canonical JSON
raw_payload_sha256 TEXT NOT NULL H64
normalized_sha256 TEXT NOT NULL H64
schema_version INTEGER NOT NULL =1
```

Collector只在raw payload、normalized value和source identity全部一致时，在保存forecast变化的同一事务追加一行。上海只允许`Shanghai/weatherol_shanghai/ZSPD/weatherol_d0`；北京、广州只允许`Beijing|Guangzhou/aviationweather_taf/ZBAA|ZGGG/taf_normalized`。重复poll不重复publication；任何UPDATE必须产生新publication_seq。

### 2.2 Collector market publication

```text
strategy_market_publications
publication_seq INTEGER PRIMARY KEY AUTOINCREMENT
committed_at TEXT NOT NULL
publication_id TEXT NOT NULL H64
city TEXT NOT NULL TitleCaseCity
target_date TEXT NOT NULL Date
contracts_json TEXT NOT NULL canonical complete bucket array
contracts_sha256 TEXT NOT NULL H64
fee_payload_sha256 TEXT NOT NULL H64
schema_version INTEGER NOT NULL =1
UNIQUE(publication_id,city,target_date)
```

它与完整market scan publication同事务追加。`contracts_json`每个元素必须包含market_id、condition_id、question、description、end_date、bucket、outcomes、tokens、YES token、feesEnabled和完整feeSchedule。三城各自形成完整整数摄氏bucket partition；任何成员缺失则不发布本城行。

### 2.3 Collector settlement publication

```text
strategy_settlement_publications
publication_seq INTEGER PRIMARY KEY AUTOINCREMENT
committed_at TEXT NOT NULL
city TEXT NOT NULL TitleCaseCity
target_date TEXT NOT NULL Date
market_id TEXT NOT NULL DecimalDigits
condition_id TEXT NOT NULL HexId
bucket_id TEXT NOT NULL H64
yes_resolved INTEGER NOT NULL CHECK IN(0,1)
resolution_evidence_id TEXT NOT NULL
resolution_payload_sha256 TEXT NOT NULL H64
schema_version INTEGER NOT NULL =1
UNIQUE(market_id,resolution_evidence_id)
```

只允许Collector正式final evidence产生；天气结果不得写入。

### 2.4 Realtime complete book publication

```text
strategy_book_publications
publication_seq INTEGER PRIMARY KEY AUTOINCREMENT
committed_at TEXT NOT NULL
captured_at TEXT NOT NULL
market_id TEXT NOT NULL DecimalDigits
token_id TEXT NOT NULL DecimalDigits
depth_fresh INTEGER NOT NULL =1
best_bid TEXT NULL Decimal01
best_ask TEXT NULL Decimal01
bid_size TEXT NULL DecimalNonNegative
ask_size TEXT NULL DecimalNonNegative
tick_size TEXT NOT NULL DecimalPositive
min_order_size TEXT NOT NULL DecimalPositive
neg_risk INTEGER NOT NULL CHECK IN(0,1)
level_count INTEGER NOT NULL >0
levels_sha256 TEXT NOT NULL H64
schema_version INTEGER NOT NULL =1
```

Realtime只在`book_snapshots.depth_fresh=1`时，与header及现有`orderbook_levels`中同一`captured_at+token_id`的完整levels同一事务追加这个轻量publication header。publication不复制levels；Evidence在同一只读快照中按header定位原levels。levels按`side ASC, price numeric ASC`规范排序后计算`level_count`和`levels_sha256`；每项规范形式是`{side,price,size}`十进制字符串。BBO必须可由levels重算且逐Decimal相等；否则不发布。任何book变化产生新seq，即使captured_at相同也禁止UPDATE旧publication。publication header与其所引用levels必须使用同一保留期并原子清理；若Evidence cursor落后于可见最小seq则失败关闭，禁止跳过。

四个publication表均为append-only：禁止UPDATE既有publication。任何DELETE/retention必须由未来独立的数据保留设计批准，并保证Evidence所需资格期、审计期及header引用levels仍完整；在该设计获批前不得清理。

### 2.5 METAR direct stream

METAR不新增publication表。cursor=`observation_id`；payload identity=`station+report_time+raw_hash`。Evidence要求`received_at<=event_at`，而非仅`report_time<=event_at`。删除导致`cursor < MIN(observation_id)-1`时输出`E_SOURCE_RETENTION_GAP`并使该城失败关闭。

## 3. Strict AS-OF统一规则

每个上游数据库分别以SQLite `mode=ro`、`query_only=ON`、`BEGIN DEFERRED`固定snapshot。对于publication表读取：

```text
persisted_seq < publication_seq <= anchor_max_seq
AND committed_at <= event_at
AND source_reported_at IS NULL OR source_reported_at <= event_at
```

METAR读取：

```text
persisted_observation_id < observation_id <= anchor_max_observation_id
AND received_at <= event_at
AND report_time <= event_at
```

anchor保存DB规范路径ID、Windows volume serial/file index、schema hash、user_version、data_version、transaction start、event_at、lower seq、upper seq、row count和range hash。业务时间不得推进cursor；后到旧source timestamp以新的publication_seq进入下一事件，只能影响其`committed_at`之后的决定。

## 4. Canonical primitive

| 名称 | 唯一表示 |
|---|---|
| H64 | `^[0-9a-f]{64}$` |
| Rfc3339 | 必须含`Z`或显式offset，解析后规范成UTC `YYYY-MM-DDTHH:MM:SS.ffffffZ` |
| Date | `YYYY-MM-DD`且日历合法 |
| DecimalDigits | `^(0|[1-9][0-9]*)$` |
| HexId | `^0x[0-9a-f]+$` |
| Decimal01 | 非指数十进制字符串，`0<=x<=1` |
| DecimalPositive | 非指数十进制字符串，`x>0` |
| DecimalNonNegative | 非指数十进制字符串，`x>=0` |
| CanonicalJson | UTF-8、对象键Unicode code point升序、数组保序、无空白、禁止float/NaN/Infinity |
| InternalCity | `SHANGHAI|BEIJING|GUANGZHOU` |
| UpstreamCity | `Shanghai|Beijing|Guangzhou` |

全部hash：`SHA256(ASCII(domain) || 0x00 || canonical_bytes(payload))`。domain逐对象冻结，禁止裸拼接。

## 5. Canonical Object字段映射

映射符号：`SQL(db.table.column)`、`JSON(schema.path)`、`DERIVE(formula)`。每个字段恰有一个权威来源；派生值不得另存成第二权威。

### O01 ReleaseIdentity

```text
code_ref:H64=JSON(approved_config.release.code_ref)
config_set_hash:H64=DERIVE(hash ApprovedConfigSet without config_set_hash)
deployment_ref:H64=JSON(deployment_manifest.deployment_ref)
python_sha256:H64=JSON(deployment_manifest.python_sha256)
```

### O02 SourceAnchor

```text
anchor_id:H64=DERIVE(hash all following fields)
city:InternalCity=SQL(evidence.source_anchor.city)
stream:FORECAST|MARKET|SETTLEMENT|METAR|BOOK=SQL(...stream)
db_path_id:str=SQL(...db_path_id)
volume_serial:str=SQL(...volume_serial)
file_index:str=SQL(...file_index)
schema_hash:H64=SQL(...schema_hash)
event_at:Rfc3339=SQL(...event_at)
lower_seq:int>=0=SQL(...lower_seq)
upper_seq:int>=0=SQL(...upper_seq)
row_count:int>=0=SQL(...row_count)
range_hash:H64=SQL(...range_hash)
```

### O03 EvidenceRecord

```text
city_seq:int>=1=SQL(evidence.evidence_record.city_seq)
event_id:H64=SQL(...event_id)
city:InternalCity=SQL(...city)
stream:O02.stream=SQL(...stream)
source_seq:int>=1=SQL(...source_seq)
source_observed_at:Rfc3339|null=SQL(...source_observed_at)
received_at:Rfc3339=SQL(...received_at)
target_date:Date|null=SQL(...target_date)
payload_json:CanonicalJson=SQL(...payload_json)
payload_sha256:H64=SQL(...payload_sha256)
previous_hash:H64=SQL(...previous_hash)
chain_hash:H64=SQL(...chain_hash)
```

### O04 Bucket

```text
bucket_id:H64=DERIVE(hash label/domain/kind/bounds/ordinal)
label:str=JSON(market_contract.bucket.label)
kind:LOWER_TAIL|SINGLETON|UPPER_TAIL=JSON(...kind)
lower_c_milli:int|null=JSON(...lower_c_milli)
upper_c_milli:int|null=JSON(...upper_c_milli)
ordinal:int>=0=JSON(...ordinal)
```

### O05 MarketContract

```text
contract_ref:H64=DERIVE(hash all contract JSON except contract_ref)
publication_seq:int>=1=JSON(contract.publication_seq)
publication_id:H64=JSON(contract.publication_id)
market_id:DecimalDigits=JSON(contract.market_id)
condition_id:HexId=JSON(contract.condition_id)
city:InternalCity=JSON(contract.city)
target_date:Date=JSON(contract.target_date)
question:str=JSON(contract.question)
description:str=JSON(contract.description)
rule_sha256:H64=DERIVE(hash description)
bucket:O04=JSON(contract.bucket)
yes_token_id:DecimalDigits=JSON(contract.yes_token_id)
no_token_id:DecimalDigits=JSON(contract.no_token_id)
end_date:Rfc3339=JSON(contract.end_date)
payload_sha256:H64=JSON(contract.payload_sha256)
```

### O06 FeeEvidence

```text
fee_ref:H64=DERIVE(hash fields excluding fee_ref)
market_id/condition_id/yes_token_id=JSON(fee same-name)
fees_enabled:bool=JSON(fee.fees_enabled)
formula:POLYMARKET_V2_P_ONE_MINUS_P|null=JSON(fee.formula)
rate_ppm:int[0,1000000]|null=JSON(fee.rate_ppm)
exponent:1|null=JSON(fee.exponent)
taker_only:true|null=JSON(fee.taker_only)
rebate_rate_ppm:int[0,1000000]|null=JSON(fee.rebate_rate_ppm)
captured_at:Rfc3339=JSON(fee.captured_at)
payload_sha256:H64=JSON(fee.payload_sha256)
```

### O07 BookSnapshot

```text
book_ref:H64=DERIVE(hash all fields excluding book_ref)
publication_seq:int>=1=JSON(book.publication_seq)
captured_at/committed_at:Rfc3339=JSON(book same-name)
market_id/token_id:DecimalDigits=JSON(book same-name)
bids/asks:array[{price:Decimal01,size:DecimalNonNegative}]=JSON(book same-name)
best_bid/best_ask:Decimal01|null=DERIVE(max bid/min ask)
tick_size/min_order_size:DecimalPositive=JSON(book same-name)
neg_risk:bool=JSON(book.neg_risk)
levels_sha256:H64=DERIVE(hash canonical bids+asks)
```

### O08 ModelInput

```text
city:InternalCity=JSON(model_input.city)
target_date:Date=JSON(...target_date)
event_at:Rfc3339=JSON(...event_at)
local_second:int[25200,57599]=DERIVE(event_at Asia/Shanghai)
forecast_high_c_milli:int divisible-by-1000=JSON(...forecast_high_c_milli)
observed_max_so_far_c_milli:int divisible-by-1000=JSON(...observed_max_so_far_c_milli)
forecast_publication_seq:int>=1=JSON(...forecast_publication_seq)
metar_anchor_ref:H64=JSON(...metar_anchor_ref)
artifact_ref:H64=JSON(...artifact_ref)
```

### O09 ProbabilityVector

```text
bucket_ids:array[H64]>=2=JSON(probability.bucket_ids)
raw:array[Decimal01]=JSON(...raw)
calibrated:array[Decimal01]=JSON(...calibrated)
lcb:array[Decimal01]=JSON(...lcb)
raw/calibrated length=bucket_ids length; each sum exactly 1 at 12 places; lcb no sum requirement
```

### O10 ApprovedModelRef / O11 ApprovedConfigSet

```text
O10={city,artifact_ref,qualification_ref,candidate_ref,policy_ref}
O11={schema_version=1,code_ref,common_policy_hash,models:{SHANGHAI:O10,BEIJING:O10,GUANGZHOU:O10},approved_by_sid,approval_ref,approved_at,config_set_hash}
config_set_hash=DERIVE(hash O11 without config_set_hash)
```

O11只存在于CREATE_NEW只读文件，不存在`approved_model`数据库表。

### O12 Decision

```text
decision_id:H64=DERIVE(hash fields except decision_id)
previous_decision_id:H64|null=SQL(runtime.decision.previous_decision_id)
city/event_at/target_date=SQL(runtime.decision same-name)
event_id/snapshot_ref/contract_ref/fee_ref/book_ref/artifact_ref/config_set_hash:H64=SQL(...same-name)
bucket_id:H64=SQL(...bucket_id)
state:NO_TRADE|YES_CANDIDATE|INVALIDATED|FAIL_CLOSED|WINDOW_CLOSED=SQL(...state)
reasons_json:array[DecisionReason]=SQL(...reasons_json)
errors_json:array[ErrorCode]=SQL(...errors_json)
p_lcb/c_executable/e_conservative:Decimal01|null=SQL(...same-name)
output_json:CanonicalJson=SQL(...output_json)
```

## 6. 完整JSON Schema规则

未来唯一Schema文件为`contracts.schema.json`，Draft 2020-12，根`$defs`包含O01-O12。每个object必须`type:object`、上述全部非nullable字段进入`required`、`additionalProperties:false`；nullable使用`oneOf`。O04使用三分支oneOf：LOWER_TAIL仅upper，SINGLETON上下相等，UPPER_TAIL仅lower。O06：fees_enabled=false时公式字段全部null；true时formula/rate/exponent/taker_only非null。O11的models使用固定三键且`minProperties=maxProperties=3`。O12由state控制数值字段：YES_CANDIDATE必须三个数值非null；WINDOW_CLOSED/FAIL_CLOSED允许null。

附录必须给出该Schema的逐字JSON正文；本文字段表与附录逐字Schema冲突时V8.2终审FAIL，不允许实现者选择。

## 7. 七个失败边界裁决

```text
Schema/DDL：字段权威映射 + 附录完整文本
模型时间：完整fold_decision_at，预测与事后标签分离
批准：单个ApprovedConfigSet文件是唯一提交点，无approved_model表
book：Realtime完整publication，header/count/hash/levels/BBO同事务
cursor：仅AUTOINCREMENT publication_seq或METAR observation_id
reason：单一DecisionReason Enum机械生成Schema/DDL CHECK
停止：三个入口均调用common.lifecycle.run_until_absolute_stop
```

任何上游publication未实现并部署时，V8.2只能保持`SOURCE_PUBLICATION_UNAVAILABLE/FAIL_CLOSED`，不得回退旧时间cursor。
