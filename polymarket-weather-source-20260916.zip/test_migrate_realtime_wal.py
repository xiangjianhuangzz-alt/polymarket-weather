from __future__ import annotations

import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

from migrate_realtime_wal import inspect, migrate


class RealtimeWalMigrationTests(unittest.TestCase):
    def test_migration_changes_only_journal_mode(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "realtime.sqlite3"
            with closing(sqlite3.connect(database)) as db, db:
                db.execute("CREATE TABLE latest_bbo(token_id TEXT PRIMARY KEY,captured_at TEXT)")
                db.executemany("INSERT INTO latest_bbo VALUES (?,?)", [("yes", "2026-01-01T00:00:00+00:00"), ("no", "2026-01-01T00:00:01+00:00")])
            before = inspect(database)
            result = migrate(database)
            after = inspect(database)
            self.assertTrue(result["changed"])
            self.assertEqual(before["table_counts"], after["table_counts"])
            self.assertEqual(after["integrity"], "ok")
            self.assertEqual(after["journal_mode"], "wal")

    def test_migration_requires_existing_database(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(RuntimeError):
                migrate(Path(temporary) / "missing.sqlite3")


if __name__ == "__main__":
    unittest.main()
