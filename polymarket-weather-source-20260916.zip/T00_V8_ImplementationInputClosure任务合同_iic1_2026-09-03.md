# V8 Implementation Input Closure iic1｜任务合同

状态：`CANDIDATE_FROZEN_AWAITING_INDEPENDENT_QA`  
日期：2026-09-03（Asia/Shanghai）  
当前阶段：`IMPLEMENTATION_INPUT_CLOSURE_DESIGN`

## 1. 唯一目标

本任务只为设计血缘审计确认的`MISSING-01`至`MISSING-07`建立当前、唯一、可实现的规范归属，并在候选冻结后接受独立QA。本任务不是`cd5`、`ak3`、Implementation、Implementation Test或Deployment。

## 2. 唯一规范源

本文件只定义授权、范围、交付物和停止点，不定义业务算法。唯一机器可读规范源为：

`T00_新动态策略ImplementationInputClosure规范_iic1_2026-09-03.json`

Manifest只记录候选身份和成员哈希。发生语义冲突时，不得用本任务合同或Manifest覆盖机器规范源；必须失败关闭并报告冲突。

## 3. 当前绑定

- branch：`codex/handoff-baseline-20260809`
- HEAD：`13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac`
- AGENTS SHA256：`19f561c33b28ccd5cbad7c115955e739d9141ba56058a9cce791f2e7ff3e99e0`
- ak2 SHA256：`e01d30534b8b1de77ac4c426d925dda222a0c772540fb09b6425d39fab11308d`
- cd4 canonical SHA256：`5d510e91b5950767bd0550b8870bce02a50456aa882d606d24db776417509742`
- cd4 candidate hash：`74503f27d0b91d583c42936f0fa9c1be3dc319f461bba80330a450f38af185c4`

## 4. 允许范围

- 必要只读仓库事实核对；
- T01、DATA、STRATEGY、BE专业设计协作；
- 当前控制面阶段状态同步；
- 创建本任务合同、唯一JSON规范源和Manifest；
- 冻结后由QA执行独立只读审查。

## 5. 禁止范围

- 修改`ak2`或`cd1`—`cd4`，创建`ak3`或`cd5`；
- 编写业务实现或`strategy_v8`；
- 执行DDL、修改真实数据库或运行Implementation Test；
- 故障注入、replay、backtest或任何实证有效性判断；
- Git写入、部署、服务启停、Shadow、Paper、Live、订单、钱包或资金操作；
- 处理`backups/`或其他未授权资产。

## 6. 交付物与停止点

交付物恰为本任务合同、唯一JSON规范源和Manifest。候选冻结后，T00、T01、DATA、STRATEGY和BE不得修改候选。QA结束即停止：FAIL时不得自动创建`iic2`；PASS时也不得自动进入Implementation Planning。

以下状态始终保持：

```text
IMPLEMENTATION_AUTHORIZED=NO
TEST_EXECUTION_AUTHORIZED=NO
GIT_WRITE_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
SHADOW_AUTHORIZED=NO
PAPER_AUTHORIZED=NO
LIVE_TRADING_AUTHORIZED=NO
```

`READY_FOR_IMPLEMENTATION_PLANNING != IMPLEMENTATION_AUTHORIZED`
