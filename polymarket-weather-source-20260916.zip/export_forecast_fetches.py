"""Export Weatherol pull history into compact CSV files for review."""
import csv
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB = BASE / "data" / "research.sqlite3"
OUT = BASE / "outputs" / "forecast_fetches"
CN_TZ = timezone(timedelta(hours=8))
CITIES = ("Beijing", "Chengdu", "Guangzhou", "Shanghai", "Shenzhen")


def china_time(value: str) -> str:
    return datetime.fromisoformat(value).astimezone(CN_TZ).strftime("%Y-%m-%d %H:%M:%S")


OUT.mkdir(parents=True, exist_ok=True)
db = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
rows = db.execute("""SELECT captured_at, source_reported_at, city, target_date, forecast_high_c
  FROM forecast_update_values
  WHERE captured_at >= '2026-07-16T16:00:00+00:00'
  ORDER BY captured_at, city, target_date""").fetchall()

captures: dict[str, dict[tuple[str, str], float]] = {}
reported: dict[str, str] = {}
for captured_at, reported_at, city, target_date, high in rows:
    captures.setdefault(captured_at, {})[(city, target_date)] = high
    reported[captured_at] = reported_at

dates = sorted({target_date for _, _, _, target_date, _ in rows})
columns = [f"{city} {target_date}" for city in CITIES for target_date in dates]
with (OUT / "拉取明细.csv").open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["采集时间（北京时间）", "气象在线报告时间（北京时间）", *columns])
    for captured_at, values in captures.items():
        writer.writerow([china_time(captured_at), china_time(reported[captured_at]),
                         *[values.get((city, target_date)) for city in CITIES for target_date in dates]])

changes = db.execute("""SELECT source, city, target_date, forecast_high_c,
  MIN(captured_at), MAX(captured_at), COUNT(*)
  FROM forecast_update_values
  WHERE captured_at >= '2026-07-16T16:00:00+00:00'
  GROUP BY source, city, target_date, forecast_high_c
  ORDER BY city, target_date, MIN(captured_at)""").fetchall()
with (OUT / "预报变化汇总.csv").open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["来源", "城市", "目标日期", "预报最高温（°C）", "首次捕获（北京时间）", "最后捕获（北京时间）", "出现次数"])
    for source, city, target_date, high, first, last, count in changes:
        writer.writerow([source, city, target_date, high, china_time(first), china_time(last), count])

db.close()
