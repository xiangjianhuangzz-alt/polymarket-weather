from __future__ import annotations

import asyncio
import copy
import math
import sqlite3
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock, patch

import collector


CAPTURED_AT = "2026-08-13T02:00:00+00:00"

NEW_SOURCES = {
    "Wuhan": {
        "station": "ZHHH",
        "aid": "JCCN100054",
        "airportname": "武汉天河国际机场",
        "lat": "30.776258",
        "lng": "114.217379",
    },
    "Chongqing": {
        "station": "ZUCK",
        "aid": "JCCN100139",
        "airportname": "重庆江北国际机场",
        "lat": "29.727675",
        "lng": "106.648039",
    },
}

PRIMARY_SOURCES = {
    "Beijing": {"station": "ZBAA", "aid": "JCCN100005", "airportname": "北京首都国际机场", "lat": "40.08", "lng": "116.58"},
    "Shanghai": {"station": "ZSPD", "aid": "JCCN100117", "airportname": "上海浦东国际机场", "lat": "31.14", "lng": "121.80"},
    "Chengdu": {"station": "ZUUU", "aid": "JCCN100160", "airportname": "成都双流国际机场", "lat": "30.57", "lng": "103.95"},
    "Guangzhou": {"station": "ZGGG", "aid": "JCCN100037", "airportname": "广州白云国际机场", "lat": "23.39", "lng": "113.30"},
    "Shenzhen": {"station": "ZGSZ", "aid": "JCCN100048", "airportname": "深圳宝安国际机场", "lat": "22.64", "lng": "113.81"},
}

PRIMARY = frozenset({"Beijing", "Shanghai", "Chengdu", "Guangzhou", "Shenzhen"})
ADDITIONAL = frozenset(NEW_SOURCES)
ACTIVE_TAF = frozenset({
    "Beijing", "Shanghai", "Chengdu", "Guangzhou", "Shenzhen",
    "Wuhan", "Chongqing",
})


class TextSubclass(str):
    pass


def valid_payload(city: str, *, high: object = "31") -> dict:
    source = NEW_SOURCES.get(city) or PRIMARY_SOURCES[city]
    return {
        "code": 200,
        "data": {
            "current": {
                "current": {
                    "jcid": source["aid"],
                    "airportname": source["airportname"],
                    "lat": source["lat"],
                    "lng": source["lng"],
                    "reporttime": "01:55",
                }
            },
            "forecast15d": [
                {"forecasttime": "08/12", "temperature_am": "29"},
                {"forecasttime": "08/13", "temperature_am": high},
                {"forecasttime": "08/14", "temperature_am": "30"},
            ],
        },
    }


class Response:
    def __init__(self, payload: dict) -> None:
        self._payload = payload

    def raise_for_status(self) -> None:
        return None

    def json(self) -> dict:
        return copy.deepcopy(self._payload)


class PayloadClient:
    def __init__(self, payloads: dict[str, dict]) -> None:
        self.payloads = payloads
        self.urls: list[str] = []

    async def get(self, url: str, **_kwargs) -> Response:
        self.urls.append(url)
        aid = url.rsplit("=", 1)[-1]
        return Response(self.payloads[aid])


class TAFClient:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict]] = []

    async def get(self, url: str, **kwargs) -> Response:
        self.calls.append((url, kwargs))
        return Response([])


def open_test_db(tmp: tempfile.TemporaryDirectory) -> sqlite3.Connection:
    path = Path(tmp.name) / "research.sqlite3"
    with patch.object(collector, "DB_PATH", path):
        return collector.connect()


def insert_stations(db: sqlite3.Connection, cities: set[str]) -> None:
    for city in cities:
        source = NEW_SOURCES[city]
        point = collector.TAF_GRID_STATIONS[city][1]
        db.execute(
            "INSERT INTO airport_stations VALUES (?,?,?,?,?)",
            (source["station"], city, point[0], point[1], CAPTURED_AT),
        )
    db.commit()


class SourceConfigurationTests(unittest.TestCase):
    def test_active_sources_exclude_retired_cities(self) -> None:
        self.assertEqual(collector.PRIMARY_WEATHEROL_CITIES, PRIMARY)
        self.assertEqual(collector.ADDITIONAL_WEATHEROL_CITIES, ADDITIONAL)
        self.assertEqual(collector.TAF_DISCOVERY_CITIES, ACTIVE_TAF)
        for city, source in NEW_SOURCES.items():
            aid, url = collector.weatherol_airport_for_city(city)
            self.assertEqual(aid, source["aid"])
            self.assertEqual(url, f"https://weatherol.cn/api/getData?aid={source['aid']}")
        self.assertIsNone(collector.weatherol_airport_for_city("Jinan"))
        self.assertIsNone(collector.weatherol_airport_for_city("Qingdao"))

    def test_existing_five_sources_and_schedules_are_unchanged(self) -> None:
        self.assertEqual(
            {city: collector.weatherol_airport_for_city(city) for city in PRIMARY},
            {
                "Beijing": ("JCCN100005", "https://weatherol.cn/api/getData?aid=JCCN100005"),
                "Shanghai": ("JCCN100117", "https://weatherol.cn/api/getData?aid=JCCN100117"),
                "Chengdu": ("JCCN100160", "https://weatherol.cn/api/getData?aid=JCCN100160"),
                "Guangzhou": ("JCCN100037", "https://weatherol.cn/api/getData?aid=JCCN100037"),
                "Shenzhen": ("JCCN100048", "https://weatherol.cn/api/getData?aid=JCCN100048"),
            },
        )
        self.assertEqual(collector.PRECISION_FORECAST_SCHEDULE, {
            57: {"Beijing", "Shanghai", "Guangzhou", "Shenzhen"},
            12: {"Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Chengdu"},
            2: {"Chengdu"}, 17: {"Chengdu"},
        })
        self.assertEqual(collector.PRECISION_RETRY_SCHEDULE, {
            0: {"Beijing", "Shanghai", "Guangzhou", "Shenzhen"},
            15: {"Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Chengdu"},
            5: {"Chengdu"}, 20: {"Chengdu"},
        })
        self.assertEqual(collector.EXPECTED_REPORT_MINUTES, {
            "Beijing": {55, 10}, "Shanghai": {55, 10},
            "Guangzhou": {55, 10}, "Shenzhen": {55, 10},
            "Chengdu": {0, 10, 15},
        })


class ForecastCyclePlanTests(unittest.TestCase):
    def assert_plan(self, when: str, *, first: bool, refresh: bool,
                    primary: set[str], additional: set[str], taf: set[str]) -> None:
        plan = collector.build_forecast_cycle_plan(
            datetime.fromisoformat(when), first_cycle=first, refresh_markets=refresh
        )
        self.assertEqual(plan.primary_qxzx, frozenset(primary))
        self.assertEqual(plan.additional_qxzx, frozenset(additional))
        self.assertEqual(plan.taf, frozenset(taf))
        self.assertEqual(plan.run_cycle, bool(primary or additional or taf or refresh))

    def test_first_cycle_and_discovery_are_full_but_precision_is_legacy_only(self) -> None:
        self.assert_plan("2026-08-13T08:07:00+08:00", first=True, refresh=False,
                         primary=set(PRIMARY), additional=set(ADDITIONAL), taf=set(ACTIVE_TAF))
        self.assert_plan("2026-08-13T08:10:00+08:00", first=False, refresh=False,
                        primary=set(PRIMARY), additional=set(ADDITIONAL), taf=set(ACTIVE_TAF))
        self.assert_plan("2026-08-13T08:12:00+08:00", first=False, refresh=False,
                         primary={"Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Chengdu"},
                         additional=set(),
                         taf={"Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Chengdu"})
        self.assert_plan("2026-08-13T08:13:00+08:00", first=False, refresh=True,
                         primary=set(), additional=set(), taf=set())

    def test_overlap_is_deduplicated_and_transition_minute_is_exact(self) -> None:
        plan = collector.build_forecast_cycle_plan(
            datetime.fromisoformat("2026-08-13T08:20:00+08:00"),
            first_cycle=False, refresh_markets=False,
        )
        self.assertEqual(plan.primary_qxzx, PRIMARY)
        self.assertEqual(plan.additional_qxzx, ADDITIONAL)
        self.assertEqual(plan.taf, ACTIVE_TAF)


class AdditionalIdentityGateTests(unittest.TestCase):
    def test_valid_payloads_freeze_identity_and_today_high(self) -> None:
        for city, source in NEW_SOURCES.items():
            with self.subTest(city=city):
                verified = collector.validate_additional_weatherol_payload(
                    city, valid_payload(city), CAPTURED_AT
                )
                self.assertEqual(verified.aid, source["aid"])
                self.assertEqual(verified.airport_name, source["airportname"])
                self.assertEqual(verified.target_date, "2026-08-13")
                self.assertEqual(verified.forecast_high_c, 31.0)
                self.assertTrue(math.isfinite(verified.latitude))
                self.assertTrue(math.isfinite(verified.longitude))

    def test_identity_and_structure_mutations_fail_closed(self) -> None:
        mutations = {
            "code_bool": lambda p: p.__setitem__("code", True),
            "code_wrong": lambda p: p.__setitem__("code", 201),
            "jcid_wrong": lambda p: p["data"]["current"]["current"].__setitem__("jcid", "JCCN100139"),
            "jcid_subclass": lambda p: p["data"]["current"]["current"].__setitem__("jcid", TextSubclass("JCCN100054")),
            "jcid_space": lambda p: p["data"]["current"]["current"].__setitem__("jcid", " JCCN100054 "),
            "name_wrong": lambda p: p["data"]["current"]["current"].__setitem__("airportname", "北京首都国际机场"),
            "name_subclass": lambda p: p["data"]["current"]["current"].__setitem__("airportname", TextSubclass("武汉天河国际机场")),
            "lat_nan": lambda p: p["data"]["current"]["current"].__setitem__("lat", "NaN"),
            "lon_infinite": lambda p: p["data"]["current"]["current"].__setitem__("lng", float("inf")),
            "far_point": lambda p: p["data"]["current"]["current"].__setitem__("lat", "40"),
            "report_time_bad": lambda p: p["data"]["current"]["current"].__setitem__("reporttime", "1:55"),
            "forecast_object": lambda p: p["data"].__setitem__("forecast15d", {}),
            "no_today": lambda p: p["data"].__setitem__("forecast15d", [{"forecasttime": "08/14", "temperature_am": "30"}]),
            "duplicate_today": lambda p: p["data"]["forecast15d"].append({"forecasttime": "08/13", "temperature_am": "32"}),
            "bad_temperature": lambda p: p["data"]["forecast15d"][1].__setitem__("temperature_am", "NaN"),
        }
        for name, mutate in mutations.items():
            with self.subTest(name=name):
                payload = valid_payload("Wuhan")
                mutate(payload)
                with self.assertRaises(collector.AdditionalWeatherolSourceRejected):
                    collector.validate_additional_weatherol_payload("Wuhan", payload, CAPTURED_AT)

    def test_url_contract_rejects_spoofed_forms(self) -> None:
        invalid = [
            "http://weatherol.cn/api/getData?aid=JCCN100054",
            "https://evil.weatherol.cn/api/getData?aid=JCCN100054",
            "https://weatherol.cn.evil/api/getData?aid=JCCN100054",
            "https://weatherol.cn/api/getData/fake?aid=JCCN100054",
            "https://weatherol.cn/api/getData?aid=JCCN100054&extra=1",
            "https://weatherol.cn/api/getData?aid=JCCN100054&aid=JCCN100054",
        ]
        for url in invalid:
            with self.subTest(url=url):
                self.assertFalse(collector.valid_weatherol_source_url(url, "JCCN100054"))

    def test_invalid_configured_url_is_rejected_before_network(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        db = open_test_db(tmp)
        try:
            insert_stations(db, {"Wuhan"})
            client = PayloadClient({NEW_SOURCES["Wuhan"]["aid"]: valid_payload("Wuhan")})
            with patch.dict(
                collector.WEATHEROL_AIRPORTS,
                {"wuhan": ("JCCN100054", "https://weatherol.cn.evil/api/getData?aid=JCCN100054")},
            ):
                fetched = asyncio.run(collector.collect_forecasts(
                    client, db, CAPTURED_AT, {"Wuhan"}
                ))
            self.assertEqual(fetched, [])
            self.assertEqual(client.urls, [])
            audit = db.execute(
                "SELECT status,detail FROM forecast_fetch_audits WHERE source='weatherol_wuhan'"
            ).fetchone()
            self.assertEqual(audit, (
                "fetch_failed", "source_identity_rejected:source_url_invalid"
            ))
        finally:
            db.close()
            tmp.cleanup()

    def test_wrong_city_station_pair_is_rejected_before_network(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        db = open_test_db(tmp)
        try:
            db.execute(
                "INSERT INTO airport_stations VALUES (?,?,?,?,?)",
                ("ZUCK", "Wuhan", 29.7192, 106.642, CAPTURED_AT),
            )
            db.commit()
            client = PayloadClient({NEW_SOURCES["Wuhan"]["aid"]: valid_payload("Wuhan")})
            fetched = asyncio.run(collector.collect_forecasts(
                client, db, CAPTURED_AT, {"Wuhan"}
            ))
            self.assertEqual(fetched, [])
            self.assertEqual(client.urls, [])
            self.assertEqual(db.execute(
                "SELECT status,detail FROM forecast_fetch_audits WHERE source='weatherol_wuhan'"
            ).fetchone(), ("fetch_failed", "source_identity_rejected:station_mismatch"))
        finally:
            db.close()
            tmp.cleanup()


class ForecastDatabaseIntegrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.db = open_test_db(self.tmp)

    def tearDown(self) -> None:
        self.db.close()
        self.tmp.cleanup()

    def test_active_additional_sources_write_expected_city_station_and_d0(self) -> None:
        insert_stations(self.db, set(ADDITIONAL))
        client = PayloadClient({source["aid"]: valid_payload(city) for city, source in NEW_SOURCES.items()})
        fetched = asyncio.run(collector.collect_forecasts(client, self.db, CAPTURED_AT, set(ADDITIONAL)))
        self.assertEqual(set(fetched), set(ADDITIONAL))
        self.assertEqual(len(client.urls), 2)
        rows = self.db.execute(
            "SELECT source,city,station,target_date,forecast_high_c FROM forecast_update_values ORDER BY city"
        ).fetchall()
        self.assertEqual(len(rows), 2)
        self.assertEqual({(row[1], row[2]) for row in rows}, {
            (city, source["station"]) for city, source in NEW_SOURCES.items()
        })
        self.assertEqual({row[3] for row in rows}, {"2026-08-13"})
        self.assertEqual({row[4] for row in rows}, {31.0})
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM forecast_d0_registry").fetchone()[0], 2)

    def test_existing_five_keep_legacy_payload_behavior_without_new_identity_gate(self) -> None:
        for city, source in PRIMARY_SOURCES.items():
            point = collector.TAF_GRID_STATIONS[city][1]
            self.db.execute(
                "INSERT INTO airport_stations VALUES (?,?,?,?,?)",
                (source["station"], city, point[0], point[1], CAPTURED_AT),
            )
        self.db.commit()
        payloads = {
            source["aid"]: valid_payload(city)
            for city, source in PRIMARY_SOURCES.items()
        }
        # The old path never required jcid or exact airport name; retaining this
        # proves the new strict ownership gate did not leak into the original five.
        for payload in payloads.values():
            payload["data"]["current"]["current"].pop("jcid")
            payload["data"]["current"]["current"]["airportname"] = "legacy display name"
        fetched = asyncio.run(collector.collect_forecasts(
            PayloadClient(payloads), self.db, CAPTURED_AT, set(PRIMARY)
        ))
        self.assertEqual(set(fetched), set(PRIMARY))
        self.assertEqual(
            self.db.execute("SELECT COUNT(*) FROM forecast_update_values").fetchone()[0],
            5,
        )

    def test_rejected_city_writes_only_failure_audit_and_does_not_block_others(self) -> None:
        insert_stations(self.db, set(ADDITIONAL))
        payloads = {source["aid"]: valid_payload(city) for city, source in NEW_SOURCES.items()}
        payloads[NEW_SOURCES["Wuhan"]["aid"]]["data"]["current"]["current"]["jcid"] = "JCCN100139"
        before = self.db.execute("SELECT latitude,longitude FROM airport_stations WHERE city='Wuhan'").fetchone()
        fetched = asyncio.run(collector.collect_forecasts(
            PayloadClient(payloads), self.db, CAPTURED_AT, set(ADDITIONAL)
        ))
        self.assertEqual(set(fetched), set(ADDITIONAL) - {"Wuhan"})
        after = self.db.execute("SELECT latitude,longitude FROM airport_stations WHERE city='Wuhan'").fetchone()
        self.assertEqual(after, before)
        source = "weatherol_wuhan"
        for table, where in (
            ("forecast_raw_payloads", "source=?"),
            ("forecast_snapshots", "model=?"),
            ("forecast_update_values", "source=?"),
            ("forecast_versions", "source=?"),
            ("forecast_events", "source=?"),
            ("forecast_d0_registry", "source=?"),
        ):
            self.assertEqual(self.db.execute(f"SELECT COUNT(*) FROM {table} WHERE {where}", (source,)).fetchone()[0], 0)
        audit = self.db.execute(
            "SELECT status,detail FROM forecast_fetch_audits WHERE source=?", (source,)
        ).fetchone()
        self.assertEqual(audit[0], "fetch_failed")
        self.assertTrue(audit[1].startswith("source_identity_rejected:"))


class CycleExecutionOrderTests(unittest.IsolatedAsyncioTestCase):
    async def test_primary_then_taf_then_additional_use_separate_phases(self) -> None:
        db = sqlite3.connect(":memory:")
        db.execute("CREATE TABLE collector_runs(captured_at TEXT PRIMARY KEY,active_markets INTEGER,airport_stations INTEGER,settled_markets INTEGER)")
        db.execute("CREATE TABLE service_heartbeats(service TEXT PRIMARY KEY,updated_at TEXT,detail TEXT)")
        calls: list[tuple[str, frozenset[str]]] = []

        async def forecasts(_client, _db, _captured, cities, _progress):
            stage = "primary" if frozenset(cities).issubset(PRIMARY) else "additional"
            calls.append((stage, frozenset(cities)))
            return []

        async def taf(_client, _db, _captured, cities, _progress):
            calls.append(("taf", frozenset(cities)))
            return []

        class ClientContext:
            async def __aenter__(self):
                return object()

            async def __aexit__(self, *_args):
                return False

        try:
            with patch.object(collector.httpx, "AsyncClient", return_value=ClientContext()), \
                 patch.object(collector, "collect_forecasts", new=AsyncMock(side_effect=forecasts)), \
                 patch.object(collector, "collect_taf_forecasts", new=AsyncMock(side_effect=taf)):
                await collector.one_cycle(
                    db, refresh_markets=False,
                    forecast_cities=set(PRIMARY),
                    additional_forecast_cities=set(ADDITIONAL),
                    taf_cities=set(ACTIVE_TAF),
                )
            self.assertEqual(calls, [
                ("primary", PRIMARY), ("taf", ACTIVE_TAF), ("additional", ADDITIONAL)
            ])
        finally:
            db.close()

    async def test_discovery_taf_request_contains_exact_ten_station_ids(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        db = open_test_db(tmp)
        client = TAFClient()
        try:
            await collector.collect_taf_forecasts(client, db, CAPTURED_AT, set(ACTIVE_TAF))
            self.assertEqual(len(client.calls), 1)
            url, kwargs = client.calls[0]
            self.assertEqual(url, collector.TAF_FORECAST_URL)
            self.assertEqual(
                kwargs["params"]["ids"].split(","),
                [station for station, _point in collector.TAF_GRID_STATIONS.values()],
            )
            self.assertEqual(len(kwargs["params"]["ids"].split(",")), 7)
            self.assertNotIn("ZSJN", kwargs["params"]["ids"])
            self.assertNotIn("ZSQD", kwargs["params"]["ids"])
            self.assertNotIn("ZHCC", kwargs["params"]["ids"])
        finally:
            db.close()
            tmp.cleanup()


if __name__ == "__main__":
    unittest.main()
