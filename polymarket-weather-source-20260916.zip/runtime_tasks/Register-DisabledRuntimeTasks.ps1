[CmdletBinding()]
param(
    [ValidateSet("Audit", "RegisterDisabled")]
    [string]$Mode = "Audit",
    [string]$ConfirmToken = ""
)

$ErrorActionPreference = "Stop"
$ExpectedToken = "REGISTER_DISABLED_RUNTIME_TASKS"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestPath = Join-Path $PackageRoot "runtime_tasks.json"

if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
    throw "Task manifest is missing: $ManifestPath"
}

$Manifest = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$ExpectedServices = @(
    "collector",
    "realtime_stream",
    "metar_collector",
    "runtime_observer"
)

if ($Manifest.registration_mode -ne "disabled_only") {
    throw "Manifest is not restricted to disabled registration."
}
if ($Manifest.settings.enabled -ne $false) {
    throw "Manifest unexpectedly enables tasks."
}
if (@($Manifest.tasks).Count -ne 4) {
    throw "Exactly four isolated tasks are required."
}
if (@($Manifest.tasks.service | Sort-Object -Unique).Count -ne 4) {
    throw "Task services must be unique."
}
foreach ($Service in $ExpectedServices) {
    if ($Service -notin @($Manifest.tasks.service)) {
        throw "Missing required service task: $Service"
    }
}
if (-not (Test-Path -LiteralPath $Manifest.python_executable -PathType Leaf)) {
    throw "Python executable is missing: $($Manifest.python_executable)"
}
if (-not (Test-Path -LiteralPath $Manifest.working_directory -PathType Container)) {
    throw "Working directory is missing: $($Manifest.working_directory)"
}
foreach ($Task in $Manifest.tasks) {
    if ($Task.rescue_trigger -isnot [bool]) {
        throw "Task rescue_trigger must be boolean: $($Task.name)"
    }
    if ($Task.arguments -match "service_supervisor|bot\.py|LIVE_TRADING|PRIVATE_KEY") {
        throw "Forbidden legacy or live-trading argument in task $($Task.name)."
    }
    $QuotedScript = [regex]::Match($Task.arguments, '^"([^"]+\.py)"')
    if (-not $QuotedScript.Success -or
        -not (Test-Path -LiteralPath $QuotedScript.Groups[1].Value -PathType Leaf)) {
        throw "Task script is missing or malformed: $($Task.name)"
    }
}

if ($Mode -eq "Audit") {
    [pscustomobject]@{
        Result = "AUDIT_ONLY"
        Registered = $false
        Enabled = $false
        TaskPath = $Manifest.task_path
        TaskCount = @($Manifest.tasks).Count
        Services = (@($Manifest.tasks.service) -join ",")
    }
    return
}

if ($ConfirmToken -cne $ExpectedToken) {
    throw "Registration requires -ConfirmToken $ExpectedToken"
}

$UserId = if ($env:USERDOMAIN) {
    "$($env:USERDOMAIN)\$($env:USERNAME)"
} else {
    $env:USERNAME
}
$LogonTrigger = New-ScheduledTaskTrigger -AtLogOn -User $UserId
$RescueTrigger = New-ScheduledTaskTrigger `
    -Once `
    -At ((Get-Date).AddMinutes(1)) `
    -RepetitionInterval (New-TimeSpan -Minutes $Manifest.settings.rescue_interval_minutes) `
    -RepetitionDuration (New-TimeSpan -Days $Manifest.settings.rescue_duration_days)
$Principal = New-ScheduledTaskPrincipal `
    -UserId $UserId `
    -LogonType Interactive `
    -RunLevel Limited
$Settings = New-ScheduledTaskSettingsSet `
    -Disable `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -StartWhenAvailable `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries

foreach ($Task in $Manifest.tasks) {
    $Existing = Get-ScheduledTask `
        -TaskPath $Manifest.task_path `
        -TaskName $Task.name `
        -ErrorAction SilentlyContinue
    if ($null -ne $Existing) {
        throw "Refusing to overwrite existing task: $($Manifest.task_path)$($Task.name)"
    }
}

# Register-ScheduledTask does not consistently create a custom folder across
# Windows builds.  Create only this package's dedicated folder; no existing
# task or folder is modified.
$Scheduler = New-Object -ComObject "Schedule.Service"
$Scheduler.Connect()
try {
    $null = $Scheduler.GetFolder($Manifest.task_path)
} catch {
    if ($Manifest.task_path -ne "\PolymarketWeather\") {
        throw "Refusing to create an unexpected task folder: $($Manifest.task_path)"
    }
    $RootFolder = $Scheduler.GetFolder("\")
    $null = $RootFolder.CreateFolder("PolymarketWeather")
}

foreach ($Task in $Manifest.tasks) {
    $TaskTriggers = if ($Task.rescue_trigger) {
        @($LogonTrigger, $RescueTrigger)
    } else {
        @($LogonTrigger)
    }
    $Action = New-ScheduledTaskAction `
        -Execute $Manifest.python_executable `
        -Argument $Task.arguments `
        -WorkingDirectory $Manifest.working_directory
    Register-ScheduledTask `
        -TaskPath $Manifest.task_path `
        -TaskName $Task.name `
        -Action $Action `
        -Trigger $TaskTriggers `
        -Settings $Settings `
        -Principal $Principal `
        -Description $Task.description | Out-Null
}

$Registered = @(
    Get-ScheduledTask -TaskPath $Manifest.task_path |
        Where-Object { $_.TaskName -in @($Manifest.tasks.name) }
)
if ($Registered.Count -ne 4 -or @($Registered | Where-Object State -ne "Disabled").Count -ne 0) {
    throw "Post-registration verification failed: all four tasks must exist and remain disabled."
}

[pscustomobject]@{
    Result = "REGISTERED_DISABLED"
    Registered = $true
    Enabled = $false
    TaskPath = $Manifest.task_path
    TaskCount = $Registered.Count
}
