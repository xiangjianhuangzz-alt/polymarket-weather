"""Modern local dashboard with a strictly local paper-trading ledger."""
from __future__ import annotations

import json
import math
import os
import re
import sqlite3
import threading
from collections import OrderedDict
from typing import Callable, Any
from datetime import UTC, datetime, timedelta, timezone
from pathlib import Path

import webview
from db_paths import OBSERVATIONS_DB, RESEARCH_DB, REALTIME_DB, PAPER_DB as LEDGER_DB

BASE = Path(__file__).resolve().parent
DB = RESEARCH_DB
PAPER_DB = LEDGER_DB
PUBLIC_ERROR_MESSAGES = {
    "data_temporarily_unavailable": "Data temporarily unavailable",
    "data_contract_unavailable": "Data contract unavailable",
}
RETIREMENT_EFFECTIVE_DATE_CN = "2026-08-22"
CITY_RETIREMENT_DATES = {"Jinan": "2026-08-22", "Qingdao": "2026-08-22", "Zhengzhou": "2026-08-30"}
RETIRED_CITIES = frozenset(CITY_RETIREMENT_DATES)
CITY_ORDER = ["Beijing", "Shanghai", "Chengdu", "Guangzhou", "Shenzhen"]
CN = {"Beijing": "北京", "Shanghai": "上海", "Chengdu": "成都", "Guangzhou": "广州", "Shenzhen": "深圳"}
MODELS = {
    "aviationweather_taf": "TAF",
    "weatherol_beijing": "QXZX（北京机场）", "weatherol_shanghai": "QXZX（上海机场）",
    "weatherol_chengdu": "QXZX（成都机场）", "weatherol_guangzhou": "QXZX（广州机场）",
    "weatherol_shenzhen": "QXZX（深圳机场）", "weatherol_shenzhen_baoan": "QXZX（深圳宝安）",
    "weatherol_wuhan": "QXZX（武汉机场）", "weatherol_chongqing": "QXZX（重庆机场）",
    "weatherol_jinan": "QXZX（济南机场）", "weatherol_zhengzhou": "QXZX（郑州机场）",
}
# Fixed forecast ownership is deliberately separate from the legacy five-city
# compatibility constants below.  It cannot grow from database contents.
FORECAST_API_CITIES = (
    {"city": "Beijing", "city_label": "北京", "station": "ZBAA", "city_scope": "formal", "qxzx_source": "weatherol_beijing"},
    {"city": "Shanghai", "city_label": "上海", "station": "ZSPD", "city_scope": "formal", "qxzx_source": "weatherol_shanghai"},
    {"city": "Chengdu", "city_label": "成都", "station": "ZUUU", "city_scope": "formal", "qxzx_source": "weatherol_chengdu"},
    {"city": "Guangzhou", "city_label": "广州", "station": "ZGGG", "city_scope": "formal", "qxzx_source": "weatherol_guangzhou"},
    {"city": "Shenzhen", "city_label": "深圳", "station": "ZGSZ", "city_scope": "research_only", "qxzx_source": "weatherol_shenzhen"},
    {"city": "Wuhan", "city_label": "武汉", "station": "ZHHH", "city_scope": "research_only", "qxzx_source": "weatherol_wuhan"},
    {"city": "Chongqing", "city_label": "重庆", "station": "ZUCK", "city_scope": "research_only", "qxzx_source": "weatherol_chongqing"},
    {"city": "Jinan", "city_label": "济南", "station": "ZSJN", "city_scope": "research_only", "qxzx_source": "weatherol_jinan"},
    {"city": "Qingdao", "city_label": "青岛", "station": "ZSQD", "city_scope": "research_only", "qxzx_source": None},
    {"city": "Zhengzhou", "city_label": "郑州", "station": "ZHCC", "city_scope": "research_only", "qxzx_source": "weatherol_zhengzhou"},
)
FORECAST_API_CITY_BY_NAME = {item["city"]: item for item in FORECAST_API_CITIES}
FORECAST_API_OWNERSHIP = {
    (source, item["city"], item["station"]): item
    for item in FORECAST_API_CITIES
    for source in ([item["qxzx_source"]] if item["qxzx_source"] else []) + ["aviationweather_taf"]
}
TRACKED_SOURCE_MODELS = tuple(sorted({source for source, _city, _station in FORECAST_API_OWNERSHIP}))


def _forecast_iso(value: object) -> datetime | None:
    if type(value) is not str or not value or value != value.strip():
        return None
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if stamp.tzinfo is None or stamp.utcoffset() is None:
            return None
        stamp = stamp.astimezone(UTC)
        stamp.astimezone(CHINA_TZ)
        return stamp
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def _forecast_date(value: object) -> str | None:
    if type(value) is not str or value != value.strip() or len(value) != 10:
        return None
    try:
        return value if datetime.strptime(value, "%Y-%m-%d").strftime("%Y-%m-%d") == value else None
    except ValueError:
        return None


def _forecast_number(value: object) -> float | int | None | object:
    if value is None:
        return None
    if type(value) not in (int, float):
        return _FORECAST_INVALID
    try:
        finite = math.isfinite(value)
    except OverflowError:
        return _FORECAST_INVALID
    if not finite:
        return _FORECAST_INVALID
    return value


_FORECAST_INVALID = object()


def _forecast_china_time(stamp: datetime | None) -> str | None:
    if stamp is None:
        return None
    try:
        return stamp.astimezone(CHINA_TZ).strftime("%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def _select_strict_registry(rows: list[sqlite3.Row | dict]) -> dict | None:
    """Select one v2/overlay registry fact without reviving an older row."""
    candidates = []
    for raw in rows:
        latest = _forecast_iso(dict(raw).get("latest_checked_at"))
        if latest is None:
            return None
        candidates.append((latest, str(dict(raw).get("grid_version")), raw))
    if not candidates:
        return None
    candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return _d0_registry_row(candidates[0][2], strict_owner=True)


def _select_latest_snapshot(rows: list[tuple]) -> list[tuple]:
    """Return one UTC-newest non-conflicting snapshot per source/station."""
    groups: dict[tuple[str, str], list[tuple[datetime, tuple]]] = {}
    invalid: set[tuple[str, str]] = set()
    for row in rows:
        city, station, model, raw, captured = row
        key, stamp = (station, model), _forecast_iso(captured)
        if stamp is None:
            invalid.add(key)
        else:
            groups.setdefault(key, []).append((stamp, row))
    selected = []
    for key, candidates in groups.items():
        if key in invalid:
            continue
        latest = max(stamp for stamp, _row in candidates)
        newest = [row for stamp, row in candidates if stamp == latest]
        if len({(row[0], row[2], row[3]) for row in newest}) == 1:
            selected.append(newest[0])
    return selected


def _order_updates(rows: list[tuple], allowed_dates: set[str]) -> list[tuple[dict, datetime, object, object, str, str, str, str]]:
    ordered = []
    for source, city, station, target_date, high, captured_at in rows:
        normalized = _forecast_update_row(source, city, station, target_date, high, captured_at, allowed_dates)
        if normalized is not None:
            ordered.append((*normalized, high, captured_at, source, city, station, target_date))
    return sorted(ordered, key=lambda item: (item[1], item[0]["city"], item[0]["station"], str(item[3])))


def _d0_registry_row(row: sqlite3.Row | dict, *, strict_owner: bool = False) -> dict | None:
    data = dict(row)
    if (type(data.get("source")) is not str or type(data.get("city")) is not str
            or type(data.get("station")) is not str or type(data.get("target_date")) is not str
            or type(data.get("status")) is not str or data["status"] not in D0_STATUS_META):
        return None
    if strict_owner and (data["source"], data["city"], data["station"]) not in FORECAST_API_OWNERSHIP:
        return None
    if _forecast_date(data["target_date"]) is None:
        return None
    for field in ("forecast_high_c", "capture_delay_seconds"):
        value = _forecast_number(data.get(field))
        if value is _FORECAST_INVALID or (field == "capture_delay_seconds" and value is not None and value < 0):
            return None
        data[field] = value
    bucket = data.get("forecast_bucket")
    if bucket is not None and type(bucket) is not int:
        return None
    for field in ("source_reported_at", "first_captured_at", "frozen_at", "latest_checked_at"):
        raw = data.get(field)
        stamp = _forecast_iso(raw) if raw is not None else None
        if raw is not None and stamp is None:
            return None
        data[f"_{field}"] = stamp
    for field in ("grid_version", "reason", "content_hash"):
        if data.get(field) is not None and type(data[field]) is not str:
            return None
    if data["status"] == "valid_d0":
        if (data["forecast_high_c"] is None or data["forecast_bucket"] is None
                or data["_source_reported_at"] is None
                or data["_first_captured_at"] is None or data["_frozen_at"] is None
                or data["_latest_checked_at"] is None):
            return None
        if (data["_frozen_at"] < data["_first_captured_at"]
                or data["_latest_checked_at"] < data["_frozen_at"]
                or (data["_source_reported_at"] is not None
                    and data["_source_reported_at"] > data["_first_captured_at"] + timedelta(minutes=5))
                or data["forecast_bucket"] != math.floor(data["forecast_high_c"])
                or any(type(data.get(field)) is not str or not data[field]
                       or data[field] != data[field].strip()
                       for field in ("grid_version", "content_hash", "reason"))):
            return None
    elif data["status"] != "missing_target_value":
        data["forecast_high_c"] = None
        data["forecast_bucket"] = None
        data["_frozen_at"] = None
    return data


def _d0_version_row(row: sqlite3.Row | dict) -> dict | None:
    data = dict(row)
    if (type(data.get("version_id")) is not str or not data["version_id"]
            or data["version_id"] != data["version_id"].strip()
            or type(data.get("content_hash")) is not str or not data["content_hash"]
            or data["content_hash"] != data["content_hash"].strip()
            or type(data.get("source")) is not str or type(data.get("city")) is not str
            or type(data.get("station")) is not str or type(data.get("target_date")) is not str
            or (data["source"], data["city"], data["station"]) not in FORECAST_API_OWNERSHIP
            or _forecast_date(data["target_date"]) is None):
        return None
    value = _forecast_number(data.get("forecast_high_c"))
    if value is _FORECAST_INVALID:
        return None
    data["forecast_high_c"] = value
    for field in ("first_seen_at", "last_seen_at", "source_display_time"):
        raw = data.get(field)
        stamp = _forecast_iso(raw) if raw is not None else None
        if raw is not None and stamp is None:
            return None
        data[f"_{field}"] = stamp
    if data["_first_seen_at"] is None or data["_last_seen_at"] is None:
        return None
    if data["_last_seen_at"] < data["_first_seen_at"]:
        return None
    if type(data.get("is_change")) is not int or data["is_change"] not in (0, 1):
        return None
    return data


def _forecast_snapshot_row(source: object, city: object, station: object, raw: object,
                           captured_at: object, allowed_dates: set[str]) -> list[tuple[str, float | int | None, datetime, datetime | None]] | None:
    if type(source) is not str or type(city) is not str or type(station) is not str:
        return None
    if (source, city, station) not in FORECAST_API_OWNERSHIP or _forecast_iso(captured_at) is None:
        return None
    def reject_constant(_value: str) -> None:
        raise ValueError("non-finite JSON constant")

    def reject_duplicates(pairs: list[tuple[str, object]]) -> dict:
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    try:
        if type(raw) is not str:
            return None
        payload = json.loads(raw, parse_constant=reject_constant, object_pairs_hook=reject_duplicates)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if type(payload) is not dict or type(payload.get("daily")) is not dict:
        return None
    metadata = payload.get("metadata", {})
    if type(metadata) is not dict:
        return None
    times, highs = payload["daily"].get("time"), payload["daily"].get("temperature_2m_max")
    if type(times) is not list or type(highs) is not list or len(times) != len(highs):
        return None
    source_value = next((metadata[key] for key in ("source_reported_at", "model_run_at", "issued_at")
                         if key in metadata and metadata[key] is not None), None)
    source_time = _forecast_iso(source_value) if source_value is not None else None
    if source_value is not None and source_time is None:
        return None
    captured = _forecast_iso(captured_at)
    result, seen = [], set()
    for day, high in zip(times, highs):
        valid_day = _forecast_date(day)
        valid_high = _forecast_number(high)
        if valid_day is None or valid_high is _FORECAST_INVALID or valid_day in seen:
            return None
        seen.add(valid_day)
        if valid_day in allowed_dates:
            result.append((valid_day, valid_high, captured, source_time))
    return result


def _forecast_update_row(source: object, city: object, station: object, target_date: object,
                         high: object, captured_at: object, allowed_dates: set[str]) -> tuple[dict, datetime] | None:
    if type(source) is not str or type(city) is not str or type(station) is not str:
        return None
    owner = FORECAST_API_OWNERSHIP.get((source, city, station))
    valid_date, valid_high, stamp = _forecast_date(target_date), _forecast_number(high), _forecast_iso(captured_at)
    if owner is None or valid_date not in allowed_dates or valid_high is _FORECAST_INVALID or stamp is None:
        return None
    if stamp.astimezone(CHINA_TZ).date().isoformat() != valid_date:
        return None
    return owner, stamp
CHINA_TZ = timezone(timedelta(hours=8), name="Asia/Shanghai")

D0_SCHEMA = "d0_evidence.v1"
D0_POLICY_VERSION = "d0-evidence-facts-v1"
D0_SCHEMA_V2 = "d0_evidence.v2"
D0_V2_CITIES = FORECAST_API_CITIES
D0_V2_CITY_BY_NAME = {item["city"]: item for item in D0_V2_CITIES}
def _d0_cities_for_date(target_date: str):
    return tuple(item for item in D0_V2_CITIES if target_date < CITY_RETIREMENT_DATES.get(item["city"], "9999-12-31"))
METAR_ACTUAL_CITIES = (
    {"city": "Beijing", "city_label": "\u5317\u4eac", "station": "ZBAA", "decision_scope": "risk_exclusion"},
    {"city": "Shanghai", "city_label": "\u4e0a\u6d77", "station": "ZSPD", "decision_scope": "risk_exclusion"},
    {"city": "Chengdu", "city_label": "\u6210\u90fd", "station": "ZUUU", "decision_scope": "risk_exclusion"},
    {"city": "Guangzhou", "city_label": "\u5e7f\u5dde", "station": "ZGGG", "decision_scope": "risk_exclusion"},
    {"city": "Shenzhen", "city_label": "\u6df1\u5733", "station": "ZGSZ", "decision_scope": "research_only"},
    {"city": "Wuhan", "city_label": "\u6b66\u6c49", "station": "ZHHH", "decision_scope": "research_only"},
    {"city": "Chongqing", "city_label": "\u91cd\u5e86", "station": "ZUCK", "decision_scope": "research_only"},
    {"city": "Jinan", "city_label": "\u6d4e\u5357", "station": "ZSJN", "decision_scope": "research_only"},
    {"city": "Qingdao", "city_label": "\u9752\u5c9b", "station": "ZSQD", "decision_scope": "research_only"},
    {"city": "Zhengzhou", "city_label": "\u90d1\u5dde", "station": "ZHCC", "decision_scope": "research_only"},
)
METAR_ACTUAL_BY_STATION = {item["station"]: item for item in METAR_ACTUAL_CITIES}
ACTIVE_METAR_ACTUAL_CITIES = tuple(
    item for item in METAR_ACTUAL_CITIES
    if "2026-08-30" < CITY_RETIREMENT_DATES.get(item["city"], "9999-12-31")
)


def _metar_cities_now():
    today = china_now().date().isoformat()
    return tuple(item for item in METAR_ACTUAL_CITIES if today < CITY_RETIREMENT_DATES.get(item["city"], "9999-12-31"))
D0_STATIONS = {
    "Beijing": "ZBAA", "Shanghai": "ZSPD", "Chengdu": "ZUUU",
    "Guangzhou": "ZGGG", "Shenzhen": "ZGSZ",
}
D0_STATUS_META = {
    "valid_d0": ("有效 D0", "ok"),
    "waiting": ("等待正常发布", "neutral"),
    "publication_overdue": ("发布异常延迟", "warning"),
    "delayed_carry": ("旧报延续", "warning"),
    "source_time_missing": ("来源时间缺失", "error"),
    "source_clock_skew": ("来源时间异常", "error"),
    "midnight_not_after": ("零点报文，不计入 D0", "neutral"),
    "missing_target_value": ("缺少目标日温度或 TAF TX", "error"),
    "fetch_failed": ("来源读取失败", "error"),
    "legacy_unverified": ("历史记录未验证来源时间", "neutral"),
    "not_retained": ("历史明细已超过保留期", "neutral"),
    "not_observed": ("尚无采集事实", "neutral"),
    "policy_undetermined": ("当前政策不足以判定", "warning"),
}
D0_ANOMALIES = {
    "source_time_missing", "source_clock_skew", "missing_target_value",
    "fetch_failed", "publication_overdue",
}
D0_STATUS_PRIORITY = (
    "source_clock_skew", "source_time_missing", "missing_target_value",
    "delayed_carry", "midnight_not_after", "fetch_failed",
)
D0_REASON_CODES = {
    "source_clock_skew": "source_clock_skew_observed",
    "source_time_missing": "source_time_unavailable",
    "delayed_carry": "source_day_before_target",
    "midnight_not_after": "source_exactly_midnight",
    "fetch_failed": "provider_fetch_failed",
    "legacy_unverified": "historical_policy_missing",
    "not_retained": "detail_retention_expired",
    "not_observed": "no_collection_fact",
    "policy_undetermined": "historical_policy_missing",
}


def _d0_now_iso() -> str:
    return china_now().isoformat(timespec="seconds")


def _d0_china_iso(value: str | None) -> str | None:
    if not value:
        return None
    try:
        stamp = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=UTC)
        return stamp.astimezone(CHINA_TZ).isoformat(timespec="seconds")
    except ValueError:
        return None


def _d0_error(code: str, message: str, field: str | None,
              retryable: bool = False) -> dict:
    return {
        "schema": D0_SCHEMA, "ok": False,
        "error": {"code": code, "message": message, "field": field,
                  "retryable": retryable},
        "page_updated_at": _d0_now_iso(), "timezone": "Asia/Shanghai",
    }


def _d0_valid_date(target_date: str) -> bool:
    try:
        return datetime.strptime(str(target_date), "%Y-%m-%d").strftime("%Y-%m-%d") == target_date
    except (TypeError, ValueError):
        return False


def _d0_has_table(db: sqlite3.Connection, name: str) -> bool:
    return db.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
    ).fetchone() is not None


def _d0_retention() -> dict:
    return {
        "registry_days": 90,
        "detail_days": 7,
        "fetch_audits": {"days": None, "bounded_by_row_limit": True},
        "resolution_days": None,
        "limitations": [
            "detail tables may be unavailable after retention cleanup",
            "fetch audits have no target_date and are not attributed heuristically",
        ],
    }


def china_now() -> datetime:
    return datetime.now(CHINA_TZ)


def china_time(value: str | None) -> str | None:
    """Show all stored timestamps as China time, never ambiguous UTC."""
    if not value:
        return None
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
        return stamp.astimezone(CHINA_TZ).strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return value


def parse_time(value: str | None) -> datetime | None:
    """Parse a stored quote clock for monotonic live/durable comparison."""
    if not value:
        return None
    try:
        stamp = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=UTC)
    return stamp.astimezone(UTC)


def prefer_projected_quote(projected: dict[str, Any] | None,
                           durable: tuple | None) -> bool:
    """Choose the newest quote without letting recovery roll time backwards."""
    if not projected:
        return False
    if not durable:
        return True
    projected_at = parse_time(projected.get("captured_at"))
    durable_at = parse_time(durable[4])
    if projected_at is None:
        return durable_at is None
    return durable_at is None or projected_at >= durable_at


def freshness(value: str | None, threshold_seconds: int) -> dict:
    """Expose stale local records rather than presenting them as live."""
    if not value:
        return {"state": "missing", "age_seconds": None}
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=UTC)
        age = max(0.0, (datetime.now(UTC) - stamp).total_seconds())
        return {"state": "healthy" if age <= threshold_seconds else "stale", "age_seconds": round(age, 1)}
    except ValueError:
        return {"state": "missing", "age_seconds": None}


def market_date(question: str) -> str:
    import re
    match = re.search(r"on ([A-Za-z]+ \d{1,2}(?:, \d{4})?)", question)
    if not match:
        return "未知"
    text = match.group(1)
    try:
        return datetime.strptime(text + ("" if "," in text else f", {china_now().year}"), "%B %d, %Y").strftime("%Y-%m-%d")
    except ValueError:
        return text


def assess_forecast(bucket: str, forecast: float | None) -> tuple[str, str]:
    """Compare a rounded forecast to the actual Polymarket winning bucket."""
    if forecast is None:
        return "未采集", "—"
    raw_value = float(forecast)
    if False:  # Decimal forecasts map to their integer market bucket by floor.
        return "非整数预报，待处理", "—"
    value = math.floor(raw_value)
    match = re.search(r"(\d+)", bucket or "")
    if not match:
        return "无法识别结算桶", "—"
    boundary = int(match.group(1))
    label = (bucket or "").lower()
    if "below" in label:
        distance = max(0, value - boundary)
        if distance == 0:
            return "命中结算桶", "≤%d°C" % boundary
        return ("偏差 +%d°C（停止交易）" % distance if distance >= 2 else "偏差 +1°C（观察）",
                "高于上界 %d°C" % distance)
    if "higher" in label:
        distance = max(0, boundary - value)
        if distance == 0:
            return "命中结算桶", "≥%d°C" % boundary
        return ("偏差 -%d°C（停止交易）" % distance if distance >= 2 else "偏差 -1°C（观察）",
                "低于下界 %d°C" % distance)
    delta = value - boundary
    if delta == 0:
        return "命中结算桶", "0°C"
    if abs(delta) >= 2:
        return "偏差 %+d°C（停止交易）" % delta, "%+d°C" % delta
    return "偏差 %+d°C（观察）" % delta, "%+d°C" % delta


def d0_model_validations(db: sqlite3.Connection, city: str, target_date: str,
                         bucket: str) -> list[dict]:
    """Return one D0 settlement-validation row per forecast model.

    These are model-quality observations, not paper-strategy performance.
    The exploratory +/-1 experiment is intentionally not consulted here.
    """
    # Prefer source-time-verified frozen D0.  The registry did not exist for
    # older settled days, though.  For those days we show the earliest capture
    # from the China target date as an explicitly labelled historical backfill;
    # it must never be confused with source-time-verified D0 evidence.
    result: dict[str, dict] = {}
    if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='forecast_d0_registry'").fetchone():
        rows = db.execute("""SELECT source,forecast_high_c,first_captured_at
          FROM forecast_d0_registry WHERE city=? AND target_date=? AND status='valid_d0'
            AND forecast_high_c IS NOT NULL ORDER BY source""", (city, target_date)).fetchall()
        for model, high, captured_at in rows:
            status, deviation = assess_forecast(bucket or "", float(high))
            result[str(model)] = {"model": MODELS.get(str(model), str(model)), "high": float(high),
                                  "captured_at": china_time(str(captured_at)), "status": status,
                                  "deviation": deviation, "provenance": "verified_d0"}
    start = datetime.fromisoformat(target_date).replace(tzinfo=CHINA_TZ).astimezone(UTC).isoformat()
    end = (datetime.fromisoformat(target_date).replace(tzinfo=CHINA_TZ) + timedelta(days=1)).astimezone(UTC).isoformat()
    # Rows are sorted ascending: the first target-day pull is the only honest
    # fallback for a historical D0 backfill.  Do not overwrite it with a later
    # intraday revision.
    earliest: dict[str, tuple[float, str]] = {}
    for source, high, captured_at in db.execute("""SELECT source,forecast_high_c,captured_at
      FROM forecast_update_values WHERE city=? AND target_date=? AND captured_at>=? AND captured_at<?
      ORDER BY captured_at""", (city, target_date, start, end)):
        if high is not None and str(source) not in earliest:
            earliest[str(source)] = (float(high), str(captured_at))
    for model, raw, captured_at in db.execute("""SELECT f.model,f.forecast_json,f.captured_at
      FROM forecast_snapshots f JOIN airport_stations a ON a.station=f.city
      WHERE a.city=? AND f.captured_at>=? AND f.captured_at<?
        AND f.model IN ('aviationweather_taf')
      ORDER BY f.captured_at""", (city, start, end)):
        try:
            daily = json.loads(raw).get("daily", {})
            high = next((value for stamp, value in zip(daily.get("time", []), daily.get("temperature_2m_max", []))
                         if str(stamp) == target_date and value is not None), None)
        except (TypeError, ValueError, json.JSONDecodeError):
            high = None
        if high is not None and str(model) not in earliest:
            earliest[str(model)] = (float(high), str(captured_at))
    for model, (high, captured_at) in earliest.items():
        # A valid immutable D0, when present, always wins over a backfill.
        if model in result:
            continue
        status, deviation = assess_forecast(bucket or "", high)
        result[model] = {"model": MODELS.get(model, model), "high": high,
                         "captured_at": china_time(captured_at), "status": status,
                         "deviation": deviation, "provenance": "historical_backfill"}
    return sorted(result.values(), key=lambda item: item["model"])


def match_market_bucket(markets: list[dict], city: str, target_date: str,
                        forecast: float | None) -> tuple[dict | None, str | None]:
    """Map an integral forecast into exactly one actual Polymarket bucket."""
    if forecast is None:
        return None, "missing_forecast"
    value = float(forecast)
    if not value.is_integer():
        return None, "non_integer_forecast"
    temperature = int(value)
    matches: list[dict] = []
    candidates = [item for item in markets if item["city"] == city and item["date"] == target_date]
    if not candidates:
        return None, "market_not_available"
    for item in candidates:
        label = str(item["bucket"])
        number = re.search(r"(\d+)", label)
        if not number:
            continue
        boundary = int(number.group(1))
        normalized = label.lower()
        if ("below" in normalized and temperature <= boundary) or (
            "higher" in normalized and temperature >= boundary) or (
            "below" not in normalized and "higher" not in normalized and temperature == boundary
        ):
            matches.append(item)
    if len(matches) == 1:
        return matches[0], None
    return None, "market_bucket_not_found" if not matches else "market_bucket_not_unique"


def minute_price_points(db: sqlite3.Connection, token: str, start_at: str, end_at: str) -> list[tuple[int, float]]:
    """Return the final two-sided midpoint for each minute in a time range."""
    if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='book_price_bars'").fetchone():
        rows = db.execute("""SELECT CAST(unixepoch(bucket_at)/60 AS INTEGER),close_mid
          FROM book_price_bars WHERE token_id=? AND interval_seconds=60
            AND bucket_at>=? AND bucket_at<? AND close_mid IS NOT NULL
          ORDER BY bucket_at""", (token, start_at, end_at)).fetchall()
        if rows:
            return [(int(bucket), float(close)) for bucket, close in rows]
    rows = db.execute("""WITH ticks AS (
        SELECT captured_at,(best_bid+best_ask)/2.0 AS mid,
          CAST(strftime('%s',captured_at) AS INTEGER)/60 AS bucket
        FROM book_snapshots WHERE token_id=? AND captured_at>=? AND captured_at<?
          AND best_bid IS NOT NULL AND best_ask IS NOT NULL
          AND NOT (best_bid<=0.001 AND best_ask>=0.999)
      ), ranked AS (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY bucket ORDER BY captured_at DESC) AS last_rank
        FROM ticks
      ) SELECT bucket,MAX(CASE WHEN last_rank=1 THEN mid END)
      FROM ranked GROUP BY bucket ORDER BY bucket""", (token, start_at, end_at)).fetchall()
    return [(int(bucket), float(close)) for bucket, close in rows]


def market_price_points(db: sqlite3.Connection, token: str, start_at: str, end_at: str) -> list[tuple[int, float]]:
    """Return final midpoints in five-minute buckets for the full market chart."""
    if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='book_price_bars'").fetchone():
        rows = db.execute("""SELECT CAST(unixepoch(bucket_at)/300 AS INTEGER),close_mid
          FROM book_price_bars WHERE token_id=? AND interval_seconds=300
            AND bucket_at>=? AND bucket_at<? AND close_mid IS NOT NULL
          ORDER BY bucket_at""", (token, start_at, end_at)).fetchall()
        if rows:
            return [(int(bucket), float(close)) for bucket, close in rows]
    rows = db.execute("""WITH ticks AS (
        SELECT captured_at,(best_bid+best_ask)/2.0 AS mid,
          CAST(strftime('%s',captured_at) AS INTEGER)/300 AS bucket
        FROM book_snapshots WHERE token_id=? AND captured_at>=? AND captured_at<?
          AND best_bid IS NOT NULL AND best_ask IS NOT NULL
          AND NOT (best_bid<=0.001 AND best_ask>=0.999)
      ), ranked AS (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY bucket ORDER BY captured_at DESC) AS last_rank
        FROM ticks
      ) SELECT bucket,MAX(CASE WHEN last_rank=1 THEN mid END)
      FROM ranked GROUP BY bucket ORDER BY bucket""", (token, start_at, end_at)).fetchall()
    return [(int(bucket), float(close)) for bucket, close in rows]


class Api:
    CACHE_LIMIT = 256
    MAX_RUNTIME_ID_LENGTH = 256
    MAX_REACTION_IDS = 100

    def __init__(self, live_quote_provider: Callable[[], dict[str, Any]] | None = None) -> None:
        self._market_tokens: list[dict] = []
        self._reaction_cache: OrderedDict[str, dict] = OrderedDict()
        self._history_cache: OrderedDict[str, list[tuple[int, float]]] = OrderedDict()
        self._update_records: dict[str, tuple[str, str, float | None, str]] = {}
        self._cache_lock = threading.RLock()
        # Optional read-only low-latency quote projection.  Database BBO rows
        # remain the fallback and audit source whenever this provider is stale.
        self._live_quote_provider = live_quote_provider

    @classmethod
    def _valid_runtime_id(cls, value: object) -> bool:
        return (
            type(value) is str
            and 1 <= len(value) <= cls.MAX_RUNTIME_ID_LENGTH
            and re.fullmatch(r"[A-Za-z0-9_.:+-]+", value) is not None
        )

    def _known_market_token(self, token: str) -> bool:
        with self._cache_lock:
            return any(str(item.get("token") or "") == token for item in self._market_tokens)

    def _cache_get(self, cache: OrderedDict, key: str) -> Any:
        with self._cache_lock:
            value = cache.get(key)
            if value is not None:
                cache.move_to_end(key)
            return value

    def _cache_put(self, cache: OrderedDict, key: str, value: Any) -> None:
        with self._cache_lock:
            cache[key] = value
            cache.move_to_end(key)
            while len(cache) > self.CACHE_LIMIT:
                cache.popitem(last=False)

    @staticmethod
    def _d0_source_specs(city: str) -> tuple[tuple[str, str, str, str], ...]:
        return (
            ("qxzx", f"weatherol_{city.lower()}", "QXZX", "formal_paper_direction"),
            ("taf", "aviationweather_taf", "TAF", "independent_observation"),
        )

    @staticmethod
    def _d0_comparison(sources: list[dict]) -> dict:
        valid = [item for item in sources
                 if item["status"] == "valid_d0" and item["temperature_c"] is not None]
        anomalous = [item["source_key"] for item in sources if item["status"] in D0_ANOMALIES]
        delta = None
        if len(valid) == 2:
            delta = abs(float(valid[0]["temperature_c"]) - float(valid[1]["temperature_c"]))
            status = "both_valid_equal" if delta == 0 else "both_valid_delta"
            severity = "neutral" if delta == 0 else "warning"
        elif len(valid) == 1:
            status = "qxzx_only_valid" if valid[0]["source_key"] == "qxzx" else "taf_only_valid"
            severity = "neutral"
        elif all(item["status"] == "waiting" for item in sources):
            status, severity = "both_waiting", "neutral"
        elif anomalous:
            status, severity = "source_anomaly", "error"
        else:
            status, severity = "no_valid_evidence", "neutral"
        labels = {
            "both_valid_equal": "两来源有效且一致", "both_valid_delta": "两来源有效但有温差",
            "qxzx_only_valid": "仅 QXZX 有效", "taf_only_valid": "仅 TAF 有效",
            "both_waiting": "两来源均等待", "source_anomaly": "来源证据异常",
            "no_valid_evidence": "无有效证据",
        }
        return {"status": status, "status_label": labels[status], "severity": severity,
                "delta_c": delta, "reason_code": status,
                "valid_sources": [item["source_key"] for item in valid],
                "anomalous_sources": anomalous}

    @staticmethod
    def _d0_source_evidence(db: sqlite3.Connection, city: str, target_date: str,
                            spec: tuple[str, str, str, str],
                            station_override: str | None = None,
                            strict_registry: bool = False) -> dict:
        source_key, source, label, role = spec
        station = station_override or D0_STATIONS[city]
        rows: list[sqlite3.Row] = []
        if _d0_has_table(db, "forecast_d0_registry"):
            rows = db.execute("""SELECT source,city,station,target_date,grid_version,status,
              forecast_high_c,forecast_bucket,source_reported_at,first_captured_at,
              capture_delay_seconds,content_hash,reason,frozen_at,latest_checked_at
              FROM forecast_d0_registry
              WHERE source=? AND city=? AND station=? AND target_date=?
              ORDER BY latest_checked_at DESC, grid_version DESC""",
              (source, city, station, target_date)).fetchall()
        if strict_registry:
            selected = _select_strict_registry(rows)
            rows = [selected] if selected is not None else []
        # The policy's highest-priority database row must be wholly valid.  A
        # damaged newest row is not allowed to silently revive an older fact.
        complete = next((row for row in rows if row["status"] == "valid_d0"
                         and row["forecast_high_c"] is not None and row["frozen_at"]), None)
        missing_value = next((row for row in rows if row["status"] in {
            "valid_d0", "missing_target_value"
        } and row["forecast_high_c"] is None), None)
        selected_by_status = {
            status: next((row for row in rows if row["status"] == status), None)
            for status in D0_STATUS_PRIORITY
        }
        selected_by_status["missing_target_value"] = missing_value
        row = complete or next((selected_by_status[status] for status in D0_STATUS_PRIORITY
                                if selected_by_status[status] is not None), None)
        if row is None:
            row = next((candidate for candidate in rows
                        if candidate["status"] not in {"publication_overdue", "waiting"}), None)
        if row is None and rows:
            row = rows[0]
        registry_status = row["status"] if row else None
        limitations: list[str] = []
        if complete is not None:
            status, reason_code = "valid_d0", "first_complete_d0_frozen"
        elif missing_value is not None and row is missing_value:
            status = "missing_target_value"
            reason_code = "taf_tx_missing" if source_key == "taf" else "target_temperature_missing"
        elif row is not None and registry_status == "publication_overdue":
            status = "waiting"
            reason_code = ("taf_schedule_not_frozen" if source_key == "taf"
                           else "qxzx_window_not_enabled_v1")
            limitations.append("publication_overdue_ignored_v1")
        elif row is not None and registry_status == "waiting":
            status = "waiting"
            reason_code = ("taf_schedule_not_frozen" if source_key == "taf"
                           else "qxzx_window_not_enabled_v1")
        elif row is not None and registry_status in D0_STATUS_META:
            status = str(registry_status)
            reason_code = D0_REASON_CODES.get(status, status)
        else:
            # Frozen v1 Q-C/T-A policy: without a more specific fact both
            # sources wait, and overdue is deliberately unreachable.
            status = "waiting"
            reason_code = ("taf_schedule_not_frozen" if source_key == "taf"
                           else "qxzx_window_not_enabled_v1")
        status_label, severity = D0_STATUS_META[status]
        reason_text = str(row["reason"]) if row is not None and row["reason"] else status_label
        has_version = False
        if row is not None and _d0_has_table(db, "forecast_versions"):
            has_version = db.execute("""SELECT 1 FROM forecast_versions
              WHERE source=? AND city=? AND station=? AND target_date=? LIMIT 1""",
              (source, city, station, target_date)).fetchone() is not None
        if status in {"not_retained", "not_observed", "policy_undetermined"}:
            retention_state = status
        elif row is None:
            retention_state = "policy_undetermined"
            limitations.extend(["target_date_attribution_unavailable",
                                "cannot distinguish not_observed from not_retained"])
        elif has_version:
            retention_state = "detail_available"
        else:
            retention_state = "summary_only"
            limitations.append("detail availability cannot distinguish absent from retention cleanup")
        limitations.append("fetch_audit_target_date_unavailable")
        evidence_status = (
            "valid_d0" if complete is not None else
            "policy_undetermined" if row is None or registry_status in {
                "waiting", "publication_overdue"
            } else status
        )
        return {
            "source_key": source_key, "source": source, "source_label": label,
            "source_role": role,
            "city": city, "station": station, "target_date": target_date,
            "status": status, "policy_status": status, "evidence_status": evidence_status,
            "fetch_health": "not_attributed", "status_label": status_label,
            "severity": severity,
            "reason_code": reason_code, "reason_text": reason_text,
            "temperature_c": (float(row["forecast_high_c"])
                              if complete is not None else None),
            "forecast_bucket": (row["forecast_bucket"] if complete is not None else None),
            "source_reported_at": (_forecast_china_time(row["_source_reported_at"])
                                   if strict_registry and row else _d0_china_iso(row["source_reported_at"] if row else None)),
            "first_captured_at": (_forecast_china_time(row["_first_captured_at"])
                                  if strict_registry and row else _d0_china_iso(row["first_captured_at"] if row else None)),
            "capture_delay_seconds": row["capture_delay_seconds"] if row else None,
            "frozen_at": (_forecast_china_time(row["_frozen_at"])
                          if strict_registry and row else _d0_china_iso(row["frozen_at"] if row else None)),
            "latest_checked_at": (_forecast_china_time(row["_latest_checked_at"])
                                  if strict_registry and row else _d0_china_iso(row["latest_checked_at"] if row else None)),
            "grid_version": row["grid_version"] if row else None,
            "content_hash": row["content_hash"] if row else None,
            "expected_window_start": None, "expected_window_end": None,
            "grace_deadline": None, "evaluation_at": _d0_now_iso(),
            "last_attempt_at": None, "last_attempt_status": "not_attributed",
            "last_success_at": None, "expected_attempt_seen": "unknown",
            "policy_version": D0_POLICY_VERSION,
            "fetch": {"status": "not_attributed", "requested_at": None,
                      "received_at": None,
                      "detail": "fetch audit lacks target_date; no heuristic attribution"},
            "retention_state": retention_state,
            "limitations": limitations,
            "provenance": {
                "kind": "forecast_d0_registry" if row else "policy_default",
                "registry_status": registry_status,
                "immutable_frozen": complete is not None,
                "detail_availability": retention_state,
                "policy_version": D0_POLICY_VERSION,
                "source_table": "forecast_d0_registry" if row else None,
                "registry_statuses": [candidate["status"] for candidate in rows],
                "raw_reason": row["reason"] if row else None,
                "read_only": True,
            },
        }

    def _d0_panel_from_db(self, db: sqlite3.Connection, target_date: str) -> dict:
        cities = []
        for city in CITY_ORDER:
            sources = [self._d0_source_evidence(db, city, target_date, spec)
                       for spec in self._d0_source_specs(city)]
            cities.append({"city": city, "city_label": CN[city],
                           "station": D0_STATIONS[city], "sources": sources,
                           "comparison": self._d0_comparison(sources)})
        comparisons = [item["comparison"] for item in cities]
        summary = {
            "city_count": len(cities),
            "qxzx_valid_city_count": sum(row["sources"][0]["status"] == "valid_d0" for row in cities),
            "taf_valid_city_count": sum(row["sources"][1]["status"] == "valid_d0" for row in cities),
            "both_valid_city_count": sum(item["status"] in {"both_valid_equal", "both_valid_delta"}
                                         for item in comparisons),
            "different_city_count": sum(item["status"] == "both_valid_delta" for item in comparisons),
            "max_delta_c": max((item["delta_c"] for item in comparisons
                                if item["delta_c"] is not None), default=None),
            "anomalous_city_count": sum(item["status"] == "source_anomaly" for item in comparisons),
            "waiting_city_count": sum(item["status"] == "both_waiting" for item in comparisons),
        }
        return {"schema": D0_SCHEMA, "ok": True, "target_date": target_date,
                "timezone": "Asia/Shanghai", "page_updated_at": _d0_now_iso(),
                "retention": _d0_retention(),
                "provenance": {"read_only": True, "database": "research",
                               "policy_version": D0_POLICY_VERSION,
                               "target_date_bound": True,
                               "source_tables": ["forecast_d0_registry"]},
                "summary": summary, "cities": cities}

    def d0_evidence_panel(self, target_date: str) -> dict:
        if not _d0_valid_date(target_date):
            return _d0_error("invalid_target_date", "target_date must be a real YYYY-MM-DD date",
                             "target_date")
        db = None
        try:
            db = sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=3)
            db.row_factory = sqlite3.Row
            if not _d0_has_table(db, "forecast_d0_registry"):
                return _d0_error("data_contract_unavailable",
                                 "forecast_d0_registry is unavailable", None)
            return self._d0_panel_from_db(db, target_date)
        except sqlite3.OperationalError:
            return _d0_error("data_temporarily_unavailable", PUBLIC_ERROR_MESSAGES["data_temporarily_unavailable"], None, True)
        except sqlite3.Error:
            return _d0_error("data_contract_unavailable", PUBLIC_ERROR_MESSAGES["data_contract_unavailable"], None)
        except Exception:
            return _d0_error("data_contract_unavailable", PUBLIC_ERROR_MESSAGES["data_contract_unavailable"], None)
        finally:
            if db is not None:
                db.close()

    @staticmethod
    def _d0_versions(db: sqlite3.Connection, city: str, target_date: str) -> list[dict]:
        if not _d0_has_table(db, "forecast_versions"):
            return []
        rows = db.execute("""SELECT version_id,source,city,station,target_date,
          forecast_high_c,content_hash,first_seen_at,last_seen_at,source_display_time,is_change
          FROM forecast_versions WHERE city=? AND target_date=?
          ORDER BY source,first_seen_at,version_id""", (city, target_date)).fetchall()
        return [{"version_id": row["version_id"], "source": row["source"],
                 "city": row["city"], "station": row["station"],
                 "target_date": row["target_date"],
                 "temperature_c": row["forecast_high_c"],
                 "content_hash": row["content_hash"],
                 "first_seen_at": _d0_china_iso(row["first_seen_at"]),
                 "last_seen_at": _d0_china_iso(row["last_seen_at"]),
                 "source_reported_at": _d0_china_iso(row["source_display_time"]),
                 "is_change": bool(row["is_change"])} for row in rows]

    @staticmethod
    def _d0_resolution(db: sqlite3.Connection, city: str, target_date: str,
                       sources: list[dict]) -> dict:
        empty = {"status": "not_resolved", "market_id": None, "bucket_label": None,
                 "yes_resolved": None, "resolved_at": None,
                 "resolution_source": None, "forecast_bucket_delta_c": None,
                 "delta_kind": "settlement_minus_qxzx_frozen_bucket",
                 "quality_code": None, "limitations": []}
        if not _d0_has_table(db, "market_resolutions"):
            return empty
        rows = db.execute("""SELECT market_id,bucket_label,yes_resolved,resolved_at,resolution_source
          FROM market_resolutions WHERE city=? AND target_date=?
          ORDER BY resolved_at,market_id""", (city, target_date)).fetchall()
        if not rows:
            return empty
        yes_rows = [row for row in rows if row["yes_resolved"] == 1]
        if len(yes_rows) != 1:
            quality_code = ("no_yes_resolution" if not yes_rows
                            else "conflicting_yes_resolutions")
            return {**empty, "status": "unavailable", "quality_code": quality_code,
                    "limitations": [quality_code], "observed_bucket_count": len(rows),
                    "yes_bucket_count": len(yes_rows)}
        row = yes_rows[0]
        qxzx = sources[0]
        numbers = re.findall(r"-?\d+", str(row["bucket_label"] or ""))
        delta = None
        limitations = []
        if len(numbers) == 1 and qxzx["forecast_bucket"] is not None:
            delta = int(numbers[0]) - int(qxzx["forecast_bucket"])
        elif len(numbers) != 1:
            limitations.append("unparseable_bucket_label")
        return {"status": "resolved",
                "market_id": row["market_id"], "bucket_label": row["bucket_label"],
                "yes_resolved": True,
                "resolved_at": _d0_china_iso(row["resolved_at"]),
                "resolution_source": row["resolution_source"],
                "forecast_bucket_delta_c": delta,
                "delta_kind": "settlement_minus_qxzx_frozen_bucket",
                "quality_code": None, "limitations": limitations,
                "observed_bucket_count": len(rows), "yes_bucket_count": 1}

    @staticmethod
    def _d0_research(db: sqlite3.Connection) -> dict:
        # BE-05 has not frozen a stable city+target_date artifact contract.
        # FE-00 therefore exposes availability only and never synthesizes a
        # probability, path label, candidate mapping, or trading conclusion.
        research_tables = [row[0] for row in db.execute("""SELECT name FROM sqlite_master
          WHERE type='table' AND (name LIKE 'wp3_%' OR name LIKE 'd0_research%')
          ORDER BY name""")]
        availability = "unsupported_version" if research_tables else "not_yet_known"
        return {
            "availability": availability,
            "availability_label": ("现有研究产物版本不受支持" if research_tables
                                   else "尚无受支持的点时研究产物"),
            "reasons": (["research tables exist but no supported city+target_date DTO version is frozen"]
                        if research_tables else
                        ["supported research artifact contract is not frozen"]),
            "provenance": {"schema_version": None, "snapshot_id": None,
                           "factor_version": None, "path_label_version": None,
                           "stratum_version": None, "information_cutoff": None,
                           "generated_at": None, "source_tables": research_tables,
                           "read_only": True},
            "point_in_time": {"evaluation_at": None, "t_info": None,
                              "not_before_basis": [], "target_end": None},
            "snapshot": {"complete": False, "ready_for_future_stratification": False,
                         "ready_for_probability": False,
                         "probability_block_reason": "unsupported_research_contract",
                         "block_reasons": ["no supported point-in-time artifact"]},
            "historical_deviations": [], "history_window": None,
            "market_evidence": None, "model_output": None,
        }

    def d0_evidence_detail(self, city: str, target_date: str) -> dict:
        if city not in CITY_ORDER:
            return _d0_error("unsupported_city", "city is not in the fixed five-city scope", "city")
        if not _d0_valid_date(target_date):
            return _d0_error("invalid_target_date", "target_date must be a real YYYY-MM-DD date",
                             "target_date")
        db = None
        try:
            db = sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=3)
            db.row_factory = sqlite3.Row
            if not _d0_has_table(db, "forecast_d0_registry"):
                return _d0_error("data_contract_unavailable",
                                 "forecast_d0_registry is unavailable", None)
            sources = [self._d0_source_evidence(db, city, target_date, spec)
                       for spec in self._d0_source_specs(city)]
            versions = self._d0_versions(db, city, target_date)
            resolution = self._d0_resolution(db, city, target_date, sources)
            research = self._d0_research(db)
            retention_states = {item["retention_state"] for item in sources}
            if versions:
                detail_availability = "available"
            elif "summary_only" in retention_states:
                detail_availability = "summary_only"
            else:
                detail_availability = "policy_undetermined"
            return {
                "schema": D0_SCHEMA, "ok": True, "city": city,
                "city_label": CN[city], "station": D0_STATIONS[city],
                "target_date": target_date, "timezone": "Asia/Shanghai",
                "page_updated_at": _d0_now_iso(), "retention": _d0_retention(),
                "availability": {"detail": detail_availability,
                                 "fetch_timeline": "not_attributed",
                                 "raw_evidence": "hash_only"},
                "provenance": {"read_only": True, "database": "research",
                               "policy_version": D0_POLICY_VERSION,
                               "target_date_bound": True,
                               "source_tables": ["forecast_d0_registry",
                                                 "forecast_versions", "market_resolutions"]},
                "sources": sources, "comparison": self._d0_comparison(sources),
                "versions": versions, "fetch_timeline": [],
                "raw_evidence": [{"source_key": item["source_key"],
                                  "content_hash": item["content_hash"],
                                  "availability": "hash_only" if item["content_hash"] else "not_retained"}
                                 for item in sources],
                "resolution": resolution,
                "validation": {"kind": "mechanical_fact_delta",
                               "forecast_bucket_delta_c": resolution["forecast_bucket_delta_c"],
                               "model_conclusion": None},
                "research": research,
            }
        except sqlite3.OperationalError:
            return _d0_error("data_temporarily_unavailable", PUBLIC_ERROR_MESSAGES["data_temporarily_unavailable"], None, True)
        except sqlite3.Error:
            return _d0_error("data_contract_unavailable", PUBLIC_ERROR_MESSAGES["data_contract_unavailable"], None)
        except Exception:
            return _d0_error("data_contract_unavailable", PUBLIC_ERROR_MESSAGES["data_contract_unavailable"], None)
        finally:
            if db is not None:
                db.close()

    @staticmethod
    def _d0_error_v2(code: str, message: str, field: str | None,
                      retryable: bool = False) -> dict:
        result = _d0_error(code, message, field, retryable)
        result["schema"] = D0_SCHEMA_V2
        return result

    @staticmethod
    def _d0_unconfigured_qxzx(meta: dict, target_date: str) -> dict:
        role = ("formal_paper_direction" if meta["city_scope"] == "formal"
                else "research_observation")
        return {
            "source_key": "qxzx", "source": None, "source_label": "QXZX",
            "source_role": role, "city": meta["city"], "station": meta["station"],
            "target_date": target_date, "city_scope": meta["city_scope"],
            "status": "policy_undetermined", "policy_status": "policy_undetermined",
            "evidence_status": "policy_undetermined", "retention_state": "policy_undetermined",
            "fetch_health": "not_configured", "status_label": "\u5f53\u524d\u653f\u7b56\u4e0d\u8db3\u4ee5\u5224\u5b9a",
            "severity": "warning", "reason_code": "qxzx_source_not_configured",
            "reason_text": "QXZX \u673a\u573a\u6765\u6e90\u5c1a\u672a\u6838\u9a8c\u914d\u7f6e",
            "temperature_c": None, "forecast_bucket": None,
            "source_reported_at": None, "first_captured_at": None,
            "capture_delay_seconds": None, "frozen_at": None,
            "latest_checked_at": None, "grid_version": None, "content_hash": None,
            "expected_window_start": None, "expected_window_end": None,
            "grace_deadline": None, "evaluation_at": _d0_now_iso(),
            "last_attempt_at": None, "last_attempt_status": "not_configured",
            "last_success_at": None, "expected_attempt_seen": "unknown",
            "policy_version": D0_POLICY_VERSION,
            "fetch": {"status": "not_configured", "requested_at": None,
                      "received_at": None, "detail": "QXZX source is not configured"},
            "limitations": ["source_not_configured", "qxzx_airport_aid_unverified"],
            "provenance": {
                "kind": "source_configuration", "configured": False,
                "registry_status": None, "immutable_frozen": False,
                "detail_availability": "policy_undetermined",
                "policy_version": D0_POLICY_VERSION, "source_table": None,
                "registry_statuses": [], "raw_reason": None, "read_only": True,
            },
        }

    @staticmethod
    def _d0_normalize_source_v2(source: dict) -> dict:
        if source.get("provenance", {}).get("registry_status") != "publication_overdue":
            return source
        return {**source, "reason_text": source["status_label"]}

    def _d0_sources_v2(self, db: sqlite3.Connection, meta: dict,
                        target_date: str) -> list[dict]:
        if meta["qxzx_source"] is None:
            qxzx = self._d0_unconfigured_qxzx(meta, target_date)
        else:
            qxzx_role = ("formal_paper_direction" if meta["city_scope"] == "formal"
                         else "research_observation")
            qxzx = self._d0_source_evidence(
                db, meta["city"], target_date,
                ("qxzx", meta["qxzx_source"], "QXZX", qxzx_role),
                station_override=meta["station"], strict_registry=True,
            )
            qxzx = self._d0_normalize_source_v2(qxzx)
            qxzx = {**qxzx, "city_scope": meta["city_scope"]}
            qxzx["provenance"] = {**qxzx["provenance"], "configured": True}
        taf = self._d0_source_evidence(
            db, meta["city"], target_date,
            ("taf", "aviationweather_taf", "TAF", "independent_observation"),
            station_override=meta["station"], strict_registry=True,
        )
        taf = self._d0_normalize_source_v2(taf)
        taf = {**taf, "city_scope": meta["city_scope"]}
        taf["provenance"] = {**taf["provenance"], "configured": True}
        return [qxzx, taf]

    def _d0_panel_from_db_v2(self, db: sqlite3.Connection, target_date: str) -> dict:
        cities = []
        for meta in _d0_cities_for_date(target_date):
            sources = self._d0_sources_v2(db, meta, target_date)
            cities.append({
                "city": meta["city"], "city_label": meta["city_label"],
                "station": meta["station"], "city_scope": meta["city_scope"],
                "target_date": target_date, "sources": sources,
                "comparison": self._d0_comparison(sources),
            })
        comparisons = [item["comparison"] for item in cities]
        summary = {
            "city_count": len(cities),
            "formal_city_count": sum(item["city_scope"] == "formal" for item in cities),
            "research_only_city_count": sum(item["city_scope"] == "research_only" for item in cities),
            "qxzx_valid_city_count": sum(row["sources"][0]["status"] == "valid_d0" for row in cities),
            "taf_valid_city_count": sum(row["sources"][1]["status"] == "valid_d0" for row in cities),
            "both_valid_city_count": sum(item["status"] in {"both_valid_equal", "both_valid_delta"}
                                         for item in comparisons),
            "different_city_count": sum(item["status"] == "both_valid_delta" for item in comparisons),
            "max_delta_c": max((item["delta_c"] for item in comparisons
                                if item["delta_c"] is not None), default=None),
            "anomalous_city_count": sum(item["status"] == "source_anomaly" for item in comparisons),
            "waiting_city_count": sum(item["status"] == "both_waiting" for item in comparisons),
        }
        return {
            "schema": D0_SCHEMA_V2, "ok": True, "target_date": target_date,
            "timezone": "Asia/Shanghai", "page_updated_at": _d0_now_iso(),
            "retention": _d0_retention(),
            "provenance": {"read_only": True, "database": "research",
                           "policy_version": D0_POLICY_VERSION,
                           "target_date_bound": True,
                           "source_tables": ["forecast_d0_registry"]},
            "summary": summary, "cities": cities,
        }

    def d0_evidence_panel_v2(self, target_date: str) -> dict:
        if not _d0_valid_date(target_date):
            return self._d0_error_v2(
                "invalid_target_date", "target_date must be a real YYYY-MM-DD date",
                "target_date",
            )
        db = None
        try:
            db = sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=3)
            db.row_factory = sqlite3.Row
            if not _d0_has_table(db, "forecast_d0_registry"):
                return self._d0_error_v2(
                    "data_contract_unavailable", "forecast_d0_registry is unavailable", None,
                )
            return self._d0_panel_from_db_v2(db, target_date)
        except sqlite3.OperationalError:
            return self._d0_error_v2("data_temporarily_unavailable", PUBLIC_ERROR_MESSAGES["data_temporarily_unavailable"], None, True)
        except sqlite3.Error:
            return self._d0_error_v2("data_contract_unavailable", PUBLIC_ERROR_MESSAGES["data_contract_unavailable"], None)
        except Exception:
            return self._d0_error_v2("data_contract_unavailable", PUBLIC_ERROR_MESSAGES["data_contract_unavailable"], None)
        finally:
            if db is not None:
                db.close()

    @staticmethod
    def _d0_versions_v2(db: sqlite3.Connection, meta: dict,
                         target_date: str) -> list[dict]:
        if not _d0_has_table(db, "forecast_versions"):
            return []
        sources = ["aviationweather_taf"]
        if meta["qxzx_source"] is not None:
            sources.append(meta["qxzx_source"])
        placeholders = ",".join("?" for _ in sources)
        rows = db.execute(f"""SELECT version_id,source,city,station,target_date,
          forecast_high_c,content_hash,first_seen_at,last_seen_at,source_display_time,is_change
          FROM forecast_versions WHERE city=? AND station=? AND target_date=?
            AND source IN ({placeholders})
          ORDER BY source,first_seen_at,version_id""",
          (meta["city"], meta["station"], target_date, *sources)).fetchall()
        valid_rows = [item for item in (_d0_version_row(row) for row in rows) if item is not None]
        valid_rows.sort(key=lambda row: (row["source"], row["_first_seen_at"], row["version_id"]))
        return [{"version_id": row["version_id"], "source": row["source"],
                 "city": row["city"], "station": row["station"],
                 "target_date": row["target_date"],
                 "temperature_c": row["forecast_high_c"],
                 "content_hash": row["content_hash"],
                 "first_seen_at": _forecast_china_time(row["_first_seen_at"]),
                 "last_seen_at": _forecast_china_time(row["_last_seen_at"]),
                 "source_reported_at": _forecast_china_time(row["_source_display_time"]),
                 "is_change": row["is_change"] == 1} for row in valid_rows]

    @staticmethod
    def _d0_research_v2(db: sqlite3.Connection) -> dict:
        research = Api._d0_research(db)
        return {key: research[key] for key in ("availability", "reasons", "provenance")}

    def d0_evidence_detail_v2(self, city: str, target_date: str) -> dict:
        if target_date >= CITY_RETIREMENT_DATES.get(city, "9999-12-31"):
            return self._d0_error_v2(
                "retired_city", "city is permanently retired from the active scope", "city",
            )
        meta = D0_V2_CITY_BY_NAME.get(city)
        if meta is None:
            return self._d0_error_v2(
                "unsupported_city", "city is not in the fixed ten-city scope", "city",
            )
        if not _d0_valid_date(target_date):
            return self._d0_error_v2(
                "invalid_target_date", "target_date must be a real YYYY-MM-DD date",
                "target_date",
            )
        db = None
        try:
            db = sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=3)
            db.row_factory = sqlite3.Row
            if not _d0_has_table(db, "forecast_d0_registry"):
                return self._d0_error_v2(
                    "data_contract_unavailable", "forecast_d0_registry is unavailable", None,
                )
            sources = self._d0_sources_v2(db, meta, target_date)
            versions = self._d0_versions_v2(db, meta, target_date)
            resolution = self._d0_resolution(db, city, target_date, sources)
            research = self._d0_research_v2(db)
            retention_states = {item["retention_state"] for item in sources}
            if versions:
                detail_availability = "available"
            elif "summary_only" in retention_states:
                detail_availability = "summary_only"
            else:
                detail_availability = "policy_undetermined"
            raw_evidence = []
            for item in sources:
                if not item["provenance"].get("configured", True):
                    availability = "not_configured"
                elif item["content_hash"]:
                    availability = "hash_only"
                else:
                    availability = item["retention_state"]
                raw_evidence.append({
                    "source_key": item["source_key"],
                    "content_hash": item["content_hash"],
                    "availability": availability,
                })
            if any(item["content_hash"] for item in sources):
                raw_evidence_availability = "hash_only"
            elif all(item["availability"] == "not_configured" for item in raw_evidence):
                raw_evidence_availability = "not_configured"
            else:
                raw_evidence_availability = "policy_undetermined"
            return {
                "schema": D0_SCHEMA_V2, "ok": True, "city": city,
                "city_label": meta["city_label"], "station": meta["station"],
                "city_scope": meta["city_scope"], "target_date": target_date,
                "timezone": "Asia/Shanghai", "page_updated_at": _d0_now_iso(),
                "retention": _d0_retention(),
                "availability": {"detail": detail_availability,
                                 "fetch_timeline": "not_attributed",
                                 "raw_evidence": raw_evidence_availability},
                "provenance": {"read_only": True, "database": "research",
                               "policy_version": D0_POLICY_VERSION,
                               "target_date_bound": True,
                               "source_tables": ["forecast_d0_registry",
                                                 "forecast_versions", "market_resolutions"]},
                "sources": sources, "comparison": self._d0_comparison(sources),
                "versions": versions, "fetch_timeline": [],
                "raw_evidence": raw_evidence, "resolution": resolution,
                "validation": {"kind": "mechanical_fact_delta",
                               "forecast_bucket_delta_c": resolution["forecast_bucket_delta_c"],
                               "model_conclusion": None},
                "research": research,
            }
        except sqlite3.OperationalError:
            return self._d0_error_v2("data_temporarily_unavailable", PUBLIC_ERROR_MESSAGES["data_temporarily_unavailable"], None, True)
        except sqlite3.Error:
            return self._d0_error_v2("data_contract_unavailable", PUBLIC_ERROR_MESSAGES["data_contract_unavailable"], None)
        except Exception:
            return self._d0_error_v2("data_contract_unavailable", PUBLIC_ERROR_MESSAGES["data_contract_unavailable"], None)
        finally:
            if db is not None:
                db.close()

    def set_live_quote_provider(self, provider: Callable[[], dict[str, Any]] | None) -> None:
        self._live_quote_provider = provider

    def apply_live_quotes(self, frame: dict) -> dict:
        """Overlay a healthy local BBO projection onto an existing DB frame.

        This intentionally performs no database access.  The caller refreshes
        the full frame periodically; if the local hub is stale, that frame is
        left untouched and its SQLite-derived quote values remain visible.
        """
        if not self._live_quote_provider or not isinstance(frame, dict):
            return frame
        try:
            live = self._live_quote_provider()
        except Exception:
            return frame
        if not isinstance(live, dict):
            return frame
        quotes = live.get("quotes", {}) if live.get("state") == "healthy" else {}
        if quotes:
            for item in frame.get("markets", []):
                quote = quotes.get(item.get("token"))
                if not quote:
                    continue
                stamp = quote.get("captured_at")
                item.update(bid=quote.get("bid"), ask=quote.get("ask"),
                            bid_size=quote.get("bid_size"), ask_size=quote.get("ask_size"),
                            book_time=china_time(stamp), quote_captured_at=stamp,
                            quote_health=freshness(stamp, 20),
                            exchange_at=quote.get("exchange_at"),
                            received_at=quote.get("received_at"),
                            published_at=quote.get("published_at"),
                            source_to_receive_ms=quote.get("source_to_receive_ms"),
                            source_to_hub_ms=quote.get("source_to_hub_ms"),
                            quote_sequence=quote.get("sequence"),
                            quote_stream_id=quote.get("stream_id"),
                            levels=quote.get("levels") or [])
        latest_quote = max(
            quotes.values(),
            key=lambda value: int(value.get("sequence") or 0),
            default={},
        )
        services = frame.setdefault("services", {})
        services["state_hub"] = {"updated_at": None,
            "detail": f"local BBO projection · {len(quotes)} tokens",
            "state": live.get("state", "offline"), "age_seconds": live.get("age_seconds"),
            "upstream_connected": live.get("upstream_connected"),
            "upstream_detail": live.get("upstream_detail"),
            "latency_ms": latest_quote.get("source_to_hub_ms")}
        return frame

    def health_snapshot(self) -> dict:
        """Read only service freshness for the header; never build a full UI frame."""
        db = quote_db = None
        try:
            db = sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=3)
            quote_db = sqlite3.connect(f"file:{REALTIME_DB}?mode=ro", uri=True, timeout=3)
            services = {}
            for service, updated_at, detail in db.execute("SELECT service,updated_at,detail FROM service_heartbeats"):
                health = freshness(updated_at, 480 if service == "collector" else 90)
                if service == "realtime_stream" and any(word in str(detail).lower()
                        for word in ("connecting", "reconnecting", "waiting", "offline", "writer=error")):
                    health["state"] = "recovering"
                services[service] = {"updated_at": china_time(updated_at), "detail": detail, **health}
            for service, updated_at, detail in quote_db.execute("SELECT service,updated_at,detail FROM service_heartbeats"):
                health = freshness(updated_at, 90)
                if service == "realtime_stream" and any(word in str(detail).lower()
                        for word in ("connecting", "reconnecting", "waiting", "offline", "writer=error")):
                    health["state"] = "recovering"
                services[service] = {"updated_at": china_time(updated_at), "detail": detail, **health}
            if self._live_quote_provider:
                try:
                    live = self._live_quote_provider()
                except Exception:
                    live = {}
                if isinstance(live, dict):
                    live_quotes = live.get("quotes", {})
                    latest_quote = max(
                        live_quotes.values(),
                        key=lambda value: int(value.get("sequence") or 0),
                        default={},
                    ) if isinstance(live_quotes, dict) else {}
                    services["state_hub"] = {"updated_at": None,
                        "detail": f"local BBO projection · {len(live_quotes)} tokens",
                        "state": live.get("state", "offline"), "age_seconds": live.get("age_seconds"),
                        "upstream_connected": live.get("upstream_connected"),
                        "upstream_detail": live.get("upstream_detail"),
                        "latency_ms": latest_quote.get("source_to_hub_ms")}
            return {"now": china_now().strftime("%Y-%m-%d %H:%M:%S"), "services": services}
        except sqlite3.Error:
            return {"now": china_now().strftime("%Y-%m-%d %H:%M:%S"), "services": {}, "error": "dashboard_health_unavailable"}
        finally:
            if quote_db is not None:
                quote_db.close()
            if db is not None:
                db.close()

    @staticmethod
    def _metar_actual_placeholders(detail: str) -> list[dict[str, Any]]:
        return [{
            "city": spec["city"], "city_cn": spec["city_label"],
            "station": spec["station"],
            "decision_scope": spec["decision_scope"],
            "scope": spec["decision_scope"],
            "state": "unavailable", "detail": detail, "available": False,
            "temperature_c": None, "report_time": None, "read_time": None,
            "age_minutes": None, "report_type": None, "conditions": None,
            "wind_mps": None, "visibility_km": None, "today_high": None,
            "points": [],
        } for spec in _metar_cities_now()]

    @staticmethod
    def _metar_iso_time(value: Any) -> datetime | None:
        if type(value) is not str or not value or value != value.strip():
            return None
        try:
            stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if stamp.tzinfo is None or stamp.utcoffset() is None:
                return None
            stamp_utc = stamp.astimezone(UTC)
            stamp_utc.astimezone(CHINA_TZ)
            return stamp_utc
        except (ValueError, TypeError, OverflowError, OSError):
            return None

    @staticmethod
    def _metar_china_time(stamp_utc: datetime | None) -> str | None:
        if stamp_utc is None:
            return None
        try:
            return stamp_utc.astimezone(CHINA_TZ).strftime("%Y-%m-%d %H:%M:%S")
        except (ValueError, TypeError, OverflowError, OSError):
            return None

    @staticmethod
    def _metar_number(value: Any, *, nullable: bool, nonnegative: bool = False) -> bool:
        if value is None:
            return nullable
        if isinstance(value, bool) or type(value) not in {int, float}:
            return False
        return math.isfinite(value) and (not nonnegative or value >= 0)

    @staticmethod
    def _metar_status_valid(item: dict[str, Any], spec: dict[str, str]) -> bool:
        for field in ("station", "city", "decision_scope", "state"):
            value = item.get(field)
            if type(value) is not str or not value or value != value.strip():
                return False
        return (item["station"] == spec["station"]
                and item["city"] == spec["city"]
                and item["decision_scope"] == spec["decision_scope"]
                and item["state"] in {"healthy", "delayed", "unavailable"}
                and (item.get("detail") is None or type(item.get("detail")) is str))

    @classmethod
    def _metar_observation_valid(cls, item: dict[str, Any], spec: dict[str, str]) -> bool:
        for field in ("station", "city", "decision_scope"):
            value = item.get(field)
            if type(value) is not str or not value or value != value.strip():
                return False
        return (item["station"] == spec["station"]
                and item["city"] == spec["city"]
                and item["decision_scope"] == spec["decision_scope"]
                and cls._metar_iso_time(item.get("report_time")) is not None
                and cls._metar_iso_time(item.get("received_at")) is not None
                and cls._metar_number(item.get("temperature_c"), nullable=False)
                and cls._metar_number(item.get("wind_mps"), nullable=True, nonnegative=True)
                and cls._metar_number(item.get("visibility_km"), nullable=True, nonnegative=True)
                and item.get("report_type") in {"METAR", "SPECI"}
                and type(item.get("report_type")) is str
                and (item.get("conditions") is None or type(item.get("conditions")) is str))

    def actual_snapshot(self) -> list[dict[str, Any]]:
        """Return the independent METAR view; never fall back to stale CMA data."""
        if not OBSERVATIONS_DB.exists():
            return self._metar_actual_placeholders("metar_database_unavailable")
        db = None
        try:
            db = sqlite3.connect(f"file:{OBSERVATIONS_DB}?mode=ro", uri=True, timeout=3)
            db.row_factory = sqlite3.Row
            status_rows = db.execute("""SELECT station,city,decision_scope,state,detail
              FROM metar_live_status""").fetchall()
            # The dashboard needs only today's China-day path, not the raw
            # archive. This keeps the actuals patch small and bounded.
            start = china_now().replace(hour=0, minute=0, second=0, microsecond=0).astimezone(UTC).timestamp()
            end = start + 86400
            rows = db.execute("""SELECT station,city,decision_scope,report_time,received_at,
              report_type,temperature_c,wind_mps,visibility_km,conditions
              FROM metar_observations
              WHERE (unixepoch(report_time)>=? AND unixepoch(report_time)<?)
                 OR (unixepoch(received_at)>=? AND unixepoch(received_at)<?)""",
              (start, end, start, end)).fetchall()
            statuses: dict[str, dict[str, Any]] = {}
            invalid_records: set[str] = set()
            for row in status_rows:
                item = dict(row)
                station = item.get("station")
                spec = METAR_ACTUAL_BY_STATION.get(station) if type(station) is str else None
                if spec is None:
                    stripped = str(station).strip() if isinstance(station, str) else None
                    if stripped in METAR_ACTUAL_BY_STATION:
                        invalid_records.add(stripped)
                    continue
                if station in statuses or not self._metar_status_valid(item, spec):
                    invalid_records.add(station)
                    continue
                statuses[station] = item
            selected: dict[str, dict[str, Any]] = {}
            points: dict[str, list[dict[str, Any]]] = {}
            seen_report: set[tuple[str, str]] = set()
            valid_rows: list[tuple[datetime, dict[str, Any]]] = []
            for row in rows:
                item = dict(row)
                station = item.get("station")
                spec = METAR_ACTUAL_BY_STATION.get(station) if type(station) is str else None
                if spec is None:
                    stripped = str(station).strip() if isinstance(station, str) else None
                    if stripped in METAR_ACTUAL_BY_STATION:
                        invalid_records.add(stripped)
                    continue
                if not self._metar_observation_valid(item, spec):
                    invalid_records.add(station)
                    continue
                report_stamp = self._metar_iso_time(item["report_time"])
                item["_report_utc"] = report_stamp
                item["_received_utc"] = self._metar_iso_time(item["received_at"])
                if not start <= report_stamp.timestamp() < end:
                    continue
                valid_rows.append((report_stamp, item))
            valid_rows.sort(key=lambda pair: (pair[1]["station"], pair[0],
                                              pair[1]["_received_utc"]), reverse=True)
            for _report_stamp, item in valid_rows:
                station = item["station"]
                selected.setdefault(station, item)
                key = (station, item["report_time"])
                if key in seen_report:
                    continue
                seen_report.add(key)
                stamp = self._metar_china_time(_report_stamp)
                points.setdefault(station, []).append({"t": stamp[11:16] if stamp else "—",
                                                       "v": item["temperature_c"]})
            result = []
            for spec in _metar_cities_now():
                station = spec["station"]
                city = spec["city"]
                status = statuses.get(station, {})
                latest = selected.get(station)
                if station in invalid_records:
                    latest = None
                    status = {}
                record_ok = station not in invalid_records
                source_state = status.get("state", "unavailable") if record_ok else "unavailable"
                status_allows_facts = source_state in {"healthy", "delayed"}
                available = bool(latest and status and status_allows_facts)
                state = source_state if available else "unavailable"
                if not record_ok:
                    detail = "metar_record_invalid"
                elif not status:
                    detail = "metar_status_unavailable"
                elif not latest:
                    detail = "metar_observation_unavailable"
                elif source_state == "unavailable":
                    detail = status.get("detail") or "metar_status_unavailable"
                else:
                    detail = status.get("detail")
                parse_utc = latest.get("_report_utc") if available else None
                age_minutes = (max(0, int((datetime.now(UTC) - parse_utc.astimezone(UTC)).total_seconds() // 60))
                               if parse_utc else None)
                result.append({
                    "city": city, "city_cn": spec["city_label"], "station": station,
                    "decision_scope": spec["decision_scope"],
                    "scope": spec["decision_scope"],
                    "state": state,
                    "detail": detail,
                    # A failed source must never render its retained value as
                    # though it were a current observation.
                    "available": available,
                    "temperature_c": latest.get("temperature_c") if available else None,
                    "report_time": self._metar_china_time(parse_utc),
                    "read_time": (self._metar_china_time(latest.get("_received_utc"))
                                  if available else None),
                    "age_minutes": age_minutes,
                    "report_type": latest.get("report_type") if available else None,
                    "conditions": latest.get("conditions") if available else None,
                    "wind_mps": latest.get("wind_mps") if available else None,
                    "visibility_km": latest.get("visibility_km") if available else None,
                    "today_high": (max((point["v"] for point in points.get(station, [])), default=None)
                                   if available else None),
                    "points": list(reversed(points.get(station, []))) if available else [],
                })
            return result
        except (sqlite3.Error, ValueError, TypeError):
            return self._metar_actual_placeholders("metar_query_unavailable")
        finally:
            if db is not None:
                db.close()

    def paper_snapshot(self) -> dict:
        db = None
        try:
            db = sqlite3.connect(f"file:{PAPER_DB}?mode=ro", uri=True)
            db.row_factory = sqlite3.Row
            account = db.execute("SELECT * FROM paper_accounts WHERE account_id='research'").fetchone()
            if account is None:
                db.close()
                return {"ok": False, "error": "纸面账户尚未初始化"}
            reset = db.execute("""SELECT * FROM paper_reset_events
              WHERE account_id='research' ORDER BY reset_at DESC LIMIT 1""").fetchone()
            reset_at = reset["reset_at"] if reset else None
            positions = []
            for row in db.execute("""SELECT p.*,q.best_bid,q.best_ask,q.bid_size,q.ask_size,
                     q.captured_at AS quote_at,r.high_bid,r.trailing_active,
                     r.last_evaluated_at,r.last_exit_reason,r.strategy_version
              FROM paper_positions p
              LEFT JOIN paper_quote_marks q ON q.token_id=p.token_id
              LEFT JOIN paper_position_risk_state r ON r.token_id=p.token_id
              WHERE p.account_id='research' AND p.quantity>0.000001
              ORDER BY p.updated_at DESC"""):
                item = dict(row)
                mark = item.pop("best_bid", None)
                item["mark"] = float(mark) if mark is not None else None
                item["best_ask"] = float(item["best_ask"]) if item.get("best_ask") is not None else None
                item["unrealized_pnl"] = ((item["mark"] - float(item["avg_cost"])) * float(item["quantity"])
                                          if item["mark"] is not None else None)
                item["market_value"] = (item["mark"] * float(item["quantity"])
                                        if item["mark"] is not None else None)
                item["return_pct"] = (((item["mark"] / float(item["avg_cost"])) - 1.0) * 100.0
                                      if item["mark"] is not None and float(item["avg_cost"] or 0) > 0 else None)
                item["stop_price"] = float(item["avg_cost"]) * 0.5
                item["trail_activation_price"] = float(item["avg_cost"]) * 1.2
                item["trail_stop_price"] = (float(item["high_bid"]) * 0.9
                                             if item.get("trailing_active") and item.get("high_bid") is not None else None)
                for key in ("updated_at", "quote_at", "last_evaluated_at"):
                    item[key] = china_time(item.get(key))
                positions.append(item)

            order_filter = " AND created_at>=?" if reset_at else ""
            order_params = (reset_at,) if reset_at else ()
            orders = []
            for row in db.execute(f"""SELECT * FROM paper_orders
              WHERE account_id='research'{order_filter} ORDER BY created_at DESC LIMIT 80""", order_params):
                item = dict(row)
                for key in ("created_at", "updated_at", "last_quote_at"):
                    item[key] = china_time(item.get(key))
                orders.append(item)

            fill_filter = " AND f.filled_at>=?" if reset_at else ""
            fill_params = (reset_at,) if reset_at else ()
            fills = []
            for row in db.execute(f"""SELECT f.*,o.city,o.target_date,o.bucket,o.order_type,
                     o.limit_price,o.reason AS order_reason
              FROM paper_fills f
              JOIN paper_orders o ON o.order_id=f.order_id
              WHERE o.account_id='research'{fill_filter}
              ORDER BY f.filled_at DESC LIMIT 80""", fill_params):
                item = dict(row)
                for key in ("filled_at", "quote_at"):
                    item[key] = china_time(item.get(key))
                fills.append(item)

            decision_filter = "WHERE evaluated_at>=?" if reset_at else ""
            decision_params = (reset_at,) if reset_at else ()
            decisions = []
            for row in db.execute(f"""SELECT * FROM (
                SELECT s.*,ROW_NUMBER() OVER (PARTITION BY token_id ORDER BY evaluated_at DESC) AS rn
                FROM paper_shadow_gate_state s {decision_filter}
              ) WHERE rn=1 ORDER BY evaluated_at DESC LIMIT 40""", decision_params):
                raw = dict(row)
                try:
                    gates = json.loads(raw.get("gates_json") or "{}")
                except (TypeError, ValueError, json.JSONDecodeError):
                    gates = {}
                price_gate = gates.get("price") if isinstance(gates.get("price"), dict) else {}
                execution_gate = gates.get("execution") if isinstance(gates.get("execution"), dict) else {}
                gate_view = {}
                for gate_name in ("direction", "weather", "price", "execution"):
                    gate = gates.get(gate_name) if isinstance(gates.get(gate_name), dict) else {}
                    gate_view[gate_name] = {
                        "status": str(gate.get("status") or "unknown"),
                        "reason": str(gate.get("reason") or ""),
                    }
                decisions.append({
                    "evaluated_at": china_time(raw.get("evaluated_at")),
                    "city": raw.get("city"), "target_date": raw.get("target_date"),
                    "bucket": raw.get("bucket"), "signal_source": raw.get("signal_source"),
                    "state": raw.get("state"), "gates": gate_view,
                    "raw_probability": price_gate.get("raw_probability"),
                    "historical_count": price_gate.get("historical_count"),
                    "sample_count": price_gate.get("sample_count"),
                    "edge": price_gate.get("edge"),
                    "ask": execution_gate.get("ask", price_gate.get("executable_ask")),
                    "ask_size": execution_gate.get("ask_size"),
                })
            session = db.execute("SELECT * FROM paper_sessions WHERE status='ACTIVE' ORDER BY started_at DESC LIMIT 1").fetchone()
            market_value = sum(float(row["quantity"]) * float(row["mark"] or 0) for row in positions)
            unrealized = sum(float(row["unrealized_pnl"] or 0) for row in positions)
            result = {"account": dict(account), "positions": positions, "orders": orders, "fills": fills,
                      "decisions": decisions, "equity": float(account["cash"]) + market_value,
                      "unrealized_pnl": unrealized, "open_order_count": sum(row["status"] == "OPEN" for row in orders),
                      "reset": ({**dict(reset), "reset_at": china_time(reset["reset_at"])} if reset else None)}
            db.close()
            automation = {"state": "paused", "message": "自动模拟已暂停；仅保留本地模拟会话"}
            return {"ok": True, **result, "session": dict(session) if session else None, "automation": automation}
        except Exception:
            return {"ok": False, "error": "paper_data_unavailable"}
        finally:
            if db is not None:
                db.close()

    def snapshot(self) -> dict:
        if not DB.exists():
            return {"error": "尚未建立研究数据库。请先启动 collector.py。"}
        db = quote_db = None
        try:
            db = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
            quote_db = sqlite3.connect(f"file:{REALTIME_DB}?mode=ro", uri=True, timeout=3)
            rows = db.execute("""
              SELECT m.market_id,m.city,COALESCE(m.bucket_label,m.question),m.question,m.tokens_json,m.outcomes_json,m.liquidity
              FROM market_snapshots m JOIN (SELECT market_id,MAX(captured_at) latest FROM market_snapshots GROUP BY market_id) x
              ON x.market_id=m.market_id AND x.latest=m.captured_at WHERE m.active=1
            """).fetchall()
            markets=[]
            for ident, city, bucket, question, tokens, outcomes, liquidity in rows:
                parsed=json.loads(tokens or "[]")
                parsed_outcomes=json.loads(outcomes or "[]")
                try:
                    yes_token = str(parsed[[str(value).lower() for value in parsed_outcomes].index("yes")])
                except (ValueError, IndexError):
                    continue
                markets.append({"id":str(ident),"city":city,"city_cn":CN.get(city,city),"bucket":bucket,"question":question,"date":market_date(question),"token":yes_token,"liquidity":round(float(liquidity or 0))})
            today = china_now().date()
            allowed_dates = {(today.fromordinal(today.toordinal() + offset)).isoformat() for offset in range(3)}
            markets = [item for item in markets if item["date"] in allowed_dates]
            markets.sort(key=lambda x:(CITY_ORDER.index(x["city"]) if x["city"] in CITY_ORDER else 99,x["date"],x["bucket"]))
            with self._cache_lock:
                self._market_tokens = list(markets)
            active_tokens = [item["token"] for item in markets]
            live_view: dict[str, Any] = {}
            if self._live_quote_provider:
                try:
                    candidate = self._live_quote_provider()
                    if isinstance(candidate, dict):
                        live_view = candidate
                except Exception:
                    # A live projection is an optimization only.  Never let a
                    # local websocket failure prevent the dashboard fallback.
                    live_view = {}
            # Keep the last local quote during a hub reconnect.  SQLite is then
            # compared by capture time below; an older durable row can never
            # roll the visible price backwards.
            live_quotes = live_view.get("quotes", {}) if isinstance(
                live_view.get("quotes", {}), dict
            ) else {}
            latest_books: dict[str, tuple] = {}
            durable_tokens = (
                [token for token in active_tokens if token not in live_quotes]
                if live_view.get("state") == "healthy"
                else active_tokens
            )
            if durable_tokens:
                token_marks = ",".join("?" for _ in durable_tokens)
                # Bounded live projection maintained by the stream writer.
                # Never aggregate historical BBO rows in the dashboard path.
                rows = quote_db.execute(f"""SELECT token_id,best_bid,best_ask,bid_size,ask_size,captured_at
                  FROM latest_bbo WHERE token_id IN ({token_marks})
                    AND NOT (COALESCE(best_bid,0)<=0.001 AND COALESCE(best_ask,1)>=0.999)""",
                  durable_tokens).fetchall()
                latest_books = {token: (bid, ask, bid_size, ask_size, captured_at)
                                for token, bid, ask, bid_size, ask_size, captured_at in rows}
            for item in markets:
                projected = live_quotes.get(item["token"])
                durable = latest_books.get(item["token"])
                use_projected = prefer_projected_quote(projected, durable)
                if use_projected:
                    bid, ask = projected.get("bid"), projected.get("ask")
                    bs, ass = projected.get("bid_size"), projected.get("ask_size")
                    stamp = projected.get("captured_at")
                else:
                    bid,ask,bs,ass,stamp=durable or (None,None,None,None,None)
                item.update(bid=bid, ask=ask, bid_size=bs, ask_size=ass,
                            # SQLite stores UTC.  The whole dashboard uses
                            # China time, so never expose a raw UTC quote time.
                            book_time=china_time(stamp), quote_captured_at=stamp,
                            quote_health=freshness(stamp, 20))
                if use_projected:
                    item.update(
                        exchange_at=projected.get("exchange_at"),
                        received_at=projected.get("received_at"),
                        published_at=projected.get("published_at"),
                        source_to_receive_ms=projected.get("source_to_receive_ms"),
                        source_to_hub_ms=projected.get("source_to_hub_ms"),
                        quote_sequence=projected.get("sequence"),
                        quote_stream_id=projected.get("stream_id"),
                        levels=projected.get("levels") or [],
                    )
            forecasts=[]
            approved_sources = TRACKED_SOURCE_MODELS
            placeholders = ",".join("?" for _ in approved_sources)
            has_d0_registry = db.execute("""SELECT 1 FROM sqlite_master
              WHERE type='table' AND name='forecast_d0_registry'""").fetchone() is not None
            d0_rows = db.execute(f"""SELECT source,city,station,target_date,status,forecast_high_c,
              forecast_bucket,source_reported_at,first_captured_at,capture_delay_seconds,
              grid_version,reason,frozen_at,latest_checked_at,content_hash
              FROM forecast_d0_registry
              WHERE source IN ({placeholders}) AND target_date IN ({','.join('?' for _ in allowed_dates)})""",
              (*approved_sources, *sorted(allowed_dates))).fetchall() if has_d0_registry else []
            d0_by_key, d0_groups = {}, {}
            for values in d0_rows:
                source, city, station, target_date, status, high, bucket, source_time, captured, delay, grid, reason, frozen, checked, content_hash = values
                key = (source, city, station, target_date)
                d0_groups.setdefault(key, []).append({
                    "source": source, "city": city, "station": station, "target_date": target_date,
                    "status": status, "forecast_high_c": high, "forecast_bucket": bucket,
                    "source_reported_at": source_time, "first_captured_at": captured,
                    "capture_delay_seconds": delay, "grid_version": grid, "reason": reason,
                    "frozen_at": frozen, "latest_checked_at": checked, "content_hash": content_hash,
                })
            for key, rows in d0_groups.items():
                normalized = _select_strict_registry(rows)
                if normalized is None:
                    d0_by_key[key] = None
                    continue
                d0_by_key[key] = {
                    "d0_status": normalized["status"], "d0_high": normalized["forecast_high_c"],
                    "d0_bucket": normalized["forecast_bucket"],
                    "d0_source_reported_at": _forecast_china_time(normalized["_source_reported_at"]),
                    "d0_captured": _forecast_china_time(normalized["_first_captured_at"]),
                    "d0_delay_seconds": normalized["capture_delay_seconds"], "grid_version": normalized["grid_version"],
                    "d0_reason": normalized["reason"], "d0_frozen_at": _forecast_china_time(normalized["_frozen_at"]),
                }
            snapshot_rows = list(db.execute(f"""
              SELECT a.city,f.city,f.model,f.forecast_json,f.captured_at FROM forecast_snapshots f
              LEFT JOIN airport_stations a ON a.station=f.city
              WHERE f.model IN ({placeholders})
            """, approved_sources))
            for city, station, model, raw, captured in _select_latest_snapshot(snapshot_rows):
                valid_rows = _forecast_snapshot_row(model, city, station, raw, captured, allowed_dates)
                if valid_rows is None:
                    continue
                for day, high, captured_stamp, source_stamp in valid_rows:
                        if day >= CITY_RETIREMENT_DATES.get(city, "9999-12-31"):
                            continue
                        d0 = d0_by_key.get((model, city, station, day)) or {}
                        # Historical rows predate the registry.  Keep them visible,
                        # but never present them as verified D0 evidence.
                        if not d0:
                            d0 = {"d0_status": "legacy_unverified", "d0_high": None,
                                  "d0_bucket": None, "d0_source_reported_at": None,
                                  "d0_captured": None, "d0_delay_seconds": None,
                                  "grid_version": None, "d0_reason": "历史记录未保存可验证来源发布时间"}
                        forecasts.append({"city":city,"station":station,"source_key":model,"model":MODELS.get(model,model),"date":day,
                                          "high":float(high) if high is not None else None,
                                          "status":"ok" if high is not None else "empty_daily_high",
                                          "captured":_forecast_china_time(captured_stamp),
                                          "latest_source_reported_at":_forecast_china_time(source_stamp), **d0})
            forecasts.sort(key=lambda item: (next(index for index, meta in enumerate(FORECAST_API_CITIES)
                                               if meta["city"] == item["city"]),
                                              item["date"], item["source_key"]))
            # Rebuild display events from immutable source-report pulls.  The
            # migrated forecast_events table has known timestamp drift and is
            # not suitable for D0 timing or reaction baselines.
            pull_rows = list(db.execute(f"""SELECT source,city,station,target_date,forecast_high_c,captured_at
              FROM forecast_update_values
              WHERE source IN ({placeholders}) AND target_date IN ({','.join('?' for _ in allowed_dates)})
              ORDER BY source,station,target_date,captured_at""", (*approved_sources, *sorted(allowed_dates))))
            updates, previous = [], {}
            update_records: dict[str, tuple[str, str, float | None, str]] = {}
            for owner, captured_stamp, high, captured_at, source, city, station, target_date in _order_updates(pull_rows, allowed_dates):
                key = (source, station, target_date)
                prior = previous.get(key, object())
                captured_day = captured_stamp.astimezone(CHINA_TZ).date().isoformat()
                if captured_day == target_date and (not any(x["date"] == target_date and x["source_key"] == source for x in updates) or prior != high):
                    version_id = f"fetch:{source}:{station}:{target_date}:{captured_at}"
                    update_records[version_id] = (city, target_date, high, captured_at)
                    updates.append({"version_id": version_id, "source_key": source,
                        "source": MODELS.get(source, source), "city": city, "city_cn": owner["city_label"],
                        "station": station, "captured_at": _forecast_china_time(captured_stamp),
                        "date": target_date, "high": high, "_captured_utc": captured_stamp})
                previous[key] = high
            updates.sort(key=lambda item: (item["_captured_utc"], item["source_key"], item["station"]), reverse=True)
            for item in updates:
                item.pop("_captured_utc", None)
            with self._cache_lock:
                self._update_records = update_records
            run=db.execute("SELECT captured_at FROM collector_runs ORDER BY captured_at DESC LIMIT 1").fetchone()
            services = {}
            for service, updated_at, detail in db.execute("SELECT service,updated_at,detail FROM service_heartbeats"):
                health = freshness(updated_at, 480 if service == "collector" else 90)
                # A recent reconnect attempt is not a healthy quote feed.  It
                # must stay visibly degraded until a new BBO reaches SQLite.
                if service == "realtime_stream" and any(word in str(detail).lower()
                        for word in ("connecting", "reconnecting", "waiting", "offline", "writer=error")):
                    health["state"] = "recovering"
                services[service] = {"updated_at": china_time(updated_at), "detail": detail, **health}
            # The quote writer owns its own heartbeat.  It must not be
            # inferred from the collector's research heartbeat.
            for service, updated_at, detail in quote_db.execute("SELECT service,updated_at,detail FROM service_heartbeats"):
                health = freshness(updated_at, 90)
                if service == "realtime_stream" and any(word in str(detail).lower()
                        for word in ("connecting", "reconnecting", "waiting", "offline", "writer=error")):
                    health["state"] = "recovering"
                services[service] = {"updated_at": china_time(updated_at), "detail": detail, **health}
            if self._live_quote_provider:
                live_age = live_view.get("age_seconds")
                latest_quote = max(
                    live_quotes.values(),
                    key=lambda value: int(value.get("sequence") or 0),
                    default={},
                )
                services["state_hub"] = {"updated_at": None,
                    "detail": f"local BBO projection · {len(live_quotes)} tokens",
                    "state": live_view.get("state", "offline"), "age_seconds": live_age,
                    "upstream_connected": live_view.get("upstream_connected"),
                    "upstream_detail": live_view.get("upstream_detail"),
                    "latency_ms": latest_quote.get("source_to_hub_ms")}
            resolution_rows = list(db.execute("""
              SELECT city,target_date,bucket_label,MAX(resolved_at)
              FROM market_resolutions WHERE yes_resolved=1
              GROUP BY city,target_date,bucket_label ORDER BY target_date DESC, city LIMIT 100
            """))
            resolutions = [{"city": CN.get(city, city), "date": target_date, "bucket": bucket,
                            "resolved_at": china_time(resolved_at)}
                           for city, target_date, bucket, resolved_at in resolution_rows]
            validations = []
            for city, target_date, bucket, resolved_at in resolution_rows:
                for item in d0_model_validations(db, city, target_date, bucket):
                    validations.append({"city": CN.get(city, city), "date": target_date, "bucket": bucket,
                                        "model": item["model"], "captured_at": item["captured_at"],
                                        "provenance": item["provenance"],
                                        "horizons": [{"name": "D0", "high": item["high"],
                                                      "captured_at": item["captured_at"], "execution_ready": True,
                                                      "status": item["status"], "deviation": item["deviation"]}]})
            return {"markets":markets,"forecasts":forecasts,"updates":updates,
                    "actuals":self.actual_snapshot(),
                    "collector":china_time(run[0]) if run else None,
                    "now":china_now().strftime("%Y-%m-%d %H:%M:%S"),"services":services,
                    "resolutions":resolutions,"validations":validations}
        except Exception:
            return {"error":"dashboard_data_unavailable"}
        finally:
            if quote_db is not None:
                quote_db.close()
            if db is not None:
                db.close()

    def history(self, token: str) -> list[dict]:
        if not self._valid_runtime_id(token) or not self._known_market_token(token):
            return []
        db = sqlite3.connect(f"file:{REALTIME_DB}?mode=ro", uri=True)
        try:
            now = datetime.now(UTC).isoformat()
            points = self._cache_get(self._history_cache, token)
            if points:
                current_bucket = datetime.fromtimestamp(points[-1][0] * 300, UTC).isoformat()
                updates = market_price_points(db, token, current_bucket, now)
                if updates:
                    points = [point for point in points if point[0] < updates[0][0]] + updates
                    self._cache_put(self._history_cache, token, points)
            else:
                points = market_price_points(db, token, "1970-01-01T00:00:00+00:00", now)
                self._cache_put(self._history_cache, token, points)
        finally:
            db.close()
        return [{"t": datetime.fromtimestamp(bucket * 300, UTC).astimezone(CHINA_TZ).strftime("%m-%d %H:%M"),
                 "v": round(value * 100, 2),
                 # Never connect a recovered feed to an earlier point as though
                 # the market had been observed continuously.
                 "gap_before": index > 0 and bucket - points[index - 1][0] > 600}
                for index, (bucket, value) in enumerate(points)]

    def depth(self, token: str) -> list[dict]:
        if not self._valid_runtime_id(token) or not self._known_market_token(token):
            return []
        db = sqlite3.connect(f"file:{REALTIME_DB}?mode=ro", uri=True)
        try:
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='latest_orderbook_levels'").fetchone():
                rows = db.execute("""SELECT side,price,size FROM latest_orderbook_levels
                  WHERE token_id=? ORDER BY side,
                  CASE side WHEN 'ask' THEN price END ASC,
                  CASE side WHEN 'bid' THEN price END DESC""", (token,)).fetchall()
                if rows:
                    return [{"side": side, "price": price, "size": size} for side, price, size in rows]
            columns = {row[1] for row in db.execute("PRAGMA table_info(book_snapshots)")}
            latest = db.execute("""SELECT captured_at,event_reason,depth_fresh FROM book_snapshots
              WHERE token_id=? ORDER BY captured_at DESC LIMIT 1""", (token,)).fetchone() if "depth_fresh" in columns else None
            depth_at = None
            if latest and latest[2]:
                depth_at = latest[0]
            elif latest and latest[1] == "heartbeat":
                row = db.execute("SELECT MAX(captured_at) FROM orderbook_levels WHERE token_id=? AND captured_at<=?",
                                 (token, latest[0])).fetchone()
                depth_at = row[0] if row else None
            rows = db.execute("""SELECT side,price,size FROM orderbook_levels
              WHERE token_id=? AND captured_at=?
              ORDER BY side, CASE side WHEN 'ask' THEN price END ASC, CASE side WHEN 'bid' THEN price END DESC""",
              (token, depth_at)).fetchall() if depth_at else []
        finally:
            db.close()
        return [{"side": side, "price": price, "size": size} for side, price, size in rows]

    def reaction_live(self, version_ids: list[str]) -> dict[str, dict]:
        """Return a full-day price line for every selected forecast version.

        The line starts when the forecast version is first captured and ends at
        the target day's China-time midnight.  One close per minute keeps the
        display smooth without repeatedly sending every raw quote to the UI.
        """
        if (
            type(version_ids) is not list
            or not version_ids
            or len(version_ids) > self.MAX_REACTION_IDS
            or any(not self._valid_runtime_id(value) for value in version_ids)
        ):
            return {}
        with self._cache_lock:
            market_tokens = list(self._market_tokens)
            update_records = dict(self._update_records)
        if not market_tokens:
            return {}
        db = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
        quote_db = sqlite3.connect(f"file:{REALTIME_DB}?mode=ro", uri=True)
        result: dict[str, dict] = {}
        try:
            event_ids = [value for value in version_ids if not str(value).startswith("fetch:")]
            versions = []
            if event_ids:
                placeholders = ",".join("?" for _ in event_ids)
                versions.extend(db.execute(f"""SELECT event_id,city,target_date,forecast_high_c,first_seen_at
                  FROM forecast_events WHERE event_id IN ({placeholders})""", event_ids).fetchall())
            for version_id in version_ids:
                record = update_records.get(str(version_id))
                if record:
                    versions.append((str(version_id), *record))
            for version_id, city, target_date, high, first_seen_at in versions:
                market, match_error = match_market_bucket(market_tokens, city, target_date, high)
                if not market:
                    result[version_id] = {"error": match_error}
                    continue
                token = market["token"]
                day_end = (datetime.fromisoformat(target_date).replace(tzinfo=CHINA_TZ)
                           + timedelta(days=1)).astimezone(UTC).isoformat()
                cache = self._cache_get(self._reaction_cache, str(version_id))
                if cache is None or cache["token"] != token or cache["day_end"] != day_end:
                    baseline = quote_db.execute("""SELECT best_bid,best_ask FROM book_snapshots
                      WHERE token_id=? AND captured_at<=?
                        AND NOT (COALESCE(best_bid,0)<=0.001 AND COALESCE(best_ask,1)>=0.999)
                      ORDER BY captured_at DESC LIMIT 1""", (token, first_seen_at)).fetchone()
                    if not baseline:
                        continue
                    baseline_mid = ((float(baseline[0]) + float(baseline[1])) / 2
                                    if baseline[0] is not None and baseline[1] is not None
                                    else float(baseline[0] if baseline[0] is not None else baseline[1]))
                    points = minute_price_points(quote_db, token, first_seen_at, day_end)
                    cache = {"token": token, "day_end": day_end, "baseline": baseline_mid, "points": points}
                    self._cache_put(self._reaction_cache, str(version_id), cache)
                else:
                    points = cache["points"]
                    if points:
                        current_minute = datetime.fromtimestamp(points[-1][0] * 60, UTC).isoformat()
                        updates = minute_price_points(quote_db, token, current_minute, day_end)
                        if updates:
                            points = [point for point in points if point[0] < updates[0][0]] + updates
                            cache["points"] = points
                    else:
                        points = minute_price_points(quote_db, token, first_seen_at, day_end)
                        cache["points"] = points
                baseline_mid = cache["baseline"]
                if not points:
                    continue
                latest = quote_db.execute("""SELECT best_bid,best_ask FROM book_snapshots
                  WHERE token_id=? AND captured_at>=? AND captured_at<?
                    AND NOT (COALESCE(best_bid,0)<=0.001 AND COALESCE(best_ask,1)>=0.999)
                  ORDER BY captured_at DESC LIMIT 1""", (token, first_seen_at, day_end)).fetchone()
                if latest and latest[0] is not None and latest[1] is not None:
                    current_mid = (float(latest[0]) + float(latest[1])) / 2
                elif latest and latest[0] is not None:
                    current_mid = float(latest[0])
                elif latest and latest[1] is not None:
                    current_mid = float(latest[1])
                else:
                    current_mid = points[-1][1]
                result[version_id] = {"baseline": baseline_mid, "current": current_mid,
                    "change": current_mid - baseline_mid,
                    "points": [{"t": datetime.fromtimestamp(bucket * 60, UTC).astimezone(CHINA_TZ).strftime("%H:%M"),
                                "v": value}
                               for bucket, value in points]}
        finally:
            quote_db.close()
            db.close()
        return result


if __name__ == "__main__":
    # Keep the historical entry point from silently reopening the retired
    # five-second snapshot page.  The live shell is the sole desktop UI.
    from dashboard_live import LiveDashboard
    app = LiveDashboard()
    webview.start()
