import asyncio
import hashlib
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

import collector
import realtime_stream as stream
from test_research_market_attribution import (
    SCANNED_AT,
    _TwoCityMatrixClient,
)


def v1_member(token: str, market: str, *, scan: str, **changes):
    member = {
        "schema": "research_market_attribution.v1",
        "token_id": token,
        "market_id": market,
        "city": "Beijing",
        "city_scope": "formal",
        "station": "ZBAA",
        "target_date": "2026-08-10",
        "outcome": "Yes",
        "event_id": f"event-{market}",
        "source_scan_id": scan,
        "attribution_status": "verified",
    }
    member.update(changes)
    return member


def publication_row(members, *, published_at: str):
    raw = json.dumps(members, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    return (
        f"{published_at}:{token_hash[:12]}",
        published_at,
        token_hash,
        len(members),
        raw,
        "complete_scan",
    )


class CollectorMetadataOnlyTests(unittest.TestCase):
    def test_only_source_scan_change_is_suppressed_but_other_facts_are_not(self):
        accepted = collector.AcceptedManifestMembers(
            [v1_member("100", "market-100", scan="scan-old")], "v1"
        )
        source_only = [v1_member("100", "market-100", scan="scan-new")]
        self.assertTrue(
            collector._metadata_only_v1_publication(accepted, source_only)
        )

        unsafe = (
            [v1_member("100", "market-100", scan="scan-old")],
            [v1_member("100", "market-changed", scan="scan-new")],
            [v1_member("100", "market-100", scan="scan-new", event_id="changed")],
            [v1_member(
                "100", "market-100", scan="scan-new", city="Shanghai",
                city_scope="formal", station="ZSPD",
            )],
            [v1_member("100", "market-100", scan="scan-new", target_date="2026-08-11")],
            [v1_member("100", "market-100", scan="scan-new", extra_fact="changed")],
            source_only + [v1_member("101", "market-101", scan="scan-new")],
            [],
        )
        for members in unsafe:
            with self.subTest(members=members):
                self.assertFalse(
                    collector._metadata_only_v1_publication(accepted, members)
                )

    def test_prepare_marks_source_scan_only_candidate_for_publication_suppression(self):
        accepted = collector.AcceptedManifestMembers(
            [v1_member("100", "market-100", scan="scan-old")], "v1"
        )
        candidate = {
            "members": [v1_member("100", "market-100", scan="scan-new")],
            "token_count": 1,
            "token_hash": "f" * 64,
        }
        with patch.object(
            collector, "load_realtime_accepted_universe_read_only",
            return_value={"token_hash": "a" * 64, "token_count": 1},
        ), patch.object(
            collector, "load_accepted_research_universe_members_read_only",
            return_value=accepted,
        ), patch.object(
            collector, "build_research_universe_candidate", return_value=candidate,
        ):
            decision = collector.prepare_research_universe_publication([], [])
        self.assertTrue(decision["suppress_universe_publication"])
        self.assertIs(decision["candidate"], candidate)

    def test_collect_still_writes_market_facts_but_not_a_metadata_publication(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "research.sqlite3"
            with patch.object(collector, "DB_PATH", path), patch.object(
                collector, "prune_research_data"
            ):
                db = collector.connect()

            def metadata_decision(records, _statuses, **_kwargs):
                return {
                    "candidate": collector.build_research_universe_candidate(records),
                    "already_published": False,
                    "suppress_universe_publication": True,
                }

            try:
                with patch.object(collector, "ALLOWED_CITIES", {"beijing", "wuhan"}), patch.object(
                    collector, "prepare_research_universe_publication",
                    side_effect=metadata_decision,
                ):
                    found = asyncio.run(collector.collect_markets(
                        _TwoCityMatrixClient(), db, SCANNED_AT,
                    ))
                self.assertEqual(found, 1)
                self.assertGreater(
                    db.execute("SELECT COUNT(*) FROM market_snapshots").fetchone()[0], 0
                )
                self.assertGreater(
                    db.execute("SELECT COUNT(*) FROM market_rules").fetchone()[0], 0
                )
                self.assertEqual(
                    db.execute("SELECT COUNT(*) FROM market_universe_publications").fetchone()[0],
                    0,
                )
            finally:
                db.close()

    def test_unchanged_publication_means_zero_realtime_send_and_audit(self):
        members = [v1_member("100", "market-100", scan="scan-old")]
        row = publication_row(members, published_at="2026-08-12T00:00:00+00:00")
        manifest = stream._manifest_from_row(row, accepted_legacy_hashes=set())
        self.assertIsNotNone(manifest)
        writer = Mock()
        hub = stream.LiveStateHub()
        hub.set_universe(manifest.token_market)
        state = stream.StreamState(
            None, manifest.token_market, writer, hub, manifest.token_hash,
            token_target_date=manifest.token_target_date, manifest=manifest,
        )
        websocket = Mock()
        websocket.send = AsyncMock()
        with patch.object(stream, "record_connection_event") as audit:
            change = asyncio.run(stream.apply_manifest_candidate(
                websocket, state, manifest,
                now_cn=datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ),
            ))
        self.assertIsNone(change)
        websocket.send.assert_not_awaited()
        audit.assert_not_called()


class RollbackChainNoiseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.research = Path(self.tmp.name) / "research.sqlite3"
        self.realtime = Path(self.tmp.name) / "realtime.sqlite3"
        self.old_research, self.old_db = stream.RESEARCH_DB, stream.DB
        stream.RESEARCH_DB, stream.DB = self.research, self.realtime
        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute("""CREATE TABLE market_universe_publications (
              publication_id TEXT PRIMARY KEY, published_at TEXT, token_hash TEXT,
              token_count INTEGER, members_json TEXT, reason TEXT)""")
        db = stream.connect()
        db.close()

    def tearDown(self):
        stream.RESEARCH_DB, stream.DB = self.old_research, self.old_db
        self.tmp.cleanup()

    def store(self, members, event_at):
        row = publication_row(members, published_at=event_at)
        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute(
                "INSERT INTO market_universe_publications VALUES (?,?,?,?,?,?)", row
            )
        return row[2]

    def accept(self, token_hash, event_at):
        with closing(sqlite3.connect(self.realtime)) as db, db:
            db.execute("""INSERT INTO stream_connection_events VALUES
              (?,?,?,?,?,?,?)""", (
                event_at, "universe_changed", "fixture", token_hash, 1, "[]", "[]",
            ))

    def state_for_hash(self, token_hash):
        manifest = stream.published_universe_manifest(token_hash)
        self.assertIsNotNone(manifest)
        hub = stream.LiveStateHub()
        hub.set_universe(manifest.token_market)
        return stream.StreamState(
            None, manifest.token_market, Mock(), hub, manifest.token_hash,
            token_target_date=manifest.token_target_date, manifest=manifest,
        )

    def test_logical_chain_skips_only_source_scan_noise_and_allows_real_predecessor(self):
        old_hash = self.store(
            [v1_member("100", "market-100", scan="scan-old")],
            "2026-08-12T00:00:00+00:00",
        )
        asset_hash = self.store(
            [
                v1_member("100", "market-100", scan="scan-assets"),
                v1_member("101", "market-101", scan="scan-assets"),
            ],
            "2026-08-12T00:01:00+00:00",
        )
        current_hash = self.store(
            [
                v1_member("100", "market-100", scan="scan-metadata"),
                v1_member("101", "market-101", scan="scan-metadata"),
            ],
            "2026-08-12T00:02:00+00:00",
        )
        for token_hash, event_at in (
            (old_hash, "2026-08-12T00:00:01+00:00"),
            (asset_hash, "2026-08-12T00:01:01+00:00"),
            (current_hash, "2026-08-12T00:02:01+00:00"),
        ):
            self.accept(token_hash, event_at)

        self.assertEqual(
            stream.accepted_universe_hash_chain(),
            [current_hash, asset_hash, old_hash],
        )
        self.assertEqual(
            stream.accepted_universe_rollback_chain(),
            [current_hash, old_hash],
        )
        plan = stream.plan_explicit_rollback(
            self.state_for_hash(current_hash),
            expected_current_hash=current_hash,
            target_previous_hash=old_hash,
        )
        self.assertIsNotNone(plan)
        self.assertEqual(plan.pinned_hash, old_hash)

    def test_real_change_is_never_skipped(self):
        oldest = self.store(
            [v1_member("100", "market-100", scan="scan-0")],
            "2026-08-12T00:00:00+00:00",
        )
        real_change = self.store(
            [
                v1_member("100", "market-100", scan="scan-1"),
                v1_member("102", "market-102", scan="scan-1"),
            ],
            "2026-08-12T00:01:00+00:00",
        )
        current = self.store(
            [
                v1_member("100", "market-100", scan="scan-2"),
                v1_member("101", "market-101", scan="scan-2"),
            ],
            "2026-08-12T00:02:00+00:00",
        )
        for token_hash, event_at in (
            (oldest, "2026-08-12T00:00:01+00:00"),
            (real_change, "2026-08-12T00:01:01+00:00"),
            (current, "2026-08-12T00:02:01+00:00"),
        ):
            self.accept(token_hash, event_at)
        self.assertEqual(
            stream.accepted_universe_rollback_chain(),
            [current, real_change, oldest],
        )
        self.assertIsNone(stream.plan_explicit_rollback(
            self.state_for_hash(current),
            expected_current_hash=current,
            target_previous_hash=oldest,
        ))

    def test_unreadable_intermediate_publication_fails_closed(self):
        old_hash = self.store(
            [v1_member("100", "market-100", scan="scan-old")],
            "2026-08-12T00:00:00+00:00",
        )
        current_hash = self.store(
            [v1_member("100", "market-100", scan="scan-current")],
            "2026-08-12T00:02:00+00:00",
        )
        missing_hash = "f" * 64
        for token_hash, event_at in (
            (old_hash, "2026-08-12T00:00:01+00:00"),
            (missing_hash, "2026-08-12T00:01:01+00:00"),
            (current_hash, "2026-08-12T00:02:01+00:00"),
        ):
            self.accept(token_hash, event_at)
        self.assertEqual(stream.accepted_universe_rollback_chain(), [])
        self.assertIsNone(stream.plan_explicit_rollback(
            self.state_for_hash(current_hash),
            expected_current_hash=current_hash,
            target_previous_hash=old_hash,
        ))

    def test_market_remap_is_a_real_version_and_is_not_skipped(self):
        previous = self.store(
            [v1_member("100", "market-100", scan="scan-old")],
            "2026-08-12T00:00:00+00:00",
        )
        current = self.store(
            [v1_member("100", "market-remapped", scan="scan-new")],
            "2026-08-12T00:01:00+00:00",
        )
        self.accept(previous, "2026-08-12T00:00:01+00:00")
        self.accept(current, "2026-08-12T00:01:01+00:00")
        self.assertEqual(
            stream.accepted_universe_rollback_chain(), [current, previous]
        )
        self.assertIsNone(stream.plan_explicit_rollback(
            self.state_for_hash(current),
            expected_current_hash=current,
            target_previous_hash=previous,
        ))


if __name__ == "__main__":
    unittest.main()
