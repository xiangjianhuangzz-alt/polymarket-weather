import asyncio
import math
import sqlite3
import tempfile
import threading
import time
import unittest
from contextlib import closing
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, patch

import realtime_stream as stream


TOKEN_COUNT = 308
NORMAL_RAW_ROWS_PER_HOUR = 73_877
STRESS_MULTIPLIER = 2
STRESS_LOGICAL_SECONDS = 5 * 60
SAFETY_FACTOR = 1.25
DEPTH_LEVELS_PER_SNAPSHOT = 10


def quote_event(token: str, captured_at: datetime, *, depth: bool = False) -> dict:
    levels = []
    if depth:
        levels = [
            ("bid", 0.30 - level / 1000, 10.0 + level)
            for level in range(5)
        ] + [
            ("ask", 0.31 + level / 1000, 10.0 + level)
            for level in range(5)
        ]
    return {
        "token": token,
        "market": f"market-{token}",
        "captured_at": captured_at.isoformat(),
        "received_at": captured_at.isoformat(),
        "exchange_at": None,
        "bid": 0.30,
        "ask": 0.31,
        "bid_size": 10.0,
        "ask_size": 11.0,
        "reason": "capacity-stress",
        "depth_fresh": depth,
        "levels": levels,
        "latest_levels": levels,
    }


class TemporaryRealtimeDatabaseMixin:
    def setUp(self) -> None:
        super().setUp()
        self._temporary_directory = tempfile.TemporaryDirectory()
        self.database_path = Path(self._temporary_directory.name) / "realtime.sqlite3"
        self._database_patch = patch.object(stream, "DB", self.database_path)
        self._database_patch.start()

    def tearDown(self) -> None:
        self._database_patch.stop()
        self._temporary_directory.cleanup()
        super().tearDown()


class RetentionCapacityPlanTests(unittest.TestCase):
    def test_plan_derives_308_token_caps_with_two_x_and_safety_margin(self):
        plan = stream.retention_capacity_plan()

        self.assertEqual(plan["token_count"], TOKEN_COUNT)
        self.assertEqual(plan["stress_multiplier"], STRESS_MULTIPLIER)
        self.assertEqual(plan["stress_logical_seconds"], STRESS_LOGICAL_SECONDS)
        self.assertEqual(plan["safety_factor"], SAFETY_FACTOR)
        self.assertEqual(plan["raw"]["normal_rows_per_hour"], NORMAL_RAW_ROWS_PER_HOUR)
        self.assertEqual(
            plan["raw"]["minimum_rows"],
            NORMAL_RAW_ROWS_PER_HOUR * 6,
        )
        self.assertGreaterEqual(
            plan["raw"]["ceiling"],
            math.ceil(NORMAL_RAW_ROWS_PER_HOUR * 6 * STRESS_MULTIPLIER * SAFETY_FACTOR),
        )

        normal_depth_rows_per_hour = (
            TOKEN_COUNT * DEPTH_LEVELS_PER_SNAPSHOT * 3600
            // stream.DEPTH_SNAPSHOT_SECONDS
        )
        self.assertEqual(
            plan["depth"]["normal_rows_per_hour"], normal_depth_rows_per_hour
        )
        self.assertGreaterEqual(
            plan["depth"]["ceiling"],
            math.ceil(normal_depth_rows_per_hour * 6 * STRESS_MULTIPLIER * SAFETY_FACTOR),
        )

    def test_bar_caps_cover_six_and_seven_days_with_safety_margin(self):
        plan = stream.retention_capacity_plan()
        minute_minimum = TOKEN_COUNT * 60 * 24 * 6
        five_minute_minimum = TOKEN_COUNT * 12 * 24 * 7

        self.assertEqual(plan["minute_bar"]["minimum_rows"], minute_minimum)
        self.assertEqual(plan["five_minute_bar"]["minimum_rows"], five_minute_minimum)
        self.assertGreaterEqual(
            plan["minute_bar"]["ceiling"], math.ceil(minute_minimum * SAFETY_FACTOR)
        )
        self.assertGreaterEqual(
            plan["five_minute_bar"]["ceiling"],
            math.ceil(five_minute_minimum * SAFETY_FACTOR),
        )
        self.assertGreaterEqual(stream.MINUTE_BAR_RETENTION_DAYS, 6)
        self.assertGreaterEqual(stream.FIVE_MINUTE_BAR_RETENTION_DAYS, 7)

    def test_runtime_caps_cannot_fall_below_the_frozen_plan(self):
        plan = stream.retention_capacity_plan()
        self.assertGreaterEqual(stream.MAX_RAW_QUOTE_ROWS, plan["raw"]["ceiling"])
        self.assertGreaterEqual(stream.MAX_DEPTH_ROWS, plan["depth"]["ceiling"])
        self.assertGreaterEqual(
            stream.MAX_MINUTE_BAR_ROWS, plan["minute_bar"]["ceiling"]
        )
        self.assertGreaterEqual(
            stream.MAX_FIVE_MINUTE_BAR_ROWS, plan["five_minute_bar"]["ceiling"]
        )

    def test_effective_retention_never_falls_below_scheme_a_defaults(self):
        self.assertEqual(stream._effective_retention_period(1, 6), 6)
        self.assertEqual(stream._effective_retention_period(5, 6), 6)
        self.assertEqual(stream._effective_retention_period(6, 6), 6)
        self.assertEqual(stream._effective_retention_period(12, 6), 12)
        self.assertEqual(stream._effective_retention_period(1, 7), 7)
        self.assertEqual(stream._effective_retention_period(7, 7), 7)
        self.assertEqual(stream._effective_retention_period(14, 7), 14)
        self.assertEqual(stream._effective_retention_period(180, 7), 180)
        self.assertGreaterEqual(stream.RAW_QUOTE_RETENTION_HOURS, 6)
        self.assertGreaterEqual(stream.DEPTH_RETENTION_HOURS, 6)
        self.assertGreaterEqual(stream.MINUTE_BAR_RETENTION_DAYS, 6)
        self.assertGreaterEqual(stream.FIVE_MINUTE_BAR_RETENTION_DAYS, 7)


class RetentionBoundaryTests(TemporaryRealtimeDatabaseMixin, unittest.TestCase):
    def _insert_compact_bar(
        self, db: sqlite3.Connection, token: str, captured_at: datetime
    ) -> None:
        bucket = captured_at.replace(
            minute=(captured_at.minute // 5) * 5,
            second=0,
            microsecond=0,
        ).isoformat()
        db.execute(
            """INSERT INTO book_price_bars VALUES
            (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                300, bucket, f"market-{token}", token,
                0.305, 0.305, 0.305, 0.305, 0.30, 0.31, 10, 11,
                0.01, 0.01, 1, captured_at.isoformat(),
            ),
        )

    def test_raw_and_depth_cap_keep_rows_at_or_inside_six_hour_boundary(self):
        fixed_now = datetime(2026, 8, 10, 12, 0, tzinfo=UTC)
        cutoff = fixed_now - timedelta(hours=6)
        db = stream.connect()
        try:
            raw_rows = (
                (cutoff - timedelta(seconds=1), "raw-old"),
                (cutoff, "raw-boundary"),
                (cutoff + timedelta(seconds=1), "raw-inside"),
            )
            for captured_at, token in raw_rows:
                db.execute(
                    "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
                    (
                        captured_at.isoformat(), "market", token,
                        0.30, 0.31, 10, 11, "test", 0,
                    ),
                )
            depth_rows = (
                (cutoff - timedelta(seconds=1), "depth-old"),
                (cutoff, "depth-boundary"),
                (cutoff + timedelta(seconds=1), "depth-inside"),
            )
            for captured_at, token in depth_rows:
                db.execute(
                    "INSERT INTO orderbook_levels VALUES (?,?,?,?,?,?)",
                    (captured_at.isoformat(), "market", token, "bid", 0.30, 10),
                )
            db.commit()

            with (
                patch.object(stream, "MAX_RAW_QUOTE_ROWS", 1),
                patch.object(stream, "MAX_DEPTH_ROWS", 1),
                patch.object(stream, "ROW_CAP_HEADROOM", 0),
                patch.object(stream, "PRUNE_BATCH_ROWS", 100),
            ):
                raw_deleted = stream.enforce_row_cap_phase(
                    db, "raw", headroom=False, now=fixed_now
                )
                depth_deleted = stream.enforce_row_cap_phase(
                    db, "depth", headroom=False, now=fixed_now
                )
                db.commit()

            raw_remaining = {
                row[0] for row in db.execute("SELECT token_id FROM book_snapshots")
            }
            depth_remaining = {
                row[0] for row in db.execute("SELECT token_id FROM orderbook_levels")
            }
        finally:
            db.close()

        self.assertEqual(raw_deleted, 1)
        self.assertEqual(depth_deleted, 1)
        self.assertEqual(raw_remaining, {"raw-boundary", "raw-inside"})
        self.assertEqual(depth_remaining, {"depth-boundary", "depth-inside"})

    def test_time_prune_is_strictly_older_than_raw_and_depth_boundary(self):
        fixed_now = datetime(2026, 8, 10, 12, 0, tzinfo=UTC)
        cutoff = fixed_now - timedelta(hours=6)
        db = stream.connect()
        try:
            for prefix, table in (("raw", "book_snapshots"), ("depth", "orderbook_levels")):
                for suffix, captured_at in (
                    ("old", cutoff - timedelta(seconds=1)),
                    ("boundary", cutoff),
                ):
                    token = f"{prefix}-{suffix}"
                    if table == "book_snapshots":
                        db.execute(
                            "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
                            (
                                captured_at.isoformat(), "market", token,
                                0.30, 0.31, 10, 11, "test", 0,
                            ),
                        )
                    else:
                        db.execute(
                            "INSERT INTO orderbook_levels VALUES (?,?,?,?,?,?)",
                            (
                                captured_at.isoformat(), "market", token,
                                "bid", 0.30, 10,
                            ),
                        )
                    self._insert_compact_bar(db, token, captured_at)
            db.commit()

            raw_deleted = stream.prune_retention_phase(db, "raw_time", now=fixed_now)
            depth_deleted = stream.prune_retention_phase(db, "depth_time", now=fixed_now)
            db.commit()
            raw_remaining = {
                row[0] for row in db.execute("SELECT token_id FROM book_snapshots")
            }
            depth_remaining = {
                row[0] for row in db.execute("SELECT token_id FROM orderbook_levels")
            }
        finally:
            db.close()

        self.assertEqual(raw_deleted, 1)
        self.assertEqual(depth_deleted, 1)
        self.assertEqual(raw_remaining, {"raw-boundary"})
        self.assertEqual(depth_remaining, {"depth-boundary"})

    def test_bar_time_and_row_caps_keep_exact_sla_boundaries(self):
        fixed_now = datetime(2026, 8, 10, 12, 0, tzinfo=UTC)
        db = stream.connect()
        try:
            cases = (
                (60, 6, "bar60", "bar60_time", "minute"),
                (300, 7, "bar300", "bar300_time", "five"),
            )
            for interval, days, _cap_phase, _time_phase, prefix in cases:
                cutoff = fixed_now - timedelta(days=days)
                for suffix, captured_at in (
                    ("old", cutoff - timedelta(seconds=1)),
                    ("boundary", cutoff),
                    ("inside", cutoff + timedelta(seconds=1)),
                ):
                    token = f"{prefix}-{suffix}"
                    stamp = captured_at.isoformat()
                    db.execute(
                        """INSERT INTO book_price_bars VALUES
                        (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (
                            interval, stamp, "market", token,
                            0.305, 0.305, 0.305, 0.305, 0.30, 0.31,
                            10, 11, 0.01, 0.01, 1, stamp,
                        ),
                    )
            db.commit()

            with (
                patch.object(stream, "MINUTE_BAR_RETENTION_DAYS", 6),
                patch.object(stream, "FIVE_MINUTE_BAR_RETENTION_DAYS", 7),
                patch.object(stream, "MAX_MINUTE_BAR_ROWS", 1),
                patch.object(stream, "MAX_FIVE_MINUTE_BAR_ROWS", 1),
                patch.object(stream, "ROW_CAP_HEADROOM", 0),
                patch.object(stream, "PRUNE_BATCH_ROWS", 100),
            ):
                results = {}
                for _interval, _days, cap_phase, time_phase, prefix in cases:
                    results[f"{prefix}_cap"] = stream.enforce_row_cap_phase(
                        db, cap_phase, headroom=False, now=fixed_now
                    )
                    results[f"{prefix}_time"] = stream.prune_retention_phase(
                        db, time_phase, now=fixed_now
                    )
                db.commit()

            remaining = {
                row[0] for row in db.execute("SELECT token_id FROM book_price_bars")
            }
        finally:
            db.close()

        self.assertEqual(results, {
            "minute_cap": 1,
            "minute_time": 0,
            "five_cap": 1,
            "five_time": 0,
        })
        self.assertEqual(
            remaining,
            {"minute-boundary", "minute-inside", "five-boundary", "five-inside"},
        )

    def _assert_effective_window_protected(
        self,
        *,
        phase: str,
        retention_name: str,
        retention_value: int,
        window: timedelta,
        table: str,
        interval: int | None = None,
    ) -> None:
        fixed_now = datetime(2026, 8, 10, 12, 0, tzinfo=UTC)
        cutoff = fixed_now - window
        db = stream.connect()
        try:
            for suffix, captured_at in (
                ("outside", cutoff - timedelta(seconds=1)),
                ("boundary", cutoff),
                ("inside", cutoff + timedelta(seconds=1)),
            ):
                token = f"{phase}-{suffix}"
                stamp = captured_at.isoformat()
                if table == "book_snapshots":
                    db.execute(
                        "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
                        (stamp, "market", token, 0.30, 0.31, 10, 11, "test", 0),
                    )
                elif table == "orderbook_levels":
                    db.execute(
                        "INSERT INTO orderbook_levels VALUES (?,?,?,?,?,?)",
                        (stamp, "market", token, "bid", 0.30, 10),
                    )
                else:
                    db.execute(
                        """INSERT INTO book_price_bars VALUES
                        (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (
                            interval, stamp, "market", token,
                            0.305, 0.305, 0.305, 0.305, 0.30, 0.31,
                            10, 11, 0.01, 0.01, 1, stamp,
                        ),
                    )
            db.commit()
            ceiling_name = {
                "raw": "MAX_RAW_QUOTE_ROWS",
                "depth": "MAX_DEPTH_ROWS",
                "bar60": "MAX_MINUTE_BAR_ROWS",
                "bar300": "MAX_FIVE_MINUTE_BAR_ROWS",
            }[phase]
            with (
                patch.object(stream, retention_name, retention_value),
                patch.object(stream, ceiling_name, 1),
                patch.object(stream, "ROW_CAP_HEADROOM", 0),
                patch.object(stream, "PRUNE_BATCH_ROWS", 100),
            ):
                deleted = stream.enforce_row_cap_phase(
                    db, phase, headroom=False, now=fixed_now
                )
                db.commit()
            interval_filter = (
                " WHERE interval_seconds=?" if interval is not None else ""
            )
            params = (interval,) if interval is not None else ()
            remaining = {
                row[0] for row in db.execute(
                    f"SELECT token_id FROM {table}{interval_filter}", params
                )
            }
        finally:
            db.close()

        self.assertEqual(deleted, 1)
        self.assertEqual(remaining, {f"{phase}-boundary", f"{phase}-inside"})

    def test_raw_cap_protects_explicit_twelve_hour_window(self):
        self._assert_effective_window_protected(
            phase="raw",
            retention_name="RAW_QUOTE_RETENTION_HOURS",
            retention_value=12,
            window=timedelta(hours=12),
            table="book_snapshots",
        )

    def test_depth_cap_protects_explicit_twelve_hour_window(self):
        self._assert_effective_window_protected(
            phase="depth",
            retention_name="DEPTH_RETENTION_HOURS",
            retention_value=12,
            window=timedelta(hours=12),
            table="orderbook_levels",
        )

    def test_minute_cap_protects_explicit_ten_day_window(self):
        self._assert_effective_window_protected(
            phase="bar60",
            retention_name="MINUTE_BAR_RETENTION_DAYS",
            retention_value=10,
            window=timedelta(days=10),
            table="book_price_bars",
            interval=60,
        )

    def test_five_minute_cap_protects_explicit_fourteen_day_window(self):
        self._assert_effective_window_protected(
            phase="bar300",
            retention_name="FIVE_MINUTE_BAR_RETENTION_DAYS",
            retention_value=14,
            window=timedelta(days=14),
            table="book_price_bars",
            interval=300,
        )

    def test_five_minute_cap_protects_explicit_180_day_window(self):
        fixed_now = datetime(2026, 8, 10, 12, 0, tzinfo=UTC)
        cases = (
            ("outside", fixed_now - timedelta(days=180, seconds=1)),
            ("boundary", fixed_now - timedelta(days=180)),
            ("seven-days", fixed_now - timedelta(days=7)),
        )
        db = stream.connect()
        try:
            for suffix, captured_at in cases:
                stamp = captured_at.isoformat()
                db.execute(
                    """INSERT INTO book_price_bars VALUES
                    (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        300, stamp, "market", f"bar300-180-{suffix}",
                        0.305, 0.305, 0.305, 0.305, 0.30, 0.31,
                        10, 11, 0.01, 0.01, 1, stamp,
                    ),
                )
            db.commit()
            with (
                patch.object(stream, "FIVE_MINUTE_BAR_RETENTION_DAYS", 180),
                patch.object(stream, "MAX_FIVE_MINUTE_BAR_ROWS", 1),
                patch.object(stream, "ROW_CAP_HEADROOM", 0),
                patch.object(stream, "PRUNE_BATCH_ROWS", 100),
            ):
                deleted = stream.enforce_row_cap_phase(
                    db, "bar300", headroom=False, now=fixed_now
                )
                db.commit()
            remaining = {
                row[0] for row in db.execute(
                    "SELECT token_id FROM book_price_bars "
                    "WHERE interval_seconds=300"
                )
            }
        finally:
            db.close()

        self.assertEqual(deleted, 1)
        self.assertEqual(remaining, {
            "bar300-180-boundary",
            "bar300-180-seven-days",
        })


class MaintenanceCapacityTests(TemporaryRealtimeDatabaseMixin, unittest.TestCase):
    def test_representative_sqlite_maintenance_catches_up_and_is_cumulative(self):
        db = stream.connect()
        old_start = datetime(2026, 1, 1, tzinfo=UTC)
        try:
            db.executemany(
                "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
                [
                    (
                        (old_start + timedelta(seconds=index)).isoformat(),
                        "market", f"old-{index}", 0.30, 0.31, 10, 11, "test", 0,
                    )
                    for index in range(2_500)
                ],
            )
            db.commit()
            writer = stream.PersistenceWriter()
            with (
                patch.object(stream, "MAX_RAW_QUOTE_ROWS", 500),
                patch.object(stream, "ROW_CAP_HEADROOM", 0),
                patch.object(stream, "PRUNE_BATCH_ROWS", 1_000),
                patch.object(stream, "MAINTENANCE_BUDGET_SECONDS", 1.0),
            ):
                completed = []
                maintenance_started = time.monotonic()
                for _ in range(4):
                    completed.append(writer._run_bounded_maintenance(
                        db,
                        "capacity/raw",
                        lambda connection, *, should_yield:
                            stream.enforce_row_cap_phase(
                                connection,
                                "raw",
                                should_yield=should_yield,
                                headroom=False,
                            ),
                    ))
                    if db.execute("SELECT COUNT(*) FROM book_snapshots").fetchone()[0] <= 500:
                        break
                maintenance_seconds = time.monotonic() - maintenance_started
            remaining = db.execute("SELECT COUNT(*) FROM book_snapshots").fetchone()[0]
            metrics = writer.maintenance_snapshot()
        finally:
            db.close()

        self.assertTrue(all(completed))
        self.assertEqual(remaining, 500)
        self.assertEqual(metrics["rows_deleted_total"], 2_000)
        self.assertEqual(metrics["runs"], 2)
        self.assertEqual(metrics["overruns"], 0)
        self.assertEqual(metrics["failures"], 0)
        self.assertGreater(2_000 / maintenance_seconds, NORMAL_RAW_ROWS_PER_HOUR / 3600)
        print(
            "BE04_MAINTENANCE_METRICS",
            {
                "rows_deleted": 2_000,
                "slices": metrics["runs"],
                "seconds": round(maintenance_seconds, 4),
                "rows_per_second": round(2_000 / maintenance_seconds, 1),
                "normal_raw_rows_per_second": round(
                    NORMAL_RAW_ROWS_PER_HOUR / 3600, 2
                ),
                "preemptions": metrics["preemptions"],
                "overruns": metrics["overruns"],
                "failures": metrics["failures"],
            },
        )

    def test_real_writer_schedule_drains_stale_backlog_after_scaled_normal_load(self):
        time_scale = 5
        scaled_cap_interval = 5.0 / time_scale
        scaled_retention_interval = 600.0 / time_scale
        scaled_retry_interval = 1.0 / time_scale
        scaled_rows_per_second = NORMAL_RAW_ROWS_PER_HOUR / 3600 * time_scale
        producer_seconds = 1.0
        producer_events = math.ceil(scaled_rows_per_second * producer_seconds)
        initial_stale = 2_500
        target_cap = 500
        old_start = datetime(2026, 1, 1, tzinfo=UTC)

        bootstrap = stream.connect()
        bootstrap.executemany(
            "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
            [
                (
                    (old_start + timedelta(seconds=index)).isoformat(),
                    "old-market", f"stale-{index}", 0.30, 0.31,
                    10, 11, "stale-backlog", 0,
                )
                for index in range(initial_stale)
            ],
        )
        bootstrap.executemany(
            """INSERT INTO book_price_bars VALUES
            (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            [
                (
                    300,
                    (
                        old_start + timedelta(seconds=index)
                    ).replace(
                        minute=(
                            (old_start + timedelta(seconds=index)).minute // 5
                        ) * 5,
                        second=0,
                        microsecond=0,
                    ).isoformat(),
                    "old-market", f"stale-{index}",
                    0.305, 0.305, 0.305, 0.305, 0.30, 0.31,
                    10, 11, 0.01, 0.01, 1,
                    (old_start + timedelta(seconds=index)).isoformat(),
                )
                for index in range(initial_stale)
            ],
        )
        bootstrap.commit()
        bootstrap.close()

        writer = stream.PersistenceWriter(maxsize=5_000)
        committed = []
        writer.on_committed = lambda event: committed.append(event["token"])
        actual_enforce = stream.enforce_row_cap_phase
        actual_prune = stream.prune_retention_phase
        capacity_phases = []
        retention_phases = []

        def tracked_enforce(connection, phase, **kwargs):
            capacity_phases.append(phase)
            return actual_enforce(connection, phase, **kwargs)

        def tracked_prune(connection, phase, **kwargs):
            retention_phases.append(phase)
            return actual_prune(connection, phase, **kwargs)

        producer_done = threading.Event()
        base = datetime(2026, 8, 10, 12, 0, tzinfo=UTC)

        def produce() -> None:
            batch_size = 10
            for batch_start in range(0, producer_events, batch_size):
                for index in range(
                    batch_start, min(batch_start + batch_size, producer_events)
                ):
                    accepted = writer.submit(quote_event(
                        f"live-{index % TOKEN_COUNT}",
                        base + timedelta(milliseconds=index),
                    ))
                    if not accepted:
                        producer_done.set()
                        return
                time.sleep(batch_size / scaled_rows_per_second)
            writer.submit_connection_event(
                "scaled_normal_load_complete",
                "5x time-compressed normal writer schedule",
            )
            producer_done.set()

        def persisted_counts() -> tuple[int, int]:
            with closing(sqlite3.connect(
                f"file:{self.database_path}?mode=ro", uri=True, timeout=0.2
            )) as observer:
                total, stale = observer.execute(
                    "SELECT COUNT(*),SUM(event_reason='stale-backlog') "
                    "FROM book_snapshots"
                ).fetchone()
                return int(total), int(stale or 0)

        initial_backlog = max(0, initial_stale - target_cap)
        backlog_samples = [initial_backlog]
        stale_samples = [initial_stale]
        producer = threading.Thread(target=produce, name="capacity-normal-producer")
        final_queue = -1
        health_before_close = "unknown"
        drain_started = 0.0
        try:
            with (
                patch.object(stream, "MAX_RAW_QUOTE_ROWS", target_cap),
                patch.object(stream, "ROW_CAP_HEADROOM", 0),
                patch.object(stream, "ROW_CAP_ENFORCE_SECONDS", scaled_cap_interval),
                patch.object(
                    stream, "MAINTENANCE_INTERVAL_SECONDS",
                    scaled_retention_interval,
                ),
                patch.object(
                    stream, "MAINTENANCE_RETRY_SECONDS", scaled_retry_interval
                ),
                patch.object(stream, "MAINTENANCE_BUDGET_SECONDS", 0.1),
                patch.object(stream, "PRUNE_BATCH_ROWS", 1_000),
                patch.object(stream, "enforce_row_cap_phase", side_effect=tracked_enforce),
                patch.object(stream, "prune_retention_phase", side_effect=tracked_prune),
            ):
                writer.start()
                producer.start()
                while not producer_done.wait(timeout=0.05):
                    total, stale = persisted_counts()
                    backlog_samples.append(max(0, total - target_cap))
                    stale_samples.append(stale)
                producer.join(timeout=2)
                drain_started = time.monotonic()
                # The 5x clock compression preserves the production ratios:
                # capacity 5s -> 1s, retention 600s -> 120s and retry
                # 1s -> 0.2s.  The writer intentionally retains its existing
                # 30-second startup grace before the first retention cycle.
                deadline = drain_started + 35.0
                while time.monotonic() < deadline:
                    total, stale = persisted_counts()
                    current_backlog = max(0, total - target_cap)
                    backlog_samples.append(current_backlog)
                    stale_samples.append(stale)
                    if (
                        current_backlog == 0
                        and stale == 0
                        and writer.events.empty()
                        and set(capacity_phases) == set(stream.CAPACITY_PHASES)
                    ):
                        break
                    time.sleep(0.05)
                drain_seconds = time.monotonic() - drain_started
                final_backlog = backlog_samples[-1]
                final_stale = stale_samples[-1]
                final_queue = writer.events.qsize()
                health_before_close = writer.health()
                metrics = writer.maintenance_snapshot()
        finally:
            producer.join(timeout=2)
            writer.close()

        self.assertEqual(stream.MAINTENANCE_BUDGET_SECONDS, 0.1)
        self.assertEqual(producer_events, 103)
        self.assertGreater(len(committed), 0)
        self.assertLess(min(backlog_samples[1:]), initial_backlog)
        self.assertLess(final_stale, initial_stale)
        self.assertEqual(final_backlog, 0)
        self.assertEqual(
            final_stale, 0,
            {
                "retention_phases": retention_phases,
                "capacity_phase_count": len(capacity_phases),
                "maintenance": metrics,
            },
        )
        self.assertLess(drain_seconds, 35.0)
        self.assertEqual(set(capacity_phases), set(stream.CAPACITY_PHASES))
        self.assertIn("raw_time", retention_phases)
        self.assertGreaterEqual(metrics["runs"], len(stream.CAPACITY_PHASES))
        self.assertGreater(metrics["rows_deleted_total"], 0)
        self.assertGreater(metrics["queue_peak"], 0)
        self.assertEqual(final_queue, 0)
        self.assertEqual(writer.dropped_critical, 0)
        self.assertEqual(writer.dropped_heartbeats, 0)
        self.assertEqual(health_before_close, "ok")
        self.assertFalse(writer.thread.is_alive())
        print(
            "BE04_REAL_WRITER_MAINTENANCE_METRICS",
            {
                "time_scale": time_scale,
                "cap_interval_seconds": scaled_cap_interval,
                "retention_interval_seconds": scaled_retention_interval,
                "retry_interval_seconds": scaled_retry_interval,
                "producer_seconds": producer_seconds,
                "producer_events": producer_events,
                "initial_capacity_backlog": initial_backlog,
                "minimum_capacity_backlog": min(backlog_samples[1:]),
                "final_capacity_backlog": final_backlog,
                "initial_stale_rows": initial_stale,
                "final_stale": final_stale,
                "drain_seconds": round(drain_seconds, 3),
                "capacity_phase_counts": {
                    phase: capacity_phases.count(phase)
                    for phase in stream.CAPACITY_PHASES
                },
                "retention_phases": retention_phases,
                "maintenance_runs": metrics["runs"],
                "preemptions": metrics["preemptions"],
                "overruns": metrics["overruns"],
                "rows_deleted_total": metrics["rows_deleted_total"],
                "queue_peak": metrics["queue_peak"],
                "queue_final": final_queue,
                "dropped_critical": writer.dropped_critical,
                "dropped_heartbeats": writer.dropped_heartbeats,
                "writer_health": health_before_close,
            },
        )


class _SlowClient:
    def __init__(self) -> None:
        self.closed = False
        self.release = asyncio.Event()

    async def send(self, _payload: str) -> None:
        await self.release.wait()

    async def close(self, **_kwargs) -> None:
        self.closed = True
        self.release.set()


class _BadClient:
    closed = False

    async def send(self, _payload: str) -> None:
        raise ConnectionError("closed capacity client")

    async def close(self, **_kwargs) -> None:
        self.closed = True


class TwoTimesWriterPressureTests(
    TemporaryRealtimeDatabaseMixin, unittest.IsolatedAsyncioTestCase
):
    async def test_explicit_two_x_five_minute_pressure_recovers_without_drop(self):
        writer = stream.PersistenceWriter(maxsize=20_000)
        progress = Mock()
        hub = stream.LiveStateHub()
        hub.client_queue_size = 4
        slow_client = _SlowClient()
        bad_client = _BadClient()
        hub._register_client(slow_client)
        hub._register_client(bad_client)

        bbo_events = math.ceil(
            NORMAL_RAW_ROWS_PER_HOUR
            * STRESS_MULTIPLIER
            * STRESS_LOGICAL_SECONDS
            / 3600
        )
        depth_snapshots = math.ceil(
            TOKEN_COUNT
            * STRESS_MULTIPLIER
            * STRESS_LOGICAL_SECONDS
            / stream.DEPTH_SNAPSHOT_SECONDS
        )
        started_at = datetime(2026, 8, 10, 12, 0, tzinfo=UTC)
        bbo_step = 3600 / (NORMAL_RAW_ROWS_PER_HOUR * STRESS_MULTIPLIER)
        depth_step = stream.DEPTH_SNAPSHOT_SECONDS / (TOKEN_COUNT * STRESS_MULTIPLIER)
        events = [
            quote_event(
                f"token-{index % TOKEN_COUNT}",
                started_at + timedelta(seconds=index * bbo_step),
            )
            for index in range(bbo_events)
        ]
        events.extend(
            quote_event(
                f"token-{index % TOKEN_COUNT}",
                started_at + timedelta(seconds=index * depth_step),
                depth=True,
            )
            for index in range(depth_snapshots)
        )
        events.sort(key=lambda event: event["captured_at"])

        loop_ticks = 0
        heartbeat_attempts = 0
        database_peak = 0
        wal_peak = 0
        bootstrap = stream.connect()
        bootstrap.execute("PRAGMA journal_mode=WAL").fetchone()
        bootstrap.close()
        writer.start()
        try:
            async def event_loop_probe() -> None:
                nonlocal loop_ticks, heartbeat_attempts, database_peak, wal_peak
                while not producer_done.is_set():
                    loop_ticks += 1
                    heartbeat_attempts += 1
                    stream.runtime_heartbeat(writer, "capacity-pressure", progress)
                    hub.record_quote(quote_event(
                        f"probe-{loop_ticks % TOKEN_COUNT}",
                        datetime.now(UTC),
                    ))
                    if self.database_path.exists():
                        database_peak = max(database_peak, self.database_path.stat().st_size)
                    wal_path = Path(str(self.database_path) + "-wal")
                    if wal_path.exists():
                        wal_peak = max(wal_peak, wal_path.stat().st_size)
                    await asyncio.sleep(0.002)

            producer_done = asyncio.Event()

            def produce() -> None:
                for index, event in enumerate(events, start=1):
                    if not writer.submit(event):
                        break
                    if index % 100 == 0:
                        time.sleep(0.001)

            probe_task = asyncio.create_task(event_loop_probe())
            await asyncio.to_thread(produce)
            producer_done.set()
            await probe_task
            marker_accepted = writer.submit_connection_event(
                "capacity_probe_complete",
                "2x logical five-minute replay complete",
            )
            self.assertTrue(marker_accepted)

            drain_started = time.monotonic()
            marker_seen = False
            final_counts = {}
            while time.monotonic() - drain_started < 15:
                if self.database_path.exists():
                    database_peak = max(database_peak, self.database_path.stat().st_size)
                    wal_path = Path(str(self.database_path) + "-wal")
                    if wal_path.exists():
                        wal_peak = max(wal_peak, wal_path.stat().st_size)
                    try:
                        with closing(sqlite3.connect(
                            f"file:{self.database_path}?mode=ro", uri=True, timeout=0.1
                        )) as observer:
                            marker_seen = observer.execute(
                                "SELECT 1 FROM stream_connection_events "
                                "WHERE event_type='capacity_probe_complete'"
                            ).fetchone() is not None
                            if marker_seen:
                                final_counts = {
                                    "raw": observer.execute(
                                        "SELECT COUNT(*) FROM book_snapshots"
                                    ).fetchone()[0],
                                    "depth": observer.execute(
                                        "SELECT COUNT(*) FROM orderbook_levels"
                                    ).fetchone()[0],
                                    "bar60": observer.execute(
                                        "SELECT COUNT(*) FROM book_price_bars "
                                        "WHERE interval_seconds=60"
                                    ).fetchone()[0],
                                    "bar300": observer.execute(
                                        "SELECT COUNT(*) FROM book_price_bars "
                                        "WHERE interval_seconds=300"
                                    ).fetchone()[0],
                                }
                    except sqlite3.Error:
                        marker_seen = False
                if marker_seen and writer.events.empty():
                    break
                await asyncio.sleep(0.02)
            drain_seconds = time.monotonic() - drain_started
            health_before_close = writer.health()
            queue_peak = writer.maintenance_snapshot()["queue_peak"]
        finally:
            await hub.close()
            writer.close()

        self.assertEqual(bbo_events, 12_313)
        self.assertEqual(depth_snapshots, 616)
        self.assertEqual(len(events), 12_929)
        self.assertTrue(marker_seen)
        self.assertGreater(final_counts["raw"], 0)
        self.assertGreater(final_counts["depth"], 0)
        self.assertGreater(final_counts["bar60"], 0)
        self.assertGreater(final_counts["bar300"], 0)
        self.assertLess(drain_seconds, 15)
        self.assertGreater(queue_peak, 0)
        self.assertTrue(writer.events.empty())
        self.assertEqual(writer.dropped_critical, 0)
        self.assertEqual(writer.dropped_heartbeats, 0)
        self.assertEqual(health_before_close, "ok")
        self.assertFalse(writer.thread.is_alive())
        self.assertGreaterEqual(loop_ticks, 10)
        self.assertGreaterEqual(heartbeat_attempts, 10)
        self.assertEqual(progress.publish.call_count, heartbeat_attempts)
        self.assertGreaterEqual(hub.client_send_failures, 1)
        self.assertNotIn(slow_client, hub.clients)
        self.assertNotIn(bad_client, hub.clients)
        self.assertGreater(database_peak, 0)
        self.assertGreater(wal_peak, 0)
        print(
            "BE04_CAPACITY_METRICS",
            {
                "logical_seconds": STRESS_LOGICAL_SECONDS,
                "bbo_events": bbo_events,
                "depth_snapshots": depth_snapshots,
                "depth_rows": depth_snapshots * DEPTH_LEVELS_PER_SNAPSHOT,
                "queue_peak": queue_peak,
                "drain_seconds": round(drain_seconds, 3),
                "database_peak_bytes": database_peak,
                "wal_peak_bytes": wal_peak,
                "final_counts": final_counts,
                "loop_ticks": loop_ticks,
                "heartbeat_attempts": heartbeat_attempts,
                "dropped_critical": writer.dropped_critical,
            },
        )


if __name__ == "__main__":
    unittest.main()
