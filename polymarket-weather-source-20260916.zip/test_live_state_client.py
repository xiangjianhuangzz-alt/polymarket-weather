import threading
import time
import unittest

from dashboard_modern import prefer_projected_quote
from live_state_client import LiveQuoteStore


class LiveQuoteStoreTests(unittest.TestCase):
    def test_snapshot_and_delta_are_bounded_and_fresh(self):
        store = LiveQuoteStore()
        store.mark_connected()
        self.assertTrue(store.apply({"type": "snapshot", "quotes": [
            {"token_id": "a", "bid": .20, "ask": .21, "captured_at": "2026-07-22T00:00:00+00:00"}],
            "shadow": {"state": "shadow"}}))
        self.assertTrue(store.apply({"type": "bbo", "token_id": "a", "bid": .22, "ask": .23,
                                     "captured_at": "2026-07-22T00:00:05+00:00"}))
        view = store.view()
        self.assertEqual(view["state"], "healthy")
        self.assertEqual(view["quotes"]["a"]["bid"], .22)
        self.assertEqual(view["revision"], 3)

    def test_unknown_message_cannot_change_quotes(self):
        store = LiveQuoteStore()
        store.mark_connected()
        self.assertFalse(store.apply({"type": "order", "token_id": "a"}))
        self.assertEqual(store.view()["quotes"], {})

    def test_wait_for_revision_wakes_on_quote_and_reports_changed_token(self):
        store = LiveQuoteStore()
        revision = store.view()["revision"]

        def publish():
            time.sleep(0.03)
            store.apply({
                "type": "bbo", "schema": 2, "stream_id": "run",
                "sequence": 1, "token_id": "a",
                "captured_at": "2026-07-22T00:00:00+00:00",
            })

        worker = threading.Thread(target=publish)
        worker.start()
        view = store.wait_for_revision(revision, timeout=0.5)
        worker.join()

        self.assertIn("a", view["changed_tokens"])
        self.assertGreater(view["revision"], revision)

    def test_upstream_disconnect_fails_closed_without_deleting_quote(self):
        store = LiveQuoteStore()
        store.mark_connected()
        store.apply({
            "type": "snapshot", "schema": 2, "stream_id": "run",
            "sequence": 1, "upstream": {"connected": True},
            "quotes": [{"type": "bbo", "schema": 2, "stream_id": "run",
                        "sequence": 1, "token_id": "a",
                        "captured_at": "2026-07-22T00:00:00+00:00"}],
        })
        self.assertEqual(store.view()["state"], "healthy")

        store.apply({
            "type": "status", "schema": 2, "stream_id": "run",
            "sequence": 2,
            "upstream": {"connected": False, "detail": "reset"},
        })

        view = store.view()
        self.assertEqual(view["state"], "recovering")
        self.assertIn("a", view["quotes"])

    def test_older_delta_cannot_roll_quote_back(self):
        store = LiveQuoteStore()
        store.mark_connected()
        store.apply({"type": "bbo", "token_id": "a", "bid": .30, "ask": .31,
                     "captured_at": "2026-07-22T00:00:10+00:00"})
        self.assertFalse(store.apply(
            {"type": "bbo", "token_id": "a", "bid": .20, "ask": .21,
             "captured_at": "2026-07-22T00:00:05+00:00"}
        ))
        self.assertEqual(store.view()["quotes"]["a"]["bid"], .30)

    def test_snapshot_prunes_membership_without_regressing_active_quote(self):
        store = LiveQuoteStore()
        store.mark_connected()
        store.apply({"type": "snapshot", "quotes": [
            {"token_id": "old", "bid": .10, "captured_at": "2026-07-22T00:00:00+00:00"},
            {"token_id": "active", "bid": .30, "captured_at": "2026-07-22T00:00:10+00:00"},
        ]})
        store.apply({"type": "snapshot", "quotes": [
            {"token_id": "active", "bid": .20, "captured_at": "2026-07-22T00:00:05+00:00"},
        ]})
        view = store.view()
        self.assertEqual(set(view["quotes"]), {"active"})
        self.assertEqual(view["quotes"]["active"]["bid"], .30)

    def test_connection_state_changes_revision(self):
        store = LiveQuoteStore()
        start = store.view()["revision"]
        store.mark_connected()
        connected = store.view()["revision"]
        store.mark_disconnected("ConnectionClosed")
        self.assertGreater(connected, start)
        self.assertGreater(store.view()["revision"], connected)

    def test_reconnect_requires_a_new_message_before_becoming_healthy(self):
        store = LiveQuoteStore()
        store.mark_connected()
        store.apply({
            "type": "snapshot",
            "quotes": [{"token_id": "a", "captured_at": "2026-07-22T00:00:00+00:00"}],
        })
        self.assertEqual(store.view()["state"], "healthy")

        store.mark_disconnected("ConnectionClosed")
        self.assertEqual(store.view()["state"], "offline")
        store.mark_connected()
        reconnecting = store.view()
        self.assertEqual(reconnecting["state"], "recovering")
        self.assertIn("a", reconnecting["quotes"])

        store.apply({
            "type": "snapshot",
            "quotes": [{"token_id": "a", "captured_at": "2026-07-22T00:00:05+00:00"}],
        })
        self.assertEqual(store.view()["state"], "healthy")

    def test_durable_recovery_cannot_replace_newer_projected_quote(self):
        projected = {"captured_at": "2026-07-22T00:00:10+00:00"}
        older_durable = (.20, .21, 5, 6, "2026-07-22T00:00:05+00:00")
        newer_durable = (.30, .31, 5, 6, "2026-07-22T00:00:15+00:00")
        self.assertTrue(prefer_projected_quote(projected, older_durable))
        self.assertFalse(prefer_projected_quote(projected, newer_durable))


if __name__ == "__main__":
    unittest.main()
