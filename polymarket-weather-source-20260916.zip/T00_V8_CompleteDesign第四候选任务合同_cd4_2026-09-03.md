# T00｜V8 Complete Design 第四候选任务合同（cd4）｜2026-09-03

## 1. 阶段与范围

```text
CURRENT_STAGE=COMPLETE_DESIGN
ROUND=CD4_SINGLE_BLOCKER_CLOSURE
ONLY_ROOT_BLOCKER=CD-06_PATH_POLICY_LOGICAL_ROOT_CONTRACT
```

cd1、cd2、cd3均为冻结历史候选，不得修改。本轮仅替换cd3的CD-06；CD-01至CD-05的规范对象保持不变。实际DDL、实现、测试、故障注入、Windows绝对路径、部署URI、ACL现场配置、目录存在性和部署脚本均不属于本轮。

## 2. 绑定基线

```text
branch=codex/handoff-baseline-20260809
HEAD=13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
ak2_sha256=e01d30534b8b1de77ac4c426d925dda222a0c772540fb09b6425d39fab11308d
cd3_canonical_sha256=310199043bb9e96a3a2afaa40fc59707668cfa5e957240b39fc0b555dfe76daa
AS_OF=2026-09-02T17:32:22.159Z
```

## 3. 唯一规范源

cd4的唯一机器可读规范源为：

```text
T00_新动态策略CompleteDesign规范_cd4_2026-09-03.json
```

本任务合同和Manifest仅说明任务边界与候选身份，不得成为第二套业务规范。

## 4. CD-06唯一裁决

```text
TREE_ROOT_TARGET_ID=release_root
RUNTIME_BASE_TARGET_ID=runtime_root
runtime_root.parent_target_id=release_root
```

- `release_root`是唯一`parent_target_id=null`的逻辑目标。
- `runtime_root`是Runtime Base/Anchor，不是整棵逻辑目标树的根。
- `PATH_TARGET_REGISTRY`恰好包含ak2 R08的10个目录和10个数据库逻辑目标。
- 每个非root目标恰好一个已存在父目标；父图必须无环并最终到达`release_root`。
- PathPolicy身份必须绑定规范排序的完整目标集合及父关系，不允许自引用hash。
- unknown、duplicate、missing parent、multiple roots、cycle、orphan、incomplete registry或hash不符统一为现有`E_PATH_POLICY_INVALID_FAIL_CLOSED`。

## 5. 关闭标准

```text
CD06_LOGICAL_TREE_UNIQUE=YES
CD06_EXACT_20_TARGET_REGISTRY_FROZEN=YES
CD06_RUNTIME_BASE_DISTINCT_FROM_TREE_ROOT=YES
CAN_TWO_IMPLEMENTERS_STILL_DIVERGE=NO
CD06_STATUS=CLOSED_PENDING_QA
```

## 6. 路由与停止点

```text
BE=CD06_SPECIALIST_PROPOSAL_COMPLETE
T01=CD4_INTEGRATION_REVIEW_PASS
QA=ONLY_AFTER_CD4_FREEZE
```

QA如FAIL，本轮停止，不创建cd5。QA如PASS，仅可记录Complete Design已独立验证并接受；不得自动开始实现、测试、Git写入或部署。

## 7. 权限状态

```text
IMPLEMENTATION_AUTHORIZED=NO
TEST_EXECUTION_AUTHORIZED=NO
GIT_WRITE_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
SHADOW_AUTHORIZED=NO
PAPER_AUTHORIZED=NO
LIVE_TRADING_AUTHORIZED=NO
```
