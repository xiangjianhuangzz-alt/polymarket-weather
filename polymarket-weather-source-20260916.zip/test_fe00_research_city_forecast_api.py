from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import dashboard_modern


TARGET = "2026-08-13"
TEN = (
    ("Beijing", "ZBAA", "weatherol_beijing"),
    ("Shanghai", "ZSPD", "weatherol_shanghai"),
    ("Chengdu", "ZUUU", "weatherol_chengdu"),
    ("Guangzhou", "ZGGG", "weatherol_guangzhou"),
    ("Shenzhen", "ZGSZ", "weatherol_shenzhen"),
    ("Wuhan", "ZHHH", "weatherol_wuhan"),
    ("Chongqing", "ZUCK", "weatherol_chongqing"),
    ("Jinan", "ZSJN", "weatherol_jinan"),
    ("Qingdao", "ZSQD", None),
    ("Zhengzhou", "ZHCC", "weatherol_zhengzhou"),
)


class ResearchCityForecastApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.research = Path(self.tmp.name) / "research.sqlite3"
        self.realtime = Path(self.tmp.name) / "realtime.sqlite3"
        db = sqlite3.connect(self.research)
        db.executescript("""
          CREATE TABLE market_snapshots (market_id TEXT, city TEXT, bucket_label TEXT,
            question TEXT, tokens_json TEXT, outcomes_json TEXT, liquidity REAL, captured_at TEXT, active INTEGER);
          CREATE TABLE forecast_d0_registry (source TEXT, city TEXT, station TEXT, target_date TEXT,
            grid_version TEXT, status TEXT, forecast_high_c REAL, forecast_bucket INTEGER,
            source_reported_at TEXT, first_captured_at TEXT, capture_delay_seconds REAL,
            content_hash TEXT, reason TEXT, frozen_at TEXT, latest_checked_at TEXT);
          CREATE TABLE forecast_snapshots (city TEXT, model TEXT, forecast_json TEXT, captured_at TEXT);
          CREATE TABLE forecast_update_values (source TEXT, city TEXT, station TEXT, target_date TEXT,
            forecast_high_c REAL, captured_at TEXT);
          CREATE TABLE forecast_versions (version_id TEXT, source TEXT, city TEXT, station TEXT,
            target_date TEXT, forecast_high_c REAL, content_hash TEXT, first_seen_at TEXT,
            last_seen_at TEXT, source_display_time TEXT, is_change INTEGER);
          CREATE TABLE collector_runs (captured_at TEXT);
          CREATE TABLE service_heartbeats (service TEXT, updated_at TEXT, detail TEXT);
          CREATE TABLE market_resolutions (market_id TEXT, city TEXT, target_date TEXT, bucket_label TEXT,
            yes_resolved INTEGER, resolved_at TEXT, outcome_prices_json TEXT, resolution_source TEXT);
          CREATE TABLE airport_stations (station TEXT, city TEXT);
        """)
        for index, (city, station, qxzx) in enumerate(TEN):
            db.execute("INSERT INTO airport_stations VALUES (?,?)", (station, city))
            for source in ([qxzx] if qxzx else []) + ["aviationweather_taf"]:
                payload = json.dumps({"daily": {"time": [TARGET], "temperature_2m_max": [20 + index]},
                                      "metadata": {"issued_at": "2026-08-13T00:00:00+00:00"}})
                db.execute("INSERT INTO forecast_snapshots VALUES (?,?,?,?)",
                           (station, source, payload, "2026-08-13T01:00:00+00:00"))
                db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                           (source, city, station, TARGET, 20 + index, "2026-08-13T01:00:00+00:00"))
        db.commit(); db.close()
        quote = sqlite3.connect(self.realtime)
        quote.executescript("CREATE TABLE latest_bbo (token_id TEXT,best_bid REAL,best_ask REAL,bid_size REAL,ask_size REAL,captured_at TEXT); CREATE TABLE service_heartbeats (service TEXT,updated_at TEXT,detail TEXT);")
        quote.commit(); quote.close()

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def snapshot(self):
        with patch.object(dashboard_modern, "DB", self.research), \
             patch.object(dashboard_modern, "REALTIME_DB", self.realtime), \
             patch.object(dashboard_modern, "china_now", return_value=datetime(2026, 8, 13, 10, tzinfo=dashboard_modern.CHINA_TZ)), \
             patch.object(dashboard_modern.Api, "actual_snapshot", return_value=[]):
            self.api = dashboard_modern.Api()
            return self.api.snapshot()

    def test_snapshot_accepts_fixed_ten_city_matrix_and_display_names(self) -> None:
        response = self.snapshot()
        self.assertNotIn("error", response)
        facts = {(x["source_key"], x["city"], x["station"], x["date"]): x for x in response["forecasts"]}
        self.assertEqual(len(facts), 19)
        for city, station, qxzx in TEN:
            self.assertIn(("aviationweather_taf", city, station, TARGET), facts)
            if qxzx:
                self.assertIn((qxzx, city, station, TARGET), facts)
        self.assertNotIn("weatherol_qingdao", {x["source_key"] for x in response["forecasts"]})
        names = {x["source_key"]: x["source"] for x in response["updates"]}
        self.assertEqual(names["weatherol_wuhan"], "QXZX（武汉机场）")
        self.assertEqual(names["weatherol_chongqing"], "QXZX（重庆机场）")
        self.assertEqual(names["weatherol_jinan"], "QXZX（济南机场）")
        self.assertEqual(names["weatherol_zhengzhou"], "QXZX（郑州机场）")

    def test_snapshot_rejects_wrong_ownership_and_bad_json_without_cross_city_leak(self) -> None:
        db = sqlite3.connect(self.research)
        db.execute("INSERT INTO forecast_snapshots VALUES (?,?,?,?)", ("ZHHH", "weatherol_chongqing", json.dumps({"daily":{"time":[TARGET],"temperature_2m_max":[98]}}), "2026-08-13T02:00:00+00:00"))
        db.execute("INSERT INTO forecast_snapshots VALUES (?,?,?,?)", ("ZHHH", "weatherol_wuhan", "{bad", "2026-08-13T03:00:00+00:00"))
        db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)", ("aviationweather_taf", "Wuhan", "ZBAA", TARGET, 99, "2026-08-13T02:00:00+00:00"))
        db.commit(); db.close()
        response = self.snapshot()
        self.assertNotIn("error", response)
        self.assertFalse(any(x["high"] == 98.0 for x in response["forecasts"]))
        self.assertTrue(any(x["city"] == "Chongqing" and x["source_key"] == "weatherol_chongqing" for x in response["forecasts"]))
        self.assertFalse(any(x["city"] == "Wuhan" and x["station"] == "ZBAA" for x in response["updates"]))

    def test_d0_v2_new_qxzx_is_real_and_qingdao_remains_not_configured(self) -> None:
        db = sqlite3.connect(self.research)
        for index, (city, station, source) in enumerate(TEN):
            if source:
                db.execute("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                           (source, city, station, TARGET, "g1", "valid_d0", 30 + index, 30 + index,
                            "2026-08-13T00:00:00+00:00", "2026-08-13T00:10:00+00:00", 600,
                            f"hash-{city}", "frozen", "2026-08-13T00:10:00+00:00", "2026-08-13T01:00:00+00:00"))
        db.commit(); db.close()
        with patch.object(dashboard_modern, "DB", self.research), \
             patch.object(dashboard_modern, "_d0_now_iso", return_value="2026-08-13T12:00:00+08:00"):
            api = dashboard_modern.Api(); panel = api.d0_evidence_panel_v2(TARGET)
            for city, station, source in TEN:
                detail = api.d0_evidence_detail_v2(city, TARGET)
                self.assertEqual(detail["sources"], next(x["sources"] for x in panel["cities"] if x["city"] == city))
                qxzx = detail["sources"][0]
                if source:
                    self.assertEqual((qxzx["source"], qxzx["status"], qxzx["station"]), (source, "valid_d0", station))
                else:
                    self.assertEqual((qxzx["source"], qxzx["fetch_health"], qxzx["provenance"]["configured"]), (None, "not_configured", False))

    def test_retirement_dates_switch_api_from_ten_to_eight_to_seven_without_rewriting_history(self) -> None:
        with patch.object(dashboard_modern, "DB", self.research), \
             patch.object(dashboard_modern, "_d0_now_iso", return_value="2026-08-22T06:00:00+08:00"):
            api = dashboard_modern.Api()
            historical = api.d0_evidence_panel_v2("2026-08-13")
            active = api.d0_evidence_panel_v2("2026-08-22")
            current = api.d0_evidence_panel_v2("2026-08-30")
            self.assertEqual(len(historical["cities"]), 10)
            self.assertEqual(len(active["cities"]), 8)
            self.assertEqual(len(current["cities"]), 7)
            self.assertNotIn("Jinan", {row["city"] for row in active["cities"]})
            self.assertNotIn("Qingdao", {row["city"] for row in active["cities"]})
            self.assertIn("Zhengzhou", {row["city"] for row in active["cities"]})
            self.assertNotIn("Zhengzhou", {row["city"] for row in current["cities"]})
            self.assertEqual(
                api.d0_evidence_detail_v2("Jinan", "2026-08-22")["error"]["code"],
                "retired_city",
            )
            self.assertEqual(
                api.d0_evidence_detail_v2("Zhengzhou", "2026-08-30")["error"]["code"],
                "retired_city",
            )
            self.assertEqual(
                api.d0_evidence_detail_v2("Zhengzhou", "2026-08-29")["city"],
                "Zhengzhou",
            )
            self.assertEqual(
                api.d0_evidence_detail_v2("Qingdao", "2026-08-22")["error"]["code"],
                "retired_city",
            )

    def test_snapshot_is_read_only_and_both_connections_close_on_second_open_failure(self) -> None:
        before = hashlib.sha256(self.research.read_bytes()).hexdigest()
        real_connect = sqlite3.connect; opened = []
        def connect(*args, **kwargs):
            if opened:
                raise sqlite3.OperationalError("second open fails")
            conn = real_connect(*args, **kwargs); opened.append(conn); return conn
        with patch.object(dashboard_modern, "DB", self.research), patch.object(dashboard_modern, "REALTIME_DB", self.realtime), \
             patch.object(dashboard_modern.sqlite3, "connect", side_effect=connect):
            response = dashboard_modern.Api().snapshot()
        self.assertIn("error", response)
        with self.assertRaises(sqlite3.ProgrammingError):
            opened[0].execute("SELECT 1")
        self.assertEqual(before, hashlib.sha256(self.research.read_bytes()).hexdigest())

    def test_snapshot_isolates_malformed_forecast_and_update_records(self) -> None:
        db = sqlite3.connect(self.research)
        bad_snapshots = (
            {"daily": {"time": None, "temperature_2m_max": [88]}, "metadata": {}},
            {"daily": {"time": [TARGET], "temperature_2m_max": "31"}, "metadata": {}},
            {"daily": {"time": [TARGET, TARGET], "temperature_2m_max": [31, 32]}, "metadata": {}},
            {"daily": {"time": [" 2026-08-13 "], "temperature_2m_max": [float("nan")]}, "metadata": []},
        )
        for index, payload in enumerate(bad_snapshots):
            db.execute("INSERT INTO forecast_snapshots VALUES (?,?,?,?)",
                       ("ZHHH", "weatherol_wuhan", json.dumps(payload),
                        f"2026-08-13T0{index + 2}:00:00+00:00"))
        db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                   ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, 31, "not-an-iso-time"))
        db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                   ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, "31", "2026-08-13T01:30:00+00:00"))
        db.commit(); db.close()
        response = self.snapshot()
        self.assertNotIn("error", response)
        self.assertTrue(any(x["city"] == "Chongqing" for x in response["forecasts"]))
        self.assertFalse(any(x["city"] == "Wuhan" and x["high"] in {3.0, 31.0, 32.0, 88.0}
                             for x in response["forecasts"]))
        wuhan_updates = [x for x in response["updates"] if x["city"] == "Wuhan"]
        self.assertTrue(wuhan_updates)
        self.assertFalse(any(row["high"] == "31" or row["captured_at"] == "not-an-iso-time"
                             for row in wuhan_updates))
        self.assertFalse(any(record[0] == "Wuhan" and record[2] == "31"
                             for record in self.api._update_records.values()))

    def test_update_labels_and_times_are_matrix_bound_and_invalid_entries_are_isolated(self) -> None:
        db = sqlite3.connect(self.research)
        for city, station, source in TEN[5:]:
            if source:
                db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                           (source, city, station, TARGET, 31, "2026-08-13T02:00:00+00:00"))
        db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                   ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, float("inf"), "2026-08-13T02:00:00+00:00"))
        db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                   ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, 31, "2026-08-12T16:00:00+00:00"))
        db.commit(); db.close()
        response = self.snapshot()
        labels = {row["city"]: row["city_cn"] for row in response["updates"]}
        self.assertEqual({city: labels[city] for city in ("Wuhan", "Chongqing", "Jinan", "Zhengzhou")},
                         {"Wuhan": "武汉", "Chongqing": "重庆", "Jinan": "济南", "Zhengzhou": "郑州"})
        self.assertTrue(all(type(row["high"]) in {int, float} and math.isfinite(row["high"])
                            for row in response["updates"] if row["high"] is not None))

    def test_extreme_times_and_bad_d0_overlay_are_isolated_from_snapshot(self) -> None:
        db = sqlite3.connect(self.research)
        payload = json.dumps({"daily": {"time": [TARGET], "temperature_2m_max": [31]},
                              "metadata": {"issued_at": "9999-12-31T23:59:59-23:59"}})
        db.execute("INSERT INTO forecast_snapshots VALUES (?,?,?,?)",
                   ("ZHHH", "weatherol_wuhan", payload, "2026-08-13T04:00:00+00:00"))
        db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                   ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, 31,
                    "0001-01-01T00:00:00+23:59"))
        db.execute("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, "z9", "valid_d0", 31,
                    "bad-bucket", "9999-12-31T23:59:59-23:59", "2026-08-13T00:10:00+00:00",
                    "bad-delay", "bad", "bad", "2026-08-13T00:10:00+00:00",
                    "2026-08-13T01:00:00+00:00"))
        db.commit(); db.close()
        response = self.snapshot()
        self.assertNotIn("error", response)
        self.assertFalse(any(row["city"] == "Wuhan" and row["high"] == 31.0
                             for row in response["forecasts"]))
        self.assertTrue(any(row["city"] == "Chongqing" for row in response["forecasts"]))

    def test_huge_integer_and_deterministic_registry_overlay_fail_closed(self) -> None:
        db = sqlite3.connect(self.research)
        huge = 10 ** 1000
        bad_payload = '{"daily":{"time":["2026-08-13"],"temperature_2m_max":[' + str(huge) + ']},"metadata":{}}'
        db.execute("INSERT INTO forecast_snapshots VALUES (?,?,?,?)",
                   ("ZHHH", "weatherol_wuhan", bad_payload, "2026-08-13T04:00:00+00:00"))
        db.executemany("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
            ("weatherol_chongqing", "Chongqing", "ZUCK", TARGET, "old", "valid_d0", 30, 30,
             "2026-08-13T00:00:00+00:00", "2026-08-13T00:10:00+00:00", 600, "old", "old",
             "2026-08-13T00:10:00+00:00", "2026-08-13T01:00:00+00:00"),
            ("weatherol_chongqing", "Chongqing", "ZUCK", TARGET, "new", "valid_d0", float("inf"), 31,
             "2026-08-13T00:00:00+00:00", "2026-08-13T00:20:00+00:00", 600, "new", "new",
             "2026-08-13T00:20:00+00:00", "2026-08-13T02:00:00+00:00"),
        ])
        db.commit(); db.close()
        response = self.snapshot()
        self.assertNotIn("error", response)
        self.assertTrue(all(row["high"] is None or abs(row["high"]) < 1000
                            for row in response["forecasts"]))
        chongqing = next(row for row in response["forecasts"]
                         if row["city"] == "Chongqing" and row["source_key"] == "weatherol_chongqing")
        self.assertEqual(chongqing["d0_status"], "legacy_unverified")
        self.assertIsNone(chongqing["d0_high"])

    def test_snapshot_and_update_choose_latest_by_utc_not_iso_text(self) -> None:
        db = sqlite3.connect(self.research)
        for captured, high in (("2026-08-13T02:00:00+00:00", 42),
                               ("2026-08-13T03:00:00+02:00", 11)):
            payload = json.dumps({"daily": {"time": [TARGET], "temperature_2m_max": [high]},
                                  "metadata": {}})
            db.execute("INSERT INTO forecast_snapshots VALUES (?,?,?,?)",
                       ("ZHHH", "weatherol_wuhan", payload, captured))
            db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                       ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, high, captured))
        db.commit(); db.close()
        response = self.snapshot()
        forecast = next(row for row in response["forecasts"]
                        if row["city"] == "Wuhan" and row["source_key"] == "weatherol_wuhan")
        update = next(row for row in response["updates"]
                      if row["city"] == "Wuhan" and row["source_key"] == "weatherol_wuhan")
        self.assertEqual(forecast["high"], 42.0)
        self.assertEqual(update["high"], 42)

    def test_updates_use_utc_sequence_independent_of_insert_order(self) -> None:
        db = sqlite3.connect(self.research)
        db.execute("DELETE FROM forecast_update_values WHERE source=? AND city=?",
                   ("weatherol_wuhan", "Wuhan"))
        facts = ((20, "2026-08-13T00:00:00+00:00"),
                 (31, "2026-08-13T03:00:00+02:00"),
                 (20, "2026-08-13T02:00:00+00:00"))
        for high, captured in reversed(facts):
            db.execute("INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?)",
                       ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, high, captured))
        db.commit(); db.close()
        response = self.snapshot()
        rows = [row for row in response["updates"]
                if row["source_key"] == "weatherol_wuhan" and row["city"] == "Wuhan"]
        self.assertEqual([row["high"] for row in rows], [20, 31, 20])

    def test_invalid_latest_registry_closes_overlay_without_old_fallback(self) -> None:
        db = sqlite3.connect(self.research)
        db.executemany("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
            ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, "old", "valid_d0", 30, 30,
             "2026-08-13T00:00:00+00:00", "2026-08-13T00:10:00+00:00", 600,
             "old-hash", "frozen", "2026-08-13T00:10:00+00:00", "2026-08-13T01:00:00+00:00"),
            ("weatherol_wuhan", "Wuhan", "ZHHH", TARGET, "new", "valid_d0", 31, 31,
             "2026-08-13T00:00:00+00:00", "2026-08-13T00:20:00+00:00", 600,
             "new-hash", "frozen", "2026-08-13T00:20:00+00:00", "bad-time"),
        ])
        db.commit(); db.close()
        row = next(item for item in self.snapshot()["forecasts"]
                   if item["city"] == "Wuhan" and item["source_key"] == "weatherol_wuhan")
        self.assertEqual(row["d0_status"], "legacy_unverified")
        self.assertIsNone(row["d0_high"])

    def test_snapshot_formats_verified_forecast_and_update_times(self) -> None:
        response = self.snapshot()
        forecast = next(row for row in response["forecasts"]
                        if row["city"] == "Wuhan" and row["source_key"] == "weatherol_wuhan")
        update = next(row for row in response["updates"]
                      if row["city"] == "Wuhan" and row["source_key"] == "weatherol_wuhan")
        self.assertEqual(forecast["captured"], "2026-08-13 09:00:00")
        self.assertEqual(forecast["latest_source_reported_at"], "2026-08-13 08:00:00")
        self.assertEqual(update["captured_at"], "2026-08-13 09:00:00")

    def test_legacy_five_forecast_update_golden_is_explicit(self) -> None:
        response = self.snapshot()
        legacy = {"Beijing", "Shanghai", "Chengdu", "Guangzhou", "Shenzhen"}
        forecast = sorted(
            ({key: row[key] for key in ("city", "station", "source_key", "date", "high", "status",
                                         "captured", "latest_source_reported_at", "d0_status", "d0_high",
                                         "d0_bucket", "grid_version")}
             for row in response["forecasts"] if row["city"] in legacy),
            key=lambda row: (row["city"], row["source_key"]),
        )
        expected = []
        for index, (city, station, source) in enumerate(TEN[:5]):
            for key in ("aviationweather_taf", source):
                expected.append({"city": city, "station": station, "source_key": key, "date": TARGET,
                                 "high": float(20 + index), "status": "ok", "captured": "2026-08-13 09:00:00",
                                 "latest_source_reported_at": "2026-08-13 08:00:00", "d0_status": "legacy_unverified",
                                 "d0_high": None, "d0_bucket": None, "grid_version": None})
        self.assertEqual(forecast, sorted(expected, key=lambda row: (row["city"], row["source_key"])))
        updates = sorted(
            ({key: row[key] for key in ("source_key", "city", "city_cn", "station", "date", "high", "captured_at")}
             for row in response["updates"] if row["city"] in legacy),
            key=lambda row: (row["city"], row["source_key"]),
        )
        labels = {"Beijing": "北京", "Shanghai": "上海", "Chengdu": "成都", "Guangzhou": "广州", "Shenzhen": "深圳"}
        expected_updates = []
        for index, (city, station, source) in enumerate(TEN[:5]):
            for key in ("aviationweather_taf", source):
                expected_updates.append({"source_key": key, "city": city, "city_cn": labels[city], "station": station,
                                         "date": TARGET, "high": 20 + index, "captured_at": "2026-08-13 09:00:00"})
        self.assertEqual(updates, sorted(expected_updates, key=lambda row: (row["city"], row["source_key"])))
