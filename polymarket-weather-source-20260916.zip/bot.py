"""Conservative auto-buyer for selected Polymarket weather markets."""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import re
import sqlite3
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv

GAMMA = "https://gamma-api.polymarket.com"
CLOB = "https://clob.polymarket.com"
CITIES = {
    # Coordinates are the airport stations named in Polymarket's rules, not city centres.
    "beijing": (40.0799, 116.6031, "ZBAA"),       # Beijing Capital
    "shanghai": (31.1434, 121.8052, "ZSPD"),      # Shanghai Pudong
    "chengdu": (30.5785, 103.9471, "ZUUU"),       # Chengdu Shuangliu
    "guangzhou": (23.3924, 113.2990, "ZGGG"),     # Guangzhou Baiyun
}


@dataclass(frozen=True)
class Settings:
    live: bool
    eligible: bool
    max_order: float
    max_daily: float
    min_edge: float
    max_price: float
    min_liquidity: float
    models: list[str]

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            live=os.getenv("LIVE_TRADING", "false").lower() == "true",
            eligible=os.getenv("I_CONFIRM_ELIGIBLE", "false").lower() == "true",
            max_order=float(os.getenv("MAX_ORDER_USDC", "5")),
            max_daily=float(os.getenv("MAX_DAILY_USDC", "20")),
            min_edge=float(os.getenv("MIN_EDGE", "0.08")),
            max_price=float(os.getenv("MAX_ENTRY_PRICE", "0.85")),
            min_liquidity=float(os.getenv("MIN_LIQUIDITY_USDC", "100")),
            # This legacy bot is not an approved execution path.  Open-Meteo
            # has been retired from the project and no environment setting may
            # re-enable it here.
            models=[],
        )


def database() -> sqlite3.Connection:
    Path("data").mkdir(exist_ok=True)
    db = sqlite3.connect("data/trades.sqlite3")
    db.execute("CREATE TABLE IF NOT EXISTS trades (market_id TEXT PRIMARY KEY, created_at TEXT, amount REAL)")
    return db


def market_city(text: str) -> tuple[float, float, str] | None:
    lower = text.lower()
    for name, item in CITIES.items():
        if name in lower:
            return item
    return None


def temperature_range(question: str) -> tuple[float, float] | None:
    """Support explicit Celsius ranges such as 'between 28°C and 30°C'."""
    q = question.lower().replace("º", "°")
    patterns = [
        r"between\s*(-?\d+(?:\.\d+)?)\s*°?c\s*(?:and|to)\s*(-?\d+(?:\.\d+)?)\s*°?c",
        r"(-?\d+(?:\.\d+)?)\s*(?:-|–|to)\s*(-?\d+(?:\.\d+)?)\s*°?c",
    ]
    for pattern in patterns:
        found = re.search(pattern, q)
        if found:
            low, high = map(float, found.groups())
            return min(low, high), max(low, high)
    return None


def target_date(question: str) -> str | None:
    # ISO dates are unambiguous; reject prose dates rather than guessing timezone/year.
    found = re.search(r"(20\d{2}-\d{2}-\d{2})", question)
    return found.group(1) if found else None


async def active_markets(client: httpx.AsyncClient) -> list[dict[str, Any]]:
    """Gamma caps list responses at 100, so explicitly page through results."""
    markets: list[dict[str, Any]] = []
    maximum = int(os.getenv("MARKET_SCAN_LIMIT", "2000"))
    for offset in range(0, maximum, 100):
        response = await client.get(f"{GAMMA}/markets", params={
            "active": "true", "closed": "false", "limit": 100,
            "offset": offset, "order": "volume_24hr", "ascending": "false",
        })
        response.raise_for_status()
        page = response.json()
        markets.extend(page)
        if len(page) < 100:
            break
    return markets


async def forecast_probability(client: httpx.AsyncClient, lat: float, lon: float, date: str, low: float, high: float, models: list[str]) -> float | None:
    """Legacy compatibility shim; the retired Open-Meteo source is unavailable."""
    return None


async def best_ask(client: httpx.AsyncClient, token_id: str) -> float | None:
    response = await client.get(f"{CLOB}/book", params={"token_id": token_id})
    response.raise_for_status()
    asks = response.json().get("asks", [])
    return min((float(x["price"]) for x in asks), default=None)


def already_spent(db: sqlite3.Connection) -> float:
    today = datetime.now(UTC).date().isoformat()
    return db.execute("SELECT COALESCE(SUM(amount), 0) FROM trades WHERE created_at LIKE ?", (today + "%",)).fetchone()[0]


def place_order(market: dict[str, Any], token: str, price: float, amount: float) -> dict[str, Any]:
    from py_clob_client_v2 import ClobClient, OrderArgs, OrderType, PartialCreateOrderOptions, Side
    private_key, funder = os.environ["PRIVATE_KEY"], os.environ["FUNDER_ADDRESS"]
    temp = ClobClient(CLOB, key=private_key, chain_id=137)
    client = ClobClient(CLOB, key=private_key, chain_id=137, creds=temp.create_or_derive_api_key(), signature_type=int(os.getenv("SIGNATURE_TYPE", "0")), funder=funder)
    return client.create_and_post_order(OrderArgs(token_id=token, price=price, size=amount / price, side=Side.BUY), PartialCreateOrderOptions(tick_size=str(market.get("tickSize", "0.01")), neg_risk=bool(market.get("negRisk", False))), OrderType.FAK)


async def cycle(settings: Settings, db: sqlite3.Connection) -> None:
    async with httpx.AsyncClient(timeout=20) as client:
        markets = await active_markets(client)
        logging.info("scanning %d active markets (live_trading=%s)", len(markets), settings.live)
        candidates = 0
        for market in markets:
            question = market.get("question", "")
            city = market_city(question)
            bounds, date = temperature_range(question), target_date(question)
            if not city or not bounds or not date or "temperature" not in question.lower() or not market.get("resolutionSource"):
                continue
            candidates += 1
            if float(market.get("liquidityNum") or market.get("liquidity") or 0) < settings.min_liquidity:
                continue
            if db.execute("SELECT 1 FROM trades WHERE market_id=?", (str(market["id"]),)).fetchone():
                continue
            tokens = json.loads(market.get("clobTokenIds", "[]"))
            outcomes = json.loads(market.get("outcomes", "[]"))
            if not tokens or not outcomes or "yes" not in [str(x).lower() for x in outcomes]:
                logging.info("skip %s: nonstandard outcome layout", question)
                continue
            yes_token = tokens[[str(x).lower() for x in outcomes].index("yes")]
            probability = await forecast_probability(client, city[0], city[1], date, *bounds, settings.models)
            ask = await best_ask(client, yes_token)
            if probability is None or ask is None:
                continue
            edge = probability - ask
            logging.info("%s | p=%.2f ask=%.2f edge=%.2f", question, probability, ask, edge)
            amount = min(settings.max_order, settings.max_daily - already_spent(db))
            if edge < settings.min_edge or ask > settings.max_price or amount <= 0:
                continue
            if not settings.live:
                logging.warning("DRY RUN: would buy $%.2f YES: %s", amount, question)
                continue
            if not settings.eligible:
                raise RuntimeError("Refusing live order: set I_CONFIRM_ELIGIBLE=true after confirming eligibility.")
            result = place_order(market, yes_token, ask, amount)
            if result.get("success"):
                db.execute("INSERT INTO trades VALUES (?, ?, ?)", (str(market["id"]), datetime.now(UTC).isoformat(), amount))
                db.commit()
                order_id = str(result.get("orderID") or result.get("order_id") or "unknown")
                safe_order_id = re.sub(r"[^A-Za-z0-9_.:-]", "_", order_id)[:128]
                logging.warning("ORDER SENT: order_id=%s", safe_order_id)
            else:
                status = str(result.get("status") or result.get("error_code") or "unknown")
                safe_status = re.sub(r"[^A-Za-z0-9_.:-]", "_", status)[:64]
                logging.error("ORDER REJECTED: status=%s", safe_status)
        if candidates == 0:
            logging.info("no supported target-city temperature markets found in this scan")


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    load_dotenv()
    settings, db = Settings.from_env(), database()
    if settings.live:
        raise RuntimeError(
            "Legacy bot.py is intentionally disabled during the research rebuild. "
            "It does not yet implement calibrated bucket probabilities, exits, or stop-losses."
        )
    logging.warning(
        "Legacy bot.py is frozen. It may be used only to inspect old dry-run logs; "
        "it is not part of the rebuilt research or trading workflow."
    )
    logging.info("bot started: dry-run=%s; polling every %ss", not settings.live, os.getenv("POLL_SECONDS", "300"))
    while True:
        try:
            await cycle(settings, db)
        except Exception:
            logging.exception("cycle failed")
        if args.once:
            return
        await asyncio.sleep(int(os.getenv("POLL_SECONDS", "300")))


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    asyncio.run(main())
