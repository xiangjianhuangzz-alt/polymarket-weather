from __future__ import annotations

import json, os, shutil, subprocess, tempfile, textwrap, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent; HTML=ROOT/'ui'/'live.html'
NODE=Path(os.environ.get('CODEX_NODE',r'C:\Users\HP\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'))
MODULES=NODE.parent.parent/'node_modules'
SPECS=(('Beijing','北京','ZBAA','risk_exclusion'),('Shanghai','上海','ZSPD','risk_exclusion'),('Chengdu','成都','ZUUU','risk_exclusion'),('Guangzhou','广州','ZGGG','risk_exclusion'),('Shenzhen','深圳','ZGSZ','research_only'),('Wuhan','武汉','ZHHH','research_only'),('Chongqing','重庆','ZUCK','research_only'),('Jinan','济南','ZSJN','research_only'),('Qingdao','青岛','ZSQD','research_only'),('Zhengzhou','郑州','ZHCC','research_only'))

def chromium():
    for value in (os.environ.get('PLAYWRIGHT_CHROMIUM'),shutil.which('chrome'),shutil.which('msedge'),r'C:\Program Files\Google\Chrome\Application\chrome.exe',r'C:\Program Files\Microsoft\Edge\Application\msedge.exe'):
        if value and Path(value).is_file(): return value
    raise RuntimeError('required Chromium-family browser is missing')

def actuals(state='healthy',available=True):
    off=state=='unavailable'
    return [dict(city=city,city_cn=cn,station=station,decision_scope=scope,scope=scope,state=state,detail=None,available=available,temperature_c=None if off else 20+i,report_time=None if off else '2026-08-12 10:00:00',read_time=None if off else '2026-08-12 10:01:00',age_minutes=None if off else 1,report_type=None if off else 'METAR',conditions=None if off else 'CAVOK',wind_mps=None if off else 2,visibility_km=None if off else 10,today_high=None if off else 25,points=[] if off else [dict(t='10:00',v=20+i)]) for i,(city,cn,station,scope) in enumerate(SPECS)]

class ActualDomTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
    if not NODE.is_file() or not (MODULES/'playwright').is_dir() or not HTML.is_file(): raise RuntimeError('required Node + Playwright + HTML DOM-test runtime is missing')
    cls.chrome=chromium()

 def dom(self,cases):
    js=textwrap.dedent('''
      const fs=require('fs'),{chromium}=require('playwright'),input=JSON.parse(fs.readFileSync(process.argv[2],'utf8')),copy=x=>structuredClone(x);
      const visible=x=>{if(!x)return false;let r=x.getBoundingClientRect(),s=getComputedStyle(x);return x.getClientRects().length>0&&r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
      (async()=>{let browser=await chromium.launch({headless:true,executablePath:input.chrome}),out=[];for(const c of input.cases){let page=await browser.newPage({viewport:{width:c.width||1440,height:900}}),errors=[];page.on('pageerror',e=>errors.push(String(e)));await page.addInitScript(()=>window.pywebview={api:{snapshot:async()=>({}),history:async()=>[],depth:async()=>[],d0_evidence_panel_v2:async()=>({ok:false,error:{code:'offline',message:'offline'}})}});await page.goto(input.html);let cn=Object.fromEntries(input.specs.map(x=>[x[0],x[1]])),frame={now:'2026-08-12 10:02:00',markets:[{id:c.city.toLowerCase(),city:c.city,city_cn:cn[c.city],date:'2026-08-12',bucket:'20°C',question:'q',liquidity:0}],actuals:copy(c.rows),services:{}};await page.evaluate(x=>window.dashboardInit(x),frame);
        const sample=()=>page.evaluate(()=>{const x=document.querySelector('#actualBand');return x.innerText});let snapshots=[await sample()];for(const op of(c.ops||[])){if(op.type==='tab'){await page.click(`[data-tab="${op.value}"]`)}else await page.evaluate(op=>{let rows=structuredClone(op.rows||[]),x=rows[op.index??4];if(op.type==='mutate'){x[op.field]=op.value==='NaN'?NaN:op.value==='Infinity'?Infinity:op.value;window.dashboardPatch({actuals:rows})}else if(op.type==='patch')window.dashboardPatch(op.value==='undefined'?{actuals:undefined}:op.value==='omit'?{services:{collector:{state:'healthy'}}}:{actuals:op.value});else if(op.type==='html_conditions'){x.conditions='<span id="poison">POISON</span>';window.dashboardPatch({actuals:rows})}else if(op.type==='html_point'){x.points=[{t:'<b id="bad-time">BAD</b>',v:24}];window.dashboardPatch({actuals:rows})}else if(op.type==='restore')window.dashboardPatch({actuals:rows})},op);await page.waitForTimeout(15);snapshots.push(await sample())}
        const report=await page.evaluate(()=>{const band=document.querySelector('#actualBand'),br=band.getBoundingClientRect(),v=id=>{const x=document.querySelector(id);if(!x)return false;const r=x.getBoundingClientRect(),s=getComputedStyle(x);return x.getClientRects().length>0&&r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'},tags=[...document.querySelectorAll('.actualTag')].map(x=>{const r=x.getBoundingClientRect();return {l:r.left,r:r.right,t:r.top,b:r.bottom,w:r.width,h:r.height,sw:x.scrollWidth,cw:x.clientWidth,sh:x.scrollHeight,ch:x.clientHeight}});return {text:band.innerText,errors:0,poison:!!document.querySelector('#poison'),bad:!!document.querySelector('#bad-time'),legacyPaper:document.querySelector('.paper')!==null,tags,band:{l:br.left,r:br.right,t:br.top,b:br.bottom,sw:band.scrollWidth,cw:band.clientWidth},root:{sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth},visible:{market:v('#marketPage'),city:v('#city'),date:v('#date'),refresh:v('#refresh'),actual:v('#actualBand'),book:v('.book'),chart:v('#chart'),forecast:v('#forecastPage'),d0nav:v('.d0DateNav'),d0table:v('#d0Table'),bias:v('#biasPage'),biasTable:v('#biasPage table')}}});report.errors=errors.length;report.snapshots=snapshots;out.push(report);await page.close()}await browser.close();process.stdout.write(JSON.stringify(out))})().catch(e=>{console.error(e.stack||e);process.exit(1)});
    ''')
    payload={'chrome':self.chrome,'html':HTML.as_uri(),'specs':SPECS,'cases':cases}
    with tempfile.TemporaryDirectory() as d:
      p=Path(d);(p/'run.js').write_text(js,encoding='utf8');(p/'input.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf8')
      run=subprocess.run([str(NODE),str(p/'run.js'),str(p/'input.json')],cwd=ROOT,env=os.environ|{'NODE_PATH':str(MODULES)},text=True,encoding='utf8',capture_output=True,timeout=120,check=False)
    if run.returncode:self.fail(f'real Node + Playwright + Chromium DOM test failed:\n{run.stderr}')
    return json.loads(run.stdout)

 def closed(self,r):
    self.assertEqual(r['text'].strip(),'实况接口契约异常');self.assertEqual(r['errors'],0);self.assertFalse(r['poison']);self.assertFalse(r['bad']);self.assertFalse(r['legacyPaper']);self.assertTrue(r['visible']['market'] and r['visible']['book'] and r['visible']['chart'])

 def test_legal_pairs_identity_responsive_and_navigation(self):
    cases=[]
    for city,_,_,scope in SPECS:
      for state,available,label in (('healthy',True,'实况正常'),('delayed',True,'报文延迟'),('unavailable',False,'实况不可用')):cases.append(dict(rows=actuals(state,available),city=city,scope=scope,label=label))
    cases += [dict(rows=actuals(),city='Beijing',width=w) for w in (1440,900,390)]
    results=self.dom(cases)
    for c,r in zip(cases,results):
      with self.subTest(city=c['city'],label=c.get('label')):
       if 'label'in c:self.assertIn('仅研究' if c['scope']=='research_only' else '风险排除范围',r['text']);self.assertIn(c['label'],r['text']);self.assertEqual(r['errors'],0)
       else:self.geometry(r);self.assertFalse(r['legacyPaper']);self.assertTrue(all(r['visible'][x] for x in ('market','city','date','refresh','actual','book','chart')))
    views=self.dom([dict(rows=actuals(),city='Shenzhen',ops=[dict(type='tab',value='forecast')]),dict(rows=actuals(),city='Shenzhen',ops=[dict(type='tab',value='bias')]),dict(rows=actuals(),city='Shenzhen',ops=[dict(type='tab',value='forecast'),dict(type='tab',value='bias'),dict(type='tab',value='market')])]);self.assertTrue(views[0]['visible']['forecast'] and views[0]['visible']['d0nav'] and views[0]['visible']['d0table'] and not views[0]['visible']['market']);self.assertTrue(views[1]['visible']['bias'] and views[1]['visible']['biasTable'] and not views[1]['visible']['market']);self.assertTrue(views[2]['visible']['market'] and views[2]['visible']['actual'] and views[2]['visible']['city'] and views[2]['visible']['refresh']);self.assertEqual(views[2]['errors'],0)

 def geometry(self,r):
    self.assertEqual(len(r['tags']),2);a,b=r['tags'];self.assertTrue(all(x['w']>0 and x['h']>0 and x['sw']<=x['cw'] and x['sh']<=x['ch'] and x['l']>=r['band']['l'] and x['r']<=r['band']['r'] for x in (a,b)));self.assertTrue(a['r']<=b['l'] or b['r']<=a['l'] or a['b']<=b['t'] or b['b']<=a['t']);self.assertLessEqual(r['band']['sw'],r['band']['cw']);self.assertLessEqual(r['root']['sw'],r['root']['cw'])

 def test_fixed_matrix_snapshot_and_patch_fail_closed(self):
    variants=[]
    def add(name,fn):
      rows=actuals();fn(rows);variants.append((name,rows))
    add('missing',lambda x:x.pop());add('duplicate',lambda x:x.__setitem__(-1,dict(x[-2])));add('unknown',lambda x:x[-1].__setitem__('city','Unknown'));add('order',lambda x:x.__setitem__(slice(0,2),[x[1],x[0]]));add('city',lambda x:x[0].__setitem__('city','Wrong'));add('city_cn',lambda x:x[0].__setitem__('city_cn','错'));add('station',lambda x:x[0].__setitem__('station','XXXX'));add('decision_scope',lambda x:x[4].__setitem__('decision_scope','risk_exclusion'));add('scope',lambda x:x[4].__setitem__('scope','risk_exclusion'));add('mismatch',lambda x:x[4].__setitem__('scope','risk_exclusion'));add('state',lambda x:x[4].__setitem__('state','unknown'));add('healthy_available',lambda x:x[4].__setitem__('available',False));
    bad=actuals('unavailable',False);bad[4]['available']=True;variants.append(('unavailable_available',bad));bad=actuals('unavailable',False);bad[4]['temperature_c']=99;bad[4]['report_time']='2026-08-12 10:00:00';bad[4]['today_high']=100;bad[4]['points']=[{'t':'10:00','v':99}];variants.append(('unavailable_facts',bad));add('missing_field',lambda x:x[0].pop('detail'));add('extra_field',lambda x:x[0].__setitem__('extra',1))
    cases=[]
    for _,rows in variants:cases += [dict(rows=rows,city='Shenzhen'),dict(rows=actuals(),city='Shenzhen',ops=[dict(type='restore',rows=rows)])]
    for r in self.dom(cases):self.closed(r)

 def test_types_points_times_and_html_and_patch_semantics(self):
    cases=[]
    for f in ('temperature_c','age_minutes','wind_mps','visibility_km','today_high'):
      for v in ('42','   ',True,False,[],{},'NaN','Infinity'):cases.append(dict(rows=actuals(),city='Shenzhen',ops=[dict(type='mutate',field=f,value=v,rows=actuals())]))
    for v in (None,'bad',{},[None],[{'t':'10:00'}],[{'v':24}],[{'t':'10:00','v':24,'x':1}],[{'t':42,'v':24}],[{'t':'10:00','v':'24'}],[{'t':'23:60','v':24}]):cases.append(dict(rows=actuals(),city='Shenzhen',ops=[dict(type='mutate',field='points',value=v,rows=actuals())]))
    for f,v in (('report_time','2026-02-30 10:00:00'),('read_time','2026-13-01 10:00:00'),('report_time',' 2026-08-12 10:00:00'),('report_type','OTHER'),('conditions',{}),('detail',{})):cases.append(dict(rows=actuals(),city='Shenzhen',ops=[dict(type='mutate',field=f,value=v,rows=actuals())]))
    cases.append(dict(rows=actuals(),city='Shenzhen',ops=[dict(type='html_point',rows=actuals())]))
    cases += [dict(rows=actuals(),city='Shenzhen',ops=[dict(type='patch',value=v)]) for v in (None,'undefined',[],{},'bad')]
    for r in self.dom(cases):self.closed(r)
    safe=self.dom([dict(rows=actuals(),city='Shenzhen',ops=[dict(type='html_conditions',rows=actuals())])])[0];self.assertIn('<span id="poison">POISON</span>',safe['text']);self.assertFalse(safe['poison']);self.assertIn('仅研究',safe['text']);self.assertIn('实况正常',safe['text']);self.assertEqual(safe['errors'],0)
    before=self.dom([dict(rows=actuals(),city='Shenzhen',ops=[dict(type='patch',value='omit')])])[0];self.assertEqual(before['snapshots'][0],before['snapshots'][1]);self.assertIn('24°C',before['text']);self.assertIn('仅研究',before['text']);self.assertIn('实况正常',before['text']);self.assertNotIn('实况接口契约异常',before['text']);self.assertEqual(before['errors'],0)
    rows=actuals();rows[4]['points']=None;stale=self.dom([dict(rows=actuals(),city='Shenzhen',ops=[dict(type='restore',rows=rows),dict(type='patch',value='omit')])])[0];self.closed(stale)
    recover=self.dom([dict(rows=actuals(),city='Shenzhen',ops=[dict(type='patch',value=None),dict(type='restore',rows=actuals())])])[0];self.assertIn('实况正常',recover['text']);self.assertEqual(recover['errors'],0)

if __name__=='__main__':unittest.main()
