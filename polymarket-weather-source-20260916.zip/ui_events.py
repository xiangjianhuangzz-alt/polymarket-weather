"""Durable, transaction-bound dashboard event cursors.

The dashboard never treats these records as trading input.  They exist only
to decide which local UI domain needs a refresh after a *committed* write.
SQLite triggers make the data write and event record atomic, including writes
made by legacy collector paths.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path


OUTBOX = "dashboard_event_outbox"
VERSIONS = "dashboard_domain_versions"
KEEP_EVENTS = 20_000


def _table_exists(db: sqlite3.Connection, table: str) -> bool:
    return db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def _base_schema(db: sqlite3.Connection) -> None:
    db.executescript(f"""
    CREATE TABLE IF NOT EXISTS {OUTBOX} (
      event_id INTEGER PRIMARY KEY AUTOINCREMENT,
      domain TEXT NOT NULL,
      entity_key TEXT NOT NULL,
      occurred_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_dashboard_event_domain_id ON {OUTBOX}(domain,event_id);
    CREATE TABLE IF NOT EXISTS {VERSIONS} (
      domain TEXT PRIMARY KEY,
      revision INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );
    CREATE TRIGGER IF NOT EXISTS dashboard_event_trim
    AFTER INSERT ON {OUTBOX} WHEN NEW.event_id % 500 = 0
    BEGIN
      DELETE FROM {OUTBOX} WHERE event_id <= NEW.event_id - {KEEP_EVENTS};
    END;
    """)


def _watch(db: sqlite3.Connection, source: str, table: str, domain: str, key: str, *, outbox: bool = True) -> None:
    """Add idempotent INSERT/UPDATE triggers for one already-existing table."""
    if not _table_exists(db, table):
        return
    for operation in ("INSERT", "UPDATE"):
        name = f"dashboard_{source}_{table}_{operation.lower()}"
        version = f"""
          INSERT INTO {VERSIONS}(domain,revision,updated_at) VALUES ('{domain}',1,strftime('%Y-%m-%dT%H:%M:%fZ','now'))
          ON CONFLICT(domain) DO UPDATE SET revision=revision+1,updated_at=excluded.updated_at;
        """
        event = f"INSERT INTO {OUTBOX}(domain,entity_key,occurred_at) VALUES ('{domain}',{key},strftime('%Y-%m-%dT%H:%M:%fZ','now'));" if outbox else ""
        db.execute(f"""
          CREATE TRIGGER IF NOT EXISTS {name} AFTER {operation} ON {table}
          BEGIN {version} {event} END;
        """)


def ensure_research_events(db: sqlite3.Connection) -> None:
    _base_schema(db)
    # A pre-B deployment stored quote state in research.  Once the stream is
    # moved, this trigger would create misleading quote revisions in the
    # research outbox even though that database is no longer the quote source.
    for name in ("dashboard_research_latest_bbo_insert", "dashboard_research_latest_bbo_update"):
        db.execute(f"DROP TRIGGER IF EXISTS {name}")
    _watch(db, "research", "market_snapshots", "markets", "NEW.market_id")
    _watch(db, "research", "forecast_snapshots", "forecasts", "NEW.city || ':' || NEW.model")
    _watch(db, "research", "forecast_d0_registry", "forecasts", "NEW.city || ':' || NEW.source")
    _watch(db, "research", "market_resolutions", "settlements", "NEW.market_id")
    _watch(db, "research", "service_heartbeats", "health", "NEW.service")


def ensure_realtime_events(db: sqlite3.Connection) -> None:
    """Install the small quote revision cursor in the quote-owned database."""
    _base_schema(db)
    # Quote events are high-frequency.  They receive a durable revision only;
    # actual deltas travel through the bounded local state hub.
    _watch(db, "realtime", "latest_bbo", "quotes", "NEW.token_id", outbox=False)
    _watch(db, "realtime", "service_heartbeats", "health", "NEW.service")


def ensure_paper_events(db: sqlite3.Connection) -> None:
    _base_schema(db)
    for table, key in (("paper_accounts", "NEW.account_id"), ("paper_orders", "NEW.order_id"),
                       ("paper_positions", "NEW.token_id"), ("paper_fills", "NEW.fill_id"),
                       ("paper_sessions", "NEW.session_id"),
                       ("paper_settlements", "NEW.settlement_id")):
        _watch(db, "paper", table, "paper", key)


def ensure_observations_events(db: sqlite3.Connection) -> None:
    """Emit an ``actuals`` refresh only for a newly stored METAR/SPECI.

    Poll status is intentionally not watched: it changes every minute and
    must not cause a dashboard repaint.  State transitions are published
    explicitly by the METAR worker instead.
    """
    _base_schema(db)
    _watch(db, "observations", "metar_observations", "actuals",
           "NEW.station || ':' || NEW.report_time || ':' || NEW.raw_hash")


def publish_event(db: sqlite3.Connection, domain: str, entity_key: str) -> None:
    """Publish a transaction-bound domain transition without adding a trigger."""
    _base_schema(db)
    db.execute(f"""INSERT INTO {VERSIONS}(domain,revision,updated_at)
                   VALUES (?,1,strftime('%Y-%m-%dT%H:%M:%fZ','now'))
                   ON CONFLICT(domain) DO UPDATE SET
                     revision=revision+1,updated_at=excluded.updated_at""", (domain,))
    db.execute(f"""INSERT INTO {OUTBOX}(domain,entity_key,occurred_at)
                 VALUES (?,?,strftime('%Y-%m-%dT%H:%M:%fZ','now'))""",
               (domain, entity_key))


def high_water(path: Path) -> int:
    try:
        db = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)
        row = db.execute(f"SELECT COALESCE(MAX(event_id),0) FROM {OUTBOX}").fetchone()
        db.close()
        return int(row[0])
    except sqlite3.Error:
        return 0


def read_after(path: Path, after: int, limit: int = 512) -> tuple[list[tuple[int, str]], bool]:
    """Return ordered domain events and whether the retained history has a gap."""
    try:
        db = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)
        bounds = db.execute(f"SELECT COALESCE(MIN(event_id),0),COALESCE(MAX(event_id),0) FROM {OUTBOX}").fetchone()
        earliest, latest = int(bounds[0]), int(bounds[1])
        gap = bool(after and earliest and after < earliest - 1)
        rows = db.execute(f"SELECT event_id,domain FROM {OUTBOX} WHERE event_id>? ORDER BY event_id LIMIT ?", (after, limit)).fetchall()
        db.close()
        if not rows and latest > after:
            # More than one bounded batch is pending.  Caller retries next loop.
            return [], False
        return [(int(event_id), str(domain)) for event_id, domain in rows], gap
    except sqlite3.Error:
        return [], False


def domain_revision(path: Path, domain: str) -> int:
    try:
        db = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)
        row = db.execute(f"SELECT revision FROM {VERSIONS} WHERE domain=?", (domain,)).fetchone()
        db.close()
        return int(row[0]) if row else 0
    except sqlite3.Error:
        return 0
