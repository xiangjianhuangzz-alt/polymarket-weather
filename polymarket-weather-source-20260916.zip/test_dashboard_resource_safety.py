import sqlite3
import unittest
from unittest.mock import patch

import dashboard_modern


class _ConnectionProbe:
    def __init__(self, *, execute_error: Exception | None = None) -> None:
        self.execute_error = execute_error
        self.closed = False

    def execute(self, *_args, **_kwargs):
        if self.execute_error is not None:
            raise self.execute_error
        return iter(())

    def close(self) -> None:
        self.closed = True


class DashboardResourceSafetyTests(unittest.TestCase):
    def test_health_snapshot_closes_both_connections_on_first_query_failure(self):
        research = _ConnectionProbe(execute_error=sqlite3.OperationalError("fixture"))
        realtime = _ConnectionProbe()
        with patch.object(
            dashboard_modern.sqlite3, "connect", side_effect=[research, realtime]
        ):
            response = dashboard_modern.Api().health_snapshot()
        self.assertIn("error", response)
        self.assertTrue(research.closed)
        self.assertTrue(realtime.closed)

    def test_history_closes_connection_on_query_failure(self):
        connection = _ConnectionProbe()
        api = dashboard_modern.Api()
        api._market_tokens = [{"token": "token"}]
        with (
            patch.object(dashboard_modern.sqlite3, "connect", return_value=connection),
            patch.object(
                dashboard_modern,
                "market_price_points",
                side_effect=sqlite3.OperationalError("fixture"),
            ),
            self.assertRaises(sqlite3.OperationalError),
        ):
            api.history("token")
        self.assertTrue(connection.closed)

    def test_depth_closes_connection_on_query_failure(self):
        connection = _ConnectionProbe(
            execute_error=sqlite3.OperationalError("fixture")
        )
        api = dashboard_modern.Api()
        api._market_tokens = [{"token": "token"}]
        with (
            patch.object(dashboard_modern.sqlite3, "connect", return_value=connection),
            self.assertRaises(sqlite3.OperationalError),
        ):
            api.depth("token")
        self.assertTrue(connection.closed)

    def test_unknown_or_malformed_token_never_opens_database(self):
        api = dashboard_modern.Api()
        api._market_tokens = [{"token": "known-token"}]
        with patch.object(dashboard_modern.sqlite3, "connect") as connect:
            self.assertEqual(api.history('bad"token'), [])
            self.assertEqual(api.depth("unknown-token"), [])
        connect.assert_not_called()

    def test_history_cache_is_bounded(self):
        api = dashboard_modern.Api()
        api._market_tokens = [
            {"token": f"token-{index}"} for index in range(api.CACHE_LIMIT + 1)
        ]
        connection = _ConnectionProbe()
        with (
            patch.object(dashboard_modern.sqlite3, "connect", return_value=connection),
            patch.object(dashboard_modern, "market_price_points", return_value=[(1, 0.5)]),
        ):
            for index in range(api.CACHE_LIMIT + 1):
                api.history(f"token-{index}")
        self.assertEqual(len(api._history_cache), api.CACHE_LIMIT)
        self.assertNotIn("token-0", api._history_cache)

    def test_reaction_rejects_oversized_request_before_database_open(self):
        api = dashboard_modern.Api()
        api._market_tokens = [{"token": "token"}]
        with patch.object(dashboard_modern.sqlite3, "connect") as connect:
            self.assertEqual(
                api.reaction_live(["id"] * (api.MAX_REACTION_IDS + 1)), {}
            )
        connect.assert_not_called()


if __name__ == "__main__":
    unittest.main()
