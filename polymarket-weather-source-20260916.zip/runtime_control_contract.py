"""Strict, short-lived control-file contract for guardian breaker resets."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
import json
import re
from typing import Any


RESET_SCHEMA = "service_guardian_reset.v1"
RESET_ACTION = "reset_circuit_breaker"
RESET_MAX_LIFETIME = timedelta(minutes=5)
RESET_CLOCK_SKEW = timedelta(seconds=5)
REQUEST_ID = re.compile(r"[0-9a-f]{32}")
SERVICE_NAME = re.compile(r"[a-z0-9_]{1,64}")
RESET_FIELDS = frozenset({
    "schema", "request_id", "service", "action", "requested_at", "expires_at", "reason",
})


class ResetRequestError(ValueError):
    pass


@dataclass(frozen=True)
class ResetRequest:
    schema: str
    request_id: str
    service: str
    action: str
    requested_at: str
    expires_at: str
    reason: str


def strict_json_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ResetRequestError("duplicate reset request field")
        result[key] = value
    return result


def _strict_time(value: Any) -> datetime:
    if type(value) is not str or not value or value != value.strip():
        raise ResetRequestError("reset request time is invalid")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (OverflowError, ValueError) as exc:
        raise ResetRequestError("reset request time is invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ResetRequestError("reset request time must be timezone-aware")
    return parsed.astimezone(UTC)


def parse_reset_request(payload: Any, *, expected_service: str,
                        now: datetime | None = None) -> ResetRequest:
    if type(payload) is not dict or set(payload) != RESET_FIELDS:
        raise ResetRequestError("reset request fields are not exact")
    if any(type(value) is not str for value in payload.values()):
        raise ResetRequestError("reset request fields must be strings")
    request = ResetRequest(**payload)
    if request.schema != RESET_SCHEMA or request.action != RESET_ACTION:
        raise ResetRequestError("reset request operation is invalid")
    if request.service != expected_service or SERVICE_NAME.fullmatch(request.service) is None:
        raise ResetRequestError("reset request service is invalid")
    if REQUEST_ID.fullmatch(request.request_id) is None:
        raise ResetRequestError("reset request id is invalid")
    if not request.reason or len(request.reason) > 256 or any(ord(char) < 32 for char in request.reason):
        raise ResetRequestError("reset request reason is invalid")
    requested_at = _strict_time(request.requested_at)
    expires_at = _strict_time(request.expires_at)
    checked_at = (now or datetime.now(UTC)).astimezone(UTC)
    if requested_at > checked_at + RESET_CLOCK_SKEW or not requested_at <= checked_at < expires_at:
        raise ResetRequestError("reset request is not active")
    if expires_at - requested_at > RESET_MAX_LIFETIME:
        raise ResetRequestError("reset request lifetime is invalid")
    return request


def decode_reset_request(raw: bytes, *, expected_service: str,
                         now: datetime | None = None) -> ResetRequest:
    try:
        payload = json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=strict_json_pairs,
            parse_constant=lambda value: (_ for _ in ()).throw(
                ResetRequestError(f"invalid JSON constant: {value}")
            ),
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ResetRequestError("reset request is not strict UTF-8 JSON") from exc
    return parse_reset_request(payload, expected_service=expected_service, now=now)
