import unittest

from polymarket_rules import (
    RuleError,
    is_marketable,
    normalize_time_in_force,
    rules_for_market,
    validate_order_constraints,
)


class PolymarketRulesTests(unittest.TestCase):
    def test_weather_fallback_is_explicit_and_versioned(self):
        rules = rules_for_market({})
        self.assertEqual(str(rules.tick_size), "0.01")
        self.assertEqual(str(rules.min_order_size), "5")
        self.assertEqual(str(rules.fee_schedule.platform_rate), "0.05")
        self.assertEqual(rules.metadata_source, "official_weather_fallback")

    def test_captured_market_metadata_overrides_weather_fallback(self):
        rules = rules_for_market({
            "tickSize": "0.001",
            "minOrderSize": "2",
            "negRisk": False,
            "feeSchedule": {
                "versionId": "captured-v1",
                "platformRate": "0.02",
                "maker_builder_bps": 5,
                "taker_builder_bps": 10,
            },
        })
        self.assertEqual(str(rules.tick_size), "0.001")
        self.assertEqual(str(rules.min_order_size), "2")
        self.assertFalse(rules.neg_risk)
        self.assertEqual(rules.fee_schedule.version_id, "captured-v1")
        self.assertEqual(rules.metadata_source, "captured_market_metadata")

    def test_builder_fee_caps_follow_official_limits(self):
        with self.assertRaisesRegex(RuleError, "maker_builder_bps"):
            rules_for_market({"feeSchedule": {
                "versionId": "bad-maker", "platformRate": "0.05",
                "maker_builder_bps": 51,
            }})
        with self.assertRaisesRegex(RuleError, "taker_builder_bps"):
            rules_for_market({"feeSchedule": {
                "versionId": "bad-taker", "platformRate": "0.05",
                "taker_builder_bps": 101,
            }})

    def test_post_only_and_market_order_boundaries(self):
        rules = rules_for_market({})
        with self.assertRaises(RuleError):
            validate_order_constraints(
                side="BUY", order_type="MARKET", quantity=5,
                limit_price=None, time_in_force="FAK", post_only=True,
                rules=rules,
            )
        self.assertEqual(normalize_time_in_force("MARKET", None), "FAK")
        self.assertEqual(normalize_time_in_force("LIMIT", None), "GTC")

    def test_marketable_uses_executable_opposite_side(self):
        self.assertTrue(is_marketable(
            side="BUY", order_type="LIMIT", limit_price=.42,
            best_bid=.40, best_ask=.42,
        ))
        self.assertFalse(is_marketable(
            side="BUY", order_type="LIMIT", limit_price=.41,
            best_bid=.40, best_ask=.42,
        ))
        self.assertTrue(is_marketable(
            side="SELL", order_type="LIMIT", limit_price=.40,
            best_bid=.40, best_ask=.42,
        ))


if __name__ == "__main__":
    unittest.main()
