# T00｜新动态策略Canonical Contract｜V8.2-R1候选｜2026-09-01

状态：`R1_CANDIDATE_DESIGN_ONLY`  
规则：本文与R1最终登记共同构成唯一实现规范；不引用V8/V8.1/R2/V8.2补义。冲突时R1终审必须FAIL，不允许实现者选择。

## 1. 当前上游Truth Table

| 当前域 | 唯一writer | 当前事实 | 可直接作无遗漏cursor | R1裁决 |
|---|---|---|---|---|
| Collector `forecast_snapshots/raw_payloads/versions` | Collector | REPLACE/UPDATE/可重建 | 否 | U001同事务追加Forecast状态转换publication |
| Collector `forecast_events` | Collector | event_id递增；只含归一值变化 | 部分 | 只作交叉证据，不能代替raw identity |
| Collector market/rules/snapshots | Collector | UPSERT/REPLACE/latest投影/retention | 否 | U001追加完整Market状态转换publication |
| Collector settlement/evidence | Collector | final replace + evidence | 否 | U001在正式final事务追加Settlement publication |
| METAR observations | METAR | observation_id AUTOINCREMENT；INSERT OR IGNORE；14日retention | 是（保留期内） | 直接使用observation_id；gap失败关闭 |
| Realtime book_snapshots | Realtime | captured+token UPSERT，depth_fresh | 否 | U003追加Book publication header |
| Realtime orderbook_levels | Realtime | captured+token+side+price UPSERT | 否且可变 | U003把完整levels复制到以publication_seq为键的不可变表 |
| Realtime market rules | Realtime | snapshot + latest；同键可更新 | 否 | tick/min/neg-risk与Book publication同事务冻结 |

业务时间、SQLite rowid、`MAX(TEXT)`、latest projection和文件mtime均禁止作cursor。

## 2. 上游publication唯一语义

### 2.1 公共operation identity

```text
operation_id = domain_hash(
  "R1_SOURCE_OPERATION",
  {writer_run_id,stream,state_key,raw_identity}
)
```

每个上游DB有`strategy_publication_receipts`。同operation_id同input_hash返回原outcome；同operation_id不同input_hash零写并SYSTEM身份失败。publication只INSERT，禁止UPDATE。

### 2.2 Forecast状态转换

`state_key=upstream_city+source+station+target_date`。Collector在同一writer事务读取该key最后一条publication：

- 无前序：写`INITIAL`；
- normalized hash等于最后状态：只写幂等receipt，`outcome_seq=NULL`；
- 不等：写`CHANGE`；历史曾出现同hash不影响本次写入，A→B→A必须产生三个seq。

publication保存raw payload、raw hash、normalized hash、前一normalized hash、source time和本地`committed_at`。

### 2.3 Market状态转换

`state_key=city+target_date`。normalized payload必须包含该日完整互斥bucket partition、market/condition、YES/NO token、question、description、end date及正式fee evidence。与最后状态相同只写receipt；不同即写新seq，A→B→A同样保留。

任一城市解析失败只阻止该城publication，不回滚或污染其他城市。

### 2.4 Settlement final

只允许Collector正式Polymarket final evidence触发。publication保存city、date、market、condition、resolved bucket、YES结果、evidence identity和首次本地`committed_at`。天气结果没有该表写入口。

### 2.5 Book不可变publication

Realtime每个`depth_fresh=1`事件在同一事务：

1. 写现有book/rule/levels；
2. 插入`strategy_book_publications` header获得publication_seq；
3. 按`side ASC, price numeric ASC, size numeric ASC`排序完整levels；
4. 逐ordinal插入`strategy_book_publication_levels(publication_seq,ordinal,side,price,size)`；
5. 从不可变levels重算count/hash/BBO并与header逐Decimal相等；
6. 写operation receipt后COMMIT。

不可变levels禁止UPDATE。即使captured_at相同，两次book变化也有不同publication_seq和独立levels。初始FORWARD_STRICT阶段不执行publication retention；部署预检必须证明冻结容量预算，未来retention另行设计授权。

### 2.6 METAR

cursor=`observation_id`；identity=`station+report_time+raw_hash`。Evidence必须同时检查`received_at<=event_at`和`report_time<=event_at`。若cursor小于可见最小ID减1，输出`E_RETENTION_GAP`并仅使该城失败关闭。

## 3. Strict AS-OF读取

每城、每stream维护`global_seq`与`accepted_seq`。一次读取：

```text
BEGIN DEFERRED/query_only
读取规范DB路径、volume serial、file index、schema hash、user_version、data_version
记录transaction_started_at和event_at
固定upper_seq=MAX(publication_seq|observation_id)
读取cursor < seq <= upper_seq的全部全局行
验证全局连续；其他城市行只推进scanned global_seq
筛选本城并验证committed/received/source time <= event_at
计算row_count/range_hash
结束RO事务
在本城Evidence单事务提交anchor/records/cursor/head/health/receipt
```

后到旧source time以新的本地seq进入，只影响`event_at>=committed_at`的新决定。gap、DB替换、Schema漂移、sequence倒退或同seq冲突均禁止跳过/自动修复。

## 4. Canonical primitives

| 名称 | 唯一表示 |
|---|---|
| H64 | lowercase `^[0-9a-f]{64}$` |
| Rfc3339 | 必须含Z/offset；canonical UTC `YYYY-MM-DDTHH:MM:SS.ffffffZ` |
| Date | 合法`YYYY-MM-DD` |
| DecimalDigits | `^(0|[1-9][0-9]*)$` |
| HexId | `^0x[0-9a-f]+$` |
| Decimal01 | 非指数canonical decimal，`0<=x<=1` |
| DecimalSigned11 | 非指数canonical decimal，`-1<=x<=1` |
| DecimalPositive | 非指数canonical decimal，`x>0` |
| DecimalNonNegative | 非指数canonical decimal，`x>=0` |
| CanonicalJson | UTF-8；对象键Unicode code point升序；数组保序；无空白；禁止float/NaN/Infinity |
| InternalCity | `SHANGHAI|BEIJING|GUANGZHOU` |
| Stream | `FORECAST|METAR|MARKET|BOOK|SETTLEMENT` |

除文件raw SHA外，全部身份hash为：

```text
SHA256(ASCII(domain) || 0x00 || canonical_bytes(payload_without_derived_identity))
```

同一对象只有下表指定domain。任何自身份字段均从hash payload排除；不存在自哈希环。

## 5. 字段来源符号

```text
SQL(db.table.column)  持久化权威列
JSON(schema.path)     不可变JSON文件权威字段
ARG(api.argument)     瞬时对象唯一构造参数
DERIVE(formula)       不持久化第二权威
CONST(value)          冻结常量
```

nullable写作`T?`；未写`?`即required/non-null。数组方括号表示有序数组。

## 6. O01-O12核心对象

### O01 ReleaseIdentity

```text
code_ref:H64=JSON(ApprovedConfigSet.code_ref)
config_set_hash:H64=DERIVE(hash ApprovedConfigSet excluding config_set_hash)
deployment_ref:H64=JSON(DeploymentManifest.deployment_ref)
python_sha256:H64=JSON(DeploymentManifest.python_sha256)
```

### O02 SourceAnchor

```text
anchor_id:H64=DERIVE(domain R1_SOURCE_ANCHOR, all following fields)
city:InternalCity=SQL(evidence.source_anchor.city)
stream:Stream=SQL(...stream)
db_path_id:H64=SQL(...db_path_id)
volume_serial:str=SQL(...volume_serial)
file_index:str=SQL(...file_index)
schema_hash:H64=SQL(...schema_hash)
user_version:int>=0=SQL(...user_version)
data_version:int>=0=SQL(...data_version)
transaction_started_at:Rfc3339=SQL(...transaction_started_at)
event_at:Rfc3339=SQL(...event_at)
lower_seq:int>=0=SQL(...lower_seq)
upper_seq:int>=lower_seq=SQL(...upper_seq)
row_count:int>=0=SQL(...row_count)
range_hash:H64=SQL(...range_hash)
```

### O03 EvidenceRecord

```text
city_seq:int>=1=SQL(evidence_record.city_seq)
event_id:H64=DERIVE(domain R1_EVIDENCE_EVENT, city/stream/source_seq/payload_sha256)
city:InternalCity=SQL(...city); stream:Stream=SQL(...stream); source_seq:int>=1=SQL(...source_seq)
source_observed_at:Rfc3339?=SQL(...source_observed_at); received_at:Rfc3339=SQL(...received_at)
target_date:Date?=SQL(...target_date); payload_json:CanonicalJson=SQL(...payload_json)
payload_sha256:H64=DERIVE(raw SHA256 canonical payload)=SQL(...payload_sha256)
previous_hash:H64=SQL(...previous_hash); chain_hash:H64=DERIVE(domain R1_EVIDENCE_CHAIN, previous_hash+record)=SQL(...chain_hash)
```

唯一身份是`stream+source_seq`。同身份同payload幂等；不同payload不得写第二行。

### O04 Bucket

```text
bucket_id:H64=DERIVE(domain R1_BUCKET, label/kind/bounds/ordinal)
label:str=ARG; kind:LOWER_TAIL|SINGLETON|UPPER_TAIL=ARG
lower_c_milli:int?=ARG; upper_c_milli:int?=ARG; ordinal:int>=0=ARG
LOWER_TAIL: lower=null,upper=int
SINGLETON: lower=upper且均为1000倍数
UPPER_TAIL: lower=int,upper=null
```

### O05 MarketContract

```text
contract_ref:H64=DERIVE(domain R1_MARKET_CONTRACT, all following fields)
publication_seq:int>=1=ARG; publication_id:H64=ARG
market_id:DecimalDigits=ARG; condition_id:HexId=ARG; city:InternalCity=ARG; target_date:Date=ARG
question:str=ARG; description:str=ARG; rule_sha256:H64=DERIVE(raw SHA256 description UTF-8)
bucket:O04=ARG; yes_token_id/no_token_id:DecimalDigits=ARG; end_date:Rfc3339=ARG; payload_sha256:H64=ARG
```

### O06 FeeEvidence

```text
fee_ref:H64=DERIVE(domain R1_FEE, all following fields)
market_id:DecimalDigits=ARG; condition_id:HexId=ARG; yes_token_id:DecimalDigits=ARG
fees_enabled:bool=ARG
formula:POLYMARKET_V2_P_ONE_MINUS_P?=ARG
rate_ppm:int[0,1000000]?=ARG; exponent:int=1?=ARG; taker_only:true?=ARG; rebate_rate_ppm:int[0,1000000]?=ARG
captured_at:Rfc3339=ARG; payload_sha256:H64=ARG
fees_enabled=false => five formula fields null
fees_enabled=true => formula/rate/exponent/taker_only/rebate_rate非null
```

### O07 BookSnapshot

```text
book_ref:H64=DERIVE(domain R1_BOOK, all following fields)
publication_seq:int>=1=ARG; captured_at/committed_at:Rfc3339=ARG
market_id/token_id:DecimalDigits=ARG
bids/asks:[{ordinal:int>=0,price:Decimal01,size:DecimalPositive}]=ARG
best_bid/best_ask:Decimal01?=DERIVE(max bid/min ask)
tick_size/min_order_size:DecimalPositive=ARG; neg_risk:bool=ARG
levels_sha256:H64=DERIVE(raw SHA256 canonical ordered bids+asks)
```

### O08 ModelInput

```text
event_id:H64=ARG; city:InternalCity=ARG; target_date:Date=ARG; event_at:Rfc3339=ARG
local_second:int[25200,57599]=DERIVE(floor event_at Asia/Shanghai to whole second)
forecast_high_c_milli:int multiple1000=ARG; observed_max_so_far_c_milli:int multiple1000=ARG
forecast_publication_seq:int>=1=ARG; metar_anchor_ref:H64=ARG; artifact_ref:H64=ARG
```

### O09 ProbabilityVector

```text
bucket_ids:[H64]>=2=ARG; raw/calibrated:[Decimal01]=ARG; lcb:[Decimal01]=ARG
raw与calibrated长度相等且各自12位Decimal和精确为1；lcb同长度但不要求和为1
```

### O10 ApprovedModelRef

```text
city:InternalCity=JSON; artifact_ref/qualification_ref/candidate_ref/policy_ref:H64=JSON
```

### O11 ApprovedConfigSet

```text
schema_version:1=CONST
code_ref/common_policy_hash:H64=JSON
models:{SHANGHAI:O10,BEIJING:O10,GUANGZHOU:O10}=JSON且key==ref.city
approved_by_sid:str=JSON; approval_ref:H64=JSON; approved_at:Rfc3339=JSON
config_set_hash:H64=DERIVE(domain R1_APPROVED_CONFIG, object excluding config_set_hash)=JSON
```

### O12 Decision

```text
decision_id:H64=DERIVE(domain R1_DECISION, all fields excluding decision_id)=SQL
previous_decision_id:H64?=SQL; city:InternalCity=SQL; event_at:Rfc3339=SQL; target_date:Date=SQL
event_id/snapshot_ref/contract_ref/fee_ref/book_ref/artifact_ref/config_set_hash/bucket_id:H64=SQL
state:NO_TRADE|YES_CANDIDATE|INVALIDATED|FAIL_CLOSED|WINDOW_CLOSED=SQL
reasons:[DecisionReason]=JSON encoded SQL; errors:[ErrorCode]=JSON encoded SQL
p_lcb:Decimal01?=SQL; c_executable:Decimal01?=SQL; e_conservative:DecimalSigned11?=SQL
output_json:CanonicalJson=SQL; created_at:Rfc3339=SQL
YES_CANDIDATE要求三个数值非null；有完整有效输入的NO_TRADE同样保存三个数值，包括负edge
```

## 7. O13-O33运行、模型与部署对象

```text
O13 EvidenceHealth = city:InternalCity,pid:int,parent_pid:int,writer_epoch:int,lease_ref/code_ref/deployment_ref:H64,last_city_seq:int,cursors:map[Stream,int],breakers:map[Stream,CLOSED|OPEN|HALF_OPEN],emitted_at:Rfc3339；SQL worker_health；无hash
O14 TrainingDay = training_day_ref:H64(domain R1_TRAINING_DAY),city:InternalCity,target_date:Date,weather_station:str,forecast_timeline:[ForecastPoint],metar_timeline:[MetarPoint],market_partition:[O04],weather_label_cutoff:Rfc3339,coverage_first_ok/last_ok/gap_ok:bool,final_max_c_milli:int?,final_visible_at:Rfc3339?,settlement_bucket_id:H64?,settlement_visible_at:Rfc3339?；JSON ModelArtifact.training_days
O15 CalibrationPoint = validation_date:Date,local_second:int,bucket_upper_c_milli:int,q:Decimal01,y:0|1,weight:DecimalPositive,prediction_ref:H64；ARG；prediction_ref domain R1_OOF_PREDICTION
O16 CalibrationModel = local_second:int,points_hash:H64,blocks:[{q_min,q_max,fitted,weight}],validation_dates:[Date],calibration_hash:H64(domain R1_PAV)；ARG/DERIVE，不持久化
O17 BootstrapSpec = iterations:int>=1,confidence:DecimalOpen01,alpha/alpha_adjusted:DecimalOpen01,max_candidate_evaluations_per_day:int>=1,seed:H64,sampling=TARGET_DAY_CLUSTER,quantile=NEAREST_RANK；ARG
O18 ModelArtifact = schema_version:1,artifact_ref:H64(domain R1_ARTIFACT_REF excluding artifact_ref/artifact_sha256),city,code_ref,training_cutoff,training_days:[O14],algorithm_hash,artifact_sha256(raw SHA256 canonical object excluding artifact_sha256)；JSON immutable
O19 Qualification = qualification_ref:H64(domain R1_QUALIFICATION),city,artifact_ref,policy_ref,metrics_ref,state:APPROVED|REJECTED,decided_at；SQL qualification
O20 ConfigCandidate = schema_version:1,candidate_ref:H64(domain R1_CONFIG_CANDIDATE excluding candidate_ref),city,artifact_ref,qualification_ref,policy_ref,bootstrap_iterations,confidence,max_candidate_evaluations_per_day,minimum_training_days,freshness_seconds,target_shares,slippage_reserve,impact_reserve,rule_reserve,probability_floor,delta,state=UNAPPROVED,created_at；JSON + SQL payload
O21 CostVector = shares,fills,notional,fee_upper,slippage_reserve,impact_reserve,rule_reserve,c_executable；ARG；全部Decimal，c_executable Decimal01
O22 RuntimeEvent = event_id:H64(domain R1_RUNTIME_EVENT),scope:CITY|SYSTEM,city_seq:int?,system_seq:int?,kind,event_at,payload_ref:H64；SQL runtime_event
O23 WriterLease = lease_ref:H64(domain R1_WRITER_LEASE),db_path_id:H64,file_identity,lock_path_id:H64,pid,process_created_at,writer_role,city?,writer_epoch,code_ref,deployment_ref；SQL writer_epoch + kernel handle
O24 OperationReceipt = operation_id:H64,transaction_id:H64,scope,input_hash:H64,write_set_hash:H64,committed_at:Rfc3339；SQL operation_receipt
O25 MetricValue = numerator:DecimalSigned,denominator:int>=0,value:DecimalSigned?,missing_count:int>=0,population_id:H64；JSON
O26 MetricsReport = metrics_ref:H64(domain R1_METRICS),city,artifact_ref,target_day_n:int,metrics:map[M001-M018,O25],created_at；JSON immutable
O27 CodeManifest = schema_version:1,members:[{path,sha256,size}],python_requirement_lock_sha256:H64,schema_set_hash:H64,code_ref:H64(domain R1_CODE_MANIFEST excluding code_ref)；JSON immutable
O28 DeploymentManifest = schema_version:1,code_ref,config_set_hash,python_exe,python_sha256,release_dir,system_dir,city_dirs:map[City,path],config_dir,status_path,task_xml_hashes:map[task,H64],acl_hash:H64,network_policy_hash:H64,sid,created_at,deployment_ref:H64(domain R1_DEPLOYMENT_MANIFEST excluding deployment_ref)；JSON immutable
O29 ClockAttestation = utc_now:Rfc3339,local_now:Rfc3339,timezone=Asia/Shanghai,monotonic_ns:int,wall_monotonic_delta_ms:DecimalNonNegative,trusted:bool,reason?；ARG
O30 DecisionInput = model_input:O08,probability:O09,contract:O05,fee:O06,book:O07,approved_config:O11,selected_bucket_id:H64；ARG
O31 StatusReport = schema_version:1,generated_at,release:O01,system_state,city_states:map[City],health:map,errors:[ErrorCode],report_hash:H64(domain R1_STATUS excluding report_hash)；status JSON replace-only
O32 PreflightReport = schema_version:1,deployment_ref,checks:[{id,status:PASS|FAIL,evidence_hash}],passed:bool,created_at,report_hash:H64(domain R1_PREFLIGHT excluding report_hash)；JSON immutable
O33 VerificationReport = schema_version:1,deployment_ref,checks:[{id,status:PASS|FAIL,evidence_hash}],passed:bool,verified_at,report_hash:H64(domain R1_VERIFY excluding report_hash)；JSON immutable
```

`DecimalSigned`仅用于指标numerator/value且是非指数规范十进制，不限制[-1,1]；交易决策edge必须用DecimalSigned11。

## 8. O34-O41八份静态配置

每个配置都有`schema_version=1`、`config_hash=domain_hash(指定domain, object excluding config_hash)`，是F047验证的不可变canonical JSON。

```text
O34 CitySourcesConfig/R1_CITY_SOURCES:
  cities固定三键；每城{internal_city,upstream_city,forecast_source,forecast_station,observation_source=aviationweather_metar,observation_station,timezone=Asia/Shanghai}
  SHANGHAI={Shanghai,weatherol_shanghai,weatherol_d0,ZSPD}
  BEIJING={Beijing,aviationweather_taf,ZBAA,ZBAA}
  GUANGZHOU={Guangzhou,aviationweather_taf,ZGGG,ZGGG}

O35 EvidencePolicy/R1_EVIDENCE_POLICY:
  poll_interval_ms=1000; stream_order=[FORECAST,METAR,MARKET,BOOK,SETTLEMENT]
  weather_label_freeze_delay_hours=24; boundary_tolerance_minutes=30; max_metar_gap_minutes=90
  source_retry_limit=3; breaker_reset_seconds=300; publication_retention_enabled=false

O36 ModelPolicy/R1_MODEL_POLICY:
  local_second_rule=FLOOR_TO_SECOND; calibration_population=SAME_LOCAL_SECOND_PRIOR_TARGET_DAYS
  pav_scope=ALL_FINITE_BOUNDARIES; target_day_total_weight=1; bootstrap_sampling=TARGET_DAY_CLUSTER
  bootstrap_iterations/confidence/max_candidate_evaluations_per_day/minimum_training_days=null
  admission=BLOCKED_UNQUALIFIED

O37 QualificationPolicy/R1_QUALIFICATION_POLICY:
  population_unit=CITY_TARGET_DATE; evaluation_selector=FIRST_ELIGIBLE_EVENT_PER_TARGET_DAY
  required_metrics=[M001..M018]; all gate thresholds=null; admission=BLOCKED_UNQUALIFIED

O38 RuntimePolicy/R1_RUNTIME_POLICY:
  window_start=07:00:00; window_end=16:00:00; safe_recheck_seconds=30
  forecast/metar/market/book freshness_seconds=null
  target_shares/slippage_reserve/impact_reserve/rule_reserve/probability_floor/delta=null
  side=BUY_YES_ONLY; admission=BLOCKED_UNQUALIFIED

O39 PathPolicy/R1_PATH_POLICY:
  release_root=D:\\polymarket天气\\releases\\strategy_v82_r1
  runtime_root=D:\\polymarket天气\\runtime_strategy_v82_r1
  system_dir=<runtime_root>\\system; city_dir_template=<runtime_root>\\cities\\{CITY}
  config_dir=<runtime_root>\\config; status_path=<runtime_root>\\status\\status.json
  lock_dir=<runtime_root>\\locks; absolute_paths_only=true; reparse_points_allowed=false

O40 TaskPolicy/R1_TASK_POLICY:
  Evidence={start 06:50:00,absolute_stop 16:10:00,limit PT9H20M}
  Runtime={start 06:55:00,business_close 16:00:00,absolute_stop 16:05:00,limit PT9H10M}
  Observer={start 06:55:00,absolute_stop 16:15:00,limit PT9H20M}
  Enabled=false,LogonType=InteractiveToken,RunLevel=LeastPrivilege,MultipleInstances=IgnoreNew,StartWhenAvailable=false

O41 NetworkPolicy/R1_NETWORK_POLICY:
  mode=PYTHON_IMPORT_AND_CALLSITE_DENY; threat_model=COOPERATIVE_SIGNED_RELEASE_NOT_MALICIOUS_SAME_SID_USER
  allowed_endpoints=[]; os_firewall_required=false
  denied_modules=[socket,ssl,http,urllib,requests,httpx,aiohttp,web3,websockets]
  denied_symbols=[subprocess.Popen,subprocess.run,os.system]，唯一例外是F009/F019/F038经固定argv调用已登记worker模块
  runtime_import_guard=true; ast_import_scan=true; lock_dependency_scan=true
```

## 9. 天气精确标签冻结

目标日D按Asia/Shanghai `[D 00:00:00,D+1 00:00:00)`和逐城固定METAR站定义。标签截止：

```text
weather_label_cutoff(D)=D+2 00:00:00 Asia/Shanghai
```

只使用`report_time`在天气日内且`received_at<=cutoff`的METAR/SPECI。合格需：首报距00:00不超过30分钟、末报距24:00不超过30分钟、相邻report_time最大间隔不超过90分钟、全部温度非null且station/city一致。合格时：

```text
final_max_c_milli=max(temperature_c_milli)
final_visible_at=weather_label_cutoff(D)
```

不合格则两个字段永久null并计missing；cutoff后迟到记录不得修订该TrainingDay。正式Polymarket settlement label独立按其publication committed_at附加，不能替代精确温度。

## 10. 唯一动态概率与校准population

当前事件目标日D、event_at t，`s=floor(local second)`。每个历史验证日v恰形成一个target-day cluster：

1. 对v按同一个s构造`fold_decision_at(v,s)`；
2. 训练集合只含`d<v`、天气标签在fold前可见的合格TrainingDay；
3. 取v在fold前最后Forecast publication和observed max；生成OOF raw temperature CDF；
4. v的正式settlement必须在artifact cutoff前可见；
5. 对v市场partition的每个有限上边界u生成一点`(q,y)`；若有`m_v`个有限边界，每点weight=`1/m_v`，所以该日总权重恰为1；
6. 全部validation day points按`q,validation_date,u`排序，运行加权PAV；相邻下降块按权重合并；
7. 当前日的raw CDF在当前市场有限边界上应用该唯一PAV，端点外推后作非降投影，再差分得到bucket概率。

因此校准不读取历史事件数量、不用整点或15分钟锚、每次实时事件都按其精确秒重算。无合格validation day或点数低于未来资格阈值时输出`CALIBRATION_INSUFFICIENT`。

原始残差：

```text
residual_d=final_max_c_milli(d)-forecast_high_c_milli(d,fold)
x_d=max(current_observed_max_so_far,current_forecast_high+residual_d)
```

按当前bucket计数形成raw分布。市场价格不进入上述任何步骤。

## 11. Bootstrap LCB

O08显式携带event_id。种子：

```text
SHA256("R1_BOOTSTRAP\0"+city+"\0"+artifact_ref+"\0"+event_id)
```

按TrainingDay cluster有放回抽N日；SHA256 rejection sampling消除mod N偏差；固定本事件O16，不在bootstrap中重拟合PAV。`alpha=1-confidence`，逐城`alpha_adjusted=alpha/(bucket_count*max_candidate_evaluations_per_day)`，`k=ceil(alpha_adjusted*B)`且`1<=k<=B`。每bucket取第k小，nearest-rank，不要求LCB和为1。三城不共享样本、seed、alpha预算或候选计数。

## 12. 成本与保留公式

只评估一个YES bucket。按ask价格升序、ordinal稳定取前五档直到target_shares：

```text
notional=sum(q_i*p_i)
fee=sum(ceil_5dp(q_i*rate*p_i*(1-p_i)))
C_executable=(notional+fee)/target_shares
             +slippage_reserve_per_share
             +impact_reserve_per_share
             +rule_reserve_per_share
E_conservative(B,t)=P_LCB(B|I_t)-C_executable(B,t)
```

`E_conservative`合法范围[-1,1]。候选必须严格`E_conservative>delta`；等于不通过。费用缺失、公式未知、深度不足、成本>1、任何非有限值均失败关闭。

## 13. Schema、DDL与表现形式边界

- F046必须包含O01-O33所有JSON可表达对象的`$defs`；根oneOf只列实际不可变/交换JSON对象O11、O18、O20、O26-O33。SQL-only对象仍在`$defs`供payload/round-trip验证，不产生第二权威。
- F047必须完整包含O34-O41；每个配置根恰好一个definition。
- F048完整包含O27/O28/O31-O33及三TaskSpec、ACL矩阵黄金对象。
- F049-F052是SQL唯一权威；payload JSON是可复算副本。
- 最终登记中的逐字Schema/DDL/XML/ACL与本文字段表有任何不等即R1终审FAIL。
