from __future__ import annotations

import logging
import tempfile
import unittest
from pathlib import Path

from runtime_logging import configure_runtime_logging


class RuntimeLoggingTests(unittest.TestCase):
    def test_service_log_rotates_with_bounded_backups(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            directory = Path(temp)
            configure_runtime_logging("collector", log_dir=directory, max_bytes=128, backup_count=2)
            for _ in range(12):
                logging.info("x" * 80)
            for handler in logging.getLogger().handlers:
                handler.flush()
            self.assertTrue((directory / "collector.log").exists())
            self.assertTrue((directory / "collector.log.1").exists())
            self.assertLessEqual(len(list(directory.glob("collector.log*"))), 3)
            # Windows retains the file handle until the handler is closed.
            # Close it before TemporaryDirectory removes the test directory.
            root = logging.getLogger()
            for handler in root.handlers[:]:
                root.removeHandler(handler)
                handler.close()
