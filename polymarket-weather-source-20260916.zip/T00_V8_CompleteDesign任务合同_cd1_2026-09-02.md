# V8 Complete Design 受限任务合同｜cd1｜2026-09-02

## 1. 身份与授权

```text
TASK_ID=PWM-V8-CD1-001
CURRENT_STAGE=COMPLETE_DESIGN
BRANCH=codex/handoff-baseline-20260809
HEAD=13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
KERNEL_CANDIDATE=ak2
KERNEL_SHA256=e01d30534b8b1de77ac4c426d925dda222a0c772540fb09b6425d39fab11308d
KERNEL_FINAL_VERDICT=PASS
ARCHITECTURE_KERNEL_STAGE_COMPLETE=YES
COMPLETE_DESIGN_AUTHORIZED=YES
IMPLEMENTATION_AUTHORIZED=NO
TEST_EXECUTION_AUTHORIZED=NO
GIT_WRITE_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
SHADOW_AUTHORIZED=NO
PAPER_AUTHORIZED=NO
LIVE_TRADING_AUTHORIZED=NO
```

授权来源为用户在当前T00任务中的明确指令：开始Complete Design阶段，只处理`DEFERRED_COMPLETE_DESIGN`，不得进入Implementation/Test、Deployment Acceptance或代码实现。

## 2. 阶段目标与成功标准

本阶段只把已经冻结的Architecture Kernel原则补全为可由实现者唯一消费的详细合同。成功标准为：13项Finding均被一个且仅一个规范工作包覆盖；机器规范可解析；同一规则不在多个文件中重复定义；后续测试和部署事项仍保持延期。

本阶段不证明代码正确、测试通过、已集成或可部署。

## 3. 唯一范围

13项`DEFERRED_COMPLETE_DESIGN`去重为6个工作包：

| 工作包 | Finding | 本阶段输出 |
|---|---|---|
| CD-01 | B01、R01、N01 | Canonical机器合同、唯一规范来源、编码/hash、生成与反向消费 |
| CD-02 | B06 | M001—M018完整指标合同 |
| CD-03 | B11、R05 | Candidate commit receipt、结果不明、零副作用重试和恢复分支 |
| CD-04 | B12、R06、N06 | ErrorCode机器Registry、命名空间、唯一Outcome映射 |
| CD-05 | B13、R07 | Lease字段、CAS、Guardian/Worker恢复交接 |
| CD-06 | B15、R09 | Breaker/HALF_OPEN、PathPolicy和状态Guard |

## 4. 明确排除

以下事项不得在cd1中设计、执行或据此判定：

- `DEFERRED_IMPLEMENTATION_TEST`：B03、B04、B05、N03；
- `DEFERRED_DEPLOYMENT_ACCEPTANCE`：B07、B08、B14、R08、N04、AK2-NEW-001；
- 已判无效的B09/R03、B10/R04/N05；
- ak2或KG-01的修改；
- 完整DDL、Trigger、实现代码、测试向量、故障注入、任务URI、Windows ACL、部署配置；
- Backtest、盈利能力、edge阈值；
- Shadow、Paper、Live、订单、资金或资格激活。

## 5. 单一规范来源

本任务的详细规范唯一来源是：

```text
T00_新动态策略CompleteDesign规范_cd1_2026-09-02.json
```

本合同与Manifest只描述范围、身份、完整性和阶段状态，不得覆盖JSON中的业务定义。ak2继续拥有K1—K6原则；cd1只能细化本合同列出的13项Finding。二者冲突时失败关闭，不得以“较新文件”静默覆盖Kernel。

## 6. 最小执行顺序

```text
绑定Kernel与13项Finding
→ T01/STRATEGY/BE/OPS按责任域只读给出设计输入
→ T00去重并形成单一机器规范
→ 作者级静态一致性检查
→ 冻结cd1 Manifest
→ STOP，等待独立QA授权
```

QA不参与冻结前文本修改。作者级静态检查不等于独立验收。

## 7. 停止点

当规范JSON、任务合同和Manifest身份完成并且静态检查无结构错误后停止。不得自动开始独立QA、代码实现、测试、Git操作或部署。
