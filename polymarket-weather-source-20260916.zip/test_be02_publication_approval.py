from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import collector


NOW = datetime.fromisoformat("2026-08-11T00:30:00+08:00")
SCANNED_AT = "2026-08-10T16:30:00+00:00"
SCAN_ID = "offline-approval-scan"
HASH_A = "a" * 64
HASH_B = "b" * 64


def _source(city: str, station: str) -> str:
    return f"https://www.wunderground.com/weather/cn/{city.lower()}/{station}"


def _record(
    *,
    token_id: str = "1001",
    other_token: str = "1002",
    market_id: str = "market-current",
    city: str = "Wuhan",
    station: str = "ZHHH",
    target_date: str = "2026-08-11",
    scanned_at: str = SCANNED_AT,
    scan_id: str = SCAN_ID,
) -> dict:
    target = datetime.fromisoformat(target_date).date()
    day = f"{target.strftime('%B')} {target.day}"
    event = {
        "id": f"event-{city.lower()}-{target_date}",
        "title": f"Highest temperature in {city} on {day}",
        "resolutionSource": _source(city, station),
        "active": True,
        "closed": False,
        "_query_city": city,
        "_query_target_date": target_date,
    }
    market = {
        "id": market_id,
        "question": f"Will the highest temperature in {city} be 30 C on {day}?",
        "resolutionSource": _source(city, station),
        "outcomes": json.dumps(["Yes", "No"]),
        "clobTokenIds": json.dumps([token_id, other_token]),
        "groupItemTitle": "30 C",
        "active": True,
        "closed": False,
    }
    result = collector.attribute_research_market(
        event, market, scan_id=scan_id, scanned_at=scanned_at
    )
    assert result["attribution_status"] == "verified"
    return result


def _legacy_members() -> list[dict[str, str]]:
    return [
        {
            "token_id": "1001",
            "market_id": "market-current",
            "city": "Wuhan",
            "target_date": "2026-08-11",
        },
        {
            "token_id": "9001",
            "market_id": "market-expired",
            "city": "Beijing",
            "target_date": "2026-08-10",
        },
    ]


def _canonical_hash(members: list[dict]) -> str:
    raw = json.dumps(
        members, ensure_ascii=False, separators=(",", ":"), sort_keys=True
    )
    return hashlib.sha256(raw.encode()).hexdigest()


def _removed_hash(tokens: list[str]) -> str:
    raw = json.dumps(sorted(tokens), ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()


def _approval(current_hash: str, candidate: dict, **changes) -> dict:
    dto = {
        "schema": "universe_publication_approval.v1",
        "operation_id": "t00-offline-operation",
        "expected_current_hash": current_hash,
        "approved_candidate_hash": candidate["token_hash"],
        "approved_token_count": candidate["token_count"],
        "approved_added_count": 0,
        "approved_removed_count": 1,
        "approved_remapped_count": 0,
        "approved_removed_token_hash": _removed_hash(["9001"]),
        "allowed_removed_target_dates": ["2026-08-10"],
        "not_before": "2026-08-11T00:25:00+08:00",
        "expires_at": "2026-08-11T00:35:00+08:00",
    }
    dto.update(changes)
    return dto


def _forward_mixed_approval(current_hash: str, candidate: dict, **changes) -> dict:
    """Explicit v2 approval for one legacy -> v1 forward-mixed transition."""
    dto = {
        "schema": "universe_publication_approval.v2",
        "operation_id": "t00-offline-forward-operation",
        "transition": "legacy_to_v1_forward_mixed",
        "expected_current_hash": current_hash,
        "approved_candidate_hash": candidate["token_hash"],
        "approved_token_count": candidate["token_count"],
        "approved_added_count": 1,
        "approved_removed_count": 1,
        "approved_remapped_count": 0,
        "approved_added_token_hash": _removed_hash(["7001"]),
        "approved_removed_token_hash": _removed_hash(["9001"]),
        "allowed_added_target_dates": ["2026-08-11"],
        "allowed_removed_target_dates": ["2026-08-10"],
        "not_before": "2026-08-11T00:25:00+08:00",
        "expires_at": "2026-08-11T00:35:00+08:00",
    }
    dto.update(changes)
    return dto


def _write_json(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=True),
        encoding="utf-8",
    )


def _seed_research(path: Path, members: list[dict] | None = None) -> tuple[str, sqlite3.Connection]:
    legacy = members or _legacy_members()
    token_hash = _canonical_hash(legacy)
    with patch.object(collector, "DB_PATH", path), patch.object(
        collector, "prune_research_data"
    ):
        db = collector.connect()
    collector.publish_market_universe(
        db, "2026-08-10T15:55:00+00:00", legacy, "complete_scan"
    )
    db.commit()
    return token_hash, db


def _seed_realtime(path: Path, token_hash: str, token_count: int = 2) -> None:
    db = sqlite3.connect(path)
    try:
        db.execute(
            """CREATE TABLE stream_connection_events (
            event_at TEXT NOT NULL, event_type TEXT NOT NULL, detail TEXT,
            universe_hash TEXT, token_count INTEGER, added_tokens_json TEXT,
            removed_tokens_json TEXT)"""
        )
        db.execute(
            "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
            (
                "2026-08-10T16:00:00+00:00",
                "connected",
                "offline accepted fixture",
                token_hash,
                token_count,
                "[]",
                "[]",
            ),
        )
        db.commit()
    finally:
        db.close()


def _complete_statuses(record: dict) -> list[dict]:
    scanned = datetime.fromisoformat(record["scanned_at"])
    scan_date = scanned.astimezone(collector.SHANGHAI_TZ).date()
    statuses: list[dict] = []
    verified_point = (record["city"], record["target_date"])
    for city_key in sorted(collector.CITY_ROLES):
        city = city_key.title()
        station = collector.CITY_SETTLEMENT_STATIONS[city_key]
        for offset in range(3):
            target = scan_date.fromordinal(scan_date.toordinal() + offset).isoformat()
            if (city, target) == verified_point:
                statuses.append(record)
            else:
                statuses.append(
                    collector.research_attribution_status(
                        "no_active_market",
                        "no_exact_active_event",
                        scan_id=record["scan_id"],
                        scanned_at=record["scanned_at"],
                        city=city,
                        station=station,
                        target_date=target,
                    )
                )
    return statuses


class ApprovalFileTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "approval.json"
        self.candidate = collector.build_research_universe_candidate([_record()])
        self.valid = _approval(_canonical_hash(_legacy_members()), self.candidate)

    def test_missing_empty_oversize_and_non_regular_files_fail_closed(self) -> None:
        cases: list[tuple[str, Path]] = [("missing", self.path)]
        empty = Path(self.tmp.name) / "empty.json"
        empty.write_bytes(b"")
        cases.append(("empty", empty))
        oversized = Path(self.tmp.name) / "oversized.json"
        oversized.write_bytes(b"x" * (16 * 1024 + 1))
        cases.append(("oversized", oversized))
        directory = Path(self.tmp.name) / "directory"
        directory.mkdir()
        cases.append(("directory", directory))
        for name, path in cases:
            with self.subTest(name=name), self.assertRaises(collector.MarketScanIncomplete):
                collector.load_universe_publication_approval(path, now=NOW)

    def test_utf8_json_duplicate_unknown_and_nonfinite_values_fail_closed(self) -> None:
        cases = {
            "utf8": b"\xff",
            "json": b"{",
            "duplicate": b'{"schema":"universe_publication_approval.v1","schema":"x"}',
            "unknown": json.dumps({**self.valid, "database_path": "forbidden"}).encode(),
            "nan": json.dumps({**self.valid, "approved_token_count": float("nan")}).encode(),
            "infinity": json.dumps({**self.valid, "approved_token_count": float("inf")}).encode(),
        }
        for name, payload in cases.items():
            with self.subTest(name=name):
                self.path.write_bytes(payload)
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.load_universe_publication_approval(self.path, now=NOW)

    def test_schema_native_types_hash_counts_dates_and_operation_are_strict(self) -> None:
        cases = (
            {"schema": "universe_publication_approval.v2"},
            {"operation_id": True},
            {"operation_id": " operation"},
            {"expected_current_hash": "A" * 64},
            {"approved_candidate_hash": "b" * 63},
            {"approved_token_count": True},
            {"approved_removed_count": -1},
            {"approved_added_count": 1},
            {"approved_remapped_count": 1},
            {"allowed_removed_target_dates": []},
            {"allowed_removed_target_dates": ["2026-08-10", "2026-08-10"]},
            {"allowed_removed_target_dates": ["2026-08-11", "2026-08-10"]},
            {"allowed_removed_target_dates": ["2026-8-10"]},
            {"allowed_removed_target_dates": [True]},
            {"not_before": "2026-08-11T00:25:00"},
        )
        for changes in cases:
            with self.subTest(changes=changes):
                _write_json(self.path, {**self.valid, **changes})
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.load_universe_publication_approval(self.path, now=NOW)

    def test_not_yet_valid_expired_and_over_fifteen_minutes_fail_closed(self) -> None:
        cases = (
            {
                "not_before": "2026-08-11T00:31:00+08:00",
                "expires_at": "2026-08-11T00:35:00+08:00",
            },
            {"expires_at": "2026-08-11T00:30:00+08:00"},
            {
                "not_before": "2026-08-11T00:20:00+08:00",
                "expires_at": "2026-08-11T00:35:01+08:00",
            },
        )
        for changes in cases:
            with self.subTest(changes=changes):
                _write_json(self.path, {**self.valid, **changes})
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.load_universe_publication_approval(self.path, now=NOW)


class RealtimeAcceptedReadTests(unittest.TestCase):
    def test_open_schema_locked_and_missing_accepted_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            missing = Path(tmp) / "missing.sqlite3"
            with self.assertRaises(collector.MarketScanIncomplete):
                collector.load_realtime_accepted_universe_read_only(missing)
            schema_missing = Path(tmp) / "schema.sqlite3"
            sqlite3.connect(schema_missing).close()
            with self.assertRaises(collector.MarketScanIncomplete):
                collector.load_realtime_accepted_universe_read_only(schema_missing)
            no_accepted = Path(tmp) / "empty.sqlite3"
            db = sqlite3.connect(no_accepted)
            try:
                db.execute(
                    "CREATE TABLE stream_connection_events (event_at TEXT,event_type TEXT,universe_hash TEXT,token_count INTEGER)"
                )
                db.commit()
            finally:
                db.close()
            with self.assertRaises(collector.MarketScanIncomplete):
                collector.load_realtime_accepted_universe_read_only(no_accepted)

    def test_mode_ro_and_success_and_error_connections_are_closed(self) -> None:
        class FakeConnection:
            def __init__(self, *, fail: bool = False) -> None:
                self.fail = fail
                self.closed = False

            def execute(self, _query):
                if self.fail:
                    raise sqlite3.OperationalError("locked")
                return self

            def fetchone(self):
                return (HASH_A, 2)

            def close(self):
                self.closed = True

        for fail in (False, True):
            fake = FakeConnection(fail=fail)
            with self.subTest(fail=fail), patch.object(
                collector.sqlite3, "connect", return_value=fake
            ) as connect:
                if fail:
                    with self.assertRaises(collector.MarketScanIncomplete):
                        collector.load_realtime_accepted_universe_read_only(Path("fixture.sqlite3"))
                else:
                    self.assertEqual(
                        collector.load_realtime_accepted_universe_read_only(Path("fixture.sqlite3")),
                        {"token_hash": HASH_A, "token_count": 2},
                    )
                self.assertIn("mode=ro", connect.call_args.args[0])
                self.assertTrue(connect.call_args.kwargs["uri"])
                self.assertTrue(fake.closed)


class PublicationAuthorizationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.research_path = root / "research.sqlite3"
        self.realtime_path = root / "realtime.sqlite3"
        self.approval_path = root / "approval.json"
        self.current_hash, self.db = _seed_research(self.research_path)
        self.addCleanup(self.db.close)
        _seed_realtime(self.realtime_path, self.current_hash)
        self.record = _record()
        self.statuses = _complete_statuses(self.record)
        self.candidate = collector.build_research_universe_candidate([self.record])
        self.valid_approval = _approval(self.current_hash, self.candidate)
        _write_json(self.approval_path, self.valid_approval)

    def authorize(self, *, records=None, statuses=None, now=NOW):
        return collector.authorize_research_universe_publication(
            records or [self.record],
            self.statuses if statuses is None else statuses,
            approval_path=self.approval_path,
            realtime_database_path=self.realtime_path,
            research_database_path=self.research_path,
            now=now,
        )

    def test_expected_current_hash_and_count_are_exactly_bound(self) -> None:
        for name, changes, realtime_count in (
            ("hash", {"expected_current_hash": "c" * 64}, 2),
            ("count", {}, 1),
        ):
            with self.subTest(name=name):
                if changes:
                    _write_json(self.approval_path, {**self.valid_approval, **changes})
                if realtime_count != 2:
                    self.realtime_path.unlink()
                    _seed_realtime(self.realtime_path, self.current_hash, realtime_count)
                with self.assertRaises(collector.MarketScanIncomplete):
                    self.authorize()
                _write_json(self.approval_path, self.valid_approval)

    def test_candidate_hash_count_and_each_diff_fact_are_exactly_bound(self) -> None:
        cases = (
            {"approved_candidate_hash": "c" * 64},
            {"approved_token_count": 2},
            {"approved_removed_count": 0},
            {"approved_removed_token_hash": "d" * 64},
            {"allowed_removed_target_dates": ["2026-08-09"]},
        )
        for changes in cases:
            with self.subTest(changes=changes):
                _write_json(self.approval_path, {**self.valid_approval, **changes})
                with self.assertRaises(collector.MarketScanIncomplete):
                    self.authorize()

    def test_added_remapped_shared_rewrite_and_incomplete_scan_fail_closed(self) -> None:
        added = _record(token_id="7001", other_token="7002", market_id="added")
        remapped = _record(market_id="rewritten-market")
        bad_statuses = list(self.statuses)
        bad_statuses[0] = {
            **bad_statuses[0],
            "attribution_status": "search_failed",
            "reason_code": "search_request_failed",
        }
        for name, records, statuses in (
            ("added", [self.record, added], self.statuses),
            ("shared_rewrite", [remapped], _complete_statuses(remapped)),
            ("scan_incomplete", [self.record], bad_statuses),
        ):
            with self.subTest(name=name), self.assertRaises(collector.MarketScanIncomplete):
                self.authorize(records=records, statuses=statuses)

    def test_past_candidate_and_non_homogeneous_v1_fail_closed(self) -> None:
        past = _record(
            target_date="2026-08-10", scanned_at="2026-08-10T00:30:00+08:00"
        )
        past_candidate = collector.build_research_universe_candidate([past])
        _write_json(self.approval_path, _approval(self.current_hash, past_candidate))
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize(records=[past], statuses=_complete_statuses(past))
        _write_json(self.approval_path, self.valid_approval)
        malformed = {**self.record, "schema": "research_market_attribution.v2"}
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize(records=[malformed])

    def test_all_facts_match_and_existing_identical_publication_is_idempotent(self) -> None:
        decision = self.authorize()
        self.assertFalse(decision["already_published"])
        self.assertEqual(decision["candidate"]["diff"]["removed"], ("9001",))
        collector.publish_market_universe(
            self.db,
            SCANNED_AT,
            decision["candidate"]["members"],
            "complete_scan",
        )
        self.db.commit()
        again = self.authorize()
        self.assertTrue(again["already_published"])
        before = self.db.execute(
            "SELECT COUNT(*) FROM market_universe_publications"
        ).fetchone()[0]
        self.assertEqual(before, 2)


class ForwardMixedApprovalTests(unittest.TestCase):
    """The forward transition needs its own schema, never a widened v1."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.research_path = root / "research.sqlite3"
        self.realtime_path = root / "realtime.sqlite3"
        self.approval_path = root / "approval.json"
        self.current_hash, self.db = _seed_research(self.research_path)
        self.addCleanup(self.db.close)
        _seed_realtime(self.realtime_path, self.current_hash)
        self.shared = _record()
        self.added = _record(token_id="7001", other_token="7002", market_id="market-added")
        self.records = [self.shared, self.added]
        self.statuses = _complete_statuses(self.shared)
        self.candidate = collector.build_research_universe_candidate(self.records)
        self.valid = _forward_mixed_approval(self.current_hash, self.candidate)
        _write_json(self.approval_path, self.valid)

    def authorize(self, *, now=NOW):
        return collector.authorize_research_universe_publication(
            self.records,
            self.statuses,
            approval_path=self.approval_path,
            realtime_database_path=self.realtime_path,
            research_database_path=self.research_path,
            now=now,
        )

    def test_explicit_v2_forward_mixed_binds_added_removed_hashes_and_dates(self) -> None:
        decision = self.authorize()
        self.assertEqual(decision["approval"]["schema"], "universe_publication_approval.v2")
        self.assertEqual(decision["candidate"]["diff"], {
            "added": ("7001",), "removed": ("9001",), "remapped": (), "pure_add": False,
        })

    def test_v1_nonzero_added_remains_rejected_and_v2_drift_fails_closed(self) -> None:
        cases = (
            _approval(self.current_hash, self.candidate, approved_added_count=1),
            _forward_mixed_approval(self.current_hash, self.candidate, approved_added_count=0),
            _forward_mixed_approval(self.current_hash, self.candidate, approved_removed_count=0),
            _forward_mixed_approval(self.current_hash, self.candidate, approved_remapped_count=1),
            _forward_mixed_approval(self.current_hash, self.candidate, approved_added_token_hash="c" * 64),
            _forward_mixed_approval(self.current_hash, self.candidate, approved_removed_token_hash="d" * 64),
            _forward_mixed_approval(self.current_hash, self.candidate, allowed_added_target_dates=["2026-08-10"]),
            _forward_mixed_approval(self.current_hash, self.candidate, allowed_removed_target_dates=["2026-08-11"]),
            _forward_mixed_approval(self.current_hash, self.candidate, transition="wrong"),
        )
        for approval in cases:
            with self.subTest(schema=approval["schema"], changes=approval):
                _write_json(self.approval_path, approval)
                with self.assertRaises(collector.MarketScanIncomplete):
                    self.authorize()

    def test_forward_mixed_requires_china_midnight_to_six_window(self) -> None:
        allowed = (
            datetime.fromisoformat("2026-08-11T00:00:00+08:00"),
            datetime.fromisoformat("2026-08-11T03:00:00+08:00"),
            datetime.fromisoformat("2026-08-11T05:59:59+08:00"),
        )
        for now in allowed:
            approval = _forward_mixed_approval(
                self.current_hash,
                self.candidate,
                not_before=(now.replace(microsecond=0)).isoformat(),
                expires_at=(now.replace(microsecond=0) + timedelta(minutes=10)).isoformat(),
            )
            _write_json(self.approval_path, approval)
            with self.subTest(now=now):
                self.authorize(now=now)

        for now in (
            datetime.fromisoformat("2026-08-10T23:59:59+08:00"),
            datetime.fromisoformat("2026-08-11T06:00:00+08:00"),
        ):
            approval = _forward_mixed_approval(
                self.current_hash,
                self.candidate,
                not_before=now.isoformat(),
                expires_at=(now + timedelta(minutes=10)).isoformat(),
            )
            _write_json(self.approval_path, approval)
            with self.subTest(now=now), self.assertRaises(collector.MarketScanIncomplete):
                self.authorize(now=now)

    def test_forward_mixed_shared_rewrite_and_past_added_are_rejected(self) -> None:
        rewritten = _record(market_id="market-rewritten")
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.authorize_research_universe_publication(
                [rewritten, self.added], _complete_statuses(rewritten),
                approval_path=self.approval_path,
                realtime_database_path=self.realtime_path,
                research_database_path=self.research_path,
                now=NOW,
            )
        past = _record(
            token_id="7001", other_token="7002", market_id="market-added",
            target_date="2026-08-10", scanned_at="2026-08-09T16:30:00+00:00",
        )
        past_candidate = collector.build_research_universe_candidate([past])
        _write_json(self.approval_path, _forward_mixed_approval(self.current_hash, past_candidate))
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.authorize_research_universe_publication(
                [past], _complete_statuses(past),
                approval_path=self.approval_path,
                realtime_database_path=self.realtime_path,
                research_database_path=self.research_path,
                now=NOW,
            )

    def test_v2_unknown_or_mixed_fields_never_fall_back_to_v1(self) -> None:
        for changes in (
            {"schema": "universe_publication_approval.v3"},
            {"transition": "legacy_to_v1_forward_mixed", "approved_added_count": 0},
            {"unexpected": "field"},
        ):
            with self.subTest(changes=changes):
                _write_json(self.approval_path, {**self.valid, **changes})
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.load_universe_publication_approval(self.approval_path, now=NOW)


class PublicationIntegrationTests(unittest.TestCase):
    class DetailClient:
        def __init__(self, detail: dict) -> None:
            self.detail = detail

        async def get(self, url: str, *_args, **_kwargs):
            if url.endswith(f"/events/{self.detail['id']}"):
                return PublicationIntegrationTests.Response(self.detail)
            raise AssertionError(url)

    class Response:
        def __init__(self, payload: object) -> None:
            self.payload = payload

        def raise_for_status(self) -> None:
            return None

        def json(self) -> object:
            return self.payload

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.research_path = root / "research.sqlite3"
        self.realtime_path = root / "realtime.sqlite3"
        self.approval_path = root / "approval.json"
        self.current_hash, self.db = _seed_research(self.research_path)
        self.addCleanup(self.db.close)
        _seed_realtime(self.realtime_path, self.current_hash)
        self.record = _record(scan_id=f"market-scan:{SCANNED_AT}")
        self.candidate = collector.build_research_universe_candidate([self.record])
        _write_json(self.approval_path, _approval(self.current_hash, self.candidate))
        self.detail = {
            "id": self.record["event_id"],
            "title": self.record["event_title"],
            "resolutionSource": _source("Wuhan", "ZHHH"),
            "active": True,
            "closed": False,
            "_query_city": "Wuhan",
            "_query_target_date": "2026-08-11",
            "markets": [
                {
                    "id": "market-current",
                    "question": "Will the highest temperature in Wuhan be 30 C on August 11?",
                    "resolutionSource": _source("Wuhan", "ZHHH"),
                    "outcomes": json.dumps(["Yes", "No"]),
                    "clobTokenIds": json.dumps(["1001", "1002"]),
                    "groupItemTitle": "30 C",
                    "active": True,
                    "closed": False,
                }
            ],
        }

    def active_events(self, _client, _progress, *, query_date, query_results):
        for item in _complete_statuses(self.record):
            status = item["attribution_status"]
            query_results.append(
                {
                    "query_city": item["city"],
                    "query_target_date": item["target_date"],
                    "status": "pending" if status == "verified" else status,
                    "reason_code": (
                        "event_detail_pending" if status == "verified" else item["reason_code"]
                    ),
                }
            )
        return [
            {
                key: self.detail[key]
                for key in (
                    "id",
                    "title",
                    "active",
                    "closed",
                    "_query_city",
                    "_query_target_date",
                )
            }
        ]

    def collect(self) -> int:
        with patch.object(collector, "active_events", side_effect=self.active_events):
            return asyncio.run(
                collector.collect_markets(
                    self.DetailClient(self.detail),
                    self.db,
                    SCANNED_AT,
                    approval_path=self.approval_path,
                    realtime_database_path=self.realtime_path,
                    research_database_path=self.research_path,
                    approval_now=NOW,
                )
            )

    def snapshot(self):
        return {
            "snapshots": self.db.execute(
                "SELECT * FROM market_snapshots ORDER BY captured_at,market_id"
            ).fetchall(),
            "rules": self.db.execute("SELECT * FROM market_rules ORDER BY market_id").fetchall(),
            "publications": self.db.execute(
                "SELECT publication_id,published_at,token_hash,token_count,members_json,reason "
                "FROM market_universe_publications ORDER BY published_at"
            ).fetchall(),
        }

    def test_all_matching_publishes_one_complete_v1_and_repeat_is_idempotent(self) -> None:
        self.assertEqual(self.collect(), 1)
        first = self.snapshot()
        self.assertEqual(len(first["publications"]), 2)
        latest = first["publications"][-1]
        members = json.loads(latest[4])
        self.assertEqual(latest[2], self.candidate["token_hash"])
        self.assertEqual(latest[3], 1)
        self.assertEqual(latest[5], "complete_scan")
        self.assertEqual({member["schema"] for member in members}, {collector.RESEARCH_MARKET_SCHEMA})
        self.assertEqual(self.collect(), 1)
        self.assertEqual(self.snapshot(), first)

    def test_missing_approval_never_falls_back_to_legacy_or_shrunken_publication(self) -> None:
        self.approval_path.unlink()
        before = self.snapshot()
        self.assertEqual(self.collect(), 0)
        self.assertEqual(self.snapshot(), before)

    def test_transaction_failure_preserves_snapshot_rules_publication_and_active_state(self) -> None:
        before = self.snapshot()
        with patch.object(
            collector, "publish_market_universe", side_effect=sqlite3.OperationalError("write failed")
        ):
            with self.assertRaises(sqlite3.OperationalError):
                self.collect()
        self.assertEqual(self.snapshot(), before)

    def test_forward_mixed_v2_publishes_only_after_all_pretransaction_gates(self) -> None:
        added = {
            **self.detail["markets"][0],
            "id": "market-added",
            "clobTokenIds": json.dumps(["7001", "7002"]),
        }
        self.detail["markets"].append(added)
        added_record = _record(
            token_id="7001", other_token="7002", market_id="market-added",
            scan_id=f"market-scan:{SCANNED_AT}",
        )
        candidate = collector.build_research_universe_candidate([self.record, added_record])
        _write_json(
            self.approval_path,
            _forward_mixed_approval(self.current_hash, candidate),
        )
        self.assertEqual(self.collect(), 1)
        latest = self.snapshot()["publications"][-1]
        self.assertEqual(latest[2], candidate["token_hash"])
        self.assertEqual(latest[3], 2)

    def test_forward_mixed_binding_failure_occurs_before_any_write(self) -> None:
        added = {
            **self.detail["markets"][0],
            "id": "market-added",
            "clobTokenIds": json.dumps(["7001", "7002"]),
        }
        self.detail["markets"].append(added)
        added_record = _record(
            token_id="7001", other_token="7002", market_id="market-added",
            scan_id=f"market-scan:{SCANNED_AT}",
        )
        candidate = collector.build_research_universe_candidate([self.record, added_record])
        _write_json(
            self.approval_path,
            _forward_mixed_approval(self.current_hash, candidate, approved_added_token_hash="c" * 64),
        )
        before = self.snapshot()
        self.assertEqual(self.collect(), 0)
        self.assertEqual(self.snapshot(), before)


if __name__ == "__main__":
    unittest.main()
