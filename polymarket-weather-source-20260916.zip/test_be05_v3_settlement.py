import sqlite3
import unittest
from datetime import UTC, datetime

from be05_v3_settlement import (
    append_resolution_evidence,
    ensure_settlement_schema,
    final_market_resolutions,
    final_resolution_map,
)


class V3SettlementEvidenceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.db = sqlite3.connect(":memory:")
        ensure_settlement_schema(self.db)
        self.base = {
            "observed_at": datetime(2026, 8, 17, 1, tzinfo=UTC).isoformat(),
            "market_id": "market-31",
            "city": "Shanghai",
            "station": "ZSPD",
            "target_date": "2026-08-16",
            "question": "Will the highest temperature in Shanghai be 31 C on August 16?",
            "bucket_label": "31 C",
            "yes_resolved": 1,
            "yes_price": "1",
            "outcome_prices_json": '["1", "0"]',
            "resolution_source": "https://www.wunderground.com/weather/cn/shanghai/ZSPD",
            "market_active": False,
            "market_closed": True,
            "state": "final",
        }

    def tearDown(self) -> None:
        self.db.close()

    def test_final_closed_evidence_is_visible_and_idempotent(self) -> None:
        self.assertTrue(append_resolution_evidence(self.db, **self.base))
        self.assertFalse(append_resolution_evidence(self.db, **self.base))
        rows = final_market_resolutions(self.db)
        self.assertEqual(len(rows), 1)
        self.assertEqual(
            (rows[0]["market_id"], rows[0]["yes_resolved"], rows[0]["station"]),
            ("market-31", 1, "ZSPD"),
        )

    def test_final_preserves_live_gamma_active_true_when_closed(self) -> None:
        live_gamma_final = {**self.base, "market_active": True}
        self.assertTrue(append_resolution_evidence(self.db, **live_gamma_final))
        rows = final_market_resolutions(self.db)
        self.assertEqual(len(rows), 1)
        self.assertEqual(
            self.db.execute(
                "SELECT market_active,market_closed FROM market_resolution_evidence"
            ).fetchone(),
            (1, 1),
        )

    def test_open_provisional_winner_never_becomes_final(self) -> None:
        provisional = {
            **self.base,
            "market_active": True,
            "market_closed": False,
            "state": "provisional",
        }
        self.assertTrue(append_resolution_evidence(self.db, **provisional))
        self.assertEqual(final_market_resolutions(self.db), [])

    def test_final_requires_closed_identity_time_and_station(self) -> None:
        mutations = (
            {"market_closed": False},
            {"observed_at": "2026-08-17T01:00:00"},
            {"station": "ZBAA"},
            {"target_date": "not-a-date"},
            {"yes_price": "nan"},
        )
        for mutation in mutations:
            with self.subTest(mutation=mutation):
                self.assertFalse(append_resolution_evidence(self.db, **{**self.base, **mutation}))
        self.assertEqual(final_market_resolutions(self.db), [])

    def test_resolution_source_is_non_authoritative_metadata(self) -> None:
        sources = (
            "https://www.weather.gov/wrh/timeseries?site=zspd",
            "https://www.wunderground.com/weather/cn/shanghai/ZSPD",
            "https://example.invalid/settlement",
            "",
        )
        for index, source in enumerate(sources):
            evidence = {
                **self.base,
                "market_id": f"source-market-{index}",
                "resolution_source": source,
            }
            self.assertTrue(append_resolution_evidence(self.db, **evidence))
        rows = final_market_resolutions(self.db)
        self.assertEqual(len(rows), len(sources))
        self.assertEqual({row["yes_resolved"] for row in rows}, {1})

    def test_final_requires_binary_payout_not_near_certain_price(self) -> None:
        invalid = {
            **self.base,
            "outcome_prices_json": '["0.99", "0.01"]',
            "yes_price": "0.99",
        }
        self.assertFalse(append_resolution_evidence(self.db, **invalid))

    def test_mutated_row_hash_fails_closed(self) -> None:
        self.assertTrue(append_resolution_evidence(self.db, **self.base))
        self.db.execute(
            "UPDATE market_resolution_evidence SET bucket_label='32 C' WHERE market_id='market-31'"
        )
        self.assertEqual(final_market_resolutions(self.db), [])

    def test_conflicting_final_revisions_fail_closed(self) -> None:
        self.assertTrue(append_resolution_evidence(self.db, **self.base))
        loser = {
            **self.base,
            "observed_at": datetime(2026, 8, 17, 2, tzinfo=UTC).isoformat(),
            "yes_resolved": 0,
            "yes_price": "0",
            "outcome_prices_json": '["0", "1"]',
        }
        self.assertTrue(append_resolution_evidence(self.db, **loser))
        self.assertEqual(final_market_resolutions(self.db), [])

    def test_selected_set_requires_every_exact_city_date_market(self) -> None:
        self.assertTrue(append_resolution_evidence(self.db, **self.base))
        self.assertEqual(
            set(
                final_resolution_map(
                    self.db,
                    ["market-31", "market-32"],
                    city="Shanghai",
                    target_date="2026-08-16",
                )
            ),
            {"market-31"},
        )
        self.assertEqual(
            final_resolution_map(
                self.db,
                ["market-31"],
                city="Beijing",
                target_date="2026-08-16",
            ),
            {},
        )

    def test_missing_or_legacy_schema_is_not_authoritative(self) -> None:
        legacy = sqlite3.connect(":memory:")
        try:
            legacy.execute(
                "CREATE TABLE market_resolutions(market_id TEXT,yes_resolved INTEGER,resolved_at TEXT)"
            )
            legacy.execute(
                "INSERT INTO market_resolutions VALUES ('market-31',1,'2026-08-17T01:00:00+00:00')"
            )
            self.assertEqual(final_market_resolutions(legacy), [])
        finally:
            legacy.close()


if __name__ == "__main__":
    unittest.main()
