from __future__ import annotations

import sqlite3
import tempfile
import unittest
from pathlib import Path

from ui_events import domain_revision, ensure_realtime_events, ensure_research_events, high_water, read_after


class DashboardEventTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "research.sqlite3"
        self.db = sqlite3.connect(self.path)
        self.db.executescript("""
          CREATE TABLE latest_bbo(token_id TEXT PRIMARY KEY);
          CREATE TABLE market_snapshots(market_id TEXT, captured_at TEXT, PRIMARY KEY(market_id,captured_at));
          CREATE TABLE forecast_snapshots(city TEXT, model TEXT, captured_at TEXT, PRIMARY KEY(city,model,captured_at));
          CREATE TABLE forecast_d0_registry(city TEXT, source TEXT, PRIMARY KEY(city,source));
          CREATE TABLE market_resolutions(market_id TEXT PRIMARY KEY);
          CREATE TABLE service_heartbeats(service TEXT PRIMARY KEY);
        """)
        ensure_research_events(self.db)
        self.db.commit()

    def tearDown(self) -> None:
        self.db.close()
        self.temp.cleanup()

    def test_events_are_visible_only_after_commit(self) -> None:
        self.db.execute("INSERT INTO forecast_snapshots VALUES ('Beijing','gfs','t1')")
        self.assertEqual(high_water(self.path), 0)
        self.db.commit()
        rows, gap = read_after(self.path, 0)
        self.assertFalse(gap)
        self.assertEqual(rows[-1][1], "forecasts")

    def test_quote_updates_only_revision_not_outbox(self) -> None:
        realtime = Path(self.temp.name) / "realtime.sqlite3"
        quote_db = sqlite3.connect(realtime)
        quote_db.execute("CREATE TABLE latest_bbo(token_id TEXT PRIMARY KEY)")
        ensure_realtime_events(quote_db)
        quote_db.execute("INSERT INTO latest_bbo VALUES ('token-a')")
        quote_db.commit()
        quote_db.close()
        self.assertGreater(domain_revision(realtime, "quotes"), 0)
        self.assertEqual(high_water(realtime), 0)

    def test_outbox_is_ordered_and_deduplicable_by_domain(self) -> None:
        self.db.execute("INSERT INTO market_snapshots VALUES ('m1','t1')")
        self.db.execute("INSERT INTO market_resolutions VALUES ('m1')")
        self.db.commit()
        rows, gap = read_after(self.path, 0)
        self.assertFalse(gap)
        self.assertEqual([domain for _, domain in rows], ["markets", "settlements"])


if __name__ == "__main__":
    unittest.main()
