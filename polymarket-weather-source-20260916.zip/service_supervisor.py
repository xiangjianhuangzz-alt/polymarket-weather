"""Keep collector and quote stream alive independently of the dashboard UI."""
from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import sys
import time
import uuid
import logging
import re
from datetime import UTC, datetime, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parent
from db_paths import OBSERVATIONS_DB, RESEARCH_DB, REALTIME_DB
from stability_audit import RuntimeLogTail, StabilityAudit
from runtime_logging import configure_runtime_logging
from runtime_environment import allowed_runtime_values, child_environment
DB = RESEARCH_DB
RUNTIME_DIR = BASE / "data" / "runtime"
LOCK = RUNTIME_DIR / "supervisor.lock"
STATUS = RUNTIME_DIR / "supervisor_status.json"
STABILITY_DB = BASE / "data" / "stability_audit.sqlite3"
BASE_PYTHON = Path(getattr(sys, "_base_executable", sys.executable))
VENV_SITE = BASE / ".venv" / "Lib" / "site-packages"
CHECK_SECONDS = 5
STALE_SECONDS = {"collector": 8 * 60, "realtime_stream": 90, "metar_collector": 150}
GRACE_SECONDS = {"collector": 90, "realtime_stream": 45, "metar_collector": 45}
COLLECTOR_PHASE_GRACE_SECONDS = 45
# A worker that repeatedly fails must stop visibly rather than be restarted
# forever.  The dashboard can then truthfully show a halted service and no
# new paper entry is attempted until a deliberate supervisor restart.
RESTART_LIMIT = {"collector": 5, "realtime_stream": 5, "metar_collector": 5}
RESTART_WINDOW_SECONDS = 10 * 60
SUPERVISOR_INSTANCE_ID = uuid.uuid4().hex
WORKERS = {
    "collector": [str(BASE_PYTHON), str(BASE / "collector.py")],
    "realtime_stream": [str(BASE_PYTHON), str(BASE / "realtime_stream.py")],
    "metar_collector": [str(BASE_PYTHON), str(BASE / "metar_collector.py")],
}
def utc_now() -> datetime:
    return datetime.now(UTC)


def parse_utc(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return result if result.tzinfo else result.replace(tzinfo=UTC)
    except ValueError:
        return None


def heartbeat(service: str) -> tuple[float | None, str | None]:
    database = (REALTIME_DB if service == "realtime_stream"
                else OBSERVATIONS_DB if service == "metar_collector" else DB)
    if not database.exists():
        return None, None
    try:
        db = sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=2)
        row = db.execute("SELECT updated_at,detail FROM service_heartbeats WHERE service=?", (service,)).fetchone()
        db.close()
        stamp = parse_utc(row[0]) if row else None
        return ((utc_now() - stamp).total_seconds(), row[1]) if stamp else (None, None)
    except sqlite3.Error as exc:
        logging.warning("cannot read %s heartbeat: %s", service, exc)
        return None, None


def collector_restart_reason(age_seconds: float | None, detail: str | None,
                             now: datetime | None = None) -> str | None:
    """Distinguish a slow, progressing collection phase from a dead worker.

    Older collector heartbeats have no structured phase data and retain the
    legacy stale rule.  New heartbeats provide a phase deadline; a worker is
    only restarted after that deadline plus a small supervisor grace period.
    """
    if age_seconds is None:
        return None
    now = now or utc_now()
    if detail and "state=running" in detail:
        phase_match = re.search(r"(?:^|;)\s*phase=([^;\s]+)", detail)
        deadline_match = re.search(r"(?:^|;)\s*deadline_at=([^;\s]+)", detail)
        deadline = parse_utc(deadline_match.group(1)) if deadline_match else None
        if deadline:
            if now > deadline + timedelta(seconds=COLLECTOR_PHASE_GRACE_SECONDS):
                phase = phase_match.group(1) if phase_match else "unknown"
                return f"phase_deadline_exceeded:{phase}"
            return None
    if age_seconds > STALE_SECONDS["collector"]:
        return f"heartbeat_stale:{int(age_seconds)}s"
    return None


def latest_quote_age() -> float | None:
    """A live websocket is insufficient: prove that quotes are reaching SQLite."""
    if not REALTIME_DB.exists():
        return None
    try:
        db = sqlite3.connect(f"file:{REALTIME_DB}?mode=ro", uri=True, timeout=2)
        # Use the bounded live projection.  Scanning the historical BBO table
        # here can itself time out and hide an otherwise healthy quote stream.
        row = db.execute("SELECT MAX(captured_at) FROM latest_bbo").fetchone()
        db.close()
        stamp = parse_utc(row[0]) if row else None
        return (utc_now() - stamp).total_seconds() if stamp else None
    except sqlite3.Error:
        return None


def active_strategy_yes_tokens() -> set[str]:
    """Return only active temperature-market YES token ids for audit metrics.

    This is a read-only research query.  Forecast/market discovery remains
    owned by the collector; the supervisor merely freezes the measurement
    universe used to judge quote freshness.
    """
    tokens: set[str] = set()
    try:
        with sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=2) as db:
            manifest = db.execute("""SELECT members_json FROM market_universe_publications
                                   ORDER BY published_at DESC LIMIT 1""").fetchone()
            if manifest:
                try:
                    members = json.loads(manifest[0])
                    published = {str(item["token_id"]) for item in members
                                 if isinstance(item, dict) and item.get("token_id")}
                    if published:
                        return published
                except (TypeError, KeyError, json.JSONDecodeError):
                    logging.warning("invalid published market universe; falling back to snapshot query")
            rows = db.execute("""SELECT m.tokens_json,m.outcomes_json
              FROM market_snapshots m JOIN (
                SELECT market_id,MAX(captured_at) captured_at
                FROM market_snapshots GROUP BY market_id
              ) latest ON latest.market_id=m.market_id AND latest.captured_at=m.captured_at
              WHERE m.active=1 AND m.question LIKE '%highest temperature%'""").fetchall()
        for raw_tokens, raw_outcomes in rows:
            try:
                market_tokens = json.loads(raw_tokens or "[]")
                outcomes = json.loads(raw_outcomes or "[]")
                index = [str(value).strip().lower() for value in outcomes].index("yes")
                token = str(market_tokens[index]).strip()
                if token:
                    tokens.add(token)
            except (ValueError, TypeError, IndexError, json.JSONDecodeError):
                continue
    except sqlite3.Error as exc:
        logging.warning("cannot read active strategy token universe: %s", exc)
    return tokens


def pid_exists(pid: int) -> bool:
    """Return whether a process is actually running, including on Windows.

    ``os.kill(pid, 0)`` isn't a trustworthy liveness check on all Windows
    process handles: a terminated child can still be reported as addressable
    briefly.  The supervisor must fail closed here, otherwise it can display
    a fresh-looking old heartbeat while a quote worker no longer exists.
    """
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes

        synchronize = 0x00100000
        query_limited_information = 0x00001000
        still_active = 259
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(synchronize | query_limited_information, False, pid)
        if not handle:
            return False
        try:
            code = ctypes.c_ulong()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
                return False
            return code.value == still_active
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def write_status(workers: dict[str, dict]) -> None:
    payload = {"updated_at": utc_now().isoformat(), "supervisor_pid": os.getpid(),
               "supervisor_instance_id": SUPERVISOR_INSTANCE_ID, "workers": workers}
    temporary = STATUS.with_name(f".{STATUS.stem}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    # Antivirus/indexing can transiently hold the status file on Windows.
    # Status reporting must not kill the worker supervisor in that case.
    for attempt in range(3):
        try:
            temporary.replace(STATUS)
            return
        except PermissionError:
            time.sleep(0.1 * (attempt + 1))
    logging.warning("could not refresh supervisor status after retries")


def acquire_lock() -> bool:
    """Acquire exclusive supervisor ownership without trusting a fresh status file.

    The lock owner PID is authoritative for liveness.  Status timestamps are
    diagnostic only: after a crash they can be fresh even though no supervisor
    exists.  An unreadable lock fails closed rather than risking two writers.
    """
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        try:
            raw = LOCK.read_text(encoding="utf-8").strip()
            parsed = json.loads(raw) if raw.startswith("{") else {"pid": int(raw)}
            owner_pid = int(parsed["pid"])
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
            logging.error("supervisor lock is unreadable; refusing unsafe takeover")
            return False
        if pid_exists(owner_pid):
            logging.warning("supervisor lock is owned by live pid=%s; refusing duplicate start", owner_pid)
            return False
        # The owner is conclusively dead.  A concurrent starter can only win
        # the next O_EXCL creation; recursion then sees its live lock and
        # returns False, so this cannot create duplicate supervisors.
        LOCK.unlink(missing_ok=True)
        return acquire_lock()
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        json.dump({"pid": os.getpid(), "instance_id": SUPERVISOR_INSTANCE_ID,
                   "started_at": utc_now().isoformat()}, handle)
    return True


def spawn(name: str) -> subprocess.Popen:
    # Reload configuration for each replacement worker.  This lets a reviewed
    # paper-strategy mode change take effect on the next simulator restart
    # without restarting the independent collector or quote stream.
    environment = child_environment(dotenv_path=BASE / ".env", pythonpath=VENV_SITE)
    # Run the real interpreter directly while retaining the project's virtual
    # environment packages.  The old venv launcher spawned an untracked child
    # process, which was the root cause of the duplicate-stream storm.
    # BASE_PYTHON is the real interpreter, not a .venv launcher.  The Popen
    # PID is therefore the worker PID that we supervise and terminate.
    return subprocess.Popen(WORKERS[name], cwd=BASE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=environment,
                            creationflags=(getattr(subprocess, "CREATE_NO_WINDOW", 0) |
                                           getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)), close_fds=True)


def terminate_tree(child: subprocess.Popen) -> None:
    """Stop a worker and every descendant, never leaving an orphan writer."""
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(child.pid), "/T", "/F"], stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, check=False)
        return
    child.terminate()


def main() -> None:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    (RUNTIME_DIR / "logs").mkdir(exist_ok=True)
    configure_runtime_logging("supervisor")
    if allowed_runtime_values(BASE / ".env").get(
        "RUNTIME_TOPOLOGY", "legacy"
    ).strip().lower() == "isolated":
        logging.error("legacy aggregate supervisor disabled by RUNTIME_TOPOLOGY=isolated")
        return
    if not acquire_lock():
        logging.warning("supervisor already active; refusing duplicate start")
        return
    children: dict[str, subprocess.Popen] = {}
    audit = StabilityAudit(STABILITY_DB)
    audit.begin_window("stage_e_instrumentation_enabled")
    runtime_logs = RUNTIME_DIR / "logs"
    worker_logs = [runtime_logs / f"{name}.log" for name in WORKERS]
    log_tail = RuntimeLogTail()
    log_tail.prime(worker_logs)
    started: dict[str, float] = {}
    restarts = {name: 0 for name in WORKERS}
    restart_times = {name: [] for name in WORKERS}
    halted: dict[str, str] = {}
    last_audit_sample = 0.0
    last_audit_token_refresh = 0.0
    audit_tokens: set[str] = set()
    try:
        while True:
            monotonic_now = time.monotonic()
            state: dict[str, dict] = {}
            for name in WORKERS:
                if name in halted:
                    state[name] = {"pid": None, "alive": False, "heartbeat_age_seconds": None,
                                   "heartbeat_detail": halted[name], "restarts": restarts[name],
                                   "restart_reason": "circuit_breaker_open"}
                    continue
                child = children.get(name)
                reason = None
                initial_start = child is None
                age, detail = heartbeat(name)
                if child is None:
                    reason = "not_running"
                elif not pid_exists(child.pid):
                    # ``Popen.poll`` can lag after an external Windows force
                    # kill.  The OS PID check keeps a missing collector from
                    # being displayed as alive indefinitely.
                    reason = "pid_missing"
                elif child.poll() is not None:
                    # A real interpreter process exiting is always a worker
                    # failure.  Never treat an old shared heartbeat as proof
                    # that an untracked descendant is healthy.
                    reason = f"worker_exited:{child.returncode}"
                else:
                    if name == "realtime_stream" and detail and "writer=dead" in detail:
                        reason = "quote_writer_dead"
                    # The stream itself reconnects after a 60-second receive
                    # timeout.  Allow it one full reconnect cycle before a
                    # hard restart; the dashboard still marks the quote stale
                    # immediately and the paper engine refuses stale quotes.
                    elif name == "realtime_stream" and (quote_age := latest_quote_age()) is not None and quote_age > 120 and monotonic_now - started[name] > 90:
                        reason = f"quotes_stale:{int(quote_age)}s"
                    elif name == "collector" and monotonic_now - started[name] > GRACE_SECONDS[name] and (collector_reason := collector_restart_reason(age, detail)):
                        reason = collector_reason
                        terminate_tree(child)
                        try:
                            child.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            child.kill()
                    elif age is not None and monotonic_now - started[name] > GRACE_SECONDS[name] and age > STALE_SECONDS[name]:
                        reason = f"heartbeat_stale:{int(age)}s"
                        terminate_tree(child)
                        try:
                            child.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            child.kill()
                if reason:
                    # The first launch after a deliberate supervisor start is
                    # not a failure or a restart.  Counting it as one would
                    # make every fresh Stage-E window fail before any worker
                    # had an opportunity to run.
                    if not initial_start:
                        audit.event(name, "worker_restart", reason)
                    terminate_tree(child) if child is not None else None
                    if not initial_start:
                        restart_times[name] = [stamp for stamp in restart_times[name]
                                               if monotonic_now - stamp <= RESTART_WINDOW_SECONDS]
                        restart_times[name].append(monotonic_now)
                        restarts[name] += 1
                        if len(restart_times[name]) > RESTART_LIMIT[name]:
                            halted[name] = (f"circuit breaker: {len(restart_times[name])} restarts in "
                                            f"{RESTART_WINDOW_SECONDS // 60}m; manual audit required")
                            logging.error("halting %s: %s", name, halted[name])
                            state[name] = {"pid": None, "alive": False, "heartbeat_age_seconds": None,
                                           "heartbeat_detail": halted[name], "restarts": restarts[name],
                                           "restart_reason": "circuit_breaker_open"}
                            continue
                        logging.warning("restarting %s: %s", name, reason)
                    else:
                        logging.info("starting %s", name)
                    children[name] = spawn(name)
                    started[name] = monotonic_now
                age, detail = heartbeat(name)
                active = children[name]
                state[name] = {"pid": active.pid, "alive": active.poll() is None,
                               "heartbeat_age_seconds": round(age, 1) if age is not None else None,
                               "heartbeat_detail": detail, "restarts": restarts[name], "restart_reason": reason}
                if name == "realtime_stream":
                    state[name]["latest_quote_age_seconds"] = round(latest_quote_age(), 1) if latest_quote_age() is not None else None
            if monotonic_now - last_audit_token_refresh >= 60:
                audit_tokens = active_strategy_yes_tokens()
                last_audit_token_refresh = monotonic_now
            for path, line in log_tail.lock_messages(worker_logs):
                audit.event(path.stem, "database_locked", line)
            if monotonic_now - last_audit_sample >= 10:
                audit.sample_quotes(REALTIME_DB, audit_tokens)
                last_audit_sample = monotonic_now
            write_status(state)
            time.sleep(CHECK_SECONDS)
    finally:
        for child in children.values():
            terminate_tree(child)
        LOCK.unlink(missing_ok=True)


if __name__ == "__main__":
    try:
        main()
    except BaseException:
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        (RUNTIME_DIR / "logs").mkdir(exist_ok=True)
        configure_runtime_logging("supervisor")
        logging.exception("supervisor fatal error")
        raise
