"""Read-only health observer for the isolated runtime topology.

The observer never starts, stops or restarts a service.  It opens each
functional database in SQLite read-only mode and writes evidence only to the
separate stability database plus its own atomic status file.
"""
from __future__ import annotations

import json
import logging
import os
import signal
import sqlite3
import threading
import time
from contextlib import closing
from datetime import UTC, datetime, timedelta, timezone
from pathlib import Path

from db_paths import (
    OBSERVATIONS_DB,
    REALTIME_DB,
    RESEARCH_DB,
)
from runtime_instance_lock import AlreadyRunningError, DUPLICATE_INSTANCE_EXIT, guardian_lock
from runtime_logging import configure_runtime_logging
from runtime_status import atomic_json, parse_utc
from stability_audit import RuntimeLogTail, StabilityAudit


BASE = Path(__file__).resolve().parent
RUNTIME_DIR = BASE / "data" / "runtime"
STATUS = RUNTIME_DIR / "services" / "runtime_observer.json"
STABILITY_DB = BASE / "data" / "stability_audit.sqlite3"
POLL_SECONDS = 10
CN = timezone(timedelta(hours=8), name="Asia/Shanghai")
SERVICE_DATABASES = {
    "collector": RESEARCH_DB,
    "realtime_stream": REALTIME_DB,
    "metar_collector": OBSERVATIONS_DB,
}
SERVICE_HEARTBEAT_THRESHOLDS = {
    "collector": 8 * 60,
    "realtime_stream": 90,
    "metar_collector": 150,
}


def utc_now() -> datetime:
    return datetime.now(UTC)


def read_service(service: str, database: Path, *, now: datetime | None = None) -> dict:
    """Read one service independently; one broken database cannot block peers."""
    if not database.exists():
        return {"state": "missing_database", "updated_at": None, "age_seconds": None}
    try:
        with closing(sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=2)) as db:
            row = db.execute(
                "SELECT updated_at,detail FROM service_heartbeats WHERE service=?",
                (service,),
            ).fetchone()
    except sqlite3.Error as exc:
        return {
            "state": "read_error",
            "updated_at": None,
            "age_seconds": None,
            "detail": f"{type(exc).__name__}: {exc}",
        }
    stamp = parse_utc(row[0]) if row else None
    age = ((now or utc_now()) - stamp).total_seconds() if stamp else None
    threshold = SERVICE_HEARTBEAT_THRESHOLDS.get(service)
    state = "missing_heartbeat"
    if age is not None:
        state = "healthy" if threshold is None or age <= threshold else "heartbeat_stale"
    return {
        "state": state,
        "updated_at": row[0] if row else None,
        "age_seconds": round(age, 1) if age is not None else None,
        "detail": row[1] if row else None,
    }


def read_quote_age(database: Path = REALTIME_DB, *, now: datetime | None = None) -> float | None:
    if not database.exists():
        return None
    try:
        with closing(sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=2)) as db:
            row = db.execute("SELECT MAX(captured_at) FROM latest_bbo").fetchone()
    except sqlite3.Error:
        return None
    stamp = parse_utc(row[0]) if row else None
    return ((now or utc_now()) - stamp).total_seconds() if stamp else None


def read_subscribed_universe(database: Path = REALTIME_DB) -> tuple[int | None, str | None]:
    """Read the latest accepted connection or in-place universe transition."""
    if not database.exists():
        return None, None
    try:
        with closing(sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=2)) as db:
            row = db.execute(
                """SELECT token_count,universe_hash FROM stream_connection_events
                   WHERE event_type IN ('connected','universe_changed')
                   ORDER BY event_at DESC LIMIT 1"""
            ).fetchone()
    except sqlite3.Error:
        return None, None
    if not row:
        return None, None
    return (
        int(row[0]) if row[0] is not None else None,
        str(row[1]) if row[1] is not None else None,
    )


def active_strategy_universe(database: Path = RESEARCH_DB) -> tuple[set[str], str | None]:
    """Read the collector's completed manifest without writing or repairing it."""
    if not database.exists():
        return set(), None
    try:
        with closing(sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=2)) as db:
            row = db.execute(
                """SELECT members_json,token_hash FROM market_universe_publications
                   ORDER BY published_at DESC LIMIT 1"""
            ).fetchone()
            if row:
                try:
                    members = json.loads(row[0])
                    tokens = {
                        str(item["token_id"]) for item in members
                        if isinstance(item, dict) and item.get("token_id")
                    }
                    if tokens:
                        return tokens, str(row[1]) if row[1] else None
                except (TypeError, KeyError, json.JSONDecodeError):
                    pass
            rows = db.execute(
                """SELECT m.tokens_json,m.outcomes_json
                   FROM market_snapshots m JOIN (
                     SELECT market_id,MAX(captured_at) captured_at
                     FROM market_snapshots GROUP BY market_id
                   ) latest ON latest.market_id=m.market_id AND latest.captured_at=m.captured_at
                   WHERE m.active=1 AND m.question LIKE '%highest temperature%'"""
            ).fetchall()
    except sqlite3.Error:
        return set(), None
    tokens: set[str] = set()
    for raw_tokens, raw_outcomes in rows:
        try:
            market_tokens = json.loads(raw_tokens or "[]")
            outcomes = json.loads(raw_outcomes or "[]")
            index = [str(value).strip().lower() for value in outcomes].index("yes")
            token = str(market_tokens[index]).strip()
            if token:
                tokens.add(token)
        except (ValueError, TypeError, IndexError, json.JSONDecodeError):
            continue
    return tokens, None


def active_strategy_tokens(database: Path = RESEARCH_DB) -> set[str]:
    """Backward-compatible token-only view used by focused tests and tools."""
    return active_strategy_universe(database)[0]


class RuntimeObserver:
    def __init__(self, *, status_path: Path = STATUS, stability_db: Path = STABILITY_DB,
                 poll_seconds: float = POLL_SECONDS) -> None:
        self.status_path = Path(status_path)
        self.audit = StabilityAudit(Path(stability_db))
        self.poll_seconds = poll_seconds
        self.stop_event = threading.Event()
        self.log_tail = RuntimeLogTail()
        self.worker_logs = [
            RUNTIME_DIR / "logs" / f"{service}.log" for service in SERVICE_DATABASES
        ]
        self.guardian_logs = [
            RUNTIME_DIR / "logs" / f"{service}_guardian.log"
            for service in SERVICE_DATABASES
        ]
        self.log_tail.prime(self.worker_logs)
        self.guardian_log_tail = RuntimeLogTail()
        self.guardian_log_tail.prime(self.guardian_logs)

    def write_status(self, payload: dict) -> bool:
        """Write diagnostic status without becoming a business dependency."""
        try:
            atomic_json(self.status_path, payload)
            return True
        except OSError as exc:
            logging.warning("runtime observer status update skipped: %s", exc)
            return False

    def poll_once(self, *, now: datetime | None = None) -> dict:
        stamp = now or utc_now()
        services = {
            service: read_service(service, database, now=stamp)
            for service, database in SERVICE_DATABASES.items()
        }
        quote_age = read_quote_age(now=stamp)
        subscribed_count, subscribed_hash = read_subscribed_universe(REALTIME_DB)
        realtime = services.get("realtime_stream")
        if realtime is not None:
            realtime["latest_quote_age_seconds"] = round(quote_age, 1) if quote_age is not None else None
            realtime["subscribed_token_count"] = subscribed_count
            realtime["subscribed_universe_hash"] = subscribed_hash
            if realtime.get("state") == "healthy" and (quote_age is None or quote_age >= 20):
                realtime["state"] = "quote_stale"
        for path, line in self.log_tail.lock_messages(self.worker_logs):
            self.audit.event(path.stem, "database_locked", line)
        for path, line in self.guardian_log_tail.restart_messages(self.guardian_logs):
            component = path.stem.removesuffix("_guardian")
            self.audit.event(component, "worker_restart", line)
        tokens, universe_hash = active_strategy_universe()
        self.audit.sample_quotes(
            REALTIME_DB, tokens, expected_universe_hash=universe_hash
        )
        payload = {
            "state": "observing",
            "observer_pid": os.getpid(),
            "updated_at": stamp.isoformat(),
            "services": services,
        }
        self.write_status(payload)
        return payload

    def run(self) -> None:
        self.audit.begin_window("isolated_runtime_observer_started")
        try:
            while not self.stop_event.is_set():
                try:
                    self.poll_once()
                except Exception as exc:
                    logging.exception("runtime observer poll failed")
                    self.write_status({
                        "state": "observer_error",
                        "observer_pid": os.getpid(),
                        "updated_at": utc_now().isoformat(),
                        "error": f"{type(exc).__name__}: {exc}",
                    })
                self.stop_event.wait(self.poll_seconds)
        finally:
            self.write_status({
                "state": "stopped",
                "observer_pid": os.getpid(),
                "updated_at": utc_now().isoformat(),
            })


def install_signal_handlers(observer: RuntimeObserver) -> None:
    def stop(_signum, _frame) -> None:
        observer.stop_event.set()

    for signal_name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        candidate = getattr(signal, signal_name, None)
        if candidate is not None:
            signal.signal(candidate, stop)


def main() -> None:
    configure_runtime_logging("runtime_observer")
    observer = RuntimeObserver()
    install_signal_handlers(observer)
    try:
        with guardian_lock("runtime_observer"):
            observer.run()
    except AlreadyRunningError:
        logging.error("runtime observer already active; refusing duplicate start")
        raise SystemExit(DUPLICATE_INSTANCE_EXIT)
    except BaseException:
        logging.exception("runtime observer fatal error")
        raise


if __name__ == "__main__":
    main()
