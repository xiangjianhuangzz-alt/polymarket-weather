from datetime import datetime, timezone
from decimal import Decimal
import unittest

from execution_evidence import (
    EvidenceError,
    ExecutablePathPoint,
    FeeSchedule,
    LiquidityRole,
    PathOutcome,
    classify_exit_path,
    execution_curve,
    executable_vwap,
    fee_for_trade,
    stop_for_entry,
    target_for_entry,
)


def D(value: str) -> Decimal:
    return Decimal(value)


def point(
    sequence: int,
    sell_vwap: str | None,
    *,
    coverage_ok: bool = True,
) -> ExecutablePathPoint:
    return ExecutablePathPoint(
        sequence=sequence,
        received_at=datetime(2026, 7, 31, 0, 0, sequence, tzinfo=timezone.utc),
        sell_vwap=None if sell_vwap is None else D(sell_vwap),
        coverage_ok=coverage_ok,
    )


class ExecutableVwapTests(unittest.TestCase):
    def test_buy_vwap_consumes_asks_from_low_to_high(self) -> None:
        fill = executable_vwap(
            [(D("0.32"), D("4")), (D("0.31"), D("2"))],
            side="buy",
            quantity=D("5"),
        )
        self.assertIsNotNone(fill)
        assert fill is not None
        self.assertEqual(fill.quantity, D("5"))
        self.assertEqual(fill.vwap, D("0.316"))
        self.assertEqual(fill.worst_price, D("0.32"))
        self.assertEqual(fill.notional, D("1.580"))
        self.assertEqual(fill.levels_used, 2)

    def test_sell_vwap_consumes_bids_high_to_low_and_aggregates_duplicates(self) -> None:
        fill = executable_vwap(
            [
                (D("0.29"), D("2")),
                (D("0.30"), D("2")),
                (D("0.30"), D("2")),
            ],
            side="sell",
            quantity=D("5"),
        )
        self.assertIsNotNone(fill)
        assert fill is not None
        self.assertEqual(fill.vwap, D("0.298"))
        self.assertEqual(fill.worst_price, D("0.29"))
        self.assertEqual(fill.levels_used, 2)

    def test_insufficient_depth_returns_none_instead_of_partial_fill(self) -> None:
        fill = executable_vwap(
            [(D("0.31"), D("2"))],
            side="buy",
            quantity=D("5"),
        )
        self.assertIsNone(fill)

    def test_execution_curve_covers_actual_position_sizes(self) -> None:
        curve = execution_curve(
            bids=[(D("0.29"), D("30"))],
            asks=[(D("0.31"), D("12"))],
        )
        self.assertEqual(tuple(curve.quantities), tuple(map(D, ("5", "10", "15", "20", "25"))))
        self.assertIsNotNone(curve.buy[D("5")])
        self.assertIsNotNone(curve.buy[D("10")])
        self.assertIsNone(curve.buy[D("15")])
        self.assertTrue(all(curve.sell[q] is not None for q in curve.quantities))

    def test_invalid_negative_depth_is_rejected(self) -> None:
        with self.assertRaises(EvidenceError):
            executable_vwap(
                [(D("0.31"), D("-1"))],
                side="buy",
                quantity=D("5"),
            )


class TargetAndFeeTests(unittest.TestCase):
    def test_target_uses_larger_of_three_cents_or_twenty_percent_and_rounds_up(self) -> None:
        plan = target_for_entry(D("0.31"), D("0.01"))
        self.assertEqual(plan.raw_target, D("0.372"))
        self.assertEqual(plan.rounded_target, D("0.38"))
        self.assertTrue(plan.entry_allowed)

    def test_ninety_cent_target_is_allowed_but_above_ninety_is_blocked(self) -> None:
        allowed = target_for_entry(D("0.75"), D("0.01"))
        blocked = target_for_entry(D("0.76"), D("0.01"))
        self.assertEqual(allowed.rounded_target, D("0.90"))
        self.assertTrue(allowed.entry_allowed)
        self.assertEqual(blocked.rounded_target, D("0.92"))
        self.assertFalse(blocked.entry_allowed)

    def test_stop_is_fifty_percent_below_cost(self) -> None:
        self.assertEqual(stop_for_entry(D("0.31")), D("0.155"))

    def test_taker_platform_and_builder_fees_are_both_counted(self) -> None:
        schedule = FeeSchedule(
            version_id="weather-v1",
            platform_rate=D("0.05"),
            platform_taker_only=True,
            maker_builder_bps=0,
            taker_builder_bps=100,
        )
        fee = fee_for_trade(
            shares=D("5"),
            price=D("0.40"),
            role=LiquidityRole.TAKER,
            schedule=schedule,
        )
        self.assertEqual(fee.platform_fee, D("0.06000"))
        self.assertEqual(fee.builder_fee, D("0.02000"))
        self.assertEqual(fee.total_fee, D("0.08000"))

    def test_maker_does_not_pay_taker_only_platform_fee(self) -> None:
        schedule = FeeSchedule(
            version_id="weather-v1",
            platform_rate=D("0.05"),
            platform_taker_only=True,
            maker_builder_bps=50,
            taker_builder_bps=100,
        )
        fee = fee_for_trade(
            shares=D("5"),
            price=D("0.40"),
            role=LiquidityRole.MAKER,
            schedule=schedule,
        )
        self.assertEqual(fee.platform_fee, D("0.00000"))
        self.assertEqual(fee.builder_fee, D("0.01000"))
        self.assertEqual(fee.total_fee, D("0.01000"))

    def test_fee_schedule_requires_a_version(self) -> None:
        with self.assertRaises(EvidenceError):
            FeeSchedule(version_id="", platform_rate=D("0.05"))


class PathClassificationTests(unittest.TestCase):
    def test_target_first_is_success(self) -> None:
        result = classify_exit_path(
            [point(1, "0.32"), point(2, "0.39"), point(3, "0.10")],
            target=D("0.38"),
            stop=D("0.155"),
        )
        self.assertEqual(result.outcome, PathOutcome.TARGET_FIRST)
        self.assertEqual(result.first_target_sequence, 2)

    def test_stop_first_is_failure(self) -> None:
        result = classify_exit_path(
            [point(1, "0.30"), point(2, "0.15"), point(3, "0.40")],
            target=D("0.38"),
            stop=D("0.155"),
        )
        self.assertEqual(result.outcome, PathOutcome.STOP_FIRST)
        self.assertEqual(result.first_stop_sequence, 2)

    def test_complete_path_with_no_hit_is_failure(self) -> None:
        result = classify_exit_path(
            [point(1, "0.30"), point(2, "0.32")],
            target=D("0.38"),
            stop=D("0.155"),
        )
        self.assertEqual(result.outcome, PathOutcome.NO_HIT)

    def test_coverage_gap_before_later_target_is_unknown(self) -> None:
        result = classify_exit_path(
            [
                point(1, "0.30"),
                point(2, None, coverage_ok=False),
                point(3, "0.40"),
            ],
            target=D("0.38"),
            stop=D("0.155"),
        )
        self.assertEqual(result.outcome, PathOutcome.UNKNOWN)
        self.assertEqual(result.reason, "coverage_gap_before_exit")

    def test_coverage_gap_after_target_does_not_erase_known_outcome(self) -> None:
        result = classify_exit_path(
            [
                point(1, "0.40"),
                point(2, None, coverage_ok=False),
            ],
            target=D("0.38"),
            stop=D("0.155"),
        )
        self.assertEqual(result.outcome, PathOutcome.TARGET_FIRST)

    def test_target_and_stop_at_same_sequence_is_unknown(self) -> None:
        result = classify_exit_path(
            [point(1, "0.40"), point(1, "0.10")],
            target=D("0.38"),
            stop=D("0.155"),
        )
        self.assertEqual(result.outcome, PathOutcome.UNKNOWN)
        self.assertEqual(result.reason, "same_sequence_ambiguous")

    def test_non_monotonic_sequence_is_unknown(self) -> None:
        result = classify_exit_path(
            [point(2, "0.30"), point(1, "0.40")],
            target=D("0.38"),
            stop=D("0.155"),
        )
        self.assertEqual(result.outcome, PathOutcome.UNKNOWN)
        self.assertEqual(result.reason, "non_monotonic_sequence")

    def test_missing_executable_sell_vwap_is_unknown(self) -> None:
        result = classify_exit_path(
            [point(1, None)],
            target=D("0.38"),
            stop=D("0.155"),
        )
        self.assertEqual(result.outcome, PathOutcome.UNKNOWN)
        self.assertEqual(result.reason, "missing_executable_depth")


if __name__ == "__main__":
    unittest.main()
