"""Append-only Stage-E stability evidence, owned exclusively by the supervisor.

This database deliberately contains only small health events and ten-second
quote aggregates.  It never stores order books, forecasts, orders or strategy
state, and failure to write it must never interrupt a production worker.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import uuid
from contextlib import closing
from datetime import UTC, datetime, timedelta, timezone
from pathlib import Path
import re

from d0_policy import strict_qxzx_settled_window


AUDIT_RETENTION_DAYS = 30
MAX_QUOTE_SAMPLES = 300_000
WINDOW_HOURS = 48
MIN_D0_SAMPLES_PER_CITY = 7
FORECAST_RETRY_DELAY_SECONDS = 3 * 60
UNIVERSE_MISMATCH_GRACE_SECONDS = 30
ACTUAL_STATUS_MAX_AGE_SECONDS = 3 * 60
CHINA_TZ = timezone(timedelta(hours=8), name="Asia/Shanghai")
LOCK_PATTERN = re.compile(r"\bdatabase\s+(?:is\s+)?(?:locked|busy)\b", re.IGNORECASE)
GUARDIAN_RESTART_PATTERN = re.compile(r"\brequires restart:\s*(.+)$", re.IGNORECASE)
GUARDIAN_LOG_TIME_PATTERN = re.compile(
    r"^(?P<stamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})"
)


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


class StabilityAudit:
    """Supervisor-only writer for stable, bounded Stage-E evidence."""

    def __init__(self, database: Path) -> None:
        self.database = database
        self.window_id: str | None = None
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        db = sqlite3.connect(self.database, timeout=2)
        db.execute("PRAGMA busy_timeout=2000")
        return db

    def _init_schema(self) -> None:
        self.database.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as db, db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""CREATE TABLE IF NOT EXISTS stability_windows (
              window_id TEXT PRIMARY KEY, started_at TEXT NOT NULL, ended_at TEXT,
              state TEXT NOT NULL, reason TEXT NOT NULL)""")
            db.execute("""CREATE TABLE IF NOT EXISTS stability_events (
              event_id INTEGER PRIMARY KEY AUTOINCREMENT, occurred_at TEXT NOT NULL,
              window_id TEXT, component TEXT NOT NULL, event_type TEXT NOT NULL,
              detail TEXT, planned INTEGER NOT NULL DEFAULT 0)""")
            db.execute("""CREATE TABLE IF NOT EXISTS quote_freshness_samples (
              sampled_at TEXT PRIMARY KEY, window_id TEXT NOT NULL,
              token_count INTEGER NOT NULL, fresh_token_count INTEGER NOT NULL,
              max_age_seconds REAL, read_error TEXT,
              executable_fresh_token_count INTEGER NOT NULL DEFAULT 0,
              stream_heartbeat_age_seconds REAL,
              expected_universe_hash TEXT,
              subscribed_token_count INTEGER,
              subscribed_universe_hash TEXT,
              universe_match INTEGER)""")
            sample_columns = {row[1] for row in db.execute("PRAGMA table_info(quote_freshness_samples)")}
            if "executable_fresh_token_count" not in sample_columns:
                db.execute("ALTER TABLE quote_freshness_samples ADD COLUMN executable_fresh_token_count INTEGER NOT NULL DEFAULT 0")
            if "stream_heartbeat_age_seconds" not in sample_columns:
                db.execute("ALTER TABLE quote_freshness_samples ADD COLUMN stream_heartbeat_age_seconds REAL")
            if "expected_universe_hash" not in sample_columns:
                db.execute("ALTER TABLE quote_freshness_samples ADD COLUMN expected_universe_hash TEXT")
            if "subscribed_token_count" not in sample_columns:
                db.execute("ALTER TABLE quote_freshness_samples ADD COLUMN subscribed_token_count INTEGER")
            if "subscribed_universe_hash" not in sample_columns:
                db.execute("ALTER TABLE quote_freshness_samples ADD COLUMN subscribed_universe_hash TEXT")
            if "universe_match" not in sample_columns:
                db.execute("ALTER TABLE quote_freshness_samples ADD COLUMN universe_match INTEGER")
            db.execute("""CREATE TABLE IF NOT EXISTS stage_e_gate_evidence (
              gate_key TEXT PRIMARY KEY, status TEXT NOT NULL,
              observed_at TEXT NOT NULL, detail TEXT,
              evidence_json TEXT NOT NULL DEFAULT '{}')""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_stability_events_window ON stability_events(window_id,occurred_at)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_quote_samples_window ON quote_freshness_samples(window_id,sampled_at)")

    def begin_window(self, reason: str = "stage_e_instrumentation_enabled") -> str:
        """Start a fresh window; an unclosed prior one is conservatively failed."""
        now = utc_now()
        try:
            with closing(self._connect()) as db, db:
                prior = db.execute("SELECT window_id FROM stability_windows WHERE state='ACTIVE' ORDER BY started_at DESC LIMIT 1").fetchone()
                if prior:
                    db.execute("UPDATE stability_windows SET state='FAILED',ended_at=?,reason=? WHERE window_id=?",
                               (now, "supervisor_restarted_before_window_complete", prior[0]))
                    db.execute("INSERT INTO stability_events(occurred_at,window_id,component,event_type,detail,planned) VALUES (?,?,?,?,?,0)",
                               (now, prior[0], "supervisor", "supervisor_restarted", "prior window closed conservatively"))
                self.window_id = uuid.uuid4().hex
                db.execute("INSERT INTO stability_windows VALUES (?,?,?,?,?)",
                           (self.window_id, now, None, "ACTIVE", reason))
                db.execute("INSERT INTO stability_events(occurred_at,window_id,component,event_type,detail,planned) VALUES (?,?,?,?,?,1)",
                           (now, self.window_id, "supervisor", "window_started", reason))
            return self.window_id
        except sqlite3.Error as exc:
            logging.warning("stability audit unavailable at window start: %s", exc)
            self.window_id = None
            return ""

    def event(self, component: str, event_type: str, detail: str = "", *, planned: bool = False) -> None:
        if not self.window_id:
            return
        try:
            with closing(self._connect()) as db, db:
                db.execute("INSERT INTO stability_events(occurred_at,window_id,component,event_type,detail,planned) VALUES (?,?,?,?,?,?)",
                           (utc_now(), self.window_id, component, event_type, detail[:1000], int(planned)))
        except sqlite3.Error as exc:
            logging.warning("stability audit event skipped: %s", exc)

    def sample_quotes(self, realtime_db: Path, strategy_tokens: set[str], *,
                      expected_universe_hash: str | None = None) -> None:
        """Sample only active strategy YES tokens from the bounded BBO projection.

        Missing tokens count as stale.  This avoids both false passes (a live
        unrelated market hides a missing strategy quote) and false failures
        (stale historic tokens are outside the strategy universe).
        """
        if not self.window_id:
            return
        now = datetime.now(UTC)
        stamp = now.isoformat()
        expected = {str(token) for token in strategy_tokens if str(token)}
        count = len(expected)
        strict_fresh = 0
        executable_fresh = 0
        max_age: float | None = None
        stream_age: float | None = None
        subscribed_count: int | None = None
        subscribed_hash: str | None = None
        universe_match: int | None = None
        error: str | None = None
        try:
            with closing(sqlite3.connect(f"file:{realtime_db}?mode=ro", uri=True, timeout=2)) as db:
                heartbeat = db.execute(
                    "SELECT updated_at FROM service_heartbeats WHERE service='realtime_stream'"
                ).fetchone()
                if not heartbeat:
                    error = "stream_heartbeat_missing"
                else:
                    heartbeat_at = datetime.fromisoformat(str(heartbeat[0]).replace("Z", "+00:00"))
                    if heartbeat_at.tzinfo is None:
                        heartbeat_at = heartbeat_at.replace(tzinfo=UTC)
                    stream_age = max(0.0, (now - heartbeat_at.astimezone(UTC)).total_seconds())
                has_connection_events = db.execute(
                    """SELECT 1 FROM sqlite_master
                       WHERE type='table' AND name='stream_connection_events'"""
                ).fetchone()
                if has_connection_events:
                    subscribed = db.execute(
                        """SELECT token_count,universe_hash
                           FROM stream_connection_events
                           WHERE event_type IN ('connected','universe_changed')
                           ORDER BY event_at DESC LIMIT 1"""
                    ).fetchone()
                    if subscribed:
                        subscribed_count = (
                            int(subscribed[0]) if subscribed[0] is not None else None
                        )
                        subscribed_hash = (
                            str(subscribed[1]) if subscribed[1] is not None else None
                        )
                if expected_universe_hash and subscribed_hash:
                    universe_match = int(expected_universe_hash == subscribed_hash)
                elif subscribed_count is not None:
                    universe_match = int(subscribed_count == count)
                if expected:
                    placeholders = ",".join("?" for _ in expected)
                    rows = db.execute(
                        f"SELECT token_id,captured_at FROM latest_bbo WHERE token_id IN ({placeholders})",
                        tuple(sorted(expected)),
                    )
                    for _token_id, captured_at in rows:
                        parsed = datetime.fromisoformat(str(captured_at).replace("Z", "+00:00"))
                        if parsed.tzinfo is None:
                            parsed = parsed.replace(tzinfo=UTC)
                        age = max(0.0, (now - parsed.astimezone(UTC)).total_seconds())
                        strict_fresh += int(age < 10)
                        executable_fresh += int(age < 20)
                        max_age = age if max_age is None else max(max_age, age)
        except (sqlite3.Error, ValueError, OSError) as exc:
            error = type(exc).__name__
        try:
            with closing(self._connect()) as db, db:
                db.execute("""INSERT OR REPLACE INTO quote_freshness_samples
                  (sampled_at,window_id,token_count,fresh_token_count,max_age_seconds,read_error,
                   executable_fresh_token_count,stream_heartbeat_age_seconds,
                   expected_universe_hash,subscribed_token_count,
                   subscribed_universe_hash,universe_match)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                           (stamp, self.window_id, count, strict_fresh, max_age, error,
                            executable_fresh, stream_age, expected_universe_hash,
                            subscribed_count, subscribed_hash, universe_match))
                cutoff = (now - timedelta(days=AUDIT_RETENTION_DAYS)).isoformat()
                db.execute("DELETE FROM quote_freshness_samples WHERE sampled_at < ?", (cutoff,))
                db.execute("DELETE FROM stability_events WHERE occurred_at < ?", (cutoff,))
                db.execute("DELETE FROM quote_freshness_samples WHERE rowid IN (SELECT rowid FROM quote_freshness_samples ORDER BY sampled_at ASC LIMIT MAX(0,(SELECT COUNT(*) FROM quote_freshness_samples)-?))", (MAX_QUOTE_SAMPLES,))
        except sqlite3.Error as exc:
            logging.warning("stability quote sample skipped: %s", exc)

    def record_gate_evidence(self, gate_key: str, status: str, detail: str = "",
                             evidence: dict | None = None) -> None:
        """Record an explicit offline gate result without touching a business database."""
        try:
            with closing(self._connect()) as db, db:
                db.execute("""INSERT OR REPLACE INTO stage_e_gate_evidence
                  (gate_key,status,observed_at,detail,evidence_json)
                  VALUES (?,?,?,?,?)""",
                           (str(gate_key), str(status), utc_now(), detail[:1000],
                            json.dumps(evidence or {}, ensure_ascii=False,
                                       sort_keys=True, default=str)))
        except sqlite3.Error as exc:
            logging.warning("stage-E gate evidence skipped: %s", exc)


class RuntimeLogTail:
    """Read only log additions made after the audit window starts.

    The tail starts at EOF deliberately: historic errors are retained in the
    worker logs for diagnosis, but they cannot invalidate a newly started
    Stage-E observation window.  Rotation/truncation is handled safely.
    """

    def __init__(self) -> None:
        self._offsets: dict[Path, int] = {}

    def prime(self, paths: list[Path]) -> None:
        for path in paths:
            try:
                self._offsets[path] = path.stat().st_size
            except OSError:
                self._offsets[path] = 0

    def lock_messages(self, paths: list[Path]) -> list[tuple[Path, str]]:
        matches: list[tuple[Path, str]] = []
        for path in paths:
            prior = self._offsets.get(path, 0)
            try:
                size = path.stat().st_size
                if size < prior:
                    prior = 0
                with path.open("r", encoding="utf-8", errors="replace") as handle:
                    handle.seek(prior)
                    text = handle.read()
                self._offsets[path] = size
            except OSError:
                continue
            for line in text.splitlines():
                if LOCK_PATTERN.search(line):
                    matches.append((path, line[:1000]))
        return matches

    def restart_messages(self, paths: list[Path]) -> list[tuple[Path, str]]:
        matches: list[tuple[Path, str]] = []
        for path in paths:
            prior = self._offsets.get(path, 0)
            try:
                size = path.stat().st_size
                if size < prior:
                    prior = 0
                with path.open("r", encoding="utf-8", errors="replace") as handle:
                    handle.seek(prior)
                    text = handle.read()
                self._offsets[path] = size
            except OSError:
                continue
            for line in text.splitlines():
                if GUARDIAN_RESTART_PATTERN.search(line):
                    matches.append((path, line[:1000]))
        return matches


def parse_timestamp(value: object, *, default_tz=UTC) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=default_tz)
    return parsed.astimezone(UTC)


def guardian_restart_evidence(log_dir: Path | None, *,
                              started_at: datetime,
                              ended_at: datetime) -> dict:
    """Read guardian restart lines for the requested window without changing logs."""
    if log_dir is None:
        return {"available": False, "events": []}
    directory = Path(log_dir)
    paths = sorted(directory.glob("*_guardian.log")) if directory.exists() else []
    events: list[dict] = []
    for path in paths:
        component = path.stem.removesuffix("_guardian")
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            reason_match = GUARDIAN_RESTART_PATTERN.search(line)
            stamp_match = GUARDIAN_LOG_TIME_PATTERN.match(line)
            if not reason_match or not stamp_match:
                continue
            try:
                occurred = datetime.strptime(
                    stamp_match.group("stamp"), "%Y-%m-%d %H:%M:%S,%f"
                ).replace(tzinfo=CHINA_TZ).astimezone(UTC)
            except ValueError:
                continue
            if started_at <= occurred <= ended_at:
                events.append({
                    "occurred_at": occurred.isoformat(),
                    "component": component,
                    "event_type": "worker_restart",
                    "detail": line[:1000],
                    "reason": reason_match.group(1).strip(),
                })
    return {"available": bool(paths), "events": events}


def breaker_restart_evidence(status_dir: Path | None, *,
                             started_at: datetime,
                             ended_at: datetime) -> dict:
    """Use breaker timestamps as a short-retention cross-check for guardian logs."""
    if status_dir is None:
        return {"available": False, "events": []}
    directory = Path(status_dir)
    paths = sorted(directory.glob("*.breaker.json")) if directory.exists() else []
    events: list[dict] = []
    for path in paths:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
        component = str(payload.get("service") or path.name.removesuffix(".breaker.json"))
        reason = str(payload.get("last_reason") or "restart")
        for raw_stamp in payload.get("restart_timestamps", []):
            try:
                occurred = datetime.fromtimestamp(float(raw_stamp), tz=UTC)
            except (TypeError, ValueError, OSError):
                continue
            if started_at <= occurred <= ended_at:
                events.append({
                    "occurred_at": occurred.isoformat(),
                    "component": component,
                    "event_type": "worker_restart",
                    "detail": reason,
                })
    return {"available": bool(paths), "events": events}


def _forecast_family_key(row: tuple) -> tuple[str, str, str]:
    """Map one precision/retry attempt to its release-window family."""
    scheduled = parse_timestamp(row[0], default_tz=CHINA_TZ)
    kind = str(row[1])
    city = str(row[2])
    source = str(row[3])
    if scheduled is None:
        return city, source, f"{kind}:{row[0]}"
    anchor = scheduled.astimezone(UTC)
    if kind == "retry":
        anchor -= timedelta(seconds=FORECAST_RETRY_DELAY_SECONDS)
    elif kind != "precision":
        return city, source, f"{kind}:{anchor.isoformat()}"
    return city, source, anchor.isoformat()


def forecast_delivery_gate(database: Path | None, *,
                           started_at: datetime,
                           ended_at: datetime) -> dict:
    if database is None or not Path(database).exists():
        return {"status": "missing", "reason": "research_database_unavailable"}
    try:
        with closing(sqlite3.connect(
                f"file:{Path(database)}?mode=ro", uri=True, timeout=2)) as db:
            rows = db.execute("""SELECT scheduled_at,schedule_kind,city,source,status,
              requested_at,received_at,source_reported_at,detail,completed_at
              FROM forecast_delivery_windows""").fetchall()
    except sqlite3.Error as exc:
        return {"status": "missing", "reason": f"read_error:{type(exc).__name__}"}
    selected = []
    for row in rows:
        completed = parse_timestamp(row[9], default_tz=CHINA_TZ)
        if completed is not None and started_at <= completed <= ended_at:
            selected.append(row)
    if not selected:
        return {"status": "blocked", "reason": "no_delivery_window_evidence",
                "windows": 0, "families": 0, "success": 0, "failed": 0,
                "recovered_failures": 0, "unresolved_families": 0}

    families: dict[tuple[str, str, str], list[tuple]] = {}
    for row in rows:
        families.setdefault(_forecast_family_key(row), []).append(row)
    selected_keys = {_forecast_family_key(row) for row in selected}
    selected_families = {
        key: families[key] for key in selected_keys
    }
    failures = [row for row in selected if str(row[4]) != "ok"]
    success = sum(str(row[4]) == "ok" for row in selected)
    unresolved = {
        key: attempts for key, attempts in selected_families.items()
        if not any(str(attempt[4]) == "ok" for attempt in attempts)
    }
    recovered_failures = sum(
        1 for row in failures
        if _forecast_family_key(row) not in unresolved
    )
    if unresolved:
        statuses = {
            str(attempt[4])
            for attempts in unresolved.values()
            for attempt in attempts
            if str(attempt[4]) != "ok"
        }
        return {
            "status": "blocked",
            "reason": "unreconciled_delivery_families",
            "windows": len(selected),
            "families": len(selected_families),
            "success": success,
            "failed": len(failures),
            "recovered_failures": recovered_failures,
            "unresolved_families": len(unresolved),
            "failure_statuses": sorted(statuses),
        }
    return {
        "status": "pass",
        "reason": "all_delivery_families_satisfied",
        "windows": len(selected),
        "families": len(selected_families),
        "success": success,
        "failed": len(failures),
        "recovered_failures": recovered_failures,
        "unresolved_families": 0,
    }


def actual_source_gate(database: Path | None, *,
                       now: datetime | None = None) -> dict:
    if database is None or not Path(database).exists():
        return {"status": "missing", "reason": "observations_database_unavailable",
                "eligible_cities": []}
    observed_at = now or datetime.now(UTC)
    try:
        with closing(sqlite3.connect(
                f"file:{Path(database)}?mode=ro", uri=True, timeout=2)) as db:
            rows = db.execute("""SELECT city,station,decision_scope,last_success_at,
              last_report_at,state,updated_at,detail
              FROM metar_live_status ORDER BY city""").fetchall()
    except sqlite3.Error as exc:
        return {"status": "missing", "reason": f"read_error:{type(exc).__name__}",
                "eligible_cities": []}
    configured = [
        str(city) for city, _station, scope, *_rest in rows
        if str(scope) == "risk_exclusion"
    ]
    if not configured:
        return {"status": "blocked", "reason": "no_risk_exclusion_source_configured",
                "eligible_cities": []}

    eligible: list[str] = []
    unhealthy: dict[str, list[str]] = {}
    status_ages: dict[str, float | None] = {}
    for city, _station, scope, success, report, state, updated, _detail in rows:
        if str(scope) != "risk_exclusion":
            continue
        city_name = str(city)
        reasons: list[str] = []
        if not success or not report:
            reasons.append("retained_report_missing")
        if str(state) != "healthy":
            reasons.append(f"state_{state or 'missing'}")
        updated_at = parse_timestamp(updated)
        success_at = parse_timestamp(success)
        age = (
            (observed_at - updated_at).total_seconds()
            if updated_at is not None else None
        )
        status_ages[city_name] = round(age, 1) if age is not None else None
        if updated_at is None or success_at is None:
            reasons.append("status_timestamp_missing")
        elif age < -5:
            reasons.append("status_clock_future")
        elif age > ACTUAL_STATUS_MAX_AGE_SECONDS:
            reasons.append("status_stale")
        if reasons:
            unhealthy[city_name] = reasons
        else:
            eligible.append(city_name)
    if unhealthy:
        return {
            "status": "blocked",
            "reason": "metar_risk_exclusion_source_not_current",
            "eligible_cities": sorted(eligible),
            "unhealthy_cities": sorted(unhealthy),
            "city_reasons": unhealthy,
            "status_age_seconds": status_ages,
            "max_status_age_seconds": ACTUAL_STATUS_MAX_AGE_SECONDS,
        }
    return {
        "status": "pass",
        "reason": "metar_risk_exclusion_source_current",
        "eligible_cities": sorted(eligible),
        "status_age_seconds": status_ages,
        "max_status_age_seconds": ACTUAL_STATUS_MAX_AGE_SECONDS,
    }


def _mismatch_direction(row: tuple) -> str:
    expected_count, subscribed_count = row[1], row[2]
    expected_hash, subscribed_hash = row[3], row[4]
    if expected_count is not None and subscribed_count is not None:
        if int(expected_count) > int(subscribed_count):
            return "expected_ahead"
        if int(expected_count) < int(subscribed_count):
            return "subscribed_ahead"
        if expected_hash and subscribed_hash and str(expected_hash) != str(subscribed_hash):
            return "set_mismatch"
    return "unknown"


def universe_mismatch_gate(rows: list[tuple]) -> dict:
    """Classify bounded universe convergence without hiding unresolved drift."""
    ordered = sorted(
        rows,
        key=lambda row: parse_timestamp(row[0]) or datetime.min.replace(tzinfo=UTC),
    )
    mismatch_samples = sum(row[5] == 0 for row in ordered)
    transient = 0
    blocking = 0
    directions: dict[str, int] = {}
    max_resolution: float | None = None
    index = 0
    while index < len(ordered):
        if ordered[index][5] != 0:
            index += 1
            continue
        first = ordered[index]
        first_at = parse_timestamp(first[0])
        streak_directions: set[str] = set()
        has_read_error = False
        while index < len(ordered) and ordered[index][5] == 0:
            streak_directions.add(_mismatch_direction(ordered[index]))
            has_read_error = has_read_error or bool(ordered[index][6])
            index += 1
        direction = (
            next(iter(streak_directions))
            if len(streak_directions) == 1 else "mixed"
        )
        directions[direction] = directions.get(direction, 0) + 1
        resolved = index < len(ordered) and ordered[index][5] == 1
        resolved_at = parse_timestamp(ordered[index][0]) if resolved else None
        resolution_seconds = (
            max(0.0, (resolved_at - first_at).total_seconds())
            if resolved_at is not None and first_at is not None else None
        )
        if resolution_seconds is not None:
            max_resolution = (
                resolution_seconds if max_resolution is None
                else max(max_resolution, resolution_seconds)
            )
        if (
            not has_read_error
            and resolved
            and resolution_seconds is not None
            and resolution_seconds <= UNIVERSE_MISMATCH_GRACE_SECONDS
        ):
            transient += 1
        else:
            blocking += 1
    return {
        "status": "pass" if blocking == 0 else "blocked",
        "reason": (
            "no_persistent_universe_mismatch"
            if blocking == 0 else "persistent_or_unresolved_universe_mismatch"
        ),
        "mismatch_samples": mismatch_samples,
        "transient_streaks": transient,
        "blocking_streaks": blocking,
        "directions": directions,
        "max_resolution_seconds": (
            round(max_resolution, 3) if max_resolution is not None else None
        ),
        "grace_seconds": UNIVERSE_MISMATCH_GRACE_SECONDS,
    }


def d0_sample_gate(database: Path | None, eligible_cities: list[str]) -> dict:
    if database is None or not Path(database).exists():
        return {"status": "missing", "reason": "research_database_unavailable",
                "required_per_city": MIN_D0_SAMPLES_PER_CITY, "counts": {}}
    if not eligible_cities:
        return {"status": "blocked", "reason": "no_eligible_cities",
                "required_per_city": MIN_D0_SAMPLES_PER_CITY, "counts": {}}
    counts: dict[str, int] = {}
    range_counts: dict[str, int] = {}
    try:
        with closing(sqlite3.connect(
                f"file:{Path(database)}?mode=ro", uri=True, timeout=2)) as db:
            for city in sorted(set(eligible_cities)):
                window = strict_qxzx_settled_window(
                    db, city, limit=MIN_D0_SAMPLES_PER_CITY
                )
                counts[city] = len(window)
                range_counts[city] = sum(
                    item["settlement_kind"] != "exact" for item in window
                )
    except sqlite3.Error as exc:
        return {"status": "missing", "reason": f"read_error:{type(exc).__name__}",
                "required_per_city": MIN_D0_SAMPLES_PER_CITY, "counts": counts,
                "range_counts": range_counts}
    insufficient = {
        city: value for city, value in counts.items()
        if value < MIN_D0_SAMPLES_PER_CITY
    }
    if insufficient:
        return {"status": "blocked", "reason": "insufficient_strict_d0_samples",
                "required_per_city": MIN_D0_SAMPLES_PER_CITY,
                "counts": counts, "range_counts": range_counts,
                "insufficient": insufficient}
    return {"status": "pass", "reason": "strict_d0_sample_gate_satisfied",
            "required_per_city": MIN_D0_SAMPLES_PER_CITY, "counts": counts,
            "range_counts": range_counts}


def paper_recovery_gate(recorded_evidence: dict[str, dict]) -> dict:
    evidence = recorded_evidence.get("paper_recovery")
    if not evidence:
        return {"status": "blocked",
                "reason": "tracking_high_recovery_evidence_missing"}
    if str(evidence.get("status")) != "pass":
        return {"status": "blocked",
                "reason": str(evidence.get("detail") or "paper_recovery_not_passed"),
                "observed_at": evidence.get("observed_at"),
                "evidence": evidence.get("evidence", {})}
    return {"status": "pass", "reason": "isolated_paper_recovery_verified",
            "observed_at": evidence.get("observed_at"),
            "evidence": evidence.get("evidence", {})}


def report(database: Path, *, research_db: Path | None = None,
           observations_db: Path | None = None,
           paper_db: Path | None = None,
           runtime_log_dir: Path | None = None,
           runtime_status_dir: Path | None = None) -> dict:
    """Read-only Stage-E report.  Missing evidence never produces a pass."""
    if not database.exists():
        return {"state": "NOT_STARTED", "reason": "stability audit database missing"}
    with closing(sqlite3.connect(f"file:{database}?mode=ro", uri=True)) as db:
        db.row_factory = sqlite3.Row
        window = db.execute("SELECT * FROM stability_windows ORDER BY started_at DESC LIMIT 1").fetchone()
        if not window:
            return {"state": "NOT_STARTED", "reason": "no audit window"}
        start = parse_timestamp(window["started_at"])
        if start is None:
            return {"state": "BLOCKED", "reason": "invalid_window_start",
                    "window_id": window["window_id"]}
        now = datetime.now(UTC)
        ended = parse_timestamp(window["ended_at"]) if window["ended_at"] else now
        ended = ended or now
        elapsed = (ended - start).total_seconds()
        events = db.execute("""SELECT occurred_at,component,event_type,detail
          FROM stability_events WHERE window_id=? AND planned=0""",
                            (window["window_id"],)).fetchall()
        sample_columns = {
            row[1] for row in db.execute("PRAGMA table_info(quote_freshness_samples)")
        }
        mismatch_sql = (
            "SUM(CASE WHEN universe_match=0 AND token_count>0 THEN 1 ELSE 0 END)"
            if "universe_match" in sample_columns else "0"
        )
        sample = db.execute(f"""SELECT COUNT(*),COALESCE(SUM(fresh_token_count),0),
          COALESCE(SUM(executable_fresh_token_count),0),COALESCE(SUM(token_count),0),
          SUM(CASE WHEN read_error IS NOT NULL THEN 1 ELSE 0 END),
          SUM(CASE WHEN stream_heartbeat_age_seconds IS NOT NULL
                    AND stream_heartbeat_age_seconds < 10
                    AND read_error IS NULL THEN 1 ELSE 0 END),
          {mismatch_sql}
          FROM quote_freshness_samples WHERE window_id=?""",
                            (window["window_id"],)).fetchone()
        universe_rows = (
            db.execute("""SELECT sampled_at,token_count,subscribed_token_count,
              expected_universe_hash,subscribed_universe_hash,universe_match,
              read_error FROM quote_freshness_samples
              WHERE window_id=? ORDER BY sampled_at""",
                       (window["window_id"],)).fetchall()
            if "universe_match" in sample_columns else []
        )
        evidence_table = db.execute("""SELECT 1 FROM sqlite_master
          WHERE type='table' AND name='stage_e_gate_evidence'""").fetchone()
        recorded_evidence: dict[str, dict] = {}
        if evidence_table:
            for row in db.execute("""SELECT gate_key,status,observed_at,detail,evidence_json
              FROM stage_e_gate_evidence"""):
                try:
                    payload = json.loads(row[4] or "{}")
                except (TypeError, ValueError, json.JSONDecodeError):
                    payload = {}
                recorded_evidence[str(row[0])] = {
                    "status": str(row[1]), "observed_at": row[2],
                    "detail": row[3], "evidence": payload,
                }
    total = int(sample[3] or 0)
    strict_freshness = (float(sample[1]) / total) if total else 1.0
    executable_freshness = (float(sample[2]) / total) if total else 1.0
    continuity = (float(sample[5]) / int(sample[0])) if sample[0] else 0.0
    guardian = guardian_restart_evidence(
        runtime_log_dir, started_at=start, ended_at=ended
    )
    breaker = breaker_restart_evidence(
        runtime_status_dir, started_at=start, ended_at=ended
    )
    db_event_signatures = {
        (str(row["component"]), str(row["detail"] or "")) for row in events
    }
    guardian_events = [
        event for event in guardian["events"]
        if (str(event["component"]), str(event["detail"])) not in db_event_signatures
    ]
    unexpected_event_count = len(events) + len(guardian_events)
    runtime_restart_detected = bool(guardian["events"] or breaker["events"])

    universe_gate = universe_mismatch_gate(list(universe_rows))
    actual_gate = actual_source_gate(observations_db, now=ended)
    gates = {
        "forecast_delivery": forecast_delivery_gate(
            research_db, started_at=start, ended_at=ended
        ),
        "paper_recovery": paper_recovery_gate(recorded_evidence),
        "actual_source": actual_gate,
        "d0_sample": d0_sample_gate(
            research_db, list(actual_gate.get("eligible_cities") or [])
        ),
    }

    blockers: list[str] = []
    window_state = str(window["state"])
    if window_state not in {"ACTIVE", "COMPLETED"}:
        blockers.append("window_state_not_eligible")
    if elapsed < WINDOW_HOURS * 3600:
        blockers.append("48h_window_incomplete")
    if unexpected_event_count or runtime_restart_detected:
        blockers.append("unexpected_runtime_event")
    if int(sample[4] or 0):
        blockers.append("quote_sample_read_error")
    if continuity < 0.99:
        blockers.append("quote_stream_continuity_below_99pct")
    if total and executable_freshness < 0.99:
        blockers.append("quote_executable_freshness_below_99pct")
    if universe_gate["status"] != "pass":
        blockers.append("quote_universe_mismatch")
    for gate_name, gate in gates.items():
        if gate.get("status") != "pass":
            blockers.append(f"{gate_name}_gate_not_passed")
    state = "PASS" if not blockers else (
        "FAILED" if window_state == "FAILED" else "BLOCKED"
    )
    return {"state": state, "window_id": window["window_id"],
            "elapsed_seconds": round(elapsed, 1), "quote_samples": int(sample[0] or 0),
            "quote_fresh_fraction_diagnostic_lt10": round(strict_freshness, 6),
            "quote_executable_fresh_fraction_lt20": round(executable_freshness, 6),
            "quote_stream_continuity_fraction_lt10": round(continuity, 6),
            "quote_universe_mismatch_samples": int(sample[6] or 0),
            "quote_universe": universe_gate,
            "unexpected_events": unexpected_event_count,
            "guardian_restart_events": len(guardian["events"]),
            "breaker_restart_events": len(breaker["events"]),
            "restart_evidence": {
                "guardian_logs_available": bool(guardian["available"]),
                "breaker_files_available": bool(breaker["available"]),
            },
            "gates": gates,
            "blockers": blockers, "window_state": window_state}


if __name__ == "__main__":
    from db_paths import DATA, OBSERVATIONS_DB, PAPER_DB, RESEARCH_DB
    print(json.dumps(report(
        DATA / "stability_audit.sqlite3",
        research_db=RESEARCH_DB,
        observations_db=OBSERVATIONS_DB,
        paper_db=PAPER_DB,
        runtime_log_dir=DATA / "runtime" / "logs",
        runtime_status_dir=DATA / "runtime" / "services",
    ), ensure_ascii=False, indent=2))
