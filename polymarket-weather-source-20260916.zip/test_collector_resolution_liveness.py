from __future__ import annotations

import asyncio
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import collector


class _Response:
    def __init__(self, payload, status_code: int = 200) -> None:
        self._payload = payload
        self.status_code = status_code

    def json(self):
        return self._payload


class _BatchClient:
    def __init__(self, payloads=None, *, delay_for=None, transform=None) -> None:
        self.payloads = payloads or {}
        self.delay_for = delay_for or (lambda _ids, _closed: 0.0)
        self.transform = transform or (lambda values, _ids, _closed: values)
        self.calls: list[tuple[tuple[str, ...], str | None, int]] = []

    async def get(self, url: str, *_args, **kwargs) -> _Response:
        if not url.endswith("/markets"):
            raise AssertionError(f"per-market request is forbidden: {url}")
        params = list(kwargs.get("params") or [])
        requested = tuple(str(value) for key, value in params if key == "id")
        closed = next((str(value) for key, value in params if key == "closed"), None)
        limit = int(next(value for key, value in params if key == "limit"))
        self.calls.append((requested, closed, limit))
        await asyncio.sleep(float(self.delay_for(requested, closed)))
        values = []
        for market_id in requested:
            payload = self.payloads.get(market_id)
            if payload is None:
                continue
            if closed == "true" and payload.get("closed") is not True:
                continue
            if closed == "false" and payload.get("closed") is not False:
                continue
            values.append(payload)
        return _Response(self.transform(values, requested, closed))


class ResolutionLivenessTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        path = Path(self.tmp.name) / "research.sqlite3"
        with patch.object(collector, "DB_PATH", path), patch.object(
            collector, "prune_research_data"
        ):
            self.db = collector.connect()

    def tearDown(self) -> None:
        self.db.close()
        self.tmp.cleanup()

    @staticmethod
    def market(
        market_id: str,
        *,
        day: int = 16,
        yes_price: str = "1",
        no_price: str | None = None,
        resolution_source: str | None = None,
        active: bool = True,
        closed: bool = True,
        city: str = "Beijing",
        station: str = "ZBAA",
        bucket: str = "30 C",
    ) -> dict:
        return {
            "id": market_id,
            "question": f"Will the highest temperature in {city} be {bucket} on August {day}?",
            "description": "unit",
            "resolutionSource": (
                f"https://www.wunderground.com/history/daily/cn/{city.lower()}/{station}"
                if resolution_source is None else resolution_source
            ),
            "endDate": f"2026-08-{day:02d}T12:00:00Z",
            "outcomes": '["Yes", "No"]',
            "outcomePrices": json.dumps([
                yes_price, no_price if no_price is not None else ("0" if yes_price == "1" else "1")
            ]),
            "clobTokenIds": '["1001", "1002"]',
            "liquidityNum": 1,
            "volumeNum": 1,
            "active": active,
            "closed": closed,
            "acceptingOrders": not closed,
            "umaResolutionStatus": "resolved" if closed else "unresolved",
            "groupItemTitle": bucket,
        }

    def add_market(self, market: dict, captured_at: str = "2026-08-16T15:00:00+00:00") -> None:
        collector.save_market(self.db, captured_at, market, market["question"].split(" in ", 1)[1].split(" be ", 1)[0])

    def add_legacy_resolution(self, market: dict) -> None:
        self.db.execute(
            """INSERT INTO market_resolutions
            (market_id,city,target_date,bucket_label,yes_resolved,resolved_at,
             outcome_prices_json,resolution_source) VALUES (?,?,?,?,?,?,?,?)""",
            (
                str(market["id"]),
                "Beijing",
                "2026-08-15",
                "30 C",
                1,
                "2026-08-16T00:00:00+00:00",
                market["outcomePrices"],
                market["resolutionSource"],
            ),
        )

    def test_1628_snapshot_backlog_prioritizes_current_final_and_batches_requests(self) -> None:
        payloads = {}
        for index in range(820):
            market = self.market(str(1_000_000 + index), day=14)
            self.add_market(market)
            self.add_legacy_resolution(market)
        for index in range(807):
            self.add_market(self.market(str(2_000_000 + index), day=15))
        current = self.market("9000000", day=16, active=True, closed=True)
        self.add_market(current)
        payloads[current["id"]] = current
        self.db.commit()
        client = _BatchClient(payloads)

        resolved = asyncio.run(
            collector.collect_resolutions(client, self.db, "2026-08-17T01:00:00+00:00")
        )

        self.assertEqual(resolved, 1)
        self.assertIn("9000000", client.calls[0][0])
        final_calls = [call for call in client.calls if call[1] == "true"]
        self.assertEqual(len(final_calls), 17)
        self.assertTrue(all(call[2] == len(call[0]) <= 50 for call in final_calls))
        self.assertFalse(any(market_id.startswith("100") for call in client.calls for market_id in call[0]))

    def test_completed_batch_survives_later_timeout_and_returns_real_count(self) -> None:
        payloads = {}
        for index in range(60):
            market_id = str(3_000_000 + index)
            market = self.market(market_id)
            self.add_market(market)
            payloads[market_id] = market
        self.db.commit()
        client = _BatchClient(
            payloads,
            delay_for=lambda ids, closed: 0.2 if closed == "true" and ids[0] >= "3000050" else 0,
        )
        with patch.object(collector, "RESOLUTION_SCAN_BUDGET_SECONDS", 0.05):
            with self.assertLogs(level="WARNING") as logs:
                resolved = asyncio.run(
                    collector.collect_resolutions(client, self.db, "2026-08-17T01:00:00+00:00")
                )
        self.assertEqual(resolved, 50)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0], 50)
        self.assertTrue(any("pending=" in line and "final=50" in line for line in logs.output))

    def test_unordered_and_missing_batch_maps_by_market_id_without_inference(self) -> None:
        winner = self.market("4000001", yes_price="1")
        loser = self.market("4000002", yes_price="0")
        missing = self.market("4000003", yes_price="0")
        for market in (winner, loser, missing):
            self.add_market(market)
        self.db.commit()
        client = _BatchClient(
            {winner["id"]: winner, loser["id"]: loser},
            transform=lambda values, _ids, _closed: list(reversed(values)),
        )

        resolved = asyncio.run(
            collector.collect_resolutions(client, self.db, "2026-08-17T01:00:00+00:00")
        )

        rows = self.db.execute(
            "SELECT market_id,yes_resolved FROM market_resolutions ORDER BY market_id"
        ).fetchall()
        self.assertEqual(resolved, 2)
        self.assertEqual(rows, [("4000001", 1), ("4000002", 0)])
        self.assertIsNone(
            self.db.execute("SELECT 1 FROM market_resolutions WHERE market_id='4000003'").fetchone()
        )

    def test_unknown_or_duplicate_id_rejects_compromised_batch(self) -> None:
        for mode in ("unknown", "duplicate"):
            with self.subTest(mode=mode):
                market = self.market("4100001")
                self.add_market(market, f"2026-08-16T15:00:0{len(mode)}+00:00")
                self.db.commit()

                def transform(values, _ids, closed):
                    if closed != "true":
                        return values
                    if mode == "unknown":
                        return values + [{**market, "id": "not-requested"}]
                    return values + values

                resolved = asyncio.run(
                    collector.collect_resolutions(
                        _BatchClient({market["id"]: market}, transform=transform),
                        self.db,
                        "2026-08-17T01:00:00+00:00",
                    )
                )
                self.assertEqual(resolved, 0)
                self.assertIsNone(
                    self.db.execute(
                        "SELECT 1 FROM market_resolutions WHERE market_id='4100001'"
                    ).fetchone()
                )

    def test_final_requires_resolved_closed_not_accepting_orders_and_strict_identity(self) -> None:
        mutations = [
            {"active": "true"},
            {"closed": False},
            {"acceptingOrders": True},
            {"umaResolutionStatus": "proposed"},
            {"groupItemTitle": "31 C"},
            {"question": "Will the highest temperature in Shanghai be 30 C on August 16?"},
        ]
        payloads = {}
        for index, mutation in enumerate(mutations):
            market_id = str(4_200_000 + index)
            market = {**self.market(market_id), **mutation}
            stored = self.market(market_id)
            self.add_market(stored)
            payloads[market_id] = market
        good = self.market("4299999", active=True, closed=True)
        self.add_market(good)
        payloads[good["id"]] = good
        self.db.commit()

        resolved = asyncio.run(
            collector.collect_resolutions(
                _BatchClient(payloads), self.db, "2026-08-17T01:00:00+00:00"
            )
        )

        self.assertEqual(resolved, 1)
        self.assertEqual(
            self.db.execute("SELECT market_id FROM market_resolutions").fetchall(),
            [("4299999",)],
        )
        self.assertEqual(
            self.db.execute(
                "SELECT market_active,market_closed FROM market_resolution_evidence"
            ).fetchone(),
            (1, 1),
        )

    def test_resolution_source_does_not_gate_formal_final(self) -> None:
        sources = (
            "https://www.weather.gov/wrh/timeseries?site=zbaa",
            "https://www.wunderground.com/weather/cn/beijing/ZBAA",
            "https://example.invalid/settlement",
            "",
        )
        payloads = {}
        for index, source in enumerate(sources):
            market = self.market(
                f"425000{index}", resolution_source=source,
            )
            self.add_market(market)
            payloads[market["id"]] = market
        self.db.commit()

        resolved = asyncio.run(
            collector.collect_resolutions(
                _BatchClient(payloads), self.db, "2026-08-17T01:00:00+00:00"
            )
        )

        self.assertEqual(resolved, len(sources))
        rows = self.db.execute(
            "SELECT market_id,yes_resolved FROM market_resolutions ORDER BY market_id"
        ).fetchall()
        self.assertEqual(rows, [(f"425000{index}", 1) for index in range(len(sources))])

    def test_nonterminal_price_does_not_write_final(self) -> None:
        market = self.market("4260001", yes_price="0.99", no_price="0.01")
        self.add_market(market)
        self.db.commit()

        resolved = asyncio.run(
            collector.collect_resolutions(
                _BatchClient({market["id"]: market}),
                self.db,
                "2026-08-17T01:00:00+00:00",
            )
        )

        self.assertEqual(resolved, 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0], 0)

    def test_final_requires_binary_payout(self) -> None:
        market = self.market("4270001", yes_price="0.5", no_price="0.5")
        self.add_market(market)
        self.db.commit()

        resolved = asyncio.run(
            collector.collect_resolutions(
                _BatchClient({market["id"]: market}),
                self.db,
                "2026-08-17T01:00:00+00:00",
            )
        )

        self.assertEqual(resolved, 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0], 0)

    def test_open_terminal_price_is_provisional_only(self) -> None:
        market = self.market("4300001", active=True, closed=False, yes_price="1")
        self.add_market(market)
        self.db.commit()

        resolved = asyncio.run(
            collector.collect_resolutions(
                _BatchClient({market["id"]: market}),
                self.db,
                "2026-08-17T01:00:00+00:00",
            )
        )

        self.assertEqual(resolved, 0)
        self.assertEqual(
            self.db.execute(
                "SELECT state,market_active,market_closed FROM market_resolution_evidence"
            ).fetchone(),
            ("provisional", 1, 0),
        )
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0], 0)

    def test_final_write_is_idempotent_and_second_cycle_does_not_requery(self) -> None:
        market = self.market("4400001")
        self.add_market(market)
        self.db.commit()
        client = _BatchClient({market["id"]: market})
        first = asyncio.run(
            collector.collect_resolutions(client, self.db, "2026-08-17T01:00:00+00:00")
        )
        call_count = len(client.calls)
        second = asyncio.run(
            collector.collect_resolutions(client, self.db, "2026-08-17T01:05:00+00:00")
        )
        self.assertEqual((first, second), (1, 0))
        self.assertEqual(len(client.calls), call_count)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0], 1)

    def test_historical_batch_start_rotates_between_five_minute_slots(self) -> None:
        latest = self.market("9900000", day=16)
        self.add_market(latest)
        for index in range(120):
            self.add_market(self.market(str(5_000_000 + index), day=15))
        self.db.commit()

        first_client = _BatchClient()
        second_client = _BatchClient()
        asyncio.run(
            collector.collect_resolutions(
                first_client, self.db, "2026-08-17T01:00:00+00:00"
            )
        )
        asyncio.run(
            collector.collect_resolutions(
                second_client, self.db, "2026-08-17T01:05:00+00:00"
            )
        )
        first_final = [call[0] for call in first_client.calls if call[1] == "true"]
        second_final = [call[0] for call in second_client.calls if call[1] == "true"]
        self.assertIn("9900000", first_final[0])
        self.assertIn("9900000", second_final[0])
        self.assertNotEqual(first_final[0][1:], second_final[0][1:])


if __name__ == "__main__":
    unittest.main()
