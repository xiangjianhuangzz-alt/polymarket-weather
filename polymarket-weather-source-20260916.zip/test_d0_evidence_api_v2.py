from __future__ import annotations

import hashlib
import base64
import json
import sqlite3
import tempfile
import unittest
import zlib
from pathlib import Path
from unittest.mock import patch

import dashboard_modern


V2_CITIES = [
    ("Beijing", "ZBAA", "formal"),
    ("Shanghai", "ZSPD", "formal"),
    ("Chengdu", "ZUUU", "formal"),
    ("Guangzhou", "ZGGG", "formal"),
    ("Shenzhen", "ZGSZ", "research_only"),
    ("Wuhan", "ZHHH", "research_only"),
    ("Chongqing", "ZUCK", "research_only"),
    ("Jinan", "ZSJN", "research_only"),
    ("Qingdao", "ZSQD", "research_only"),
    ("Zhengzhou", "ZHCC", "research_only"),
]
SOURCE_REQUIRED_FIELDS = {
    "source", "source_role", "city", "station", "target_date", "city_scope",
    "policy_status", "status_label", "reason_code", "reason_text", "severity",
    "evidence_status", "fetch_health", "temperature_c", "forecast_bucket",
    "source_reported_at", "first_captured_at", "capture_delay_seconds", "frozen_at",
    "latest_checked_at", "expected_window_start", "expected_window_end",
    "grace_deadline", "evaluation_at", "last_attempt_at", "last_attempt_status",
    "last_success_at", "expected_attempt_seen", "policy_version", "provenance",
    "limitations", "retention_state",
}

# Fixed against the 9d489469 five-city fixture with _d0_now_iso pinned below.
# It is deliberately static: this test never loads Git, another worktree, or
# derives its expected value from the candidate under test.
V1_FULL_GOLDEN_ZLIB_B64 = (
    "eNrtXFtrJMcV/itNv0azGe0lkZWndUz2NWG9YNYMRU13zUxF3dWj7uqRRss8OM7FGwx2wGHB2MGQhLAQ50KIV15w8mc0I/Ivck5d+j6SZr3WrlCBWaS6njrn1Pedr9XuR37IJOWRv/vIpzP4gQ55xOUcf7c9tiNi/pY/YjKYEMljFnHBoFMkklApUz7MJQthREoPCJvxkIkA+yc0m5BERHN/seUHamn/TcZ/zsXY1w0E1ma4z/LDJyfP/4qtSTylKc8SoewSSUyjJM9IluRpwDJ/993BFpgXSUoCf/fmjT7syigMJ0ES4qbDRE7IjEY8JGoYrJmxGUv19gc0FXr7TFKZZ2smqL7CuJPjP60+//Pq+cerzx6vfv/ByTe/xh+Ony6f/Q0G66mlff7+4dEhtEs68geLttvwAMmevyvTnG35UzpmJJ+GFDwIzoTdbvZv/qDX3+n133h7++Zuvw//fa+/A//CmtM0mTFBlXshSlTSIc3w1CnLGE2DCY5JIh7MCRw54+hFP+z3bFB6IxrIrDfb9pXbQh0dY4o+ApEYbnWQUZKygGaShH2SsjHPZDrHPLDNZosM2mKa7jEJo7IkyqVqHKAL0jG04uHIMMlFqLdaNDPl3WYGVlIHU0JIJiTBNujaP+ypnwqD99hcNYPXF1ubrAQR6lwKI7cYbJVObd0QlfpzONqeSA4EzK92l0n9j09XT75YfvRk9cnfVx++d/rpL09/8fXqyVenX3xy+vSrk+d/OX38FOZOwLFJygMaQQLOONXuU3miu+bkgIswOfB3RR5FhbNL/5lmuAARSXI5zaVtmyYczsuFyj88B4N0zdUWKtv0KDzNkGFcCeQTN5vjvFFix5hYMgwitiya2YiplaRl3ulpYyZYWiS3bsNl01gbEeQyGY0KcyncReW+5jrtbA0mLKbNYZmg02wCx+Fh0dRI6wHebzApj+uTFxZJVO5n+XSapGC3Z7PAo6nkeEgP0yjFH3jmgeu8UZocMYEJb7dHfwyjJNgjlSVF4pWrqsD0uOhhYIqlcQ1EwIhJ8OmIRhlTbh7a1KouChmWi2JFYu0k1jxzx+cEvE1GucwhvOrkfATJJtXBzRbluMpmpnehHGPvtTpZHmD+mTTXXtaQvMcxPQBwpYxYjFct5gKQFC8n0W4ienYVR8x6BarrFSMec1m9DCbty8ju51Q5RSO/zRNrqYHkWseslocFBWD+234wbM6y8tcyNxA6jAc0PwKwzWH6Dy3G0zzkMlMeQrCDvYZzkiYHRB3FJq6eZFatH9Ks6+lc9WI694bMy0XBwh4dSZZ6hS1eEDEq8qllZ0+b4E3ojEFqehUA9qgIIc+YytiStb0Jy4FuJcIPXC6Fehrpzene6NecWrNe30FFMQUa3VDkUtLhIz+gU5V7EF86JxmD/AyhZ3un30f6bhcG6/C+gV1nMqU1hxRBNhSvOg+nLNCYJFk8lWAU09fJ4nkxQiNvCXvtLtggLVJKRaFWQVXi4kU02MuqQfkRBqmIQBEWzDL0esB4PWNTtp+zTK7P4ko5VpQeE0YjOemq10Y8hetn4tMuP8Cjt2tObdxYf/fWNjTqa33u5DFgEiYBDXUdZPghhaCUtcoYkyfCLWxoyoPWmted2gzL8gDSL6vNlgwPO2FgesdZdxoJ1LiZlRtOqmVN5XLi5THFV1fSXbQua9R4Gmka5Ue9VVXnPI5zhRsGZy3cGEheU8tduFiEeq1gHbNBBykX2NHlgEanrjGL/kGdqdeZvGjW+yaHDWni2Kp5OFCyQ1m32qCnMoR1u7OiGaBYt7ahgmBQo7A0iaBisojVLkSLNlsL/uydh++UrSkzpN1xa7ZraWgnJNYloIfIlE5ZSkIO/jFYkUlD6P7DN+/ercqbSgAaskarGe+tvl+r1GsGYRfcNyzhEMIDvPI3+lhmr0H12zsXAvVK6e1Q/ZJR/c6ucucZqH5rPao3J19tVDf1VhVdvYAKLJFCDJ4Y5zyDOA8zyF2s8+P1tddrQw5ZHkOpPLei1xHDixNDw5VrSYEa2W7IgeAThI6HCi1WePvuTy5CCncaWVwnBYgjmwKUIbwmkKnpjF4+K9wCVhh07HjWEqB8jxL1JPFuxun370+oGE8ot8/UqFVb5whFk8gxC2AB9RgF87N4mKcfiwD/BFFeU/vF4yslUs5XIfYuWIRFejm/7OUZQbvGzF4FjWSdc3c643x20bFBKbFJbNqkXzhMKXDfGNLbP/QX+JhzSgVTz5LBk5ytc+o1eebr5K+Tv07+Ovnr5K+Tv07+Ovnr5K+Tv07+Xjv5q4hCO6wibmsi6OT4t6t/P9tYBBV/FG+qoAPKpWHlMlqC5TKlUUsBVQavUT/Lz39z+uXj5X9+1SF6Lih0tKkdbqhRoqGhb0WG5tLin14lS2MA5NDx4lm8aI7RJEDTXFKgZbXzua6D1L5Drut6UaD20lHFxzU2guxr0xwaogGEhZrs9HsBEFudSS/Ic+Ute5k0153sbbYzb3gYujOzQjaieSRfkOjWvJHTIjk7rk1vLVKrvYBjAU29NWIuHoYCXAKDIdu2WySmQWr15R+Xx8fLj363PH6/k9C6ndaNlG3Fk5Xg9e0kT+3FpA20zf2fvlXF8LXw3emNi7OZDoYDdAfoDtAdoL9EQAcRQPCdsTCH82As1kiS7xDNX75U6QLzC2mSy0TzQWvnijb58YSJcZg3pcnqg4//9/4310aaVLzgiMwRmSMyR2RXRpkEBXa9GmHy4MGD102YODh3cO7g3MG50yWb6pLLBPNBa+eKLrmXUzE+miQtZbL8+r/LZ3+4Nsqk5gdHZo7MHJk5Mrsy2mRcQa9Xo07u3bv3uqkTB+kO0h2kO0h3+mRzfXKZcD5o7Vx7p4uJo4mKQ/0PJ8/+ufzsX9fona7SDY7KHJU5KnNUdoXe6SrA6xWJk/sPX793uhygO0B3gO4A3WmTTbXJJaL5oLXz4mp/WvTsL4a67+9t8v09/X9u1WVnoD+WmAvwBaxa+QhCtWfbqFnz6x3wGB+NWIp53xgX00NS/y6DKu8610Sc6Owwd6TWfHvxYl8OWSz+D4ePW/w="
)


class D0EvidenceApiV2Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "research.sqlite3"
        db = sqlite3.connect(self.path)
        db.executescript("""
          CREATE TABLE forecast_d0_registry (
            source TEXT NOT NULL, city TEXT NOT NULL, station TEXT NOT NULL,
            target_date TEXT NOT NULL, grid_version TEXT NOT NULL,
            status TEXT NOT NULL, forecast_high_c REAL, forecast_bucket INTEGER,
            source_reported_at TEXT, first_captured_at TEXT NOT NULL,
            capture_delay_seconds REAL, content_hash TEXT, reason TEXT,
            frozen_at TEXT, latest_checked_at TEXT NOT NULL,
            PRIMARY KEY (source, station, target_date, grid_version));
          CREATE TABLE forecast_versions (
            version_id TEXT PRIMARY KEY, source TEXT NOT NULL, city TEXT NOT NULL,
            station TEXT NOT NULL, target_date TEXT NOT NULL, forecast_high_c REAL,
            content_hash TEXT NOT NULL, first_seen_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL, source_display_time TEXT,
            is_change INTEGER NOT NULL DEFAULT 1);
          CREATE TABLE market_resolutions (
            market_id TEXT PRIMARY KEY, city TEXT NOT NULL, target_date TEXT,
            bucket_label TEXT, yes_resolved INTEGER, resolved_at TEXT NOT NULL,
            outcome_prices_json TEXT, resolution_source TEXT);
        """)
        db.executemany("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
            ("weatherol_beijing", "Beijing", "ZBAA", "2026-08-09", "g1",
             "valid_d0", 31.0, 31, "2026-08-09T00:10:00+08:00",
             "2026-08-09T00:40:00+08:00", 1800.0, "qx-hash", "frozen",
             "2026-08-09T00:40:00+08:00", "2026-08-09T08:00:00+08:00"),
            ("aviationweather_taf", "Beijing", "ZBAA", "2026-08-09", "g1",
             "valid_d0", 33.0, 33, "2026-08-09T05:00:00+08:00",
             "2026-08-09T05:08:00+08:00", 480.0, "taf-hash", "frozen",
             "2026-08-09T05:08:00+08:00", "2026-08-09T08:00:00+08:00"),
            ("weatherol_wuhan", "Wuhan", "ZHHH", "2026-08-09", "g1",
             "valid_d0", 99.0, 99, "2026-08-09T00:10:00+08:00",
             "2026-08-09T00:40:00+08:00", 1800.0, "fake-qxzx", "unverified",
             "2026-08-09T00:40:00+08:00", "2026-08-09T08:00:00+08:00"),
            ("aviationweather_taf", "Wuhan", "ZHHH", "2026-08-09", "g1",
             "valid_d0", 35.0, 35, "2026-08-09T05:00:00+08:00",
             "2026-08-09T05:08:00+08:00", 480.0, "wuhan-taf", "frozen",
             "2026-08-09T05:08:00+08:00", "2026-08-09T08:00:00+08:00"),
            ("aviationweather_taf", "Jinan", "ZSJN", "2026-08-10", "g1",
             "valid_d0", 38.0, 38, "2026-08-10T05:00:00+08:00",
             "2026-08-10T05:08:00+08:00", 480.0, "jinan-latest", "frozen",
             "2026-08-10T05:08:00+08:00", "2026-08-10T08:00:00+08:00"),
        ])
        db.executemany("INSERT INTO forecast_versions VALUES (?,?,?,?,?,?,?,?,?,?,?)", [
            ("beijing-qx", "weatherol_beijing", "Beijing", "ZBAA", "2026-08-09",
             31.0, "qx-version", "2026-08-09T00:40:00+08:00",
             "2026-08-09T08:00:00+08:00", "2026-08-09T00:10:00+08:00", 1),
            ("wuhan-taf", "aviationweather_taf", "Wuhan", "ZHHH", "2026-08-09",
             35.0, "wuhan-taf-version", "2026-08-09T05:08:00+08:00",
             "2026-08-09T08:00:00+08:00", "2026-08-09T05:00:00+08:00", 1),
            ("malicious-wuhan-qx", "weatherol_wuhan", "Wuhan", "ZHHH", "2026-08-09",
             99.0, "fake-qxzx-version", "2026-08-09T00:40:00+08:00",
             "2026-08-09T08:00:00+08:00", "2026-08-09T00:10:00+08:00", 1),
            ("wrong-station-wuhan-taf", "aviationweather_taf", "Wuhan", "ZBAA",
             "2026-08-09", 88.0, "wrong-station", "2026-08-09T05:08:00+08:00",
             "2026-08-09T08:00:00+08:00", "2026-08-09T05:00:00+08:00", 1),
            ("wrong-date-jinan-taf", "aviationweather_taf", "Jinan", "ZSJN",
             "2026-08-10", 38.0, "wrong-date", "2026-08-10T05:08:00+08:00",
             "2026-08-10T08:00:00+08:00", "2026-08-10T05:00:00+08:00", 1),
        ])
        db.execute("""INSERT INTO market_resolutions VALUES
          ('other-date','Jinan','2026-08-10','38?C',1,
           '2026-08-11T12:00:00+08:00','{}','official')""")
        db.commit()
        db.close()
        self.api = dashboard_modern.Api()
        self.db_patch = patch.object(dashboard_modern, "DB", self.path)
        self.db_patch.start()

    def tearDown(self) -> None:
        self.db_patch.stop()
        self.temp.cleanup()

    def _digest(self) -> str:
        return hashlib.sha256(self.path.read_bytes()).hexdigest()

    def test_v1_remains_fixed_five_city_contract(self) -> None:
        fixed_now = "2026-08-09T12:00:00+08:00"
        with patch.object(dashboard_modern, "_d0_now_iso", return_value=fixed_now):
            panel = self.api.d0_evidence_panel("2026-08-09")
            detail = self.api.d0_evidence_detail("Beijing", "2026-08-09")
            self.api.d0_evidence_panel_v2("2026-08-09")
            self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
            panel_after = self.api.d0_evidence_panel("2026-08-09")
            detail_after = self.api.d0_evidence_detail("Beijing", "2026-08-09")
        self.assertEqual(panel["schema"], "d0_evidence.v1")
        self.assertEqual([row["city"] for row in panel["cities"]], [
            "Beijing", "Shanghai", "Chengdu", "Guangzhou", "Shenzhen",
        ])
        self.assertTrue(all("city_scope" not in row for row in panel["cities"]))
        self.assertTrue(all("city_scope" not in source
                            for row in panel["cities"] for source in row["sources"]))
        self.assertEqual(detail["schema"], "d0_evidence.v1")
        self.assertNotIn("city_scope", detail)
        self.assertTrue(all("city_scope" not in source for source in detail["sources"]))
        self.assertEqual(panel, panel_after)
        self.assertEqual(detail, detail_after)

    def test_v1_full_panel_and_detail_match_static_legacy_golden(self) -> None:
        expected = json.loads(zlib.decompress(base64.b64decode(V1_FULL_GOLDEN_ZLIB_B64)))
        with patch.object(dashboard_modern, "_d0_now_iso", return_value="2026-08-09T12:00:00+08:00"):
            actual = {
                "panel": self.api.d0_evidence_panel("2026-08-09"),
                "detail": self.api.d0_evidence_detail("Beijing", "2026-08-09"),
            }
        self.assertEqual(actual, expected)

    def test_v2_is_exact_ordered_ten_city_scope_and_station_matrix(self) -> None:
        panel = self.api.d0_evidence_panel_v2("2026-08-09")
        self.assertEqual(panel["schema"], "d0_evidence.v2")
        self.assertEqual(
            [(row["city"], row["station"], row["city_scope"]) for row in panel["cities"]],
            V2_CITIES,
        )
        self.assertEqual(sum(row["city_scope"] == "formal" for row in panel["cities"]), 4)
        self.assertEqual(sum(row["city_scope"] == "research_only" for row in panel["cities"]), 6)
        for city, station, scope in V2_CITIES:
            row = next(item for item in panel["cities"] if item["city"] == city)
            self.assertEqual(row["target_date"], "2026-08-09")
            self.assertEqual([source["source_key"] for source in row["sources"]], ["qxzx", "taf"])
            for source in row["sources"]:
                self.assertTrue(SOURCE_REQUIRED_FIELDS.issubset(source),
                                SOURCE_REQUIRED_FIELDS.difference(source))
                self.assertEqual(
                    (source["city"], source["station"], source["target_date"], source["city_scope"]),
                    (city, station, "2026-08-09", scope),
                )
            detail = self.api.d0_evidence_detail_v2(city, "2026-08-09")
            self.assertEqual(
                (detail["city"], detail["station"], detail["target_date"], detail["city_scope"]),
                (city, station, "2026-08-09", scope),
            )
            self.assertEqual(
                [(item["city"], item["station"], item["target_date"], item["city_scope"])
                 for item in detail["sources"]],
                [(city, station, "2026-08-09", scope)] * 2,
            )

    def test_unconfigured_qxzx_is_static_fail_closed_even_with_malicious_row(self) -> None:
        panel = self.api.d0_evidence_panel_v2("2026-08-09")
        configured = {"Beijing", "Shanghai", "Chengdu", "Guangzhou", "Shenzhen",
                      "Wuhan", "Chongqing", "Jinan", "Zhengzhou"}
        for row in panel["cities"]:
            qxzx = row["sources"][0]
            if row["city"] in configured:
                self.assertEqual(qxzx["source"], f"weatherol_{row['city'].lower()}")
                expected_role = ("formal_paper_direction" if row["city_scope"] == "formal"
                                 else "research_observation")
                self.assertEqual(qxzx["source_role"], expected_role)
                continue
            self.assertIsNone(qxzx["source"])
            self.assertEqual(qxzx["policy_status"], "policy_undetermined")
            self.assertEqual(qxzx["status"], "policy_undetermined")
            self.assertEqual(qxzx["evidence_status"], "policy_undetermined")
            self.assertEqual(qxzx["retention_state"], "policy_undetermined")
            self.assertEqual(qxzx["fetch_health"], "not_configured")
            self.assertEqual(qxzx["reason_code"], "qxzx_source_not_configured")
            self.assertEqual(qxzx["source_role"], "research_observation")
            for field in ("temperature_c", "forecast_bucket", "source_reported_at",
                          "first_captured_at", "capture_delay_seconds", "frozen_at",
                          "latest_checked_at", "grid_version", "content_hash"):
                self.assertIsNone(qxzx[field])
            self.assertIn("source_not_configured", qxzx["limitations"])
            self.assertIn("qxzx_airport_aid_unverified", qxzx["limitations"])
            self.assertFalse(qxzx["provenance"]["configured"])
            self.assertTrue(qxzx["provenance"]["read_only"])
            self.assertIsNone(qxzx["provenance"]["source_table"])
            self.assertEqual(qxzx["provenance"]["registry_statuses"], [])
            self.assertNotEqual(qxzx.get("temperature_c"), 99.0)

        qingdao = next(row for row in panel["cities"] if row["city"] == "Qingdao")
        self.assertEqual(qingdao["comparison"]["status"], "no_valid_evidence")
        real_connect = sqlite3.connect
        statements = []

        def tracing_connect(*args, **kwargs):
            connection = real_connect(*args, **kwargs)
            connection.set_trace_callback(statements.append)
            return connection

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracing_connect):
            detail = self.api.d0_evidence_detail_v2("Qingdao", "2026-08-09")
        self.assertFalse(any("weatherol_qingdao" in statement for statement in statements))
        self.assertEqual([item["source"] for item in detail["versions"]], [])
        self.assertEqual(detail["raw_evidence"][0]["availability"], "not_configured")
        self.assertIsNone(detail["raw_evidence"][0]["content_hash"])

    def test_all_taf_slots_use_fixed_station_and_existing_policy(self) -> None:
        panel = self.api.d0_evidence_panel_v2("2026-08-09")
        for (city, station, _), row in zip(V2_CITIES, panel["cities"]):
            taf = row["sources"][1]
            self.assertEqual(taf["source"], "aviationweather_taf")
            self.assertEqual(taf["source_role"], "independent_observation")
            self.assertEqual((taf["city"], taf["station"]), (city, station))
            self.assertIsNone(taf["expected_window_start"])
            self.assertIsNone(taf["expected_window_end"])
            self.assertIsNone(taf["grace_deadline"])

    def test_extreme_and_invalid_registry_values_fail_closed_consistently(self) -> None:
        db = sqlite3.connect(self.path)
        db.execute("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   ("weatherol_wuhan", "Wuhan", "ZHHH", "2026-08-09", "z9", "valid_d0",
                    float("inf"), "bad-bucket", "9999-12-31T23:59:59-23:59",
                    "0001-01-01T00:00:00+23:59", "bad-delay", "bad", "bad",
                    "9999-12-31T23:59:59-23:59", "9999-12-31T23:59:59-23:59"))
        db.commit(); db.close()
        panel = self.api.d0_evidence_panel_v2("2026-08-09")
        detail = self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
        self.assertTrue(panel["ok"])
        self.assertTrue(detail["ok"])
        panel_source = next(row for row in panel["cities"] if row["city"] == "Wuhan")["sources"][0]
        self.assertEqual(panel_source, detail["sources"][0])
        self.assertNotEqual(panel_source["status"], "valid_d0")
        self.assertIsNone(panel_source["temperature_c"])
        self.assertIsNone(panel_source["forecast_bucket"])
        self.assertIsNone(panel_source["capture_delay_seconds"])

    def test_v2_versions_reject_invalid_fields_without_detail_escape(self) -> None:
        db = sqlite3.connect(self.path)
        db.executemany("INSERT INTO forecast_versions VALUES (?,?,?,?,?,?,?,?,?,?,?)", [
            ("good", "weatherol_wuhan", "Wuhan", "ZHHH", "2026-08-09", 31.0, "good-hash",
             "2026-08-09T00:10:00+08:00", "2026-08-09T00:20:00+08:00", None, 1),
            (" bad ", "weatherol_wuhan", "Wuhan", "ZHHH", "2026-08-09", float("inf"), " bad ",
             "0001-01-01T00:00:00+23:59", "9999-12-31T23:59:59-23:59", None, "1"),
            ("reverse", "weatherol_wuhan", "Wuhan", "ZHHH", "2026-08-09", 32.0, "reverse-hash",
             "2026-08-09T01:00:00+08:00", "2026-08-09T00:20:00+08:00", None, 2),
        ])
        db.commit(); db.close()
        detail = self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
        self.assertTrue(detail["ok"])
        versions = {row["version_id"]: row for row in detail["versions"]}
        self.assertIn("good", versions)
        self.assertNotIn(" bad ", versions)
        self.assertNotIn("reverse", versions)
        self.assertTrue(versions["good"]["is_change"])

    def test_v2_d0_requires_complete_valid_fact_and_uses_utc_priority(self) -> None:
        db = sqlite3.connect(self.path)
        db.executemany("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
            ("weatherol_chongqing", "Chongqing", "ZUCK", "2026-08-09", "old", "valid_d0",
             30.0, 30, "2026-08-09T00:00:00+00:00", "2026-08-09T00:10:00+00:00", 600,
             "old", "old", "2026-08-09T00:10:00+00:00", "2026-08-09T02:00:00+00:00"),
            ("weatherol_chongqing", "Chongqing", "ZUCK", "2026-08-09", "new", "valid_d0",
             41.0, 41, "2026-08-09T00:00:00+00:00", "2026-08-09T00:20:00+00:00", 600,
             "new", "new", "2026-08-09T00:20:00+00:00", "2026-08-09T03:00:00+02:00"),
            ("weatherol_jinan", "Jinan", "ZSJN", "2026-08-09", "bad", "valid_d0",
             29.0, None, "2026-08-09T00:00:00+00:00", "2026-08-09T00:10:00+00:00", 600,
             "bad", "bad", None, "2026-08-09T02:00:00+00:00"),
            ("weatherol_zhengzhou", "Zhengzhou", "ZHCC", "2026-08-09", "waiting", "waiting",
             28.0, 28, "2026-08-09T00:00:00+00:00", "2026-08-09T00:10:00+00:00", 600,
             "waiting", "waiting", "2026-08-09T00:10:00+00:00", "2026-08-09T02:00:00+00:00"),
        ])
        db.commit(); db.close()
        panel = self.api.d0_evidence_panel_v2("2026-08-09")
        records = {row["city"]: row["sources"][0] for row in panel["cities"]}
        self.assertEqual(records["Chongqing"]["temperature_c"], 30.0)
        self.assertNotEqual(records["Jinan"]["status"], "valid_d0")
        self.assertIsNone(records["Jinan"]["temperature_c"])
        self.assertEqual(records["Zhengzhou"]["status"], "waiting")
        self.assertIsNone(records["Zhengzhou"]["temperature_c"])

    def test_v2_versions_order_by_normalized_utc_not_iso_text(self) -> None:
        db = sqlite3.connect(self.path)
        db.executemany("INSERT INTO forecast_versions VALUES (?,?,?,?,?,?,?,?,?,?,?)", [
            ("real-new", "weatherol_wuhan", "Wuhan", "ZHHH", "2026-08-09", 31.0, "hash-new",
             "2026-08-09T02:00:00+00:00", "2026-08-09T02:10:00+00:00", None, 1),
            ("lex-old", "weatherol_wuhan", "Wuhan", "ZHHH", "2026-08-09", 30.0, "hash-old",
             "2026-08-09T03:00:00+02:00", "2026-08-09T03:10:00+02:00", None, 1),
        ])
        db.commit(); db.close()
        detail = self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
        rows = [row["version_id"] for row in detail["versions"]
                if row["version_id"] in {"real-new", "lex-old"}]
        self.assertEqual(rows, ["lex-old", "real-new"])

    def test_v2_formats_verified_times_in_public_panel_and_detail(self) -> None:
        panel = self.api.d0_evidence_panel_v2("2026-08-09")
        source = next(row for row in panel["cities"] if row["city"] == "Beijing")["sources"][0]
        self.assertEqual(source["source_reported_at"], "2026-08-09 00:10:00")
        self.assertEqual(source["first_captured_at"], "2026-08-09 00:40:00")
        self.assertEqual(source["frozen_at"], "2026-08-09 00:40:00")
        self.assertEqual(source["latest_checked_at"], "2026-08-09 08:00:00")
        detail = self.api.d0_evidence_detail_v2("Beijing", "2026-08-09")
        version = next(row for row in detail["versions"] if row["version_id"] == "beijing-qx")
        self.assertEqual(version["first_seen_at"], "2026-08-09 00:40:00")
        self.assertEqual(version["last_seen_at"], "2026-08-09 08:00:00")
        self.assertEqual(version["source_reported_at"], "2026-08-09 00:10:00")

    def test_valid_d0_without_source_time_is_fail_closed_in_v2(self) -> None:
        db = sqlite3.connect(self.path)
        db.execute("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   ("weatherol_chongqing", "Chongqing", "ZUCK", "2026-08-09", "missing-source-time",
                    "valid_d0", 30.0, 30, None, "2026-08-09T00:10:00+00:00", 600,
                    "hash", "frozen", "2026-08-09T00:10:00+00:00", "2026-08-09T01:00:00+00:00"))
        db.commit(); db.close()
        panel_source = next(row for row in self.api.d0_evidence_panel_v2("2026-08-09")["cities"]
                            if row["city"] == "Chongqing")["sources"][0]
        detail_source = self.api.d0_evidence_detail_v2("Chongqing", "2026-08-09")["sources"][0]
        self.assertNotEqual(panel_source["status"], "valid_d0")
        self.assertEqual(panel_source, detail_source)
        self.assertIsNone(panel_source["temperature_c"])
        self.assertIsNone(panel_source["forecast_bucket"])
        self.assertIsNone(panel_source["frozen_at"])

    def test_v2_overdue_is_unreachable_for_configured_qxzx_and_taf(self) -> None:
        qxzx_raw_reason = "old overdue qxzx"
        taf_raw_reason = "old overdue taf"
        db = sqlite3.connect(self.path)
        db.executemany("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
            ("weatherol_shanghai", "Shanghai", "ZSPD", "2026-08-09", "old",
             "publication_overdue", None, None, None, "2026-08-09T06:00:00+08:00",
             None, None, qxzx_raw_reason, None, "2026-08-09T06:00:00+08:00"),
            ("aviationweather_taf", "Guangzhou", "ZGGG", "2026-08-09", "old",
             "publication_overdue", None, None, None, "2026-08-09T06:00:00+08:00",
             None, None, taf_raw_reason, None, "2026-08-09T06:00:00+08:00"),
        ])
        db.commit()
        db.close()

        fixed_now = "2026-08-09T12:00:00+08:00"
        with patch.object(dashboard_modern, "_d0_now_iso", return_value=fixed_now):
            v1_panel_before = self.api.d0_evidence_panel("2026-08-09")
            v1_details_before = {
                city: self.api.d0_evidence_detail(city, "2026-08-09")
                for city in ("Shanghai", "Guangzhou")
            }
            panel = self.api.d0_evidence_panel_v2("2026-08-09")
            details = {
                city: self.api.d0_evidence_detail_v2(city, "2026-08-09")
                for city in ("Shanghai", "Guangzhou")
            }
            v1_panel_after = self.api.d0_evidence_panel("2026-08-09")
            v1_details_after = {
                city: self.api.d0_evidence_detail(city, "2026-08-09")
                for city in ("Shanghai", "Guangzhou")
            }

        self.assertEqual(v1_panel_before, v1_panel_after)
        self.assertEqual(v1_details_before, v1_details_after)
        v1_cases = [
            (next(row for row in v1_panel_after["cities"]
                  if row["city"] == "Shanghai")["sources"][0], qxzx_raw_reason),
            (next(row for row in v1_panel_after["cities"]
                  if row["city"] == "Guangzhou")["sources"][1], taf_raw_reason),
            (v1_details_after["Shanghai"]["sources"][0], qxzx_raw_reason),
            (v1_details_after["Guangzhou"]["sources"][1], taf_raw_reason),
        ]
        for source, raw_reason in v1_cases:
            self.assertEqual(source["reason_text"], raw_reason)

        cases = [
            ("qxzx-panel", next(row for row in panel["cities"]
                                 if row["city"] == "Shanghai")["sources"][0],
             "qxzx_window_not_enabled_v1", qxzx_raw_reason),
            ("taf-panel", next(row for row in panel["cities"]
                                if row["city"] == "Guangzhou")["sources"][1],
             "taf_schedule_not_frozen", taf_raw_reason),
            ("qxzx-detail", details["Shanghai"]["sources"][0],
             "qxzx_window_not_enabled_v1", qxzx_raw_reason),
            ("taf-detail", details["Guangzhou"]["sources"][1],
             "taf_schedule_not_frozen", taf_raw_reason),
        ]
        for path, source, reason_code, raw_reason in cases:
            with self.subTest(path=path):
                self.assertEqual(source["status"], "waiting")
                self.assertEqual(source["policy_status"], "waiting")
                self.assertEqual(source["evidence_status"], "policy_undetermined")
                self.assertEqual(source["reason_code"], reason_code)
                self.assertEqual(source["reason_text"], source["status_label"])
                self.assertEqual(source["reason_text"], "等待正常发布")
                self.assertNotEqual(source["reason_text"], raw_reason)
                for key, value in source.items():
                    if key != "provenance" and isinstance(value, str):
                        self.assertNotIn(raw_reason, value)
                self.assertNotIn(
                    raw_reason,
                    str({key: value for key, value in source.items()
                         if key != "provenance"}),
                )
                self.assertNotIn("publication_overdue", {
                    source["status"], source["policy_status"],
                    source["evidence_status"], source["reason_code"],
                    source["reason_text"], source["status_label"],
                })
                self.assertEqual(source["provenance"]["registry_status"],
                                 "publication_overdue")
                self.assertEqual(source["provenance"]["raw_reason"], raw_reason)
                self.assertIn("publication_overdue_ignored_v1", source["limitations"])
                self.assertIsNone(source["expected_window_start"])
                self.assertIsNone(source["expected_window_end"])
                self.assertIsNone(source["grace_deadline"])

    def test_detail_resolution_and_research_are_fail_closed(self) -> None:
        banned = {"probability", "candidate_mapping", "path_label", "entry", "stop",
                  "strategy_direction", "trading_advice", "profit", "position", "orders"}
        for city in ("Jinan", "Zhengzhou"):
            detail = self.api.d0_evidence_detail_v2(city, "2026-08-09")
            self.assertEqual(detail["schema"], "d0_evidence.v2")
            self.assertEqual(detail["city_scope"], "research_only")
            self.assertEqual(detail["target_date"], "2026-08-09")
            resolution = detail["resolution"]
            self.assertEqual(resolution["status"], "not_resolved")
            self.assertIsNone(resolution["market_id"])
            self.assertIsNone(resolution["forecast_bucket_delta_c"])
            self.assertEqual(set(detail["research"]), {"availability", "reasons", "provenance"})

            def keys(value):
                if isinstance(value, dict):
                    for key, nested in value.items():
                        yield key
                        yield from keys(nested)
                elif isinstance(value, list):
                    for nested in value:
                        yield from keys(nested)

            self.assertFalse(banned.intersection(keys(detail)))

    def test_v2_resolution_keeps_unique_yes_quality_gate_without_guessing_delta(self) -> None:
        db = sqlite3.connect(self.path)
        db.executemany("INSERT INTO market_resolutions VALUES (?,?,?,?,?,?,?,?)", [
            ("jn-yes", "Jinan", "2026-08-09", "37 C", 1,
             "2026-08-10T10:00:00+08:00", "{}", "official"),
            ("jn-latest-no", "Jinan", "2026-08-09", "38 C", 0,
             "2026-08-10T12:00:00+08:00", "{}", "official"),
        ])
        db.commit()
        db.close()
        resolution = self.api.d0_evidence_detail_v2("Jinan", "2026-08-09")["resolution"]
        self.assertEqual(resolution["status"], "resolved")
        self.assertEqual(resolution["market_id"], "jn-yes")
        self.assertIsNone(resolution["forecast_bucket_delta_c"])

        db = sqlite3.connect(self.path)
        db.execute("UPDATE market_resolutions SET yes_resolved=0 WHERE market_id='jn-yes'")
        db.commit()
        db.close()
        no_yes = self.api.d0_evidence_detail_v2("Jinan", "2026-08-09")["resolution"]
        self.assertEqual(no_yes["status"], "unavailable")
        self.assertEqual(no_yes["quality_code"], "no_yes_resolution")

        db = sqlite3.connect(self.path)
        db.executemany("INSERT INTO market_resolutions VALUES (?,?,?,?,?,?,?,?)", [
            ("jn-yes-a", "Jinan", "2026-08-09", "36 C", 1,
             "2026-08-10T13:00:00+08:00", "{}", "official"),
            ("jn-yes-b", "Jinan", "2026-08-09", "37 C", 1,
             "2026-08-10T14:00:00+08:00", "{}", "official"),
        ])
        db.commit()
        db.close()
        conflicting = self.api.d0_evidence_detail_v2("Jinan", "2026-08-09")["resolution"]
        self.assertEqual(conflicting["status"], "unavailable")
        self.assertEqual(conflicting["quality_code"], "conflicting_yes_resolutions")

        db = sqlite3.connect(self.path)
        db.execute("DELETE FROM market_resolutions WHERE city='Jinan' AND target_date='2026-08-09'")
        db.execute("INSERT INTO market_resolutions VALUES (?,?,?,?,?,?,?,?)",
                   ("jn-unparseable", "Jinan", "2026-08-09", "unknown bucket", 1,
                    "2026-08-10T15:00:00+08:00", "{}", "official"))
        db.commit()
        db.close()
        unparseable = self.api.d0_evidence_detail_v2("Jinan", "2026-08-09")["resolution"]
        self.assertIsNone(unparseable["forecast_bucket_delta_c"])
        self.assertIn("unparseable_bucket_label", unparseable["limitations"])

    def test_v1_and_v2_are_strictly_target_date_bound(self) -> None:
        v1 = self.api.d0_evidence_panel("2026-08-09")
        v2 = self.api.d0_evidence_panel_v2("2026-08-09")
        v1_junk = [row for row in v1["cities"] if row["city"] == "Shenzhen"][0]
        self.assertTrue(all(source["target_date"] == "2026-08-09" for source in v1_junk["sources"]))
        jinan = next(row for row in v2["cities"] if row["city"] == "Jinan")
        self.assertIsNone(jinan["sources"][1]["temperature_c"])
        self.assertEqual(jinan["sources"][1]["target_date"], "2026-08-09")
        jinan_detail = self.api.d0_evidence_detail_v2("Jinan", "2026-08-09")
        self.assertEqual(jinan_detail["versions"], [])
        self.assertIsNone(jinan_detail["resolution"]["market_id"])
        self.assertEqual(jinan_detail["availability"]["raw_evidence"],
                         "policy_undetermined")
        invalid = self.api.d0_evidence_detail_v2("Nanjing", "2026-08-09")
        self.assertEqual(invalid["schema"], "d0_evidence.v2")
        self.assertEqual(invalid["error"]["code"], "unsupported_city")

    def test_v2_uses_read_only_connections_closes_and_preserves_database(self) -> None:
        before = self._digest()
        panel = self.api.d0_evidence_panel_v2("2026-08-09")
        detail = self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
        self.assertTrue(panel["provenance"]["read_only"])
        self.assertTrue(detail["provenance"]["read_only"])
        self.assertEqual(before, self._digest())

        real_connect = sqlite3.connect
        tracked = []

        class ConnectionProxy:
            def __init__(self, connection, uri):
                object.__setattr__(self, "connection", connection)
                object.__setattr__(self, "closed", False)
                object.__setattr__(self, "uri", uri)
                object.__setattr__(self, "total_changes_at_close", None)

            def __getattr__(self, name):
                return getattr(self.connection, name)

            def __setattr__(self, name, value):
                if name in {"connection", "closed", "uri", "total_changes_at_close"}:
                    object.__setattr__(self, name, value)
                else:
                    setattr(self.connection, name, value)

            def close(self):
                object.__setattr__(self, "total_changes_at_close", self.connection.total_changes)
                object.__setattr__(self, "closed", True)
                return self.connection.close()

        def tracking_connect(*args, **kwargs):
            proxy = ConnectionProxy(real_connect(*args, **kwargs), args[0])
            tracked.append(proxy)
            return proxy

        def assert_last_read_only_and_closed(index):
            self.assertIn("mode=ro", tracked[index].uri)
            self.assertTrue(tracked[index].closed)
            self.assertEqual(tracked[index].total_changes_at_close, 0)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect):
            self.assertTrue(self.api.d0_evidence_panel_v2("2026-08-09")["ok"])
            self.assertTrue(self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")["ok"])
        assert_last_read_only_and_closed(0)
        assert_last_read_only_and_closed(1)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(dashboard_modern, "_d0_has_table", return_value=False):
            response = self.api.d0_evidence_panel_v2("2026-08-09")
        self.assertEqual(response["error"]["code"], "data_contract_unavailable")
        assert_last_read_only_and_closed(2)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(dashboard_modern, "_d0_has_table", return_value=False):
            response = self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
        self.assertEqual(response["error"]["code"], "data_contract_unavailable")
        assert_last_read_only_and_closed(3)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(self.api, "_d0_panel_from_db_v2", side_effect=ValueError("dto failed")):
            response = self.api.d0_evidence_panel_v2("2026-08-09")
        self.assertFalse(response["ok"])
        assert_last_read_only_and_closed(4)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(self.api, "_d0_sources_v2", side_effect=ValueError("dto failed")):
            response = self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
        self.assertEqual(response["error"]["code"], "data_contract_unavailable")
        assert_last_read_only_and_closed(5)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(self.api, "_d0_versions_v2",
                          side_effect=sqlite3.DatabaseError("query failed")):
            response = self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
        self.assertEqual(response["error"]["code"], "data_contract_unavailable")
        assert_last_read_only_and_closed(6)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(dashboard_modern, "_d0_has_table",
                          side_effect=sqlite3.OperationalError("database is locked")):
            response = self.api.d0_evidence_detail_v2("Wuhan", "2026-08-09")
        self.assertEqual(response["error"]["code"], "data_temporarily_unavailable")
        assert_last_read_only_and_closed(7)

        with patch.object(dashboard_modern.sqlite3, "connect") as connect_mock:
            bad_date = self.api.d0_evidence_panel_v2("2026-02-30")
            bad_city = self.api.d0_evidence_detail_v2("Nanjing", "2026-08-09")
        self.assertEqual(bad_date["schema"], "d0_evidence.v2")
        self.assertEqual(bad_city["schema"], "d0_evidence.v2")
        connect_mock.assert_not_called()


if __name__ == "__main__":
    unittest.main()
