"""Chinese, read-only, real-time dashboard for highest-temperature research."""
from __future__ import annotations

import json
import os
import sqlite3
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import ttk

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "research.sqlite3"
REFRESH_MS = int(os.getenv("UI_REFRESH_MS", "2000"))
BG, PANEL, PANEL_2, TEXT, MUTED = "#0b0f14", "#121922", "#18212c", "#eef3f8", "#91a0b2"
GREEN, RED, BORDER, BLUE = "#8dc48d", "#dc8d95", "#263342", "#77aee8"
CITY_NAMES = {"Beijing": "北京", "Shanghai": "上海", "Chengdu": "成都", "Guangzhou": "广州", "Shenzhen": "深圳"}
MODEL_NAMES = {"aviationweather_taf": "TAF"}


class Dashboard(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("温度市场实时看板（只读研究模式）")
        self.geometry("1360x820")
        self.minsize(1080, 680)
        self.configure(bg=BG)
        self.selected_market: str | None = None
        self.markets: list[dict] = []
        self.city_var = tk.StringVar()
        self.date_var = tk.StringVar()
        self.status_var = tk.StringVar(value="正在连接研究数据库…")
        self._build()
        self.refresh()

    def label(self, parent: tk.Widget, text: str = "", size: int = 10, bold: bool = False, fg: str = TEXT, **kwargs: object) -> tk.Label:
        return tk.Label(parent, text=text, bg=kwargs.pop("bg", PANEL), fg=fg,
                        font=("Microsoft YaHei UI", size, "bold" if bold else "normal"), **kwargs)

    def _build(self) -> None:
        top = tk.Frame(self, bg=BG, padx=18, pady=13); top.pack(fill="x")
        self.label(top, "温度市场实时看板", 18, True, bg=BG).pack(side="left")
        self.label(top, "仅记录市场与预报；不会下单", 10, bg=BG, fg=GREEN).pack(side="left", padx=16)
        self.label(top, "", 9, bg=BG, fg=MUTED, textvariable=self.status_var).pack(side="right")
        tk.Button(top, text="结算结果与偏差", command=self.show_bias, bg=PANEL_2, fg=TEXT, activebackground="#253244", relief="flat", padx=10).pack(side="right", padx=6)
        tk.Button(top, text="预报模型记录", command=self.show_forecasts, bg=PANEL_2, fg=TEXT, activebackground="#253244", relief="flat", padx=10).pack(side="right", padx=6)

        controls = tk.Frame(self, bg=PANEL, padx=16, pady=10); controls.pack(fill="x", padx=18)
        self.label(controls, "城市", 10, True).pack(side="left")
        self.city_box = ttk.Combobox(controls, textvariable=self.city_var, state="readonly", width=12)
        self.city_box.pack(side="left", padx=(8, 18)); self.city_box.bind("<<ComboboxSelected>>", lambda _: self._reselect())
        self.label(controls, "交易日期", 10, True).pack(side="left")
        self.date_box = ttk.Combobox(controls, textvariable=self.date_var, state="readonly", width=14)
        self.date_box.pack(side="left", padx=8); self.date_box.bind("<<ComboboxSelected>>", lambda _: self._reselect())
        tk.Button(controls, text="立即刷新", command=self.refresh, bg=PANEL_2, fg=TEXT, activebackground="#253244", relief="flat", padx=12).pack(side="right")

        title = tk.Frame(self, bg=BG, padx=18, pady=13); title.pack(fill="x")
        self.market_title = self.label(title, "等待市场数据", 15, True, bg=BG); self.market_title.pack(anchor="w")
        self.market_subtitle = self.label(title, "", 10, bg=BG, fg=MUTED); self.market_subtitle.pack(anchor="w", pady=(3, 0))
        self.bucket_frame = tk.Frame(self, bg=BG, padx=18); self.bucket_frame.pack(fill="x")

        body = tk.Frame(self, bg=BG, padx=18, pady=12); body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=PANEL); left.pack(side="left", fill="both", expand=True)
        right = tk.Frame(body, bg=PANEL, width=325); right.pack(side="right", fill="y", padx=(12, 0)); right.pack_propagate(False)
        self._build_chart(left)
        self._build_book(right)

        bottom = tk.Frame(self, bg=BG, padx=18); bottom.pack(fill="x", pady=(0, 18))
        self._build_bottom(bottom)

    def _build_chart(self, parent: tk.Frame) -> None:
        header = tk.Frame(parent, bg=PANEL, padx=14, pady=11); header.pack(fill="x")
        self.chart_value = self.label(header, "—", 20, True); self.chart_value.pack(side="left")
        self.chart_change = self.label(header, "等待实时盘口", 10, bg=PANEL, fg=MUTED); self.chart_change.pack(side="left", padx=12)
        self.label(header, "YES 概率 · 最近 1 小时", 10, bg=PANEL, fg=MUTED).pack(side="right")
        self.chart = tk.Canvas(parent, bg=PANEL, highlightthickness=0, height=350)
        self.chart.pack(fill="both", expand=True, padx=10, pady=(0, 10)); self.chart.bind("<Configure>", lambda _: self._draw_chart())

    def _build_book(self, parent: tk.Frame) -> None:
        self.label(parent, "盘口深度", 13, True, bg=PANEL).pack(anchor="w", padx=14, pady=(13, 3))
        self.book_note = self.label(parent, "最近一次完整订单簿", 9, bg=PANEL, fg=MUTED); self.book_note.pack(anchor="w", padx=14, pady=(0, 8))
        headings = tk.Frame(parent, bg=PANEL, padx=14); headings.pack(fill="x")
        self.label(headings, "价格", 9, bg=PANEL, fg=MUTED).pack(side="left")
        self.label(headings, "数量", 9, bg=PANEL, fg=MUTED).pack(side="right")
        self.asks = tk.Frame(parent, bg=PANEL, padx=14); self.asks.pack(fill="x")
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", padx=14, pady=9)
        self.spread = self.label(parent, "买卖价差：—", 10, bg=PANEL, fg=MUTED); self.spread.pack(anchor="w", padx=14)
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", padx=14, pady=9)
        self.bids = tk.Frame(parent, bg=PANEL, padx=14); self.bids.pack(fill="x")

    def _build_bottom(self, parent: tk.Frame) -> None:
        parent.columnconfigure((0, 1, 2), weight=1)
        self.forecast_card = self._card(parent, 0, "预报最高温", "等待预报数据", "来源：—")
        self.quote_card = self._card(parent, 1, "当前报价", "买一 — / 卖一 —", "实时 CLOB 订单簿")
        self.mode_card = self._card(parent, 2, "策略状态", "研究模式：不下单", "仅记录价格、预报与未来偏差")

    def _card(self, parent: tk.Frame, col: int, heading: str, value: str, sub: str) -> tuple[tk.Label, tk.Label]:
        frame = tk.Frame(parent, bg=PANEL, padx=15, pady=13); frame.grid(row=0, column=col, sticky="ew", padx=(0 if col == 0 else 6, 0 if col == 2 else 6))
        self.label(frame, heading, 10, True, bg=PANEL, fg=MUTED).pack(anchor="w")
        value_label = self.label(frame, value, 14, True, bg=PANEL); value_label.pack(anchor="w", pady=(6, 2))
        sub_label = self.label(frame, sub, 9, bg=PANEL, fg=MUTED); sub_label.pack(anchor="w")
        return value_label, sub_label

    @staticmethod
    def _date_from_question(question: str) -> str:
        # Gamma's end time can be UTC; the question is the market's authoritative displayed date.
        import re
        match = re.search(r"on ([A-Za-z]+ \d{1,2}(?:, \d{4})?)", question)
        if not match:
            return "未知日期"
        raw = match.group(1)
        try:
            return datetime.strptime(raw + ("" if "," in raw else ", " + str(datetime.now().year)), "%B %d, %Y").strftime("%Y-%m-%d")
        except ValueError:
            return raw

    def _read(self) -> None:
        db = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
        rows = db.execute("""
            SELECT m.market_id, m.city, COALESCE(m.bucket_label, m.question), m.question, m.tokens_json,
                   m.liquidity, m.end_date, m.resolution_source
            FROM market_snapshots m JOIN (
                SELECT market_id, MAX(captured_at) AS latest FROM market_snapshots GROUP BY market_id
            ) x ON x.market_id=m.market_id AND x.latest=m.captured_at
            WHERE m.active=1 ORDER BY m.city, m.question, m.bucket_label
        """).fetchall()
        self.markets = []
        for row in rows:
            tokens = json.loads(row[4] or "[]")
            if tokens:
                self.markets.append({"id": str(row[0]), "city": row[1], "bucket": row[2], "question": row[3], "token": str(tokens[0]), "liquidity": row[5] or 0, "date": self._date_from_question(row[3])})
        self._db = db

    def _reselect(self) -> None:
        choices = [m for m in self.markets if (not self.city_var.get() or m["city"] == self.city_var.get()) and (not self.date_var.get() or m["date"] == self.date_var.get())]
        if choices and self.selected_market not in {m["id"] for m in choices}:
            self.selected_market = choices[0]["id"]
        self._render()

    def _selected(self) -> dict | None:
        return next((m for m in self.markets if m["id"] == self.selected_market), None)

    def _fill_levels(self, target: tk.Frame, levels: list[tuple[float, float]], color: str) -> None:
        for child in target.winfo_children(): child.destroy()
        for price, size in levels:
            row = tk.Frame(target, bg=PANEL); row.pack(fill="x", pady=2)
            self.label(row, f"{price * 100:.1f}%", 10, bg=PANEL, fg=color).pack(side="left")
            self.label(row, f"{size:,.0f}", 10, bg=PANEL, fg=TEXT).pack(side="right")

    def _render(self) -> None:
        selected = self._selected()
        for child in self.bucket_frame.winfo_children(): child.destroy()
        if not selected:
            self.market_title.config(text="当前没有可显示的最高温市场")
            self.market_subtitle.config(text="采集器下一轮会重新搜索北京、上海、成都、广州、深圳的今天/明天/后天市场。")
            self.chart_value.config(text="—"); self._fill_levels(self.asks, [], RED); self._fill_levels(self.bids, [], GREEN); return
        siblings = [m for m in self.markets if m["city"] == selected["city"] and m["date"] == selected["date"]]
        for market in siblings:
            active = market["id"] == selected["id"]
            tk.Button(self.bucket_frame, text=market["bucket"], command=lambda ident=market["id"]: self._select(ident),
                      bg=BLUE if active else PANEL_2, fg="#07111d" if active else TEXT, activebackground=BLUE,
                      relief="flat", padx=10, pady=7).pack(side="left", padx=(0, 6), pady=2)
        cn_city = CITY_NAMES.get(selected["city"], selected["city"])
        self.market_title.config(text=f"{cn_city} · {selected['date']} · {selected['bucket']}")
        self.market_subtitle.config(text=f"Polymarket 原文：{selected['question']}    流动性：${float(selected['liquidity']):,.0f}")
        levels = self._db.execute("""
            SELECT side, price, size FROM orderbook_levels WHERE token_id=? AND captured_at=(
              SELECT MAX(captured_at) FROM orderbook_levels WHERE token_id=?) ORDER BY side, price
        """, (selected["token"], selected["token"])).fetchall()
        asks = sorted([(float(p), float(s)) for side, p, s in levels if side == "ask"], key=lambda x: x[0])[:5]
        bids = sorted([(float(p), float(s)) for side, p, s in levels if side == "bid"], key=lambda x: x[0], reverse=True)[:5]
        if not levels:
            bbo = self._db.execute("SELECT best_bid, best_ask, bid_size, ask_size FROM book_snapshots WHERE token_id=? ORDER BY captured_at DESC LIMIT 1", (selected["token"],)).fetchone()
            if bbo:
                bids = [(float(bbo[0]), float(bbo[2] or 0))] if bbo[0] is not None else []
                asks = [(float(bbo[1]), float(bbo[3] or 0))] if bbo[1] is not None else []
                self.book_note.config(text="实时买一/卖一（完整深度等待下一次订单簿推送）")
        else:
            self.book_note.config(text="最近一次完整订单簿 · 前五档")
        self._fill_levels(self.asks, list(reversed(asks)), RED); self._fill_levels(self.bids, bids, GREEN)
        if bids and asks: self.spread.config(text=f"买卖价差：{(asks[0][0] - bids[0][0]) * 100:.1f} 个百分点")
        else: self.spread.config(text="买卖价差：等待报价")
        bbo = self._db.execute("SELECT best_bid, best_ask FROM book_snapshots WHERE token_id=? ORDER BY captured_at DESC LIMIT 1", (selected["token"],)).fetchone()
        bid, ask = (bbo or (None, None))
        mid = (float(bid) + float(ask)) / 2 if bid is not None and ask is not None else (float(bid) if bid is not None else (float(ask) if ask is not None else None))
        self.chart_value.config(text=f"{mid * 100:.1f}%" if mid is not None else "—")
        self.quote_card[0].config(text=f"买一 {float(bid)*100:.1f}% / 卖一 {float(ask)*100:.1f}%" if bid is not None and ask is not None else "等待买卖报价")
        self._forecast(selected)
        self._draw_chart()

    def _forecast(self, selected: dict) -> None:
        station_row = self._db.execute("SELECT station FROM airport_stations WHERE city=? LIMIT 1", (selected["city"],)).fetchone()
        if not station_row: return
        rows = self._db.execute("""
          SELECT model, forecast_json FROM forecast_snapshots WHERE city=? AND captured_at=(
            SELECT MAX(captured_at) FROM forecast_snapshots WHERE city=?) ORDER BY model
        """, (station_row[0], station_row[0])).fetchall()
        values = []
        for model, raw in rows:
            daily = json.loads(raw).get("daily", {}); dates = daily.get("time", []); highs = daily.get("temperature_2m_max", [])
            for date, high in zip(dates, highs):
                normalized = str(date)
                if len(normalized) == 8 and normalized.isdigit(): normalized = f"{normalized[:4]}-{normalized[4:6]}-{normalized[6:]}"
                if normalized == selected["date"] and high is not None: values.append((MODEL_NAMES.get(model, model), float(high)))
        if values:
            text = " / ".join(f"{name.split('（')[0]} {high:.1f}°C" for name, high in values)
            self.forecast_card[0].config(text=text); self.forecast_card[1].config(text="机场/观测点坐标对应的日最高温")
        else:
            self.forecast_card[0].config(text="尚无该日期的预报"); self.forecast_card[1].config(text="等待采集器更新")

    def _draw_chart(self) -> None:
        if not hasattr(self, "_db"): return
        selected = self._selected(); canvas = self.chart; canvas.delete("all")
        if not selected: return
        rows = self._db.execute("SELECT captured_at, best_bid, best_ask FROM book_snapshots WHERE token_id=? ORDER BY captured_at DESC LIMIT 360", (selected["token"],)).fetchall()[::-1]
        points = []
        for stamp, bid, ask in rows:
            if bid is not None and ask is not None: points.append((stamp, (float(bid)+float(ask))*50))
            elif bid is not None: points.append((stamp, float(bid)*100))
            elif ask is not None: points.append((stamp, float(ask)*100))
        width, height = max(canvas.winfo_width(), 320), max(canvas.winfo_height(), 220)
        if len(points) < 2:
            canvas.create_text(width/2, height/2, text="等待实时盘口历史…", fill=MUTED, font=("Microsoft YaHei UI", 11)); return
        vals = [v for _, v in points]; low, high = min(vals), max(vals)
        pad = max(1.0, (high-low)*0.18); low, high = max(0, low-pad), min(100, high+pad)
        for frac in (0, .25, .5, .75, 1):
            y = 18 + frac*(height-48); value = high-(high-low)*frac
            canvas.create_line(48, y, width-14, y, fill=BORDER)
            canvas.create_text(40, y, text=f"{value:.0f}%", fill=MUTED, font=("Microsoft YaHei UI", 8), anchor="e")
        xy = []
        for i, (_, value) in enumerate(points):
            x = 52 + i*(width-70)/max(1, len(points)-1); y = 18+(high-value)*(height-48)/max(.1, high-low); xy.extend((x,y))
        canvas.create_line(*xy, fill=GREEN if vals[-1] >= vals[0] else RED, width=2, smooth=True)
        canvas.create_text(52, height-16, text=points[0][0][11:16], fill=MUTED, font=("Microsoft YaHei UI", 8), anchor="w")
        canvas.create_text(width-14, height-16, text=points[-1][0][11:16], fill=MUTED, font=("Microsoft YaHei UI", 8), anchor="e")
        change = vals[-1] - vals[0]; self.chart_change.config(text=f"近段变化 {change:+.1f} 个百分点", fg=GREEN if change >= 0 else RED)

    def _select(self, market_id: str) -> None:
        self.selected_market = market_id; self._render()

    def _research_window(self, title: str, columns: tuple[str, ...], widths: tuple[int, ...]) -> tuple[tk.Toplevel, ttk.Treeview]:
        window = tk.Toplevel(self); window.title(title); window.geometry("1120x560"); window.configure(bg=BG)
        tk.Label(window, text=title, bg=BG, fg=TEXT, font=("Microsoft YaHei UI", 15, "bold")).pack(anchor="w", padx=16, pady=(14, 4))
        holder = tk.Frame(window, bg=BG); holder.pack(fill="both", expand=True, padx=16, pady=(6, 16))
        table = ttk.Treeview(holder, columns=columns, show="headings")
        for name, width in zip(columns, widths):
            table.heading(name, text=name); table.column(name, width=width, minwidth=80, stretch=True)
        bar = ttk.Scrollbar(holder, orient="vertical", command=table.yview); table.configure(yscrollcommand=bar.set)
        table.pack(side="left", fill="both", expand=True); bar.pack(side="right", fill="y")
        return window, table

    def show_forecasts(self) -> None:
        window, table = self._research_window("预报模型记录（仅日最高温）", ("城市", "观测点", "预报来源", "日期", "预测最高温", "采集时间"), (110, 100, 230, 150, 150, 220))
        try:
            db = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
            rows = db.execute("""
                SELECT a.city, f.city, f.model, f.forecast_json, f.captured_at FROM forecast_snapshots f
                LEFT JOIN airport_stations a ON a.station=f.city
                WHERE f.captured_at IN (SELECT MAX(captured_at) FROM forecast_snapshots GROUP BY city, model)
                ORDER BY a.city, f.model
            """).fetchall(); db.close()
            for city, station, model, raw, captured in rows:
                daily = json.loads(raw).get("daily", {})
                for date, high in zip(daily.get("time", []), daily.get("temperature_2m_max", [])):
                    if high is not None:
                        text_date = str(date); text_date = f"{text_date[:4]}-{text_date[4:6]}-{text_date[6:]}" if len(text_date) == 8 and text_date.isdigit() else text_date
                        table.insert("", "end", values=(CITY_NAMES.get(city, city), station, MODEL_NAMES.get(model, model), text_date, f"{float(high):.1f}°C", captured.replace("T", " ")[:19]))
        except (sqlite3.Error, json.JSONDecodeError, OSError) as exc:
            table.insert("", "end", values=("读取失败", str(exc), "", "", "", ""))

    def show_bias(self) -> None:
        window, table = self._research_window("结算结果与偏差", ("城市", "最高温档位", "结算状态", "市场最终 YES", "模型偏差", "交易偏差"), (120, 160, 150, 160, 210, 210))
        note = tk.Label(window, text="说明：当前已保存已结算市场；最终机场实测值与模型偏差将在结算解析模块完成后填入。", bg=BG, fg=MUTED, font=("Microsoft YaHei UI", 9))
        note.pack(anchor="w", padx=16, pady=(0, 8), before=table.master)
        try:
            db = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
            rows = db.execute("""
                SELECT city, COALESCE(bucket_label, question), prices_json FROM market_snapshots
                WHERE closed=1 AND captured_at IN (SELECT MAX(captured_at) FROM market_snapshots GROUP BY market_id)
                ORDER BY city, bucket_label
            """).fetchall(); db.close()
            if not rows: table.insert("", "end", values=("暂无已结算市场", "—", "—", "—", "待接入最终实测值", "待累计盘口/成交记录"))
            for city, bucket, prices in rows:
                yes = float(json.loads(prices or "[0]")[0]) * 100
                table.insert("", "end", values=(CITY_NAMES.get(city, city), bucket, "已结算", f"{yes:.1f}%", "待接入最终实测值", "待累计盘口/成交记录"))
        except (sqlite3.Error, json.JSONDecodeError, OSError) as exc:
            table.insert("", "end", values=("读取失败", str(exc), "", "", "", ""))

    def refresh(self) -> None:
        try:
            if not DB_PATH.exists(): raise FileNotFoundError("尚未创建数据库")
            self._read()
            cities = sorted({m["city"] for m in self.markets}, key=lambda c: list(CITY_NAMES).index(c) if c in CITY_NAMES else 99)
            if cities:
                self.city_box["values"] = cities
                if self.city_var.get() not in cities: self.city_var.set(cities[0])
                dates = sorted({m["date"] for m in self.markets if m["city"] == self.city_var.get()})
                self.date_box["values"] = dates
                if self.date_var.get() not in dates: self.date_var.set(dates[0])
                self._reselect()
            run = self._db.execute("SELECT captured_at FROM collector_runs ORDER BY captured_at DESC LIMIT 1").fetchone()
            self.status_var.set(f"自动刷新：{REFRESH_MS/1000:.0f} 秒 · 采集器最近：{run[0].replace('T',' ')[:19] if run else '等待首轮'}")
            self._db.close(); del self._db
        except (sqlite3.Error, OSError, json.JSONDecodeError) as exc:
            self.status_var.set(f"等待数据：{exc}")
        self.after(REFRESH_MS, self.refresh)


if __name__ == "__main__":
    Dashboard().mainloop()
