# Polymarket天气项目｜当前任务契约

版本：v1.4
状态：ACTIVE
当前日期：2026-09-03（Asia/Shanghai）

## 1. 当前业务位置

- V3已经于2026-08-30完成系统级退役，不得恢复。
- 郑州已经于2026-08-30完成系统级退役，不得进入未来采集、行情订阅、METAR或页面路径；历史结算身份和历史记录保持可读。
- 当前活动运行域仅为Collector、Realtime、METAR和Runtime Observer。
- Dashboard不属于正式活动管理域；2026-08-31实现前现场审计发现未纳管的`dashboard_live.py`父子进程，该漂移不代表Dashboard恢复，未经独立授权不得启停或处置。
- 真实交易、订单、资金和资格保持关闭。
- 当前运行Release不能由进程完整自证时，必须继续标记`RUNNING_RELEASE_UNVERIFIED`。

## 2. 当前策略阶段

- 新动态策略V8曾被登记为`ACCEPTED_V8_COMPLETE_END_TO_END_RESEARCH_ARCHITECTURE_DESIGN_ONLY`；2026-09-01方案B只读全面交叉审查发现冻结正文、登记附录、上游合同与独立终审结论之间存在实施级矛盾。V8四份冻结文件继续作为不可回写的历史设计证据，但V8不再具备直接实施充分性。
- 当前权威设计输入为[`T00_新动态策略设计输入基线_2026-08-31.md`](T00_新动态策略设计输入基线_2026-08-31.md)。
- V8设计规范成员为[`T00_新动态策略端到端研究架构完整设计_v8_2026-08-31.md`](T00_新动态策略端到端研究架构完整设计_v8_2026-08-31.md)和[`T00_新动态策略端到端研究架构登记附录_v8_2026-08-31.md`](T00_新动态策略端到端研究架构登记附录_v8_2026-08-31.md)；冻结身份及接受证据分别为[`T00_新动态策略端到端研究架构设计Manifest_v8_2026-08-31.md`](T00_新动态策略端到端研究架构设计Manifest_v8_2026-08-31.md)和[`T00_新动态策略端到端研究架构独立终审_v8_2026-08-31.md`](T00_新动态策略端到端研究架构独立终审_v8_2026-08-31.md)。
- V8正文、附录和Manifest文件头的`AWAITING_V8_MANIFEST`或`FROZEN_FOR_INDEPENDENT_V8_DESIGN_AUDIT_ONLY`记录各文件被冻结时的阶段，不是当前生命周期裁决；为保持冻结SHA256不得回写。当前设计状态只由哈希匹配的Manifest与后续独立终审共同证明，最终为设计-only接受，不产生实现或部署授权。
- V8设计控制面已在Git提交`96e9b3f3d2b8b2dd8c7495dbc06cfdad562d92d3`完成集成，但只证明提交身份。V8.1、R2、V8.2与V8.2-R1独立终审均为`FAIL`。R1 FAIL后形成并冻结Architecture Kernel `ak2`；2026-09-02依据当前`AGENTS.md`阶段边界完成Finding重新分类和KG-01裁决，独立QA最终确认`K1—K6=PASS`、`TRUE_KERNEL_BLOCKERS=0`、`KERNEL_FINAL_VERDICT=PASS`。Architecture Kernel阶段正式结束，但不产生完整设计、实现、测试、Git或部署授权。
- Complete Design候选`cd4`已经冻结并完成独立QA：`COMPLETE_DESIGN_QA_VERDICT=PASS`、`COMPLETE_DESIGN_ACCEPTED=YES`、`TRUE_COMPLETE_DESIGN_BLOCKERS=0`。`cd1`、`cd2`、`cd3`、`cd4`均保持冻结；这一状态不产生实现、测试、Git或部署授权。
- 设计血缘审计曾确认缺少的7组实现规划必需Requirement，已经由Implementation Input Closure `iic2`逐项闭合并通过最终独立QA。当前冻结`IIC2 Candidate Hash=fde2c34c6f8c01e68a176b6c577eead4d931c81ab4f4ea64b41875d4c9629c03`，唯一规范源SHA256=`22958942034314447067b0d01b124cc855b0207bf862f192ece48d6cfb4b3ff4`，Manifest SHA256=`0b2fc5d318ff05e3f5f83965cc0135ded84d79722fa6b66e42b0b0a46cb969c3`；最终QA为`IMPLEMENTATION_INPUT_CLOSURE_QA_VERDICT=PASS`、`TRUE_IMPLEMENTATION_INPUT_BLOCKERS=0`、`CAN_TWO_IMPLEMENTERS_STILL_DIVERGE=NO`。因此`IMPLEMENTATION_INPUT_CLOSURE_COMPLETE=YES`、`IMPLEMENTATION_PLANNING_READINESS=READY`；该READY只允许等待Implementation Planning的独立授权，不产生实现或后续权限。
- 当前阶段已由用户独立授权进入`CURRENT_STAGE=IMPLEMENTATION_PLANNING`；`IMPLEMENTATION_PLAN_STATUS=READY`、`IMPLEMENTATION_PLAN_REFERENCE=IMPLEMENTATION_PLAN_V1`、`ACCEPTED_FOR_PLANNING=YES`、`IMPLEMENTATION_AUTHORIZATION_REQUEST_STATUS=READY`。`IMPLEMENTATION_PLAN_V1`是本控制面内嵌施工摘要对应的规划标识，不是仓库中的独立文件；其状态只证明规划可供后续授权使用，不表示实现已经开始。
- 第一次Implementation候选范围固定为：`WP-01`仅实现Canonical、Hash、Decimal、Time、Enum及ErrorCode/OutcomeClass；`WP-02-FOUNDATION`仅实现`schema_metadata`、`database_identity`、city/role隔离基础及repository identity validation，不包括业务表、Decision、ActiveConfig或Runtime状态；`VS-01-SKELETON`仅定义Request、Result、DependencySet和输入输出边界，且`VS01_SKELETON_ONLY=YES`、`VS01_EXECUTABLE=NO`。
- 第一次Implementation候选明确排除：WP-03及以后策略实现、Probability Model、PAV、P_LCB、C_executable、delta Gate、ActiveConfig实现、Decision流程、Guardian/Worker、Deployment、Shadow、Paper、Live、Funds及Order execution。
- 任何Implementation开始前必须重新绑定并核对Branch、HEAD、AGENTS SHA256、TASK_CONTRACT SHA256、CURRENT_ISSUES SHA256、ak2 SHA256、cd4规范源SHA256/Candidate Hash及IIC2规范源SHA256/Candidate Hash。任一必需身份不匹配即`IMPLEMENTATION_GATE=BLOCKED`；因本次同步会改变两份控制文件，其有效SHA256必须以未来用户签发Implementation授权前的现场只读复算值为准，不得沿用同步前旧值。
- 当前仍为`IMPLEMENTATION_AUTHORIZED=NO`。以上范围是可供用户签发下一次独立授权的候选边界，不构成授权，不得据此创建`strategy_v8/`、写代码、运行测试、执行Git写入、操作数据库或部署。
- 时间窗口冻结为Asia/Shanghai `07:00:00 <= t < 16:00:00`。
- 必须使用Strict AS-OF并防止未来信息污染。
- 正式范围只评价BUY YES；上海、北京、广州从训练、输入、模型、状态、游标、决定、失败到恢复端到端独立。
- 唯一从V3继承的策略公式为：

```text
E_conservative(B,t)
= P_LCB(B | I_t)
- C_executable(B,t)
```

- V3旧模型、旧参数、旧运行架构、旧AS-OF实现、Shadow、Paper及步骤路线均不自动继承。

当前固定顺序为：Architecture Kernel阶段完成→Complete Design独立QA PASS→Implementation Input Closure正式规范→独立QA→Implementation Planning→用户独立授权候选实现→用户独立授权Implementation Test→独立实现完整性审查→用户独立授权Git集成→用户独立授权部署候选→用户独立授权激活与现场验收→FORWARD_STRICT证据积累→三城分别模型资格→独立Shadow设计/授权/验收→独立Paper设计/授权/验收→未来真实交易专项设计/资格/授权。Implementation Input Closure完成仅允许进入Implementation Planning，不自动产生任何实现或后续授权。

阶段门统一采用当前`AGENTS.md`规则：只有`FINDING_VALID=YES`、`CURRENT_STAGE_REQUIRED=YES`且`CURRENT_STAGE_BLOCKER=YES`的Finding才能阻断当前阶段。有效但属于后续阶段的Finding必须保留并延期，不得反向使Architecture Kernel失败。旧规则“第二次Kernel审查存在实施级架构阻断→STOP_REDESIGN”自本次阶段关闭起不再具有当前门禁效力。

Architecture Kernel最终Finding归属为：`TOTAL_FINDINGS=31`、`DEFERRED_COMPLETE_DESIGN=13`、`DEFERRED_IMPLEMENTATION_TEST=4`、`DEFERRED_DEPLOYMENT_ACCEPTANCE=6`、`INVALID_FINDINGS=5`。这些后续Finding必须在各自阶段处理，不得继续作为Kernel blocker。

K3最终架构原则为：`ApprovedConfigSet`是按`config_set_hash`唯一寻址的不可变历史对象；系统只有一个逻辑权威、可变的`ActiveConfigPointer`，Runtime唯一合法选择路径为`ActiveConfigPointer→active_config_set_hash→ApprovedConfigSet`。禁止根据目录顺序、mtime、最新文件或调用者任意hash推断active配置；Pointer缺失、歧义、目标不存在、hash不匹配或身份无法确认时必须`FAIL_CLOSED`。Pointer的Schema、文件格式、原子实现和恢复实现属于后续阶段。

## 3. 当前问题与执行方法

- 当前问题、等待条件和固定顺序以[`CURRENT_ISSUES.md`](CURRENT_ISSUES.md)为准。
- 执行方法、授权、部门协同和停止规则以[`PROJECT_EXECUTION_PROTOCOL.md`](PROJECT_EXECUTION_PROTOCOL.md)为准。
- 当前导航和系统边界分别以[`项目索引.md`](项目索引.md)和[`系统架构.md`](系统架构.md)为准。
- 旧V3契约和历史过程仅保留在Git历史中，不构成当前授权。

## 4. 硬性禁止

未经用户独立授权，不得：

- 创建任何V8/V8.1策略实现，或部署任何新策略实现；
- 恢复V3、AS-OF、Shadow、Paper或旧Dashboard运行路径；
- 修改、回填、重算或改判历史数据库、Evidence、checkpoint、manifest或Seal；
- 启停或重启服务；
- 操作Dashboard、订单、资金、资格或真实交易；
- 处理`backups/`、密钥、环境变量或其他用户资产。

## 5. 阶段分离

```text
需求冻结
!= 架构设计通过
!= 模型设计通过
!= 实现通过
!= 离线验证通过
!= Shadow通过
!= Paper通过
!= 真实交易资格
```

每一阶段必须分别验收并取得用户独立授权。

当前已证明状态：需求冻结=YES；V8/V8.1/R2直接实施充分性=NO；V8.2独立终审=FAIL；R1候选身份=PASS/FROZEN；R1独立终审=FAIL；R1 FAIL后路线决策=COMPLETE；`ak2`候选身份=PASS/FROZEN；Architecture Kernel最终独立QA=`PASS`；`ARCHITECTURE_KERNEL_STAGE_COMPLETE=YES`；`TRUE_KERNEL_BLOCKERS=0`；Complete Design `cd4`独立QA=`PASS`；`COMPLETE_DESIGN_ACCEPTED=YES`；`TRUE_COMPLETE_DESIGN_BLOCKERS=0`；Implementation Input Closure `iic2`最终独立QA=`PASS`；`IMPLEMENTATION_INPUT_CLOSURE_COMPLETE=YES`；`TRUE_IMPLEMENTATION_INPUT_BLOCKERS=0`；`CURRENT_STAGE=IMPLEMENTATION_PLANNING`；`IMPLEMENTATION_PLAN_STATUS=READY`；`IMPLEMENTATION_PLAN_REFERENCE=IMPLEMENTATION_PLAN_V1`；`IMPLEMENTATION_AUTHORIZATION_REQUEST_STATUS=READY`。`IMPLEMENTATION_AUTHORIZED=NO`；`TEST_EXECUTION_AUTHORIZED=NO`；`GIT_WRITE_AUTHORIZED=NO`；`DEPLOYMENT_AUTHORIZED=NO`；`SHADOW_AUTHORIZED=NO`；`PAPER_AUTHORIZED=NO`；`LIVE_TRADING_AUTHORIZED=NO`；实现完成=NO；离线验证=NO；部署=NO；真实交易资格=NO。

## 6. 当前研究进度批次（2026-09-05）

本节是当前阶段状态记录；本文件上方仍保留的`CURRENT_STAGE=IMPLEMENTATION_PLANNING`及首次Foundation授权描述属于先前阶段历史，不再作为当前施工门。它们没有被删除，是为了保留治理血缘。

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_STAGE=WP03_STRATEGY_VALIDATION
CURRENT_WORK_BATCH=T00_RESEARCH_PROGRESS_EXECUTION_AUTHORIZATION_V1
LIMITED_RESEARCH_IMPLEMENTATION=COMPLETED
LOCAL_ENGINEERING_TEST_EXECUTION=COMPLETED
HISTORICAL_EDGE_FEASIBILITY=CLOSED
HISTORICAL_EDGE_SAMPLE_USABLE=NO
WEATHER_PIPELINE_ENGINEERING_PILOT=PASS_RESEARCH_LEVEL
WEATHER_PIPELINE_QA=PASS
FORWARD_EDGE_COLLECTION_ACTIVATION_READY=NO
FULL_E3_AUDIT_COMPLETION=DEFERRED
IMPLEMENTATION_TESTED=NO
IMPLEMENTATION_ACCEPTED=NO
STRATEGY_ENGINE_IMPLEMENTATION_AUTHORIZED=NO
BACKTEST_AUTHORIZED=NO
LIVE_DATA_COLLECTION_START_AUTHORIZED=NO
SERVICE_CHANGE_AUTHORIZED=NO
GIT_WRITE_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
PAPER_AUTHORIZED=NO
LIVE_TRADING_AUTHORIZED=NO
```

本批仅新增Research天气Adapter、相关测试及研究报告。上海`2026-08-22..2026-09-02`共12日全部保留并进入Research天气输入链；独立QA重跑11项限定测试全部通过。该结果不等于严格IIC2数据链、模型执行、预测能力、正Edge、盈利、Strategy Validation验收或生产就绪。

本批授权已在完成报告后终止。继续模型、PAV、P_LCB、Decision、Backtest、前瞻采集启用、服务/配置修改、数据库写入、Git写入、部署、Shadow、Paper、Live、订单或资金操作，均需要新的明确授权。

---

## WP03_STAGE1_WEATHER_MODEL_VALIDATION — governance transition (2026-09-05)

Authority: `T00_TEST_ENV_STANDARDIZATION_AND_STRATEGY_VALIDATION_TRANSITION_V1`.

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_MILESTONE=WP-03_STRATEGY_VALIDATION
CURRENT_PHASE=WP03_STAGE1_WEATHER_MODEL_VALIDATION
CURRENT_WORK_BATCH=T00_TEST_ENV_STANDARDIZATION_AND_STRATEGY_VALIDATION_TRANSITION_V1
TEST_ENVIRONMENT=D:\polymarket天气\.venv-strategy-tests-v1
PYTHON_EXECUTABLE=D:\polymarket天气\.venv-strategy-tests-v1\Scripts\python.exe
TZDATA_INSTALLED=YES
ZONEINFO_ASIA_SHANGHAI=PASS
STRATEGY_ENGINE_SYNTHETIC_TESTS=6/6_PASS
WEATHER_PIPELINE_PILOT_RESULT=PASS_RESEARCH_LEVEL
FORWARD_COLLECTOR_OFFLINE_STATUS=COMPLETE_FOR_RESEARCH_CANDIDATE
IMPLEMENTATION_WORKSPACE_REGRESSION=PASS_9/9
QA_INDEPENDENT_EXECUTION=BLOCKED_BY_QA_SANDBOX_FILESYSTEM_PERMISSION
QA_INDEPENDENT_REPRODUCTION=NOT_ESTABLISHED
UNCONDITIONAL_QA_ACCEPTANCE=NO
MODEL_EXECUTION_AUTHORIZED=NO
BACKTEST_AUTHORIZED=NO
LIVE_CAPTURE_AUTHORIZED=NO
FORWARD_COLLECTION_RUNNING=NO
IMPLEMENTATION_ACCEPTED=NO
```

`COMPLETE_FOR_RESEARCH_CANDIDATE` is limited to the isolated offline Forward Collector candidate: frame persistence, hash, identity, fail-close behavior, FEC-02 full-ladder semantics, and a current-workspace fixture-isolation regression. It does not mean real API compatibility, capture, continuous collection, deployment, long-term retention, production ACL, online runtime, or independent QA reproduction. Do not expand FEC-01..08 into production work under this transition.

The current deliverable is the protocol-only `WP03_STAGE1_WEATHER_MODEL_VALIDATION_PLAN_V1`. No model execution, parameter tuning, Strategy Engine modification, Edge return analysis, profit backtest, PAV final-effect claim, P_LCB coverage claim, or Decision execution is authorized by this record.

---

## Current task — Forward blind accumulation V1 (2026-09-05)

Authority: `T00_FREEZE_WEATHER_CANDIDATE_AND_START_FORWARD_BLIND_ACCUMULATION_V1`. The preceding Stage1 protocol-only restrictions remain historical batch records, not the current authorization for this narrowly scoped forward workflow.

Task objective: freeze the existing exploratory weather candidate and prepare a single bounded daily weather/market research command. Current milestone impact: obtain genuinely new prospective evidence without tuning the model or upgrading exploratory findings to proof. P0/P1 affecting this workflow may block it; production persistence, full IIC2 and E3 hardening remain deferred.

The verified source result is `data/strategy_analysis/wp03_stage1a_research_quantization_exception_rerun_v1/20260905T180807+0800/WP03_STAGE1A_RESEARCH_QUANTIZATION_EXCEPTION_RERUN_REPORT_V1.md`: 25 available mature days, 23 paired scores, zero computation failures, exploratory EARLY_SIGNAL=POSITIVE, not confirmatory skill proof.

Current run: `data/strategy_analysis/wp03_forward_blind_accumulation_v1/20260905T184548+0800/`.

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_PHASE=WP03_FORWARD_WEATHER_BLIND_ACCUMULATION_V1
WEATHER_CANDIDATE_FREEZE=WEATHER_CANDIDATE_FREEZE_V1
RESEARCH_QUANTIZATION_POLICY_ID=STAGE1A_LARGEST_REMAINDER_E12_V1
EARLY_SIGNAL=POSITIVE
EXPLORATORY_SCORING_DAYS=23
FORWARD_BLIND_SCORING_DAYS_AT_ACTIVATION=0
RESEARCH_LIVE_DATA_CAPTURE_AUTHORIZED=YES
RESEARCH_FORWARD_MARKET_COLLECTION_AUTHORIZED=YES
FORWARD_COLLECTION_RUNNING=NO
PERSISTENT_EXECUTION_AVAILABLE=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
IMPLEMENTATION_ACCEPTED=NO
PRODUCTION_READY=NO
```

Outputs: `WEATHER_CANDIDATE_FREEZE_V1.json`, `forward_blind_protocol.json`, `research_quantization_policy.json`, `forward_config.json`, runtime/source identities, focused test evidence and `WP03_FORWARD_BLIND_ACCUMULATION_ACTIVATION_REPORT_V1.md` in this run. Exact daily command and operational limitations are in `FORWARD_DAILY_RUN_COMMAND_V1.md`.

Allowed implementation is only the thin new research daily entry/weather source adapter and their synthetic tests; reuse the original collector store, do not rebuild it. Model/runner/metrics/production collector and original datasets stay unchanged. Source SQLite opens are read-only; all new research outputs and fixtures stay below the declared run. Explicit environment: `.venv-strategy-tests-v1/Scripts/python.exe`, Python 3.12.10, tzdata 2026.3, WORKSPACE_WRITE, `-X utf8 -B`; CWRD and identities must be recorded.

The first possible target is 2026-09-06, conditional on a timely invocation and source availability. No capture for the already-missed 2026-09-05 anchor. A human or separately approved external trigger must invoke the bounded command before 08:00; no persistent scheduler/service/startup integration is authorized here. Predictions are immutable; D+2 labels and scores are separate append-only files. Retain failed/missed days and actual published market membership. Five YES shares and 60 seconds are unchanged. Blind checkpoints 5/10/20/30 are metrics-only; 30+30 remains a future target. No automatic Stage1B, production or trading transition. Stop after the activation report.

## Current multi-city batch closeout — 2026-09-05

Authority: `T00_MULTI_CITY_BEIJING_GUANGZHOU_EXPANSION_AND_FAST_VALIDATION_V1`.
`CURRENT_PHASE=MULTI_CITY_STRATEGY_VALIDATION_V1`; `BATCH_RESULT=PARTIAL_BLOCKED`.
This entry appends the authorized Beijing/ZBAA and Guangzhou/ZGGG expansion without replacing Shanghai history or its frozen V1. Allowed new candidate files are under `tools/research_multi_city_v1/`, `tests/research_multi_city_v1/`, and the independent run `data/strategy_analysis/wp03_multi_city_validation_v1/20260905T194807+0800/`; no Shanghai/model-core/production/IIC2/data-source writes were authorized or performed by this batch.

Implemented candidate scope: city-local residual/baseline adapter, read-only TAF/METAR forward inputs, separate append-only prediction/label/score files, city-specific public-market frame adapter, and an unaccepted concurrent launcher. Runtime remains Python 3.12.10 in `.venv-strategy-tests-v1`, tzdata 2026.3, WORKSPACE_WRITE with explicit project-run CWRD and `-X utf8 -B`.

Actual results: T00 forward adapter regression 8/8 PASS; independent combined unittest run 18 executed, 16 passed, two distinct cases errored (four error events including teardown), exit 1. The two pytest-style population functions were not discovered by unittest and are NOT_RUN, not PASS. Current historical population artifacts remain provisional (42 candidate dates and 24 claimed AVAILABLE per city in the intermediate V1); neither maximum population completeness nor those availability claims is accepted. `CITY_FAST_SIGNAL_EXECUTED=NO`; no real city metrics or generalization result is inferred from synthetic tests.

Four P1 blockers are retained: naive timestamps; missing observation-only candidate dates; missing-label failure omission; undefined launcher `_utc_text` with secondary file-handle cleanup errors. Stop the bounded correction cycle, retain all evidence, do not rerun or activate the candidate. `CROSS_CITY_SIGNAL=INSUFFICIENT_EVIDENCE`; all three blind scoring counts 0; forward/market readiness PARTIAL; collection running NO. No model tuning, market inputs to weather training, PAV/P_LCB/Edge/Decision/profit backtest, capture, service/scheduler changes, trading or Git writes. Final report: `WP03_MULTI_CITY_BEIJING_GUANGZHOU_EXPANSION_REPORT_V1.md` in this run.

## Formal dynamic window alignment — 2026-09-05

Authority: `T00_FORMAL_DYNAMIC_WINDOW_ALIGNMENT_AND_FORWARD_REPAIR_V1`. This is an append-only governance classification, not a rerun or amendment of any historical experiment or frozen candidate.

```text
FORMAL_STRATEGY_WINDOW=[07:00,16:00) Asia/Shanghai
FORMAL_STRATEGY_START=07:00
FORMAL_STRATEGY_END=16:00_EXCLUSIVE
FORMAL_AS_OF=t_ACTUAL_DECISION_TIME
FIXED_RESEARCH_BENCHMARK_ANCHOR=08:00 Asia/Shanghai
FIXED_BENCHMARK_CLASSIFICATION=FIXED_0800_RESEARCH_BENCHMARK_V1
FORMAL_DYNAMIC_OBJECT=FORMAL_DYNAMIC_ASOF_STRATEGY_V1
DYNAMIC_REEVALUATION_TRIGGER=UNRESOLVED_EVENT_TO_WEATHER_EVALUATION_MAPPING
FORMAL_DYNAMIC_FORWARD_READY=NO
REAL_CAPTURE_EXECUTED=NO
FORWARD_COLLECTION_RUNNING=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
PRODUCTION_READY=NO
```

IIC2 `shared_contracts.dynamic_window`, AK2 §2/§7 and the original control window agree on [07:00,16:00). Facts used at t must be visible no later than t, including the formal effective/observed/committed AS-OF predicates; source available/received times must never be bypassed with a later fact. Forecast-revision selection and historical training identity remain city/local-second specific. The fixed 08:00 benchmark cannot replace the full dynamic window or its time-specific training inputs.

AK2 §7 already freezes five event cause types, event identity/deduplication, and 30-second safety rechecks. With no new cause object/state change, such a recheck updates health only: no event, Decision or model call. It is not a model polling cadence. The remaining unresolved mapping is which cause/transition requires weather probability recomputation versus only market-side processing/invalidation; the associated scope window-ID derivation is not mechanically closed. Stop dynamic-runner implementation at this point; do not invent a 1/5/30-minute schedule or reopen frozen IIC2.

Shanghai, Beijing and Guangzhou V1 candidate files, populations, research quantization, predictions and historical results remain unchanged. Their POSITIVE signals (23/22/22 exploratory scoring days) and CONSISTENT_POSITIVE cross-city result belong to FIXED_0800_RESEARCH_BENCHMARK_V1, not confirmation of the whole dynamic strategy. Preserve the 08:00 benchmark for a future separately authorized dynamic comparison; no dynamic value-add is yet measured. Earlier provisional/blocked batch entries above remain historical records, not the latest three-city result.

This batch only aligns governance and repairs the existing benchmark runner's evidence counters and QA environment. Its 07:58-to-08:00 entry is not a formal dynamic strategy entry. No real capture, Decision, Edge, model tuning, production policy change, service, source-DB write or trading is authorized here. Evidence: `data/strategy_analysis/wp03_formal_dynamic_window_alignment_forward_repair_v1/20260905T225723+0800/`; read `time_authority_clarification.json` together with the initial time review, whose AS-OF/deduplication ambiguity claims are explicitly corrected.

<a id="current-execution-state"></a>

## Current-state entry — active goal and preserved completed batches

This is the designated entry to recorded project state, not a standing execution grant. Read it with the user's current explicit instruction. The batch snapshot below remains unchanged evidence of its closeout; a later planning-only or instruction-editing request does not execute that batch, activate an archived plan, or choose a new strategy phase. Update this entry only when a future authorized task actually changes project state; keep older batch records historical.

### T00 context handoff, 2026-09-14

The user explicitly requested a clean new T00 and complete handoff, and selected the saved local project `D:\polymarket天气` rather than a new worktree. New T00: `01a09f75-7008-7323-ac96-faceab293029`; previous T00: `01a076d5-2837-7e82-9c23-c912fcd5712c`. Handoff authority and evidence: `data/reports/T00_HANDOFF_20260914.md` and `data/reports/T00_HANDOFF_20260914_MANIFEST.md`; receiving report: `data/reports/T00_HANDOFF_ACCEPTANCE_20260914.md` (pending actual receipt at this entry's creation).

This task is handoff and read-only acceptance only, not renewed product implementation or runtime activation. The previous T00 ceases product dispatch; existing long-term departments and all unfinished work remain preserved. The September 12 goal record below is historical execution evidence: current September 14 `get_goal` returned `goal=null`, so no active goal object or automatic goal-mode transfer is asserted. The user's formal automatic simulation objective remains incomplete; no strategy stage, qualification, trading, funds, source-service or Git permission is changed by this handoff. Consult the dated handoff receipt for actual acceptance, not merely file existence.

Handoff receipt subsequently received and read back on 2026-09-14: `HANDOFF_ACCEPTED=YES_WITH_DISCLOSED_LIMITATIONS`, report SHA256 `7939ca38381170256f4a3f318af4a3d9f8495b68aab13a3f531d47735ee6af01`. The new T00 verified all 134 listed files: 133 exact matches and the predeclared TASK_CONTRACT handoff insertion, whose removal in memory reproduced the original hash. No unexplained handoff identity difference remains. The original handoff/Manifest are preserved as reviewed input snapshots; their initial pending field and this entry's creation-time pending wording are historical, resolved by this actual receipt. This closeout paragraph is appended after that review and does not modify its input files or certify the unfinished simulation objective. The new T00 is the sole route for future scoped product work; the previous task remains a historical reference.

### Active user goal, 2026-09-12

The user explicitly requested goal-mode execution through completion of the formal dynamic automatic simulation objective, collaborating with existing long-term departments and without repeated approvals for covered actions. Execution scope, current baseline, task budgets, success criteria and exclusions are recorded in `data/reports/goal_formal_simulation_20260912.md`. The goal is ACTIVE, not accepted or running by assertion. Existing business-stage dependencies and frozen strategy rules remain unchanged; engineering preparation is not stage acceptance. Historical closeout stop points below do not constitute the authority for this new task. Live orders/funds, secrets, ACL changes, destructive evidence operations and production/source-service mutations remain outside scope.

### Recorded M1 closeout, 2026-09-06 (completed batch)

Authority: `T00_M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT_V1`. This is the sole current master milestone and supersedes older current-state/authorization entries above, without changing historical reports, candidate freezes, IIC2, AK2 or CD4.

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_MASTER_MILESTONE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
CURRENT_MILESTONE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
CURRENT_PHASE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
FORMAL_STRATEGY_WINDOW=[07:00,16:00) Asia/Shanghai
ASOF_MODE=ACTUAL_DECISION_TIME
EVENT_ACTION_MAPPING_FROZEN=YES
DYNAMIC_REEVALUATION_TRIGGER=EVENT_DRIVEN
PERIODIC_MODEL_RECOMPUTE=NO
FIXED_BENCHMARK=FIXED_0800_RESEARCH_BENCHMARK_V1
SHANGHAI_EARLY_SIGNAL=POSITIVE
BEIJING_EARLY_SIGNAL=POSITIVE
GUANGZHOU_EARLY_SIGNAL=POSITIVE
CROSS_CITY_SIGNAL=CONSISTENT_POSITIVE
EXISTING_EVIDENCE_SUFFICIENT_FOR_M1=NO
STOP_HISTORICAL_DYNAMIC_REPLAY=YES
FORWARD_SOURCEFACT_CAPTURE_REQUIRED=YES
QA_STATUS=PASS_92_OF_92_SYNTHETIC_RELATED_REGRESSION
LEGAL_DYNAMIC_WEATHER_SNAPSHOT_COUNT=0
M1_STATUS=BLOCKED_NEEDS_FORWARD_SOURCEFACT
FORMAL_DYNAMIC_FORWARD_READY=NO
REAL_CAPTURE_EXECUTED=NO
FORWARD_COLLECTION_RUNNING=NO
MODEL_TUNING_AUTHORIZED=NO
RESEARCH_LIVE_DATA_CAPTURE_AUTHORIZED_THIS_BATCH=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
IMPLEMENTATION_ACCEPTED=NO
PRODUCTION_READY=NO
```

The user-fixed master path is M1 first legal dynamic weather snapshot -> M2 weather/market forward -> M3 time alignment/executable Edge -> M4 PAV/P_LCB/risk/Decision Shadow -> M5 forward strategy validation -> M6 production hardening. Only M1 is currently actionable; no automatic M2 entry or network/service/trading authorization follows from QA.

M1 engineering changes: source-specific mandatory effective/observed/committed validation, conditional received/available constraints, distinct WeatherLabel commit/maturity handling; actual evaluator trigger-fact membership/type/city/date/hash/time binding; saved snapshot verification before new events; append-only claim processing and terminal evidence distinguishing completed from interrupted attempts; explicit replay failure classes and actual saved-source snapshot requirement. These passed focused 21-case regression and independent related 92-case QA. They do not prove a real legal SourceFact or snapshot. An initial focused run had 20 passes and one fixture-URI guard environment error; only the test execution wrapper was corrected, and the failed log is retained.

The single bounded evidence review is closed. Existing inspected forecast/raw-payload associations, formal source commit visibility and mature label evidence cannot establish one legal dynamic snapshot; do not continue historical scans/recovery or substitute first_seen/received/mtime/frozen_at for committed time. Preserve all old 08:00 populations/results and the research-only quantization exception. No historical dynamic replay or benchmark rerun was executed in this M1 batch.

Finding routing is now mandatory:
- BLOCK_M1_NOW: absent provable source/revision/commit and mature city-local training evidence.
- FIX_BEFORE_M2: market duplicate-payload metadata identity; WeatherOL and TAF each need a legal source-path proof before their M2 use.
- FIX_BEFORE_BLIND_CONCLUSION: full blind counter scoring eligibility.
- DEFER_TO_PRODUCTION: production ACL/retention/release hardening and full E3.
- DOCUMENT_ONLY: preserved exploratory results and resolved historical failures.

CURRENT_UNIQUE_NEXT_CRITICAL_ACTION=separately authorize the minimum real forward SourceFact capture for M1, including genuine source/observed/commit identities and D+2 training-label evidence. No market capture, Edge, Cost, PAV, P_LCB, Decision, Shadow/Paper/Live, services, orders, wallets/funds, Production or Git writes. The active-observation SHM mtime changed during DATA reads while recorded bytes/SHA remained equal; attribution is unverified and no source SQL write is claimed.

Evidence root: `data/strategy_analysis/wp03_m1_first_legal_dynamic_weather_snapshot_v1/20260906T021642+0800/`; timestamp matrix and bounded review under `data_review/`, independent QA under `qa_review/`, final report `M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT_REPORT_V1.md`. Completed batch; stop.
