"""Explicit environment boundary for supervised research services."""
from __future__ import annotations

import os
from pathlib import Path
import re
from typing import Mapping


SYSTEM_ENVIRONMENT = frozenset({
    "SystemRoot", "WINDIR", "COMSPEC", "PATH", "PATHEXT", "TEMP", "TMP",
    "LOCALAPPDATA", "APPDATA", "PROGRAMDATA", "PROGRAMFILES", "PROGRAMFILES(X86)",
    "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "USERNAME", "USERDOMAIN",
    "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE", "PROCESSOR_IDENTIFIER",
    "SESSIONNAME", "TERM", "LANG", "TZ", "PYTHONUTF8", "PYTHONIOENCODING",
    "SSL_CERT_FILE", "SSL_CERT_DIR", "REQUESTS_CA_BUNDLE", "HTTP_PROXY",
    "HTTPS_PROXY", "NO_PROXY",
})

SERVICE_CONFIGURATION = frozenset({
    "AUTO_SIM_ENABLED", "RUNTIME_TOPOLOGY", "COLLECT_SECONDS",
    "RESEARCH_RETENTION_DAYS", "REACTION_RETENTION_DAYS", "MAX_MARKET_SNAPSHOT_ROWS",
    "MAX_FORECAST_AUDIT_ROWS", "MAX_FORECAST_UPDATE_ROWS", "MAX_FORECAST_RAW_ROWS",
    "MARKET_REQUEST_CONCURRENCY", "MARKET_SCAN_BUDGET_SECONDS",
    "MARKET_PUBLISH_BUDGET_SECONDS", "RESOLUTION_SCAN_BUDGET_SECONDS",
    "FORECAST_PHASE_BUDGET_SECONDS", "COLLECTOR_STARTUP_BUDGET_SECONDS",
    "RESEARCH_MAINTENANCE_INTERVAL_SECONDS", "RESEARCH_MAINTENANCE_BUDGET_SECONDS",
    "RESEARCH_MAINTENANCE_BATCH_ROWS", "DEPTH_SNAPSHOT_SECONDS",
    "RAW_QUOTE_RETENTION_HOURS", "DEPTH_RETENTION_HOURS",
    "MINUTE_BAR_RETENTION_DAYS", "FIVE_MINUTE_BAR_RETENTION_DAYS",
    "MAX_RAW_QUOTE_ROWS", "MAX_DEPTH_ROWS", "MAX_MINUTE_BAR_ROWS",
    "MAX_FIVE_MINUTE_BAR_ROWS",
    "LATEST_PROJECTION_RETENTION_HOURS", "BBO_HEARTBEAT_SECONDS",
    "BBO_PRICE_WRITE_SECONDS", "BBO_SIZE_CHANGE_MIN", "BBO_SIZE_CHANGE_RATIO",
    "BBO_SIZE_WRITE_SECONDS", "PRUNE_BATCH_ROWS", "ROW_CAP_ENFORCE_SECONDS",
    "ROW_CAP_HEADROOM", "MAINTENANCE_BUDGET_SECONDS", "MAINTENANCE_PROGRESS_OPS",
    "MAINTENANCE_RETRY_SECONDS", "DYNAMIC_UNIVERSE_ENABLED", "STATE_HUB_ENABLED",
    "DIRECT_LIVE_BBO_ENABLED", "STATE_HUB_PORT", "STATE_HUB_RECONCILE_SECONDS",
    "STATE_HUB_READ_DEADLINE_SECONDS", "RECEIVE_MAINTENANCE_SECONDS",
    "APP_PING_INTERVAL_SECONDS", "APP_PONG_STALE_SECONDS",
    "EXCHANGE_CLOCK_FUTURE_TOLERANCE_MS",
})

ALLOWED_CHILD_ENVIRONMENT = SYSTEM_ENVIRONMENT | SERVICE_CONFIGURATION | {"PYTHONPATH"}
ALLOWED_CHILD_ENVIRONMENT_CASEFOLD = frozenset(
    key.casefold() for key in ALLOWED_CHILD_ENVIRONMENT
)
DOTENV_KEY = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def _read_simple_dotenv(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return values
    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if DOTENV_KEY.fullmatch(key) is None:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        values[key] = value
    return values


def allowed_runtime_values(dotenv_path: Path | None = None,
                           environ: Mapping[str, str] | None = None) -> dict[str, str]:
    source = dict(os.environ if environ is None else environ)
    values: dict[str, str] = {}
    if dotenv_path is not None and dotenv_path.is_file():
        for key, value in _read_simple_dotenv(dotenv_path).items():
            if key in SERVICE_CONFIGURATION and value is not None:
                values[key] = str(value)
    values.update({key: str(value) for key, value in source.items()
                   if key.casefold() in ALLOWED_CHILD_ENVIRONMENT_CASEFOLD
                   and value is not None})
    return values


def child_environment(*, dotenv_path: Path | None = None,
                      pythonpath: Path | None = None,
                      environ: Mapping[str, str] | None = None) -> dict[str, str]:
    values = allowed_runtime_values(dotenv_path, environ)
    if pythonpath is not None:
        inherited = values.get("PYTHONPATH")
        values["PYTHONPATH"] = str(pythonpath) + (os.pathsep + inherited if inherited else "")
    return values
