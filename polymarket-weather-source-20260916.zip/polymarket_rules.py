"""Versioned Polymarket execution rules used by the local paper broker.

This module is deliberately independent from the quote stream and collectors.
It turns captured market metadata into deterministic validation and fee rules;
it never performs network I/O and cannot place a real order.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any

from execution_evidence import FeeSchedule, LiquidityRole, TradeFee, fee_for_trade


WEATHER_RULES_VERSION = "polymarket-weather-v2-2026-03-30"
DEFAULT_WEATHER_TICK_SIZE = Decimal("0.01")
DEFAULT_WEATHER_MIN_ORDER_SIZE = Decimal("5")
DEFAULT_WEATHER_FEE_SCHEDULE = FeeSchedule(
    version_id=WEATHER_RULES_VERSION,
    platform_rate=Decimal("0.05"),
    platform_taker_only=True,
    maker_builder_bps=0,
    taker_builder_bps=0,
    rounding_quantum=Decimal("0.00001"),
)
SUPPORTED_TIME_IN_FORCE = frozenset({"GTC", "GTD", "FAK", "FOK"})
MAX_BUILDER_MAKER_FEE_BPS = 50
MAX_BUILDER_TAKER_FEE_BPS = 100


class RuleError(ValueError):
    """Raised when an order contradicts captured Polymarket constraints."""


def _decimal(value: Any, name: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise RuleError(f"{name} must be numeric") from exc
    if not result.is_finite():
        raise RuleError(f"{name} must be finite")
    return result


@dataclass(frozen=True)
class MarketTradingRules:
    version_id: str
    tick_size: Decimal
    min_order_size: Decimal
    neg_risk: bool
    fee_schedule: FeeSchedule
    metadata_source: str

    def __post_init__(self) -> None:
        if not self.version_id.strip():
            raise RuleError("rules version_id is required")
        if self.tick_size <= 0 or self.tick_size >= 1:
            raise RuleError("tick_size must be between 0 and 1")
        if self.min_order_size <= 0:
            raise RuleError("min_order_size must be positive")


def _fee_schedule(value: Any) -> FeeSchedule:
    if isinstance(value, FeeSchedule):
        return value
    if value is None:
        return DEFAULT_WEATHER_FEE_SCHEDULE
    if not isinstance(value, dict):
        raise RuleError("fee_schedule must be a FeeSchedule or mapping")
    maker_builder_bps = int(value.get("maker_builder_bps", 0))
    taker_builder_bps = int(value.get("taker_builder_bps", 0))
    if not 0 <= maker_builder_bps <= MAX_BUILDER_MAKER_FEE_BPS:
        raise RuleError(
            f"maker_builder_bps must be between 0 and {MAX_BUILDER_MAKER_FEE_BPS}"
        )
    if not 0 <= taker_builder_bps <= MAX_BUILDER_TAKER_FEE_BPS:
        raise RuleError(
            f"taker_builder_bps must be between 0 and {MAX_BUILDER_TAKER_FEE_BPS}"
        )
    return FeeSchedule(
        version_id=str(value.get("version_id") or value.get("versionId") or "").strip(),
        platform_rate=_decimal(
            value.get("platform_rate", value.get("platformRate")),
            "platform_rate",
        ),
        platform_taker_only=bool(value.get("platform_taker_only", True)),
        maker_builder_bps=maker_builder_bps,
        taker_builder_bps=taker_builder_bps,
        rounding_quantum=_decimal(value.get("rounding_quantum", "0.00001"), "rounding_quantum"),
    )


def rules_for_market(market: dict[str, Any]) -> MarketTradingRules:
    """Resolve captured market rules, with a versioned weather fallback.

    The current research schema does not yet persist CLOB metadata.  Existing
    weather markets therefore use the explicit official-weather baseline.  If
    a caller supplies captured values, those values take precedence and their
    provenance is recorded on the paper order/fill.
    """
    has_metadata = any(
        key in market
        for key in ("tick_size", "tickSize", "min_order_size", "minOrderSize",
                    "neg_risk", "negRisk", "fee_schedule", "feeSchedule")
    )
    tick = _decimal(
        market.get("tick_size", market.get("tickSize", DEFAULT_WEATHER_TICK_SIZE)),
        "tick_size",
    )
    minimum = _decimal(
        market.get("min_order_size", market.get("minOrderSize", DEFAULT_WEATHER_MIN_ORDER_SIZE)),
        "min_order_size",
    )
    neg_risk = bool(market.get("neg_risk", market.get("negRisk", True)))
    schedule = _fee_schedule(market.get("fee_schedule", market.get("feeSchedule")))
    version = str(market.get("rules_version") or schedule.version_id or WEATHER_RULES_VERSION)
    return MarketTradingRules(
        version_id=version,
        tick_size=tick,
        min_order_size=minimum,
        neg_risk=neg_risk,
        fee_schedule=schedule,
        metadata_source="captured_market_metadata" if has_metadata else "official_weather_fallback",
    )


def normalize_time_in_force(order_type: str, value: str | None) -> str:
    result = str(value or ("FAK" if order_type.upper() == "MARKET" else "GTC")).upper()
    if result not in SUPPORTED_TIME_IN_FORCE:
        raise RuleError("time_in_force must be GTC, GTD, FAK, or FOK")
    return result


def validate_order_constraints(
    *,
    side: str,
    order_type: str,
    quantity: float,
    limit_price: float | None,
    time_in_force: str,
    post_only: bool,
    rules: MarketTradingRules,
) -> None:
    normalized_side = side.upper()
    normalized_type = order_type.upper()
    if normalized_side not in {"BUY", "SELL"}:
        raise RuleError("side must be BUY or SELL")
    if normalized_type not in {"LIMIT", "MARKET"}:
        raise RuleError("order_type must be LIMIT or MARKET")
    size = _decimal(quantity, "quantity")
    if size < rules.min_order_size:
        raise RuleError(f"quantity is below market minimum {rules.min_order_size}")
    if normalized_type == "MARKET" and limit_price is not None:
        raise RuleError("market order cannot specify limit_price")
    if normalized_type == "LIMIT":
        if limit_price is None:
            raise RuleError("limit order requires limit_price")
        price = _decimal(limit_price, "limit_price")
        if price < rules.tick_size or price > Decimal("1") - rules.tick_size:
            raise RuleError("limit_price is outside the market tick range")
        if price % rules.tick_size != 0:
            raise RuleError(f"limit_price must align to tick_size {rules.tick_size}")
    if post_only and (normalized_type != "LIMIT" or time_in_force not in {"GTC", "GTD"}):
        raise RuleError("post_only is valid only for GTC/GTD limit orders")


def is_marketable(
    *, side: str, order_type: str, limit_price: float | None,
    best_bid: float | None, best_ask: float | None,
) -> bool:
    if order_type.upper() == "MARKET":
        return (best_ask if side.upper() == "BUY" else best_bid) is not None
    if limit_price is None:
        return False
    if side.upper() == "BUY":
        return best_ask is not None and float(limit_price) + 1e-12 >= float(best_ask)
    return best_bid is not None and float(limit_price) <= float(best_bid) + 1e-12


def fee_for_fill(
    *, shares: float, price: float, role: LiquidityRole | str,
    schedule: FeeSchedule,
) -> TradeFee:
    return fee_for_trade(
        shares=Decimal(str(shares)),
        price=Decimal(str(price)),
        role=role,
        schedule=schedule,
    )
