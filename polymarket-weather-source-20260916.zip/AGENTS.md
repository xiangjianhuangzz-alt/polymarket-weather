# AGENTS.md

## Project purpose

This repository is a weather-market research and decision system for Polymarket-style temperature markets.

Primary goals:

- produce correct, reproducible, time-aware conclusions;
- keep data identity, source, timestamp, and AS-OF boundaries explicit;
- separate research, strategy, implementation, validation, deployment, and trading states;
- prefer the smallest sufficient change over broad refactors;
- stop when the user's success criteria are met instead of continuously expanding scope.

Do not optimize for architectural completeness at the expense of the current task.

## Current-state entry and historical records

For the latest recorded project state, read `TASK_CONTRACT.md#current-execution-state` together with the user's current explicit instruction. `CURRENT_ISSUES.md` records finding details, not a second independent authorization source. A recorded completed batch, an archived plan, or a historical `AUTHORIZED=YES` does not authorize a new task.

This file owns stable agent behavior. Dated batch sections below are preserved historical snapshots; do not execute their old stop/continue instructions or treat their `Current` wording as active authority. Future state updates belong at the designated TASK_CONTRACT entry, with evidence links rather than duplicated full state blocks in every control file. This instruction-only edit does not select a new strategy phase or alter experiment results.

## Historical objective reset (stable priorities retained)

The following records the governance reset; current milestone and task authority are resolved through the current-state entry above:

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_MILESTONE=WP-03_STRATEGY_VALIDATION
```

The governing question is whether the new strategy model has useful predictive skill and positive expected value. Engineering work must directly support answering that question.

Historical reclassification at that reset:

```text
FOUNDATION_IMPLEMENTATION_STATUS=COMPLETED_FOR_STRATEGY_VALIDATION
FOUNDATION_62_CASE_EXECUTION_RESULT=PASS
FULL_E3_AUDIT_COMPLETION=DEFERRED
WP03_IMPLEMENTATION_STARTED=NO
```

`COMPLETED_FOR_STRATEGY_VALIDATION` means the foundation is sufficient to begin planning the strategy-validation experiment. It does not mean production readiness, full E3 completion, deployment acceptance, Paper/Live authorization, or profitability proof.

The incomplete E3 identity, wrapper, transport, payload-recovery, and hash-reconstruction work belongs to `DEFERRED_ENGINEERING_FINDINGS`. It must not block strategy validation unless concrete evidence shows that a specific item materially affects the correctness, reproducibility, or credibility of the strategy experiment.

Project objective priority is:

1. complete the current milestone;
2. establish the smallest verifiable end-to-end loop;
3. obtain experimental feedback quickly;
4. defer production and audit hardening that does not affect the current milestone.

Project objective priority takes precedence over engineering perfection.

---

## Objective alignment and finding classification

Before starting any new task, report:

```text
TASK_OBJECTIVE=
CURRENT_MILESTONE_IMPACT=
BLOCKING_STATUS=
DEFERRED_ALLOWED=
```

The report must answer which project objective the task serves, whether it directly affects the current milestone, whether deferral blocks that objective, and whether it belongs in the deferred queue.

Every finding must be classified before any correction is proposed or performed:

- `P0`: prevents execution of the current-stage objective;
- `P1`: materially undermines the credibility or correctness of the current experiment;
- `P2`: future production, deployment, operational, or audit risk;
- `P3`: engineering optimization or nonessential improvement.

Only `P0` and `P1` may block the current milestone. `P2` and `P3` must be recorded and deferred.

Finding discovery alone does not authorize correction. Check whether the current user instruction already authorizes the affected object, correction, and verification before requesting more approval. The required sequence is:

```text
DISCOVER_FINDING
-> CLASSIFY_FINDING
-> DETERMINE_CURRENT_MILESTONE_IMPACT
-> CHECK_CURRENT_AUTHORIZATION
-> EXECUTE_IF_COVERED_ELSE_DEFER_OR_REQUEST_AUTHORIZATION
```

Do not automatically enter an unbounded repair loop. Explicitly authorized repair and regression steps proceed within their scope, retry limit, and budget without duplicate approval requests.

---

## No autonomous scope expansion

Without current explicit user authorization, agents must not:

- create a new Work Package;
- add an Acceptance Gate;
- raise the required test or evidence standard;
- introduce a new Evidence requirement;
- broaden audit scope;
- change the project objective or milestone;
- convert a deferred item into a current blocker.

If expansion appears necessary, stop and output:

```text
SCOPE_EXPANSION_REQUEST
```

Explain the evidence, impact, minimum proposed expansion, and consequence of deferral, then wait for user approval.

Agents analyze, execute authorized work, and provide recommendations. The human user controls objectives, priorities, scope expansion, and stage transitions. No prior authorization is permanent or transferable to a new task.

---

## Research and production validation levels

During `STRATEGY_VALIDATION`, use the smallest evidence and tests sufficient to make the experiment credible. Simplified tests, fast experiments, and minimum validation are allowed when their limitations are explicit.

The research milestone does not require completion of:

- production-grade audit infrastructure;
- a complete replay system;
- end-to-end institutional evidence reconstruction;
- production deployment validation;
- Paper or Live controls.

Full Evidence, Audit, identity-chain, replay, deployment, and operational acceptance requirements become mandatory only in their applicable future production, Paper, Live, or Deployment stages, or earlier when a concrete `P0`/`P1` link to strategy-validation credibility is demonstrated.

The next milestone, `WP-03_STRATEGY_VALIDATION`, is intended to form the first strategy experiment loop:

```text
data source + model + market state
-> prediction + confidence + decision + backtest result
```

Its primary success criterion is evidence about predictive capability, not codebase completeness. This governance rule does not itself authorize WP-03 implementation, test execution, deployment, Shadow, Paper, Live trading, order execution, or funds operations.

---

## Source of truth

For the current task, use this precedence:

1. the user's latest explicit instruction;
2. current repository control documents that apply to the object being changed;
3. current code, schemas, configuration, and tests;
4. current Git/worktree/runtime evidence;
5. prior thread history, handoffs, or historical notes.

Subject to higher-priority platform instructions, an explicit current user instruction replacing a named project restriction takes effect for the specified task and objects. Record that replacement and proceed without asking the user to approve it again. A generic request to continue or finish does not waive a specific high-risk prohibition. If a material conflict remains unresolved by this precedence, report it and pause only the dependent action; do not silently choose a business interpretation.

### Clarification and routine choices

Ask when uncertainty materially changes business semantics, acceptance criteria, authorization, data/source identity, irreversible results, or external impact. First use safe, in-scope checks when they can resolve it. For low-risk, reversible implementation details that do not change those properties, follow existing project conventions, disclose meaningful assumptions, and continue. Never guess AS-OF times, station identities, model rules, frozen parameters, or funding/trading permissions. Continue already-authorized independent work that does not depend on the unresolved choice.

Historical thread statements are context, not automatically verified current facts.

When relevant, inspect these project control files if they exist:

- `TASK_CONTRACT.md`
- `CURRENT_ISSUES.md`
- `README.md`
- `系统架构.md`
- `项目索引.md`
- the current design/Manifest/audit files referenced by the control documents

Do not assume that the highest version number or newest filename is authoritative without checking the control chain.

---

## Baseline and AS-OF discipline

Before making a material project-state claim, establish the relevant baseline.

For significant design, implementation, integration, or release work, identify as needed:

- branch;
- HEAD;
- working-tree state;
- relevant design/control identity;
- relevant data or runtime identity;
- AS_OF time.

Rules:

- old baselines are historical evidence, not current state;
- current state does not prove that something never happened historically;
- file existence does not prove testing, integration, deployment, or acceptance;
- a passed design review does not imply implementation authorization;
- implementation does not imply testing;
- testing does not imply integration;
- integration does not imply deployment.

Never use vague states such as `DONE`, `TESTED`, or `ACCEPTED` when the object is ambiguous.

Prefer explicit forms such as:

- `DESIGN_ACCEPTED`
- `IMPLEMENTED`
- `IMPLEMENTATION_TESTED`
- `IMPLEMENTATION_INTEGRATED`
- `IMPLEMENTATION_ACCEPTED`
- `DEPLOYED`

---

## Stage boundaries and acceptance gates

Every finding must be evaluated against the current project stage.

A valid issue is not automatically a blocker for the current stage.

Before marking a task, design, or review as failed, determine:

- `CURRENT_STAGE`
- `CURRENT_STAGE_GOAL`
- `CURRENT_STAGE_SUCCESS_CRITERIA`
- `FINDING_VALID`
- `CURRENT_STAGE_REQUIRED`
- `DEFERRED_TO`

A finding may be:

```text
FINDING_VALID=YES
CURRENT_STAGE_REQUIRED=NO
```

In that case, it must not fail the current stage.

Record it as:

```text
DEFERRED_TO=<next appropriate stage>
```

Do not require a previous stage to fully solve work that belongs to a later stage.

Default project stages are:

1. `ARCHITECTURE / KERNEL`

   Freeze architecture-shaping choices and remove ambiguity that could produce incompatible implementations.

2. `COMPLETE_DESIGN`

   Define detailed contracts, schemas, DDL, registries, mappings, payloads, error catalogs, and recovery mechanics.

3. `IMPLEMENTATION_TEST`

   Implement behavior and prove it with tests, fault injection, replay, backtests, or other executable validation.

4. `DEPLOYMENT_ACCEPTANCE`

   Freeze runtime topology, exact entrypoints, ACLs, environment, operational identities, release configuration, and deployment validation.

A stage is complete only when its authorized deliverables and stage-specific evidence requirements are met:

- all decisions required by that stage are sufficiently determined;
- remaining valid findings are assigned to an appropriate later stage;
- no unresolved current-stage blocker remains: architecture/design requires sufficiently closed decisions; implementation requires the specified behavior and tests; experimentation requires actual data and results; deployment requires the authorized runtime acceptance evidence. Decision closure alone is not implementation, experiment, or deployment completion.

A stage is not required to eliminate all future unknowns.

Do not expand current-stage scope merely to make the overall system more complete.

If acceptance criteria require completing work that belongs to a later stage before the current stage can pass, report:

```text
STAGE_GATE_MISALIGNED=YES
```

Propose the smallest gate correction for user review; do not change a frozen acceptance standard yourself. Pause only work dependent on that unresolved gate, not unrelated authorized work.

---

## Gate circularity

Do not create or enforce circular stage gates.

Invalid example:

```text
Complete Design cannot start until Architecture passes,
while Architecture cannot pass until Complete Design details are finished.
```

If such a dependency is detected:

- stop redesign;
- identify the circular dependency;
- propose moving later-stage requirements to their proper stage;
- obtain approval for any change to frozen acceptance criteria before continuing dependent work.

Do not solve a gate-definition problem by adding more design detail.

---

## Long-term role boundaries

When the current thread has an assigned project role, stay inside that role unless the user or T00 explicitly changes the assignment.

### T00 — Orchestrator

Responsible for task decomposition, minimum-necessary routing, conflict handling, and final project-level summaries.

Do not replace specialist work with unsupported conclusions.
Do not treat another thread's self-report as independently verified fact.

### T01 — Governance / workflow

Responsible for project structure, workflow, version/control-chain analysis, handoffs, and design-governance consistency.

Do not implement product code merely to close a governance issue.

### FE — Frontend

Responsible for UI, read-only presentation, interaction, and frontend consumption of backend state.

Do not redefine backend, strategy, risk, or data truth.

### BE — Backend

Responsible for APIs, services, transactions, persistence, and backend implementation.

Do not redefine strategy semantics or independently certify your own implementation.

### DATA — Data / AS-OF / evidence

Responsible for schemas, source identity, normalization, timestamps, AS-OF boundaries, persistence evidence, and data correctness.

Do not change strategy meaning or upgrade your own historical claims to verified facts without evidence.

### STRATEGY — Strategy / model

Responsible for formulas, signals, scoring, decision rules, model semantics, and strategy calculations.

Do not deploy, trade, or alter data provenance.

### RESEARCH — External research

Responsible for current external facts, API/documentation research, and source verification.

External research is evidence input, not automatically project runtime truth.

### RISK — Risk

Responsible for Paper/Live readiness, exposure, position/risk limits, qualification, and risk analysis.

Do not execute trades or move funds merely because a risk check passes.

### QA — Independent validation

Responsible for independent reproduction, tests, regressions, and acceptance evidence.

Do not modify the implementation merely to make a test pass.
Do not certify your own critical output.

### OPS — Runtime / release

Responsible for runtime identity, release readiness, environment, deployment preparation, and operational verification.

Do not change business logic or deploy merely because deployment appears ready.

### SEC — Security / permissions

Responsible for secrets, ACLs, permissions, protected paths, destructive operations, and high-risk external writes.

Do not substitute security review for user authorization.

---

## Routing rules

Use the minimum number of roles needed for the task.

More agents do not automatically improve the result.

Prefer:

- one clear PRIMARY;
- one independent VALIDATOR only when the conclusion materially changes project state;
- CONSULTED roles only when their domain is actually implicated.

Independent work may run in parallel only when:

- the baseline is the same;
- the tasks do not depend on each other's outputs;
- they do not mutate the same object;
- one result cannot change the other's scope.

Stop expanding the route when enough evidence exists to answer the user's current task.

Do not call extra roles merely because they are available.

---

## Evidence rules

For material claims, distinguish:

- claim/context;
- current artifact evidence;
- independently reproduced evidence;
- auditable historical evidence.

At minimum, when the distinction matters, make clear:

- OBJECT;
- STATEMENT;
- BASELINE;
- AS_OF;
- SOURCE/EVIDENCE.

Rules:

- a thread's self-report is not independent validation;
- current repository state cannot prove a historical negative;
- stale evidence must be labeled stale;
- conflicting evidence must be surfaced, not averaged away;
- never claim a test passed unless a relevant test was actually run and its result observed;
- never claim deployment/trading/runtime state solely from code or documentation.

---

## Work method

For each task:

1. Restate the concrete goal internally.
2. Identify the success criterion.
3. Inspect the smallest set of relevant files/evidence.
4. Make the smallest sufficient plan.
5. Perform only the authorized scope.
6. Run the smallest relevant validation.
7. Review the diff or resulting state.
8. Report:
   - what changed;
   - what was validated;
   - what remains unresolved;
   - the single most useful next step, if any.
9. Stop.

Completion means all required deliverables in the current user request, not just a successful internal step. An authorized workflow may include repair, QA, data processing, and reporting; continue its authorized downstream steps when their conditions pass. Preserve explicit user stop points and separate approval gates. Planning-only, diagnosis-only, and review-only requests do not authorize implementation.

Do not continue improving a completed task just because more improvements are possible.

Record non-blocking future ideas as future work instead of implementing them automatically.

---

## Editing rules

- Keep changes scoped to the user's request.
- Do not refactor unrelated code.
- Do not rename/move files without a concrete need.
- Preserve public interfaces unless the task requires changing them.
- Prefer existing project patterns over introducing new frameworks or abstractions.
- Do not create speculative infrastructure for problems that are not currently blocking.
- Do not overwrite evidence or control history merely to make the repository look clean.
- Inspect `git diff` / relevant worktree changes before declaring completion.
- Do not commit, merge, push, or rewrite Git history unless the user explicitly asks for that Git action.

If a requested change spans several domains, use T00 routing instead of silently taking over another role.

---

## Validation

Before a validator marks the current stage as `FAIL`, it must distinguish `FINDING_VALID` from `CURRENT_STAGE_REQUIRED`.

A valid finding assigned to a later stage must be reported and deferred, not used to fail the current stage.

Validation output for material findings should therefore distinguish:

```text
FINDING_VALID=YES/NO
CURRENT_STAGE_REQUIRED=YES/NO
DEFERRED_TO=<stage or NONE>
CURRENT_STAGE_BLOCKER=YES/NO
```

After code changes, run the smallest meaningful checks that cover the changed behavior.

When practical:

- run focused tests first;
- expand to broader regression tests only when warranted;
- report exactly what was run;
- report failures rather than hiding them.

If no suitable test exists, say so.

A validator that checked nothing is not a passing validator.

Do not convert `PARTIAL`, `UNKNOWN`, `TIMEOUT`, `STALE`, or `UNVERIFIED` into `PASS`.

---

## High-risk boundaries

The following require an explicit current-task user instruction before execution:

- Live trading;
- moving or transferring funds;
- real-account orders;
- deployment or service activation with external impact;
- secrets access or rotation;
- ACL/permission changes;
- destructive database or evidence changes;
- irreversible external operations.

Paper trading also requires an explicit task request; do not start it merely because analysis is complete.

For an operation that may have produced an external side effect:

- if the outcome is unknown or ambiguous, do not automatically retry;
- stop and reconcile the actual state first.

A recommendation, validator PASS, or risk PASS is not equivalent to user authorization.

---

## Stop and escalation conditions

Stop and report instead of expanding the task when:

- the authoritative baseline cannot be determined after reasonable, safe, in-scope checks;
- current control documents materially conflict and the source precedence does not resolve the conflict;
- a necessary claim remains stale, conflicting, or unverified after those checks, or further verification requires new authority;
- the requested scope would have to expand materially;
- the action becomes high-risk and explicit authorization is absent;
- a side-effecting operation has an unknown result;
- all required success criteria and deliverables of the current user request have been met.

An unverified fact is initially a reason to investigate safely, not to abandon a verification task. Pause actions dependent on a remaining blocker and finish unaffected authorized work. Never present missing evidence as verified.

If the same blocker reappears without new evidence, do not add more agents or more architecture. Surface the blocker and stop.

---

## Communication

Keep final reports concrete and concise.

Prefer:

- current fact;
- evidence;
- action taken;
- validation result;
- unresolved blocker;
- next step.

Clearly separate:

- current state;
- inference;
- recommendation;
- authorization.

Do not present speculative future work as required work.

---

## TEST_ENVIRONMENT_STANDARD

Before executing tests or programs that create fixtures, caches, logs, or generated artifacts, declare the actual runtime and applicable fields (use the actual non-Python runtime when relevant):

```text
QA_RUNTIME_ROOT=
TEST_ENVIRONMENT=
PYTHON_EXECUTABLE=
PYTHON_VERSION=
WORKSPACE_PERMISSION_MODE=
```

Do not silently depend on the system `TEMP`, user Desktop, user Documents, an unverified cache directory, or another undeclared temporary path. Use the declared Python executable and a declared, verified writable runtime root. Before a file-writing test, verify and record `CREATE`, `WRITE`, `READ`, and `DELETE` against that root.

For ordinary document creation or editing through an editing tool, check the authorized target, overwrite risk, and write permission; Python, dependency setup, and QA fixtures are not prerequisites. A script-generated document records the runtime actually used. This exception grants no additional write scope.

Record the environment identity, dependency identity, exact test command, raw output location, and exit code. Classify an environment, path, dependency, permission, fixture, or OS failure as `TEST_ENVIRONMENT_ISSUE` unless the same failure is reproduced in a verified environment and is shown to be a business-code failure. Do not treat an environment failure as a code defect or a test pass.

## CODEX_WORKSPACE_PERMISSION_RULE

Before a test or write operation, explicitly record the applicable Codex sandbox permission mode: `READ_ONLY`, `WORKSPACE_WRITE`, or `FULL_ACCESS`.

- `READ_ONLY`: do not create files, create fixtures, modify code, or run a test that can write fixtures, caches, logs, or other files. Report `TEST_EXECUTION_BLOCKED_BY_READ_ONLY`.
- `WORKSPACE_WRITE`: the default project standard for authorized project tests and scoped artifacts; write only within current authorized paths.
- `FULL_ACCESS`: not a default requirement. Request it only when the user has separately and explicitly authorized the necessary wider operation.

Environment repair, business-code repair, permission escalation, and test reruns are distinct actions to record, but one explicit user authorization may cover several of them. If the current authorization covers the next action, proceed; completion alone never grants an uncovered action. Dependency installation, protected-path access, source/service changes, and high-risk operations still require their applicable explicit authorization and actual tool approval.

## Historical batch record — forward research authorization, 2026-09-05 (superseded)

Latest authority: `T00_FREEZE_WEATHER_CANDIDATE_AND_START_FORWARD_BLIND_ACCUMULATION_V1`.
This entry supersedes earlier protocol-only/no-research-capture batch states for this specific forward research workflow; it does not reopen production, E3 or trading.

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_PHASE=WP03_FORWARD_WEATHER_BLIND_ACCUMULATION_V1
EARLY_SIGNAL=POSITIVE
WEATHER_CANDIDATE_FREEZE=WEATHER_CANDIDATE_FREEZE_V1
EXPLORATORY_SCORING_DAYS=23
FORWARD_BLIND_SCORING_DAYS_AT_ACTIVATION=0
RESEARCH_LIVE_DATA_CAPTURE_AUTHORIZED=YES
RESEARCH_FORWARD_MARKET_COLLECTION_AUTHORIZED=YES
FORWARD_COLLECTION_RUNNING=NO
PERSISTENT_EXECUTION_AVAILABLE=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
IMPLEMENTATION_ACCEPTED=NO
PRODUCTION_READY=NO
```

Freeze and forward protocol: `data/strategy_analysis/wp03_forward_blind_accumulation_v1/20260905T184548+0800/WEATHER_CANDIDATE_FREEZE_V1.json` and `forward_blind_protocol.json` in the same directory. The original 25-day population, model family, residual formula, features, 08:00 Shanghai anchor, 52 buckets, baseline, expanding mature-prior rule, D+2 labels, Brier SUM and MAE remain frozen. The same `STAGE1A_LARGEST_REMAINDER_E12_V1` is explicitly authorized here for forward research only; original IIC2/production policy and the old Stage1A policy file remain unchanged.

The daily entry is a bounded invocation, not a persistent service. It requires a timely external/manual trigger, the declared Python environment and source availability. No schedule, Windows service or startup item is created. First conditional eligible target is 2026-09-06; never backfill a missed 08:00 prediction or eligible market frame. Preserve failed dates and all expected market members. Save predictions once before labels, then append D+2 labels/scores without re-predicting. The old 23 exploratory scores never count as blind scores. Checkpoints 5/10/20/30 permit metrics inspection only, not tuning; 30+30 remains a future confirmatory target.

Only weather-source reads, public market reads and research-file saves under `data/strategy_analysis/` are authorized. Weather and market inputs remain separated. Market capture means full YES ask ladders for the actual published population; five YES shares is fill quantity, never a five-level truncation. Greater-than-60-second or future frames remain recorded but unavailable. No Edge/Cost/Decision, model tuning, PAV/P_LCB validation, profit backtest, service/DB writes, deployment, Paper/Live trading, orders, positions, wallets, funds, Git writes or backups access. Stop and seal V1 before a separately authorized V2 change; never rewrite V1 results.

## Historical batch record — multi-city research, 2026-09-05 (superseded)

Authority: `T00_MULTI_CITY_BEIJING_GUANGZHOU_EXPANSION_AND_FAST_VALIDATION_V1`.
`CURRENT_PHASE=MULTI_CITY_STRATEGY_VALIDATION_V1`; `BATCH_RESULT=PARTIAL_BLOCKED`.
Shanghai V1 and its historical/forward protocol remain frozen and unchanged. Beijing/ZBAA and Guangzhou/ZGGG use separate TAF/METAR research tracks, never Shanghai residuals or pooled training.

Run: `data/strategy_analysis/wp03_multi_city_validation_v1/20260905T194807+0800/`.
The new historical populations are **PROVISIONAL, NOT_FROZEN**; two-city Fast Signal was not executed. Independent QA found current-stage P1 defects in historical timezone rejection, observation-only candidate-date retention, missing-label failure accounting, and the concurrent launcher's undefined time formatter. The bounded correction cycle stopped; do not treat the candidate as accepted or start its multi-city command. The detailed report records raw test results, including failures and unexecuted population tests.

Shanghai exploratory signal remains POSITIVE with 23 historical scored days; each city's blind scoring count remains 0. `THREE_CITY_FORWARD_READY=PARTIAL`; `THREE_CITY_MARKET_COLLECTION_READY=PARTIAL`; `FORWARD_COLLECTION_RUNNING=NO`. No new capture, scheduler or service was started in this batch. Research-only quantization does not change IIC2 or production policy. Predictive skill, positive Edge, profitability, implementation acceptance and production readiness remain unproven/NO. Stop after this report; further correction requires a newly scoped instruction under the existing execution protocol.

## Historical batch record — formal dynamic window alignment, 2026-09-05 (superseded)

Authority: `T00_FORMAL_DYNAMIC_WINDOW_ALIGNMENT_AND_FORWARD_REPAIR_V1`. This is an append-only governance classification, not a rerun or amendment of any historical experiment or frozen candidate.

```text
FORMAL_STRATEGY_WINDOW=[07:00,16:00) Asia/Shanghai
FORMAL_STRATEGY_START=07:00
FORMAL_STRATEGY_END=16:00_EXCLUSIVE
FORMAL_AS_OF=t_ACTUAL_DECISION_TIME
FIXED_RESEARCH_BENCHMARK_ANCHOR=08:00 Asia/Shanghai
FIXED_BENCHMARK_CLASSIFICATION=FIXED_0800_RESEARCH_BENCHMARK_V1
FORMAL_DYNAMIC_OBJECT=FORMAL_DYNAMIC_ASOF_STRATEGY_V1
DYNAMIC_REEVALUATION_TRIGGER=UNRESOLVED_EVENT_TO_WEATHER_EVALUATION_MAPPING
FORMAL_DYNAMIC_FORWARD_READY=NO
REAL_CAPTURE_EXECUTED=NO
FORWARD_COLLECTION_RUNNING=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
PRODUCTION_READY=NO
```

IIC2 `shared_contracts.dynamic_window`, AK2 §2/§7 and the original control window agree on [07:00,16:00). Facts used at t must be visible no later than t, including the formal effective/observed/committed AS-OF predicates; source available/received times must never be bypassed with a later fact. Forecast-revision selection and historical training identity remain city/local-second specific. The fixed 08:00 benchmark cannot replace the full dynamic window or its time-specific training inputs.

AK2 §7 already freezes five event cause types, event identity/deduplication, and 30-second safety rechecks. With no new cause object/state change, such a recheck updates health only: no event, Decision or model call. It is not a model polling cadence. The remaining unresolved mapping is which cause/transition requires weather probability recomputation versus only market-side processing/invalidation; the associated scope window-ID derivation is not mechanically closed. Stop dynamic-runner implementation at this point; do not invent a 1/5/30-minute schedule or reopen frozen IIC2.

Shanghai, Beijing and Guangzhou V1 candidate files, populations, research quantization, predictions and historical results remain unchanged. Their POSITIVE signals (23/22/22 exploratory scoring days) and CONSISTENT_POSITIVE cross-city result belong to FIXED_0800_RESEARCH_BENCHMARK_V1, not confirmation of the whole dynamic strategy. Preserve the 08:00 benchmark for a future separately authorized dynamic comparison; no dynamic value-add is yet measured. Earlier provisional/blocked batch entries above remain historical records, not the latest three-city result.

This batch only aligns governance and repairs the existing benchmark runner's evidence counters and QA environment. Its 07:58-to-08:00 entry is not a formal dynamic strategy entry. No real capture, Decision, Edge, model tuning, production policy change, service, source-DB write or trading is authorized here. Evidence: `data/strategy_analysis/wp03_formal_dynamic_window_alignment_forward_repair_v1/20260905T225723+0800/`; read `time_authority_clarification.json` together with the initial time review, whose AS-OF/deduplication ambiguity claims are explicitly corrected.

## Historical completed-batch record — M1 closeout, 2026-09-06

Authority: `T00_M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT_V1`. This is the sole current master milestone and supersedes older current-state/authorization entries above, without changing historical reports, candidate freezes, IIC2, AK2 or CD4.

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_MASTER_MILESTONE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
CURRENT_MILESTONE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
CURRENT_PHASE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
FORMAL_STRATEGY_WINDOW=[07:00,16:00) Asia/Shanghai
ASOF_MODE=ACTUAL_DECISION_TIME
EVENT_ACTION_MAPPING_FROZEN=YES
DYNAMIC_REEVALUATION_TRIGGER=EVENT_DRIVEN
PERIODIC_MODEL_RECOMPUTE=NO
FIXED_BENCHMARK=FIXED_0800_RESEARCH_BENCHMARK_V1
SHANGHAI_EARLY_SIGNAL=POSITIVE
BEIJING_EARLY_SIGNAL=POSITIVE
GUANGZHOU_EARLY_SIGNAL=POSITIVE
CROSS_CITY_SIGNAL=CONSISTENT_POSITIVE
EXISTING_EVIDENCE_SUFFICIENT_FOR_M1=NO
STOP_HISTORICAL_DYNAMIC_REPLAY=YES
FORWARD_SOURCEFACT_CAPTURE_REQUIRED=YES
QA_STATUS=PASS_92_OF_92_SYNTHETIC_RELATED_REGRESSION
LEGAL_DYNAMIC_WEATHER_SNAPSHOT_COUNT=0
M1_STATUS=BLOCKED_NEEDS_FORWARD_SOURCEFACT
FORMAL_DYNAMIC_FORWARD_READY=NO
REAL_CAPTURE_EXECUTED=NO
FORWARD_COLLECTION_RUNNING=NO
MODEL_TUNING_AUTHORIZED=NO
RESEARCH_LIVE_DATA_CAPTURE_AUTHORIZED_THIS_BATCH=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
IMPLEMENTATION_ACCEPTED=NO
PRODUCTION_READY=NO
```

The user-fixed master path is M1 first legal dynamic weather snapshot -> M2 weather/market forward -> M3 time alignment/executable Edge -> M4 PAV/P_LCB/risk/Decision Shadow -> M5 forward strategy validation -> M6 production hardening. Only M1 is currently actionable; no automatic M2 entry or network/service/trading authorization follows from QA.

M1 engineering changes: source-specific mandatory effective/observed/committed validation, conditional received/available constraints, distinct WeatherLabel commit/maturity handling; actual evaluator trigger-fact membership/type/city/date/hash/time binding; saved snapshot verification before new events; append-only claim processing and terminal evidence distinguishing completed from interrupted attempts; explicit replay failure classes and actual saved-source snapshot requirement. These passed focused 21-case regression and independent related 92-case QA. They do not prove a real legal SourceFact or snapshot. An initial focused run had 20 passes and one fixture-URI guard environment error; only the test execution wrapper was corrected, and the failed log is retained.

The single bounded evidence review is closed. Existing inspected forecast/raw-payload associations, formal source commit visibility and mature label evidence cannot establish one legal dynamic snapshot; do not continue historical scans/recovery or substitute first_seen/received/mtime/frozen_at for committed time. Preserve all old 08:00 populations/results and the research-only quantization exception. No historical dynamic replay or benchmark rerun was executed in this M1 batch.

Finding routing is now mandatory:
- BLOCK_M1_NOW: absent provable source/revision/commit and mature city-local training evidence.
- FIX_BEFORE_M2: market duplicate-payload metadata identity; WeatherOL and TAF each need a legal source-path proof before their M2 use.
- FIX_BEFORE_BLIND_CONCLUSION: full blind counter scoring eligibility.
- DEFER_TO_PRODUCTION: production ACL/retention/release hardening and full E3.
- DOCUMENT_ONLY: preserved exploratory results and resolved historical failures.

CURRENT_UNIQUE_NEXT_CRITICAL_ACTION=separately authorize the minimum real forward SourceFact capture for M1, including genuine source/observed/commit identities and D+2 training-label evidence. No market capture, Edge, Cost, PAV, P_LCB, Decision, Shadow/Paper/Live, services, orders, wallets/funds, Production or Git writes. The active-observation SHM mtime changed during DATA reads while recorded bytes/SHA remained equal; attribution is unverified and no source SQL write is claimed.

Evidence root: `data/strategy_analysis/wp03_m1_first_legal_dynamic_weather_snapshot_v1/20260906T021642+0800/`; timestamp matrix and bounded review under `data_review/`, independent QA under `qa_review/`, final report `M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT_REPORT_V1.md`. Completed batch; stop.
