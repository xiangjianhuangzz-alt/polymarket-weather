# T00｜V8 Architecture Kernel唯一一次受限修订任务合同｜2026-09-02

状态：`COMPLETED_AK2_CANDIDATE_FROZEN_AWAITING_SECOND_INDEPENDENT_AUDIT_AUTHORIZATION`

```text
TASK_ID=PWM-V8-AK-R1-001
PARENT_CANDIDATE_ID=T00-weather-strategy-architecture-kernel/ak1
TARGET_CANDIDATE_ID=T00-weather-strategy-architecture-kernel/ak2
BASELINE_BRANCH=codex/handoff-baseline-20260809
BASELINE_HEAD=13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
AS_OF_DATE=2026-09-02
TIMEZONE=Asia/Shanghai
AUTHORIZATION_SOURCE=用户于2026-09-02明确确认唯一一次受限Kernel修订
```

性质：第一次Architecture Kernel独立审查FAIL后的唯一一次受限设计修订；不是第二次独立审查、完整V8替代设计、实现、测试、Git、部署、激活、Shadow、Paper或交易授权。

## 1. 问题和目标

首次Kernel候选身份有效，但独立审查判定：B01、B02、B09—B15及N01—N06未闭合。唯一目标是在不修改`ak1`冻结证据的前提下，把重叠发现合并成九个根问题，在一个新`ak2`候选中给出唯一规范对象、算法、状态转换、失败行为和反例。

本任务不重新讨论已通过的B03—B08，也不扩展为完整文件、模块、类、函数、DDL、Windows XML或部署实现。

## 2. 冻结输入

| 对象 | SHA256 |
|---|---|
| `T00_V8_ArchitectureKernel任务合同_2026-09-02.md` | `6739d6eec891679d084042b3f683d93605f0e12a95d338a401b94b2c350e208e` |
| `T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md` | `b0ccc9d82e8c8bfec06836abaf6914a4c4c7fbcf932a59fb9ce54140d7485988` |
| `T00_新动态策略ArchitectureKernel设计自检_2026-09-02.md` | `c408415a01c362525e285af25ca4942a239a842da4544422ef7da3e992b06ab5` |
| `T00_新动态策略ArchitectureKernel设计Manifest_2026-09-02.md` | `f2b64b5b1f2cc851e69592ea475ade3a2106f46bfbbe8efd5bafb92bb14be829` |
| `T01_新动态策略ArchitectureKernel独立审查_2026-09-02.md` | `df01190520cf687758b78e1082671d7d2e5eb855e210307b035ecf12963eea45` |

同时继承：当前五份控制文档、`PROJECT_EXECUTION_PROTOCOL.md`、`AGENTS.md`、新策略设计输入基线和V3唯一公式归档。旧V8/V8.1/R2/V8.2/R1只作为历史与反例来源。

## 3. 九个必须关闭的根问题

```text
R01 Canonical Registry封闭实例、唯一owner、规范payload和机器冲突拒绝
R02 三城Qualification一致批准快照、单文件提交、持久化和恢复身份
R03 M007的统计对象、符号、分组、cluster bootstrap、阈值语义和失败反例
R04 Runtime事实ID、effective_at、跨重启去重、事件链水位和family提交点
R05 唯一当前候选关系、Decision/Invalidation/slot事务和确定性恢复
R06 ErrorCode→exit code→retryable→health→Guardian action封闭函数
R07 Guardian/Worker owner、child identity、spawn attempt、lease和崩溃恢复
R08 ACL/DB精确目标全集、父子关系和计数
R09 HALF_OPEN、health、PathPolicy、事务和恢复状态机
```

N01—N06必须并入R01—R09，不得形成第二套补丁清单。

## 4. 必须保留的不变量

1. 单bucket BUY YES；
2. `E_conservative(B,t)=P_LCB(B|I_t)-C_executable(B,t)`；
3. 市场价格只进入可执行成本；
4. Asia/Shanghai `07:00:00 <= t < 16:00:00`实时动态，不采用整点锚；
5. Strict AS-OF，后到事实不回写过去；
6. 上海、北京、广州从Evidence、训练、模型、资格、Runtime到恢复完全独立；
7. 上海`weatherol_shanghai/weatherol_d0`与ZSPD，北京/广州TAF与ZBAA/ZGGG；
8. 无订单、钱包、资金、Shadow、Paper或真实交易能力；
9. 设计、实现、测试、Git、部署、激活和交易资格分别授权。

## 5. 最小必要岗位

| 岗位 | 角色 | 只处理 |
|---|---|---|
| T00 | PRIMARY/INTEGRATOR | 任务边界、R01 Canonical、跨域冲突、唯一候选整合与冻结 |
| DATA | CONSULTED | R02、R04、R05中的Evidence/AS-OF/事件身份/恢复事实 |
| STRATEGY | CONSULTED | R03 M007及统计资格语义 |
| BE | CONSULTED | R02、R05、R06的SQLite事务、当前候选和CLI闭包 |
| OPS | CONSULTED | R07—R09的进程身份、ACL目标和恢复状态机 |
| T01 | EXCLUDED_FROM_REVISION | 保持第二次审查独立性；冻结前不得参与写作或修改 |

各咨询岗位只返回设计输入，不修改项目文件、不产生组织PASS。T00不得照抄互相矛盾的建议，必须裁决为一个规范。

## 6. 唯一交付物

```text
T00_V8_ArchitectureKernel受限修订任务合同_2026-09-02.md
T00_新动态策略ArchitectureKernel设计候选_ak2_2026-09-02.md
T00_新动态策略ArchitectureKernel设计自检_ak2_2026-09-02.md
T00_新动态策略ArchitectureKernel设计Manifest_ak2_2026-09-02.md
```

Manifest只绑定前三个成员，不绑定自身。首次`ak1`及其审查报告不得成为`ak2`规范成员，只作为带hash的parent/source identity。

## 7. 成功标准

- R01—R09各自只有一个规范来源、唯一算法或状态转换、明确失败状态和至少一个恶意反例；
- B03—B08已收敛规则被显式继承且不重新定义出第二版本；
- 任何同一输入在重启、重放、崩溃或不同实现者手中都不能产生两个合法结果；
- M007不依靠概率范围恒真，不把保守性、技能和资格混成一个指标；
- 当前候选、进程、事件、批准和恢复均有稳定身份；
- 作者自检不得冒充独立审查；
- 新候选和三成员hash进入新Manifest。

## 8. 禁止范围

- 不修改或重命名`ak1`四件套及其独立审查报告；
- 不修改旧V8/V8.1/R2/V8.2/R1冻结文件；
- 不创建完整替代设计或`strategy_v8/`；
- 不运行实现测试或创建Schema/DDL/Python/XML/ACL实现；
- 不修改五份控制文档；
- 不进行Git写入、数据库/Evidence/配置/任务/ACL/网络/服务操作；
- 不读取或处理`backups/`；
- 不启动第二次Kernel独立审查。

## 9. 硬停止

四份交付物冻结后必须停止：

```text
AK1=FROZEN_FAIL_EVIDENCE
AK2_CANDIDATE_FROZEN=YES
AK2_AUTHOR_SELFCHECK=PASS_OR_FAIL
AK2_INDEPENDENT_AUDIT=NOT_AUTHORIZED/NOT_RUN
COMPLETE_V8_DESIGN=NO
IMPLEMENTATION/GIT/DEPLOYMENT=NO
```

只有用户再次独立授权，T01才可进行第二次Kernel审查。第二次仍有实施级架构阻断时必须`STOP_REDESIGN`，不得创建`ak3`。
