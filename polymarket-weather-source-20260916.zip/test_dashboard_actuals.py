from __future__ import annotations

import hashlib
import shutil
import sqlite3
import tempfile
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

import dashboard_modern
from dashboard_modern import Api
from metar_collector import STATIONS as METAR_STATIONS


EXPECTED = (
    ("Beijing", "北京", "ZBAA", "risk_exclusion"),
    ("Shanghai", "上海", "ZSPD", "risk_exclusion"),
    ("Chengdu", "成都", "ZUUU", "risk_exclusion"),
    ("Guangzhou", "广州", "ZGGG", "risk_exclusion"),
    ("Shenzhen", "深圳", "ZGSZ", "research_only"),
    ("Wuhan", "武汉", "ZHHH", "research_only"),
    ("Chongqing", "重庆", "ZUCK", "research_only"),
    ("Jinan", "济南", "ZSJN", "research_only"),
    ("Qingdao", "青岛", "ZSQD", "research_only"),
    ("Zhengzhou", "郑州", "ZHCC", "research_only"),
)
ACTIVE_EXPECTED = EXPECTED[:7]


class DashboardActualSnapshotTests(unittest.TestCase):
    FACT_FIELDS = (
        "temperature_c", "report_time", "read_time", "age_minutes",
        "report_type", "conditions", "wind_mps", "visibility_km", "today_high",
    )

    def setUp(self) -> None:
        self.folder = tempfile.TemporaryDirectory()
        self.database = Path(self.folder.name) / "observations.sqlite3"
        db = sqlite3.connect(self.database)
        db.execute("""CREATE TABLE metar_observations (
          observation_id INTEGER PRIMARY KEY AUTOINCREMENT,
          station TEXT NOT NULL, city TEXT NOT NULL, decision_scope TEXT NOT NULL,
          report_time TEXT NOT NULL, received_at TEXT NOT NULL,
          report_type TEXT NOT NULL, temperature_c REAL,
          wind_mps REAL, visibility_km REAL, conditions TEXT,
          raw_observation TEXT NOT NULL, raw_hash TEXT NOT NULL,
          source TEXT NOT NULL DEFAULT 'aviationweather_metar'
        )""")
        db.execute("""CREATE TABLE metar_live_status (
          station TEXT PRIMARY KEY, city TEXT NOT NULL, decision_scope TEXT NOT NULL,
          last_attempt_at TEXT NOT NULL, last_success_at TEXT,
          last_report_at TEXT, last_report_temperature_c REAL,
          state TEXT NOT NULL, detail TEXT, updated_at TEXT NOT NULL
        )""")
        self.now = datetime(2026, 8, 12, 11, 0, tzinfo=UTC)
        now = self.now
        report_at = (now - timedelta(minutes=10)).isoformat()
        received_at = (now - timedelta(minutes=9)).isoformat()
        for index, (city, _label, station, scope) in enumerate(EXPECTED):
            state = "delayed" if station == "ZSJN" else "healthy"
            db.execute(
                """INSERT INTO metar_observations
                   (station,city,decision_scope,report_time,received_at,report_type,
                    temperature_c,wind_mps,visibility_km,conditions,raw_observation,raw_hash)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (station, city, scope, report_at, received_at, "METAR",
                 20 + index, 2.0, 10.0, "CAVOK", f"METAR {station}", f"hash-{station}"),
            )
            db.execute(
                """INSERT INTO metar_live_status
                   (station,city,decision_scope,last_attempt_at,last_success_at,last_report_at,
                    last_report_temperature_c,state,detail,updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (station, city, scope, received_at, received_at, report_at,
                 20 + index, state, f"station={station}", received_at),
            )
        db.execute(
            """INSERT INTO metar_live_status
               (station,city,decision_scope,last_attempt_at,state,detail,updated_at)
               VALUES ('XXXX','Unknown','research_only',?,'healthy','must not leak',?)""",
            (received_at, received_at),
        )
        db.execute(
            """INSERT INTO metar_observations
               (station,city,decision_scope,report_time,received_at,report_type,
                temperature_c,wind_mps,visibility_km,conditions,raw_observation,raw_hash)
               VALUES ('XXXX','Unknown','research_only',?,?,'METAR',99,9,9,
                       'MUST NOT LEAK','METAR XXXX','hash-unknown')""",
            (report_at, received_at),
        )
        db.commit()
        db.close()

    def tearDown(self) -> None:
        self.folder.cleanup()

    def snapshot(self) -> list[dict]:
        with patch.object(dashboard_modern, "OBSERVATIONS_DB", self.database), \
             patch.object(dashboard_modern, "china_now", return_value=self.now):
            return Api().actual_snapshot()

    def snapshot_database(self, database: Path) -> list[dict]:
        before = hashlib.sha256(database.read_bytes()).hexdigest()
        with patch.object(dashboard_modern, "OBSERVATIONS_DB", database), \
             patch.object(dashboard_modern, "china_now", return_value=self.now):
            rows = Api().actual_snapshot()
        self.assertEqual(before, hashlib.sha256(database.read_bytes()).hexdigest())
        return rows

    def case_database(self, slug: str) -> Path:
        database = Path(self.folder.name) / f"case_{slug}.sqlite3"
        shutil.copy2(self.database, database)
        return database

    def replace_observations_with_untyped_copy(self, database: Path) -> sqlite3.Connection:
        db = sqlite3.connect(database)
        db.execute("ALTER TABLE metar_observations RENAME TO typed_observations")
        db.execute("""CREATE TABLE metar_observations (
          station,city,decision_scope,report_time,received_at,report_type,
          temperature_c,wind_mps,visibility_km,conditions)""")
        db.execute("""INSERT INTO metar_observations
          SELECT station,city,decision_scope,report_time,received_at,report_type,
                 temperature_c,wind_mps,visibility_km,conditions FROM typed_observations""")
        return db

    def assert_unavailable_without_facts(self, row: dict, detail: str | None = None) -> None:
        self.assertEqual(row["state"], "unavailable")
        self.assertFalse(row["available"])
        if detail is not None:
            self.assertEqual(row["detail"], detail)
        for field in self.FACT_FIELDS:
            self.assertIsNone(row[field], field)
        self.assertEqual(row["points"], [])

    def assert_query_unavailable(self, rows: list[dict]) -> None:
        self.assertEqual(len(rows), 10)
        for row in rows:
            self.assert_unavailable_without_facts(row, "metar_query_unavailable")

    def test_returns_exact_fixed_ten_city_matrix_with_new_station_facts(self) -> None:
        rows = self.snapshot()
        self.assertEqual(
            [(row["city"], row["city_cn"], row["station"], row["scope"]) for row in rows],
            list(EXPECTED),
        )
        self.assertEqual(len(rows), 10)
        self.assertNotIn("XXXX", {row["station"] for row in rows})
        for index, row in enumerate(rows):
            with self.subTest(city=row["city"]):
                self.assertEqual(row["decision_scope"], EXPECTED[index][3])
                self.assertEqual(row["scope"], row["decision_scope"])
                self.assertNotIn("city_scope", row)
                self.assertTrue(row["available"])
                self.assertEqual(row["temperature_c"], 20 + index)
        self.assertEqual(rows[7]["state"], "delayed")

    def test_dashboard_matrix_is_independent_but_matches_metar_authority(self) -> None:
        dashboard_matrix = {
            item["station"]: {"city": item["city"], "scope": item["decision_scope"]}
            for item in dashboard_modern.ACTIVE_METAR_ACTUAL_CITIES
        }
        self.assertEqual(dashboard_matrix, METAR_STATIONS)
        self.assertNotEqual(
            [item["decision_scope"] for item in dashboard_modern.METAR_ACTUAL_CITIES[:4]],
            [item["city_scope"] for item in dashboard_modern.D0_V2_CITIES[:4]],
        )

    def test_missing_station_is_an_unavailable_placeholder_without_cross_station_data(self) -> None:
        db = sqlite3.connect(self.database)
        db.execute("DELETE FROM metar_observations WHERE station='ZSJN'")
        db.execute("DELETE FROM metar_live_status WHERE station='ZSJN'")
        db.commit()
        db.close()

        rows = self.snapshot()
        self.assertEqual(len(rows), 10)
        jinan = rows[7]
        self.assertEqual((jinan["city"], jinan["station"], jinan["scope"]),
                         ("Jinan", "ZSJN", "research_only"))
        self.assertFalse(jinan["available"])
        self.assertIsNone(jinan["temperature_c"])
        self.assertEqual(jinan["points"], [])

    def test_city_or_scope_mismatch_is_not_attributed_to_a_fixed_city_slot(self) -> None:
        db = sqlite3.connect(self.database)
        db.execute("UPDATE metar_observations SET city='Beijing' WHERE station='ZHHH'")
        db.execute("UPDATE metar_live_status SET decision_scope='risk_exclusion' WHERE station='ZHCC'")
        db.commit()
        db.close()

        rows = self.snapshot()
        wuhan = rows[5]
        zhengzhou = rows[9]
        self.assertFalse(wuhan["available"])
        for field in ("temperature_c", "report_time", "read_time", "age_minutes",
                      "report_type", "conditions", "wind_mps", "visibility_km",
                      "today_high"):
            self.assertIsNone(wuhan[field], field)
        self.assertEqual(wuhan["points"], [])
        self.assertFalse(zhengzhou["available"])
        for field in ("temperature_c", "report_time", "read_time", "age_minutes",
                      "report_type", "conditions", "wind_mps", "visibility_km",
                      "today_high"):
            self.assertIsNone(zhengzhou[field], field)
        self.assertEqual(zhengzhou["points"], [])

        for index, row in enumerate(rows):
            if index not in {5, 9}:
                self.assertTrue(row["available"], row["city"])
                self.assertEqual(row["temperature_c"], 20 + index)

    def test_unavailable_or_incomplete_station_clears_observation_facts_locally(self) -> None:
        db = sqlite3.connect(self.database)
        db.execute("UPDATE metar_live_status SET state='unavailable' WHERE station='ZSJN'")
        db.execute("DELETE FROM metar_live_status WHERE station='ZHCC'")
        db.execute("DELETE FROM metar_observations WHERE station='ZUCK'")
        db.commit()
        db.close()

        rows = self.snapshot()
        affected = {"Chongqing", "Jinan", "Zhengzhou"}
        fact_fields = (
            "temperature_c", "report_time", "read_time", "age_minutes",
            "report_type", "conditions", "wind_mps", "visibility_km", "today_high",
        )
        for index, row in enumerate(rows):
            with self.subTest(city=row["city"]):
                if row["city"] in affected:
                    self.assertFalse(row["available"])
                    for field in fact_fields:
                        self.assertIsNone(row[field], field)
                    self.assertEqual(row["points"], [])
                else:
                    self.assertTrue(row["available"])
                    self.assertEqual(row["temperature_c"], 20 + index)

    def test_unknown_status_fails_closed_without_affecting_other_stations(self) -> None:
        db = sqlite3.connect(self.database)
        db.execute("UPDATE metar_live_status SET state='corrupt_state' WHERE station='ZSJN'")
        db.commit()
        db.close()

        rows = self.snapshot()
        jinan = rows[7]
        self.assertEqual(jinan["state"], "unavailable")
        self.assertEqual(jinan["detail"], "metar_record_invalid")
        self.assertFalse(jinan["available"])
        for field in ("temperature_c", "report_time", "read_time", "age_minutes",
                      "report_type", "conditions", "wind_mps", "visibility_km",
                      "today_high"):
            self.assertIsNone(jinan[field], field)
        self.assertEqual(jinan["points"], [])
        for index, row in enumerate(rows):
            if index != 7:
                self.assertTrue(row["available"], row["city"])
                self.assertEqual(row["temperature_c"], 20 + index)

    def test_invalid_status_structure_fails_closed_locally(self) -> None:
        cases = (
            ("station", " ZSJN"), ("city", " Jinan"),
            ("decision_scope", " research_only"), ("state", 7), ("detail", 7),
        )
        for column, value in cases:
            with self.subTest(column=column, value=value):
                database = self.case_database(f"status_{column}")
                db = sqlite3.connect(database)
                db.execute("ALTER TABLE metar_live_status RENAME TO typed_status")
                db.execute("CREATE TABLE metar_live_status (station,city,decision_scope,state,detail)")
                db.execute("INSERT INTO metar_live_status SELECT station,city,decision_scope,state,detail FROM typed_status")
                db.execute(f"UPDATE metar_live_status SET {column}=? WHERE station='ZSJN'", (value,))
                db.commit()
                db.close()
                rows = self.snapshot_database(database)
                self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_invalid_observation_identity_strings_fail_closed_locally(self) -> None:
        cases = (("station", " ZSJN"), ("city", " Jinan"),
                 ("decision_scope", " research_only"))
        for column, value in cases:
            with self.subTest(column=column):
                database = self.case_database(f"identity_{column}")
                db = self.replace_observations_with_untyped_copy(database)
                db.execute(f"UPDATE metar_observations SET {column}=? WHERE station='ZSJN'", (value,))
                db.commit()
                db.close()
                rows = self.snapshot_database(database)
                self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_missing_required_status_columns_fail_closed_for_all_ten_slots(self) -> None:
        required = ("station", "city", "decision_scope", "state")
        declarations = {
            "station": "station TEXT", "city": "city TEXT",
            "decision_scope": "decision_scope TEXT", "state": "state TEXT",
            "detail": "detail TEXT",
        }
        for missing in required:
            with self.subTest(missing=missing):
                database = Path(self.folder.name) / f"status_missing_{missing}.sqlite3"
                db = sqlite3.connect(database)
                columns = ",".join(declarations[name] for name in declarations if name != missing)
                db.execute(f"CREATE TABLE metar_live_status ({columns})")
                db.execute("""CREATE TABLE metar_observations (
                  station TEXT,city TEXT,decision_scope TEXT,report_time TEXT,received_at TEXT,
                  report_type TEXT,temperature_c REAL,wind_mps REAL,visibility_km REAL,conditions TEXT)""")
                db.commit()
                db.close()
                before = hashlib.sha256(database.read_bytes()).hexdigest()
                self.assert_query_unavailable(self.snapshot_database(database))
                self.assertEqual(before, hashlib.sha256(database.read_bytes()).hexdigest())
                database.rename(database.with_suffix(".closed"))

    def test_missing_required_observation_columns_fail_closed_for_all_ten_slots(self) -> None:
        for missing in ("temperature_c", "report_time", "received_at"):
            with self.subTest(missing=missing):
                database = Path(self.folder.name) / f"observation_missing_{missing}.sqlite3"
                db = sqlite3.connect(database)
                db.execute("CREATE TABLE metar_live_status (station TEXT,city TEXT,decision_scope TEXT,state TEXT,detail TEXT)")
                declarations = {
                    "station": "station TEXT", "city": "city TEXT", "decision_scope": "decision_scope TEXT",
                    "report_time": "report_time TEXT", "received_at": "received_at TEXT",
                    "report_type": "report_type TEXT", "temperature_c": "temperature_c REAL",
                    "wind_mps": "wind_mps REAL", "visibility_km": "visibility_km REAL",
                    "conditions": "conditions TEXT",
                }
                columns = ",".join(declarations[name] for name in declarations if name != missing)
                db.execute(f"CREATE TABLE metar_observations ({columns})")
                db.commit()
                db.close()
                before = hashlib.sha256(database.read_bytes()).hexdigest()
                self.assert_query_unavailable(self.snapshot_database(database))
                self.assertEqual(before, hashlib.sha256(database.read_bytes()).hexdigest())
                database.rename(database.with_suffix(".closed"))

    def test_invalid_times_fail_closed_only_for_known_station(self) -> None:
        invalid_values = (42, None, "", "   ", "not-a-date", "2026-02-30T01:00:00+00:00",
                          "2026-08-12T10:50:00")
        for column in ("report_time", "received_at"):
            for value in invalid_values:
                with self.subTest(column=column, value=value):
                    database = self.case_database(f"time_{column}_{len(str(value))}_{type(value).__name__}")
                    db = self.replace_observations_with_untyped_copy(database)
                    db.execute(f"UPDATE metar_observations SET {column}=? WHERE station='ZSJN'", (value,))
                    db.commit()
                    db.close()
                    rows = self.snapshot_database(database)
                    self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                    self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))
                    database.unlink()

    def test_historical_and_future_bad_rows_do_not_close_today(self) -> None:
        offsets = (-5, -1, 1)
        for days in offsets:
            with self.subTest(days=days):
                database = self.case_database(f"date_isolation_{days}")
                db = sqlite3.connect(database)
                stamp = (self.now + timedelta(days=days)).isoformat()
                db.execute("""INSERT INTO metar_observations
                  (station,city,decision_scope,report_time,received_at,report_type,
                   temperature_c,wind_mps,visibility_km,conditions,raw_observation,raw_hash)
                  VALUES ('ZSJN','Wrong City','research_only',?,?,'METAR',99,2,10,'CAVOK','bad','bad')""",
                           (stamp, stamp))
                db.commit()
                db.close()
                rows = self.snapshot_database(database)
                self.assertTrue(rows[7]["available"])
                self.assertEqual(rows[7]["temperature_c"], 27)
                self.assertTrue(all(row["available"] for row in rows))

    def test_today_bad_row_closes_only_its_station(self) -> None:
        database = self.case_database("today_bad")
        db = sqlite3.connect(database)
        stamp = (self.now - timedelta(minutes=5)).isoformat()
        db.execute("""INSERT INTO metar_observations
          (station,city,decision_scope,report_time,received_at,report_type,
           temperature_c,wind_mps,visibility_km,conditions,raw_observation,raw_hash)
          VALUES ('ZSJN','Wrong City','research_only',?,?,'METAR',99,2,10,'CAVOK','bad','bad')""",
                   (stamp, stamp))
        db.commit()
        db.close()
        rows = self.snapshot_database(database)
        self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
        self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_either_today_time_selects_bad_record_for_validation(self) -> None:
        cases = (("report_time", "not-a-date", (self.now - timedelta(minutes=5)).isoformat()),
                 ("received_at", "not-a-date", (self.now - timedelta(minutes=5)).isoformat()))
        for bad_column, bad_value, good_value in cases:
            with self.subTest(bad_column=bad_column):
                database = self.case_database(f"or_query_{bad_column}")
                db = self.replace_observations_with_untyped_copy(database)
                other = "received_at" if bad_column == "report_time" else "report_time"
                db.execute(f"UPDATE metar_observations SET {bad_column}=?,{other}=? WHERE station='ZSJN'",
                           (bad_value, good_value))
                db.commit()
                db.close()
                rows = self.snapshot_database(database)
                self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_unprovable_times_are_not_today_facts(self) -> None:
        database = self.case_database("unprovable_times")
        db = self.replace_observations_with_untyped_copy(database)
        db.execute("UPDATE metar_observations SET report_time='bad',received_at='also bad' WHERE station='ZSJN'")
        db.commit()
        db.close()
        rows = self.snapshot_database(database)
        self.assert_unavailable_without_facts(rows[7], "metar_observation_unavailable")
        self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_time_helper_normalizes_utc_and_never_overflows_china_conversion(self) -> None:
        for value in ("0001-01-01T00:00:00+23:59", "9999-12-31T23:59:59-23:59"):
            with self.subTest(value=value):
                self.assertIsNone(Api._metar_iso_time(value))
        expected = (
            ("2026-08-12T10:00:00Z", "2026-08-12 18:00:00"),
            ("2026-08-12T10:00:00+00:00", "2026-08-12 18:00:00"),
            ("2026-08-12T12:00:00+02:00", "2026-08-12 18:00:00"),
        )
        for value, china in expected:
            with self.subTest(value=value):
                stamp = Api._metar_iso_time(value)
                self.assertEqual(stamp.tzinfo, UTC)
                self.assertEqual(Api._metar_china_time(stamp), china)

    def test_extreme_offset_today_counterpart_fails_closed_without_escape(self) -> None:
        for column, value in (("received_at", "0001-01-01T00:00:00+23:59"),
                              ("report_time", "9999-12-31T23:59:59-23:59")):
            with self.subTest(column=column):
                database = self.case_database(f"extreme_{column}")
                db = self.replace_observations_with_untyped_copy(database)
                other = "received_at" if column == "report_time" else "report_time"
                db.execute(f"UPDATE metar_observations SET {column}=?,{other}=? WHERE station='ZSJN'",
                           (value, (self.now - timedelta(minutes=5)).isoformat()))
                db.commit()
                db.close()
                rows = self.snapshot_database(database)
                self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_native_string_subclasses_are_rejected_for_all_string_fields(self) -> None:
        class TextSubclass(str):
            pass

        sqlite3.register_converter(
            "SUBTEXT",
            lambda value: TextSubclass(value.decode()[7:]) if value.startswith(b"subtext:") else value.decode(),
        )
        cases = ("station", "city", "decision_scope", "state", "detail",
                 "report_time", "received_at", "report_type", "conditions")
        for field in cases:
            with self.subTest(field=field):
                database = self.case_database(f"subtext_{field}")
                db = sqlite3.connect(database)
                table = "metar_live_status" if field in {"state", "detail"} else "metar_observations"
                db.execute(f"ALTER TABLE {table} RENAME TO typed_rows")
                if table == "metar_live_status":
                    declarations = [f"{name} {'SUBTEXT' if name == field else 'TEXT'}"
                                    for name in ("station", "city", "decision_scope", "state", "detail")]
                    db.execute(f"CREATE TABLE metar_live_status ({','.join(declarations)})")
                    db.execute("INSERT INTO metar_live_status SELECT station,city,decision_scope,state,detail FROM typed_rows")
                    db.execute(f"UPDATE metar_live_status SET {field}='subtext:'||{field} WHERE station='ZSJN'")
                else:
                    names = ("station", "city", "decision_scope", "report_time", "received_at",
                             "report_type", "temperature_c", "wind_mps", "visibility_km", "conditions")
                    declarations = [f"{name} {'SUBTEXT' if name == field else ('REAL' if name in {'temperature_c','wind_mps','visibility_km'} else 'TEXT')}"
                                    for name in names]
                    db.execute(f"CREATE TABLE metar_observations ({','.join(declarations)})")
                    db.execute(f"INSERT INTO metar_observations SELECT {','.join(names)} FROM typed_rows")
                    db.execute(f"UPDATE metar_observations SET {field}='subtext:'||{field} WHERE station='ZSJN'")
                db.commit()
                db.close()
                real_connect = sqlite3.connect
                before = hashlib.sha256(database.read_bytes()).hexdigest()
                with patch.object(dashboard_modern, "OBSERVATIONS_DB", database), \
                     patch.object(dashboard_modern, "china_now", return_value=self.now), \
                     patch.object(dashboard_modern.sqlite3, "connect",
                                  side_effect=lambda *args, **kwargs: real_connect(
                                      *args, **kwargs, detect_types=sqlite3.PARSE_DECLTYPES)):
                    rows = Api().actual_snapshot()
                self.assertEqual(before, hashlib.sha256(database.read_bytes()).hexdigest())
                self.assert_unavailable_without_facts(
                    rows[7], None if field == "station" else "metar_record_invalid")
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

        observation = {"station": TextSubclass("ZSJN"), "city": "Jinan",
                       "decision_scope": "research_only", "report_time": self.now.isoformat(),
                       "received_at": self.now.isoformat(), "report_type": "METAR",
                       "temperature_c": 27, "wind_mps": 2, "visibility_km": 10,
                       "conditions": "CAVOK"}
        self.assertFalse(Api._metar_observation_valid(
            observation, dashboard_modern.METAR_ACTUAL_BY_STATION["ZSJN"]))

    def test_station_subclass_with_whitespace_invalidates_known_observation_slot(self) -> None:
        class TextSubclass(str):
            pass

        sqlite3.register_converter(
            "STATION_SUBCLASS",
            lambda value: TextSubclass(value.decode()[8:])
            if value.startswith(b"subtext:") else value.decode(),
        )
        database = self.case_database("station_subclass_whitespace_observation")
        db = sqlite3.connect(database)
        db.execute("ALTER TABLE metar_observations RENAME TO original_observations")
        db.execute("""CREATE TABLE metar_observations (
          station STATION_SUBCLASS,city,decision_scope,report_time,received_at,report_type,
          temperature_c,wind_mps,visibility_km,conditions)""")
        db.execute("""INSERT INTO metar_observations
          SELECT station,city,decision_scope,report_time,received_at,report_type,
                 temperature_c,wind_mps,visibility_km,conditions FROM original_observations""")
        db.execute("""INSERT INTO metar_observations VALUES
          ('subtext: ZSJN ','Jinan','research_only',?,?,'METAR',99,2,10,'CAVOK')""",
                   ((self.now - timedelta(minutes=4)).isoformat(),
                    (self.now - timedelta(minutes=3)).isoformat()))
        db.commit()
        db.close()
        real_connect = sqlite3.connect
        with patch.object(dashboard_modern, "OBSERVATIONS_DB", database), \
             patch.object(dashboard_modern, "china_now", return_value=self.now), \
             patch.object(dashboard_modern.sqlite3, "connect",
                          side_effect=lambda *args, **kwargs: real_connect(
                              *args, **kwargs, detect_types=sqlite3.PARSE_DECLTYPES)):
            rows = Api().actual_snapshot()
        self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
        self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_station_subclass_with_whitespace_invalidates_known_status_slot(self) -> None:
        class TextSubclass(str):
            pass

        sqlite3.register_converter(
            "STATUS_STATION_SUBCLASS",
            lambda value: TextSubclass(value.decode()[8:])
            if value.startswith(b"subtext:") else value.decode(),
        )
        database = self.case_database("station_subclass_whitespace_status")
        db = sqlite3.connect(database)
        db.execute("ALTER TABLE metar_live_status RENAME TO original_status")
        db.execute("CREATE TABLE metar_live_status (station STATUS_STATION_SUBCLASS,city,decision_scope,state,detail)")
        db.execute("INSERT INTO metar_live_status SELECT station,city,decision_scope,state,detail FROM original_status")
        db.execute("INSERT INTO metar_live_status VALUES ('subtext: ZSJN ','Jinan','research_only','healthy','bad')")
        db.commit()
        db.close()
        real_connect = sqlite3.connect
        with patch.object(dashboard_modern, "OBSERVATIONS_DB", database), \
             patch.object(dashboard_modern, "china_now", return_value=self.now), \
             patch.object(dashboard_modern.sqlite3, "connect",
                          side_effect=lambda *args, **kwargs: real_connect(
                              *args, **kwargs, detect_types=sqlite3.PARSE_DECLTYPES)):
            rows = Api().actual_snapshot()
        self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
        self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_station_native_and_subclass_known_and_unknown_boundaries(self) -> None:
        class TextSubclass(str):
            pass

        sqlite3.register_converter(
            "BOUNDARY_STATION",
            lambda value: TextSubclass(value.decode()[8:])
            if value.startswith(b"subtext:") else value.decode(),
        )
        for value, converted, invalidates in (
            ("ZSJN", True, True),
            (" ZSJN ", False, True),
            (" XXXX ", True, False),
        ):
            with self.subTest(value=value, converted=converted):
                database = self.case_database(f"station_boundary_{converted}_{value.strip()}")
                db = sqlite3.connect(database)
                db.execute("ALTER TABLE metar_observations RENAME TO original_observations")
                station_type = "BOUNDARY_STATION" if converted else "TEXT"
                db.execute(f"""CREATE TABLE metar_observations (
                  station {station_type},city,decision_scope,report_time,received_at,report_type,
                  temperature_c,wind_mps,visibility_km,conditions)""")
                db.execute("""INSERT INTO metar_observations
                  SELECT station,city,decision_scope,report_time,received_at,report_type,
                         temperature_c,wind_mps,visibility_km,conditions FROM original_observations""")
                stored_value = f"subtext:{value}" if converted else value
                db.execute("""INSERT INTO metar_observations VALUES
                  (?,'Unknown','research_only',?,?,'METAR',99,2,10,'CAVOK')""",
                           (stored_value, (self.now - timedelta(minutes=4)).isoformat(),
                            (self.now - timedelta(minutes=3)).isoformat()))
                db.commit()
                db.close()
                real_connect = sqlite3.connect
                connect_kwargs = {"detect_types": sqlite3.PARSE_DECLTYPES} if converted else {}
                with patch.object(dashboard_modern, "OBSERVATIONS_DB", database), \
                     patch.object(dashboard_modern, "china_now", return_value=self.now), \
                     patch.object(dashboard_modern.sqlite3, "connect",
                                  side_effect=lambda *args, **kwargs: real_connect(
                                      *args, **kwargs, **connect_kwargs)):
                    rows = Api().actual_snapshot()
                if invalidates:
                    self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                else:
                    self.assertTrue(rows[7]["available"])
                    self.assertEqual(rows[7]["temperature_c"], 27.0)
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_invalid_temperature_values_fail_closed_locally(self) -> None:
        invalid_values = ("25", "NaN", float("nan"), float("inf"), float("-inf"))
        for value in invalid_values:
            with self.subTest(value=repr(value)):
                database = self.case_database(f"temperature_{len(repr(value))}_{type(value).__name__}")
                db = self.replace_observations_with_untyped_copy(database)
                db.execute("UPDATE metar_observations SET temperature_c=? WHERE station='ZSJN'", (value,))
                db.commit()
                db.close()
                rows = self.snapshot_database(database)
                self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))
                database.unlink()

    def test_invalid_optional_numbers_fail_closed_locally(self) -> None:
        invalid_values = ("2", "NaN", float("inf"), -1)
        for column in ("wind_mps", "visibility_km"):
            for value in invalid_values:
                with self.subTest(column=column, value=repr(value)):
                    database = self.case_database(f"optional_{column}_{len(repr(value))}_{type(value).__name__}")
                    db = self.replace_observations_with_untyped_copy(database)
                    db.execute(f"UPDATE metar_observations SET {column}=? WHERE station='ZSJN'", (value,))
                    db.commit()
                    db.close()
                    rows = self.snapshot_database(database)
                    self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                    self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))
                    database.unlink()

    def test_nan_optional_numbers_returned_by_sqlite_fail_closed_locally(self) -> None:
        sqlite3.register_converter("NANVALUE", lambda value: float("nan") if value == b"nan" else float(value))
        for column in ("wind_mps", "visibility_km"):
            with self.subTest(column=column):
                database = self.case_database(f"nan_{column}")
                db = sqlite3.connect(database)
                db.execute("ALTER TABLE metar_observations RENAME TO typed_observations")
                db.execute(f"""CREATE TABLE metar_observations (
                  station TEXT,city TEXT,decision_scope TEXT,report_time TEXT,received_at TEXT,
                  report_type TEXT,temperature_c REAL,
                  wind_mps {'NANVALUE' if column == 'wind_mps' else 'REAL'},
                  visibility_km {'NANVALUE' if column == 'visibility_km' else 'REAL'},conditions TEXT)""")
                db.execute("""INSERT INTO metar_observations
                  SELECT station,city,decision_scope,report_time,received_at,report_type,
                         temperature_c,wind_mps,visibility_km,conditions FROM typed_observations""")
                db.execute(f"UPDATE metar_observations SET {column}='nan' WHERE station='ZSJN'")
                db.commit()
                db.close()
                real_connect = sqlite3.connect
                with patch.object(dashboard_modern, "OBSERVATIONS_DB", database), \
                     patch.object(dashboard_modern, "china_now", return_value=self.now), \
                     patch.object(dashboard_modern.sqlite3, "connect",
                                  side_effect=lambda *args, **kwargs: real_connect(
                                      *args, **kwargs, detect_types=sqlite3.PARSE_DECLTYPES)):
                    before = hashlib.sha256(database.read_bytes()).hexdigest()
                    rows = Api().actual_snapshot()
                self.assertEqual(before, hashlib.sha256(database.read_bytes()).hexdigest())
                self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))

    def test_invalid_report_type_and_conditions_fail_closed_locally(self) -> None:
        cases = (("report_type", "TAF"), ("report_type", 7), ("conditions", 7))
        for column, value in cases:
            with self.subTest(column=column, value=value):
                database = self.case_database(f"enum_{column}_{type(value).__name__}")
                db = self.replace_observations_with_untyped_copy(database)
                db.execute(f"UPDATE metar_observations SET {column}=? WHERE station='ZSJN'", (value,))
                db.commit()
                db.close()
                rows = self.snapshot_database(database)
                self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")
                self.assertTrue(all(row["available"] for index, row in enumerate(rows) if index != 7))
                database.unlink()

    def test_unknown_station_with_invalid_values_is_ignored_before_validation(self) -> None:
        db = sqlite3.connect(self.database)
        db.execute("""UPDATE metar_observations SET report_time=42,received_at=42,
                   report_type='BROKEN',temperature_c='NaN',wind_mps=-1,visibility_km='NaN',conditions=7
                   WHERE station='XXXX'""")
        db.commit()
        db.close()
        rows = self.snapshot()
        self.assertEqual(len(rows), 10)
        self.assertTrue(all(row["available"] for row in rows))
        self.assertNotIn("XXXX", {row["station"] for row in rows})

    def test_bool_values_returned_by_sqlite_are_rejected(self) -> None:
        sqlite3.register_converter("BOOLEAN", lambda value: value == b"1")
        database = Path(self.folder.name) / "boolean.sqlite3"
        db = sqlite3.connect(database, detect_types=sqlite3.PARSE_DECLTYPES)
        db.execute("CREATE TABLE metar_live_status (station TEXT,city TEXT,decision_scope TEXT,state TEXT,detail TEXT)")
        db.execute("""CREATE TABLE metar_observations (
          station TEXT,city TEXT,decision_scope TEXT,report_time TEXT,received_at TEXT,
          report_type TEXT,temperature_c BOOLEAN,wind_mps REAL,visibility_km REAL,conditions TEXT)""")
        report_at = (self.now - timedelta(minutes=10)).isoformat()
        db.execute("INSERT INTO metar_live_status VALUES ('ZSJN','Jinan','research_only','healthy','ok')")
        db.execute("INSERT INTO metar_observations VALUES ('ZSJN','Jinan','research_only',?,?,'METAR',1,2,10,'CAVOK')",
                   (report_at, report_at))
        db.commit()
        db.close()
        real_connect = sqlite3.connect
        with patch.object(dashboard_modern, "OBSERVATIONS_DB", database), \
             patch.object(dashboard_modern, "china_now", return_value=self.now), \
             patch.object(dashboard_modern.sqlite3, "connect",
                          side_effect=lambda *args, **kwargs: real_connect(
                              *args, **kwargs, detect_types=sqlite3.PARSE_DECLTYPES)):
            before = hashlib.sha256(database.read_bytes()).hexdigest()
            rows = Api().actual_snapshot()
        self.assertEqual(before, hashlib.sha256(database.read_bytes()).hexdigest())
        self.assert_unavailable_without_facts(rows[7], "metar_record_invalid")

    def test_query_error_closes_read_only_connection(self) -> None:
        connection = MagicMock()
        connection.execute.side_effect = sqlite3.OperationalError("schema unavailable")
        with patch.object(dashboard_modern, "OBSERVATIONS_DB", self.database), \
             patch.object(dashboard_modern.sqlite3, "connect", return_value=connection) as connect:
            rows = Api().actual_snapshot()
        self.assertEqual(
            [(row["city"], row["station"], row["scope"]) for row in rows],
            [(city, station, scope) for city, _label, station, scope in ACTIVE_EXPECTED],
        )
        self.assertTrue(all(not row["available"] for row in rows))
        self.assertTrue(all(row["detail"] == "metar_query_unavailable" for row in rows))
        self.assertIn("mode=ro", connect.call_args.args[0])
        connection.close.assert_called_once_with()

    def test_missing_database_returns_fixed_unavailable_slots_without_opening(self) -> None:
        missing = self.database.with_name("missing.sqlite3")
        with patch.object(dashboard_modern, "OBSERVATIONS_DB", missing), \
             patch.object(dashboard_modern.sqlite3, "connect") as connect:
            rows = Api().actual_snapshot()
        self.assertEqual(len(rows), 7)
        self.assertTrue(all(not row["available"] for row in rows))
        self.assertTrue(all(row["detail"] == "metar_database_unavailable" for row in rows))
        connect.assert_not_called()

    def test_normal_and_dto_error_paths_close_read_only_connections(self) -> None:
        before = hashlib.sha256(self.database.read_bytes()).hexdigest()
        real_connect = sqlite3.connect
        tracked = []

        class ConnectionProxy:
            def __init__(self, connection, uri):
                object.__setattr__(self, "connection", connection)
                object.__setattr__(self, "uri", uri)
                object.__setattr__(self, "closed", False)
                object.__setattr__(self, "total_changes_at_close", None)

            def __getattr__(self, name):
                return getattr(self.connection, name)

            def __setattr__(self, name, value):
                if name in {"connection", "uri", "closed", "total_changes_at_close"}:
                    object.__setattr__(self, name, value)
                else:
                    setattr(self.connection, name, value)

            def close(self):
                object.__setattr__(self, "total_changes_at_close",
                                   self.connection.total_changes)
                object.__setattr__(self, "closed", True)
                return self.connection.close()

        def tracking_connect(*args, **kwargs):
            proxy = ConnectionProxy(real_connect(*args, **kwargs), args[0])
            tracked.append(proxy)
            return proxy

        with patch.object(dashboard_modern, "OBSERVATIONS_DB", self.database), \
             patch.object(dashboard_modern, "china_now", return_value=self.now), \
             patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect):
            rows = Api().actual_snapshot()
        self.assertEqual(len(rows), 10)
        self.assertIn("mode=ro", tracked[0].uri)
        self.assertTrue(tracked[0].closed)
        self.assertEqual(tracked[0].total_changes_at_close, 0)
        self.assertEqual(before, hashlib.sha256(self.database.read_bytes()).hexdigest())

        with patch.object(dashboard_modern, "OBSERVATIONS_DB", self.database), \
             patch.object(dashboard_modern, "china_now", return_value=self.now), \
             patch.object(Api, "_metar_china_time", side_effect=ValueError("dto failed")), \
             patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect):
            rows = Api().actual_snapshot()
        self.assertEqual(len(rows), 10)
        self.assertTrue(all(not row["available"] for row in rows))
        self.assertTrue(all(row["detail"] == "metar_query_unavailable" for row in rows))
        self.assertIn("mode=ro", tracked[1].uri)
        self.assertTrue(tracked[1].closed)
        self.assertEqual(tracked[1].total_changes_at_close, 0)
        self.assertEqual(before, hashlib.sha256(self.database.read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
