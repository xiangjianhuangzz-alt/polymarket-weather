"""Safe, service-scoped runtime inspection and circuit-breaker reset.

This tool deliberately has no aggregate stop/restart command.  Process
lifecycle remains owned by each service's independent scheduled task.
"""
from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
import uuid

from runtime_control_contract import RESET_ACTION, RESET_SCHEMA
from runtime_status import atomic_json
from service_guardian import RUNTIME_DIR, SERVICE_SPECS, SERVICE_STATUS_DIR


CONTROL_DIR = RUNTIME_DIR / "control"


def status(service: str | None = None) -> dict:
    names = [service] if service else sorted(SERVICE_SPECS)
    result = {}
    for name in names:
        path = SERVICE_STATUS_DIR / f"{name}.json"
        try:
            result[name] = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            result[name] = {"state": "not_started"}
        except (OSError, json.JSONDecodeError) as exc:
            result[name] = {"state": "status_unreadable", "error": f"{type(exc).__name__}: {exc}"}
    return result


def request_reset(service: str, *, reason: str = "operator_requested_reset",
                  now: datetime | None = None) -> Path:
    if service not in SERVICE_SPECS:
        raise ValueError("unknown service")
    if not reason or len(reason) > 256 or any(ord(char) < 32 for char in reason):
        raise ValueError("invalid reset reason")
    requested_at = (now or datetime.now(UTC)).astimezone(UTC)
    path = CONTROL_DIR / f"{service}.reset.json"
    atomic_json(path, {
        "schema": RESET_SCHEMA,
        "request_id": uuid.uuid4().hex,
        "service": service,
        "action": RESET_ACTION,
        "requested_at": requested_at.isoformat(),
        "expires_at": (requested_at + timedelta(minutes=5)).isoformat(),
        "reason": reason,
    })
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect isolated runtime services")
    subparsers = parser.add_subparsers(dest="command", required=True)
    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("--service", choices=sorted(SERVICE_SPECS))
    reset_parser = subparsers.add_parser("reset-breaker")
    reset_parser.add_argument("--service", required=True, choices=sorted(SERVICE_SPECS))
    args = parser.parse_args()
    if args.command == "status":
        print(json.dumps(status(args.service), ensure_ascii=False, indent=2))
    else:
        print(request_reset(args.service))


if __name__ == "__main__":
    main()
