import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import ctypes
from contextlib import closing
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import patch

from service_guardian import (
    BASE_PYTHON,
    ChildContainment,
    ServiceGuardian,
    ServiceSpec,
    SERVICE_SPECS,
    read_heartbeat,
    steady_status,
)
from runtime_status import WorkerProgressPublisher, atomic_json
from runtime_control import request_reset


BASE = Path(__file__).resolve().parent


def wait_for(predicate, timeout: float = 8.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(0.05)
    return False


def process_alive(pid: int) -> bool:
    if sys.platform != "win32":
        try:
            import os
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(0x00100000 | 0x00001000, False, pid)
    if not handle:
        return False
    try:
        code = ctypes.c_ulong()
        return bool(kernel32.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == 259
    finally:
        kernel32.CloseHandle(handle)


class ServiceGuardianTests(unittest.TestCase):
    def test_worker_progress_publisher_writes_latest_status_atomically(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "unit.worker.json"
            publisher = WorkerProgressPublisher(path, "unit")
            publisher.start()
            try:
                self.assertTrue(publisher.publish("starting", detail="boot"))
                self.assertTrue(publisher.publish(
                    "evaluating", detail="phase=city:Shanghai",
                    deadline_at=(datetime.now(UTC) + timedelta(seconds=30)).isoformat(),
                ))
                self.assertTrue(wait_for(lambda: path.exists()))
                self.assertTrue(wait_for(
                    lambda: '"state": "evaluating"' in path.read_text(encoding="utf-8")
                ))
                payload = json.loads(path.read_text(encoding="utf-8"))
                self.assertEqual(payload["schema"], 1)
                self.assertEqual(payload["service"], "unit")
                self.assertEqual(payload["state"], "evaluating")
                self.assertEqual(payload["worker_pid"], os.getpid())
            finally:
                publisher.close()

    def test_worker_progress_publisher_serializes_final_task_fields(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "unit.worker.json"
            publisher = WorkerProgressPublisher(path, "unit")
            publisher.start()
            try:
                self.assertTrue(publisher.publish(
                    "pending_evidence", detail="waiting",
                    task_id="2026-08-21T15:00:00+08:00",
                    reason="checkpoint_identity_unavailable",
                    orders_created=0,
                ))
                self.assertTrue(wait_for(lambda: path.exists()))
                payload = json.loads(path.read_text(encoding="utf-8"))
                self.assertEqual(payload["state"], "pending_evidence")
                self.assertEqual(payload["task_id"], "2026-08-21T15:00:00+08:00")
                self.assertEqual(payload["reason"], "checkpoint_identity_unavailable")
                self.assertEqual(payload["orders_created"], 0)
            finally:
                publisher.close()

    def test_worker_progress_publisher_rejects_invalid_final_task_fields(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            publisher = WorkerProgressPublisher(Path(temporary) / "unit.worker.json", "unit")
            with self.assertRaises((TypeError, ValueError)):
                publisher.publish("running", task_id=123)
            with self.assertRaises((TypeError, ValueError)):
                publisher.publish("running", reason=object())
            with self.assertRaises((TypeError, ValueError)):
                publisher.publish("running", orders_created=True)
            with self.assertRaises((TypeError, ValueError)):
                publisher.publish("running", orders_created=-1)
            with self.assertRaises(ValueError):
                publisher.publish("running", task_id="x" * 501)
            with self.assertRaises(ValueError):
                publisher.publish("running", reason="x" * 501)

    def test_worker_progress_publisher_old_call_keeps_optional_fields_null(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "unit.worker.json"
            publisher = WorkerProgressPublisher(path, "unit")
            publisher.start()
            try:
                self.assertTrue(publisher.publish("starting", detail="boot"))
                self.assertTrue(wait_for(lambda: path.exists()))
                payload = json.loads(path.read_text(encoding="utf-8"))
                self.assertIsNone(payload["task_id"])
                self.assertIsNone(payload["reason"])
                self.assertIsNone(payload["orders_created"])
            finally:
                publisher.close()

    def test_windows_containment_closes_only_its_child(self) -> None:
        first = subprocess.Popen([str(BASE_PYTHON), "-c", "import time;time.sleep(60)"], cwd=BASE)
        second = subprocess.Popen([str(BASE_PYTHON), "-c", "import time;time.sleep(60)"], cwd=BASE)
        containment = ChildContainment(first)
        try:
            containment.close()
            self.assertIsNotNone(first.poll())
            self.assertIsNone(second.poll())
        finally:
            if first.poll() is None:
                first.kill()
                first.wait(timeout=10)
            if second.poll() is None:
                second.kill()
                second.wait(timeout=10)

    def test_hard_guardian_death_kills_only_its_own_child(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            helper_code = (
                "import subprocess,sys,time;"
                "from pathlib import Path;"
                "from service_guardian import BASE_PYTHON,ChildContainment;"
                "child=subprocess.Popen([str(BASE_PYTHON),'-c','import time;time.sleep(60)']);"
                "job=ChildContainment(child);"
                "Path(sys.argv[1]).write_text(str(child.pid),encoding='utf-8');"
                "time.sleep(60)"
            )
            pid_a_file, pid_b_file = root / "a.pid", root / "b.pid"
            guardian_a = subprocess.Popen([str(BASE_PYTHON), "-c", helper_code, str(pid_a_file)], cwd=BASE)
            guardian_b = subprocess.Popen([str(BASE_PYTHON), "-c", helper_code, str(pid_b_file)], cwd=BASE)
            child_a = child_b = None
            try:
                self.assertTrue(wait_for(lambda: pid_a_file.exists() and pid_b_file.exists()))
                child_a = int(pid_a_file.read_text(encoding="utf-8"))
                child_b = int(pid_b_file.read_text(encoding="utf-8"))
                self.assertTrue(process_alive(child_a))
                self.assertTrue(process_alive(child_b))
                guardian_a.kill()
                guardian_a.wait(timeout=10)
                self.assertTrue(wait_for(lambda: not process_alive(child_a)))
                self.assertTrue(process_alive(child_b))
            finally:
                for guardian in (guardian_a, guardian_b):
                    if guardian.poll() is None:
                        guardian.kill()
                        guardian.wait(timeout=10)
                if child_a and process_alive(child_a):
                    subprocess.run(["taskkill", "/PID", str(child_a), "/T", "/F"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if child_b and process_alive(child_b):
                    subprocess.run(["taskkill", "/PID", str(child_b), "/T", "/F"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def test_heartbeat_reads_only_the_assigned_database(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            database = Path(temporary) / "one.sqlite3"
            with closing(sqlite3.connect(database)) as db, db:
                db.execute("CREATE TABLE service_heartbeats(service TEXT PRIMARY KEY,updated_at TEXT,detail TEXT)")
                db.execute(
                    "INSERT INTO service_heartbeats VALUES (?,?,?)",
                    ("unit", datetime.now(UTC).isoformat(), "ok"),
                )
            spec = ServiceSpec("unit", BASE / "none.py", database, "unit", 30, 1, 2)
            age, detail = read_heartbeat(spec)
            self.assertLess(age, 2)
            self.assertEqual(detail, "ok")

    def test_circuit_breaker_survives_guardian_recreation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            status_dir = Path(temporary)
            spec = ServiceSpec("unit", BASE / "none.py", status_dir / "db.sqlite3", "unit", 30, 1, 2)
            guardian = ServiceGuardian(spec, status_dir=status_dir)
            self.assertFalse(guardian._record_restart("duplicate_writer_lock"))
            recreated = ServiceGuardian(spec, status_dir=status_dir)
            self.assertEqual(recreated.halted_reason, "duplicate_writer_lock")

    def test_status_file_failure_cannot_stop_a_healthy_writer(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec("unit", BASE / "none.py", root / "db.sqlite3", "unit", 30, 1, 2)
            guardian = ServiceGuardian(spec, status_dir=root)
            with patch("service_guardian.atomic_json", side_effect=PermissionError("held")):
                guardian.write_status("healthy")
            self.assertIsNone(guardian.halted_reason)

    def test_halted_guardian_requires_explicit_reset_request(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec("collector", BASE / "none.py", root / "db.sqlite3", "collector", 30, 1, 2)
            guardian = ServiceGuardian(
                spec, status_dir=root / "status", control_dir=root / "control"
            )
            guardian.halted_reason = "circuit_breaker"
            self.assertFalse(guardian.consume_reset_request())
            self.assertEqual(guardian.halted_reason, "circuit_breaker")
            with patch("runtime_control.CONTROL_DIR", root / "control"):
                request_reset("collector", now=datetime.now(UTC))
            self.assertTrue(guardian.consume_reset_request())
            self.assertIsNone(guardian.halted_reason)
            self.assertFalse(guardian.reset_path.exists())

    def test_reset_request_rejects_wrong_service_expiry_and_duplicates(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec("unit", BASE / "none.py", root / "db.sqlite3", "unit", 30, 1, 2)
            guardian = ServiceGuardian(spec, status_dir=root / "status", control_dir=root / "control")
            guardian.halted_reason = "circuit_breaker"
            guardian.reset_path.parent.mkdir(parents=True, exist_ok=True)
            now = datetime.now(UTC)
            base = {
                "schema": "service_guardian_reset.v1", "request_id": "a" * 32,
                "service": "collector", "action": "reset_circuit_breaker",
                "requested_at": now.isoformat(),
                "expires_at": (now + timedelta(minutes=5)).isoformat(),
                "reason": "test",
            }
            guardian.reset_path.write_text(json.dumps(base), encoding="utf-8")
            self.assertFalse(guardian.consume_reset_request())
            self.assertEqual(guardian.halted_reason, "circuit_breaker")
            duplicate = json.dumps({**base, "service": "unit"})[:-1] + ',"service":"unit"}'
            guardian.reset_path.write_text(duplicate, encoding="utf-8")
            self.assertFalse(guardian.consume_reset_request())
            expired = {**base, "service": "unit", "requested_at": (now - timedelta(minutes=6)).isoformat(),
                       "expires_at": (now - timedelta(minutes=1)).isoformat()}
            guardian.reset_path.write_text(json.dumps(expired), encoding="utf-8")
            self.assertFalse(guardian.consume_reset_request())

    def test_missing_heartbeat_after_grace_requests_only_local_restart(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec("unit", BASE / "none.py", root / "missing.sqlite3", "unit", 30, 0, 2)
            guardian = ServiceGuardian(spec, status_dir=root)
            guardian.child = subprocess.Popen(
                [str(BASE_PYTHON), "-c", "import time;time.sleep(60)"], cwd=BASE
            )
            guardian.containment = ChildContainment(guardian.child)
            guardian.child_started_monotonic = time.monotonic() - 5
            try:
                self.assertEqual(guardian._reason()[0], "heartbeat_missing")
            finally:
                guardian.stop_child()

    def test_stale_quotes_do_not_restart_a_live_reconnecting_worker(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec(
                "realtime_stream", BASE / "none.py", root / "quotes.sqlite3",
                "realtime_stream", 90, 0, 5, True,
            )
            guardian = ServiceGuardian(spec, status_dir=root)
            guardian.child = unittest.mock.Mock()
            guardian.child.poll.return_value = None
            guardian.child_started_monotonic = time.monotonic() - 300
            with patch("service_guardian.read_heartbeat",
                       return_value=(5.0, "reconnecting after ConnectionError")), \
                 patch("service_guardian.latest_quote_age", return_value=300.0):
                reason, _age, _detail, quote_age = guardian._reason()
            self.assertIsNone(reason)
            self.assertEqual(
                steady_status(spec, quote_age),
                ("degraded_quote_stale", "quote_stale:300s"),
            )

    def test_fresh_worker_progress_prevents_false_database_heartbeat_restart(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec(
                "realtime_stream", BASE / "none.py", root / "quotes.sqlite3",
                "realtime_stream", 90, 0, 5, True,
            )
            guardian = ServiceGuardian(spec, status_dir=root)
            guardian.child = unittest.mock.Mock()
            guardian.child.pid = 4321
            guardian.child.poll.return_value = None
            guardian.child_started_monotonic = time.monotonic() - 300
            atomic_json(guardian.worker_status_path, {
                "schema": 1,
                "service": "realtime_stream",
                "worker_pid": 4321,
                "state": "connected",
                "updated_at": datetime.now(UTC).isoformat(),
                "detail": "writer=ok",
                "deadline_at": None,
            })
            with patch("service_guardian.read_heartbeat",
                       return_value=(92.0, "live writer=ok")), \
                 patch("service_guardian.latest_quote_age", return_value=300.0):
                self.assertIsNone(guardian._reason()[0])

    def test_collector_new_worker_progress_masks_previous_worker_database_deadline(self) -> None:
        """A replacement collector must not inherit the previous PID's timeout."""
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec(
                "collector", BASE / "none.py", root / "research.sqlite3",
                "collector", 8 * 60, 0, 5,
            )
            guardian = ServiceGuardian(spec, status_dir=root)
            guardian.child = unittest.mock.Mock()
            guardian.child.pid = 5432
            guardian.child.poll.return_value = None
            guardian.child_started_monotonic = time.monotonic() - 300
            now = datetime.now(UTC)
            atomic_json(guardian.worker_status_path, {
                "schema": 1,
                "service": "collector",
                "worker_pid": 5432,
                "state": "starting",
                "updated_at": now.isoformat(),
                "detail": "phase=database_startup",
                "deadline_at": (now + timedelta(seconds=60)).isoformat(),
            })
            previous_worker_detail = (
                "state=running; phase=market_detail; "
                f"deadline_at={(now - timedelta(minutes=10)).isoformat()}"
            )
            with patch(
                "service_guardian.read_heartbeat",
                return_value=(20 * 60, previous_worker_detail),
            ):
                self.assertIsNone(guardian._reason()[0])

    def test_collector_expired_worker_deadline_still_requests_restart(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec(
                "collector", BASE / "none.py", root / "research.sqlite3",
                "collector", 8 * 60, 0, 5,
            )
            guardian = ServiceGuardian(spec, status_dir=root)
            guardian.child = unittest.mock.Mock()
            guardian.child.pid = 6543
            guardian.child.poll.return_value = None
            guardian.child_started_monotonic = time.monotonic() - 300
            now = datetime.now(UTC)
            expired = now - timedelta(seconds=60)
            atomic_json(guardian.worker_status_path, {
                "schema": 1,
                "service": "collector",
                "worker_pid": 6543,
                "state": "running",
                "updated_at": now.isoformat(),
                "detail": "phase=market_detail",
                "deadline_at": expired.isoformat(),
            })
            detail = (
                "state=running; phase=market_detail; "
                f"deadline_at={expired.isoformat()}"
            )
            with patch(
                "service_guardian.read_heartbeat",
                return_value=(5.0, detail),
            ):
                self.assertEqual(
                    guardian._reason()[0],
                    "phase_deadline_exceeded:market_detail",
                )

    def test_deadline_prevents_killing_legitimate_long_cycle(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec(
                "unit_worker", BASE / "none.py", root / "unit.sqlite3",
                "unit_worker", 30, 0, 3,
            )
            guardian = ServiceGuardian(spec, status_dir=root)
            guardian.child = unittest.mock.Mock()
            guardian.child.pid = 9876
            guardian.child.poll.return_value = None
            guardian.child_started_monotonic = time.monotonic() - 300
            now = datetime.now(UTC)
            atomic_json(guardian.worker_status_path, {
                "schema": 1,
                "service": "unit_worker",
                "worker_pid": 9876,
                "state": "evaluating",
                "updated_at": (now - timedelta(seconds=35)).isoformat(),
                "detail": "phase=city:Shanghai",
                "deadline_at": (now + timedelta(seconds=30)).isoformat(),
            })
            with patch("service_guardian.read_heartbeat",
                       return_value=(35.0, "shadow cycle running")):
                self.assertIsNone(guardian._reason()[0])

    def test_expired_stale_progress_does_not_mask_a_hung_cycle(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec(
                "unit_worker", BASE / "none.py", root / "unit.sqlite3",
                "unit_worker", 30, 0, 3,
            )
            guardian = ServiceGuardian(spec, status_dir=root)
            guardian.child = unittest.mock.Mock()
            guardian.child.pid = 2468
            guardian.child.poll.return_value = None
            guardian.child_started_monotonic = time.monotonic() - 300
            now = datetime.now(UTC)
            atomic_json(guardian.worker_status_path, {
                "schema": 1,
                "service": "unit_worker",
                "worker_pid": 2468,
                "state": "evaluating",
                "updated_at": (now - timedelta(seconds=60)).isoformat(),
                "detail": "phase=city:Shanghai",
                "deadline_at": (now - timedelta(seconds=20)).isoformat(),
            })
            with patch("service_guardian.read_heartbeat",
                       return_value=(60.0, "shadow cycle running")):
                self.assertEqual(guardian._reason()[0], "heartbeat_stale:60s")

    def test_dead_quote_writer_still_requests_local_restart(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            spec = ServiceSpec(
                "realtime_stream", BASE / "none.py", root / "quotes.sqlite3",
                "realtime_stream", 90, 0, 5, True,
            )
            guardian = ServiceGuardian(spec, status_dir=root)
            guardian.child = unittest.mock.Mock()
            guardian.child.poll.return_value = None
            guardian.child_started_monotonic = time.monotonic() - 300
            with patch("service_guardian.read_heartbeat",
                       return_value=(5.0, "live tokens=50 writer=dead")), \
                 patch("service_guardian.latest_quote_age", return_value=300.0):
                self.assertEqual(guardian._reason()[0], "quote_writer_dead")

    def test_one_worker_restart_does_not_change_peer_pid(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)

            def make_worker(name: str) -> tuple[Path, Path]:
                database = root / f"{name}.sqlite3"
                script = root / f"{name}.py"
                script.write_text(
                    "import sqlite3,time\n"
                    "from datetime import datetime,timezone\n"
                    f"db=sqlite3.connect(r'{database}')\n"
                    "db.execute('CREATE TABLE IF NOT EXISTS service_heartbeats"
                    "(service TEXT PRIMARY KEY,updated_at TEXT,detail TEXT)')\n"
                    "while True:\n"
                    f" db.execute('INSERT OR REPLACE INTO service_heartbeats VALUES (?,?,?)',"
                    f"('{name}',datetime.now(timezone.utc).isoformat(),'ok'))\n"
                    " db.commit(); time.sleep(0.1)\n",
                    encoding="utf-8",
                )
                return script, database

            script_a, db_a = make_worker("alpha")
            script_b, db_b = make_worker("beta")
            guardian_a = ServiceGuardian(
                # Give the replacement worker a realistic startup grace.  A
                # zero-second grace races its first heartbeat and can trigger
                # an unrelated second restart during test cleanup on Windows.
                ServiceSpec("alpha", script_a, db_a, "alpha", 2, 1, 4),
                status_dir=root / "status-a",
            )
            guardian_b = ServiceGuardian(
                ServiceSpec("beta", script_b, db_b, "beta", 2, 1, 4),
                status_dir=root / "status-b",
            )
            thread_a = threading.Thread(target=guardian_a.run)
            thread_b = threading.Thread(target=guardian_b.run)
            with patch("service_guardian.CHECK_SECONDS", 0.1), \
                 patch("service_guardian.BACKOFF_SECONDS", (0.1, 0.1, 0.1)):
                thread_a.start()
                thread_b.start()
                try:
                    self.assertTrue(wait_for(lambda: guardian_a.child is not None and guardian_b.child is not None))
                    pid_a = guardian_a.child.pid
                    pid_b = guardian_b.child.pid
                    guardian_a.child.kill()
                    guardian_a.child.wait(timeout=10)
                    self.assertTrue(wait_for(
                        lambda: guardian_a.child is not None
                        and guardian_a.child.poll() is None
                        and guardian_a.child.pid != pid_a
                    ))
                    self.assertEqual(guardian_b.child.pid, pid_b)
                    self.assertIsNone(guardian_b.child.poll())
                finally:
                    guardian_a.stop_event.set()
                    guardian_b.stop_event.set()
                    thread_a.join(timeout=10)
                    thread_b.join(timeout=10)
            self.assertFalse(thread_a.is_alive())
            self.assertFalse(thread_b.is_alive())


if __name__ == "__main__":
    unittest.main()
