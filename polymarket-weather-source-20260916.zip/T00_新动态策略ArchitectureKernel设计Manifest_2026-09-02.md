# T00｜新动态策略Architecture Kernel设计Manifest｜2026-09-02

状态：`FROZEN`

```json
{
  "manifest_schema": "architecture-kernel-manifest.v1",
  "manifest_id": "T00-weather-strategy-architecture-kernel/ak1/manifest",
  "candidate_id": "T00-weather-strategy-architecture-kernel/ak1",
  "candidate_schema": "architecture-kernel.v1",
  "project": "polymarket-weather",
  "branch": "codex/handoff-baseline-20260809",
  "baseline_head": "13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac",
  "as_of_date": "2026-09-02",
  "timezone": "Asia/Shanghai",
  "hash_algorithm": "sha256",
  "members": [
    {
      "role": "TASK_CONTRACT",
      "path": "T00_V8_ArchitectureKernel任务合同_2026-09-02.md",
      "sha256": "6739d6eec891679d084042b3f683d93605f0e12a95d338a401b94b2c350e208e"
    },
    {
      "role": "CANDIDATE",
      "path": "T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md",
      "sha256": "b0ccc9d82e8c8bfec06836abaf6914a4c4c7fbcf932a59fb9ce54140d7485988"
    },
    {
      "role": "AUTHOR_SELFCHECK",
      "path": "T00_新动态策略ArchitectureKernel设计自检_2026-09-02.md",
      "sha256": "c408415a01c362525e285af25ca4942a239a842da4544422ef7da3e992b06ab5"
    }
  ],
  "source_identities": [
    {
      "role": "R1_INDEPENDENT_AUDIT",
      "path": "T01_新动态策略端到端研究架构独立终审_v8.2_r1_2026-09-01.md",
      "sha256": "ee2b599d58b1b321197bb9e87b372992955264894ab244325c1b6bb55cfa5add"
    },
    {
      "role": "POST_FAIL_ROUTE_DECISION",
      "path": "T00_V8.2_R1独立终审FAIL后续路线决策审查_2026-09-02.md",
      "sha256": "1f7e6bd451a6f1b9c9e335cbc83805268198afd95fde0ec2227489a95686d721"
    }
  ],
  "frozen_state": {
    "architecture_kernel_candidate_frozen": true,
    "author_selfcheck": "PASS_DESIGN_ONLY",
    "independent_audit_authorized": false,
    "independent_audit_completed": false,
    "kernel_accepted": false,
    "complete_replacement_design_authorized": false,
    "implementation_authorized": false,
    "test_execution_authorized": false,
    "git_write_authorized": false,
    "deployment_authorized": false
  }
}
```

## 验证规则

1. `members`必须恰好三项，按`TASK_CONTRACT`、`CANDIDATE`、`AUTHOR_SELFCHECK`排序；
2. hash按文件当前原始字节计算，算法为SHA-256并使用小写十六进制；
3. 本Manifest不绑定自身，避免自引用hash；
4. 路线决策和R1独立终审仅作为源身份，不成为Kernel规范成员；
5. 任一成员字节变化都产生新候选，不得原地覆盖后继续沿用本Manifest或候选ID；
6. `FROZEN`只表示候选字节身份冻结，不表示独立审查通过、设计接受、实现授权或部署授权。
