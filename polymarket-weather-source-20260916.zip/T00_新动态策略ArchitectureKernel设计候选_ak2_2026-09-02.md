# T00｜新动态策略Architecture Kernel唯一受限修订候选 ak2｜2026-09-02

状态：`AK2_CANDIDATE_FROZEN_AWAITING_SECOND_INDEPENDENT_AUDIT_AUTHORIZATION`

```text
CANDIDATE_ID=T00-weather-strategy-architecture-kernel/ak2
SCHEMA_VERSION=architecture-kernel.v2
PARENT_ID=T00-weather-strategy-architecture-kernel/ak1
BASELINE_BRANCH=codex/handoff-baseline-20260809
BASELINE_HEAD=13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
AS_OF_DATE=2026-09-02
TIMEZONE=Asia/Shanghai
```

性质：第一次Kernel独立审查FAIL后的唯一一次受限替代候选；不是完整V8设计、实现、实现测试、Git集成、部署、Shadow、Paper或交易规范。

## 1. 规范解释法

<a id="section-1"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.META.INTERPRETATION">

本文件只在两处产生规范：第3节的机器可读`KernelRegistryV2`和该Registry逐项指向的`NORMATIVE_PAYLOAD`。其余标题、解释、例子和关闭矩阵均为派生说明，不得覆盖Payload。

解析器必须执行：Registry条目集合与Payload标签集合完全相等；每个`rule_id`恰有一个owner；Payload不得嵌套；未知、重复、缺失、未消费或冲突条目全部失败。完整替代设计只能按`rule_id`和冻结候选hash继承，禁止复制后改写。

优先级：当前明确用户指令与项目安全边界→新动态策略设计输入基线→V3唯一公式归档→本候选Registry/Payload。V8、V8.1、R2、V8.2、R1和ak1只作为历史与反例证据。

</NORMATIVE_PAYLOAD>

## 2. 冻结业务边界

<a id="section-2"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.BUSINESS.INVARIANTS">

```text
SIDE=BUY_YES_ONLY
WINDOW=Asia/Shanghai [07:00:00,16:00:00)
DECISION_FORMULA=E_conservative(B,t)=P_LCB(B|I_t)-C_executable(B,t)
MARKET_PRICE_IN_WEATHER_MODEL=NO
STRICT_AS_OF=REQUIRED
INDEPENDENT_UNIT=city+target_date
CITIES=[SHANGHAI,BEIJING,GUANGZHOU]
SHANGHAI_FORECAST=weatherol_shanghai/weatherol_d0
STATIONS={SHANGHAI:ZSPD,BEIJING:ZBAA,GUANGZHOU:ZGGG}
BEIJING_FORECAST=TAF
GUANGZHOU_FORECAST=TAF
CITY_END_TO_END_INDEPENDENCE=REQUIRED
SHADOW=PAPER=LIVE_TRADING=FUNDS=DISABLED
```

三城不得共享Evidence行、训练日、模型、校准器、Bootstrap样本、Artifact、Qualification、Decision、事件链、lease、health或恢复写事务。仅允许共享纯代码、不可变公共policy及包含三份逐城引用的单一`ApprovedConfigSetV1`。

</NORMATIVE_PAYLOAD>

## 3. 唯一Canonical Registry实例

<a id="section-3"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.CANONICAL.REGISTRY">

下面JSON是本候选完整、封闭的Kernel Registry实例；条目以`rule_id`升序规范化，`owner_anchor`必须在本文件恰好出现一次。没有登记的对象或规则不能成为未来实现输入。

```json
{
  "registry_schema": "kernel-registry.v2",
  "candidate_id": "T00-weather-strategy-architecture-kernel/ak2",
  "canonical_encoding": "UTF-8-NFC+JCS-for-JSON+LF",
  "unknown_entry_policy": "REJECT",
  "duplicate_owner_policy": "REJECT",
  "unconsumed_normative_policy": "REJECT",
  "entries": [
    {"rule_id":"KERNEL.BUSINESS.INVARIANTS","owner_anchor":"section-2","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.CANONICAL.REGISTRY","owner_anchor":"section-3","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.DEFERRED.BOUNDARIES","owner_anchor":"section-13-boundaries","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.INHERITED.B03","owner_anchor":"section-12-b03","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.INHERITED.B04","owner_anchor":"section-12-b04","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.INHERITED.B05","owner_anchor":"section-12-b05","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.INHERITED.B06","owner_anchor":"section-12-b06","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.INHERITED.B07","owner_anchor":"section-12-b07","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.INHERITED.B08_TASK","owner_anchor":"section-12-b08-task","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.LIFECYCLE.FREEZE","owner_anchor":"section-14","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.META.INTERPRETATION","owner_anchor":"section-1","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R01.CANONICAL_CLOSURE","owner_anchor":"section-4","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R02.APPROVAL_INPUT","owner_anchor":"section-5","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R03.M007","owner_anchor":"section-6","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R04.EVENT_IDENTITY","owner_anchor":"section-7","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R05.CURRENT_CANDIDATE","owner_anchor":"section-8","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R06.OUTCOME_FUNCTION","owner_anchor":"section-9","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R07.PROCESS_IDENTITY","owner_anchor":"section-10-1","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R08.PATH_INVENTORY","owner_anchor":"section-10-2","kind":"NORMATIVE"},
    {"rule_id":"KERNEL.R09.RECOVERY_STATE","owner_anchor":"section-10-3","kind":"NORMATIVE"}
  ]
}
```

Registry身份由最终Manifest中的候选文件SHA-256绑定，不在候选内部放置自引用hash。

</NORMATIVE_PAYLOAD>

## 4. R01｜Canonical闭合和派生规则

<a id="section-4"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R01.CANONICAL_CLOSURE">

未来完整设计必须逐字提取第3节Registry及全部Payload，生成一个`CanonicalRuleSet`。每个派生Schema、DDL、配置、错误表、任务、ACL计划、测试向量和部署Manifest必须记录：

```text
kernel_candidate_id
kernel_candidate_sha256
registry_schema
consumed_rule_ids[]
generator_id
generator_version
generated_payload_sha256
```

生成门按固定顺序执行：

```text
PARSE_REGISTRY
→ ENUMERATE_PAYLOAD_TAGS
→ REQUIRE_EXACT_SET_EQUALITY
→ REQUIRE_ONE_OWNER_PER_RULE
→ BUILD_REFERENCE_GRAPH
→ REJECT_UNKNOWN_OR_CYCLIC_REFERENCE
→ GENERATE
→ REVERSE_COMPARE_EVERY_NORMATIVE_FIELD
→ HASH
```

禁止手工维护第二套F/O/TX位置编号；稳定ID只能使用`KERNEL.*`或未来Registry登记的命名空间ID。显示顺序可变化但不能成为引用。

失败状态统一为`E_CANONICAL_REGISTRY_INVALID`，结果是零生成物、零资格、零部署。反例：若完整设计把CLI映射写在正文而未消费`KERNEL.R06.OUTCOME_FUNCTION`，反向比较必须拒绝，即使输出含正确候选hash。

</NORMATIVE_PAYLOAD>

## 5. R02｜三城批准输入和单文件权威

<a id="section-5"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R02.APPROVAL_INPUT">

唯一批准权威是最终路径中的`ApprovedConfigSetV1`。`ApprovalIntentV1`只是用户指令绑定的精确输入选择，不表示批准、不可被Runtime读取，也不能替代最终文件。

`ApprovalIntentV1`固定包含：

```text
approval_intent_ref
user_directive_ref
created_at_utc
models:
  SHANGHAI: exact candidate_ref, qualification_ref, artifact_ref
  BEIJING: exact candidate_ref, qualification_ref, artifact_ref
  GUANGZHOU: exact candidate_ref, qualification_ref, artifact_ref
intent_payload_hash
```

发布器不得选择“latest”“best”或未列出的候选。它一次取得可信`approval_as_of_utc`，按`SHANGHAI→BEIJING→GUANGZHOU`顺序以`mode=ro`和`query_only=ON`读取三城Registry。每城形成`CityQualificationSnapshotRefV1`：

```text
city
registry_database_uid
database_schema_hash
approval_intent_ref
registry_chain_waterline_seq
registry_chain_waterline_hash
candidate_ref + candidate_payload_hash
qualification_ref + qualification_payload_hash
artifact_ref + artifact_payload_hash
metrics_ref + metrics_payload_hash
qualification_committed_at_utc
source_registry_hash
code_ref
common_policy_hash
```

每个waterline必须是该城`committed_at_utc <= approval_as_of_utc`的最大连续append-only前缀；后到行即使`effective_at`更早也不可进入。三城不声称共享SQLite物理快照；逻辑输入身份是固定三键向量及共同AS-OF。共同`source_registry_hash/code_ref/common_policy_hash`必须逐字一致。

`ApprovalInputSetV1={approval_intent_ref,approval_as_of_utc,models固定三键}`，其hash为：

```text
SHA256("AK2_APPROVAL_INPUT_SET_V1\0" || JCS(ApprovalInputSetV1))
```

`ApprovedConfigSetV1`必须内嵌该对象和hash，并以自身canonical bytes计算`config_set_hash`。发布流程唯一为：同一最终目录创建Runtime不可读临时文件→写入→flush→关闭→重读验证→在已通过能力预检的同卷执行原子no-replace发布到`<config_set_hash>.json`→重读最终文件验证。Registry无批准写权限；禁止`ATTACH`、跨库写事务、批准表和三份批准receipt。

恢复只看最终身份：不存在=未发布；完整字节、文件名hash、InputSet hash全匹配=幂等成功；存在但任一不符=`E_CONFIG_PUBLICATION_COLLISION`且禁止覆盖/删除。平台尚未证明同卷no-replace及断电持久时固定为`E_CONFIG_PUBLICATION_UNPROVEN`，禁止部署。

其他失败状态：`E_APPROVAL_INPUT_INVALID`、`E_APPROVAL_INPUT_INCONSISTENT`、`E_REGISTRY_SNAPSHOT_UNTRUSTED`。任一失败均不产生可消费配置。反例：广州Qualification在AS-OF后提交，即使顺序读取时可见，也必须整体拒绝。

</NORMATIVE_PAYLOAD>

## 6. R03｜M007反保守校准差

<a id="section-6"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R03.M007">

M007正式名称为`LCB_ANTI_CONSERVATISM_SIMULTANEOUS_UCB`，只判断LCB是否高于预注册组内真实发生频率；它不证明模型技能、sharpness、盈利或整体资格。

对城市`c`、目标日`d`、bucket`b`：

```text
L[c,d,t,b] = P_LCB(b|I_t)
Y[c,d,b] ∈ {0,1}
X[c,d,g] = mean over preregistered A[c,d,g] of (L-Y)
Delta[c,g] = E_target_day[X[c,d,g]]
```

`Delta>0`表示反保守，越大越坏；`Delta<=0`只表示未发现反保守。每个`city+target_date`等权且是唯一独立cluster，同日bucket和动态事件不得增加独立样本权重，三城禁止池化。

分组Registry必须在查看标签和候选结果前冻结：完整bucket→group映射、lead-time边界、必需组全集、日内聚合、`N_min`、`alpha`、replicate数`R`、统一阈值`tau_M007`、RNG/seed/分位数/缺失规则及policy hash。任一字段为空时`M007=null`且`M007_POLICY_UNFROZEN`。

每个replicate按target-day cluster有放回抽样，计算：

```text
Z[r] = max_g(delta_hat_boot[r,g] - delta_hat[g])
k = ceil((1-alpha)*(R+1))
q = kth_order_statistic(Z[1..R])
U[g] = delta_hat[g] + q
M007[c] = max_g U[g]
```

`k>R`或任一必需组不可计算时阻断。seed固定为：

```text
SHA256(
 "PWM_M007_TARGET_DAY_CLUSTER_V1" || model_artifact_hash ||
 qualification_policy_hash || city ||
 ordered(target_date,evaluation_event_id,prediction_hash,label_hash) ||
 group_registry_hash || alpha || R
)
```

抽样使用冻结的SHA-256 counter/rejection mapping。判定仅为：`M007<=tau_M007 → WITHIN_BOUND`，否则`VIOLATION`；WITHIN_BOUND不得推出Qualification PASS。全零LCB可能通过本保守性门，但必须由独立技能/非退化指标决定是否有预测价值；禁止把Brier、收益或市场价格塞入M007。过高LCB、稀疏必需组、事后改组、跨城池化、非法值或身份缺失均失败关闭。

</NORMATIVE_PAYLOAD>

## 7. R04｜事实、事件和统计family身份

<a id="section-7"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R04.EVENT_IDENTITY">

每城来源事实有自然键`(city,source_binding_id,source_publication_id,source_revision_id)`和：

```text
source_fact_id = SHA256(
 "V8_SOURCE_FACT_V1\0" || natural_key || canonical_payload_hash
)
```

自然键重复而payload不同=`E_SOURCE_FACT_ID_CONFLICT`；相同payload为幂等。三时间必须分开：`effective_at_utc`来自来源契约，`observed_at_utc`是Evidence首次观察，`committed_at_utc`是append-only提交时间。AS-OF A可见要求`observed_at<=A AND committed_at<=A`，生效另要求`effective_at<=A`；后到事实不得回写过去。

事件原因是封闭对象：`SourceFactV1`、`FreshnessBoundaryV1`、`ConfigIdentityChangeV1`、`WindowBoundaryV1`或`SystemFailureTransitionV1`。每类`effective_at`分别取来源生效时刻、冻结freshness阈值交叉时刻、配置正式发布时刻、07:00/16:00边界或故障Evidence提交时刻；禁止使用任意轮询观察时间。

`RuntimeEventV1`在单城事务中追加：

```text
event_seq=prior+1
parent_event_hash=prior_event_hash
event_id=SHA256("V8_RUNTIME_EVENT_V1\0" || city || cause_type ||
 cause_object_id || transition_kind || before_state_hash ||
 after_state_hash || effective_at_utc)
UNIQUE(city,cause_type,cause_object_id,transition_kind)
```

30秒只触发安全复查；没有新原因对象或状态变化时只更新health，不生成事件、Decision或模型调用。重启必须先重算Event链和head；相同事实只能命中既有事件。

`EvaluationFamilyAdmissionV1`唯一键是`(city,model_artifact_hash,population_id,target_date)`，只在同一事务已有实际评价结果和事件时首次追加；family数量由指定event waterline下该表基数导出，禁止事件计数器充当独立日数。链不连续、原因缺失或family无评价时=`E_EVENT_CHAIN_INVALID`或`E_FAMILY_ADMISSION_INVALID`，仅该城市fail-stop。

</NORMATIVE_PAYLOAD>

## 8. R05｜唯一当前候选与恢复折叠

<a id="section-8"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R05.CURRENT_CANDIDATE">

候选作用域固定为`CandidateScope=(city,target_date,decision_window_id)`。`DecisionV1`、`DecisionInvalidationV1`、`RuntimeEventV1`和`OperationReceiptV1`是append-only Evidence；`CurrentCandidateSlotV1`是可变派生运行对象，不定义历史真相。每个scope恰有一行slot：

```text
scope
current_decision_id|null
config_set_hash
scope_state=OPEN|CLOSED|FAIL_STOP
last_applied_event_seq
last_applied_event_hash
slot_version
updated_at_utc
```

当前候选的唯一谓词同时要求：slot指向Decision；城市/scope/config一致；Decision.state=`YES_CANDIDATE`；没有Invalidation；scope_state=`OPEN`。禁止仅查询“YES且未失效”定义当前。

每个Decision记录`prior_candidate_decision_id|null`。处理影响scope的新事件时，单城唯一writer在`BEGIN IMMEDIATE`中：验证slot与上一event waterline的历史折叠一致→插入Decision→若旧候选存在则插入恰好一条绑定当前event/新Decision的Invalidation→slot指向新YES或NULL→写receipt→提交。窗口关闭和SYSTEM_FAIL_STOP也必须先生成事件，再在同一事务失效旧候选并清slot。

历史折叠从NULL开始按`event_seq,event_hash`执行；每条Decision的prior必须等于折叠当前值，必要Invalidation必须存在且唯一，然后转为新YES ID或NULL。重启先折叠，再逐字段比较slot；不一致=`E_CANDIDATE_HISTORY_DIVERGED`并禁止自动补历史、清slot或猜最新。只有经未来授权的恢复事务才能CAS重建slot并追加receipt。

COMMIT结果不明只按`operation_id+payload_hash`查询receipt：匹配则幂等成功；receipt不存在且对同一数据库的完整事务对账证明没有任何该operation的immutable行时，才由R06/R09决定是否以同一recovery ID重试；结果仍不明或存在部分/冲突记录时`E_CANDIDATE_RECEIPT_CONFLICT`并停止。缺slot、多slot、跨城引用、prior不符或两个逻辑候选均失败关闭。

</NORMATIVE_PAYLOAD>

## 9. R06｜ProcessOutcome闭合函数

<a id="section-9"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R06.OUTCOME_FUNCTION">

退出码只有`0/2/3`。先将每个ErrorCode映射到唯一OutcomeClass，再由Class唯一派生exit、retryable、health和Guardian action：

| OutcomeClass | Exit | Retryable | Health | Guardian action |
|---|---:|---|---|---|
| SUCCESS_CONTINUE | 0 | NO | CITY_HEALTHY | CONTINUE |
| NORMAL_WINDOW_STOP | 0 | NO | CITY_STOPPED_NORMAL | WAIT_NEXT_AUTHORIZED_WINDOW |
| CITY_POLICY_REJECT | 2 | NO | CITY_REJECTED | STOP_CITY_NO_RESPAWN |
| CITY_RETRYABLE | 2 | YES | CITY_DEGRADED | RETRY_SAME_RECOVERY_ID |
| SYSTEM_FAIL_STOP | 3 | NO | SYSTEM_FAILED_STOP | STOP_SYSTEM_NO_RESPAWN |

ErrorCode全集和Class：

```text
SUCCESS_CONTINUE: OK
NORMAL_WINDOW_STOP: E_WINDOW_CLOSED
CITY_POLICY_REJECT: E_QUALIFICATION_REJECTED
CITY_RETRYABLE: E_LEASE_HELD,E_SQLITE_BUSY,E_SOURCE_RETRYABLE
SYSTEM_FAIL_STOP:
 E_CANONICAL_REGISTRY_INVALID,E_APPROVAL_INPUT_INVALID,
 E_APPROVAL_INPUT_INCONSISTENT,
 E_REGISTRY_SNAPSHOT_UNTRUSTED,E_CONFIG_PUBLICATION_COLLISION,
 E_CONFIG_PUBLICATION_UNPROVEN,E_SCHEMA_IDENTITY_INVALID,E_CROSS_CITY,
 E_SOURCE_FACT_ID_CONFLICT,E_EVENT_CHAIN_INVALID,E_FAMILY_ADMISSION_INVALID,
 E_CANDIDATE_SLOT_INVALID,E_CANDIDATE_HISTORY_DIVERGED,
 E_CANDIDATE_RECEIPT_CONFLICT,E_GUARDIAN_LEASE_CONFLICT,
 E_CHILD_IDENTITY_MISMATCH,E_ORPHAN_OR_DUPLICATE_CHILD,
 E_SPAWN_ATTEMPT_AMBIGUOUS,E_ACL_TARGET_INVENTORY_INVALID,
 E_HALF_OPEN_PROBE_CONFLICT,E_PATH_POLICY_INVALID,E_RECOVERY_ID_MISMATCH,
 E_OPERATIONAL_HEALTH_CONFLICT,E_TRANSACTION_RECEIPT_MISSING,
 E_UNCLASSIFIED_EXCEPTION
```

Worker退出前持久化`ProcessOutcome(error_code,scope,recovery_id,payload_hash)` receipt；其余字段必须从Registry派生。Guardian重算后才动作。未知ErrorCode、无/冲突receipt、非0/2/3退出或字段不符一律合成为`E_UNCLASSIFIED_EXCEPTION`并停止系统，禁止猜测重启。R09只能决定合法retry的时机，不能改变本映射。

</NORMATIVE_PAYLOAD>

## 10. 运行、路径和恢复

### 10.1 R07｜Guardian与Worker唯一身份

<a id="section-10-1"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R07.PROCESS_IDENTITY">

只有`ENTRY.EVIDENCE.GUARDIAN`和`ENTRY.RUNTIME.GUARDIAN`拥有固定child control；各自仅控制上海、北京、广州三个逐城Worker，共六个。Worker和其他模块无spawn能力，任何孙进程均失败。

每个`(guardian_kind,city)`至多一个未终结attempt。`GuardianRunEventV1`和`WorkerSpawnAttemptEventV1`为append-only；`LeaseStateV1`是CAS可变运行对象。合法Worker身份完整绑定：

```text
guardian_run_id,guardian_pid,guardian_started_at_utc,
worker_kind,city,spawn_attempt_no,worker_instance_id,
child_pid,child_started_at_utc,interpreter_hash,module_id,
canonical_argv_hash,deployment_manifest_hash,
lease_id,lease_expires_at_utc,recovery_id
```

状态事件顺序唯一为`RESERVED→STARTED→READY→TERMINATED`，或从`RESERVED/STARTED`进入终态`ABANDONED`；终态后不得追加其他状态。Guardian先CAS取得自身lease并追加RESERVED，再按Registry固定argv启动，取得PID后追加STARTED；Worker只有完整身份和未过期lease匹配才能追加READY/progress receipt。

恢复顺序：验证Guardian lease→读取每城唯一未终结attempt→lease未过期则RECOVERY_WAIT→到期后若旧child存在、身份不可读取或出现两个匹配child则fail-stop→确认旧child不存在后追加ABANDONED终态→仅在旧attempt终结后创建`spawn_attempt_no+1`。禁止按PID或模块名单独认领/重启。

失败码为`E_GUARDIAN_LEASE_CONFLICT`、`E_CHILD_IDENTITY_MISMATCH`、`E_ORPHAN_OR_DUPLICATE_CHILD`、`E_SPAWN_ATTEMPT_AMBIGUOUS`。Windows Job Object和具体lease时长留待完整设计，但字段未冻结时不得运行。

</NORMATIVE_PAYLOAD>

### 10.2 R08｜ACL和数据库精确目标

<a id="section-10-2"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R08.PATH_INVENTORY">

目录恰好10个：

```text
release_root
runtime_root=release_root/runtime
system_root=runtime_root/system
cities_root=runtime_root/cities
city_root.SHANGHAI=cities_root/SHANGHAI
city_root.BEIJING=cities_root/BEIJING
city_root.GUANGZHOU=cities_root/GUANGZHOU
config_root=runtime_root/config
status_root=runtime_root/status
locks_root=runtime_root/locks
```

数据库文件恰好10个：`system_root/system.db`及每城`evidence.db,registry.db,runtime.db`。每个target必须有`target_id,canonical_absolute_path,parent_target_id,object_kind,city|null,database_role|null,path_policy_hash`。数据库目标的parent必须是对应system/city root。

部署前按target_id排序验证精确集合、绝对路径、父子关系、对象种类、城市/角色和PathPolicy hash；缺失、重复、越界、错父或第21项出现均为`E_ACL_TARGET_INVENTORY_INVALID`，禁止生成ACL计划、建库、装任务或回滚。具体ACE/owner/inheritance保持`ACL_RIGHTS_MATRIX_NOT_DESIGNED`并阻断部署，不允许默认值。

</NORMATIVE_PAYLOAD>

### 10.3 R09｜health、breaker、PathPolicy和恢复

<a id="section-10-3"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.R09.RECOVERY_STATE">

全局可变运行对象仅为：`CurrentCandidateSlotV1`、`LeaseStateV1`和`OperationalHealthV1`；全部历史事件与receipt append-only。OperationalHealth键为`(component,city|null)`，字段：

```text
breaker_state=CLOSED|OPEN|HALF_OPEN|FAIL_STOP
health_state=CITY_HEALTHY|CITY_STOPPED_NORMAL|CITY_REJECTED|CITY_DEGRADED|SYSTEM_FAILED_STOP
consecutive_retryable_failures
open_until_utc|null
active_probe_attempt_id|null
active_lease_id|null
last_success_receipt_id|null
recovery_id
version
updated_at_utc
```

`POLICY.PATHS`是R08全部target、允许角色、数据库打开模式、canonical base、volume identity、policy hash和recovery ID的封闭Payload。不存在`worker_health/evidence_health`或位置型TX编号。

状态机唯一为：

```text
CLOSED --达到冻结失败阈值--> OPEN(open_until)
OPEN --trusted_now>=open_until且CAS成功--> HALF_OPEN(unique probe+lease)
HALF_OPEN --同probe/lease成功receipt--> CLOSED(reset count)
HALF_OPEN --retryable失败或probe lease到期--> OPEN
ANY --身份/Path/DB/receipt/事务不可重试失败--> FAIL_STOP
FAIL_STOP --无自动转换--> FAIL_STOP
```

OPEN禁止正常spawn；HALF_OPEN只允许唯一probe attempt。启动恢复顺序：验证PathPolicy→读取最后提交health及receipt→核对/终结过期lease→按事件重建唯一breaker状态。多probe、未知路径、receipt缺失或版本冲突均系统fail-stop。退出`FAIL_STOP`需要未来独立授权的恢复事务和相同`recovery_id`，本Kernel不授予。

阈值、open时长、lease时长未由完整policy冻结时，Preflight必须失败；不得用默认值。失败码使用R06已登记的R09 codes。

</NORMATIVE_PAYLOAD>

## 11. 受限修订反例矩阵

| 根问题 | 必须拒绝的反例 | 唯一规范 |
|---|---|---|
| R01 | Registry外第二份CLI/Schema规则仍被生成器接受 | KERNEL.R01.CANONICAL_CLOSURE |
| R02 | 三城不同AS-OF或不同policy仍发布ConfigSet | KERNEL.R02.APPROVAL_INPUT |
| R03 | 过高LCB、未冻阈值或稀疏必需组仍通过M007 | KERNEL.R03.M007 |
| R04 | 同一来源revision重启后产生第二事件/family | KERNEL.R04.EVENT_IDENTITY |
| R05 | slot损坏后D1、D2同时成为当前候选 | KERNEL.R05.CURRENT_CANDIDATE |
| R06 | lease冲突由不同Guardian解释成不同动作 | KERNEL.R06.OUTCOME_FUNCTION |
| R07 | Guardian崩溃后按模块名生成第二Worker | KERNEL.R07.PROCESS_IDENTITY |
| R08 | 9个目录冒充10个或数据库挂到错误父目录 | KERNEL.R08.PATH_INVENTORY |
| R09 | 两个Guardian同时从OPEN进入HALF_OPEN | KERNEL.R09.RECOVERY_STATE |

## 12. 已收敛B03—B08的继承

### 12.1 B03

<a id="section-12-b03"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.INHERITED.B03">

批准过程只读三城Registry并发布一个最终文件；禁止`ATTACH`、跨库写事务和三城批准表。文件能力未证明时失败关闭。

</NORMATIVE_PAYLOAD>

### 12.2 B04

<a id="section-12-b04"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.INHERITED.B04">

所有登记为`IMMUTABLE_AFTER_INSERT`的表必须同时生成无条件拒绝UPDATE和DELETE的`BEFORE` triggers；应用层约定和`ON DELETE RESTRICT`不能替代。可变对象仅为R09封闭集合。

</NORMATIVE_PAYLOAD>

### 12.3 B05

<a id="section-12-b05"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.INHERITED.B05">

每库恰有一个不可修改`DatabaseIdentity(singleton=1,database_uid,city,database_role,schema_version,created_at)`；System只允许`SYSTEM/REGISTRY`，三城各允许EVIDENCE/REGISTRY/RUNTIME，共10库。每业务行带`identity_key,city`复合FK及城市trigger，连接必须`foreign_keys=ON`并核验DatabaseIdentity、Manifest和路径一致。跨城企图零写并系统fail-stop。

</NORMATIVE_PAYLOAD>

### 12.4 B06

<a id="section-12-b06"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.INHERITED.B06">

Metrics属性名固定为`M001`至`M018`，全部required且`additionalProperties=false`；任意18个其他名称不得通过。

</NORMATIVE_PAYLOAD>

### 12.5 B07

<a id="section-12-b07"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.INHERITED.B07">

Preflight固定`PF001`—`PF016`，Deployment Verification固定`DV001`—`DV008`；必须完整、唯一、无额外成员。`passed`只由所有必需检查PASS派生；空、UNKNOWN、SKIP、缺项或任一FAIL均为false。

</NORMATIVE_PAYLOAD>

### 12.6 B08任务

<a id="section-12-b08-task"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.INHERITED.B08_TASK">

任务恰好三项：Evidence 07:00/11h、Runtime 07:00/11h、Observer 06:55/11h10m；分别绑定唯一固定入口。均`Enabled=false,InteractiveToken,LeastPrivilege,IgnoreNew,StartWhenAvailable=false`。重复角色、漏项、错入口、错URI或错时间均失败。ACL目标由R08唯一拥有。

</NORMATIVE_PAYLOAD>

## 13. 关闭关系和未证明边界

```text
B01→R01
B02→R02
B03→INHERITED.B03+R02
B04→INHERITED.B04+R05+R09
B05→INHERITED.B05
B06→INHERITED.B06
B07→INHERITED.B07
B08→INHERITED.B08_TASK+R08
B09→R03
B10→R04
B11→R05
B12→R06
B13→R07
B14→R08
B15→R09
N01→R01; N02→R02; N03→R05+R09; N04→R08; N05→R04; N06→R06+R09
```

<a id="section-13-boundaries"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.DEFERRED.BOUNDARIES">

仍未证明且必须失败关闭：具体模型/阈值、完整文件/类/函数/Schema/DDL、SQLite实际反例、Windows文件持久性、ACE rights、任务XML、真实SID绑定、安装/恢复/回滚、实现、测试、Git、部署和运行身份。它们只能在Kernel第二次审查PASS后的独立完整设计阶段处理。

</NORMATIVE_PAYLOAD>

## 14. 冻结前状态

<a id="section-14"></a>
<NORMATIVE_PAYLOAD rule_id="KERNEL.LIFECYCLE.FREEZE">

本文件只有在作者自检完成、三成员hash进入新Manifest后才变为`AK2_CANDIDATE_FROZEN`。冻结后T00和咨询岗位不得修改；下一步也不能自动发生，必须等待用户独立授权T01第二次Kernel审查。

</NORMATIVE_PAYLOAD>
