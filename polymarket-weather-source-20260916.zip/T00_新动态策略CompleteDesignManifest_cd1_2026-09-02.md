# V8 Complete Design Manifest｜cd1｜2026-09-02

## 1. 候选身份

```text
CANDIDATE_ID=T00-WEATHER-V8-COMPLETE-DESIGN-CD1-20260902
SCHEMA_VERSION=PWM_COMPLETE_DESIGN_REGISTRY_V1
AS_OF=2026-09-02T15:38:59.1091585Z
SOURCE_BRANCH=codex/handoff-baseline-20260809
SOURCE_HEAD=13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
SOURCE_KERNEL=ak2
SOURCE_KERNEL_SHA256=e01d30534b8b1de77ac4c426d925dda222a0c772540fb09b6425d39fab11308d
COMPLETE_DESIGN_CANDIDATE_FROZEN=YES
COMPLETE_DESIGN_INDEPENDENTLY_VALIDATED=NO
COMPLETE_DESIGN_ACCEPTED=NO
IMPLEMENTATION_AUTHORIZED=NO
TEST_EXECUTION_AUTHORIZED=NO
GIT_WRITE_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
```

## 2. 冻结成员

| 文件 | 角色 | SHA-256 |
|---|---|---|
| `T00_V8_CompleteDesign任务合同_cd1_2026-09-02.md` | 授权、范围、阶段边界；非业务规范源 | `8a4f1915558a5cd20ccff511875a4ddbcc3d00ce7d93361b1bde95cd42e7be36` |
| `T00_新动态策略CompleteDesign规范_cd1_2026-09-02.json` | 13项Finding的唯一机器可读详细规范源 | `96f01d9f9639fb6f8fca5ada9188cdcd21aa29e68023f40e93a0c7aa06cce89a` |

Manifest不复制JSON业务规则。任何成员字节变化都会产生新候选身份；不得回写cd1后仍沿用本Manifest。

## 3. Finding闭合覆盖

```text
TOTAL_DEFERRED_COMPLETE_DESIGN_FINDINGS=13
UNIQUE_DESIGN_WORK_PACKAGES=6

CD-01=B01,R01,N01
CD-02=B06
CD-03=B11,R05
CD-04=B12,R06,N06
CD-05=B13,R07
CD-06=B15,R09
```

JSON中的`authority_boundary.normative_for`与`finding_closure`键集必须精确等于上述13项。未进入本候选的后续阶段事项保持延期。

## 4. 专业输入与T00裁决

| 岗位 | 使用范围 | T00处理 |
|---|---|---|
| T01 | B01/R01/N01 | 采用单一机器规范、固定编码/hash、生成与反向消费边界 |
| STRATEGY | B06 | 采用逐城、target-day等权、首个合格事件/首个YES候选分离及M001—M018完整语义 |
| BE | B11/R05、B12/R06/N06 | 采用commit结果四分支、零副作用证明、唯一ErrorCode映射 |
| OPS | B13/R07、B15/R09 | 采用Lease fence/CAS、唯一probe、Breaker Guard与逻辑PathPolicy |

OPS额外提出的R02文件发布细节不属于本次13项，T00已排除，未写入cd1。QA未参与候选修改，以保留后续独立性。

## 5. 作者级静态一致性检查

以下检查只验证设计载体结构，不是代码测试、实现验收或部署验收：

```text
STRICT_JSON_PARSE_NO_DUPLICATE_KEYS=PASS
METRIC_ID_EXACT_SET_M001_TO_M018=PASS
METRIC_COUNT=18
FINDING_EXACT_SET=PASS
FINDING_COUNT=13
ERROR_MAPPING_TOTAL=PASS
ERROR_CODE_COUNT=32
OUTCOME_CLASS_COUNT=5
NO_ERROR_ALIAS_KEYS=PASS
BREAKER_GUARD_COUNT=9
STAGE_BOUNDARY_FLAGS=PASS
```

关键作者裁决：

- 旧恒真M007未继承；M007只引用ak2 `KERNEL.R03.M007`；
- M018比较范围排除M018自身、外层报告hash和生成时间，避免自引用；
- `effect_manifest_hash`排除自身字段，避免receipt hash循环；
- 数值阈值保持未冻结并阻断资格；未进行回测、盈利或edge验证；
- `retryable_failure_threshold=3`、`breaker_open_seconds=300`沿用既有R1运营输入；Lease 60/90秒及续租20/30秒是cd1候选的唯一设计值，必须由独立QA审查，尚不是运行配置；
- PathPolicy只冻结逻辑字段与失败语义；物理路径、ACL和任务配置继续属于Deployment Acceptance。

## 6. 阶段状态与停止点

```text
COMPLETE_DESIGN_DRAFTED=YES
COMPLETE_DESIGN_CANDIDATE_FROZEN=YES
AUTHOR_STATIC_CONSISTENCY_CHECK=PASS
INDEPENDENT_QA_REVALIDATION=NOT_RUN
COMPLETE_DESIGN_STAGE_COMPLETE=NO
READY_FOR_IMPLEMENTATION=NO
```

下一步只能是经用户独立授权的Complete Design独立QA复验。不得根据本Manifest自动开始实现、测试、Git写入、部署、Shadow、Paper或Live。
