"""Focused, side-effect-free tests for Strategy Engine V1.

This asset is not evidence that tests ran. It uses no SQL, database, network,
order, paper/live trading, E3, or deployment path.
"""

from __future__ import annotations

import unittest
from datetime import date, timedelta
from decimal import Decimal

from strategy_v8.canonical import hash_v1
from strategy_v8.contracts import City
from strategy_engine.backtest.engine import BacktestInputDay, WalkForwardBacktestV1
from strategy_engine.calibration.pav import PAVCalibratorV1, PAVPoint, build_oof_prediction
from strategy_engine.data.labels import WEATHER_LABEL_POLICY_HASH, WeatherLabel
from strategy_engine.data.normalization import HistoricalDataAdapter, NormalizedDay, SourceAnchorSetV1, SourceAnchorV1, SOURCE_BINDING_REGISTRY_BY_ID, SOURCE_BINDING_REGISTRY_HASH
from strategy_engine.data.records import (
    AskLevel, ForecastInput, MarketBook, MarketBookInput, ObservationInput,
    TemperatureUnit, Visibility, normalized_fact_id_v1, source_fact_id_v1, temperature_c,
)
from strategy_engine.data.evidence import FeeEvidenceV1, FormalSettlementV1, MarketRuleEvidenceV1
from strategy_engine.decision.engine import DecisionAction, DeltaPolicyV1, decide_buy_yes
from strategy_engine.engine import ApprovedConfigSetV1, StrategyConfigV1
from strategy_engine.features.engine import build_feature_bundle
from strategy_engine.models.residual import EmpiricalResidualModelV1, TemperatureBucket, TrainingSample
from strategy_engine.reports.engine import build_strategy_report
from strategy_engine.risk.cost import CostPolicyV1, compute_c_executable
from strategy_engine.risk.lcb import BootstrapPolicyV1, bootstrap_lcb


H64 = "0" * 64
CITY = City.SHANGHAI
DAY = date(2026, 8, 1)
AS_OF = "2026-08-01T00:00:00.000000Z"  # 08:00 Asia/Shanghai


def visibility(value: str = "2026-07-31T23:00:00.000000Z") -> Visibility:
    return Visibility(value, value, value)


def buckets() -> tuple[TemperatureBucket, ...]:
    return (TemperatureBucket("LT_30", None, Decimal(30)), TemperatureBucket("GE_30", Decimal(30), None))


def sample(day_number: int, residual: str) -> TrainingSample:
    target = date(2026, 7, day_number)
    return TrainingSample(CITY, target, 28800, Decimal(30), day(target).source_anchor_set, label(target, str(Decimal(30) + Decimal(residual))))


def day(target: date = DAY) -> NormalizedDay:
    as_of = f"{target.isoformat()}T00:00:00.000000Z"
    visibility_value = f"{target.isoformat()}T00:00:00.000000Z"
    forecast_fact = hash_v1("PWM.TEST.FORECAST_FACT", {"target_date": target.isoformat()})
    forecast_projection = hash_v1("PWM.IIC2.NORMALIZED_PROJECTION.V1", {"projection_kind": "FORECAST_HIGH_C_MILLI", "canonical_projection": {"city": CITY.value, "target_date": target.isoformat(), "local_second": 28800, "forecast_high_c_milli": 30000}})
    observation = observation_input(visibility_value, Decimal(29), TemperatureUnit.CELSIUS, visibility(visibility_value))
    observation_projection = observation.canonical_projection_hash
    observation_fact = observation.normalized_fact_id
    observation_facts = (observation_fact,)
    forecast_anchor = SourceAnchorV1("weatherol_shanghai/weatherol_d0", "publication", 1, H64, H64, forecast_fact, forecast_projection, visibility_value, visibility_value, visibility_value)
    observation_anchor = SourceAnchorV1(observation.source_binding_id, observation.source_publication_id, observation.source_revision_rank, observation.source_revision_id, observation.source_fact_id, observation.normalized_fact_id, observation_projection, visibility_value, visibility_value, visibility_value)
    anchors = tuple(sorted((forecast_anchor, observation_anchor), key=lambda item: (item.source_binding_id, item.source_publication_id, item.source_revision_rank, item.source_revision_id, item.source_fact_id)))
    bindings = tuple(sorted(("weatherol_shanghai/weatherol_d0", "aviationweather_metar/ZSPD")))
    contracts = tuple(sorted((SOURCE_BINDING_REGISTRY_BY_ID[(CITY.value, "weatherol_shanghai/weatherol_d0")]["normalization_contract_hash"], SOURCE_BINDING_REGISTRY_BY_ID[(CITY.value, "aviationweather_metar/ZSPD")]["normalization_contract_hash"])))
    anchor_object = SourceAnchorSetV1.create(CITY, target, as_of, as_of, SOURCE_BINDING_REGISTRY_HASH, contracts, bindings, anchors)
    anchor = anchor_object.source_anchor_set_hash
    payload = {"city": CITY.value, "target_date": target.isoformat(), "as_of_utc": as_of, "local_second": 28800, "forecast_high_c": "30", "current_observed_max_c": "29", "forecast_fact_id": forecast_fact, "observation_fact_ids": list(observation_facts), "source_anchor_set_hash": anchor}
    return NormalizedDay(CITY, target, as_of, 28800, Decimal(30), Decimal(29), forecast_fact, observation_facts, anchor, hash_v1("PWM.STRATEGY_ENGINE_V1.NORMALIZED_DAY", payload), anchor_object, (observation,))


def forecast_input(rank: int, value: Decimal, unit: TemperatureUnit, seen: Visibility) -> ForecastInput:
    revision = hash_v1("V8_SOURCE_REVISION_ID_V1", {"schema_version":"SourceRevisionIdentityV1","rank_scheme_id":"WEATHEROL_D0_LOCAL_REPORT_MINUTE_V1","source_revision_rank":rank,"provider_revision_token":f"2026-08-01T00:0{rank}","source_time":None})
    source_fact = source_fact_id_v1(CITY, "weatherol_shanghai/weatherol_d0", "p", revision, H64)
    high_c = temperature_c(value, unit)
    projection = {"city": CITY.value, "target_date": DAY.isoformat(), "local_second": 28800, "forecast_high_c_milli": int(high_c * 1000)}
    projection_hash = hash_v1("PWM.IIC2.NORMALIZED_PROJECTION.V1", {"projection_kind": "FORECAST_HIGH_C_MILLI", "canonical_projection": projection})
    contract_hash = SOURCE_BINDING_REGISTRY_BY_ID[(CITY.value, "weatherol_shanghai/weatherol_d0")]["normalization_contract_hash"]
    return ForecastInput(CITY, DAY, 28800, "weatherol_shanghai/weatherol_d0", "p", revision, rank, value, unit, H64, seen, "WEATHEROL_D0_LOCAL_REPORT_MINUTE_V1", f"2026-08-01T00:0{rank}", None, source_fact, H64, contract_hash, projection_hash)


def observation_input(report_time: str, value: Decimal, unit: TemperatureUnit, seen: Visibility) -> ObservationInput:
    from datetime import datetime, timezone
    report_datetime = datetime.strptime(report_time, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)
    elapsed = report_datetime - datetime(1970, 1, 1, tzinfo=timezone.utc)
    rank = elapsed.days * 86_400_000_000 + elapsed.seconds * 1_000_000 + elapsed.microseconds
    revision = hash_v1("V8_SOURCE_REVISION_ID_V1", {"schema_version": "SourceRevisionIdentityV1", "rank_scheme_id": "AVIATIONWEATHER_METAR_REPORT_TIME_V1", "source_revision_rank": rank, "provider_revision_token": f"ZSPD:METAR:{report_time}", "source_time": report_time})
    source_fact = source_fact_id_v1(CITY, "aviationweather_metar/ZSPD", "metar-publication", revision, H64)
    temp_c = temperature_c(value, unit)
    projection = {"city": CITY.value, "station": "ZSPD", "report_type": "METAR", "report_time_utc": report_time, "temperature_c_milli": int(temp_c * 1000)}
    projection_hash = hash_v1("PWM.IIC2.NORMALIZED_PROJECTION.V1", {"projection_kind": "METAR_SPECI_TEMPERATURE_C_MILLI", "canonical_projection": projection})
    contract_hash = SOURCE_BINDING_REGISTRY_BY_ID[(CITY.value, "aviationweather_metar/ZSPD")]["normalization_contract_hash"]
    return ObservationInput(CITY, "ZSPD", "METAR", report_time, value, unit, source_fact, seen, "aviationweather_metar/ZSPD", "metar-publication", revision, rank, H64, H64, contract_hash, projection_hash)


def book(target: date = DAY) -> MarketBook:
    as_of = f"{target.isoformat()}T00:00:00.000000Z"
    source = MarketBookInput(CITY, target, "market", "yes", "book-publication", H64, as_of, visibility(f"{target.isoformat()}T00:00:00.000000Z"), Decimal("0.35"), (AskLevel(Decimal("0.40"), Decimal(4), "l1"), AskLevel(Decimal("0.45"), Decimal(10), "l2")))
    return HistoricalDataAdapter((), (), (source,)).market_book(CITY, target, as_of)


def label(target: date, final_max: str) -> WeatherLabel:
    start_utc = f"{(target - timedelta(days=1)).isoformat()}T16:00:00.000000Z"
    end_utc = f"{target.isoformat()}T16:00:00.000000Z"
    frozen_utc = f"{(target + timedelta(days=1)).isoformat()}T16:00:00.000000Z"
    observation_ids = (hash_v1("PWM.TEST.LABEL_OBSERVATION", {"target_date": target.isoformat()}),)
    payload = {"schema_version": "WeatherLabelV1", "city": CITY.value, "target_date": target.isoformat(), "station": "ZSPD", "weather_label_policy_hash": WEATHER_LABEL_POLICY_HASH, "ordered_observation_normalized_fact_ids": list(observation_ids), "first_report_time_utc": start_utc, "last_report_time_utc": f"{target.isoformat()}T15:30:00.000000Z", "maximum_observed_gap_seconds": 5400, "gap_reason": None, "coverage_complete": True, "final_max_c_milli": int(Decimal(final_max) * 1000), "freeze_cutoff_utc": frozen_utc, "committed_at_utc": frozen_utc, "label_status": "FROZEN"}
    return WeatherLabel(CITY, target, "ZSPD", start_utc, end_utc, frozen_utc, Decimal(final_max), start_utc, f"{target.isoformat()}T15:30:00.000000Z", 5400, observation_ids, hash_v1("PWM.IIC2.WEATHER_LABEL.V1", payload))


def fee_rule(target: date = DAY):
    as_of = f"{target.isoformat()}T00:00:00.000000Z"
    visible = visibility(as_of)
    return (
        FeeEvidenceV1.create("market", "yes", True, Decimal("0.02"), Decimal(0), Decimal("0.0001"), visible, None, previous_evidence=None, fee_publication_id="fee-publication", fee_publication_hash=H64),
        MarketRuleEvidenceV1.create("market", "yes", Decimal("0.01"), Decimal(1), Decimal("0.0001"), visible, None, previous_evidence=None, source_rule_publication_id="rule-publication", source_rule_publication_hash=H64, source_book_hash=book(target).source_book_hash),
    )


def settlement(target: date, outcome: bool) -> FormalSettlementV1:
    settled = f"{(target + timedelta(days=2)).isoformat()}T00:00:00.000000Z"
    return FormalSettlementV1.create(CITY, target, "market", "yes", "GE_30", outcome, settled, "settlement-publication", H64, visibility(settled))


def config(target: date = DAY, *, minimum_training: int = 2) -> StrategyConfigV1:
    delta_policy = DeltaPolicyV1(CITY, Decimal("0.02"), H64, "2026-01-01T00:00:00.000000Z", "2027-01-01T00:00:00.000000Z")
    bootstrap_policy = BootstrapPolicyV1(CITY, Decimal("0.8"), 20, minimum_training, 4)
    cost_policy = CostPolicyV1(CITY, "cost", "1", Decimal(5), 1, Decimal("0.01"), Decimal("0.01"), False, 86_400_000, 86_400_000, 86_400_000)
    binding = ApprovedConfigSetV1.create(CITY, buckets(), "GE_30", "market", "yes", delta_policy, bootstrap_policy, cost_policy, minimum_training, 1)
    return StrategyConfigV1(CITY, buckets(), "GE_30", "market", "yes", delta_policy, minimum_training, 1, bootstrap_policy, cost_policy, binding)


class StrategyEngineV1Tests(unittest.TestCase):
    def test_normalization_converts_units_and_excludes_future_revision(self) -> None:
        forecasts = (
            forecast_input(1, Decimal(86), TemperatureUnit.FAHRENHEIT, visibility("2026-07-31T22:00:00.000000Z")),
            forecast_input(2, Decimal(31), TemperatureUnit.CELSIUS, visibility()),
            forecast_input(3, Decimal(99), TemperatureUnit.CELSIUS, visibility("2026-08-01T01:00:00.000000Z")),
        )
        observations = (observation_input("2026-07-31T23:30:00.000000Z", Decimal("82.4"), TemperatureUnit.FAHRENHEIT, visibility()),)
        markets = (MarketBookInput(CITY, DAY, "market", "yes", "b1", H64, "2026-07-31T23:50:00.000000Z", visibility(), Decimal("0.35"), (AskLevel(Decimal("0.40"), Decimal(10), "l1"),)),)
        adapter = HistoricalDataAdapter(forecasts, observations, markets)
        normalized = adapter.normalize_day(CITY, DAY, AS_OF)
        self.assertEqual(normalized.forecast_high_c, Decimal(31))
        self.assertEqual(normalized.current_observed_max_c, Decimal("28.0"))
        self.assertEqual(adapter.market_book(CITY, DAY, AS_OF).market_id, "market")

    def test_dynamic_window_is_half_open(self) -> None:
        with self.assertRaisesRegex(ValueError, "outside"):
            HistoricalDataAdapter((), (), ()).normalize_day(CITY, DAY, "2026-08-01T08:00:00.000000Z")

    def test_probability_market_separation_pav_and_lcb_determinism(self) -> None:
        model = EmpiricalResidualModelV1.fit(CITY, 28800, (sample(1, "-2"), sample(2, "1"), sample(3, "3")), minimum_samples=3)
        features = build_feature_bundle(day(), book(), model.residuals)
        vector = model.predict(day(), features.weather, buckets())
        self.assertEqual(sum(vector.probabilities), Decimal(1))
        points = (
            PAVPoint(build_oof_prediction(model, day(date(2026, 7, 10)), build_feature_bundle(day(date(2026, 7, 10)), book(date(2026, 7, 10)), model.residuals).weather, buckets(), 0, label(date(2026, 7, 10), "30")), Decimal(1), label(date(2026, 7, 10), "30")),
            PAVPoint(build_oof_prediction(model, day(date(2026, 7, 11)), build_feature_bundle(day(date(2026, 7, 11)), book(date(2026, 7, 11)), model.residuals).weather, buckets(), 0, label(date(2026, 7, 11), "28")), Decimal(1), label(date(2026, 7, 11), "28")),
            PAVPoint(build_oof_prediction(model, day(date(2026, 7, 12)), build_feature_bundle(day(date(2026, 7, 12)), book(date(2026, 7, 12)), model.residuals).weather, buckets(), 0, label(date(2026, 7, 12), "28")), Decimal(1), label(date(2026, 7, 12), "28")),
        )
        pav = PAVCalibratorV1.fit(points, model_policy_hash=model.model_policy_hash)
        self.assertEqual(pav.calibration_hash, PAVCalibratorV1.fit(reversed(points), model_policy_hash=model.model_policy_hash).calibration_hash)
        policy = BootstrapPolicyV1(CITY, Decimal("0.8"), 20, 3, 1)
        first = bootstrap_lcb(model, day(), features.weather, buckets(), pav, policy, evaluation_identity="e1", family_id="family", evaluation_ordinal=1, event_seq=1, event_at_utc=AS_OF)
        second = bootstrap_lcb(model, day(), features.weather, buckets(), pav, policy, evaluation_identity="e1", family_id="family", evaluation_ordinal=1, event_seq=1, event_at_utc=AS_OF)
        self.assertEqual(first, second)

    def test_depth_cost_and_strict_delta(self) -> None:
        fee, rule = fee_rule()
        policy = config().cost_policy
        cost = compute_c_executable(book(), fee, rule, policy, as_of_utc=AS_OF, approved_config_set_hash=H64)
        self.assertGreater(cost.liquidity_cost, Decimal(0))
        delta = Decimal("0.10")
        result = decide_buy_yes(city=CITY, target_date=DAY, event_id="e1", bucket_id="GE_30", p_lcb=cost.c_executable + delta, cost=cost, delta=delta, delta_policy_hash=H64, confidence_score=Decimal("0.5"), dependency_hashes=(H64,))
        self.assertIs(result.action, DecisionAction.NO_ACTION)

    def test_walk_forward_warmup_and_report(self) -> None:
        strategy_config = config(minimum_training=3)
        weather_label = label(DAY, "31")
        fee, rule = fee_rule()
        backtest = WalkForwardBacktestV1(strategy_config).run((BacktestInputDay("e1", 1, day(), weather_label, book(), fee, rule, settlement(DAY, True), Decimal(1)),))
        self.assertEqual(backtest.results[0].status, "INSUFFICIENT_PRIOR_TRAINING_DAYS")
        report = build_strategy_report(backtest)
        self.assertEqual(report.evaluated_days, 0)
        self.assertIsNone(report.prediction_accuracy)

    def test_walk_forward_reaches_prediction_decision_and_report(self) -> None:
        strategy_config = config(minimum_training=2)
        dates = (date(2026, 7, 1), date(2026, 7, 4), date(2026, 7, 7), date(2026, 7, 10))
        records = tuple(
            BacktestInputDay(f"event-{target}", 1, day(target), label(target, "31" if index % 2 else "29"), book(target), *fee_rule(target), settlement(target, index % 2 == 1), Decimal(1))
            for index, target in enumerate(dates)
        )
        backtest = WalkForwardBacktestV1(strategy_config).run(records)
        evaluated = tuple(item for item in backtest.results if item.status == "EVALUATED")
        self.assertEqual(len(evaluated), 1)
        self.assertIsNotNone(evaluated[0].evaluation)
        self.assertIsNotNone(evaluated[0].outcome_yes)
        report = build_strategy_report(backtest)
        self.assertEqual(report.evaluated_days, 1)
        self.assertIsNotNone(report.brier_score)
        self.assertIsNotNone(report.average_confidence)


if __name__ == "__main__":
    unittest.main()
