"""Research-only collector for every active Polymarket highest-temperature city.

It never places orders. Each supported market must name a Wunderground airport
station in its resolution source; the station's ICAO coordinate drives forecasts.
"""
from __future__ import annotations

import asyncio
import argparse
import hashlib
import json
import logging
import math
import os
import re
import sqlite3
import stat
import time as clock
from dataclasses import dataclass
from datetime import UTC, date, datetime, time, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qsl, urlparse

import airportsdata
import httpx
from ui_events import ensure_research_events
from db_paths import REALTIME_DB
from runtime_status import WorkerProgressPublisher
from be05_v3_settlement import append_resolution_evidence, ensure_settlement_schema

GAMMA = "https://gamma-api.polymarket.com"
AIRPORTS = airportsdata.load("ICAO")
CONTRACT_DATE_PATTERN = r"(?P<month>[A-Za-z]+) (?P<day>\d{1,2})(?:, (?P<year>\d{4}))?"
EVENT_CONTRACT_RE = re.compile(
    rf"^(?:Will the )?highest temperature in (?P<city>[A-Za-z ]+?) on {CONTRACT_DATE_PATTERN}\??$",
    re.IGNORECASE,
)
MARKET_CONTRACT_RE = re.compile(
    rf"^Will the highest temperature in (?P<city>[A-Za-z ]+?) be (?P<bucket>.+?) on {CONTRACT_DATE_PATTERN}\??$",
    re.IGNORECASE,
)
MARKET_ID_RE = re.compile(r"[A-Za-z0-9_.:-]{1,128}")
TEMPERATURE_BUCKET_RE = re.compile(
    r"^-?\d+(?:\.\d+)?\s*°?\s*C(?:\s+or\s+(?:higher|lower|below))?$",
    re.IGNORECASE,
)
ASCII_TOKEN_RE = re.compile(r"^[0-9]+$")
RESEARCH_MARKET_SCHEMA = "research_market_attribution.v1"
RESEARCH_MANIFEST_MEMBER_FIELDS = (
    "schema", "token_id", "market_id", "city", "city_scope", "station",
    "target_date", "outcome", "event_id", "source_scan_id",
    "attribution_status",
)
_RESEARCH_CANDIDATE_INTERNAL_FIELDS = {
    "scan_id", "scanned_at", "event_title", "market_question",
    "resolution_source", "resolution_source_host", "bucket_label", "active",
    "closed", "reason_code", "_query_city", "_query_target_date",
    "_outcome_token_bindings", "_gamma_token_evidence",
}
# City scope is collector metadata only.  BE-06 is the independent, mandatory
# trading gate; do not derive any trading permission from this mapping.
CITY_ROLES = {
    "beijing": "formal",
    "shanghai": "formal",
    "chengdu": "formal",
    "guangzhou": "formal",
    "shenzhen": "research_only",
    "wuhan": "research_only",
    "chongqing": "research_only",
}
RETIRED_CITY_KEYS = frozenset({"jinan", "qingdao", "zhengzhou"})
# Historical settlement identity is deliberately wider than the active city
# matrix.  Retired cities remain readable for pre-retirement resolution and
# ledger audit, but can no longer be discovered or produce new forecasts.
CITY_SETTLEMENT_STATIONS = {
    "beijing": "ZBAA",
    "shanghai": "ZSPD",
    "chengdu": "ZUUU",
    "guangzhou": "ZGGG",
    "shenzhen": "ZGSZ",
    "wuhan": "ZHHH",
    "chongqing": "ZUCK",
    "jinan": "ZSJN",
    "qingdao": "ZSQD",
    "zhengzhou": "ZHCC",
}
ALLOWED_CITIES = set(CITY_ROLES)
WEATHEROL_AIRPORTS = {
    "beijing": ("JCCN100005", "https://weatherol.cn/api/getData?aid=JCCN100005"),
    "shanghai": ("JCCN100117", "https://weatherol.cn/api/getData?aid=JCCN100117"),
    "chengdu": ("JCCN100160", "https://weatherol.cn/api/getData?aid=JCCN100160"),
    "guangzhou": ("JCCN100037", "https://weatherol.cn/api/getData?aid=JCCN100037"),
    "shenzhen": ("JCCN100048", "https://weatherol.cn/api/getData?aid=JCCN100048"),
    "wuhan": ("JCCN100054", "https://weatherol.cn/api/getData?aid=JCCN100054"),
    "chongqing": ("JCCN100139", "https://weatherol.cn/api/getData?aid=JCCN100139"),
}
PRIMARY_WEATHEROL_CITIES = frozenset({"Beijing", "Shanghai", "Chengdu", "Guangzhou", "Shenzhen"})
ADDITIONAL_WEATHEROL_CITIES = frozenset({"Wuhan", "Chongqing"})
ADDITIONAL_WEATHEROL_IDENTITIES = {
    "Wuhan": ("JCCN100054", "武汉天河国际机场", 30.776258, 114.217379),
    "Chongqing": ("JCCN100139", "重庆江北国际机场", 29.727675, 106.648039),
}
# TAF is an airport forecast, not a numerical grid model.  The airport for
# each city is selected from the user's model-reference point (nearest reporting
# METAR/TAF station).  It is retained separately in the model table so that
# its forecast maximum and weather-risk periods are auditable alongside the
# numerical models.
TAF_FORECAST_URL = "https://aviationweather.gov/api/data/taf"
TAF_GRID_STATIONS = {
    "Beijing": ("ZBAA", (40.05, 116.59)),
    "Shanghai": ("ZSPD", (31.15, 121.80)),
    "Shenzhen": ("ZGSZ", (22.64, 113.83)),
    "Chengdu": ("ZUUU", (30.57, 103.96)),
    "Guangzhou": ("ZGGG", (23.44, 113.32)),
    "Wuhan": ("ZHHH", (30.7838, 114.208)),
    "Chongqing": ("ZUCK", (29.7192, 106.642)),
}
TAF_DISCOVERY_CITIES = frozenset(TAF_GRID_STATIONS)
# China Standard Time has no daylight-saving adjustment; avoid relying on an
# optional IANA tzdata package in Windows virtual environments.
SHANGHAI_TZ = timezone(timedelta(hours=8), name="Asia/Shanghai")
BASE = Path(__file__).resolve().parent
DB_PATH = BASE / "data" / "research.sqlite3"
UNIVERSE_PUBLICATION_APPROVAL_PATH = (
    BASE / "data" / "runtime" / "control" / "universe_publication_approval.v1.json"
)
UNIVERSE_PUBLICATION_STAGING_PATH = (
    BASE / "data" / "runtime" / "staging" / "universe_publication_candidate.v1.json"
)
UNIVERSE_PUBLICATION_APPROVAL_SCHEMA = "universe_publication_approval.v1"
UNIVERSE_FORWARD_MIXED_PUBLICATION_APPROVAL_SCHEMA = "universe_publication_approval.v2"
UNIVERSE_FROZEN_PUBLICATION_APPROVAL_SCHEMA = "universe_publication_approval.v3"
UNIVERSE_PUBLICATION_STAGING_SCHEMA = "universe_publication_candidate.v1"
FORWARD_MIXED_TRANSITION = "legacy_to_v1_forward_mixed"
FORWARD_MIXED_WINDOW_END_HOUR = 6
UNIVERSE_PUBLICATION_APPROVAL_MAX_BYTES = 16 * 1024
UNIVERSE_PUBLICATION_STAGING_MAX_BYTES = 4 * 1024 * 1024
UNIVERSE_PUBLICATION_APPROVAL_FIELDS = frozenset({
    "schema",
    "operation_id",
    "expected_current_hash",
    "approved_candidate_hash",
    "approved_token_count",
    "approved_added_count",
    "approved_removed_count",
    "approved_remapped_count",
    "approved_removed_token_hash",
    "allowed_removed_target_dates",
    "not_before",
    "expires_at",
})
UNIVERSE_FORWARD_MIXED_PUBLICATION_APPROVAL_FIELDS = frozenset({
    "schema",
    "operation_id",
    "transition",
    "expected_current_hash",
    "approved_candidate_hash",
    "approved_token_count",
    "approved_added_count",
    "approved_removed_count",
    "approved_remapped_count",
    "approved_added_token_hash",
    "approved_removed_token_hash",
    "allowed_added_target_dates",
    "allowed_removed_target_dates",
    "not_before",
    "expires_at",
})
UNIVERSE_FROZEN_PUBLICATION_APPROVAL_FIELDS = frozenset(
    set(UNIVERSE_FORWARD_MIXED_PUBLICATION_APPROVAL_FIELDS)
    | {"approved_artifact_hash", "approved_source_scan_id"}
)
UNIVERSE_PUBLICATION_STAGING_FIELDS = frozenset({
    "schema", "source_scan_id", "scanned_at", "staged_at", "expires_at",
    "expected_current_hash", "expected_current_count", "scan_statuses",
    "market_payloads", "candidate", "artifact_hash",
})
FROZEN_EVENT_FIELDS = frozenset({
    "id", "title", "resolutionSource", "active", "closed",
    "_query_city", "_query_target_date",
})
FROZEN_MARKET_FIELDS = frozenset({
    "id", "question", "description", "resolutionSource", "endDate",
    "outcomes", "outcomePrices", "clobTokenIds", "liquidityNum",
    "volumeNum", "groupItemTitle", "active", "closed",
})
FROZEN_SCAN_STATUS_FIELDS = frozenset({
    "schema", "scan_id", "scanned_at", "city", "city_scope", "station",
    "target_date", "attribution_status", "reason_code",
})
FROZEN_CANDIDATE_FIELDS = frozenset({
    "schema", "scan_id", "source_scan_id", "scanned_at", "members",
    "token_count", "token_hash", "distributions", "diff",
})
RETENTION_DAYS = int(os.getenv("RESEARCH_RETENTION_DAYS", "7"))
REACTION_RETENTION_DAYS = int(os.getenv("REACTION_RETENTION_DAYS", "90"))
# Time windows are primary; these ceilings are the second line of defence
# when a provider starts emitting unexpected volumes or duplicate markets.
MAX_MARKET_SNAPSHOT_ROWS = int(os.getenv("MAX_MARKET_SNAPSHOT_ROWS", "350000"))
MAX_FORECAST_AUDIT_ROWS = int(os.getenv("MAX_FORECAST_AUDIT_ROWS", "100000"))
MAX_FORECAST_UPDATE_ROWS = int(os.getenv("MAX_FORECAST_UPDATE_ROWS", "100000"))
MAX_FORECAST_RAW_ROWS = int(os.getenv("MAX_FORECAST_RAW_ROWS", "50000"))
PRECISION_FORECAST_SCHEDULE = {
    57: {"Beijing", "Shanghai", "Guangzhou", "Shenzhen"},
    12: {"Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Chengdu"},
    2: {"Chengdu"},
    17: {"Chengdu"},
}
# A short second read after each expected release absorbs delayed page refreshes.
PRECISION_RETRY_SCHEDULE = {
    0: {"Beijing", "Shanghai", "Guangzhou", "Shenzhen"},
    15: {"Beijing", "Shanghai", "Guangzhou", "Shenzhen", "Chengdu"},
    5: {"Chengdu"},
    20: {"Chengdu"},
}
DISCOVERY_MINUTES = {0, 10, 20, 30, 40, 50}
# Weather markets appear progressively after noon, not as one atomic batch.
MARKET_OPEN_CHECK_MINUTES = set(range(0, 31))
EXPECTED_REPORT_MINUTES = {
    "Beijing": {55, 10}, "Shanghai": {55, 10}, "Guangzhou": {55, 10}, "Shenzhen": {55, 10},
    "Chengdu": {0, 10, 15},
}
REACTION_WINDOWS_MINUTES = (15, 60, 240)
MARKET_REQUEST_CONCURRENCY = int(os.getenv("MARKET_REQUEST_CONCURRENCY", "3"))
MARKET_SCAN_BUDGET_SECONDS = float(os.getenv("MARKET_SCAN_BUDGET_SECONDS", "120"))
MARKET_PUBLISH_BUDGET_SECONDS = float(os.getenv("MARKET_PUBLISH_BUDGET_SECONDS", "60"))
RESOLUTION_SCAN_BUDGET_SECONDS = float(os.getenv("RESOLUTION_SCAN_BUDGET_SECONDS", "90"))
# Proven against Gamma's official /markets list endpoint on 2026-08-17.
# This is deliberately not configurable: changing it requires another
# interface-capacity review rather than an environment-only production change.
RESOLUTION_BATCH_SIZE = 50
FORECAST_PHASE_BUDGET_SECONDS = float(os.getenv("FORECAST_PHASE_BUDGET_SECONDS", "180"))
COLLECTOR_STARTUP_BUDGET_SECONDS = float(
    os.getenv("COLLECTOR_STARTUP_BUDGET_SECONDS", "300")
)
RESEARCH_MAINTENANCE_INTERVAL_SECONDS = float(
    os.getenv("RESEARCH_MAINTENANCE_INTERVAL_SECONDS", "600")
)
RESEARCH_MAINTENANCE_BUDGET_SECONDS = float(
    os.getenv("RESEARCH_MAINTENANCE_BUDGET_SECONDS", "30")
)
RESEARCH_MAINTENANCE_BATCH_ROWS = int(
    os.getenv("RESEARCH_MAINTENANCE_BATCH_ROWS", "500")
)


class MarketScanIncomplete(RuntimeError):
    """A scan that cannot safely replace the last complete market universe."""

    def __init__(self, reason_code: str, detail: str | None = None) -> None:
        self.reason_code = str(reason_code).strip() or "market_scan_incomplete"
        self.detail = detail
        super().__init__(self.reason_code if not detail else f"{self.reason_code}: {detail}")


class AdditionalWeatherolSourceRejected(ValueError):
    """A configured research-city response that cannot prove airport ownership."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = str(reason_code).strip() or "invalid_payload"
        super().__init__(f"source_identity_rejected:{self.reason_code}")


class AcceptedManifestMembers(list[dict[str, Any]]):
    """Read-only accepted members annotated with their frozen wire format."""
    def __init__(self, members: list[dict[str, Any]], accepted_format: str) -> None:
        super().__init__(members)
        self.accepted_format = accepted_format


@dataclass(frozen=True, slots=True)
class _FrozenGammaTokenEvidence:
    """Original Gamma token fields retained independently of derived DTO fields."""

    outcomes_json: str
    clob_token_ids_json: str


@dataclass(frozen=True, slots=True)
class VerifiedAdditionalWeatherolPayload:
    aid: str
    airport_name: str
    latitude: float
    longitude: float
    target_date: str
    forecast_high_c: float


@dataclass(frozen=True, slots=True)
class ForecastCyclePlan:
    primary_qxzx: frozenset[str]
    additional_qxzx: frozenset[str]
    taf: frozenset[str]
    precision: frozenset[str]
    retry: frozenset[str]
    discovery: bool
    run_cycle: bool


def _strict_nonempty_string(value: object) -> bool:
    return type(value) is str and bool(value) and value == value.strip()


def _strict_lower_hash(value: object) -> bool:
    return _strict_nonempty_string(value) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _strict_iso_date(value: object) -> bool:
    if not _strict_nonempty_string(value) or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None:
        return False
    try:
        return date.fromisoformat(value).isoformat() == value
    except ValueError:
        return False


def _strict_aware_datetime(value: object) -> datetime:
    if not _strict_nonempty_string(value):
        raise MarketScanIncomplete("publication_approval_time_invalid")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise MarketScanIncomplete("publication_approval_time_invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise MarketScanIncomplete("publication_approval_time_invalid")
    return parsed


def _unique_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate key: {key}")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant: {value}")


def load_universe_publication_approval(
    approval_path: str | Path | None = None,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Load the sole short-lived publication approval carrier, strictly read-only."""
    path = Path(approval_path) if approval_path is not None else UNIVERSE_PUBLICATION_APPROVAL_PATH
    try:
        metadata = path.lstat()
        if path.is_symlink() or not stat.S_ISREG(metadata.st_mode):
            raise MarketScanIncomplete("publication_approval_not_regular_file")
        if metadata.st_size <= 0:
            raise MarketScanIncomplete("publication_approval_empty")
        if metadata.st_size > UNIVERSE_PUBLICATION_APPROVAL_MAX_BYTES:
            raise MarketScanIncomplete("publication_approval_too_large")
        with path.open("rb") as handle:
            opened = os.fstat(handle.fileno())
            if (
                not stat.S_ISREG(opened.st_mode)
                or (metadata.st_dev, metadata.st_ino) != (opened.st_dev, opened.st_ino)
            ):
                raise MarketScanIncomplete("publication_approval_changed_during_open")
            raw = handle.read(UNIVERSE_PUBLICATION_APPROVAL_MAX_BYTES + 1)
    except MarketScanIncomplete:
        raise
    except FileNotFoundError as exc:
        raise MarketScanIncomplete("publication_approval_missing") from exc
    except OSError as exc:
        raise MarketScanIncomplete("publication_approval_read_failed") from exc
    if not raw:
        raise MarketScanIncomplete("publication_approval_empty")
    if len(raw) > UNIVERSE_PUBLICATION_APPROVAL_MAX_BYTES:
        raise MarketScanIncomplete("publication_approval_too_large")
    try:
        approval = json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=_unique_json_object,
            parse_constant=_reject_json_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise MarketScanIncomplete("publication_approval_json_invalid") from exc
    if type(approval) is not dict:
        raise MarketScanIncomplete("publication_approval_fields_invalid")
    schema = approval.get("schema")
    if schema == UNIVERSE_PUBLICATION_APPROVAL_SCHEMA:
        fields = UNIVERSE_PUBLICATION_APPROVAL_FIELDS
    elif schema == UNIVERSE_FORWARD_MIXED_PUBLICATION_APPROVAL_SCHEMA:
        fields = UNIVERSE_FORWARD_MIXED_PUBLICATION_APPROVAL_FIELDS
    elif schema == UNIVERSE_FROZEN_PUBLICATION_APPROVAL_SCHEMA:
        fields = UNIVERSE_FROZEN_PUBLICATION_APPROVAL_FIELDS
    else:
        raise MarketScanIncomplete("publication_approval_schema_invalid")
    if set(approval) != fields:
        raise MarketScanIncomplete("publication_approval_fields_invalid")
    string_fields = (
        "schema",
        "operation_id",
        "expected_current_hash",
        "approved_candidate_hash",
        "approved_removed_token_hash",
        "not_before",
        "expires_at",
    )
    if schema in {
        UNIVERSE_FORWARD_MIXED_PUBLICATION_APPROVAL_SCHEMA,
        UNIVERSE_FROZEN_PUBLICATION_APPROVAL_SCHEMA,
    }:
        string_fields += ("transition", "approved_added_token_hash")
    if schema == UNIVERSE_FROZEN_PUBLICATION_APPROVAL_SCHEMA:
        string_fields += ("approved_artifact_hash", "approved_source_scan_id")
    if any(not _strict_nonempty_string(approval[field]) for field in string_fields):
        raise MarketScanIncomplete("publication_approval_string_invalid")
    hash_fields = [
        "expected_current_hash", "approved_candidate_hash", "approved_removed_token_hash"
    ]
    if schema in {
        UNIVERSE_FORWARD_MIXED_PUBLICATION_APPROVAL_SCHEMA,
        UNIVERSE_FROZEN_PUBLICATION_APPROVAL_SCHEMA,
    }:
        hash_fields.append("approved_added_token_hash")
    if schema == UNIVERSE_FROZEN_PUBLICATION_APPROVAL_SCHEMA:
        hash_fields.append("approved_artifact_hash")
    for field in hash_fields:
        if not _strict_lower_hash(approval[field]):
            raise MarketScanIncomplete("publication_approval_hash_invalid")
    count_fields = (
        "approved_token_count",
        "approved_added_count",
        "approved_removed_count",
        "approved_remapped_count",
    )
    if any(type(approval[field]) is not int or approval[field] < 0 for field in count_fields):
        raise MarketScanIncomplete("publication_approval_count_invalid")
    if schema == UNIVERSE_PUBLICATION_APPROVAL_SCHEMA:
        if approval["approved_added_count"] != 0 or approval["approved_remapped_count"] != 0:
            raise MarketScanIncomplete("publication_approval_transition_invalid")
        date_fields = ("allowed_removed_target_dates",)
    else:
        if (
            approval["transition"] != FORWARD_MIXED_TRANSITION
            or approval["approved_added_count"] <= 0
            or approval["approved_removed_count"] <= 0
            or approval["approved_remapped_count"] != 0
        ):
            raise MarketScanIncomplete("publication_approval_transition_invalid")
        date_fields = ("allowed_added_target_dates", "allowed_removed_target_dates")
    for date_field in date_fields:
        approval_dates = approval[date_field]
        if (
            type(approval_dates) is not list
            or not approval_dates
            or any(not _strict_iso_date(value) for value in approval_dates)
            or len(set(approval_dates)) != len(approval_dates)
            or approval_dates != sorted(approval_dates)
        ):
            raise MarketScanIncomplete("publication_approval_dates_invalid")
    not_before = _strict_aware_datetime(approval["not_before"])
    expires_at = _strict_aware_datetime(approval["expires_at"])
    lifetime = expires_at - not_before
    if lifetime <= timedelta(0) or lifetime > timedelta(minutes=15):
        raise MarketScanIncomplete("publication_approval_lifetime_invalid")
    current_time = now if now is not None else datetime.now(UTC)
    if (
        type(current_time) is not datetime
        or current_time.tzinfo is None
        or current_time.utcoffset() is None
    ):
        raise MarketScanIncomplete("publication_approval_now_invalid")
    if not_before > current_time or current_time >= expires_at:
        raise MarketScanIncomplete("publication_approval_not_active")
    return approval


def load_realtime_accepted_universe_read_only(
    database_path: str | Path | None = None,
) -> dict[str, Any]:
    """Read the newest accepted Realtime hash/count using SQLite URI mode=ro."""
    path = Path(database_path if database_path is not None else REALTIME_DB).resolve()
    uri = f"{path.as_uri()}?mode=ro"
    db: sqlite3.Connection | None = None
    try:
        db = sqlite3.connect(uri, uri=True, timeout=0.2)
        row = db.execute(
            """SELECT universe_hash,token_count FROM stream_connection_events
               WHERE event_type IN ('connected','universe_changed','universe_rollback')
                 AND universe_hash IS NOT NULL
               ORDER BY event_at DESC,rowid DESC LIMIT 1"""
        ).fetchone()
    except sqlite3.Error as exc:
        raise MarketScanIncomplete("realtime_accepted_read_failed") from exc
    finally:
        if db is not None:
            db.close()
    if row is None:
        raise MarketScanIncomplete("realtime_accepted_missing")
    token_hash, token_count = row
    if not _strict_lower_hash(token_hash):
        raise MarketScanIncomplete("realtime_accepted_hash_invalid")
    if type(token_count) is not int or token_count <= 0:
        raise MarketScanIncomplete("realtime_accepted_count_invalid")
    return {"token_hash": token_hash, "token_count": token_count}


class CollectorProgress:
    """Persist collector progress without allowing a slow provider to look dead.

    The collector remains research.sqlite3's only writer.  Network tasks call
    this synchronously from the single asyncio event loop; they never open
    their own SQLite connections or write forecast/market rows.
    """

    def __init__(
        self,
        db: sqlite3.Connection,
        cycle_id: str,
        *,
        publisher: WorkerProgressPublisher | None = None,
    ) -> None:
        self.db = db
        self.cycle_id = cycle_id
        self.publisher = publisher
        self.phase = "idle"
        self.total = 0
        self.completed = 0
        self.deadline_at: datetime | None = None

    def begin(self, phase: str, total: int, budget_seconds: float) -> None:
        self.phase = phase
        self.total = max(0, total)
        self.completed = 0
        self.deadline_at = datetime.now(UTC) + timedelta(seconds=budget_seconds)
        self._write("running")

    def advance(self, completed: int | None = None) -> None:
        self.completed = min(self.total, self.completed + 1 if completed is None else completed)
        self._write("running")

    def finish(self, summary: str) -> None:
        self.phase = "idle"
        self.total = 0
        self.completed = 0
        self.deadline_at = None
        self._write("idle", summary=summary)

    def _write(self, state: str, *, summary: str | None = None) -> None:
        updated_at = datetime.now(UTC).isoformat()
        fields = [
            f"state={state}", f"phase={self.phase}", f"cycle_id={self.cycle_id}",
            f"progress={self.completed}/{self.total}", f"last_progress_at={updated_at}",
        ]
        if self.deadline_at is not None:
            fields.append(f"deadline_at={self.deadline_at.isoformat()}")
        if summary:
            fields.append(f"summary={summary[:220]}")
        detail = "; ".join(fields)
        # This PID-scoped file is independent from research.sqlite3.  A new
        # worker therefore cannot inherit the previous PID's expired phase
        # deadline while its database connection is still starting.
        if self.publisher is not None:
            self.publisher.publish(
                state,
                detail=detail,
                deadline_at=(
                    self.deadline_at.isoformat()
                    if self.deadline_at is not None
                    else None
                ),
            )
        try:
            self.db.execute("INSERT OR REPLACE INTO service_heartbeats VALUES (?, ?, ?)",
                            ("collector", updated_at, detail))
            self.db.commit()
        except sqlite3.Error as exc:
            # A missed progress write must be visible, but never turn a
            # recoverable provider delay into a collector crash loop.
            logging.warning("collector progress heartbeat failed: %s", exc)


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(exist_ok=True)
    # Collector startup verifies schema only.  Retention is deliberately not
    # performed here: a replacement worker must be able to become observable
    # without first scanning a large research database.
    db = sqlite3.connect(DB_PATH, timeout=30)
    # WAL is configured once during database creation/migration.  Reissuing
    # `journal_mode=WAL` on every worker start requires an exclusive lock and
    # can fail while the read-only dashboard has an active query.  A collector
    # must never turn that harmless reader into a startup outage.
    db.execute("PRAGMA busy_timeout=30000")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS forecast_snapshots (
      captured_at TEXT NOT NULL, city TEXT NOT NULL, model TEXT NOT NULL,
      forecast_json TEXT NOT NULL, PRIMARY KEY (captured_at, city, model)
    );
    CREATE TABLE IF NOT EXISTS forecast_raw_payloads (
      captured_at TEXT NOT NULL, source TEXT NOT NULL, city TEXT NOT NULL,
      station TEXT NOT NULL, source_reported_at TEXT, payload_kind TEXT NOT NULL,
      payload_available INTEGER NOT NULL, payload_sha256 TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      PRIMARY KEY (captured_at, source, station, payload_kind)
    );
    CREATE TABLE IF NOT EXISTS forecast_fetch_audits (
      requested_at TEXT NOT NULL, received_at TEXT, source TEXT NOT NULL,
      city TEXT NOT NULL, station TEXT NOT NULL, status TEXT NOT NULL,
      detail TEXT, model_run_at TEXT,
      PRIMARY KEY (requested_at, source, station)
    );
    CREATE TABLE IF NOT EXISTS airport_stations (
      station TEXT PRIMARY KEY, city TEXT NOT NULL, latitude REAL NOT NULL,
      longitude REAL NOT NULL, first_seen_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS collector_runs (
      captured_at TEXT PRIMARY KEY, active_markets INTEGER NOT NULL,
      airport_stations INTEGER NOT NULL, settled_markets INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS market_snapshots (
      captured_at TEXT NOT NULL, market_id TEXT NOT NULL, city TEXT NOT NULL,
      question TEXT NOT NULL, description TEXT, resolution_source TEXT,
      end_date TEXT, outcomes_json TEXT, prices_json TEXT, tokens_json TEXT,
      liquidity REAL, volume REAL, active INTEGER, closed INTEGER, bucket_label TEXT,
      PRIMARY KEY (captured_at, market_id)
    );
    -- A completed market scan is published as one immutable manifest.  The
    -- quote stream reads this table instead of observing ``market_snapshots``
    -- while a multi-event scan is still being written.
    CREATE TABLE IF NOT EXISTS market_universe_publications (
      publication_id TEXT PRIMARY KEY, published_at TEXT NOT NULL,
      token_hash TEXT NOT NULL, token_count INTEGER NOT NULL,
      members_json TEXT NOT NULL, reason TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS forecast_update_values (
      source TEXT NOT NULL, city TEXT NOT NULL, station TEXT NOT NULL,
      source_reported_at TEXT NOT NULL, captured_at TEXT NOT NULL,
      target_date TEXT NOT NULL, forecast_high_c REAL,
      PRIMARY KEY (source, station, source_reported_at, target_date)
    );
    CREATE TABLE IF NOT EXISTS forecast_versions (
      version_id TEXT PRIMARY KEY, source TEXT NOT NULL, city TEXT NOT NULL,
      station TEXT NOT NULL, target_date TEXT NOT NULL, forecast_high_c REAL,
      content_hash TEXT NOT NULL, first_seen_at TEXT NOT NULL, last_seen_at TEXT NOT NULL,
      source_display_time TEXT, is_change INTEGER NOT NULL DEFAULT 1,
      UNIQUE(source, station, target_date, content_hash)
    );
    CREATE TABLE IF NOT EXISTS forecast_events (
      event_id INTEGER PRIMARY KEY AUTOINCREMENT,
      source TEXT NOT NULL, city TEXT NOT NULL, station TEXT NOT NULL,
      target_date TEXT NOT NULL, forecast_high_c REAL,
      previous_high_c REAL, event_kind TEXT NOT NULL,
      first_seen_at TEXT NOT NULL, last_confirmed_at TEXT NOT NULL,
      source_display_time TEXT
    );
    -- The D0 registry is intentionally separate from the append-only
    -- version/event history.  A midnight capture of yesterday's publication
    -- is evidence of a carry-over, never evidence of a new D0 forecast.
    CREATE TABLE IF NOT EXISTS forecast_d0_registry (
      source TEXT NOT NULL, city TEXT NOT NULL, station TEXT NOT NULL,
      target_date TEXT NOT NULL, grid_version TEXT NOT NULL,
      status TEXT NOT NULL, forecast_high_c REAL, forecast_bucket INTEGER,
      source_reported_at TEXT, first_captured_at TEXT NOT NULL,
      capture_delay_seconds REAL, content_hash TEXT, reason TEXT,
      frozen_at TEXT, latest_checked_at TEXT NOT NULL,
      PRIMARY KEY (source, station, target_date, grid_version)
    );
    CREATE TABLE IF NOT EXISTS service_heartbeats (
      service TEXT PRIMARY KEY, updated_at TEXT NOT NULL, detail TEXT
    );
    CREATE TABLE IF NOT EXISTS market_rules (
      market_id TEXT PRIMARY KEY, city TEXT NOT NULL, question TEXT NOT NULL,
      resolution_source TEXT, description TEXT, first_seen_at TEXT NOT NULL, last_seen_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS market_resolutions (
      market_id TEXT PRIMARY KEY, city TEXT NOT NULL, target_date TEXT,
      bucket_label TEXT, yes_resolved INTEGER, resolved_at TEXT NOT NULL,
      outcome_prices_json TEXT, resolution_source TEXT
    );
    CREATE TABLE IF NOT EXISTS forecast_price_reactions (
      version_id TEXT NOT NULL, market_id TEXT NOT NULL, token_id TEXT NOT NULL,
      minutes_after INTEGER NOT NULL, baseline_at TEXT NOT NULL, baseline_mid REAL NOT NULL,
      observed_at TEXT NOT NULL, observed_mid REAL NOT NULL,
      change REAL NOT NULL,
      PRIMARY KEY (version_id, market_id, token_id, minutes_after)
    );
    CREATE TABLE IF NOT EXISTS forecast_schedule_alerts (
      source TEXT NOT NULL, city TEXT NOT NULL, report_minute INTEGER NOT NULL,
      first_seen_at TEXT NOT NULL, last_seen_at TEXT NOT NULL, occurrences INTEGER NOT NULL DEFAULT 1,
      PRIMARY KEY (source, report_minute)
    );
    CREATE TABLE IF NOT EXISTS forecast_delivery_windows (
      scheduled_at TEXT NOT NULL, schedule_kind TEXT NOT NULL, city TEXT NOT NULL,
      cycle_started_at TEXT NOT NULL, completed_at TEXT NOT NULL, source TEXT NOT NULL,
      status TEXT NOT NULL, requested_at TEXT, received_at TEXT, source_reported_at TEXT,
      detail TEXT,
      PRIMARY KEY (scheduled_at, schedule_kind, city, source)
    );
    CREATE TABLE IF NOT EXISTS collector_migrations (
      name TEXT PRIMARY KEY, applied_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_versions_city_date ON forecast_versions(city, target_date, first_seen_at);
    CREATE INDEX IF NOT EXISTS idx_events_city_date ON forecast_events(city, target_date, event_id);
    CREATE INDEX IF NOT EXISTS idx_d0_city_date ON forecast_d0_registry(city, target_date, status);
    CREATE INDEX IF NOT EXISTS idx_reactions_version ON forecast_price_reactions(version_id);
    CREATE INDEX IF NOT EXISTS idx_raw_forecast_source_time ON forecast_raw_payloads(source, station, captured_at);
    CREATE INDEX IF NOT EXISTS idx_forecast_audit_source_time ON forecast_fetch_audits(source, station, requested_at);
    CREATE INDEX IF NOT EXISTS idx_forecast_delivery_window ON forecast_delivery_windows(scheduled_at, city, status);
    CREATE INDEX IF NOT EXISTS idx_market_universe_published ON market_universe_publications(published_at DESC);
    CREATE INDEX IF NOT EXISTS idx_market_snapshots_market_captured ON market_snapshots(market_id,captured_at DESC);
    """)
    ensure_settlement_schema(db)
    columns = {row[1] for row in db.execute("PRAGMA table_info(market_snapshots)")}
    if "bucket_label" not in columns:
        db.execute("ALTER TABLE market_snapshots ADD COLUMN bucket_label TEXT")
    version_columns = {row[1] for row in db.execute("PRAGMA table_info(forecast_versions)")}
    if "is_change" not in version_columns:
        db.execute("ALTER TABLE forecast_versions ADD COLUMN is_change INTEGER NOT NULL DEFAULT 1")
    enforce_d0_only_forecasts(db)
    repair_d0_strict_after_midnight(db)
    migrate_forecast_events(db)
    # Install event triggers only after one-off migrations have completed.
    # Bounded retention runs later, outside worker startup.
    ensure_research_events(db)
    # Schema migration and retention cleanup are writes.  Commit them before
    # any network request so a failed/slow fetch cannot hold a SQLite write
    # lock and create an artificial BBO/depth collection gap.
    db.commit()
    return db


def _delete_batch(
    db: sqlite3.Connection,
    table: str,
    where: str,
    parameters: tuple[Any, ...],
    batch_rows: int,
) -> int:
    cursor = db.execute(
        f"DELETE FROM {table} WHERE rowid IN ("
        f"SELECT rowid FROM {table} WHERE {where} LIMIT ?)",
        (*parameters, max(1, int(batch_rows))),
    )
    return max(0, int(cursor.rowcount))


def prune_research_data(
    db: sqlite3.Connection,
    *,
    batch_rows: int = RESEARCH_MAINTENANCE_BATCH_ROWS,
) -> dict[str, int]:
    """Bound research growth even when the collector runs for weeks.

    This deliberately excludes quote/depth tables: their independent bounded
    compaction runs in the real-time writer and must not be raced here.
    """
    deleted: dict[str, int] = {}
    allowed = tuple(city.title() for city in ALLOWED_CITIES)
    placeholders = ",".join("?" for _ in allowed)
    allowed_lower = tuple(city.lower() for city in allowed)
    for table in ("market_snapshots", "airport_stations"):
        deleted[table] = deleted.get(table, 0) + _delete_batch(
            db, table, f"lower(city) NOT IN ({placeholders})", allowed_lower, batch_rows
        )
    cutoff = (datetime.now(UTC) - timedelta(days=RETENTION_DAYS)).isoformat()
    for table in ("forecast_snapshots", "forecast_raw_payloads", "market_snapshots", "collector_runs"):
        deleted[table] = deleted.get(table, 0) + _delete_batch(
            db, table, "captured_at < ?", (cutoff,), batch_rows
        )
    for table, column in (
        ("forecast_update_values", "captured_at"),
        ("forecast_delivery_windows", "completed_at"),
        ("forecast_versions", "last_seen_at"),
        ("forecast_events", "last_confirmed_at"),
    ):
        deleted[table] = deleted.get(table, 0) + _delete_batch(
            db, table, f"{column} < ?", (cutoff,), batch_rows
        )
    d0_summary_cutoff = (datetime.now(UTC) - timedelta(days=REACTION_RETENTION_DAYS)).astimezone(SHANGHAI_TZ).date().isoformat()
    deleted["forecast_d0_registry"] = _delete_batch(
        db, "forecast_d0_registry", "target_date < ?", (d0_summary_cutoff,), batch_rows
    )
    reaction_cutoff = (datetime.now(UTC) - timedelta(days=REACTION_RETENTION_DAYS)).isoformat()
    deleted["forecast_price_reactions"] = _delete_batch(
        db, "forecast_price_reactions", "observed_at < ?", (reaction_cutoff,), batch_rows
    )
    # Never let a burst bypass the period retention rules.  Oldest rows are
    # safely expendable because compact D0/validation records remain.
    for table, ceiling, order_column in (
        ("market_snapshots", MAX_MARKET_SNAPSHOT_ROWS, "captured_at"),
        ("forecast_fetch_audits", MAX_FORECAST_AUDIT_ROWS, "requested_at"),
        ("forecast_update_values", MAX_FORECAST_UPDATE_ROWS, "captured_at"),
        ("forecast_raw_payloads", MAX_FORECAST_RAW_ROWS, "captured_at"),
    ):
        cursor = db.execute(f"""DELETE FROM {table} WHERE rowid IN (
          SELECT rowid FROM {table} ORDER BY {order_column} DESC
          LIMIT ? OFFSET ?)""", (max(1, int(batch_rows)), ceiling))
        deleted[table] = deleted.get(table, 0) + max(0, int(cursor.rowcount))
    return deleted


def run_bounded_research_maintenance(db: sqlite3.Connection) -> dict[str, int]:
    """Apply one interruptible maintenance slice and release its lock."""
    deadline = clock.monotonic() + RESEARCH_MAINTENANCE_BUDGET_SECONDS
    db.set_progress_handler(lambda: int(clock.monotonic() > deadline), 1000)
    try:
        deleted = prune_research_data(db)
        db.commit()
        return deleted
    except Exception:
        db.rollback()
        raise
    finally:
        db.set_progress_handler(None, 0)


def enforce_d0_only_forecasts(db: sqlite3.Connection) -> None:
    """One-time migration: retain only target-day (D0) forecast evidence.

    Old snapshots and raw provider payloads contain bundled multi-day arrays,
    so they cannot be safely retained after D1/D2 are removed.  The normalized
    D0 values remain, and D0 events are rebuilt from them below.
    """
    marker = "d0_only_forecasts_v1"
    if db.execute("SELECT 1 FROM collector_migrations WHERE name=?", (marker,)).fetchone():
        return
    rows = db.execute("SELECT rowid,target_date,captured_at FROM forecast_update_values").fetchall()
    remove_ids: list[tuple[int]] = []
    for rowid, target_date, captured_at in rows:
        try:
            published_day = datetime.fromisoformat(str(captured_at).replace("Z", "+00:00")).astimezone(SHANGHAI_TZ).date().isoformat()
        except ValueError:
            # An unparsable timestamp cannot prove D0 eligibility.
            remove_ids.append((int(rowid),))
            continue
        if str(target_date) != published_day:
            remove_ids.append((int(rowid),))
    if remove_ids:
        db.executemany("DELETE FROM forecast_update_values WHERE rowid=?", remove_ids)
    # These legacy rows embed D1/D2 content.  Future writes below are D0-only.
    db.execute("DELETE FROM forecast_snapshots")
    db.execute("DELETE FROM forecast_raw_payloads")
    db.execute("DELETE FROM forecast_versions")
    db.execute("DELETE FROM forecast_events")
    db.execute("DELETE FROM forecast_price_reactions")
    db.execute("INSERT INTO collector_migrations VALUES (?,?)", (marker, datetime.now(UTC).isoformat()))
    logging.info("D0-only migration retained %d forecast values and removed %d non-D0 values",
                 len(rows) - len(remove_ids), len(remove_ids))


def repair_d0_strict_after_midnight(db: sqlite3.Connection) -> None:
    """One-time correction for the strict ``after 00:00`` D0 rule.

    A source timestamp exactly at local midnight is not a D0 release.  Keep
    the registry row as an auditable diagnostic, but, where a later same-day
    source release exists, replace it with that earliest eligible release.
    """
    marker = "d0_strict_after_midnight_v1"
    if db.execute("SELECT 1 FROM collector_migrations WHERE name=?", (marker,)).fetchone():
        return
    rows = db.execute("""SELECT source,city,station,target_date,grid_version
      FROM forecast_d0_registry WHERE status='valid_d0'""").fetchall()
    corrected = 0
    for source, city, station, target_date, grid_version in rows:
        candidates = db.execute("""SELECT forecast_high_c,source_reported_at,captured_at
          FROM forecast_update_values
          WHERE source=? AND station=? AND target_date=?
          ORDER BY source_reported_at""", (source, station, target_date)).fetchall()
        eligible: tuple[float | None, str, str] | None = None
        for high, reported_at, captured_at in candidates:
            status, _reason, delay = d0_candidate_status(str(target_date), reported_at, captured_at)
            if status == "valid_d0":
                eligible = (high, str(reported_at), str(captured_at))
                break
        if eligible is not None:
            high, reported_at, captured_at = eligible
            _status, reason, delay = d0_candidate_status(str(target_date), reported_at, captured_at)
            bucket = None if high is None else math.floor(high)
            content_hash = hashlib.sha256(json.dumps({"high": high, "source_time": reported_at}, sort_keys=True).encode()).hexdigest()[:20]
            db.execute("""UPDATE forecast_d0_registry SET
              status='valid_d0',forecast_high_c=?,forecast_bucket=?,source_reported_at=?,
              first_captured_at=?,capture_delay_seconds=?,content_hash=?,reason=?,
              frozen_at=?,latest_checked_at=?
              WHERE source=? AND station=? AND target_date=? AND grid_version=?""",
              (high, bucket, reported_at, captured_at, delay, content_hash, reason, captured_at, captured_at,
               source, station, target_date, grid_version))
        else:
            db.execute("""UPDATE forecast_d0_registry SET status='midnight_not_after',
              forecast_high_c=NULL,forecast_bucket=NULL,reason=?,frozen_at=NULL
              WHERE source=? AND station=? AND target_date=? AND grid_version=?""",
              ("来源发布时间恰为目标日中国时间 00:00，不计入 D0", source, station, target_date, grid_version))
        corrected += 1
    db.execute("INSERT INTO collector_migrations VALUES (?,?)", (marker, datetime.now(UTC).isoformat()))
    logging.info("strict-after-midnight D0 correction reviewed %d frozen records", corrected)


def migrate_forecast_events(db: sqlite3.Connection) -> None:
    """Build an append-only event history from retained raw forecast pulls once.

    A value that returns after an intermediate change is intentionally inserted
    again: it is a new market-relevant event, not a duplicate version.
    """
    if db.execute("SELECT 1 FROM forecast_events LIMIT 1").fetchone():
        return
    previous: dict[tuple[str, str, str], float | None] = {}
    rows = db.execute("""SELECT source,city,station,target_date,forecast_high_c,captured_at,source_reported_at
      FROM forecast_update_values ORDER BY source,station,target_date,captured_at""").fetchall()
    for source, city, station, target_date, high, captured_at, reported_at in rows:
        key = (source, station, target_date)
        prior = previous.get(key)
        if key not in previous or prior != high:
            db.execute("""INSERT INTO forecast_events
              (source,city,station,target_date,forecast_high_c,previous_high_c,event_kind,first_seen_at,last_confirmed_at,source_display_time)
              VALUES (?,?,?,?,?,?,?,?,?,?)""",
              (source, city, station, target_date, high, prior,
               "initial" if key not in previous else "change", captured_at, captured_at, reported_at))
        previous[key] = high


def save_forecast_version(db: sqlite3.Connection, *, source: str, city: str, station: str,
                          target_date: str, high: float | None, captured_at: str,
                          source_display_time: str | None) -> None:
    """A forecast version changes only when the target day's high changes.

    Weatherol's reporttime is retained as display metadata, not treated as a
    new forecast release by itself.
    """
    content = json.dumps({"target_date": target_date, "high": high}, sort_keys=True)
    content_hash = hashlib.sha256(content.encode()).hexdigest()[:20]
    version_id = f"{source}:{station}:{target_date}:{content_hash}"
    latest_event = db.execute("""SELECT event_id,forecast_high_c FROM forecast_events
      WHERE source=? AND station=? AND target_date=? ORDER BY event_id DESC LIMIT 1""",
      (source, station, target_date)).fetchone()
    if latest_event is None or latest_event[1] != high:
        db.execute("""INSERT INTO forecast_events
          (source,city,station,target_date,forecast_high_c,previous_high_c,event_kind,first_seen_at,last_confirmed_at,source_display_time)
          VALUES (?,?,?,?,?,?,?,?,?,?)""",
          (source, city, station, target_date, high,
           latest_event[1] if latest_event else None,
           "change" if latest_event else "initial", captured_at, captured_at, source_display_time))
    else:
        db.execute("""UPDATE forecast_events SET last_confirmed_at=?
          WHERE event_id=?""", (captured_at, latest_event[0]))

    # Retain the old value-deduplicated table for existing reports and data
    # compatibility.  New research/UI logic uses forecast_events above.
    existing = db.execute("""SELECT 1 FROM forecast_versions
      WHERE source=? AND station=? AND target_date=? LIMIT 1""",
      (source, station, target_date)).fetchone()
    db.execute("""INSERT INTO forecast_versions
        (version_id,source,city,station,target_date,forecast_high_c,content_hash,first_seen_at,last_seen_at,source_display_time,is_change)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(source,station,target_date,content_hash) DO UPDATE SET last_seen_at=excluded.last_seen_at,
          source_display_time=excluded.source_display_time""",
        (version_id, source, city, station, target_date, high, content_hash, captured_at, captured_at, source_display_time, int(existing is not None)))


def _parse_timestamp(value: str | None) -> datetime | None:
    """Parse provider timestamps without silently assigning a local date."""
    if not value:
        return None
    try:
        stamp = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    return stamp.replace(tzinfo=UTC) if stamp.tzinfo is None else stamp


def d0_candidate_status(target_date: str, source_reported_at: str | None,
                        captured_at: str) -> tuple[str, str, float | None]:
    """Classify D0 from source time, never from collector arrival time.

    A small five-minute future tolerance is only a clock-sanity guard.  It is
    not a market timing parameter and does not make an old source release D0.
    """
    published = _parse_timestamp(source_reported_at)
    captured = _parse_timestamp(captured_at)
    if published is None:
        return "source_time_missing", "来源未提供可验证的发布时间", None
    if captured is not None and published > captured + timedelta(minutes=5):
        return "source_clock_skew", "来源发布时间晚于抓取时间超过五分钟", None
    try:
        target = date.fromisoformat(target_date)
    except ValueError:
        return "invalid_target_date", "目标日期格式无效", None
    published_day = published.astimezone(SHANGHAI_TZ).date()
    delay = None if captured is None else max(0.0, (captured - published).total_seconds())
    if published_day < target:
        return "delayed_carry", "来源发布时间早于目标日，属于旧预报延续", delay
    if published_day > target:
        return "source_clock_skew", "来源发布时间晚于目标日", delay
    if published.astimezone(SHANGHAI_TZ).time() <= time.min:
        return "midnight_not_after", "来源发布时间恰为目标日中国时间 00:00，不计入 D0", delay
    return "valid_d0", "来源发布时间位于目标日中国时间 00:00 后", delay


def register_d0_candidate(db: sqlite3.Connection, *, source: str, city: str, station: str,
                          target_date: str, high: float | None, captured_at: str,
                          source_reported_at: str | None, grid_version: str) -> str:
    """Freeze the first valid D0; retain non-valid states only as diagnostics."""
    status, reason, delay = d0_candidate_status(target_date, source_reported_at, captured_at)
    bucket = None if high is None else math.floor(high)
    content_hash = hashlib.sha256(json.dumps({"high": high, "source_time": source_reported_at}, sort_keys=True).encode()).hexdigest()[:20]
    key = (source, station, target_date, grid_version)
    current = db.execute("""SELECT status FROM forecast_d0_registry
      WHERE source=? AND station=? AND target_date=? AND grid_version=?""", key).fetchone()
    if current and current[0] == "valid_d0":
        db.execute("""UPDATE forecast_d0_registry SET latest_checked_at=?
          WHERE source=? AND station=? AND target_date=? AND grid_version=?""", (captured_at, *key))
        return "valid_d0"
    db.execute("""INSERT INTO forecast_d0_registry
      (source,city,station,target_date,grid_version,status,forecast_high_c,forecast_bucket,
       source_reported_at,first_captured_at,capture_delay_seconds,content_hash,reason,frozen_at,latest_checked_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(source,station,target_date,grid_version) DO UPDATE SET
        city=excluded.city,status=excluded.status,forecast_high_c=excluded.forecast_high_c,
        forecast_bucket=excluded.forecast_bucket,source_reported_at=excluded.source_reported_at,
        first_captured_at=excluded.first_captured_at,capture_delay_seconds=excluded.capture_delay_seconds,
        content_hash=excluded.content_hash,reason=excluded.reason,
        frozen_at=excluded.frozen_at,latest_checked_at=excluded.latest_checked_at""",
      (source, city, station, target_date, grid_version, status, high, bucket,
       source_reported_at, captured_at, delay, content_hash, reason,
       captured_at if status == "valid_d0" else None, captured_at))
    return status


def save_raw_forecast_payload(db: sqlite3.Connection, *, source: str, city: str, station: str,
                              captured_at: str, source_reported_at: str | None,
                              payload_kind: str, payload: object) -> None:
    """Keep source payloads verbatim enough for later timestamp/data-quality audit.

    In particular, QXZX's ``forecast24h`` is retained separately from the
    derived daily-high record.  An explicit unavailable record is preferable
    to silently treating a response-shape change as no weather signal.
    """
    serialized = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    payload_hash = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
    # Forecast fetch audits retain every request.  Keep a verbatim payload only
    # when its content actually changes, otherwise hourly polling would make
    # the research database grow without adding replay value.
    previous = db.execute("""SELECT payload_sha256 FROM forecast_raw_payloads
      WHERE source=? AND station=? AND payload_kind=?
      ORDER BY captured_at DESC LIMIT 1""", (source, station, payload_kind)).fetchone()
    if previous and str(previous[0]) == payload_hash:
        return
    db.execute("""INSERT OR REPLACE INTO forecast_raw_payloads
      (captured_at,source,city,station,source_reported_at,payload_kind,payload_available,payload_sha256,payload_json)
      VALUES (?,?,?,?,?,?,?,?,?)""",
      (captured_at, source, city, station, source_reported_at, payload_kind,
       int(payload is not None), payload_hash, serialized))


def midpoint(bid: float | None, ask: float | None) -> float | None:
    if bid is not None and ask is not None:
        return (float(bid) + float(ask)) / 2
    if bid is not None:
        return float(bid)
    if ask is not None:
        return float(ask)
    return None


def record_forecast_price_reactions(db: sqlite3.Connection) -> None:
    """Fill completed 15/60/240 minute reactions for genuine forecast changes.

    The baseline is the last executable BBO at or before the first observation
    of a changed forecast.  A horizon uses the first BBO at or after its due
    time, so it never looks ahead when selecting a baseline.
    """
    if not REALTIME_DB.exists():
        return
    versions = db.execute("""SELECT event_id, city, target_date, first_seen_at
      FROM forecast_events WHERE event_kind='change' AND first_seen_at >= ?""",
      ((datetime.now(UTC) - timedelta(days=RETENTION_DAYS)).isoformat(),)).fetchall()
    with sqlite3.connect(f"file:{REALTIME_DB}?mode=ro", uri=True, timeout=5) as quote_db:
      for version_id, city, target_date, changed_at in versions:
        markets = db.execute("""SELECT DISTINCT r.market_id, s.tokens_json, s.outcomes_json
          FROM market_rules r JOIN market_snapshots s ON s.market_id=r.market_id
          WHERE r.city=? AND s.question LIKE ?""", (city, f"%on {datetime.fromisoformat(target_date).strftime('%B')} {int(target_date[-2:])}%")).fetchall()
        for market_id, tokens_json, outcomes_json in markets:
            try:
                tokens, outcomes = json.loads(tokens_json or "[]"), json.loads(outcomes_json or "[]")
                token = str(tokens[[str(value).lower() for value in outcomes].index("yes")])
            except (ValueError, IndexError, json.JSONDecodeError):
                continue
            baseline = quote_db.execute("""SELECT captured_at,best_bid,best_ask FROM book_snapshots
              WHERE token_id=? AND captured_at<=?
              AND NOT (COALESCE(best_bid,0)<=0.001 AND COALESCE(best_ask,1)>=0.999)
              ORDER BY captured_at DESC LIMIT 1""", (token, changed_at)).fetchone()
            if not baseline:
                continue
            baseline_mid = midpoint(baseline[1], baseline[2])
            if baseline_mid is None:
                continue
            start = datetime.fromisoformat(changed_at)
            for minutes in REACTION_WINDOWS_MINUTES:
                exists = db.execute("""SELECT 1 FROM forecast_price_reactions
                  WHERE version_id=? AND market_id=? AND token_id=? AND minutes_after=?""",
                  (version_id, market_id, token, minutes)).fetchone()
                if exists:
                    continue
                observed = quote_db.execute("""SELECT captured_at,best_bid,best_ask FROM book_snapshots
                  WHERE token_id=? AND captured_at>=?
                  AND NOT (COALESCE(best_bid,0)<=0.001 AND COALESCE(best_ask,1)>=0.999)
                  ORDER BY captured_at LIMIT 1""", (token, (start + timedelta(minutes=minutes)).isoformat())).fetchone()
                if not observed:
                    continue
                observed_mid = midpoint(observed[1], observed[2])
                if observed_mid is None:
                    continue
                db.execute("""INSERT INTO forecast_price_reactions
                  VALUES (?,?,?,?,?,?,?,?,?)""", (version_id, market_id, token, minutes,
                    baseline[0], baseline_mid, observed[0], observed_mid, observed_mid - baseline_mid))


def weatherol_reported_at(payload: dict[str, Any], captured_at: str) -> str:
    """Use Weatherol's displayed HH:MM release time with China local date."""
    captured = datetime.fromisoformat(captured_at).astimezone(SHANGHAI_TZ)
    raw = str(payload.get("data", {}).get("current", {}).get("current", {}).get("reporttime", ""))
    try:
        hour, minute = (int(part) for part in raw.split(":"))
        reported = datetime.combine(captured.date(), time(hour, minute), tzinfo=SHANGHAI_TZ)
        # A source time later than retrieval belongs to the preceding local day.
        if reported > captured + timedelta(minutes=5):
            reported -= timedelta(days=1)
        return reported.isoformat()
    except (TypeError, ValueError):
        return captured.isoformat()


def _date_near_reference(month: str, day: str, year: str | None,
                         reference_date: date | None) -> str | None:
    try:
        month_number = datetime.strptime(month, "%B").month
        if year:
            return date(int(year), month_number, int(day)).isoformat()
        if reference_date is None:
            return None
        candidates = []
        for candidate_year in (
            reference_date.year - 1,
            reference_date.year,
            reference_date.year + 1,
        ):
            try:
                candidates.append(date(candidate_year, month_number, int(day)))
            except ValueError:
                # February 29 is valid in only some candidate years.  One
                # invalid year must not discard the valid leap-year facts.
                continue
        if not candidates:
            return None
        # Search queries cover a short window around the scan.  Nearest-date
        # selection makes December-to-January deterministic without consulting
        # the process clock during replay.
        return min(candidates, key=lambda value: (abs((value - reference_date).days), value)).isoformat()
    except ValueError:
        return None


def _reference_date_from_timestamp(value: object) -> date | None:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        return parsed.astimezone(SHANGHAI_TZ).date()
    except (TypeError, ValueError):
        return None


def market_date_from_question(question: str, *, reference_date: date | None = None) -> str | None:
    match = MARKET_CONTRACT_RE.fullmatch(str(question).strip())
    if not match:
        return None
    return _date_near_reference(
        match.group("month"), match.group("day"), match.group("year"), reference_date
    )


def weatherol_airport_for_city(city: str) -> tuple[str, str] | None:
    """Return only a previously verified airport Weatherol source.

    Research-city configuration is only the first gate; each live response is
    revalidated against its frozen airport identity before any forecast write.
    """
    return WEATHEROL_AIRPORTS.get(city.lower())


def valid_weatherol_source_url(url: object, expected_aid: str) -> bool:
    if type(url) is not str or type(expected_aid) is not str:
        return False
    if url != f"https://weatherol.cn/api/getData?aid={expected_aid}":
        return False
    try:
        parsed = urlparse(url)
        query = parse_qsl(parsed.query, keep_blank_values=True)
    except (TypeError, ValueError):
        return False
    return (
        parsed.scheme == "https"
        and parsed.hostname == "weatherol.cn"
        and parsed.username is None
        and parsed.password is None
        and parsed.port is None
        and parsed.path == "/api/getData"
        and parsed.params == ""
        and parsed.fragment == ""
        and query == [("aid", expected_aid)]
    )


def _haversine_km(latitude: float, longitude: float,
                  expected_latitude: float, expected_longitude: float) -> float:
    lat1, lon1, lat2, lon2 = map(
        math.radians, (latitude, longitude, expected_latitude, expected_longitude)
    )
    dlat, dlon = lat2 - lat1, lon2 - lon1
    value = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 6371.0088 * 2 * math.asin(min(1.0, math.sqrt(value)))


def _additional_weatherol_target(item: object, *, today: date) -> tuple[str, float] | None:
    if type(item) is not dict or "forecasttime" not in item or "temperature_am" not in item:
        raise AdditionalWeatherolSourceRejected("forecast_item_invalid")
    raw_date = item["forecasttime"]
    if type(raw_date) is not str or raw_date != raw_date.strip() or re.fullmatch(r"\d{2}/\d{2}", raw_date) is None:
        raise AdditionalWeatherolSourceRejected("forecast_date_invalid")
    try:
        month, day = (int(part) for part in raw_date.split("/"))
        target = date(today.year, month, day)
        if (target - today).days < -180:
            target = date(today.year + 1, month, day)
    except ValueError as exc:
        raise AdditionalWeatherolSourceRejected("forecast_date_invalid") from exc
    if target != today:
        return None
    raw_high = item["temperature_am"]
    if type(raw_high) not in (str, int, float):
        raise AdditionalWeatherolSourceRejected("forecast_temperature_invalid")
    if type(raw_high) is str and (not raw_high or raw_high != raw_high.strip()):
        raise AdditionalWeatherolSourceRejected("forecast_temperature_invalid")
    try:
        high = float(raw_high)
    except (TypeError, ValueError) as exc:
        raise AdditionalWeatherolSourceRejected("forecast_temperature_invalid") from exc
    if not math.isfinite(high):
        raise AdditionalWeatherolSourceRejected("forecast_temperature_invalid")
    return target.isoformat(), high


def validate_additional_weatherol_payload(
    city: str, payload: object, captured_at: str
) -> VerifiedAdditionalWeatherolPayload:
    identity = ADDITIONAL_WEATHEROL_IDENTITIES.get(city)
    if identity is None:
        raise AdditionalWeatherolSourceRejected("city_not_additional")
    if type(payload) is not dict or type(payload.get("code")) is not int or payload.get("code") != 200:
        raise AdditionalWeatherolSourceRejected("response_code_invalid")
    data = payload.get("data")
    current_wrapper = data.get("current") if type(data) is dict else None
    current = current_wrapper.get("current") if type(current_wrapper) is dict else None
    items = data.get("forecast15d") if type(data) is dict else None
    if type(current) is not dict:
        raise AdditionalWeatherolSourceRejected("current_invalid")
    if type(items) is not list or not items:
        raise AdditionalWeatherolSourceRejected("forecast_list_invalid")
    aid, airport_name, expected_latitude, expected_longitude = identity
    if type(current.get("jcid")) is not str or current.get("jcid") != aid:
        raise AdditionalWeatherolSourceRejected("jcid_mismatch")
    if type(current.get("airportname")) is not str or current.get("airportname") != airport_name:
        raise AdditionalWeatherolSourceRejected("airport_name_mismatch")
    report_time = current.get("reporttime")
    if type(report_time) is not str or re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", report_time) is None:
        raise AdditionalWeatherolSourceRejected("report_time_invalid")
    try:
        latitude, longitude = float(current.get("lat")), float(current.get("lng"))
    except (TypeError, ValueError) as exc:
        raise AdditionalWeatherolSourceRejected("coordinates_invalid") from exc
    if (
        not math.isfinite(latitude)
        or not math.isfinite(longitude)
        or not -90 <= latitude <= 90
        or not -180 <= longitude <= 180
    ):
        raise AdditionalWeatherolSourceRejected("coordinates_invalid")
    if _haversine_km(latitude, longitude, expected_latitude, expected_longitude) > 5.0:
        raise AdditionalWeatherolSourceRejected("coordinates_mismatch")
    try:
        today = datetime.fromisoformat(captured_at).astimezone(SHANGHAI_TZ).date()
    except (TypeError, ValueError) as exc:
        raise AdditionalWeatherolSourceRejected("captured_at_invalid") from exc
    matches = [match for item in items if (match := _additional_weatherol_target(item, today=today)) is not None]
    if len(matches) != 1:
        raise AdditionalWeatherolSourceRejected("target_date_not_unique")
    target_date, high = matches[0]
    return VerifiedAdditionalWeatherolPayload(
        aid=aid,
        airport_name=airport_name,
        latitude=latitude,
        longitude=longitude,
        target_date=target_date,
        forecast_high_c=high,
    )


def build_forecast_cycle_plan(
    now: datetime, *, first_cycle: bool, refresh_markets: bool
) -> ForecastCyclePlan:
    discovery = now.minute in DISCOVERY_MINUTES
    precision = frozenset(PRECISION_FORECAST_SCHEDULE.get(now.minute, set()))
    retry = frozenset(PRECISION_RETRY_SCHEDULE.get(now.minute, set()))
    scheduled = precision | retry
    full_discovery = discovery or first_cycle
    primary = PRIMARY_WEATHEROL_CITIES if full_discovery else scheduled
    additional = ADDITIONAL_WEATHEROL_CITIES if full_discovery else frozenset()
    taf = TAF_DISCOVERY_CITIES if full_discovery else scheduled
    return ForecastCyclePlan(
        primary_qxzx=frozenset(primary),
        additional_qxzx=frozenset(additional),
        taf=frozenset(taf),
        precision=precision,
        retry=retry,
        discovery=discovery,
        run_cycle=bool(primary or additional or taf or refresh_markets),
    )


def _contract_identity(text: str, *, contract_kind: str,
                       reference_date: date | None) -> tuple[str, str] | None:
    """Return identity only when the entire controlled contract template matches."""
    pattern = EVENT_CONTRACT_RE if contract_kind == "event" else MARKET_CONTRACT_RE
    match = pattern.fullmatch(str(text).strip())
    if not match:
        return None
    city_key = match.group("city").strip().lower()
    if city_key not in ALLOWED_CITIES:
        return None
    target_date = _date_near_reference(
        match.group("month"), match.group("day"), match.group("year"), reference_date
    )
    if target_date is None:
        return None
    return city_key.title(), target_date


def _valid_temperature_bucket(value: object) -> bool:
    return bool(TEMPERATURE_BUCKET_RE.fullmatch(str(value or "").strip()))


def _normalized_bucket(value: object) -> str:
    return re.sub(r"[\s°]", "", str(value or "")).lower()


def _validate_resolution_source(source: object, city: str, station: str,
                                prefix: str) -> tuple[str | None, str | None]:
    """Validate one exact settlement-source URL without suffix heuristics."""
    raw = str(source or "").strip()
    if not raw:
        return None, f"{prefix}_source_missing"
    parsed = urlparse(raw)
    if parsed.scheme.lower() != "https":
        return None, f"{prefix}_source_scheme"
    host = (parsed.hostname or "").lower()
    if host == "www.weather.gov":
        query = parse_qsl(parsed.query, keep_blank_values=True)
        if (
            parsed.username is not None
            or parsed.password is not None
            or parsed.port is not None
            or parsed.path != "/wrh/timeseries"
            or parsed.params != ""
            or parsed.fragment != ""
            or query != [("site", station.lower())]
        ):
            return None, f"{prefix}_source_path"
        return host, None
    if host != "www.wunderground.com":
        return None, f"{prefix}_source_host"
    segments = [segment for segment in parsed.path.split("/") if segment]
    allowed_prefixes = (("weather", "cn"), ("history", "daily", "cn"))
    matched_prefix = next((parts for parts in allowed_prefixes
                           if tuple(item.lower() for item in segments[:len(parts)]) == parts), None)
    if matched_prefix is None or len(segments) != len(matched_prefix) + 2:
        return None, f"{prefix}_source_path"
    if segments[-2].lower() != city.lower():
        return None, f"{prefix}_source_city_path"
    if segments[-1].upper() != station:
        return None, f"{prefix}_station_mismatch"
    return host, None


def research_attribution_status(status: str, reason_code: str, *, scan_id: str,
                                scanned_at: str, event_payload: dict[str, Any] | None = None,
                                city: str | None = None, station: str | None = None,
                                target_date: str | None = None) -> dict[str, Any]:
    """Build a non-verified attribution record with all market facts cleared."""
    allowed = {"no_active_market", "scan_not_executed", "search_failed", "attribution_rejected"}
    if status not in allowed:
        raise ValueError(f"unsupported attribution status: {status}")
    event_payload = event_payload or {}
    return {
        "schema": RESEARCH_MARKET_SCHEMA,
        "scan_id": scan_id,
        "scanned_at": scanned_at,
        "event_id": str(event_payload.get("id") or "") or None,
        "event_title": str(event_payload.get("title") or "") or None,
        "market_id": None,
        "market_question": None,
        "city": city,
        "city_scope": CITY_ROLES.get(city.lower()) if city else None,
        "station": station,
        "target_date": target_date,
        "resolution_source": None,
        "resolution_source_host": None,
        "bucket_label": None,
        "outcome": None,
        "token_id": None,
        "active": bool(event_payload.get("active")),
        "closed": bool(event_payload.get("closed")),
        "attribution_status": status,
        "reason_code": reason_code,
    }


def _gamma_outcome_token_facts(
    outcomes_json: object, clob_token_ids_json: object
) -> tuple[list[str], list[str], int | None, str | None]:
    """Parse and validate the two original Gamma token fields."""
    if not isinstance(outcomes_json, str) or not isinstance(clob_token_ids_json, str):
        return [], [], None, "market_outcome_token_format"
    try:
        outcomes = json.loads(outcomes_json)
        tokens = json.loads(clob_token_ids_json)
    except (TypeError, json.JSONDecodeError):
        return [], [], None, "market_outcome_token_format"
    if not isinstance(outcomes, list) or not isinstance(tokens, list):
        return [], [], None, "market_outcome_token_format"
    if len(outcomes) != len(tokens):
        return [], [], None, "market_outcome_token_count"
    if any(not isinstance(item, str) for item in outcomes):
        return [], [], None, "market_outcome_type"
    if any(not isinstance(item, str) for item in tokens):
        return [], [], None, "market_token_type"
    clean_outcomes = list(outcomes)
    clean_tokens = list(tokens)
    yes_indices = [index for index, item in enumerate(clean_outcomes)
                   if item.strip().lower() == "yes"]
    if not yes_indices:
        return clean_outcomes, clean_tokens, None, "market_yes_missing"
    if len(yes_indices) != 1:
        return clean_outcomes, clean_tokens, None, "market_yes_ambiguous"
    if any(not token for token in clean_tokens):
        return clean_outcomes, clean_tokens, None, "market_token_empty"
    if any(not ASCII_TOKEN_RE.fullmatch(token) for token in clean_tokens):
        return clean_outcomes, clean_tokens, None, "market_token_not_decimal"
    if len(set(clean_tokens)) != len(clean_tokens):
        return clean_outcomes, clean_tokens, None, "market_token_duplicate"
    return clean_outcomes, clean_tokens, yes_indices[0], None


def attribute_research_event(event: dict[str, Any], *, scan_id: str,
                             scanned_at: str) -> dict[str, Any]:
    """Validate an event detail before inspecting or filtering its markets."""
    query_city_raw = event.get("_query_city")
    query_target_raw = event.get("_query_target_date")
    if not isinstance(query_city_raw, str) or query_city_raw.strip().lower() not in ALLOWED_CITIES:
        return research_attribution_status(
            "attribution_rejected", "event_query_city_invalid", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event,
        )
    query_city = query_city_raw.strip().lower().title()
    try:
        query_target = date.fromisoformat(str(query_target_raw))
        if query_target.isoformat() != query_target_raw:
            raise ValueError
    except (TypeError, ValueError):
        return research_attribution_status(
            "attribution_rejected", "event_query_target_invalid", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=query_city,
            station=CITY_SETTLEMENT_STATIONS[query_city.lower()],
        )
    reference_date = query_target
    if event.get("active") is not True:
        return research_attribution_status(
            "attribution_rejected", "event_inactive", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=query_city,
            station=CITY_SETTLEMENT_STATIONS[query_city.lower()],
            target_date=query_target.isoformat(),
        )
    if event.get("closed") is not False:
        return research_attribution_status(
            "attribution_rejected", "event_closed", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=query_city,
            station=CITY_SETTLEMENT_STATIONS[query_city.lower()],
            target_date=query_target.isoformat(),
        )
    if not str(event.get("id") or "").strip():
        return research_attribution_status(
            "attribution_rejected", "event_id_missing", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=query_city,
            station=CITY_SETTLEMENT_STATIONS[query_city.lower()],
            target_date=query_target.isoformat(),
        )
    event_title = str(event.get("title") or "").strip()
    event_match = EVENT_CONTRACT_RE.fullmatch(event_title)
    if event_match and event_match.group("city").strip().lower() != query_city.lower():
        return research_attribution_status(
            "attribution_rejected", "event_query_city_mismatch", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=query_city,
            station=CITY_SETTLEMENT_STATIONS[query_city.lower()],
            target_date=query_target.isoformat(),
        )
    event_identity = _contract_identity(
        event_title, contract_kind="event", reference_date=reference_date
    )
    if event_identity is None:
        return research_attribution_status(
            "attribution_rejected", "event_contract_invalid", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=query_city,
            station=CITY_SETTLEMENT_STATIONS[query_city.lower()],
            target_date=query_target.isoformat(),
        )
    event_city, event_date = event_identity
    if event_city != query_city:
        return research_attribution_status(
            "attribution_rejected", "event_query_city_mismatch", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=query_city,
            station=CITY_SETTLEMENT_STATIONS[query_city.lower()],
            target_date=query_target.isoformat(),
        )
    if event_date != query_target.isoformat():
        return research_attribution_status(
            "attribution_rejected", "event_query_date_mismatch", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=query_city,
            station=CITY_SETTLEMENT_STATIONS[query_city.lower()],
            target_date=query_target.isoformat(),
        )
    event_station = CITY_SETTLEMENT_STATIONS[event_city.lower()]
    _event_host, reason = _validate_resolution_source(
        event.get("resolutionSource"), event_city, event_station, "event"
    )
    if reason:
        return research_attribution_status(
            "attribution_rejected", reason, scan_id=scan_id, scanned_at=scanned_at,
            event_payload=event, city=event_city, station=event_station,
            target_date=event_date,
        )
    return {
        "schema": RESEARCH_MARKET_SCHEMA,
        "scan_id": scan_id,
        "scanned_at": scanned_at,
        "event_id": str(event.get("id") or "").strip(),
        "event_title": event_title,
        "city": event_city,
        "city_scope": CITY_ROLES[event_city.lower()],
        "station": event_station,
        "target_date": event_date,
        "event_resolution_source": str(event.get("resolutionSource")),
        "event_resolution_source_host": _event_host,
        "active": True,
        "closed": False,
        "attribution_status": "verified",
        "reason_code": "verified",
        "_query_city": query_city,
        "_query_target_date": query_target.isoformat(),
    }


def attribute_research_market(event: dict[str, Any], market: dict[str, Any], *,
                              scan_id: str, scanned_at: str) -> dict[str, Any]:
    """Verify event and active market attribution as two independent contracts."""
    event_attribution = attribute_research_event(
        event, scan_id=scan_id, scanned_at=scanned_at
    )
    if event_attribution["attribution_status"] != "verified":
        return event_attribution
    event_city = event_attribution["city"]
    event_date = event_attribution["target_date"]
    event_station = event_attribution["station"]
    query_city = event_attribution["_query_city"]
    query_target = date.fromisoformat(event_attribution["_query_target_date"])

    if market.get("active") is not True:
        return research_attribution_status(
            "attribution_rejected", "market_inactive", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=event_city,
            station=event_station, target_date=event_date,
        )
    if market.get("closed") is not False:
        return research_attribution_status(
            "attribution_rejected", "market_closed", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=event_city,
            station=event_station, target_date=event_date,
        )
    market_identity = _contract_identity(
        str(market.get("question") or ""), contract_kind="market",
        reference_date=date.fromisoformat(event_date),
    )
    if market_identity is None:
        return research_attribution_status(
            "attribution_rejected", "market_contract_invalid", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=event_city,
            station=event_station, target_date=event_date,
        )
    market_city, market_date = market_identity
    if market_city != event_city:
        return research_attribution_status(
            "attribution_rejected", "event_market_city_mismatch", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=event_city,
            station=event_station, target_date=event_date,
        )
    if market_date != event_date:
        return research_attribution_status(
            "attribution_rejected", "event_market_date_mismatch", scan_id=scan_id,
            scanned_at=scanned_at, event_payload=event, city=event_city,
            station=event_station, target_date=event_date,
        )
    market_host, reason = _validate_resolution_source(
        market.get("resolutionSource"), market_city, event_station, "market"
    )
    if reason:
        return research_attribution_status(
            "attribution_rejected", reason, scan_id=scan_id, scanned_at=scanned_at,
            event_payload=event, city=event_city, station=event_station,
            target_date=event_date,
        )

    raw_outcomes = market.get("outcomes")
    raw_tokens = market.get("clobTokenIds")
    outcomes, clean_tokens, yes_index, reason = _gamma_outcome_token_facts(
        raw_outcomes, raw_tokens
    )
    bucket = str(market.get("groupItemTitle") or "").strip()
    question_match = MARKET_CONTRACT_RE.fullmatch(str(market.get("question") or "").strip())
    question_bucket = question_match.group("bucket") if question_match else None
    if reason is None and not bucket:
        reason = "market_bucket_missing"
    if reason is None and (not _valid_temperature_bucket(bucket)
                           or not _valid_temperature_bucket(question_bucket)):
        reason = "market_bucket_invalid"
    if reason is None and _normalized_bucket(bucket) != _normalized_bucket(question_bucket):
        reason = "market_bucket_mismatch"
    market_id = str(market.get("id") or "").strip()
    if reason is None and not market_id:
        reason = "market_id_missing"
    if reason is None and MARKET_ID_RE.fullmatch(market_id) is None:
        reason = "market_id_invalid"
    if reason:
        return research_attribution_status(
            "attribution_rejected", reason, scan_id=scan_id, scanned_at=scanned_at,
            event_payload=event, city=event_city, station=event_station,
            target_date=event_date,
        )

    assert yes_index is not None
    return {
        "schema": RESEARCH_MARKET_SCHEMA,
        "scan_id": scan_id,
        "scanned_at": scanned_at,
        "event_id": str(event.get("id") or "").strip(),
        "event_title": str(event.get("title") or "").strip(),
        "market_id": market_id,
        "market_question": str(market.get("question") or "").strip(),
        "city": event_city,
        "city_scope": CITY_ROLES[event_city.lower()],
        "station": event_station,
        "target_date": event_date,
        "resolution_source": str(market.get("resolutionSource")),
        "resolution_source_host": market_host,
        "bucket_label": bucket,
        "outcome": "Yes",
        "token_id": clean_tokens[yes_index],
        "active": bool(market.get("active")),
        "closed": bool(market.get("closed")),
        "attribution_status": "verified",
        "reason_code": "verified",
        "_query_city": query_city,
        "_query_target_date": query_target.isoformat(),
        "_outcome_token_bindings": tuple(zip(outcomes, clean_tokens)),
        "_gamma_token_evidence": _FrozenGammaTokenEvidence(
            outcomes_json=raw_outcomes,
            clob_token_ids_json=raw_tokens,
        ),
    }


def _canonical_research_members_json(members: list[dict[str, Any]]) -> str:
    """Serialize complete manifest members without lossy field projection."""
    try:
        return json.dumps(
            members, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise MarketScanIncomplete("candidate_member_json_invalid") from exc


def _validate_manifest_member(
    member: object, *, allow_retired_historical: bool = False
) -> dict[str, Any]:
    """Validate one already-materialized v1 member without legacy fallback."""
    if not isinstance(member, dict):
        raise MarketScanIncomplete("candidate_member_invalid")
    if any(not isinstance(key, str) for key in member):
        raise MarketScanIncomplete("candidate_member_field_name_invalid")
    for field in RESEARCH_MANIFEST_MEMBER_FIELDS:
        if (field not in member or type(member[field]) is not str
                or not member[field] or member[field] != member[field].strip()):
            raise MarketScanIncomplete("candidate_required_field_missing")
    if member["schema"] != RESEARCH_MARKET_SCHEMA:
        raise MarketScanIncomplete("candidate_schema_invalid")
    if member["attribution_status"] != "verified":
        raise MarketScanIncomplete("candidate_not_verified")
    if member["outcome"] != "Yes":
        raise MarketScanIncomplete("candidate_outcome_invalid")
    if not ASCII_TOKEN_RE.fullmatch(member["token_id"]):
        raise MarketScanIncomplete("candidate_token_invalid")
    try:
        target_date = date.fromisoformat(member["target_date"])
        if target_date.isoformat() != member["target_date"]:
            raise ValueError
    except ValueError as exc:
        raise MarketScanIncomplete("candidate_date_invalid") from exc
    city = member["city"]
    city_key = city.lower()
    if city_key in RETIRED_CITY_KEYS:
        if not allow_retired_historical:
            raise MarketScanIncomplete("candidate_retired_city")
        if (
            city != city_key.title()
            or member["city_scope"] != "research_only"
            or member["station"] != CITY_SETTLEMENT_STATIONS[city_key]
        ):
            raise MarketScanIncomplete("accepted_retired_city_invalid")
        _canonical_research_members_json([member])
        return member
    if city_key not in CITY_ROLES or city != city_key.title():
        raise MarketScanIncomplete("candidate_city_invalid")
    if member["city_scope"] != CITY_ROLES[city_key]:
        raise MarketScanIncomplete("candidate_scope_invalid")
    if member["station"] != CITY_SETTLEMENT_STATIONS[city_key]:
        raise MarketScanIncomplete("candidate_station_invalid")
    _canonical_research_members_json([member])
    return member


def research_universe_diff(candidate_members: list[dict[str, Any]],
                           accepted_members: list[dict[str, Any]]) -> dict[str, Any]:
    """Return a deterministic structural diff; this function never opens SQLite."""
    candidate = [_validate_manifest_member(member) for member in candidate_members]
    accepted_format = getattr(accepted_members, "accepted_format", "v1")
    accepted = ([_validate_legacy_manifest_member(member) for member in accepted_members]
                if accepted_format == "legacy" else
                [_validate_manifest_member(
                    member, allow_retired_historical=True
                ) for member in accepted_members])
    candidate_tokens = {member["token_id"]: member for member in candidate}
    accepted_tokens = {member["token_id"]: member for member in accepted}
    candidate_markets = {member["market_id"]: member for member in candidate}
    accepted_markets = {member["market_id"]: member for member in accepted}
    if len(candidate_tokens) != len(candidate) or len(candidate_markets) != len(candidate):
        raise MarketScanIncomplete("duplicate_mapping")
    if len(accepted_tokens) != len(accepted) or len(accepted_markets) != len(accepted):
        raise MarketScanIncomplete("accepted_duplicate_mapping")

    added = tuple(sorted(set(candidate_tokens) - set(accepted_tokens)))
    removed = tuple(sorted(set(accepted_tokens) - set(candidate_tokens)))
    immutable_fields = (("market_id", "city", "target_date") if accepted_format == "legacy"
                        else ("market_id", "city", "city_scope", "station", "target_date", "outcome", "event_id"))
    remapped_tokens = {
        token for token in set(candidate_tokens) & set(accepted_tokens)
        if any(candidate_tokens[token][field] != accepted_tokens[token][field]
               for field in immutable_fields)
    }
    # A shared market must keep its Yes token.  Expose both token identities so
    # an offline reviewer can see the unsafe mapping change without a database.
    for market_id in set(candidate_markets) & set(accepted_markets):
        if candidate_markets[market_id]["token_id"] != accepted_markets[market_id]["token_id"]:
            remapped_tokens.update((
                candidate_markets[market_id]["token_id"],
                accepted_markets[market_id]["token_id"],
            ))
    remapped = tuple(sorted(remapped_tokens))
    return {
        "added": added,
        "removed": removed,
        "remapped": remapped,
        "pure_add": bool(added) and not removed and not remapped,
    }


def _validate_legacy_manifest_member(member: object) -> dict[str, Any]:
    if not isinstance(member, dict) or any(not isinstance(key, str) for key in member):
        raise MarketScanIncomplete("accepted_legacy_member_invalid")
    required = ("token_id", "market_id", "city", "target_date")
    v1_only = {"city_scope", "station", "outcome", "event_id", "source_scan_id", "attribution_status"}
    if any(field in member for field in v1_only):
        raise MarketScanIncomplete("accepted_legacy_v1_field")
    for field in required:
        if field not in member or type(member[field]) is not str or not member[field] or member[field] != member[field].strip():
            raise MarketScanIncomplete("accepted_legacy_required_field")
    if not ASCII_TOKEN_RE.fullmatch(member["token_id"]):
        raise MarketScanIncomplete("candidate_token_invalid")
    try:
        if date.fromisoformat(member["target_date"]).isoformat() != member["target_date"]:
            raise ValueError
    except ValueError as exc:
        raise MarketScanIncomplete("candidate_date_invalid") from exc
    return member


def load_accepted_research_universe_members_read_only(
    database_path: str | Path,
    *, expected_accepted_hash: object = None,
) -> list[dict[str, Any]]:
    """Load one accepted v1 manifest through SQLite's immutable read-only URI.

    This helper is intentionally unused by the collector write path.  A later,
    separately authorized point-in-time scan may call it before comparing an
    in-memory candidate, but it can never create or update a database file.
    """
    if type(expected_accepted_hash) is not str or not re.fullmatch(r"[0-9a-f]{64}", expected_accepted_hash):
        raise MarketScanIncomplete("accepted_manifest_hash_invalid")
    path = Path(database_path).resolve()
    uri = f"{path.as_uri()}?mode=ro"
    db: sqlite3.Connection | None = None
    try:
        db = sqlite3.connect(uri, uri=True)
        row = db.execute(
            """SELECT token_hash, token_count, members_json FROM market_universe_publications
               WHERE token_hash=? ORDER BY published_at DESC, publication_id DESC LIMIT 1""",
            (expected_accepted_hash,),
        ).fetchone()
    except sqlite3.Error as exc:
        raise MarketScanIncomplete("accepted_manifest_read_failed") from exc
    finally:
        if db is not None:
            db.close()
    if row is None:
        raise MarketScanIncomplete("accepted_manifest_missing")
    try:
        members = json.loads(row[2])
    except (TypeError, json.JSONDecodeError) as exc:
        raise MarketScanIncomplete("accepted_manifest_json_invalid") from exc
    if not isinstance(members, list) or not members:
        raise MarketScanIncomplete("accepted_manifest_members_invalid")
    has_schema = ["schema" in member if isinstance(member, dict) else False for member in members]
    if any(has_schema) and not all(has_schema):
        raise MarketScanIncomplete("accepted_manifest_mixed_schema")
    accepted_format = "v1" if all(has_schema) else "legacy"
    validated = ([_validate_manifest_member(
        member, allow_retired_historical=True
    ) for member in members]
                 if accepted_format == "v1" else
                 [_validate_legacy_manifest_member(member) for member in members])
    if members != sorted(members, key=lambda member: (member["token_id"], member["market_id"])):
        raise MarketScanIncomplete("accepted_manifest_order_invalid")
    if accepted_format == "v1":
        source_scan_ids = {member["source_scan_id"] for member in validated}
        if len(source_scan_ids) != 1:
            raise MarketScanIncomplete("accepted_manifest_mixed_scan")
    if len({member["token_id"] for member in validated}) != len(validated):
        raise MarketScanIncomplete("accepted_duplicate_mapping")
    if len({member["market_id"] for member in validated}) != len(validated):
        raise MarketScanIncomplete("accepted_duplicate_mapping")
    canonical = _canonical_research_members_json(members)
    expected_hash = hashlib.sha256(canonical.encode()).hexdigest()
    if (type(row[1]) is not int or row[1] != len(members)
            or not isinstance(row[0], str) or row[0] != expected_hash):
        raise MarketScanIncomplete("accepted_manifest_integrity_invalid")
    return AcceptedManifestMembers(list(members), accepted_format)


def _accepted_member_count_matches_realtime(
    accepted_members: list[dict[str, Any]], realtime_count: int,
) -> bool:
    """Accept the immutable count or its current active-city runtime view."""
    if realtime_count == len(accepted_members):
        return True
    if getattr(accepted_members, "accepted_format", None) != "v1":
        return False
    active_count = sum(
        1 for member in accepted_members
        if member["city"].lower() in CITY_ROLES
    )
    return realtime_count == active_count


def build_research_universe_candidate(
    records: list[dict[str, Any]], *, accepted_members: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Return an in-memory canonical enriched manifest candidate or fail closed."""
    if not records:
        raise MarketScanIncomplete("candidate_empty")
    required = (
        "schema", "scan_id", "scanned_at", "event_id", "event_title", "market_id",
        "market_question", "city", "city_scope", "station", "target_date",
        "resolution_source", "resolution_source_host", "bucket_label", "outcome",
        "token_id", "active", "closed", "attribution_status", "reason_code",
        "_query_city", "_query_target_date", "_outcome_token_bindings",
        "_gamma_token_evidence",
    )
    if any(not isinstance(record, dict) for record in records):
        raise MarketScanIncomplete("candidate_record_invalid")
    scan_values = [record.get("scan_id") for record in records]
    if any(type(scan_id) is not str or not scan_id or scan_id != scan_id.strip()
           for scan_id in scan_values):
        raise MarketScanIncomplete("candidate_field_type_invalid")
    scan_ids = set(scan_values)
    if len(scan_ids) != 1 or not next(iter(scan_ids), None):
        raise MarketScanIncomplete("candidate_mixed_scan")
    candidate_scan_id = next(iter(scan_ids))
    if not isinstance(candidate_scan_id, str) or not candidate_scan_id.strip():
        raise MarketScanIncomplete("candidate_field_type_invalid")
    normalized_scanned_at: set[str] = set()
    for record in records:
        try:
            scanned_at = record.get("scanned_at")
            if not isinstance(scanned_at, str) or not scanned_at:
                raise ValueError
            scanned = datetime.fromisoformat(scanned_at.replace("Z", "+00:00"))
            if scanned.tzinfo is None:
                raise ValueError
        except ValueError as exc:
            raise MarketScanIncomplete("candidate_date_invalid") from exc
        normalized_scanned_at.add(scanned.astimezone(UTC).isoformat())
    if len(normalized_scanned_at) != 1:
        raise MarketScanIncomplete("candidate_scanned_at_mismatch")
    candidate_scanned_at = next(iter(normalized_scanned_at))
    members: list[dict[str, str]] = []
    token_to_market: dict[str, str] = {}
    market_to_token: dict[str, str] = {}
    outcome_token_owner: dict[str, str] = {}
    for record in records:
        if any(field not in record or record[field] is None or record[field] == "" for field in required):
            raise MarketScanIncomplete("candidate_required_field_missing")
        if record["schema"] != RESEARCH_MARKET_SCHEMA:
            raise MarketScanIncomplete("candidate_schema_invalid")
        if ("source_scan_id" in record
                and (not isinstance(record["source_scan_id"], str)
                     or record["source_scan_id"] != candidate_scan_id)):
            raise MarketScanIncomplete("candidate_source_scan_id_invalid")
        if record["attribution_status"] != "verified" or record["reason_code"] != "verified":
            raise MarketScanIncomplete("candidate_not_verified")
        if record["active"] is not True or record["closed"] is not False:
            raise MarketScanIncomplete("candidate_activity_invalid")
        if record["outcome"] != "Yes":
            raise MarketScanIncomplete("candidate_outcome_invalid")
        string_fields = (
            "scan_id", "scanned_at", "event_id", "event_title", "market_id",
            "market_question", "city", "city_scope", "station", "target_date",
            "resolution_source", "resolution_source_host", "bucket_label", "token_id",
            "_query_city", "_query_target_date",
        )
        if any(not isinstance(record[field], str) or not record[field].strip() for field in string_fields):
            raise MarketScanIncomplete("candidate_field_type_invalid")
        try:
            scanned = datetime.fromisoformat(record["scanned_at"].replace("Z", "+00:00"))
            if scanned.tzinfo is None:
                raise ValueError
            target = date.fromisoformat(record["target_date"])
            if target.isoformat() != record["target_date"]:
                raise ValueError
            query_target = date.fromisoformat(record["_query_target_date"])
            if query_target.isoformat() != record["_query_target_date"]:
                raise ValueError
        except ValueError as exc:
            raise MarketScanIncomplete("candidate_date_invalid") from exc
        city = record["city"]
        city_key = city.lower()
        if city_key in RETIRED_CITY_KEYS:
            raise MarketScanIncomplete("candidate_retired_city")
        if city_key not in CITY_ROLES or city != city_key.title():
            raise MarketScanIncomplete("candidate_city_invalid")
        if record["city_scope"] != CITY_ROLES[city_key]:
            raise MarketScanIncomplete("candidate_scope_invalid")
        if record["station"] != CITY_SETTLEMENT_STATIONS[city_key]:
            raise MarketScanIncomplete("candidate_station_invalid")
        if record["_query_city"] != city:
            raise MarketScanIncomplete("candidate_query_binding_invalid")
        scan_china_date = scanned.astimezone(SHANGHAI_TZ).date()
        allowed_query_targets = {
            scan_china_date + timedelta(days=offset) for offset in range(3)
        }
        if query_target not in allowed_query_targets:
            raise MarketScanIncomplete("candidate_query_window_invalid")
        if query_target != target:
            raise MarketScanIncomplete("candidate_contract_invalid")
        event_identity = _contract_identity(
            record["event_title"], contract_kind="event", reference_date=query_target
        )
        market_identity = _contract_identity(
            record["market_question"], contract_kind="market", reference_date=query_target
        )
        if event_identity != (city, record["target_date"]) or market_identity != event_identity:
            raise MarketScanIncomplete("candidate_contract_invalid")
        question_match = MARKET_CONTRACT_RE.fullmatch(record["market_question"].strip())
        question_bucket = question_match.group("bucket") if question_match else None
        if (not _valid_temperature_bucket(record["bucket_label"])
                or not _valid_temperature_bucket(question_bucket)
                or _normalized_bucket(record["bucket_label"]) != _normalized_bucket(question_bucket)):
            raise MarketScanIncomplete("candidate_bucket_invalid")
        host, source_reason = _validate_resolution_source(
            record["resolution_source"], city, record["station"], "candidate"
        )
        if source_reason or host != record["resolution_source_host"]:
            raise MarketScanIncomplete("candidate_source_invalid")
        token = record["token_id"]
        market_id = record["market_id"]
        if not ASCII_TOKEN_RE.fullmatch(token):
            raise MarketScanIncomplete("candidate_token_invalid")
        bindings = record["_outcome_token_bindings"]
        if not isinstance(bindings, (list, tuple)) or not bindings:
            raise MarketScanIncomplete("candidate_outcome_token_format")
        if any(not isinstance(binding, (list, tuple)) or len(binding) != 2
               for binding in bindings):
            raise MarketScanIncomplete("candidate_outcome_token_count")
        if any(not isinstance(outcome, str) or not isinstance(outcome_token, str)
               for outcome, outcome_token in bindings):
            raise MarketScanIncomplete("candidate_outcome_token_type")
        normalized_outcomes = [outcome.strip().lower() for outcome, _token in bindings]
        yes_indices = [index for index, outcome in enumerate(normalized_outcomes)
                       if outcome == "yes"]
        if not yes_indices:
            raise MarketScanIncomplete("candidate_yes_missing")
        if len(yes_indices) != 1:
            raise MarketScanIncomplete("candidate_yes_ambiguous")
        derived_tokens = [outcome_token for _outcome, outcome_token in bindings]
        if any(not ASCII_TOKEN_RE.fullmatch(outcome_token) for outcome_token in derived_tokens):
            raise MarketScanIncomplete("candidate_outcome_tokens_invalid")
        if len(set(derived_tokens)) != len(derived_tokens):
            raise MarketScanIncomplete("candidate_outcome_tokens_invalid")
        if token != derived_tokens[yes_indices[0]]:
            raise MarketScanIncomplete("candidate_yes_token_mismatch")
        if token in token_to_market:
            if token_to_market[token] == market_id:
                raise MarketScanIncomplete("duplicate_mapping")
            raise MarketScanIncomplete("token_remapped")
        if market_id in market_to_token:
            if market_to_token[market_id] == token:
                raise MarketScanIncomplete("duplicate_mapping")
            raise MarketScanIncomplete("market_remapped")
        token_to_market[token] = market_id
        market_to_token[market_id] = token
        evidence = record["_gamma_token_evidence"]
        if not isinstance(evidence, _FrozenGammaTokenEvidence):
            raise MarketScanIncomplete("candidate_token_evidence_invalid")
        evidence_outcomes, evidence_tokens, evidence_yes_index, evidence_reason = (
            _gamma_outcome_token_facts(
                evidence.outcomes_json, evidence.clob_token_ids_json
            )
        )
        if evidence_reason is not None or evidence_yes_index is None:
            raise MarketScanIncomplete("candidate_token_evidence_invalid")
        evidence_bindings = tuple(zip(evidence_outcomes, evidence_tokens))
        normalized_bindings = tuple((outcome, outcome_token)
                                    for outcome, outcome_token in bindings)
        if (normalized_bindings != evidence_bindings
                or token != evidence_tokens[evidence_yes_index]):
            raise MarketScanIncomplete("candidate_token_evidence_mismatch")
        for outcome_token in evidence_tokens:
            if outcome_token in outcome_token_owner:
                raise MarketScanIncomplete("outcome_token_conflict")
            outcome_token_owner[outcome_token] = market_id
        member = {
            "schema": RESEARCH_MARKET_SCHEMA,
            "token_id": token,
            "market_id": market_id,
            "city": city,
            "city_scope": record["city_scope"],
            "station": record["station"],
            "target_date": record["target_date"],
            "outcome": "Yes",
            "event_id": record["event_id"],
            "source_scan_id": candidate_scan_id,
            "attribution_status": "verified",
        }
        # Preserve forward-compatible fact fields in both the returned member
        # and the hash.  Transport/evidence fields beginning with '_' never
        # leave this in-memory validation boundary.
        for key, value in record.items():
            if key.startswith("_") or key in _RESEARCH_CANDIDATE_INTERNAL_FIELDS:
                continue
            if key not in member:
                member[key] = value
        _validate_manifest_member(member)
        members.append(member)
    members.sort(key=lambda item: (item["token_id"], item["market_id"]))
    canonical = _canonical_research_members_json(members)
    distributions = {
        "cities": {city: sum(member["city"] == city for member in members)
                   for city in sorted({member["city"] for member in members})},
        "target_dates": {target: sum(member["target_date"] == target for member in members)
                         for target in sorted({member["target_date"] for member in members})},
        "city_scopes": {scope: sum(member["city_scope"] == scope for member in members)
                        for scope in sorted({member["city_scope"] for member in members})},
        "stations": {station: sum(member["station"] == station for member in members)
                     for station in sorted({member["station"] for member in members})},
    }
    candidate = {
        "schema": RESEARCH_MARKET_SCHEMA,
        "scan_id": candidate_scan_id,
        "source_scan_id": candidate_scan_id,
        "scanned_at": candidate_scanned_at,
        "members": members,
        "token_count": len(members),
        "token_hash": hashlib.sha256(canonical.encode()).hexdigest(),
        "distributions": distributions,
    }
    if accepted_members is not None:
        candidate["diff"] = research_universe_diff(members, accepted_members)
    return candidate


def _validate_publication_scan_statuses(
    statuses: list[dict[str, Any]], candidate: dict[str, Any]
) -> None:
    """Require one complete ten-city/three-day status matrix before approval."""
    if type(statuses) is not list or not statuses:
        raise MarketScanIncomplete("publication_scan_statuses_incomplete")
    try:
        scanned_at = datetime.fromisoformat(candidate["scanned_at"].replace("Z", "+00:00"))
    except (KeyError, AttributeError, ValueError) as exc:
        raise MarketScanIncomplete("publication_candidate_invalid") from exc
    scan_date = scanned_at.astimezone(SHANGHAI_TZ).date()
    expected_points = {
        (city_key.title(), (scan_date + timedelta(days=offset)).isoformat())
        for city_key in CITY_ROLES
        for offset in range(3)
    }
    grouped: dict[tuple[str, str], list[str]] = {}
    normalized_scan = scanned_at.astimezone(UTC).isoformat()
    for status in statuses:
        if type(status) is not dict:
            raise MarketScanIncomplete("publication_scan_status_invalid")
        city = status.get("city")
        target_date = status.get("target_date")
        state = status.get("attribution_status")
        reason = status.get("reason_code")
        if (
            not _strict_nonempty_string(city)
            or not _strict_iso_date(target_date)
            or not _strict_nonempty_string(state)
            or not _strict_nonempty_string(reason)
            or status.get("scan_id") != candidate.get("scan_id")
        ):
            raise MarketScanIncomplete("publication_scan_status_invalid")
        try:
            status_scanned = datetime.fromisoformat(
                status.get("scanned_at", "").replace("Z", "+00:00")
            )
        except (AttributeError, ValueError) as exc:
            raise MarketScanIncomplete("publication_scan_status_invalid") from exc
        if (
            status_scanned.tzinfo is None
            or status_scanned.astimezone(UTC).isoformat() != normalized_scan
        ):
            raise MarketScanIncomplete("publication_scan_status_invalid")
        city_key = city.lower()
        if (
            city_key not in CITY_ROLES
            or city != city_key.title()
            or status.get("city_scope") != CITY_ROLES[city_key]
            or status.get("station") != CITY_SETTLEMENT_STATIONS[city_key]
        ):
            raise MarketScanIncomplete("publication_scan_status_invalid")
        point = (city, target_date)
        if point not in expected_points:
            raise MarketScanIncomplete("publication_scan_status_invalid")
        if state not in {"verified", "no_active_market"}:
            raise MarketScanIncomplete("publication_scan_incomplete")
        if state == "no_active_market":
            if any(
                status.get(field) is not None
                for field in (
                    "event_id",
                    "event_title",
                    "market_id",
                    "market_question",
                    "resolution_source",
                    "resolution_source_host",
                    "bucket_label",
                    "outcome",
                    "token_id",
                )
            ):
                raise MarketScanIncomplete("publication_scan_status_invalid")
        grouped.setdefault(point, []).append(state)
    if set(grouped) != expected_points:
        raise MarketScanIncomplete("publication_scan_statuses_incomplete")
    verified_points: set[tuple[str, str]] = set()
    for point, states in grouped.items():
        state_set = set(states)
        if state_set == {"verified"}:
            verified_points.add(point)
        elif state_set != {"no_active_market"} or len(states) != 1:
            raise MarketScanIncomplete("publication_scan_status_conflict")
    candidate_points = {
        (member["city"], member["target_date"]) for member in candidate["members"]
    }
    if candidate_points != verified_points:
        raise MarketScanIncomplete("publication_scan_candidate_mismatch")


def _removed_token_hash(tokens: tuple[str, ...]) -> str:
    canonical = json.dumps(
        sorted(tokens), ensure_ascii=False, separators=(",", ":"), allow_nan=False
    )
    return hashlib.sha256(canonical.encode()).hexdigest()


def _json_native(value: Any) -> Any:
    """Return the exact strict-JSON representation used at the staging boundary."""
    try:
        return json.loads(json.dumps(
            value, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
            allow_nan=False,
        ))
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise MarketScanIncomplete("frozen_candidate_json_invalid") from exc


def _canonical_artifact_payload(artifact: dict[str, Any]) -> str:
    payload = {key: value for key, value in artifact.items() if key != "artifact_hash"}
    try:
        return json.dumps(
            payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise MarketScanIncomplete("frozen_candidate_json_invalid") from exc


def finalize_frozen_publication_artifact(
    artifact: dict[str, Any],
) -> dict[str, Any]:
    """Recompute the full artifact hash after constructing an immutable payload."""
    normalized = _json_native(artifact)
    normalized.pop("artifact_hash", None)
    normalized["artifact_hash"] = hashlib.sha256(
        _canonical_artifact_payload(normalized).encode()
    ).hexdigest()
    return normalized


def _validate_frozen_publication_window(
    staged_at: datetime, expires_at: datetime
) -> None:
    staged_china = staged_at.astimezone(SHANGHAI_TZ)
    expires_china = expires_at.astimezone(SHANGHAI_TZ)
    window_start = staged_china.replace(hour=0, minute=0, second=0, microsecond=0)
    window_end = staged_china.replace(
        hour=FORWARD_MIXED_WINDOW_END_HOUR,
        minute=0,
        second=0,
        microsecond=0,
    )
    if not (window_start <= staged_china < window_end) or expires_china > window_end:
        raise MarketScanIncomplete("publication_forward_window_invalid")


def _frozen_market_payload(event: dict[str, Any], market: dict[str, Any]) -> dict[str, Any]:
    if type(event) is not dict or type(market) is not dict:
        raise MarketScanIncomplete("frozen_candidate_market_invalid")
    frozen_event = {field: event.get(field) for field in FROZEN_EVENT_FIELDS}
    frozen_market = {field: market.get(field) for field in FROZEN_MARKET_FIELDS}
    try:
        frozen_market["liquidityNum"] = float(
            market.get("liquidityNum") or market.get("liquidity") or 0
        )
        frozen_market["volumeNum"] = float(
            market.get("volumeNum") or market.get("volume") or 0
        )
    except (TypeError, ValueError, OverflowError) as exc:
        raise MarketScanIncomplete("frozen_candidate_market_invalid") from exc
    return _json_native({"event": frozen_event, "market": frozen_market})


def _rebuild_frozen_attributions(
    market_payloads: list[dict[str, Any]], *, scan_id: str, scanned_at: str,
) -> list[dict[str, Any]]:
    if type(market_payloads) is not list or not market_payloads:
        raise MarketScanIncomplete("frozen_candidate_markets_invalid")
    rebuilt: list[dict[str, Any]] = []
    for payload in market_payloads:
        if type(payload) is not dict or set(payload) != {"event", "market"}:
            raise MarketScanIncomplete("frozen_candidate_market_invalid")
        event, market = payload["event"], payload["market"]
        if (
            type(event) is not dict
            or set(event) != FROZEN_EVENT_FIELDS
            or type(market) is not dict
            or set(market) != FROZEN_MARKET_FIELDS
        ):
            raise MarketScanIncomplete("frozen_candidate_market_invalid")
        if (
            any(not _strict_nonempty_string(event[field]) for field in (
                "id", "title", "resolutionSource", "_query_city",
                "_query_target_date",
            ))
            or event["active"] is not True
            or event["closed"] is not False
            or any(not _strict_nonempty_string(market[field]) for field in (
                "id", "question", "resolutionSource", "outcomes",
                "clobTokenIds", "groupItemTitle",
            ))
            or market["active"] is not True
            or market["closed"] is not False
            or any(
                market[field] is not None and type(market[field]) is not str
                for field in ("description", "endDate", "outcomePrices")
            )
            or any(
                type(market[field]) not in {int, float}
                or isinstance(market[field], bool)
                or not math.isfinite(float(market[field]))
                or float(market[field]) < 0
                for field in ("liquidityNum", "volumeNum")
            )
        ):
            raise MarketScanIncomplete("frozen_candidate_market_invalid")
        attribution = attribute_research_market(
            event, market, scan_id=scan_id, scanned_at=scanned_at
        )
        if attribution.get("attribution_status") != "verified":
            raise MarketScanIncomplete("frozen_candidate_market_rejected")
        rebuilt.append(attribution)
    return rebuilt


def _normalize_frozen_scan_statuses(
    statuses: list[dict[str, Any]], candidate: dict[str, Any]
) -> list[dict[str, Any]]:
    _validate_publication_scan_statuses(statuses, candidate)
    scanned = datetime.fromisoformat(candidate["scanned_at"].replace("Z", "+00:00"))
    scan_date = scanned.astimezone(SHANGHAI_TZ).date()
    candidate_points = {
        (member["city"], member["target_date"]) for member in candidate["members"]
    }
    reasons: dict[tuple[str, str], str] = {}
    for status in statuses:
        if status.get("attribution_status") == "no_active_market":
            reasons[(status["city"], status["target_date"])] = status["reason_code"]
    normalized: list[dict[str, Any]] = []
    for city_key in sorted(CITY_ROLES):
        city = city_key.title()
        for offset in range(3):
            target = (scan_date + timedelta(days=offset)).isoformat()
            point = (city, target)
            state = "verified" if point in candidate_points else "no_active_market"
            normalized.append({
                "schema": RESEARCH_MARKET_SCHEMA,
                "scan_id": candidate["scan_id"],
                "scanned_at": candidate["scanned_at"],
                "city": city,
                "city_scope": CITY_ROLES[city_key],
                "station": CITY_SETTLEMENT_STATIONS[city_key],
                "target_date": target,
                "attribution_status": state,
                "reason_code": "verified" if state == "verified" else reasons.get(
                    point, "no_exact_active_event"
                ),
            })
    _validate_publication_scan_statuses(normalized, candidate)
    return normalized


def build_frozen_publication_artifact(
    attributions: list[dict[str, Any]],
    scan_statuses: list[dict[str, Any]],
    market_payloads: list[dict[str, Any]],
    *,
    accepted_members: list[dict[str, Any]],
    expected_current_hash: str,
    expected_current_count: int,
    staged_at: datetime,
    expires_at: datetime,
) -> dict[str, Any]:
    """Freeze one complete, re-playable publication plan without writing SQLite."""
    if not _strict_lower_hash(expected_current_hash):
        raise MarketScanIncomplete("frozen_candidate_current_invalid")
    if type(expected_current_count) is not int or expected_current_count <= 0:
        raise MarketScanIncomplete("frozen_candidate_current_invalid")
    if len(accepted_members) != expected_current_count:
        raise MarketScanIncomplete("frozen_candidate_current_invalid")
    if getattr(accepted_members, "accepted_format", None) != "legacy":
        raise MarketScanIncomplete("frozen_candidate_current_not_legacy")
    if any(
        type(value) is not datetime
        or value.tzinfo is None
        or value.utcoffset() is None
        for value in (staged_at, expires_at)
    ):
        raise MarketScanIncomplete("frozen_candidate_time_invalid")
    lifetime = expires_at.astimezone(UTC) - staged_at.astimezone(UTC)
    if lifetime <= timedelta(0) or lifetime > timedelta(minutes=15):
        raise MarketScanIncomplete("frozen_candidate_lifetime_invalid")
    _validate_frozen_publication_window(staged_at, expires_at)
    candidate = build_research_universe_candidate(
        attributions, accepted_members=accepted_members
    )
    normalized_payloads: list[dict[str, Any]] = []
    for payload in market_payloads:
        if type(payload) is not dict:
            raise MarketScanIncomplete("frozen_candidate_market_invalid")
        normalized_payloads.append(
            _frozen_market_payload(payload.get("event"), payload.get("market"))
        )
    rebuilt = build_research_universe_candidate(
        _rebuild_frozen_attributions(
            normalized_payloads,
            scan_id=candidate["source_scan_id"],
            scanned_at=candidate["scanned_at"],
        ),
        accepted_members=accepted_members,
    )
    if _json_native(rebuilt) != _json_native(candidate):
        raise MarketScanIncomplete("frozen_candidate_rebuild_mismatch")
    if {item["market"]["id"] for item in normalized_payloads} != {
        member["market_id"] for member in candidate["members"]
    }:
        raise MarketScanIncomplete("frozen_candidate_market_set_mismatch")
    artifact = {
        "schema": UNIVERSE_PUBLICATION_STAGING_SCHEMA,
        "source_scan_id": candidate["source_scan_id"],
        "scanned_at": candidate["scanned_at"],
        "staged_at": staged_at.astimezone(UTC).isoformat(),
        "expires_at": expires_at.astimezone(UTC).isoformat(),
        "expected_current_hash": expected_current_hash,
        "expected_current_count": expected_current_count,
        "scan_statuses": _normalize_frozen_scan_statuses(scan_statuses, candidate),
        "market_payloads": normalized_payloads,
        "candidate": _json_native(candidate),
    }
    return finalize_frozen_publication_artifact(artifact)


def write_frozen_publication_artifact(
    path: str | Path, artifact: dict[str, Any]
) -> None:
    """Atomically replace the Collector-owned staging artifact in one directory."""
    target = Path(path)
    parent = target.parent
    parent.mkdir(parents=True, exist_ok=True)
    if parent.is_symlink() or not parent.is_dir():
        raise MarketScanIncomplete("frozen_candidate_parent_invalid")
    validated = finalize_frozen_publication_artifact(artifact)
    if validated != artifact:
        raise MarketScanIncomplete("frozen_candidate_hash_invalid")
    raw = _canonical_artifact_payload(artifact)
    full = json.dumps(
        artifact, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
        allow_nan=False,
    ).encode("utf-8")
    if not raw or len(full) > UNIVERSE_PUBLICATION_STAGING_MAX_BYTES:
        raise MarketScanIncomplete("frozen_candidate_size_invalid")
    temporary = target.with_name(
        f".{target.name}.{os.getpid()}.{clock.time_ns()}.tmp"
    )
    try:
        with temporary.open("xb") as handle:
            handle.write(full)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise MarketScanIncomplete("frozen_candidate_write_failed") from exc


def load_frozen_publication_artifact(
    path: str | Path, *, now: datetime | None = None,
) -> dict[str, Any]:
    """Strictly read and reconstruct one immutable staged publication plan."""
    target = Path(path)
    try:
        before = target.lstat()
        if target.is_symlink() or not stat.S_ISREG(before.st_mode):
            raise MarketScanIncomplete("frozen_candidate_not_regular_file")
        if before.st_size <= 0 or before.st_size > UNIVERSE_PUBLICATION_STAGING_MAX_BYTES:
            raise MarketScanIncomplete("frozen_candidate_size_invalid")
        with target.open("rb") as handle:
            opened = os.fstat(handle.fileno())
            if (
                not stat.S_ISREG(opened.st_mode)
                or (before.st_dev, before.st_ino) != (opened.st_dev, opened.st_ino)
            ):
                raise MarketScanIncomplete("frozen_candidate_changed_during_open")
            raw = handle.read(UNIVERSE_PUBLICATION_STAGING_MAX_BYTES + 1)
    except MarketScanIncomplete:
        raise
    except FileNotFoundError as exc:
        raise MarketScanIncomplete("frozen_candidate_missing") from exc
    except OSError as exc:
        raise MarketScanIncomplete("frozen_candidate_read_failed") from exc
    if not raw or len(raw) > UNIVERSE_PUBLICATION_STAGING_MAX_BYTES:
        raise MarketScanIncomplete("frozen_candidate_size_invalid")
    try:
        artifact = json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=_unique_json_object,
            parse_constant=_reject_json_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise MarketScanIncomplete("frozen_candidate_json_invalid") from exc
    if type(artifact) is not dict or set(artifact) != UNIVERSE_PUBLICATION_STAGING_FIELDS:
        raise MarketScanIncomplete("frozen_candidate_fields_invalid")
    if artifact.get("schema") != UNIVERSE_PUBLICATION_STAGING_SCHEMA:
        raise MarketScanIncomplete("frozen_candidate_schema_invalid")
    if (
        not _strict_nonempty_string(artifact.get("source_scan_id"))
        or not _strict_lower_hash(artifact.get("expected_current_hash"))
        or not _strict_lower_hash(artifact.get("artifact_hash"))
        or type(artifact.get("expected_current_count")) is not int
        or artifact["expected_current_count"] <= 0
    ):
        raise MarketScanIncomplete("frozen_candidate_fields_invalid")
    expected_artifact_hash = hashlib.sha256(
        _canonical_artifact_payload(artifact).encode()
    ).hexdigest()
    if artifact["artifact_hash"] != expected_artifact_hash:
        raise MarketScanIncomplete("frozen_candidate_hash_invalid")
    staged_at = _strict_aware_datetime(artifact.get("staged_at"))
    expires_at = _strict_aware_datetime(artifact.get("expires_at"))
    if (
        expires_at <= staged_at
        or expires_at - staged_at > timedelta(minutes=15)
    ):
        raise MarketScanIncomplete("frozen_candidate_lifetime_invalid")
    _validate_frozen_publication_window(staged_at, expires_at)
    reference = now if now is not None else datetime.now(UTC)
    if (
        type(reference) is not datetime
        or reference.tzinfo is None
        or reference.utcoffset() is None
    ):
        raise MarketScanIncomplete("frozen_candidate_now_invalid")
    reference_utc = reference.astimezone(UTC)
    staged_utc = staged_at.astimezone(UTC)
    if reference_utc < staged_utc:
        raise MarketScanIncomplete("frozen_candidate_not_active")
    if reference_utc >= expires_at.astimezone(UTC):
        raise MarketScanIncomplete("frozen_candidate_not_active")
    scanned_at = _strict_aware_datetime(artifact.get("scanned_at"))
    if scanned_at.astimezone(UTC) > staged_utc:
        raise MarketScanIncomplete("frozen_candidate_time_invalid")
    market_payloads = artifact.get("market_payloads")
    rebuilt_base = build_research_universe_candidate(
        _rebuild_frozen_attributions(
            market_payloads,
            scan_id=artifact["source_scan_id"],
            scanned_at=scanned_at.astimezone(UTC).isoformat(),
        )
    )
    candidate = artifact.get("candidate")
    if (
        type(candidate) is not dict
        or set(candidate) != FROZEN_CANDIDATE_FIELDS
        or candidate.get("source_scan_id") != artifact["source_scan_id"]
    ):
        raise MarketScanIncomplete("frozen_candidate_candidate_invalid")
    for field in (
        "schema", "scan_id", "source_scan_id", "scanned_at", "members",
        "token_count", "token_hash", "distributions",
    ):
        if candidate.get(field) != _json_native(rebuilt_base).get(field):
            raise MarketScanIncomplete("frozen_candidate_candidate_invalid")
    diff = candidate.get("diff")
    if (
        type(diff) is not dict
        or set(diff) != {"added", "removed", "remapped", "pure_add"}
        or any(type(diff[key]) is not list for key in ("added", "removed", "remapped"))
        or type(diff["pure_add"]) is not bool
    ):
        raise MarketScanIncomplete("frozen_candidate_diff_invalid")
    scan_statuses = artifact.get("scan_statuses")
    if (
        type(scan_statuses) is not list
        or any(type(status) is not dict or set(status) != FROZEN_SCAN_STATUS_FIELDS
               for status in scan_statuses)
    ):
        raise MarketScanIncomplete("frozen_candidate_status_invalid")
    _validate_publication_scan_statuses(scan_statuses, candidate)
    if {item["market"]["id"] for item in market_payloads} != {
        member["market_id"] for member in candidate["members"]
    }:
        raise MarketScanIncomplete("frozen_candidate_market_set_mismatch")
    return artifact


def _identical_successful_publication_exists_read_only(
    database_path: str | Path, candidate: dict[str, Any]
) -> bool:
    """Return True only for an already committed, byte-equivalent candidate."""
    path = Path(database_path).resolve()
    uri = f"{path.as_uri()}?mode=ro"
    db: sqlite3.Connection | None = None
    try:
        db = sqlite3.connect(uri, uri=True, timeout=0.2)
        rows = db.execute(
            """SELECT publication_id,published_at,token_hash,token_count,members_json,reason
               FROM market_universe_publications WHERE token_hash=?
               ORDER BY published_at DESC,publication_id DESC""",
            (candidate["token_hash"],),
        ).fetchall()
    except sqlite3.Error as exc:
        raise MarketScanIncomplete("publication_idempotency_read_failed") from exc
    finally:
        if db is not None:
            db.close()
    if not rows:
        return False
    canonical = _canonical_research_members_json(candidate["members"])
    for publication_id, published_at, token_hash, token_count, members_json, reason in rows:
        if (
            reason != "complete_scan"
            or token_hash != candidate["token_hash"]
            or type(token_count) is not int
            or token_count != candidate["token_count"]
            or members_json != canonical
            or not _strict_nonempty_string(published_at)
            or publication_id != f"{published_at}:{token_hash[:12]}"
        ):
            continue
        try:
            published = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
        except ValueError:
            continue
        if published.tzinfo is not None and published.utcoffset() is not None:
            return True
    raise MarketScanIncomplete("publication_idempotency_conflict")


def authorize_research_universe_publication(
    records: list[dict[str, Any]],
    scan_statuses: list[dict[str, Any]],
    *,
    approval_path: str | Path | None = None,
    realtime_database_path: str | Path | None = None,
    research_database_path: str | Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Bind one regenerated v1 candidate to T00 approval and Realtime accepted facts."""
    approval = load_universe_publication_approval(approval_path, now=now)
    realtime_accepted = load_realtime_accepted_universe_read_only(realtime_database_path)
    if realtime_accepted["token_hash"] != approval["expected_current_hash"]:
        raise MarketScanIncomplete("publication_current_hash_mismatch")
    research_path = Path(
        research_database_path if research_database_path is not None else DB_PATH
    )
    accepted_members = load_accepted_research_universe_members_read_only(
        research_path,
        expected_accepted_hash=realtime_accepted["token_hash"],
    )
    if getattr(accepted_members, "accepted_format", None) != "legacy":
        raise MarketScanIncomplete("publication_current_not_legacy")
    if not _accepted_member_count_matches_realtime(
        accepted_members, realtime_accepted["token_count"]
    ):
        raise MarketScanIncomplete("publication_current_count_mismatch")
    candidate = build_research_universe_candidate(
        records, accepted_members=accepted_members
    )
    _validate_publication_scan_statuses(scan_statuses, candidate)
    effective_now = now if now is not None else datetime.now(UTC)
    current_china_date = effective_now.astimezone(SHANGHAI_TZ).date()
    if any(date.fromisoformat(member["target_date"]) < current_china_date
           for member in candidate["members"]):
        raise MarketScanIncomplete("publication_candidate_contains_past_date")
    diff = candidate["diff"]
    if diff["remapped"]:
        raise MarketScanIncomplete("publication_remap_not_allowed")
    added = diff["added"]
    removed = diff["removed"]
    candidate_by_token = {member["token_id"]: member for member in candidate["members"]}
    accepted_by_token = {member["token_id"]: member for member in accepted_members}
    added_dates = sorted({candidate_by_token[token]["target_date"] for token in added})
    removed_dates = sorted({accepted_by_token[token]["target_date"] for token in removed})
    actual_added_hash = _removed_token_hash(added)
    actual_removed_hash = _removed_token_hash(removed)
    comparisons: tuple[tuple[object, object, str], ...] = (
        (candidate["token_hash"], approval["approved_candidate_hash"], "publication_candidate_hash_mismatch"),
        (candidate["token_count"], approval["approved_token_count"], "publication_candidate_count_mismatch"),
        (len(added), approval["approved_added_count"], "publication_added_count_mismatch"),
        (len(removed), approval["approved_removed_count"], "publication_removed_count_mismatch"),
        (len(diff["remapped"]), approval["approved_remapped_count"], "publication_remapped_count_mismatch"),
    )
    if approval["schema"] == UNIVERSE_PUBLICATION_APPROVAL_SCHEMA:
        if added:
            raise MarketScanIncomplete("publication_added_not_allowed")
        comparisons += (
            (actual_removed_hash, approval["approved_removed_token_hash"], "publication_removed_hash_mismatch"),
            (removed_dates, approval["allowed_removed_target_dates"], "publication_removed_dates_mismatch"),
        )
    elif approval["schema"] == UNIVERSE_FORWARD_MIXED_PUBLICATION_APPROVAL_SCHEMA:
        china_time = effective_now.astimezone(SHANGHAI_TZ).timetz().replace(tzinfo=None)
        if not (time(0, 0) <= china_time < time(FORWARD_MIXED_WINDOW_END_HOUR, 0)):
            raise MarketScanIncomplete("publication_forward_window_invalid")
        if not added or not removed:
            raise MarketScanIncomplete("publication_forward_diff_invalid")
        if any(date.fromisoformat(target) < current_china_date for target in added_dates):
            raise MarketScanIncomplete("publication_added_date_invalid")
        if any(date.fromisoformat(target) >= current_china_date for target in removed_dates):
            raise MarketScanIncomplete("publication_removed_date_invalid")
        comparisons += (
            (actual_added_hash, approval["approved_added_token_hash"], "publication_added_hash_mismatch"),
            (actual_removed_hash, approval["approved_removed_token_hash"], "publication_removed_hash_mismatch"),
            (added_dates, approval["allowed_added_target_dates"], "publication_added_dates_mismatch"),
            (removed_dates, approval["allowed_removed_target_dates"], "publication_removed_dates_mismatch"),
        )
    else:
        raise MarketScanIncomplete("publication_approval_schema_invalid")
    for actual, approved, reason in comparisons:
        if actual != approved:
            raise MarketScanIncomplete(reason)
    return {
        "approval": approval,
        "current": realtime_accepted,
        "candidate": candidate,
        "already_published": _identical_successful_publication_exists_read_only(
            research_path, candidate
        ),
    }


def authorize_frozen_research_universe_publication(
    *,
    staging_path: str | Path,
    approval_path: str | Path,
    realtime_database_path: str | Path | None = None,
    research_database_path: str | Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Bind one v3 approval to the exact staged plan; never perform discovery."""
    effective_now = now if now is not None else datetime.now(UTC)
    artifact = load_frozen_publication_artifact(staging_path, now=effective_now)
    approval = load_universe_publication_approval(approval_path, now=effective_now)
    if approval.get("schema") != UNIVERSE_FROZEN_PUBLICATION_APPROVAL_SCHEMA:
        raise MarketScanIncomplete("publication_frozen_approval_required")
    artifact_expiry = _strict_aware_datetime(artifact["expires_at"])
    approval_expiry = _strict_aware_datetime(approval["expires_at"])
    if approval_expiry.astimezone(UTC) > artifact_expiry.astimezone(UTC):
        raise MarketScanIncomplete("publication_approval_exceeds_artifact")
    china_time = effective_now.astimezone(SHANGHAI_TZ).timetz().replace(tzinfo=None)
    if not (time(0, 0) <= china_time < time(FORWARD_MIXED_WINDOW_END_HOUR, 0)):
        raise MarketScanIncomplete("publication_forward_window_invalid")
    realtime_accepted = load_realtime_accepted_universe_read_only(
        realtime_database_path
    )
    research_path = Path(
        research_database_path if research_database_path is not None else DB_PATH
    )
    accepted_members = load_accepted_research_universe_members_read_only(
        research_path,
        expected_accepted_hash=realtime_accepted["token_hash"],
    )
    if getattr(accepted_members, "accepted_format", None) != "legacy":
        raise MarketScanIncomplete("publication_current_not_legacy")
    if (
        realtime_accepted["token_hash"] != artifact["expected_current_hash"]
        or realtime_accepted["token_count"] != artifact["expected_current_count"]
        or len(accepted_members) != realtime_accepted["token_count"]
    ):
        raise MarketScanIncomplete("publication_current_hash_mismatch")
    rebuilt_attributions = _rebuild_frozen_attributions(
        artifact["market_payloads"],
        scan_id=artifact["source_scan_id"],
        scanned_at=artifact["scanned_at"],
    )
    candidate = build_research_universe_candidate(
        rebuilt_attributions, accepted_members=accepted_members
    )
    candidate_json = _json_native(candidate)
    if candidate_json != artifact["candidate"]:
        raise MarketScanIncomplete("frozen_candidate_rebuild_mismatch")
    _validate_publication_scan_statuses(artifact["scan_statuses"], candidate)
    current_china_date = effective_now.astimezone(SHANGHAI_TZ).date()
    if any(
        date.fromisoformat(member["target_date"]) < current_china_date
        for member in candidate["members"]
    ):
        raise MarketScanIncomplete("publication_candidate_contains_past_date")
    diff = candidate["diff"]
    added, removed, remapped = diff["added"], diff["removed"], diff["remapped"]
    if not added or not removed or remapped:
        raise MarketScanIncomplete("publication_forward_diff_invalid")
    candidate_by_token = {member["token_id"]: member for member in candidate["members"]}
    accepted_by_token = {member["token_id"]: member for member in accepted_members}
    added_dates = sorted({candidate_by_token[token]["target_date"] for token in added})
    removed_dates = sorted({accepted_by_token[token]["target_date"] for token in removed})
    if any(date.fromisoformat(target) < current_china_date for target in added_dates):
        raise MarketScanIncomplete("publication_added_date_invalid")
    if any(date.fromisoformat(target) >= current_china_date for target in removed_dates):
        raise MarketScanIncomplete("publication_removed_date_invalid")
    comparisons: tuple[tuple[object, object, str], ...] = (
        (artifact["artifact_hash"], approval["approved_artifact_hash"], "publication_artifact_hash_mismatch"),
        (artifact["source_scan_id"], approval["approved_source_scan_id"], "publication_source_scan_mismatch"),
        (artifact["expected_current_hash"], approval["expected_current_hash"], "publication_current_hash_mismatch"),
        (candidate["token_hash"], approval["approved_candidate_hash"], "publication_candidate_hash_mismatch"),
        (candidate["token_count"], approval["approved_token_count"], "publication_candidate_count_mismatch"),
        (len(added), approval["approved_added_count"], "publication_added_count_mismatch"),
        (len(removed), approval["approved_removed_count"], "publication_removed_count_mismatch"),
        (len(remapped), approval["approved_remapped_count"], "publication_remapped_count_mismatch"),
        (_removed_token_hash(added), approval["approved_added_token_hash"], "publication_added_hash_mismatch"),
        (_removed_token_hash(removed), approval["approved_removed_token_hash"], "publication_removed_hash_mismatch"),
        (added_dates, approval["allowed_added_target_dates"], "publication_added_dates_mismatch"),
        (removed_dates, approval["allowed_removed_target_dates"], "publication_removed_dates_mismatch"),
    )
    for actual, approved, reason in comparisons:
        if actual != approved:
            raise MarketScanIncomplete(reason)
    return {
        "artifact": artifact,
        "approval": approval,
        "current": realtime_accepted,
        "candidate": candidate_json,
        "market_payloads": artifact["market_payloads"],
        "already_published": _identical_successful_publication_exists_read_only(
            research_path, candidate
        ),
    }


def _frozen_publish_now_utc() -> datetime:
    """Production commit clock: deliberately read only after the second acceptance check."""
    return datetime.now(UTC)


def _validated_frozen_payload_event_count(
    payloads: object, candidate: dict[str, Any]
) -> tuple[set[str], int]:
    if not isinstance(payloads, list):
        raise MarketScanIncomplete("frozen_candidate_market_set_mismatch")
    market_ids: set[str] = set()
    event_ids: set[str] = set()
    for payload in payloads:
        if not isinstance(payload, dict) or not isinstance(payload.get("event"), dict) or not isinstance(payload.get("market"), dict):
            raise MarketScanIncomplete("frozen_candidate_market_set_mismatch")
        event_id, market_id = payload["event"].get("id"), payload["market"].get("id")
        if type(event_id) is not str or not event_id or type(market_id) is not str or not market_id:
            raise MarketScanIncomplete("frozen_candidate_market_set_mismatch")
        if market_id in market_ids:
            raise MarketScanIncomplete("frozen_candidate_market_set_mismatch")
        market_ids.add(market_id)
        event_ids.add(event_id)
    if market_ids != {member["market_id"] for member in candidate["members"]}:
        raise MarketScanIncomplete("frozen_candidate_market_set_mismatch")
    return market_ids, len(event_ids)


def publish_frozen_research_universe(
    db: sqlite3.Connection,
    decision: dict[str, Any],
    *,
    published_at: str | None = None,
    realtime_database_path: str | Path,
    commit_now: datetime | None = None,
) -> int:
    """Apply exactly one validated frozen plan in the existing short transaction."""
    artifact = decision["artifact"]
    approval = decision["approval"]
    candidate = decision["candidate"]
    payloads = decision["market_payloads"]
    scan_time = artifact["scanned_at"]
    market_ids, event_count = _validated_frozen_payload_event_count(payloads, candidate)
    latest_accepted = load_realtime_accepted_universe_read_only(
        realtime_database_path
    )
    if (
        latest_accepted["token_hash"] != decision["current"]["token_hash"]
        or latest_accepted["token_count"] != decision["current"]["token_count"]
    ):
        raise MarketScanIncomplete("publication_current_hash_mismatch")
    # No production clock is captured until acceptance has been reread and
    # compared.  A slow read therefore cannot authorize a stale commit time.
    effective_commit_now = commit_now if commit_now is not None else _frozen_publish_now_utc()
    if not isinstance(effective_commit_now, datetime) or effective_commit_now.tzinfo is None:
        raise MarketScanIncomplete("frozen_candidate_commit_time_invalid")
    publication_time = effective_commit_now.astimezone(UTC).isoformat()
    artifact_staged = _strict_aware_datetime(artifact["staged_at"])
    artifact_expires = _strict_aware_datetime(artifact["expires_at"])
    approval_not_before = _strict_aware_datetime(approval["not_before"])
    approval_expires = _strict_aware_datetime(approval["expires_at"])
    if not (
        artifact_staged <= effective_commit_now < artifact_expires
        and approval_not_before <= effective_commit_now < approval_expires
        and approval_expires <= artifact_expires
    ):
        raise MarketScanIncomplete("frozen_candidate_not_active")
    china_time = effective_commit_now.astimezone(SHANGHAI_TZ).timetz().replace(tzinfo=None)
    if not (time(0, 0) <= china_time < time(6, 0)):
        raise MarketScanIncomplete("publication_frozen_window_invalid")
    deadline = clock.monotonic() + MARKET_PUBLISH_BUDGET_SECONDS
    db.set_progress_handler(lambda: int(clock.monotonic() > deadline), 1000)
    try:
        db.execute("BEGIN IMMEDIATE")
        for payload in payloads:
            event, market = payload["event"], payload["market"]
            attribution = attribute_research_market(
                event,
                market,
                scan_id=artifact["source_scan_id"],
                scanned_at=artifact["scanned_at"],
            )
            if attribution.get("attribution_status") != "verified":
                raise MarketScanIncomplete("frozen_candidate_market_rejected")
            station, city = attribution["station"], attribution["city"]
            airport = AIRPORTS.get(station)
            if not airport or airport.get("lat") is None or airport.get("lon") is None:
                raise MarketScanIncomplete("frozen_candidate_station_missing")
            db.execute(
                "INSERT OR IGNORE INTO airport_stations VALUES (?, ?, ?, ?, ?)",
                (station, city, float(airport["lat"]), float(airport["lon"]), scan_time),
            )
            save_market(db, scan_time, market, city)
            db.execute(
                """INSERT INTO market_rules
                (market_id,city,question,resolution_source,description,first_seen_at,last_seen_at)
                VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(market_id) DO UPDATE SET question=excluded.question,
                  resolution_source=excluded.resolution_source,
                  description=excluded.description,last_seen_at=excluded.last_seen_at""",
                (
                    str(market["id"]), city, market.get("question", ""),
                    market.get("resolutionSource"), market.get("description"),
                    scan_time, scan_time,
                ),
            )
        deactivate_missing_markets(db, market_ids)
        publish_market_universe(
            db, publication_time, candidate["members"], "complete_scan"
        )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.set_progress_handler(None, 0)
    return event_count


def prepare_research_universe_publication(
    records: list[dict[str, Any]],
    scan_statuses: list[dict[str, Any]],
    *,
    approval_path: str | Path | None = None,
    realtime_database_path: str | Path | None = None,
    research_database_path: str | Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Apply the one-time gate only while Realtime still accepts homogeneous legacy."""
    realtime_accepted = load_realtime_accepted_universe_read_only(realtime_database_path)
    research_path = Path(
        research_database_path if research_database_path is not None else DB_PATH
    )
    accepted_members = load_accepted_research_universe_members_read_only(
        research_path,
        expected_accepted_hash=realtime_accepted["token_hash"],
    )
    if not _accepted_member_count_matches_realtime(
        accepted_members, realtime_accepted["token_count"]
    ):
        raise MarketScanIncomplete("publication_current_count_mismatch")
    if getattr(accepted_members, "accepted_format", None) == "legacy":
        return authorize_research_universe_publication(
            records,
            scan_statuses,
            approval_path=approval_path,
            realtime_database_path=realtime_database_path,
            research_database_path=research_path,
            now=now,
        )
    if getattr(accepted_members, "accepted_format", None) != "v1":
        raise MarketScanIncomplete("publication_current_format_invalid")
    candidate = build_research_universe_candidate(records)
    # A routine scan has a new source_scan_id, but that observation identity is
    # not an asset or immutable-attribution change.  Keep collecting market
    # facts while suppressing only the redundant universe publication.
    return {
        "approval": None,
        "current": realtime_accepted,
        "candidate": candidate,
        "already_published": False,
        "suppress_universe_publication": _metadata_only_v1_publication(
            accepted_members, candidate["members"],
        ),
    }


def _metadata_only_v1_publication(
    accepted_members: list[dict[str, Any]],
    candidate_members: list[dict[str, Any]],
) -> bool:
    """Return true only for one homogeneous v1 scan-identity refresh."""
    if getattr(accepted_members, "accepted_format", None) != "v1":
        return False
    if not accepted_members or len(accepted_members) != len(candidate_members):
        return False
    try:
        accepted = [_validate_manifest_member(
            member, allow_retired_historical=True
        ) for member in accepted_members]
        candidate = [_validate_manifest_member(member) for member in candidate_members]
    except MarketScanIncomplete:
        return False
    canonical_order = lambda member: (member["token_id"], member["market_id"])
    if (
        accepted != sorted(accepted, key=canonical_order)
        or candidate != sorted(candidate, key=canonical_order)
        or len({member["token_id"] for member in accepted}) != len(accepted)
        or len({member["market_id"] for member in accepted}) != len(accepted)
        or len({member["token_id"] for member in candidate}) != len(candidate)
        or len({member["market_id"] for member in candidate}) != len(candidate)
    ):
        return False
    accepted_scans = {member["source_scan_id"] for member in accepted}
    candidate_scans = {member["source_scan_id"] for member in candidate}
    if (
        len(accepted_scans) != 1
        or len(candidate_scans) != 1
        or accepted_scans == candidate_scans
    ):
        return False
    for old, new in zip(accepted, candidate):
        old_facts, new_facts = dict(old), dict(new)
        old_facts.pop("source_scan_id", None)
        new_facts.pop("source_scan_id", None)
        if old_facts != new_facts:
            return False
    return True


def station_and_city(event: dict[str, Any], *, reference_date: date | None = None) -> tuple[str, str, float, float] | None:
    """Return airport metadata only for explicit, highest-temperature contracts."""
    try:
        if event.get("_query_target_date"):
            reference_date = date.fromisoformat(str(event["_query_target_date"]))
    except ValueError:
        return None
    identity = _contract_identity(
        str(event.get("title") or ""), contract_kind="event", reference_date=reference_date
    )
    if identity is None:
        return None
    city, target_date = identity
    query_city = event.get("_query_city")
    query_target = event.get("_query_target_date")
    if query_city is not None and str(query_city).strip().lower().title() != city:
        return None
    if query_target is not None and str(query_target) != target_date:
        return None
    expected_station = CITY_SETTLEMENT_STATIONS[city.lower()]
    _host, reason = _validate_resolution_source(
        event.get("resolutionSource"), city, expected_station, "event"
    )
    if reason:
        return None
    airport = AIRPORTS.get(expected_station)
    if not airport or airport.get("lat") is None or airport.get("lon") is None:
        logging.warning("skip event %s: no airport coordinate for %s", event.get("id"), expected_station)
        return None
    return expected_station, city, float(airport["lat"]), float(airport["lon"])


def _classify_search_event_for_query(
    event: dict[str, Any], query_city: str, query_target_date: str
) -> tuple[str, str | None]:
    """Classify one active search summary before any detail request."""
    if not str(event.get("id") or "").strip():
        return "invalid_or_misrouted", "search_event_id_missing"
    match = EVENT_CONTRACT_RE.fullmatch(str(event.get("title") or "").strip())
    if match is None:
        return "invalid_or_misrouted", "search_event_contract_invalid"
    if match.group("city").strip().lower() != query_city.lower():
        return "invalid_or_misrouted", "search_event_query_city_mismatch"
    try:
        query_date = date.fromisoformat(query_target_date)
    except ValueError:
        return "invalid_or_misrouted", "search_query_target_invalid"
    parsed_target = _date_near_reference(
        match.group("month"), match.group("day"), match.group("year"), query_date
    )
    if parsed_target is None:
        return "invalid_or_misrouted", "search_event_target_invalid"
    if parsed_target != query_target_date:
        return "same_city_other_date", None
    return "exact_match", None


async def active_events(
    client: httpx.AsyncClient,
    progress: CollectorProgress | None = None,
    *,
    query_date: date | None = None,
    query_results: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    # Weather temperature contracts are multi-outcome *events*. The generic
    # market listing did not surface them reliably; Gamma's search endpoint does.
    today = query_date or datetime.now(SHANGHAI_TZ).date()
    queries: list[tuple[str, str, str]] = []
    for city_key in sorted(ALLOWED_CITIES):
        city = city_key.title()
        for offset in range(3):
            target = today.fromordinal(today.toordinal() + offset)
            queries.append((city,
                            f"highest temperature in {city} on {target.strftime('%B')} {target.day}",
                            target.isoformat()))
    query_slots: dict[tuple[str, str], dict[str, Any]] = {}
    if query_results is not None:
        for city, _phrase, target_date in queries:
            slot = {
                "query_city": city,
                "query_target_date": target_date,
                "status": "pending",
                "reason_code": "search_not_completed",
            }
            query_results.append(slot)
            query_slots[(city, target_date)] = slot
    if progress:
        progress.begin("market_search", len(queries), MARKET_SCAN_BUDGET_SECONDS)
    semaphore = asyncio.Semaphore(max(1, MARKET_REQUEST_CONCURRENCY))
    completed = 0

    async def search(city: str, phrase: str, target_date: str) -> tuple[
        str, str, list[dict[str, Any]] | None, MarketScanIncomplete | None
    ]:
        nonlocal completed
        try:
            async with semaphore:
                response = await client.get(f"{GAMMA}/public-search", params={"q": phrase, "limit": 20})
                response.raise_for_status()
                payload = response.json()
                if not isinstance(payload, dict):
                    raise MarketScanIncomplete("search_response_not_object")
                if "events" not in payload:
                    raise MarketScanIncomplete("search_response_events_missing")
                events = payload["events"]
                if not isinstance(events, list):
                    raise MarketScanIncomplete("search_response_events_not_list")
                if any(not isinstance(event, dict) for event in events):
                    raise MarketScanIncomplete("search_response_event_not_object")
                return city, target_date, events, None
        except MarketScanIncomplete as exc:
            return city, target_date, None, exc
        except (httpx.HTTPError, ValueError) as exc:
            return city, target_date, None, MarketScanIncomplete(
                "search_request_failed", f"{phrase}: {exc}"
            )
        finally:
            completed += 1
            if progress:
                progress.advance(completed)

    results = await asyncio.gather(*(search(city, phrase, target_date)
                                     for city, phrase, target_date in queries))
    failures: list[MarketScanIncomplete] = []
    found: dict[str, dict[str, Any]] = {}
    for query_city, target_date, events, failure in results:
        if failure is not None:
            failures.append(failure)
            slot = query_slots.get((query_city, target_date))
            if slot is not None:
                slot.update(status="search_failed", reason_code=failure.reason_code)
            continue
        slot = query_slots.get((query_city, target_date))
        if any(
            "active" not in event
            or "closed" not in event
            or type(event["active"]) is not bool
            or type(event["closed"]) is not bool
            for event in (events or [])
        ):
            failure = MarketScanIncomplete("search_event_activity_invalid")
            failures.append(failure)
            if slot is not None:
                slot.update(
                    status="attribution_rejected",
                    reason_code=failure.reason_code,
                )
            continue
        active = [event for event in (events or [])
                  if event["active"] is True and event["closed"] is False]
        exact_events: dict[str, dict[str, Any]] = {}
        saw_same_city_other_date = False
        query_rejected = False
        for event in active:
            classification, query_reason = _classify_search_event_for_query(
                event, query_city, target_date
            )
            if classification == "same_city_other_date":
                saw_same_city_other_date = True
                continue
            if classification == "invalid_or_misrouted":
                failure = MarketScanIncomplete(query_reason or "search_event_attribution_rejected")
                failures.append(failure)
                query_rejected = True
                if slot is not None:
                    slot.update(status="attribution_rejected", reason_code=failure.reason_code)
                continue
            event_id = str(event.get("id") or "").strip()
            exact_events.setdefault(event_id, event)
        if query_rejected:
            continue
        if not exact_events:
            query_target = date.fromisoformat(target_date)
            slug = (
                f"highest-temperature-in-{query_city.lower().replace(' ', '-')}"
                f"-on-{query_target.strftime('%B').lower()}-{query_target.day}"
                f"-{query_target.year}"
            )
            try:
                async with semaphore:
                    slug_response = await client.get(f"{GAMMA}/events/slug/{slug}")
                if slug_response.status_code != 404:
                    slug_response.raise_for_status()
                    slug_event = slug_response.json()
                    if not isinstance(slug_event, dict):
                        raise MarketScanIncomplete("slug_event_not_object")
                    if (
                        "active" not in slug_event
                        or "closed" not in slug_event
                        or type(slug_event["active"]) is not bool
                        or type(slug_event["closed"]) is not bool
                    ):
                        raise MarketScanIncomplete("slug_event_activity_invalid")
                    if slug_event["active"] is True and slug_event["closed"] is False:
                        classification, slug_reason = _classify_search_event_for_query(
                            slug_event, query_city, target_date
                        )
                        if classification != "exact_match":
                            raise MarketScanIncomplete(
                                slug_reason or "slug_event_attribution_rejected"
                            )
                        event_id = str(slug_event.get("id") or "").strip()
                        exact_events[event_id] = slug_event
            except MarketScanIncomplete as exc:
                failures.append(exc)
                if slot is not None:
                    slot.update(status="attribution_rejected", reason_code=exc.reason_code)
                continue
            except (httpx.HTTPError, ValueError) as exc:
                failure = MarketScanIncomplete(
                    "slug_event_request_failed", f"{slug}: {exc}"
                )
                failures.append(failure)
                if slot is not None:
                    slot.update(status="search_failed", reason_code=failure.reason_code)
                continue
        if len(exact_events) > 1:
            failure = MarketScanIncomplete("multiple_exact_active_events")
            failures.append(failure)
            if slot is not None:
                slot.update(
                    status="attribution_rejected",
                    reason_code=failure.reason_code,
                )
            continue
        if not exact_events:
            if slot is not None:
                slot.update(
                    status="no_active_market",
                    reason_code=("no_exact_active_event" if saw_same_city_other_date
                                 else "no_active_event"),
                )
            continue
        if slot is not None:
            slot.update(status="pending", reason_code="event_detail_pending")
        event_id, event = next(iter(exact_events.items()))
        attributed = dict(event)
        attributed["_query_city"] = query_city
        attributed["_query_target_date"] = target_date
        prior = found.get(event_id)
        if prior and (prior.get("_query_city"), prior.get("_query_target_date")) != (
            query_city, target_date
        ):
            raise MarketScanIncomplete("search_event_query_ambiguous")
        found[event_id] = attributed
    if failures:
        raise failures[0]
    return list(found.values())


def save_market(db: sqlite3.Connection, captured_at: str, market: dict[str, Any], city: str) -> None:
    db.execute("""INSERT OR REPLACE INTO market_snapshots
        (captured_at, market_id, city, question, description, resolution_source, end_date, outcomes_json, prices_json, tokens_json, liquidity, volume, active, closed, bucket_label)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", (
        captured_at, str(market["id"]), city, market.get("question", ""), market.get("description"), market.get("resolutionSource"),
        market.get("endDate"), market.get("outcomes"), market.get("outcomePrices"), market.get("clobTokenIds"),
        float(market.get("liquidityNum") or market.get("liquidity") or 0), float(market.get("volumeNum") or market.get("volume") or 0),
        int(bool(market.get("active"))), int(bool(market.get("closed"))), market.get("groupItemTitle", ""),
    ))


def deactivate_missing_markets(
    db: sqlite3.Connection,
    active_market_ids: set[str],
) -> int:
    """Deactivate only each absent market's latest metadata snapshot.

    Historical snapshots are immutable evidence.  Rewriting every historical
    row caused a full-table scan and one dashboard event per changed row.
    Consumers already select the latest snapshot, so only that row controls
    current visibility.
    """
    known_market_ids = {
        str(row[0]) for row in db.execute(
            "SELECT DISTINCT market_id FROM market_snapshots"
        ).fetchall()
    }
    changed = 0
    for market_id in sorted(known_market_ids - active_market_ids):
        cursor = db.execute(
            """UPDATE market_snapshots SET active=0
               WHERE market_id=? AND active=1 AND captured_at=(
                 SELECT MAX(captured_at) FROM market_snapshots WHERE market_id=?)""",
            (market_id, market_id),
        )
        changed += max(0, int(cursor.rowcount))
    return changed


async def collect_markets(
    client: httpx.AsyncClient,
    db: sqlite3.Connection,
    captured_at: str,
    progress: CollectorProgress | None = None,
    attribution_results: list[dict[str, Any]] | None = None,
    *,
    staging_path: str | Path | None = None,
    approval_path: str | Path | None = None,
    realtime_database_path: str | Path | None = None,
    research_database_path: str | Path | None = None,
    approval_now: datetime | None = None,
    commit_now: datetime | None = None,
) -> int:
    """Fetch first, then publish one completed subscription universe.

    Network I/O happens before the short SQLite transaction.  If a single
    event detail fails, no partial result is published to the quote stream.
    """
    effective_now = approval_now if approval_now is not None else datetime.now(UTC)
    approval_target = Path(
        approval_path if approval_path is not None else UNIVERSE_PUBLICATION_APPROVAL_PATH
    )
    staging_target = Path(staging_path) if staging_path is not None else None
    if staging_target is not None and approval_target.exists():
        try:
            approval = load_universe_publication_approval(
                approval_target, now=effective_now
            )
            if approval["schema"] == UNIVERSE_FROZEN_PUBLICATION_APPROVAL_SCHEMA:
                decision = authorize_frozen_research_universe_publication(
                    staging_path=staging_target,
                    approval_path=approval_target,
                    realtime_database_path=realtime_database_path,
                    research_database_path=(
                        research_database_path if research_database_path is not None else DB_PATH
                    ),
                    now=effective_now,
                )
                if decision["already_published"]:
                    _market_ids, event_count = _validated_frozen_payload_event_count(
                        decision["market_payloads"], decision["candidate"]
                    )
                    return event_count
                return publish_frozen_research_universe(
                    db,
                    decision,
                    realtime_database_path=realtime_database_path,
                    commit_now=commit_now,
                )
        except MarketScanIncomplete as exc:
            logging.warning(
                "frozen market publication not authorized; prior universe retained: %s",
                exc,
            )
            return 0
    elif staging_target is not None and staging_target.exists():
        try:
            realtime_accepted = load_realtime_accepted_universe_read_only(
                realtime_database_path
            )
            accepted = load_accepted_research_universe_members_read_only(
                research_database_path if research_database_path is not None else DB_PATH,
                expected_accepted_hash=realtime_accepted["token_hash"],
            )
            if getattr(accepted, "accepted_format", None) == "legacy":
                load_frozen_publication_artifact(staging_target, now=effective_now)
                return 0
        except MarketScanIncomplete as exc:
            if exc.reason_code not in {
                "frozen_candidate_not_active",
                "candidate_retired_city",
            }:
                logging.warning("frozen candidate unavailable; prior universe retained: %s", exc)
                return 0
            if exc.reason_code == "candidate_retired_city":
                logging.warning(
                    "retired-city frozen candidate ignored; a complete fresh scan is required"
                )

    scan_id = f"market-scan:{captured_at}"
    reference_date = _reference_date_from_timestamp(captured_at)
    query_results: list[dict[str, Any]] = []

    def emit_status(status: str, reason_code: str,
                    event_payload: dict[str, Any] | None = None) -> None:
        if attribution_results is not None:
            attribution_results.append(research_attribution_status(
                status, reason_code, scan_id=scan_id, scanned_at=captured_at,
                event_payload=event_payload,
            ))

    def emit_query_statuses(pending_status: str, pending_reason: str) -> None:
        if attribution_results is None:
            return
        for query in query_results:
            status = str(query.get("status") or pending_status)
            reason = str(query.get("reason_code") or pending_reason)
            if status == "pending":
                status, reason = pending_status, pending_reason
            city = str(query.get("query_city") or "").strip().title() or None
            target_date = str(query.get("query_target_date") or "").strip() or None
            station = CITY_SETTLEMENT_STATIONS.get(city.lower()) if city else None
            attribution_results.append(research_attribution_status(
                status, reason, scan_id=scan_id, scanned_at=captured_at,
                city=city, station=station, target_date=target_date,
            ))

    try:
        async with asyncio.timeout(MARKET_SCAN_BUDGET_SECONDS):
            events = await active_events(
                client, progress, query_date=reference_date, query_results=query_results
            )
            if not events:
                if query_results:
                    emit_query_statuses("no_active_market", "no_active_event")
                else:
                    emit_status("no_active_market", "no_active_event")
                return 0
            if progress:
                progress.begin("market_detail", len(events), MARKET_SCAN_BUDGET_SECONDS)
            semaphore = asyncio.Semaphore(max(1, MARKET_REQUEST_CONCURRENCY))
            completed = 0

            async def load_detail(event: dict[str, Any]) -> dict[str, Any]:
                nonlocal completed
                try:
                    async with semaphore:
                        detail_response = await client.get(f"{GAMMA}/events/{event['id']}")
                        detail_response.raise_for_status()
                        detail = detail_response.json()
                        if not isinstance(detail, dict):
                            raise MarketScanIncomplete("event_detail_not_object")
                        if str(detail.get("id") or "") != str(event.get("id") or ""):
                            raise MarketScanIncomplete("event_detail_id_mismatch")
                        if "markets" not in detail:
                            raise MarketScanIncomplete("event_markets_missing")
                        if not isinstance(detail["markets"], list):
                            raise MarketScanIncomplete("event_markets_not_list")
                        if any(not isinstance(market, dict) for market in detail["markets"]):
                            raise MarketScanIncomplete("event_market_not_object")
                        if any(
                            "active" not in market
                            or "closed" not in market
                            or type(market["active"]) is not bool
                            or type(market["closed"]) is not bool
                            for market in detail["markets"]
                        ):
                            raise MarketScanIncomplete("market_activity_contract_invalid")
                        detail = dict(detail)
                        detail["_query_city"] = event.get("_query_city")
                        detail["_query_target_date"] = event.get("_query_target_date")
                        return detail
                except (httpx.HTTPError, ValueError) as exc:
                    raise MarketScanIncomplete("event_detail_request_failed", str(exc)) from exc
                finally:
                    completed += 1
                    if progress:
                        progress.advance(completed)

            details = await asyncio.gather(*(load_detail(event) for event in events),
                                           return_exceptions=True)
    except TimeoutError:
        logging.warning("market scan budget exhausted; prior published universe retained")
        if query_results:
            emit_query_statuses("scan_not_executed", "scan_budget_exhausted")
        else:
            emit_status("scan_not_executed", "scan_budget_exhausted")
        return 0
    except MarketScanIncomplete as exc:
        logging.warning("market scan incomplete; prior published universe retained: %s", exc)
        if query_results:
            emit_query_statuses("scan_not_executed", "scan_aborted_after_search_failure")
        else:
            emit_status("search_failed", exc.reason_code)
        return 0
    failures = [detail for detail in details if isinstance(detail, BaseException)]
    if failures:
        logging.warning("market scan incomplete; prior published universe retained: %s", failures[0])
        if query_results:
            failed_reasons: dict[tuple[str, str], str] = {}
            for event, detail in zip(events, details):
                if not isinstance(detail, BaseException):
                    continue
                point = (str(event.get("_query_city") or ""),
                         str(event.get("_query_target_date") or ""))
                reason = (detail.reason_code if isinstance(detail, MarketScanIncomplete)
                          else "event_detail_failed")
                failed_reasons.setdefault(point, reason)
            if attribution_results is not None:
                for query in query_results:
                    point = (str(query.get("query_city") or ""),
                             str(query.get("query_target_date") or ""))
                    if query.get("status") == "no_active_market":
                        status, query_reason = "no_active_market", str(query.get("reason_code"))
                    elif point in failed_reasons:
                        status, query_reason = "attribution_rejected", failed_reasons[point]
                    else:
                        status, query_reason = "scan_not_executed", "scan_aborted_after_detail_failure"
                    city, target_date = point
                    attribution_results.append(research_attribution_status(
                        status, query_reason, scan_id=scan_id, scanned_at=captured_at,
                        city=city or None,
                        station=CITY_SETTLEMENT_STATIONS.get(city.lower()) if city else None,
                        target_date=target_date or None,
                    ))
        else:
            failure = failures[0]
            reason = (failure.reason_code if isinstance(failure, MarketScanIncomplete)
                      else "event_detail_failed")
            emit_status("attribution_rejected", reason)
        return 0

    found = 0
    staged: list[tuple[str, str, float, float, dict[str, Any], dict[str, Any]]] = []
    frozen_payloads: list[dict[str, Any]] = []
    attributions: list[dict[str, Any]] = []
    point_records: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for query in query_results:
        if query.get("status") != "no_active_market":
            continue
        city = str(query.get("query_city") or "").strip().title()
        target_date = str(query.get("query_target_date") or "").strip()
        point_records.setdefault((city, target_date), []).append(
            research_attribution_status(
                "no_active_market", str(query.get("reason_code") or "no_active_event"),
                scan_id=scan_id, scanned_at=captured_at, city=city,
                station=CITY_SETTLEMENT_STATIONS.get(city.lower()),
                target_date=target_date,
            )
        )
    had_rejection = False
    for detail in details:
        query_city = str(detail.get("_query_city") or "").strip().title()
        query_target = str(detail.get("_query_target_date") or "").strip()
        point = (query_city, query_target)
        event_attribution = attribute_research_event(
            detail, scan_id=scan_id, scanned_at=captured_at
        )
        if event_attribution["attribution_status"] != "verified":
            logging.warning("event attribution rejected: %s", event_attribution["reason_code"])
            point_records.setdefault(point, []).append(event_attribution)
            had_rejection = True
            continue
        active_markets = [market for market in detail["markets"]
                          if market["active"] is True and market["closed"] is False]
        detail_verified = False
        for market in active_markets:
            attribution = attribute_research_market(
                detail, market, scan_id=scan_id, scanned_at=captured_at
            )
            point_records.setdefault(point, []).append(attribution)
            if attribution["attribution_status"] != "verified":
                logging.warning("market attribution rejected: %s", attribution["reason_code"])
                had_rejection = True
                continue
            station = attribution["station"]
            city = attribution["city"]
            airport = AIRPORTS.get(station)
            if not airport or airport.get("lat") is None or airport.get("lon") is None:
                logging.warning("market attribution rejected: station coordinate missing for %s", station)
                point_records[point].pop()
                point_records[point].append(research_attribution_status(
                    "attribution_rejected", "event_station_coordinate_missing",
                    scan_id=scan_id, scanned_at=captured_at, event_payload=detail,
                    city=query_city or None, station=station, target_date=query_target or None,
                ))
                had_rejection = True
                continue
            lat, lon = float(airport["lat"]), float(airport["lon"])
            attributions.append(attribution)
            staged.append((station, city, lat, lon, market, attribution))
            frozen_payloads.append({"event": detail, "market": market})
            detail_verified = True
        if detail_verified:
            found += 1

    for query in query_results:
        if query.get("status") != "pending":
            continue
        city = str(query.get("query_city") or "").strip().title()
        target_date = str(query.get("query_target_date") or "").strip()
        point = (city, target_date)
        if not point_records.get(point):
            point_records.setdefault(point, []).append(research_attribution_status(
                "no_active_market", "no_active_market", scan_id=scan_id,
                scanned_at=captured_at, city=city,
                station=CITY_SETTLEMENT_STATIONS.get(city.lower()),
                target_date=target_date,
            ))

    point_attributions = [record for records in point_records.values() for record in records]
    if had_rejection:
        if attribution_results is not None:
            attribution_results.extend(point_attributions)
        return 0

    if not attributions:
        if attribution_results is not None and point_attributions:
            attribution_results.extend(point_attributions)
        elif not point_attributions:
            emit_status("no_active_market", "no_active_market")
        return 0
    try:
        candidate = build_research_universe_candidate(attributions)
    except MarketScanIncomplete as exc:
        logging.warning("market attribution rejected: %s", exc)
        if attribution_results is not None:
            attribution_results.extend(point_attributions)
        emit_status("attribution_rejected", exc.reason_code)
        return 0

    if staging_target is not None and not approval_target.exists():
        try:
            realtime_accepted = load_realtime_accepted_universe_read_only(
                realtime_database_path
            )
            accepted = load_accepted_research_universe_members_read_only(
                research_database_path if research_database_path is not None else DB_PATH,
                expected_accepted_hash=realtime_accepted["token_hash"],
            )
            if getattr(accepted, "accepted_format", None) == "legacy":
                china_now = effective_now.astimezone(SHANGHAI_TZ)
                window_end = china_now.replace(
                    hour=FORWARD_MIXED_WINDOW_END_HOUR,
                    minute=0,
                    second=0,
                    microsecond=0,
                )
                if not (time(0, 0) <= china_now.timetz().replace(tzinfo=None)
                        < time(FORWARD_MIXED_WINDOW_END_HOUR, 0)):
                    raise MarketScanIncomplete("publication_forward_window_invalid")
                expires_at = min(
                    effective_now.astimezone(UTC) + timedelta(minutes=15),
                    window_end.astimezone(UTC),
                )
                artifact = build_frozen_publication_artifact(
                    attributions,
                    point_attributions,
                    frozen_payloads,
                    accepted_members=accepted,
                    expected_current_hash=realtime_accepted["token_hash"],
                    expected_current_count=realtime_accepted["token_count"],
                    staged_at=effective_now,
                    expires_at=expires_at,
                )
                write_frozen_publication_artifact(staging_target, artifact)
                if attribution_results is not None:
                    attribution_results.extend(point_attributions)
                return found
        except MarketScanIncomplete as exc:
            logging.warning("market staging failed; prior universe retained: %s", exc)
            if attribution_results is not None:
                attribution_results.extend(point_attributions)
            return 0

    # The legacy-to-v1 transition is armed only by an independently supplied,
    # short-lived approval.  It runs after discovery/attribution is complete
    # and before this function starts its sole write transaction, so a missing
    # or stale approval cannot deactivate an existing snapshot or publish a
    # reduced manifest.
    try:
        publication = prepare_research_universe_publication(
            attributions,
            point_attributions,
            approval_path=approval_path,
            realtime_database_path=realtime_database_path,
            research_database_path=(
                research_database_path if research_database_path is not None else DB_PATH
            ),
            now=approval_now,
        )
    except MarketScanIncomplete as exc:
        logging.warning("market publication not authorized; prior published universe retained: %s", exc)
        if attribution_results is not None:
            attribution_results.extend(point_attributions)
        return 0

    candidate = publication["candidate"]
    if publication["already_published"]:
        if attribution_results is not None:
            attribution_results.extend(point_attributions)
        return found

    # The only write transaction is intentionally short and contains no HTTP.
    active_market_ids = {str(market["id"]) for _, _, _, _, market, _ in staged}
    if progress:
        progress.begin("market_publish", len(staged), MARKET_PUBLISH_BUDGET_SECONDS)
    publish_deadline = clock.monotonic() + MARKET_PUBLISH_BUDGET_SECONDS
    db.set_progress_handler(lambda: int(clock.monotonic() > publish_deadline), 1000)
    try:
        db.execute("BEGIN IMMEDIATE")
        for station, city, lat, lon, market, _attribution in staged:
            db.execute("INSERT OR IGNORE INTO airport_stations VALUES (?, ?, ?, ?, ?)",
                       (station, city, lat, lon, captured_at))
            save_market(db, captured_at, market, city)
            db.execute("""INSERT INTO market_rules
                (market_id,city,question,resolution_source,description,first_seen_at,last_seen_at)
                VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(market_id) DO UPDATE SET question=excluded.question,
                  resolution_source=excluded.resolution_source,description=excluded.description,last_seen_at=excluded.last_seen_at""",
                (str(market["id"]), city, market.get("question", ""), market.get("resolutionSource"),
                 market.get("description"), captured_at, captured_at))
        # Price history is owned exclusively by realtime_stream.py.  The REST
        # book occasionally reports artificial outer quotes, so it must never
        # be mixed with websocket BBOs here.
        deactivate_missing_markets(db, active_market_ids)

        if not publication.get("suppress_universe_publication", False):
            members = candidate["members"]
            publish_market_universe(db, captured_at, members, "complete_scan")
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.set_progress_handler(None, 0)
    if progress:
        progress.advance(len(staged))
    if attribution_results is not None:
        attribution_results.extend(point_attributions)
    return found


def market_universe_members(attributions: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Return enriched members only after the complete scan passes every hard gate."""
    return build_research_universe_candidate(attributions)["members"]


def publish_market_universe(db: sqlite3.Connection, captured_at: str,
                            members: list[dict[str, str]], reason: str) -> str:
    """Publish an immutable manifest only after a completed collector scan."""
    canonical = json.dumps(members, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    token_hash = hashlib.sha256(canonical.encode()).hexdigest()
    publication_id = f"{captured_at}:{token_hash[:12]}"
    db.execute("""INSERT OR REPLACE INTO market_universe_publications
      (publication_id,published_at,token_hash,token_count,members_json,reason)
      VALUES (?,?,?,?,?,?)""", (publication_id, captured_at, token_hash, len(members), canonical, reason))
    return publication_id


async def collect_forecasts(client: httpx.AsyncClient, db: sqlite3.Connection, captured_at: str,
                            weatherol_cities: set[str] | None = None,
                            progress: CollectorProgress | None = None) -> list[str]:
    stations = db.execute("SELECT station, city, latitude, longitude FROM airport_stations").fetchall()
    fetched: list[str] = []
    if progress:
        progress.begin("forecast", len(stations), FORECAST_PHASE_BUDGET_SECONDS)
    requested = 0
    for station, city, lat, lon in stations:
        # Weatherol exposes public JSON forecasts for the configured airport pages.
        # Store it separately from numerical weather models; temperature_am is
        # the daily high displayed by the source, while temperature_pm is ignored.
        weatherol = weatherol_airport_for_city(city)
        if weatherol and (weatherol_cities is None or city in weatherol_cities):
            source_name = f"weatherol_{city.lower().replace(' ', '_')}"
            requested_at = datetime.now(UTC).isoformat()
            try:
                aid, url = weatherol
                requested += 1
                if progress:
                    progress.advance(requested)
                if city in ADDITIONAL_WEATHEROL_CITIES:
                    if CITY_SETTLEMENT_STATIONS.get(city.lower()) != station:
                        raise AdditionalWeatherolSourceRejected("station_mismatch")
                    if not valid_weatherol_source_url(url, aid):
                        raise AdditionalWeatherolSourceRejected("source_url_invalid")
                response = await client.get(url)
                response.raise_for_status()
                payload = response.json()
                received_at = datetime.now(UTC).isoformat()
                verified_additional = None
                if city in ADDITIONAL_WEATHEROL_CITIES:
                    verified_additional = validate_additional_weatherol_payload(
                        city, payload, captured_at
                    )
                    items = payload["data"]["forecast15d"]
                else:
                    items = payload.get("data", {}).get("forecast15d", [])
                reported_at = weatherol_reported_at(payload, captured_at)
                report_minute = datetime.fromisoformat(reported_at).minute
                if report_minute not in EXPECTED_REPORT_MINUTES.get(city, set()):
                    db.execute("""INSERT INTO forecast_schedule_alerts
                      (source,city,report_minute,first_seen_at,last_seen_at,occurrences)
                      VALUES (?,?,?,?,?,1)
                      ON CONFLICT(source,report_minute) DO UPDATE SET last_seen_at=excluded.last_seen_at,
                        occurrences=forecast_schedule_alerts.occurrences+1""",
                      (f"weatherol_{city.lower().replace(' ', '_')}", city, report_minute, captured_at, captured_at))
                    logging.warning("new QXZX report minute observed: %s %02d", city, report_minute)
                today = datetime.fromisoformat(captured_at).astimezone(SHANGHAI_TZ).date()
                dates: list[str] = []
                highs: list[float | None] = []
                for item in items:
                    try:
                        month, day = (int(part) for part in str(item.get("forecasttime", "")).split("/"))
                        target = date(today.year, month, day)
                        if (target - today).days < -180:
                            target = date(today.year + 1, month, day)
                        # D0-only research: the provider response bundles
                        # many dates, but only today's target is retained.
                        if target != today:
                            continue
                        dates.append(target.isoformat())
                        highs.append(float(item["temperature_am"]) if item.get("temperature_am") is not None else None)
                    except (TypeError, ValueError):
                        continue
                current = payload.get("data", {}).get("current", {}).get("current", {})
                if verified_additional is not None:
                    if dates != [verified_additional.target_date] or highs != [verified_additional.forecast_high_c]:
                        raise AdditionalWeatherolSourceRejected("derived_forecast_mismatch")
                    lat, lon = verified_additional.latitude, verified_additional.longitude
                    db.execute(
                        "UPDATE airport_stations SET latitude=?, longitude=? WHERE station=?",
                        (lat, lon, station),
                    )
                try:
                    # Preserve the provider airport point for QXZX audit only.
                    if verified_additional is None:
                        lat, lon = float(current["lat"]), float(current["lng"])
                        db.execute("UPDATE airport_stations SET latitude=?, longitude=? WHERE station=?", (lat, lon, station))
                except (KeyError, TypeError, ValueError):
                    logging.warning("Weatherol %s did not provide usable airport coordinates", city)
                # Do not retain the provider's bundled multi-day response.
                # Keep only auditable D0 metadata and the derived D0 high.
                save_raw_forecast_payload(db, source=source_name, city=city, station=station,
                                          captured_at=captured_at, source_reported_at=reported_at,
                                          payload_kind="weatherol_d0", payload={
                                              "target_date": today.isoformat(),
                                              "forecast_high_c": highs[0] if highs else None,
                                              "source_reported_at": reported_at,
                                              "airport_name": current.get("airportname"),
                                          })
                normalized = {
                    "daily": {"time": dates, "temperature_2m_max": highs},
                    "metadata": {
                        "provider": "weatherol", "aid": aid, "field": "forecast15d.temperature_am",
                        "airport_name": current.get("airportname"), "latitude": current.get("lat"),
                        "longitude": current.get("lng"), "source_reported_at": reported_at,
                    },
                }
                db.execute("INSERT OR REPLACE INTO forecast_snapshots VALUES (?, ?, ?, ?)",
                           (captured_at, station, source_name, json.dumps(normalized, ensure_ascii=False)))
                for target_date, high in zip(dates, highs):
                    db.execute("""INSERT INTO forecast_update_values
                        (source, city, station, source_reported_at, captured_at, target_date, forecast_high_c)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(source, station, source_reported_at, target_date) DO UPDATE SET
                          forecast_high_c=excluded.forecast_high_c""",
                        (source_name, city, station, reported_at, captured_at, target_date, high))
                    save_forecast_version(db, source=source_name, city=city, station=station,
                                          target_date=target_date, high=high, captured_at=captured_at,
                                          source_display_time=reported_at)
                    register_d0_candidate(db, source=source_name, city=city, station=station,
                                          target_date=target_date, high=high, captured_at=captured_at,
                                          source_reported_at=reported_at,
                                          grid_version=f"weatherol-airport:{station}")
                fetched.append(city)
            except (httpx.HTTPError, ValueError) as exc:
                db.execute("INSERT OR REPLACE INTO forecast_fetch_audits VALUES (?,?,?,?,?,?,?,?)",
                           (requested_at, datetime.now(UTC).isoformat(), source_name, city, station,
                            "fetch_failed", str(exc), None))
                logging.warning("Weatherol %s forecast unavailable: %s", city, exc)
            else:
                db.execute("INSERT OR REPLACE INTO forecast_fetch_audits VALUES (?,?,?,?,?,?,?,?)",
                           (requested_at, received_at, source_name, city, station, "ok", None, reported_at))
        # Release forecast writes before another provider/network request.
        db.commit()
        # Configured cities are intentionally Weatherol airport-only.
    return fetched


def record_forecast_delivery_windows(db: sqlite3.Connection, *, scheduled_at: str,
                                     schedule_kind: str, cities: set[str],
                                     cycle_started_at: str) -> None:
    """Record the evidence for every scheduled QXZX read or retry.

    This is deliberately metadata-only.  A missed fetch becomes an explicit
    ``not_attempted`` row instead of silently disappearing from the audit
    trail; the forecast values remain stored by the normal collector path.
    """
    completed_at = datetime.now(UTC).isoformat()
    for city in sorted(cities):
        source = f"weatherol_{city.lower().replace(' ', '_')}"
        row = db.execute("""SELECT requested_at,received_at,status,detail,model_run_at
          FROM forecast_fetch_audits
          WHERE source=? AND city=? AND requested_at>=?
          ORDER BY requested_at DESC LIMIT 1""", (source, city, cycle_started_at)).fetchone()
        status = str(row[2]) if row else "not_attempted"
        detail = str(row[3]) if row and row[3] else ("no source attempt in scheduled cycle" if not row else None)
        db.execute("""INSERT OR REPLACE INTO forecast_delivery_windows
          (scheduled_at,schedule_kind,city,cycle_started_at,completed_at,source,status,
           requested_at,received_at,source_reported_at,detail)
          VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
          (scheduled_at, schedule_kind, city, cycle_started_at, completed_at, source, status,
           row[0] if row else None, row[1] if row else None, row[4] if row else None, detail))


def taf_target_high(report: dict[str, Any], target_date: str) -> float | None:
    """Extract only the requested China-day TAF TX maximum from raw text.

    TAFs often contain maxima for two successive UTC days.  We must not let a
    next-day TX enter the D0 record merely because both values are carried in
    the same report.  Candidate dates are resolved around the TAF validity
    start and then compared in China time.
    """
    raw = str(report.get("rawTAF") or "")
    valid_from = report.get("validTimeFrom")
    if not raw or valid_from is None:
        return None
    try:
        anchor = datetime.fromtimestamp(float(valid_from), UTC)
    except (TypeError, ValueError, OSError):
        return None
    values: list[float] = []
    for encoded, day_text, hour_text in re.findall(r"\bTX(M?\d{2})/(\d{2})(\d{2})Z", raw):
        temperature = -int(encoded[1:]) if encoded.startswith("M") else int(encoded)
        for month_offset in (-1, 0, 1):
            month = anchor.month + month_offset
            year = anchor.year
            if month < 1:
                month += 12; year -= 1
            elif month > 12:
                month -= 12; year += 1
            try:
                observed_at = datetime(year, month, int(day_text), int(hour_text), tzinfo=UTC)
            except ValueError:
                continue
            # A valid-time neighborhood avoids accepting a same-numbered date
            # from an adjacent month when a TAF crosses month end.
            if abs((observed_at - anchor).total_seconds()) > 4 * 86400:
                continue
            if observed_at.astimezone(SHANGHAI_TZ).date().isoformat() == target_date:
                values.append(float(temperature))
    return max(values) if values else None


async def collect_taf_forecasts(client: httpx.AsyncClient, db: sqlite3.Connection,
                                captured_at: str, cities: set[str],
                                progress: CollectorProgress | None = None) -> list[str]:
    """Collect D0 airport TAF maximum forecasts for configured model grids."""
    selected = [(city, station, point) for city, (station, point) in TAF_GRID_STATIONS.items()
                if city in cities]
    if not selected:
        return []
    requested_at = datetime.now(UTC).isoformat()
    try:
        if progress:
            progress.begin("taf", 1, FORECAST_PHASE_BUDGET_SECONDS)
            progress.advance(1)
        response = await client.get(TAF_FORECAST_URL, params={
            "ids": ",".join(station for _, station, _ in selected), "format": "json",
        }, headers={"User-Agent": "temperature-research-dashboard/1.0"})
        response.raise_for_status()
        reports = response.json()
        if not isinstance(reports, list):
            raise ValueError("TAF response is not a list")
    except (httpx.HTTPError, ValueError) as exc:
        for city, station, _ in selected:
            db.execute("INSERT OR REPLACE INTO forecast_fetch_audits VALUES (?,?,?,?,?,?,?,?)",
                       (requested_at, datetime.now(UTC).isoformat(), "aviationweather_taf", city, station,
                        "fetch_failed", str(exc), None))
        logging.warning("TAF forecast unavailable: %s", exc)
        return []

    target_date = datetime.now(SHANGHAI_TZ).date().isoformat()
    received_at = datetime.now(UTC).isoformat()
    by_station = {str(item.get("icaoId", "")).upper(): item for item in reports if isinstance(item, dict)}
    fetched: list[str] = []
    for city, station, point in selected:
        report = by_station.get(station)
        if not report:
            db.execute("INSERT OR REPLACE INTO forecast_fetch_audits VALUES (?,?,?,?,?,?,?,?)",
                       (requested_at, received_at, "aviationweather_taf", city, station,
                        "missing_station", "no current TAF report", None))
            continue
        high = taf_target_high(report, target_date)
        issue_at = report.get("issueTime") or report.get("bulletinTime")
        status = "ok" if high is not None else "empty_d0_tx"
        db.execute("INSERT OR REPLACE INTO forecast_fetch_audits VALUES (?,?,?,?,?,?,?,?)",
                   (requested_at, received_at, "aviationweather_taf", city, station, status,
                    None if status == "ok" else "TAF has no TX maximum for the China target day", issue_at))
        # Keep only D0 fields.  In particular, never retain the raw multi-day
        # TAF text because it may include D1/D2 maxima, which this project no
        # longer collects.
        normalized = {
            "daily": {"time": [target_date], "temperature_2m_max": [high]},
            "metadata": {
                "provider": "aviationweather.gov", "product": "TAF", "station": station,
                "requested_grid_latitude": point[0], "requested_grid_longitude": point[1],
                "station_latitude": report.get("lat"), "station_longitude": report.get("lon"),
                "issued_at": issue_at, "valid_from": report.get("validTimeFrom"),
                "valid_to": report.get("validTimeTo"), "weather_risk": [
                    item.get("wxString") for item in report.get("fcsts", [])
                    if item.get("wxString")
                ],
            },
        }
        db.execute("INSERT OR REPLACE INTO forecast_snapshots VALUES (?, ?, ?, ?)",
                   (received_at, station, "aviationweather_taf", json.dumps(normalized, ensure_ascii=False)))
        save_forecast_version(db, source="aviationweather_taf", city=city, station=station,
                              target_date=target_date, high=high, captured_at=received_at,
                              source_display_time=issue_at)
        register_d0_candidate(db, source="aviationweather_taf", city=city, station=station,
                              target_date=target_date, high=high, captured_at=received_at,
                              source_reported_at=issue_at,
                              grid_version=f"model-grid:{point[0]:.4f},{point[1]:.4f}:taf")
        fetched.append(f"{city}/TAF" if high is not None else f"{city}/TAF:empty_d0_tx")
    return fetched


def _formal_gamma_payout(market: dict[str, Any]) -> tuple[int, str, list[str]] | None:
    try:
        outcomes = market.get("outcomes", [])
        prices = market.get("outcomePrices", [])
        if isinstance(outcomes, str):
            outcomes = json.loads(outcomes)
        if isinstance(prices, str):
            prices = json.loads(prices)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if not isinstance(outcomes, list) or not isinstance(prices, list) or len(outcomes) != 2 or len(prices) != 2:
        return None
    labels = [str(value).strip().lower() for value in outcomes]
    if sorted(labels) != ["no", "yes"]:
        return None
    normalized: list[str] = []
    try:
        for value in prices:
            decimal = Decimal(str(value))
            if not decimal.is_finite() or decimal not in {Decimal("0"), Decimal("1")}:
                return None
            normalized.append(format(decimal, "f"))
    except (InvalidOperation, TypeError, ValueError):
        return None
    if Decimal(normalized[0]) + Decimal(normalized[1]) != Decimal("1"):
        return None
    yes_index = labels.index("yes")
    return int(normalized[yes_index] == "1"), normalized[yes_index], normalized


async def collect_resolutions(client: httpx.AsyncClient, db: sqlite3.Connection, captured_at: str,
                              progress: CollectorProgress | None = None) -> int:
    rows = db.execute("""SELECT m.market_id,m.city,m.captured_at,m.question,
        m.resolution_source,m.bucket_label
        FROM market_snapshots m
      JOIN (SELECT market_id,MAX(captured_at) captured_at FROM market_snapshots GROUP BY market_id) current
        ON current.market_id=m.market_id AND current.captured_at=m.captured_at
      LEFT JOIN market_resolutions r ON r.market_id=m.market_id
      LEFT JOIN (
        SELECT DISTINCT market_id FROM market_resolution_evidence WHERE state='final'
      ) final ON final.market_id=m.market_id
      WHERE r.market_id IS NULL AND final.market_id IS NULL""").fetchall()
    resolved = 0
    if not rows:
        return resolved
    try:
        captured = datetime.fromisoformat(captured_at.replace("Z", "+00:00"))
        if captured.tzinfo is None:
            captured = captured.replace(tzinfo=UTC)
        china_day = captured.astimezone(SHANGHAI_TZ).date()
    except (TypeError, ValueError):
        # A malformed collector timestamp must never enable the early-result path.
        china_day = None
    if china_day is None:
        logging.warning("resolution scan rejected: captured_at_invalid")
        return 0

    # Validate the immutable local identity before spending network budget.
    # This also prevents a malformed historical backlog from starving recent
    # valid markets.
    candidates: list[tuple[date, tuple[str, str, str, str, str, str]]] = []
    rejected = 0
    deferred = 0
    for raw_row in rows:
        market_id, city, stored_at, stored_question, stored_source, stored_bucket = raw_row
        reference_date = _reference_date_from_timestamp(stored_at)
        stored_identity = _contract_identity(
            str(stored_question or ""), contract_kind="market", reference_date=reference_date
        )
        expected_station = CITY_SETTLEMENT_STATIONS.get(str(city).lower())
        stored_question_match = MARKET_CONTRACT_RE.fullmatch(
            str(stored_question or "").strip()
        )
        stored_question_bucket = (
            stored_question_match.group("bucket") if stored_question_match else None
        )
        try:
            target_day = date.fromisoformat(stored_identity[1]) if stored_identity else None
        except (TypeError, ValueError):
            target_day = None
        if (stored_identity is None or stored_identity[0] != city
                or expected_station is None
                or target_day is None
                or not _valid_temperature_bucket(stored_bucket)
                or not _valid_temperature_bucket(stored_question_bucket)
                or _normalized_bucket(stored_question_bucket)
                    != _normalized_bucket(stored_bucket)):
            rejected += 1
            continue
        if target_day >= china_day:
            deferred += 1
            continue
        candidates.append((target_day, tuple(str(value) for value in raw_row)))

    if rejected:
        logging.warning("resolution candidates rejected count=%d", rejected)

    if not candidates:
        logging.info(
            "resolution scan summary candidates=0 rejected=%d final=0 provisional=0", rejected
        )
        return 0

    # The newest ended target date is always first.  Only the older tail rotates
    # between deterministic five-minute slots, so a large backlog cannot pin the
    # same prefix forever while current settlement keeps its priority.
    candidates.sort(key=lambda item: (-item[0].toordinal(), item[1][0]))
    newest_day = candidates[0][0]
    recent = [row for target_day, row in candidates if target_day == newest_day]
    historical = [row for target_day, row in candidates if target_day != newest_day]
    if historical:
        historical_batch_count = (
            len(historical) + RESOLUTION_BATCH_SIZE - 1
        ) // RESOLUTION_BATCH_SIZE
        rotation_batch = int(captured.timestamp() // 300) % historical_batch_count
        rotation_offset = rotation_batch * RESOLUTION_BATCH_SIZE
        historical = historical[rotation_offset:] + historical[:rotation_offset]
    ordered = recent + historical
    batches = [
        ordered[index:index + RESOLUTION_BATCH_SIZE]
        for index in range(0, len(ordered), RESOLUTION_BATCH_SIZE)
    ]
    if progress:
        progress.begin("resolution", len(batches), RESOLUTION_SCAN_BUDGET_SECONDS)

    semaphore = asyncio.Semaphore(max(1, MARKET_REQUEST_CONCURRENCY))
    completed_batches = 0
    scheduled_batches = len(batches)
    requested_count = 0
    returned_count = 0
    missing_count = 0
    provisional_count = 0
    timeout_batches = 0
    failed_batches = 0
    loop = asyncio.get_running_loop()
    started_at = loop.time()

    async def fetch_batch(
        batch_index: int,
        batch: list[tuple[str, str, str, str, str, str]],
        *,
        closed: bool,
    ) -> tuple[int, list[tuple[str, str, str, str, str, str]], list[Any] | None]:
        nonlocal completed_batches, requested_count
        requested_ids = [row[0] for row in batch]
        requested_count += len(requested_ids)
        params = [("id", market_id) for market_id in requested_ids]
        params.extend((("closed", "true" if closed else "false"),
                       ("limit", str(len(requested_ids)))))
        result: list[Any] | None = None
        try:
            async with semaphore:
                response = await client.get(f"{GAMMA}/markets", params=params)
            if response.status_code == 200:
                payload = response.json()
                result = payload if isinstance(payload, list) else None
        except asyncio.CancelledError:
            raise
        except (httpx.HTTPError, ValueError) as exc:
            logging.warning(
                "resolution batch unavailable index=%d closed=%s: %s",
                batch_index, closed, exc,
            )
        completed_batches += 1
        if progress:
            progress.advance(completed_batches)
        return batch_index, batch, result

    def response_map(
        batch: list[tuple[str, str, str, str, str, str]], payload: list[Any] | None
    ) -> tuple[dict[str, dict[str, Any]] | None, set[str]]:
        nonlocal returned_count, missing_count, failed_batches
        if payload is None:
            failed_batches += 1
            return None, {row[0] for row in batch}
        requested = {row[0] for row in batch}
        mapped: dict[str, dict[str, Any]] = {}
        compromised = False
        for value in payload:
            if not isinstance(value, dict):
                compromised = True
                continue
            market_id = str(value.get("id") or "")
            if market_id not in requested or market_id in mapped:
                compromised = True
                continue
            mapped[market_id] = value
        if compromised:
            failed_batches += 1
            logging.warning("resolution batch rejected: unknown_or_duplicate_id")
            return None, requested
        returned_count += len(mapped)
        missing = requested - set(mapped)
        missing_count += len(missing)
        return mapped, missing

    def record_market(
        row: tuple[str, str, str, str, str, str],
        market: dict[str, Any],
        *,
        expected_final: bool,
    ) -> tuple[int, int, int]:
        market_id, city, stored_at, stored_question, stored_source, stored_bucket = row
        reference_date = _reference_date_from_timestamp(stored_at)
        stored_identity = _contract_identity(
            stored_question, contract_kind="market", reference_date=reference_date
        )
        if stored_identity is None or stored_identity[0] != city:
            return 0, 0, 1
        target_date = stored_identity[1]
        expected_station = CITY_SETTLEMENT_STATIONS.get(city.lower())
        response_identity = _contract_identity(
            str(market.get("question") or ""), contract_kind="market",
            reference_date=date.fromisoformat(target_date),
        )
        stored_question_match = MARKET_CONTRACT_RE.fullmatch(str(stored_question or "").strip())
        response_question_match = MARKET_CONTRACT_RE.fullmatch(
            str(market.get("question") or "").strip()
        )
        stored_question_bucket = (
            stored_question_match.group("bucket") if stored_question_match else None
        )
        response_question_bucket = (
            response_question_match.group("bucket") if response_question_match else None
        )
        response_bucket = str(market.get("groupItemTitle") or "").strip()
        if (str(market.get("id") or "") != str(market_id)
                or expected_station is None
                or response_identity != stored_identity
                or not _valid_temperature_bucket(stored_bucket)
                or not _valid_temperature_bucket(response_bucket)
                or not _valid_temperature_bucket(stored_question_bucket)
                or not _valid_temperature_bucket(response_question_bucket)
                or _normalized_bucket(stored_question_bucket) != _normalized_bucket(stored_bucket)
                or _normalized_bucket(response_question_bucket) != _normalized_bucket(response_bucket)
                or _normalized_bucket(stored_question_bucket) != _normalized_bucket(response_question_bucket)
                or _normalized_bucket(stored_bucket) != _normalized_bucket(response_bucket)):
            logging.warning("resolution attribution rejected for %s", market_id)
            return 0, 0, 1
        active = market.get("active")
        closed = market.get("closed")
        accepting_orders = market.get("acceptingOrders")
        resolution_status = market.get("umaResolutionStatus")
        if (type(active) is not bool or type(closed) is not bool
                or type(accepting_orders) is not bool):
            logging.warning("resolution activity rejected for %s: non_boolean", market_id)
            return 0, 0, 1
        normally_closed = (
            closed is True and accepting_orders is False
            and resolution_status == "resolved"
        )
        early_result_open = (
            active is True and closed is False and accepting_orders is True
        )
        if ((expected_final and not normally_closed)
                or (not expected_final and not early_result_open)):
            logging.warning("resolution activity rejected for %s: inconsistent", market_id)
            return 0, 0, 1
        formal_payout = _formal_gamma_payout(market) if normally_closed else None
        if normally_closed and formal_payout is None:
            logging.warning("resolution payout rejected for %s", market_id)
            return 0, 0, 1
        try:
            outcomes = json.loads(market.get("outcomes", "[]"))
            prices = json.loads(market.get("outcomePrices", "[]"))
            yes_index = [str(value).lower() for value in outcomes].index("yes")
            yes_price = float(prices[yes_index])
        except (ValueError, IndexError, TypeError, json.JSONDecodeError):
            yes_price = None
        try:
            target_day_ended = date.fromisoformat(target_date) < china_day
        except ValueError:
            target_day_ended = False
        terminal_winner = target_day_ended and yes_price is not None and yes_price >= 0.999
        state = "final" if normally_closed else "provisional"
        should_record = normally_closed or (early_result_open and terminal_winner)
        if should_record:
            save_market(db, captured_at, market, city)
            if formal_payout is not None:
                yes_resolved, final_yes_price, final_prices = formal_payout
                evidence_yes_price = final_yes_price
                evidence_prices = json.dumps(final_prices)
            else:
                yes_resolved = int(yes_price >= 0.999) if yes_price is not None else None
                evidence_yes_price = str(prices[yes_index])
                evidence_prices = str(market.get("outcomePrices") or "")
            evidence_written = append_resolution_evidence(
                db,
                observed_at=captured_at,
                market_id=str(market["id"]),
                city=city,
                station=expected_station,
                target_date=target_date,
                question=str(market.get("question") or ""),
                bucket_label=str(market.get("groupItemTitle") or ""),
                yes_resolved=yes_resolved,
                yes_price=evidence_yes_price,
                outcome_prices_json=evidence_prices,
                resolution_source=str(market.get("resolutionSource") or ""),
                market_active=active,
                market_closed=closed,
                state=state,
            )
            if not evidence_written and normally_closed:
                logging.warning("final resolution evidence rejected for %s", market_id)
                db.rollback()
                return 0, 0, 1
            if normally_closed:
                db.execute("""INSERT OR REPLACE INTO market_resolutions
                  (market_id,city,target_date,bucket_label,yes_resolved,resolved_at,outcome_prices_json,resolution_source)
                  VALUES (?,?,?,?,?,?,?,?)""",
                  (str(market["id"]), city, target_date,
                   market.get("groupItemTitle", ""), yes_resolved, captured_at,
                   market.get("outcomePrices"), market.get("resolutionSource")))
            # Do not hold the write lock across the next Gamma request.
            db.commit()
            return (1, 0, 0) if normally_closed else (0, 1, 0)
        return 0, 0, 1

    async def run_batches(
        selected_batches: list[list[tuple[str, str, str, str, str, str]]],
        *,
        closed: bool,
        timeout: float,
    ) -> tuple[list[tuple[int, list[tuple[str, str, str, str, str, str]], list[Any] | None]], int]:
        if not selected_batches or timeout <= 0:
            return [], len(selected_batches)
        tasks = [
            asyncio.create_task(fetch_batch(index, batch, closed=closed))
            for index, batch in enumerate(selected_batches)
        ]
        done, pending = await asyncio.wait(tasks, timeout=timeout)
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        results = [task.result() for task in done if not task.cancelled()]
        results.sort(key=lambda item: item[0])
        return results, len(pending)

    final_results, pending_final = await run_batches(
        batches, closed=True, timeout=RESOLUTION_SCAN_BUDGET_SECONDS
    )
    timeout_batches += pending_final
    recent_missing: set[str] = set()
    recent_ids = {row[0] for row in recent}
    row_by_id = {row[0]: row for row in ordered}
    for _batch_index, batch, payload in final_results:
        mapped, missing = response_map(batch, payload)
        recent_missing.update(missing & recent_ids)
        if mapped is None:
            continue
        for row in batch:
            market = mapped.get(row[0])
            if market is None:
                continue
            added, provisional_added, newly_rejected = record_market(
                row, market, expected_final=True
            )
            resolved += added
            provisional_count += provisional_added
            rejected += newly_rejected

    # Only the newest ended target date gets an open/provisional follow-up.
    # It is lower priority and consumes only the budget left after final scans.
    if pending_final == 0 and recent_missing:
        provisional_rows = [row_by_id[market_id] for market_id in sorted(recent_missing)]
        provisional_batches = [
            provisional_rows[index:index + RESOLUTION_BATCH_SIZE]
            for index in range(0, len(provisional_rows), RESOLUTION_BATCH_SIZE)
        ]
        scheduled_batches += len(provisional_batches)
        remaining_budget = max(
            0.0, RESOLUTION_SCAN_BUDGET_SECONDS - (loop.time() - started_at)
        )
        provisional_results, pending_provisional = await run_batches(
            provisional_batches, closed=False, timeout=remaining_budget
        )
        timeout_batches += pending_provisional
        for _batch_index, batch, payload in provisional_results:
            mapped, _missing = response_map(batch, payload)
            if mapped is None:
                continue
            for row in batch:
                market = mapped.get(row[0])
                if market is None:
                    continue
                added, provisional_added, newly_rejected = record_market(
                    row, market, expected_final=False
                )
                resolved += added
                provisional_count += provisional_added
                rejected += newly_rejected

    summary = (
        "resolution scan summary candidates=%d deferred=%d batches_total=%d batches_completed=%d "
        "requested=%d returned=%d missing=%d rejected=%d final=%d provisional=%d "
        "timeouts=%d pending=%d remaining=%d failed_batches=%d"
    )
    values = (
        len(candidates), deferred, scheduled_batches, completed_batches, requested_count,
        returned_count, missing_count, rejected, resolved, provisional_count, timeout_batches,
        timeout_batches, max(0, len(candidates) - resolved), failed_batches,
    )
    if timeout_batches or failed_batches:
        logging.warning(summary, *values)
    else:
        logging.info(summary, *values)
    return resolved


async def one_cycle(db: sqlite3.Connection, *, refresh_markets: bool,
                    forecast_cities: set[str] | None = None,
                    additional_forecast_cities: set[str] | None = None,
                    taf_cities: set[str] | None = None,
                    cycle_kind: str = "常规",
                    publisher: WorkerProgressPublisher | None = None) -> None:
    captured_at = datetime.now(UTC).isoformat()
    progress = CollectorProgress(db, captured_at, publisher=publisher)
    progress.begin("cycle", 0, FORECAST_PHASE_BUDGET_SECONDS)
    async with httpx.AsyncClient(timeout=25) as client:
        markets, resolved, fetched = 0, 0, []
        # QXZX timestamps are the most timing-sensitive data.  Collect them
        # before slower market discovery, and isolate failures between sources.
        if forecast_cities is not None:
            try:
                fetched.extend(await collect_forecasts(client, db, captured_at, forecast_cities, progress))
            except Exception:
                logging.exception("primary forecast collection failed")
            db.commit()
        selected_taf_cities = taf_cities if taf_cities is not None else forecast_cities
        if selected_taf_cities:
            try:
                fetched.extend(await collect_taf_forecasts(
                    client, db, captured_at, selected_taf_cities, progress
                ))
            except Exception:
                logging.exception("TAF collection failed")
            db.commit()
        if additional_forecast_cities:
            try:
                fetched.extend(await collect_forecasts(
                    client, db, captured_at, additional_forecast_cities, progress
                ))
            except Exception:
                logging.exception("additional forecast collection failed")
            db.commit()
        if refresh_markets:
            try:
                markets = await collect_markets(
                    client,
                    db,
                    captured_at,
                    progress,
                    staging_path=UNIVERSE_PUBLICATION_STAGING_PATH,
                )
                resolved = await collect_resolutions(client, db, captured_at, progress)
            except Exception:
                logging.exception("market/resolution collection failed")
            db.commit()
    # Price response is now represented by the continuous intraday line.
    # Do not add new fixed 15/60/240-minute samples.
    db.commit()
    db.execute("INSERT OR REPLACE INTO collector_runs VALUES (?, ?, ?, ?)", (captured_at, markets, len(fetched), resolved))
    forecast_detail = ",".join(fetched) if fetched else "无"
    market_detail = f"已刷新({markets})" if refresh_markets else "未刷新"
    progress.finish(f"{cycle_kind}; forecasts={forecast_detail}; markets={market_detail}")
    logging.info("%s; forecasts=%s; markets=%s; refreshed %d settled markets", cycle_kind, forecast_detail, market_detail, resolved)


async def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--once", action="store_true"); args = parser.parse_args()
    interval = int(os.getenv("COLLECT_SECONDS", "300"))
    publisher = WorkerProgressPublisher(
        BASE / "data" / "runtime" / "services" / "collector.worker.json",
        "collector",
    )
    publisher.start()
    try:
        db = None
        while db is None:
            startup_deadline = datetime.now(UTC) + timedelta(
                seconds=COLLECTOR_STARTUP_BUDGET_SECONDS
            )
            publisher.publish(
                "starting",
                detail="phase=database_startup",
                deadline_at=startup_deadline.isoformat(),
            )
            try:
                db = connect()
            except sqlite3.OperationalError as exc:
                # Retain the worker process and retry in place.  Exiting here used
                # to make the supervisor restart collector repeatedly while the
                # research database was temporarily unavailable.
                logging.warning("collector database startup locked; retrying in 10s: %s", exc)
                await asyncio.sleep(10)
        last_market_refresh = 0.0
        last_maintenance = clock.monotonic()
        last_d0_boundary: str | None = None
        first_cycle = True
        logging.info("all-city research collector started; market interval=%ss; QXZX precision schedule enabled; it never submits orders", interval)
        while True:
            try:
                now = datetime.now(SHANGHAI_TZ)
                china_day = now.date().isoformat()
                discovery = now.minute in DISCOVERY_MINUTES
                opening_check = now.hour == 12 and now.minute in MARKET_OPEN_CHECK_MINUTES
                refresh_markets = opening_check or first_cycle or (clock.monotonic() - last_market_refresh >= interval)
                plan = build_forecast_cycle_plan(
                    now, first_cycle=first_cycle, refresh_markets=refresh_markets
                )
                precision = set(plan.precision)
                retry = set(plan.retry)
                d0_boundary = china_day != last_d0_boundary
                if plan.run_cycle:
                    labels = (["启动全量"] if first_cycle else []) + (["10分钟巡检"] if discovery else []) + (["精准读取"] if precision else []) + (["补读"] if retry else []) + (["12点开盘检查"] if opening_check else [])
                    cycle_started_at = datetime.now(UTC).isoformat()
                    await one_cycle(
                        db,
                        refresh_markets=refresh_markets,
                        forecast_cities=set(plan.primary_qxzx) if plan.primary_qxzx else None,
                        additional_forecast_cities=(
                            set(plan.additional_qxzx) if plan.additional_qxzx else None
                        ),
                        taf_cities=set(plan.taf) if plan.taf else None,
                        cycle_kind="+".join(labels) or "市场刷新",
                        publisher=publisher,
                    )
                    scheduled_at = now.replace(second=0, microsecond=0).isoformat()
                    if precision:
                        record_forecast_delivery_windows(db, scheduled_at=scheduled_at,
                                                         schedule_kind="precision", cities=precision,
                                                         cycle_started_at=cycle_started_at)
                    if retry:
                        record_forecast_delivery_windows(db, scheduled_at=scheduled_at,
                                                         schedule_kind="retry", cities=retry,
                                                         cycle_started_at=cycle_started_at)
                    db.commit()
                    if refresh_markets:
                        last_market_refresh = clock.monotonic()
                    if d0_boundary:
                        last_d0_boundary = china_day
                    first_cycle = False
                if (
                    not first_cycle
                    and clock.monotonic() - last_maintenance
                    >= RESEARCH_MAINTENANCE_INTERVAL_SECONDS
                ):
                    maintenance = CollectorProgress(
                        db,
                        f"maintenance:{datetime.now(UTC).isoformat()}",
                        publisher=publisher,
                    )
                    maintenance.begin(
                        "research_maintenance",
                        RESEARCH_MAINTENANCE_BATCH_ROWS,
                        RESEARCH_MAINTENANCE_BUDGET_SECONDS,
                    )
                    try:
                        deleted = run_bounded_research_maintenance(db)
                        maintenance.finish(
                            "bounded maintenance; deleted="
                            + str(sum(deleted.values()))
                        )
                    except sqlite3.OperationalError as exc:
                        logging.warning("bounded research maintenance deferred: %s", exc)
                        maintenance.finish("bounded maintenance deferred")
                    except Exception:
                        maintenance.finish("bounded maintenance failed")
                        raise
                    finally:
                        last_maintenance = clock.monotonic()
            except Exception:
                # Release a partially-open write transaction before the next
                # scheduled cycle; otherwise collector itself can prolong a lock.
                try:
                    db.rollback()
                except sqlite3.Error:
                    pass
                logging.exception("collection cycle failed")
            if args.once:
                return
            now = datetime.now(SHANGHAI_TZ)
            await asyncio.sleep(max(1.0, 60 - now.second - now.microsecond / 1_000_000))
    finally:
        publisher.close()


if __name__ == "__main__":
    from runtime_logging import configure_runtime_logging
    from runtime_instance_lock import AlreadyRunningError, DUPLICATE_INSTANCE_EXIT, writer_lock

    instance = writer_lock("collector")
    try:
        instance.acquire()
    except AlreadyRunningError:
        raise SystemExit(DUPLICATE_INSTANCE_EXIT)
    configure_runtime_logging("collector")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    try:
        with instance:
            asyncio.run(main())
    except BaseException:
        logging.exception("collector fatal error")
        raise
