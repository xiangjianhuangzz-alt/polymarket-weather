from __future__ import annotations

import asyncio
import json
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import AsyncMock, patch

import collector
from test_be02_publication_approval import (
    NOW,
    SCANNED_AT,
    _canonical_hash,
    _complete_statuses,
    _forward_mixed_approval,
    _legacy_members,
    _record,
    _removed_hash,
    _seed_realtime,
    _seed_research,
    _source,
    _write_json,
)


def _event_market(*, scan_id: str, token_id: str = "7001", market_id: str = "market-added"):
    event = {
        "id": "event-wuhan-2026-08-11",
        "title": "Highest temperature in Wuhan on August 11",
        "resolutionSource": _source("Wuhan", "ZHHH"),
        "active": True,
        "closed": False,
        "_query_city": "Wuhan",
        "_query_target_date": "2026-08-11",
    }
    market = {
        "id": market_id,
        "question": "Will the highest temperature in Wuhan be 30 C on August 11?",
        "description": "frozen offline market",
        "resolutionSource": _source("Wuhan", "ZHHH"),
        "endDate": "2026-08-11T23:59:00Z",
        "outcomes": json.dumps(["Yes", "No"]),
        "outcomePrices": json.dumps(["0.5", "0.5"]),
        "clobTokenIds": json.dumps([token_id, str(int(token_id) + 1)]),
        "liquidityNum": 10.0,
        "volumeNum": 20.0,
        "groupItemTitle": "30 C",
        "active": True,
        "closed": False,
    }
    record = collector.attribute_research_market(
        event, market, scan_id=scan_id, scanned_at=SCANNED_AT
    )
    assert record["attribution_status"] == "verified"
    return event, market, record


def _approval_v3(current_hash: str, artifact: dict, **changes) -> dict:
    candidate = artifact["candidate"]
    diff = candidate["diff"]
    dto = {
        "schema": "universe_publication_approval.v3",
        "operation_id": "t00-frozen-offline-operation",
        "transition": "legacy_to_v1_forward_mixed",
        "expected_current_hash": current_hash,
        "approved_artifact_hash": artifact["artifact_hash"],
        "approved_source_scan_id": artifact["source_scan_id"],
        "approved_candidate_hash": candidate["token_hash"],
        "approved_token_count": candidate["token_count"],
        "approved_added_count": len(diff["added"]),
        "approved_removed_count": len(diff["removed"]),
        "approved_remapped_count": len(diff["remapped"]),
        "approved_added_token_hash": _removed_hash(list(diff["added"])),
        "approved_removed_token_hash": _removed_hash(list(diff["removed"])),
        "allowed_added_target_dates": ["2026-08-11"],
        "allowed_removed_target_dates": ["2026-08-10"],
        "not_before": "2026-08-11T00:25:00+08:00",
        "expires_at": "2026-08-11T00:35:00+08:00",
    }
    dto.update(changes)
    return dto


class _BeginFailingConnection:
    """Small offline delegate proving the frozen path clears its handler on BEGIN failure."""

    def __init__(self, db: sqlite3.Connection) -> None:
        self.db = db
        self.handlers: list[object] = []

    def set_progress_handler(self, handler, instructions) -> None:
        self.handlers.append(handler)
        self.db.set_progress_handler(handler, instructions)

    def execute(self, sql, *args):
        if sql == "BEGIN IMMEDIATE":
            raise sqlite3.OperationalError("begin failure")
        return self.db.execute(sql, *args)

    def commit(self):
        return self.db.commit()

    def rollback(self):
        return self.db.rollback()


class FrozenPublicationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.stage_path = root / "staging" / "candidate.json"
        self.approval_path = root / "control" / "approval.json"
        self.research_path = root / "research.sqlite3"
        self.realtime_path = root / "realtime.sqlite3"
        self.current_hash, self.db = _seed_research(self.research_path)
        self.addCleanup(self.db.close)
        _seed_realtime(self.realtime_path, self.current_hash)
        self.scan_id = f"market-scan:{SCANNED_AT}"
        shared_event, shared_market, shared = _event_market(
            scan_id=self.scan_id, token_id="1001", market_id="market-current"
        )
        added_event, added_market, added = _event_market(scan_id=self.scan_id)
        self.record = shared
        self.records = [shared, added]
        self.payloads = [
            {"event": shared_event, "market": shared_market},
            {"event": added_event, "market": added_market},
        ]
        accepted = collector.load_accepted_research_universe_members_read_only(
            self.research_path, expected_accepted_hash=self.current_hash
        )
        self.artifact = collector.build_frozen_publication_artifact(
            self.records,
            _complete_statuses(shared),
            self.payloads,
            accepted_members=accepted,
            expected_current_hash=self.current_hash,
            expected_current_count=2,
            staged_at=NOW,
            expires_at=NOW + timedelta(minutes=10),
        )

    def write_pair(self, **approval_changes) -> None:
        collector.write_frozen_publication_artifact(self.stage_path, self.artifact)
        self.approval_path.parent.mkdir(parents=True, exist_ok=True)
        _write_json(
            self.approval_path,
            _approval_v3(self.current_hash, self.artifact, **approval_changes),
        )

    def authorize(self, *, now=NOW):
        return collector.authorize_frozen_research_universe_publication(
            staging_path=self.stage_path,
            approval_path=self.approval_path,
            realtime_database_path=self.realtime_path,
            research_database_path=self.research_path,
            now=now,
        )

    def test_scan_b_cannot_replace_approved_scan_a(self) -> None:
        self.write_pair()
        _event, _market, scan_b_shared = _event_market(
            scan_id="market-scan:2026-08-10T16:31:00+00:00",
            token_id="1001", market_id="market-current",
        )
        _event, _market, scan_b_added = _event_market(
            scan_id="market-scan:2026-08-10T16:31:00+00:00"
        )
        candidate_a = self.artifact["candidate"]
        candidate_b = collector.build_research_universe_candidate(
            [scan_b_shared, scan_b_added]
        )
        self.assertNotEqual(candidate_a["token_hash"], candidate_b["token_hash"])
        decision = self.authorize()
        self.assertEqual(decision["candidate"], candidate_a)
        self.assertEqual(decision["artifact"]["source_scan_id"], self.scan_id)

    def test_artifact_hash_and_full_publish_plan_are_bound(self) -> None:
        self.write_pair()
        decision = self.authorize()
        self.assertEqual(
            decision["approval"]["approved_artifact_hash"],
            decision["artifact"]["artifact_hash"],
        )
        self.assertEqual(
            {item["market"]["id"] for item in decision["market_payloads"]},
            {member["market_id"] for member in decision["candidate"]["members"]},
        )
        tampered = json.loads(self.stage_path.read_text(encoding="utf-8"))
        tampered["market_payloads"][0]["market"]["volumeNum"] = 999
        _write_json(self.stage_path, tampered)
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize()

    def test_strict_staging_and_v3_only_gate_fail_closed(self) -> None:
        self.write_pair()
        malformed = json.loads(self.stage_path.read_text(encoding="utf-8"))
        malformed["unknown"] = "forbidden"
        _write_json(self.stage_path, malformed)
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize()

        collector.write_frozen_publication_artifact(self.stage_path, self.artifact)
        self.approval_path.parent.mkdir(parents=True, exist_ok=True)
        _write_json(
            self.approval_path,
            _forward_mixed_approval(self.current_hash, self.artifact["candidate"]),
        )
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize()

    def test_staging_json_parser_rejects_duplicate_keys_and_nonfinite_values(self) -> None:
        self.stage_path.parent.mkdir(parents=True, exist_ok=True)
        invalid_documents = (
            b'{"schema":"universe_publication_candidate.v1","schema":"duplicate"}',
            b'{"value":NaN}',
            b'\xff',
        )
        for raw in invalid_documents:
            with self.subTest(raw=raw):
                self.stage_path.write_bytes(raw)
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.load_frozen_publication_artifact(
                        self.stage_path, now=NOW
                    )

    def test_current_accepted_drift_rejects_before_publish(self) -> None:
        self.write_pair()
        db = sqlite3.connect(self.realtime_path)
        try:
            db.execute(
                "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                (
                    "2026-08-10T16:20:00+00:00", "universe_changed", "drift",
                    "b" * 64, 2, "[]", "[]",
                ),
            )
            db.commit()
        finally:
            db.close()
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize()

    def test_stage_and_approval_expiry_are_checked_at_consumption(self) -> None:
        self.write_pair()
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize(now=NOW + timedelta(minutes=10))
        self.artifact["expires_at"] = (NOW + timedelta(minutes=5)).isoformat()
        self.artifact = collector.finalize_frozen_publication_artifact(self.artifact)
        self.write_pair(expires_at="2026-08-11T00:34:00+08:00")
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize(now=NOW + timedelta(minutes=5))

    def test_stage_cannot_be_consumed_before_staged_at_or_before_scan(self) -> None:
        self.write_pair()
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize(now=NOW - timedelta(microseconds=1))

        invalid = dict(self.artifact)
        invalid["scanned_at"] = (NOW + timedelta(seconds=1)).isoformat()
        invalid = collector.finalize_frozen_publication_artifact(invalid)
        collector.write_frozen_publication_artifact(self.stage_path, invalid)
        _write_json(
            self.approval_path,
            _approval_v3(self.current_hash, invalid),
        )
        with self.assertRaises(collector.MarketScanIncomplete):
            self.authorize()

    def test_staging_lifetime_cannot_cross_the_0600_window_boundary(self) -> None:
        accepted = collector.load_accepted_research_universe_members_read_only(
            self.research_path, expected_accepted_hash=self.current_hash
        )
        at_0559 = datetime.fromisoformat("2026-08-11T05:59:00+08:00")
        valid = collector.build_frozen_publication_artifact(
            self.records,
            _complete_statuses(self.record),
            self.payloads,
            accepted_members=accepted,
            expected_current_hash=self.current_hash,
            expected_current_count=2,
            staged_at=at_0559,
            expires_at=datetime.fromisoformat("2026-08-11T06:00:00+08:00"),
        )
        self.assertEqual(valid["expires_at"], "2026-08-10T22:00:00+00:00")

        invalid_ranges = (
            (
                datetime.fromisoformat("2026-08-11T06:00:00+08:00"),
                datetime.fromisoformat("2026-08-11T06:01:00+08:00"),
            ),
            (
                at_0559,
                datetime.fromisoformat("2026-08-11T06:00:01+08:00"),
            ),
        )
        for staged_at, expires_at in invalid_ranges:
            with self.subTest(staged_at=staged_at, expires_at=expires_at):
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.build_frozen_publication_artifact(
                        self.records,
                        _complete_statuses(self.record),
                        self.payloads,
                        accepted_members=accepted,
                        expected_current_hash=self.current_hash,
                        expected_current_count=2,
                        staged_at=staged_at,
                        expires_at=expires_at,
                    )

    def test_frozen_publish_uses_scan_time_for_snapshot_and_commit_time_for_publication(self) -> None:
        self.write_pair()
        decision = self.authorize()
        commit_now = datetime.fromisoformat("2026-08-11T00:34:00+08:00")
        collector.publish_frozen_research_universe(
            self.db,
            decision,
            commit_now=commit_now,
            realtime_database_path=self.realtime_path,
        )
        snapshot_time = self.db.execute(
            "SELECT captured_at FROM market_snapshots WHERE market_id='market-added'"
        ).fetchone()[0]
        publication = self.db.execute(
            "SELECT published_at,token_hash FROM market_universe_publications "
            "ORDER BY published_at DESC LIMIT 1"
        ).fetchone()
        self.assertEqual(snapshot_time, SCANNED_AT)
        self.assertEqual(
            publication,
            (commit_now.astimezone(collector.UTC).isoformat(), self.artifact["candidate"]["token_hash"]),
        )

    def test_collect_markets_consumes_approved_stage_without_network(self) -> None:
        self.write_pair()
        client = AsyncMock()
        result = asyncio.run(
            collector.collect_markets(
                client,
                self.db,
                "2026-08-10T16:34:00+00:00",
                staging_path=self.stage_path,
                approval_path=self.approval_path,
                realtime_database_path=self.realtime_path,
                research_database_path=self.research_path,
                approval_now=NOW,
                commit_now=NOW,
            )
        )
        self.assertEqual(result, 1)
        client.get.assert_not_awaited()

    def test_active_unapproved_stage_is_not_overwritten_or_rescanned(self) -> None:
        collector.write_frozen_publication_artifact(self.stage_path, self.artifact)
        before = self.stage_path.read_bytes()
        client = AsyncMock()
        result = asyncio.run(
            collector.collect_markets(
                client,
                self.db,
                "2026-08-10T16:31:00+00:00",
                staging_path=self.stage_path,
                approval_path=self.approval_path,
                realtime_database_path=self.realtime_path,
                research_database_path=self.research_path,
                approval_now=NOW,
            )
        )
        self.assertEqual(result, 0)
        self.assertEqual(self.stage_path.read_bytes(), before)
        client.get.assert_not_awaited()

    def test_expired_stage_releases_discovery_for_a_new_scan(self) -> None:
        expired = dict(self.artifact)
        expired["staged_at"] = (NOW - timedelta(minutes=11)).isoformat()
        expired["expires_at"] = (NOW - timedelta(minutes=1)).isoformat()
        expired = collector.finalize_frozen_publication_artifact(expired)
        collector.write_frozen_publication_artifact(self.stage_path, expired)
        with patch.object(collector, "active_events", return_value=[]) as discovery:
            result = asyncio.run(
                collector.collect_markets(
                    AsyncMock(),
                    self.db,
                    "2026-08-10T16:31:00+00:00",
                    staging_path=self.stage_path,
                    approval_path=self.approval_path,
                    realtime_database_path=self.realtime_path,
                    research_database_path=self.research_path,
                    approval_now=NOW,
                )
            )
        self.assertEqual(result, 0)
        discovery.assert_called_once()

    def test_transaction_failure_preserves_all_existing_rows(self) -> None:
        self.write_pair()
        decision = self.authorize()
        before = {
            table: self.db.execute(f"SELECT * FROM {table}").fetchall()
            for table in (
                "market_snapshots", "market_rules", "airport_stations",
                "market_universe_publications",
            )
        }
        with patch.object(
            collector, "publish_market_universe", side_effect=sqlite3.OperationalError("boom")
        ):
            with self.assertRaises(sqlite3.OperationalError):
                collector.publish_frozen_research_universe(
                    self.db,
                    decision,
                    realtime_database_path=self.realtime_path,
                    commit_now=datetime.fromisoformat("2026-08-11T00:34:00+08:00"),
                )
        after = {
            table: self.db.execute(f"SELECT * FROM {table}").fetchall()
            for table in before
        }
        self.assertEqual(after, before)

    def test_current_drift_after_authorization_rejects_before_transaction(self) -> None:
        self.write_pair()
        decision = self.authorize()
        db = sqlite3.connect(self.realtime_path)
        try:
            db.execute(
                "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                (
                    "2026-08-10T16:29:59+00:00",
                    "universe_changed",
                    "post-authorization drift",
                    "c" * 64,
                    2,
                    "[]",
                    "[]",
                ),
            )
            db.commit()
        finally:
            db.close()
        before = self.db.execute(
            "SELECT COUNT(*) FROM market_universe_publications"
        ).fetchone()[0]
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.publish_frozen_research_universe(
                self.db,
                decision,
                realtime_database_path=self.realtime_path,
                commit_now=datetime.fromisoformat("2026-08-11T00:34:00+08:00"),
            )
        after = self.db.execute(
            "SELECT COUNT(*) FROM market_universe_publications"
        ).fetchone()[0]
        self.assertEqual(after, before)

    def test_publish_rechecks_artifact_and_approval_lifetime_before_begin(self) -> None:
        self.write_pair()
        decision = self.authorize()
        before = self.db.execute("SELECT COUNT(*) FROM market_universe_publications").fetchone()[0]
        statements: list[str] = []
        self.db.set_trace_callback(statements.append)
        try:
            with self.assertRaises(collector.MarketScanIncomplete):
                collector.publish_frozen_research_universe(
                    self.db, decision,
                    published_at="2026-08-10T16:41:00+00:00",
                    realtime_database_path=self.realtime_path,
                    commit_now=datetime.fromisoformat("2026-08-11T00:41:00+08:00"),
                )
        finally:
            self.db.set_trace_callback(None)
        self.assertNotIn("BEGIN IMMEDIATE", statements)
        self.assertEqual(
            self.db.execute("SELECT COUNT(*) FROM market_universe_publications").fetchone()[0],
            before,
        )

    def test_publish_commit_window_boundaries_and_timestamp(self) -> None:
        self.write_pair()
        decision = self.authorize()
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.publish_frozen_research_universe(
                self.db, decision, published_at="ignored",
                realtime_database_path=self.realtime_path,
                commit_now=datetime.fromisoformat("2026-08-11T06:00:00+08:00"),
            )
        decision["artifact"] = dict(
            decision["artifact"],
            staged_at="2026-08-11T05:50:00+08:00",
            expires_at="2026-08-11T06:00:00+08:00",
        )
        decision["approval"] = dict(
            decision["approval"],
            not_before="2026-08-11T05:50:00+08:00",
            expires_at="2026-08-11T06:00:00+08:00",
        )
        commit_now = datetime.fromisoformat("2026-08-11T05:59:59+08:00")
        collector.publish_frozen_research_universe(
            self.db, decision, published_at="ignored",
            realtime_database_path=self.realtime_path, commit_now=commit_now,
        )
        row = self.db.execute(
            "SELECT published_at FROM market_universe_publications ORDER BY published_at DESC LIMIT 1"
        ).fetchone()
        self.assertEqual(row[0], commit_now.astimezone(collector.UTC).isoformat())

    def test_frozen_publish_returns_unique_event_count_not_market_count(self) -> None:
        self.write_pair()
        decision = self.authorize()
        payload = decision["market_payloads"]
        payload[1] = {"event": payload[0]["event"], "market": payload[1]["market"]}
        decision["market_payloads"] = payload
        self.assertEqual(
            collector.publish_frozen_research_universe(
                self.db, decision, published_at="ignored",
                realtime_database_path=self.realtime_path,
                commit_now=datetime.fromisoformat("2026-08-11T00:31:00+08:00"),
            ),
            1,
        )

    def test_frozen_publish_clears_deadline_handler_when_begin_fails(self) -> None:
        self.write_pair()
        decision = self.authorize()
        spy = _BeginFailingConnection(self.db)
        with self.assertRaises(sqlite3.OperationalError):
            collector.publish_frozen_research_universe(
                spy, decision, realtime_database_path=self.realtime_path,
                commit_now=datetime.fromisoformat("2026-08-11T00:31:00+08:00"),
            )
        self.assertIsNotNone(spy.handlers[0])
        self.assertIsNone(spy.handlers[-1])
        self.assertEqual(self.db.execute("SELECT 1").fetchone()[0], 1)

    def test_production_commit_clock_is_read_after_second_accepted_read(self) -> None:
        self.write_pair()
        decision = self.authorize()
        original_read = collector.load_realtime_accepted_universe_read_only
        observed: list[str] = []

        def accepted_after_delay(path):
            observed.append("accepted")
            return original_read(path)

        with patch.object(collector, "load_realtime_accepted_universe_read_only", accepted_after_delay), patch.object(
            collector,
            "_frozen_publish_now_utc",
            return_value=datetime.fromisoformat("2026-08-11T00:41:00+08:00"),
        ) as final_clock, self.assertRaises(collector.MarketScanIncomplete):
            collector.publish_frozen_research_universe(
                self.db, decision, realtime_database_path=self.realtime_path,
            )
        self.assertEqual(observed, ["accepted"])
        final_clock.assert_called_once_with()
        self.assertEqual(
            self.db.execute("SELECT COUNT(*) FROM market_universe_publications").fetchone()[0],
            1,
        )

    def test_collect_markets_idempotent_stage_returns_unique_event_count(self) -> None:
        self.write_pair()
        first_client, second_client = AsyncMock(), AsyncMock()
        kwargs = {
            "staging_path": self.stage_path,
            "approval_path": self.approval_path,
            "realtime_database_path": self.realtime_path,
            "research_database_path": self.research_path,
            "approval_now": NOW,
            "commit_now": NOW,
        }
        first = asyncio.run(collector.collect_markets(first_client, self.db, "ignored", **kwargs))
        publication_count = self.db.execute("SELECT COUNT(*) FROM market_universe_publications").fetchone()[0]
        second = asyncio.run(collector.collect_markets(second_client, self.db, "ignored", **kwargs))
        self.assertEqual(first, 1)
        self.assertEqual(second, 1)
        self.assertEqual(
            self.db.execute("SELECT COUNT(*) FROM market_universe_publications").fetchone()[0],
            publication_count,
        )
        first_client.get.assert_not_awaited()
        second_client.get.assert_not_awaited()

    def test_retired_city_staging_is_replaced_only_after_a_fresh_scan(self) -> None:
        self.stage_path.parent.mkdir(parents=True, exist_ok=True)
        self.stage_path.write_text("{}", encoding="utf-8")
        client = AsyncMock()
        with patch.object(
            collector,
            "load_realtime_accepted_universe_read_only",
            return_value={"token_hash": self.current_hash, "token_count": 1},
        ), patch.object(
            collector,
            "load_accepted_research_universe_members_read_only",
            return_value=type("Accepted", (), {"accepted_format": "legacy"})(),
        ), patch.object(
            collector,
            "load_frozen_publication_artifact",
            side_effect=collector.MarketScanIncomplete("candidate_retired_city"),
        ), patch.object(
            collector,
            "active_events",
            new=AsyncMock(return_value=[]),
        ) as scan:
            found = asyncio.run(
                collector.collect_markets(
                    client,
                    self.db,
                    SCANNED_AT,
                    staging_path=self.stage_path,
                    approval_path=self.approval_path,
                    realtime_database_path=self.realtime_path,
                    research_database_path=self.research_path,
                    approval_now=NOW,
                )
            )
        self.assertEqual(found, 0)
        scan.assert_awaited_once()
        self.assertEqual(self.stage_path.read_text(encoding="utf-8"), "{}")

    def test_malformed_non_retirement_staging_remains_fail_closed(self) -> None:
        self.stage_path.parent.mkdir(parents=True, exist_ok=True)
        self.stage_path.write_text("{}", encoding="utf-8")
        with patch.object(
            collector,
            "load_realtime_accepted_universe_read_only",
            return_value={"token_hash": self.current_hash, "token_count": 1},
        ), patch.object(
            collector,
            "load_accepted_research_universe_members_read_only",
            return_value=type("Accepted", (), {"accepted_format": "legacy"})(),
        ), patch.object(
            collector,
            "load_frozen_publication_artifact",
            side_effect=collector.MarketScanIncomplete("candidate_city_invalid"),
        ), patch.object(
            collector,
            "active_events",
            new=AsyncMock(return_value=[]),
        ) as scan:
            found = asyncio.run(
                collector.collect_markets(
                    AsyncMock(), self.db, SCANNED_AT,
                    staging_path=self.stage_path,
                    approval_path=self.approval_path,
                    realtime_database_path=self.realtime_path,
                    research_database_path=self.research_path,
                    approval_now=NOW,
                )
            )
        self.assertEqual(found, 0)
        scan.assert_not_awaited()
        self.assertEqual(self.stage_path.read_text(encoding="utf-8"), "{}")


if __name__ == "__main__":
    unittest.main()
