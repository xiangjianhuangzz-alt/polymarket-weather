from __future__ import annotations

import asyncio
import json
import sqlite3
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import httpx

import collector


UTC = timezone.utc
SOURCE = "aviationweather_taf"
TARGET = "2026-08-15"
CAPTURED = "2026-08-15T04:20:00+00:00"
ACTIVE_CITY_STATIONS = (
    ("Beijing", "ZBAA"), ("Shanghai", "ZSPD"), ("Chengdu", "ZUUU"),
    ("Guangzhou", "ZGGG"), ("Shenzhen", "ZGSZ"), ("Wuhan", "ZHHH"),
    ("Chongqing", "ZUCK"),
)
REQUEST_ORDER = ("ZBAA", "ZSPD", "ZGSZ", "ZUUU", "ZGGG", "ZHHH", "ZUCK")
FIVE_CITIES = ("Beijing", "Shanghai", "Chengdu", "Guangzhou", "Shenzhen")


def frozen_datetime(value: str):
    instant = datetime.fromisoformat(value.replace("Z", "+00:00"))

    class FrozenDateTime(datetime):
        @classmethod
        def now(cls, tz=None):
            return instant.astimezone(tz) if tz else instant.replace(tzinfo=None)

    return FrozenDateTime


class Response:
    def __init__(self, payload, status=200, request=None, *, empty_body=False):
        self.payload, self.status, self.request, self.empty_body = payload, status, request, empty_body

    def raise_for_status(self):
        if self.status >= 400:
            raise httpx.HTTPStatusError(
                f"HTTP {self.status}", request=self.request,
                response=httpx.Response(self.status, request=self.request),
            )

    def json(self):
        if self.empty_body:
            raise ValueError("Expecting value: line 1 column 1 (char 0)")
        return self.payload


class ParameterCausalityClient:
    """Only the parameter-contract red tests take this HTTP-400 branch."""
    def __init__(self, reports):
        self.reports, self.calls = reports, []

    async def get(self, url, *, params, headers):
        self.calls.append((url, dict(params), dict(headers)))
        request = httpx.Request("GET", url, params=params, headers=headers)
        return Response(self.reports if "hours" not in params else None,
                        200 if "hours" not in params else 400, request)


class SuccessClient:
    """Returns a parser-valid fixture independently of the request parameters."""
    def __init__(self, reports):
        self.reports, self.calls = reports, []

    async def get(self, url, *, params, headers):
        self.calls.append((url, dict(params), dict(headers)))
        return Response(self.reports, request=httpx.Request("GET", url, params=params, headers=headers))


class FailureClient:
    """Exercises existing fail-closed paths without preserving the hours defect."""
    def __init__(self, kind):
        self.kind = kind

    async def get(self, url, *, params, headers):
        request = httpx.Request("GET", url, params=params, headers=headers)
        if self.kind == "timeout":
            raise httpx.TimeoutException("timeout", request=request)
        if self.kind == "connect":
            raise httpx.ConnectError("connect", request=request)
        if self.kind == "non_list":
            return Response({"reports": []}, request=request)
        if self.kind == 204:
            # A genuine 204 has no JSON body: HTTP succeeds, decoding fails.
            return Response(None, 204, request, empty_body=True)
        return Response(None, self.kind, request)


def report(station, raw, *, issue="2026-08-15T03:00:00+00:00", bulletin=None):
    item = {
        "icaoId": station,
        "rawTAF": raw,
        "validTimeFrom": int(datetime(2026, 8, 15, tzinfo=UTC).timestamp()),
        "validTimeTo": int(datetime(2026, 8, 16, tzinfo=UTC).timestamp()),
    }
    if issue is not None:
        item["issueTime"] = issue
    if bulletin is not None:
        item["bulletinTime"] = bulletin
    return item


class TafApiV4Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        path = Path(self.tmp.name) / "test.sqlite3"
        with patch.object(collector, "DB_PATH", path):
            self.db = collector.connect()

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def collect(self, client, cities, *, captured=CAPTURED):
        with patch.object(collector, "datetime", frozen_datetime(captured)):
            return asyncio.run(collector.collect_taf_forecasts(client, self.db, captured, set(cities)))

    def fact_counts(self, *, city="Chengdu", station="ZUUU", target=TARGET):
        return {
            "snapshots": self.db.execute(
                "SELECT COUNT(*) FROM forecast_snapshots WHERE city=? AND model=?", (station, SOURCE)
            ).fetchone()[0],
            "events": self.db.execute(
                "SELECT COUNT(*) FROM forecast_events WHERE source=? AND city=? AND station=? AND target_date=?",
                (SOURCE, city, station, target),
            ).fetchone()[0],
            "versions": self.db.execute(
                "SELECT COUNT(*) FROM forecast_versions WHERE source=? AND city=? AND station=? AND target_date=?",
                (SOURCE, city, station, target),
            ).fetchone()[0],
            "d0": self.db.execute(
                "SELECT COUNT(*) FROM forecast_d0_registry WHERE source=? AND city=? AND station=? AND target_date=?",
                (SOURCE, city, station, target),
            ).fetchone()[0],
        }

    def assert_parameter_contract(self, cities, expected_ids):
        client = ParameterCausalityClient([])
        self.collect(client, cities)
        url, params, headers = client.calls[0]
        self.assertEqual(url, collector.TAF_FORECAST_URL)
        self.assertEqual(params, {"ids": expected_ids, "format": "json"})
        self.assertEqual(headers, {"User-Agent": "temperature-research-dashboard/1.0"})

    def test_seven_station_parameter_contract(self):
        self.assert_parameter_contract(tuple(city for city, _ in ACTIVE_CITY_STATIONS), ",".join(REQUEST_ORDER))

    def test_original_five_station_parameter_contract(self):
        self.assert_parameter_contract(FIVE_CITIES, "ZBAA,ZSPD,ZGSZ,ZUUU,ZGGG")

    def test_single_zuuu_parameter_contract(self):
        self.assert_parameter_contract(("Chengdu",), "ZUUU")

    def test_fixed_seven_city_identity_and_request_order_are_not_self_derived(self):
        self.assertEqual(tuple(collector.TAF_GRID_STATIONS),
                         ("Beijing", "Shanghai", "Shenzhen", "Chengdu", "Guangzhou", "Wuhan", "Chongqing"))
        for city, station in ACTIVE_CITY_STATIONS:
            self.assertEqual(collector.TAF_GRID_STATIONS[city][0], station)
        self.assertNotIn("Jinan", collector.TAF_GRID_STATIONS)
        self.assertNotIn("Qingdao", collector.TAF_GRID_STATIONS)
        self.assertNotIn("Zhengzhou", collector.TAF_GRID_STATIONS)
        self.assertEqual(tuple(station for station, _ in collector.TAF_GRID_STATIONS.values()), REQUEST_ORDER)

    def test_success_is_mapped_by_icao_with_complete_four_layer_facts(self):
        issue = "2026-08-15T03:00:00+00:00"
        client = SuccessClient([
            report("ZGGG", "TAF ZGGG 150000Z TX35/1506Z TX40/1606Z", issue=issue),
            report("ZUUU", "TAF ZUUU 150000Z TX31/1506Z", issue=issue),
        ])
        self.assertEqual(self.collect(client, ("Chengdu", "Guangzhou")), ["Chengdu/TAF", "Guangzhou/TAF"])

        snapshots = {station: json.loads(payload) for station, payload in self.db.execute(
            "SELECT city,forecast_json FROM forecast_snapshots WHERE model=? ORDER BY city", (SOURCE,)
        )}
        for station, high in {"ZUUU": 31.0, "ZGGG": 35.0}.items():
            snap = snapshots[station]
            self.assertEqual(snap["daily"], {"time": [TARGET], "temperature_2m_max": [high]})
            self.assertEqual(snap["metadata"]["station"], station)
            self.assertEqual(snap["metadata"]["issued_at"], issue)
            self.assertEqual(snap["metadata"]["valid_from"], int(datetime(2026, 8, 15, tzinfo=UTC).timestamp()))
            self.assertEqual(snap["metadata"]["valid_to"], int(datetime(2026, 8, 16, tzinfo=UTC).timestamp()))

        expected = {"ZUUU": ("Chengdu", 31.0), "ZGGG": ("Guangzhou", 35.0)}
        rows = self.db.execute(
            "SELECT city,station,target_date,forecast_high_c,event_kind,source_display_time FROM forecast_events WHERE source=? ORDER BY station", (SOURCE,)
        ).fetchall()
        self.assertEqual(rows, [(city, station, TARGET, high, "initial", issue) for station, (city, high) in sorted(expected.items())])
        rows = self.db.execute(
            "SELECT city,station,target_date,forecast_high_c,first_seen_at,last_seen_at,source_display_time FROM forecast_versions WHERE source=? ORDER BY station", (SOURCE,)
        ).fetchall()
        self.assertEqual(rows, [(city, station, TARGET, high, CAPTURED, CAPTURED, issue) for station, (city, high) in sorted(expected.items())])
        rows = self.db.execute(
            "SELECT city,station,target_date,forecast_high_c,forecast_bucket,source_reported_at,first_captured_at,latest_checked_at,status FROM forecast_d0_registry WHERE source=? ORDER BY station", (SOURCE,)
        ).fetchall()
        self.assertEqual(rows, [(city, station, TARGET, high, int(high), issue, CAPTURED, CAPTURED, "valid_d0") for station, (city, high) in sorted(expected.items())])
        self.assertNotIn(40.0, [row[3] for row in rows])

    def test_bulletin_time_empty_d0_tx_preserves_current_four_layer_semantics(self):
        bulletin = "2026-08-15T03:00:00+00:00"
        item = report("ZUUU", "TAF ZUUU 150000Z TX35/1606Z", issue=None, bulletin=bulletin)
        self.assertEqual(self.collect(SuccessClient([item]), ("Chengdu",)), ["Chengdu/TAF:empty_d0_tx"])
        self.assertEqual(self.db.execute("SELECT status,model_run_at FROM forecast_fetch_audits").fetchone(), ("empty_d0_tx", bulletin))
        snap = json.loads(self.db.execute("SELECT forecast_json FROM forecast_snapshots").fetchone()[0])
        self.assertEqual(snap["daily"]["temperature_2m_max"], [None])
        self.assertEqual(snap["metadata"]["issued_at"], bulletin)
        self.assertEqual(self.db.execute("SELECT forecast_high_c,source_display_time FROM forecast_versions").fetchone(), (None, bulletin))
        self.assertEqual(self.db.execute("SELECT forecast_high_c,source_display_time FROM forecast_events").fetchone(), (None, bulletin))
        self.assertEqual(self.db.execute("SELECT forecast_high_c,forecast_bucket,status,source_reported_at FROM forecast_d0_registry").fetchone(), (None, None, "valid_d0", bulletin))

    def test_transport_and_decode_failures_are_fetch_failed_and_zero_four_layer_facts(self):
        for kind in (204, 400, 429, 500, "timeout", "connect", "non_list"):
            with self.subTest(kind=kind):
                self.assertEqual(self.collect(FailureClient(kind), ("Chengdu",)), [])
                self.assertEqual(self.fact_counts(), {"snapshots": 0, "events": 0, "versions": 0, "d0": 0})
                self.assertEqual(self.db.execute("SELECT status FROM forecast_fetch_audits").fetchone()[0], "fetch_failed")
                self.db.execute("DELETE FROM forecast_fetch_audits")
                self.db.commit()

    def test_http_200_missing_station_is_distinct_and_zero_four_layer_facts(self):
        self.assertEqual(self.collect(SuccessClient([]), ("Chengdu",)), [])
        self.assertEqual(self.fact_counts(), {"snapshots": 0, "events": 0, "versions": 0, "d0": 0})
        self.assertEqual(self.db.execute("SELECT status,detail FROM forecast_fetch_audits").fetchone(),
                         ("missing_station", "no current TAF report"))

    def test_failure_does_not_backfill_or_change_any_historical_fact_layer(self):
        historical_capture = "2026-08-14T04:20:00+00:00"
        historical = report("ZUUU", "TAF ZUUU 140000Z TX30/1406Z", issue="2026-08-14T03:00:00+00:00")
        self.assertEqual(self.collect(SuccessClient([historical]), ("Chengdu",), captured=historical_capture), ["Chengdu/TAF"])
        tables = ("forecast_snapshots", "forecast_events", "forecast_versions", "forecast_d0_registry")
        before = {table: self.db.execute(f"SELECT * FROM {table} ORDER BY 1,2,3,4").fetchall() for table in tables}
        self.assertEqual(self.collect(FailureClient(400), ("Chengdu",)), [])
        after = {table: self.db.execute(f"SELECT * FROM {table} ORDER BY 1,2,3,4").fetchall() for table in tables}
        self.assertEqual(after, before)
        self.assertEqual(self.db.execute(
            "SELECT COUNT(*) FROM forecast_snapshots WHERE captured_at=? AND city=? AND model=?",
            (CAPTURED, "ZUUU", SOURCE),
        ).fetchone()[0], 0)
        self.assertEqual(self.fact_counts(), {"snapshots": 1, "events": 0, "versions": 0, "d0": 0})


if __name__ == "__main__":
    unittest.main()
