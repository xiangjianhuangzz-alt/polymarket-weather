from __future__ import annotations

import logging
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sqlite3

import dashboard_modern
from dashboard_modern import Api
from runtime_environment import child_environment
from runtime_logging import SensitiveDataFilter, redact_sensitive_text
from service_guardian import ServiceGuardian, ServiceSpec


SECRET = "super-secret-private-key-value"


class RuntimeSecurityTests(unittest.TestCase):
    def test_public_api_errors_never_expose_exception_text(self) -> None:
        api = Api()
        failure = sqlite3.OperationalError(f"cannot open C:/secret?PRIVATE_KEY={SECRET}")
        with patch("dashboard_modern.sqlite3.connect", side_effect=failure):
            d0 = api.d0_evidence_panel_v2("2026-08-16")
            paper = api.paper_snapshot()
            health = api.health_snapshot()
        serialized = repr((d0, paper, health))
        self.assertNotIn(SECRET, serialized)
        self.assertEqual(d0["error"]["code"], "data_temporarily_unavailable")
        self.assertEqual(paper, {"ok": False, "error": "paper_data_unavailable"})
        self.assertEqual(health["error"], "dashboard_health_unavailable")

    def test_child_environment_is_allowlisted_for_parent_and_dotenv(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            dotenv = Path(temporary) / ".env"
            dotenv.write_text(
                f"PRIVATE_KEY={SECRET}\nFUNDER_ADDRESS=wallet\nCOLLECT_SECONDS=45\n",
                encoding="utf-8",
            )
            environment = child_environment(
                dotenv_path=dotenv,
                pythonpath=Path(temporary),
                environ={
                    "PATH": "safe-path", "SYSTEMROOT": r"C:\Windows",
                    "PRIVATE_KEY": SECRET,
                    "FUNDER_ADDRESS": "wallet", "COLLECT_SECONDS": "30",
                    "UNRELATED_SECRET": SECRET,
                },
            )
        self.assertEqual(environment["PATH"], "safe-path")
        self.assertEqual(environment["SYSTEMROOT"], r"C:\Windows")
        self.assertEqual(environment["COLLECT_SECONDS"], "30")
        self.assertIn("PYTHONPATH", environment)
        for forbidden in ("PRIVATE_KEY", "FUNDER_ADDRESS", "UNRELATED_SECRET"):
            self.assertNotIn(forbidden, environment)

    def test_guardian_worker_environment_does_not_inherit_wallet_material(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, patch.dict(
            os.environ,
            {"PRIVATE_KEY": SECRET, "FUNDER_ADDRESS": "wallet", "COLLECT_SECONDS": "30"},
            clear=True,
        ):
            root = Path(temporary)
            guardian = ServiceGuardian(
                ServiceSpec("unit", root / "none.py", root / "db.sqlite3", "unit", 30, 1, 2),
                status_dir=root,
            )
            environment = guardian._worker_environment()
        self.assertNotIn("PRIVATE_KEY", environment)
        self.assertNotIn("FUNDER_ADDRESS", environment)
        self.assertEqual(environment["COLLECT_SECONDS"], "30")

    def test_log_redaction_covers_assignments_and_bearer_tokens(self) -> None:
        raw = f"PRIVATE_KEY={SECRET}; Authorization: Bearer abc.def.ghi password=hunter2"
        redacted = redact_sensitive_text(raw)
        self.assertNotIn(SECRET, redacted)
        self.assertNotIn("abc.def.ghi", redacted)
        self.assertNotIn("hunter2", redacted)
        record = logging.LogRecord("test", logging.ERROR, __file__, 1, "%s", (raw,), None)
        self.assertTrue(SensitiveDataFilter().filter(record))
        self.assertNotIn(SECRET, record.getMessage())
        self.assertEqual(record.args, ())

if __name__ == "__main__":
    unittest.main()
