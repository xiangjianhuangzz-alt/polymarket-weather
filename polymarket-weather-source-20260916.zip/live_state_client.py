"""Read-only local client for the stream's live-state hub.

The dashboard may use this as a low-latency projection, but SQLite remains the
auditable source and the fallback path.  This module has no trading code and
cannot connect to an exchange or submit an order.
"""
from __future__ import annotations

import asyncio
import json
import threading
import time
from collections import deque
from datetime import UTC, datetime
from typing import Any

import websockets


def _timestamp_key(value: Any) -> datetime | None:
    """Return a comparable UTC timestamp, or ``None`` for malformed input."""
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _incoming_is_older(current: dict[str, Any] | None,
                       incoming: dict[str, Any]) -> bool:
    if not current:
        return False
    current_stream = current.get("stream_id")
    incoming_stream = incoming.get("stream_id")
    current_sequence = current.get("sequence")
    incoming_sequence = incoming.get("sequence")
    if current_stream and current_stream == incoming_stream:
        try:
            return int(incoming_sequence) < int(current_sequence)
        except (TypeError, ValueError):
            pass
    current_at = _timestamp_key(current.get("captured_at"))
    incoming_at = _timestamp_key(incoming.get("captured_at"))
    # A malformed incoming clock must never roll a valid quote backwards.
    if current_at is not None and incoming_at is None:
        return True
    return bool(current_at is not None and incoming_at is not None
                and incoming_at < current_at)


class LiveQuoteStore:
    """Thread-safe bounded cache of hub snapshots and BBO deltas."""

    def __init__(self) -> None:
        self._condition = threading.Condition()
        self._quotes: dict[str, dict[str, Any]] = {}
        self._revision = 0
        self._change_log: deque[tuple[int, str]] = deque(maxlen=4096)
        self._connected = False
        self._last_message_monotonic: float | None = None
        self._shadow: dict[str, Any] = {"state": "starting"}
        self._stream_id: str | None = None
        self._upstream_connected: bool | None = None
        self._upstream_detail: str | None = None
        self._upstream_updated_at: str | None = None
        self._error: str | None = None

    def _bump(self, changed_tokens: set[str] | None = None) -> None:
        self._revision += 1
        for token in changed_tokens or set():
            self._change_log.append((self._revision, token))
        self._condition.notify_all()

    def mark_connected(self) -> None:
        with self._condition:
            was_connected = self._connected
            changed = not was_connected or self._error is not None
            self._connected = True
            self._error = None
            # A re-established socket has not proved that its cached snapshot
            # is current.  Stay in ``recovering`` until the new connection
            # delivers a snapshot or BBO message.
            if not was_connected:
                self._last_message_monotonic = None
            if changed:
                self._bump()

    def mark_disconnected(self, error: str | None = None) -> None:
        with self._condition:
            changed = self._connected or self._error != error
            self._connected = False
            self._error = error
            if changed:
                self._bump()

    def apply(self, message: dict[str, Any]) -> bool:
        """Apply one validated hub message.  Unknown messages are ignored."""
        kind = message.get("type")
        with self._condition:
            changed_tokens: set[str] = set()
            if kind == "snapshot":
                quotes = message.get("quotes")
                if not isinstance(quotes, list):
                    return False
                stream_id = message.get("stream_id")
                previous_tokens = set(self._quotes)
                prepared: dict[str, dict[str, Any]] = {}
                for quote in quotes:
                    if isinstance(quote, dict) and quote.get("token_id"):
                        token = str(quote["token_id"])
                        incoming = dict(quote)
                        if stream_id and not incoming.get("stream_id"):
                            incoming["stream_id"] = stream_id
                        current = self._quotes.get(token)
                        # The snapshot is authoritative for membership, while
                        # timestamps are authoritative for values.  This lets a
                        # universe switch remove retired tokens without a
                        # reconnect snapshot rolling an active token backwards.
                        prepared[token] = (
                            dict(current) if _incoming_is_older(current, incoming)
                            else incoming
                        )
                self._quotes = prepared
                changed_tokens = previous_tokens | set(prepared)
                self._shadow = dict(message.get("shadow") or {"state": "unknown"})
                self._stream_id = str(stream_id) if stream_id else self._stream_id
                upstream = message.get("upstream")
                if isinstance(upstream, dict):
                    self._upstream_connected = bool(upstream.get("connected"))
                    self._upstream_detail = str(upstream.get("detail") or "")
                    self._upstream_updated_at = upstream.get("updated_at")
            elif kind == "bbo":
                token = message.get("token_id")
                if not token:
                    return False
                token = str(token)
                incoming = dict(message)
                if _incoming_is_older(self._quotes.get(token), incoming):
                    return False
                self._quotes[token] = incoming
                changed_tokens.add(token)
                if incoming.get("stream_id"):
                    self._stream_id = str(incoming["stream_id"])
            elif kind == "status":
                upstream = message.get("upstream")
                if not isinstance(upstream, dict):
                    return False
                if message.get("stream_id"):
                    self._stream_id = str(message["stream_id"])
                self._upstream_connected = bool(upstream.get("connected"))
                self._upstream_detail = str(upstream.get("detail") or "")
                self._upstream_updated_at = upstream.get("updated_at")
            else:
                return False
            self._bump(changed_tokens)
            self._last_message_monotonic = time.monotonic()
            return True

    def _view_locked(self, fresh_after_seconds: float,
                     since_revision: int | None = None) -> dict[str, Any]:
        age = (time.monotonic() - self._last_message_monotonic
               if self._last_message_monotonic is not None else None)
        upstream_ok = self._upstream_connected is not False
        healthy = (
            self._connected and upstream_ok
            and age is not None and age <= fresh_after_seconds
        )
        changed_tokens: list[str] = []
        if since_revision is not None and since_revision < self._revision:
            if self._change_log and since_revision < self._change_log[0][0] - 1:
                changed_tokens = sorted(self._quotes)
            else:
                changed_tokens = sorted({
                    token for revision, token in self._change_log
                    if revision > since_revision
                })
        return {
            "state": "healthy" if healthy else ("recovering" if self._connected else "offline"),
            "age_seconds": round(age, 1) if age is not None else None,
            "revision": self._revision,
            "changed_tokens": changed_tokens,
            "quotes": {token: dict(value) for token, value in self._quotes.items()},
            "shadow": dict(self._shadow),
            "stream_id": self._stream_id,
            "upstream_connected": self._upstream_connected,
            "upstream_detail": self._upstream_detail,
            "upstream_updated_at": self._upstream_updated_at,
            "error": self._error,
        }

    def view(self, fresh_after_seconds: float = 20.0) -> dict[str, Any]:
        with self._condition:
            return self._view_locked(fresh_after_seconds)

    def wait_for_revision(self, revision: int, timeout: float | None = None,
                          fresh_after_seconds: float = 20.0) -> dict[str, Any]:
        """Block a local consumer until a hub delta/status arrives or timeout."""
        with self._condition:
            self._condition.wait_for(
                lambda: self._revision != revision,
                timeout=timeout,
            )
            return self._view_locked(
                fresh_after_seconds, since_revision=revision
            )


class StateHubClient:
    """Reconnectable local-only WebSocket consumer running in one daemon thread."""

    def __init__(self, url: str = "ws://127.0.0.1:8765") -> None:
        self.url = url
        self.store = LiveQuoteStore()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._thread_main, name="dashboard-state-hub", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def view(self) -> dict[str, Any]:
        return self.store.view()

    def wait_for_revision(self, revision: int,
                          timeout: float | None = None) -> dict[str, Any]:
        return self.store.wait_for_revision(revision, timeout)

    def _thread_main(self) -> None:
        asyncio.run(self._run())

    async def _run(self) -> None:
        while not self._stop.is_set():
            try:
                async with websockets.connect(self.url, open_timeout=3, ping_interval=20, ping_timeout=20) as socket:
                    self.store.mark_connected()
                    async for raw in socket:
                        try:
                            parsed = json.loads(raw)
                        except (TypeError, json.JSONDecodeError):
                            continue
                        if isinstance(parsed, dict):
                            self.store.apply(parsed)
            except Exception as exc:
                self.store.mark_disconnected(type(exc).__name__)
            if not self._stop.is_set():
                await asyncio.sleep(2)
