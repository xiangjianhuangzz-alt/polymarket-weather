"""Read-only, isolated CLOB WebSocket stability probe.

This tool never imports the production stream, never writes a project database,
and never sends orders.  It subscribes to one currently published YES token and
prints a compact JSON result for version-to-version comparison.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sqlite3
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import websockets


BASE = Path(__file__).resolve().parent
RESEARCH_DB = BASE / "data" / "research.sqlite3"
WS = "wss://ws-subscriptions-clob.polymarket.com/ws/market"


def published_token() -> str:
    """Read one token from the collector's completed manifest; never write."""
    with sqlite3.connect(f"file:{RESEARCH_DB}?mode=ro", uri=True, timeout=3) as db:
        row = db.execute("""SELECT members_json FROM market_universe_publications
                         ORDER BY published_at DESC LIMIT 1""").fetchone()
    if not row:
        raise RuntimeError("no completed market universe available")
    members = json.loads(row[0])
    for member in members:
        token = str(member.get("token_id") or "").strip()
        if token:
            return token
    raise RuntimeError("completed market universe contains no token")


async def probe(token: str, seconds: float) -> dict[str, Any]:
    started = time.monotonic()
    result: dict[str, Any] = {
        "started_at": datetime.now(UTC).isoformat(),
        "library_version": getattr(websockets, "__version__", "unknown"),
        "duration_target_seconds": seconds,
        "token_suffix": token[-8:],
        "messages": 0,
        "first_message_ms": None,
        "error_type": None,
        "error": None,
    }
    try:
        async with websockets.connect(WS, open_timeout=15, ping_interval=20, ping_timeout=20) as socket:
            result["connect_ms"] = round((time.monotonic() - started) * 1000, 1)
            await socket.send(json.dumps({"assets_ids": [token], "type": "market", "custom_feature_enabled": True}))
            deadline = time.monotonic() + seconds
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                try:
                    await asyncio.wait_for(socket.recv(), timeout=min(5.0, remaining))
                except TimeoutError:
                    continue
                result["messages"] += 1
                if result["first_message_ms"] is None:
                    result["first_message_ms"] = round((time.monotonic() - started) * 1000, 1)
    except Exception as exc:  # The exception type is the POC output.
        result["error_type"] = type(exc).__name__
        result["error"] = str(exc)[:500]
    result["elapsed_seconds"] = round(time.monotonic() - started, 1)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=float, default=90.0)
    args = parser.parse_args()
    print(json.dumps(asyncio.run(probe(published_token(), max(5.0, args.seconds))), ensure_ascii=False))


if __name__ == "__main__":
    main()
