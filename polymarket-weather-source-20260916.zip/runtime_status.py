"""Small dependency-free helpers shared by isolated runtime processes."""
from __future__ import annotations

import json
import logging
import os
import queue
import threading
import time
from datetime import UTC, datetime
from pathlib import Path


def parse_utc(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except ValueError:
        return None


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.stem}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    for attempt in range(3):
        try:
            temporary.replace(path)
            return
        except PermissionError:
            time.sleep(0.1 * (attempt + 1))
    temporary.unlink(missing_ok=True)
    raise PermissionError(f"cannot atomically update {path}")


class WorkerProgressPublisher:
    """Publish replaceable worker liveness without touching a SQLite writer.

    Runtime hot paths only enqueue the newest status.  A tiny isolated thread
    performs the filesystem replace, so antivirus or filesystem latency cannot
    pause a websocket reader or a paper-observer cycle.
    """

    def __init__(self, path: Path, service: str) -> None:
        self.path = Path(path)
        self.service = str(service)
        self._items: queue.Queue[dict | None] = queue.Queue(maxsize=1)
        self._stopping = threading.Event()
        self._thread = threading.Thread(
            target=self._run,
            name=f"{self.service}-progress",
            daemon=True,
        )

    def start(self) -> None:
        self._thread.start()

    def publish(
        self,
        state: str,
        *,
        detail: str | None = None,
        deadline_at: str | None = None,
        task_id: str | None = None,
        reason: str | None = None,
        orders_created: int | None = None,
    ) -> bool:
        if task_id is not None and not isinstance(task_id, str):
            raise TypeError("task_id must be a string or None")
        if reason is not None and not isinstance(reason, str):
            raise TypeError("reason must be a string or None")
        if isinstance(orders_created, bool) or (
            orders_created is not None
            and (not isinstance(orders_created, int) or orders_created < 0)
        ):
            raise TypeError("orders_created must be a non-negative integer or None")
        if task_id is not None and len(task_id) > 500:
            raise ValueError("task_id exceeds maximum length")
        if reason is not None and len(reason) > 500:
            raise ValueError("reason exceeds maximum length")
        if self._stopping.is_set() or not self._thread.is_alive():
            return False
        payload = {
            "schema": 1,
            "service": self.service,
            "worker_pid": os.getpid(),
            "state": str(state),
            "updated_at": datetime.now(UTC).isoformat(),
            "detail": str(detail)[:500] if detail else None,
            "deadline_at": str(deadline_at) if deadline_at else None,
            "task_id": task_id,
            "reason": reason,
            "orders_created": orders_created,
        }
        try:
            self._items.put_nowait(payload)
            return True
        except queue.Full:
            try:
                self._items.get_nowait()
                self._items.task_done()
            except queue.Empty:
                pass
            try:
                self._items.put_nowait(payload)
                return True
            except queue.Full:
                return False

    def close(self) -> None:
        if self._stopping.is_set():
            return
        self._stopping.set()
        try:
            self._items.put_nowait(None)
        except queue.Full:
            try:
                self._items.get_nowait()
                self._items.task_done()
            except queue.Empty:
                pass
            try:
                self._items.put_nowait(None)
            except queue.Full:
                pass
        self._thread.join(timeout=3)

    def _run(self) -> None:
        while True:
            item = self._items.get()
            try:
                if item is None:
                    return
                atomic_json(self.path, item)
            except OSError as exc:
                logging.warning("%s worker progress update skipped: %s", self.service, exc)
            finally:
                self._items.task_done()
