from __future__ import annotations

import asyncio
import json
import sqlite3
import tempfile
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import collector
import httpx
import service_supervisor as supervisor
from runtime_status import WorkerProgressPublisher


class _Response:
    def __init__(self, payload, status_code: int = 200) -> None:
        self.payload = payload
        self.status_code = status_code

    def raise_for_status(self) -> None:
        return None

    def json(self):
        return self.payload


class _SlowClient:
    def __init__(self, delay: float = 0.01) -> None:
        self.delay = delay
        self.active = 0
        self.maximum_active = 0

    async def get(self, url: str, *_args, **_kwargs) -> _Response:
        self.active += 1
        self.maximum_active = max(self.maximum_active, self.active)
        try:
            await asyncio.sleep(self.delay)
            if "/events/slug/" in url:
                return _Response({}, status_code=404)
            return _Response({"events": []})
        finally:
            self.active -= 1


class _FailingClient:
    async def get(self, *_args, **_kwargs) -> _Response:
        raise httpx.ConnectError("offline")


class _SearchThenDetailFailureClient:
    async def get(self, url: str, *_args, **_kwargs) -> _Response:
        if url.endswith("/public-search"):
            return _Response({"events": [{"id": "event", "active": True, "closed": False,
                                           "title": "highest temperature in beijing on July 25"}]})
        raise httpx.ConnectError("detail offline")


class _DetailSuccessClient:
    async def get(self, url: str, *_args, **_kwargs) -> _Response:
        if url.endswith("/events/event"):
            return _Response({
                "id": "event",
                "title": "Highest temperature in Beijing on August 1, 2026",
                "resolutionSource": "https://www.wunderground.com/weather/cn/beijing/ZBAA",
                "active": True,
                "closed": False,
                "markets": [{
                    "id": "market-new",
                    "question": "Will the highest temperature in Beijing be 30 C on August 1?",
                    "description": "unit",
                    "resolutionSource": "https://www.wunderground.com/weather/cn/beijing/ZBAA",
                    "endDate": "2026-08-01",
                    "outcomes": '["Yes", "No"]',
                    "outcomePrices": '["0.5", "0.5"]',
                    "clobTokenIds": '["1001", "1002"]',
                    "liquidityNum": 1,
                    "volumeNum": 1,
                    "active": True,
                    "closed": False,
                    "groupItemTitle": "30 C",
                }],
            })
        raise AssertionError(f"unexpected URL: {url}")


class _ResolutionClient:
    def __init__(self, payloads: dict[str, dict]) -> None:
        self.payloads = payloads
        self.requested: list[str] = []

    async def get(self, url: str, *_args, **kwargs) -> _Response:
        if url.endswith("/markets"):
            params = list(kwargs.get("params") or [])
            requested = [str(value) for key, value in params if key == "id"]
            closed_filter = next((value for key, value in params if key == "closed"), None)
            self.requested.extend(requested)
            payloads = []
            for market_id in requested:
                payload = self.payloads.get(market_id)
                if payload is None:
                    continue
                if closed_filter == "true" and payload.get("closed") is not True:
                    continue
                if closed_filter == "false" and payload.get("closed") is not False:
                    continue
                payloads.append(payload)
            return _Response(payloads)
        market_id = url.rsplit("/", 1)[-1]
        self.requested.append(market_id)
        payload = self.payloads.get(market_id)
        return _Response(payload or {}, 200 if payload is not None else 404)


class _RecordingProgress:
    def __init__(self) -> None:
        self.phases: list[str] = []

    def begin(self, phase: str, _total: int, _budget: float) -> None:
        self.phases.append(phase)

    def advance(self, _completed: int) -> None:
        return None


def _test_authorized_publication(records, _statuses, **_kwargs):
    """Keep pre-approval collector tests focused on their own write behavior."""
    return {
        "candidate": collector.build_research_universe_candidate(records),
        "already_published": False,
    }


class CollectorProgressTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.db = sqlite3.connect(Path(self.tmp.name) / "research.sqlite3")
        self.db.execute("CREATE TABLE service_heartbeats(service TEXT PRIMARY KEY,updated_at TEXT,detail TEXT)")
        self.db.commit()

    def tearDown(self) -> None:
        self.db.close()
        self.tmp.cleanup()

    def test_progress_heartbeat_has_phase_deadline_and_completion(self) -> None:
        progress = collector.CollectorProgress(self.db, "cycle-test")
        progress.begin("market_search", 3, 120)
        progress.advance(1)
        row = self.db.execute("SELECT detail FROM service_heartbeats WHERE service='collector'").fetchone()
        self.assertIn("state=running", row[0])
        self.assertIn("phase=market_search", row[0])
        self.assertIn("progress=1/3", row[0])
        self.assertIn("deadline_at=", row[0])
        progress.finish("complete")
        row = self.db.execute("SELECT detail FROM service_heartbeats WHERE service='collector'").fetchone()
        self.assertIn("state=idle", row[0])

    def test_progress_also_publishes_pid_scoped_worker_status(self) -> None:
        status_path = Path(self.tmp.name) / "collector.worker.json"
        publisher = WorkerProgressPublisher(status_path, "collector")
        publisher.start()
        try:
            progress = collector.CollectorProgress(
                self.db,
                "cycle-file",
                publisher=publisher,
            )
            progress.begin("market_detail", 5, 120)
            deadline = datetime.now(UTC) + timedelta(seconds=2)
            payload = None
            while datetime.now(UTC) < deadline:
                if status_path.exists():
                    payload = json.loads(status_path.read_text(encoding="utf-8"))
                    if payload.get("state") == "running":
                        break
                import time
                time.sleep(0.02)
        finally:
            publisher.close()

        self.assertIsNotNone(payload)
        self.assertEqual(payload["service"], "collector")
        self.assertEqual(payload["state"], "running")
        self.assertIn("phase=market_detail", payload["detail"])
        self.assertIsNotNone(payload["deadline_at"])

    def test_market_search_is_bounded_concurrent_and_reports_progress(self) -> None:
        client = _SlowClient()
        progress = collector.CollectorProgress(self.db, "cycle-search")
        with patch.object(collector, "ALLOWED_CITIES", {"beijing"}), \
             patch.object(collector, "MARKET_REQUEST_CONCURRENCY", 3):
            events = asyncio.run(collector.active_events(client, progress))
        self.assertEqual(events, [])
        self.assertGreaterEqual(client.maximum_active, 2)
        detail = self.db.execute("SELECT detail FROM service_heartbeats WHERE service='collector'").fetchone()[0]
        self.assertIn("phase=market_search", detail)
        self.assertIn("progress=3/3", detail)

    def test_search_failure_is_explicit_not_silently_partial(self) -> None:
        progress = collector.CollectorProgress(self.db, "cycle-failure")
        with patch.object(collector, "ALLOWED_CITIES", {"beijing"}):
            with self.assertRaises(collector.MarketScanIncomplete):
                asyncio.run(collector.active_events(_FailingClient(), progress))

    def test_budget_exhaustion_returns_without_publishing_market_universe(self) -> None:
        progress = collector.CollectorProgress(self.db, "cycle-budget")
        with patch.object(collector, "ALLOWED_CITIES", {"beijing"}), \
             patch.object(collector, "MARKET_SCAN_BUDGET_SECONDS", 0.01):
            result = asyncio.run(collector.collect_markets(_SlowClient(0.05), self.db,
                                                            datetime.now(UTC).isoformat(), progress))
        self.assertEqual(result, 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM service_heartbeats").fetchone()[0], 1)

    def test_detail_failure_keeps_market_database_untouched(self) -> None:
        progress = collector.CollectorProgress(self.db, "cycle-detail-failure")
        with patch.object(collector, "ALLOWED_CITIES", {"beijing"}):
            result = asyncio.run(collector.collect_markets(_SearchThenDetailFailureClient(), self.db,
                                                            datetime.now(UTC).isoformat(), progress))
        self.assertEqual(result, 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM sqlite_master WHERE name='market_snapshots'").fetchone()[0], 0)

    def test_connect_does_not_run_retention_on_worker_startup(self) -> None:
        path = Path(self.tmp.name) / "startup.sqlite3"
        with patch.object(collector, "DB_PATH", path), \
             patch.object(collector, "prune_research_data") as prune:
            db = collector.connect()
            db.close()
        prune.assert_not_called()

    def test_market_database_publication_has_its_own_phase(self) -> None:
        db_path = Path(self.tmp.name) / "publish.sqlite3"
        with patch.object(collector, "DB_PATH", db_path), \
             patch.object(collector, "prune_research_data"):
            db = collector.connect()
        progress = _RecordingProgress()
        event = {
            "id": "event",
            "active": True,
            "closed": False,
            "title": "highest temperature in Beijing on August 1",
            "_query_city": "Beijing",
            "_query_target_date": "2026-08-01",
        }
        try:
            with patch.object(collector, "active_events", return_value=[event]), \
                 patch.object(collector, "prepare_research_universe_publication",
                              side_effect=_test_authorized_publication):
                found = asyncio.run(collector.collect_markets(
                    _DetailSuccessClient(), db, "2026-08-01T00:00:00+00:00", progress
                ))
        finally:
            db.close()
        self.assertEqual(found, 1)
        self.assertEqual(progress.phases, ["market_detail", "market_publish"])

    def test_locked_market_publication_rolls_back_without_partial_snapshot(self) -> None:
        db_path = Path(self.tmp.name) / "locked-publish.sqlite3"
        with patch.object(collector, "DB_PATH", db_path), \
             patch.object(collector, "prune_research_data"):
            db = collector.connect()
        blocker = sqlite3.connect(db_path, timeout=0.1)
        blocker.execute("BEGIN IMMEDIATE")
        db.execute("PRAGMA busy_timeout=20")
        event = {
            "id": "event",
            "active": True,
            "closed": False,
            "title": "highest temperature in Beijing on August 1",
            "_query_city": "Beijing",
            "_query_target_date": "2026-08-01",
        }
        try:
            with patch.object(collector, "active_events", return_value=[event]), \
                 patch.object(collector, "prepare_research_universe_publication",
                              side_effect=_test_authorized_publication):
                with self.assertRaises(sqlite3.OperationalError):
                    asyncio.run(collector.collect_markets(
                        _DetailSuccessClient(), db, "2026-08-01T00:00:00+00:00",
                        _RecordingProgress(),
                    ))
        finally:
            blocker.rollback()
            blocker.close()
        try:
            self.assertEqual(
                db.execute("SELECT COUNT(*) FROM market_snapshots").fetchone()[0], 0
            )
            self.assertEqual(
                db.execute("SELECT COUNT(*) FROM market_universe_publications").fetchone()[0], 0
            )
        finally:
            db.close()

    def test_deactivate_missing_markets_changes_only_latest_snapshot(self) -> None:
        self.db.execute("""CREATE TABLE market_snapshots (
            captured_at TEXT NOT NULL, market_id TEXT NOT NULL, active INTEGER,
            PRIMARY KEY(captured_at, market_id))""")
        self.db.executemany(
            "INSERT INTO market_snapshots VALUES (?,?,?)",
            [
                ("2026-07-30T00:00:00+00:00", "expired", 1),
                ("2026-07-31T00:00:00+00:00", "expired", 1),
                ("2026-07-30T00:00:00+00:00", "current", 1),
                ("2026-07-31T00:00:00+00:00", "current", 1),
            ],
        )
        changed = collector.deactivate_missing_markets(self.db, {"current"})
        rows = self.db.execute(
            "SELECT captured_at,market_id,active FROM market_snapshots ORDER BY market_id,captured_at"
        ).fetchall()
        self.assertEqual(changed, 1)
        self.assertEqual(rows, [
            ("2026-07-30T00:00:00+00:00", "current", 1),
            ("2026-07-31T00:00:00+00:00", "current", 1),
            ("2026-07-30T00:00:00+00:00", "expired", 1),
            ("2026-07-31T00:00:00+00:00", "expired", 0),
        ])

    def test_retention_cleanup_is_batch_bounded(self) -> None:
        path = Path(self.tmp.name) / "retention.sqlite3"
        with patch.object(collector, "DB_PATH", path), \
             patch.object(collector, "prune_research_data"):
            db = collector.connect()
        old = "2020-01-01T00:00:00+00:00"
        db.executemany(
            "INSERT INTO forecast_snapshots VALUES (?,?,?,?)",
            [(f"{old[:-6]}{index:02d}+00:00", "Beijing", f"model-{index}", "{}") for index in range(5)],
        )
        db.commit()
        try:
            collector.prune_research_data(db, batch_rows=2)
            remaining = db.execute("SELECT COUNT(*) FROM forecast_snapshots").fetchone()[0]
        finally:
            db.close()
        self.assertEqual(remaining, 3)

    @staticmethod
    def _resolution_market(
        market_id: str,
        *,
        target_day: str = "August 1",
        yes_price: str = "1",
        closed: bool = False,
        outcomes: str = '["Yes", "No"]',
    ) -> dict:
        return {
            "id": market_id,
            "question": f"Will the highest temperature in Beijing be 30 C on {target_day}?",
            "description": "unit",
            "resolutionSource": "https://www.wunderground.com/weather/cn/beijing/ZBAA",
            "endDate": "2026-08-01T12:00:00Z",
            "outcomes": outcomes,
            "outcomePrices": f'[' + json.dumps(yes_price) + ', "0"]',
            "clobTokenIds": '["1001", "1002"]',
            "liquidityNum": 1,
            "volumeNum": 1,
            "active": not closed,
            "closed": closed,
            "acceptingOrders": not closed,
            "umaResolutionStatus": "resolved" if closed else "unresolved",
            "groupItemTitle": "30 C",
        }

    def _resolution_database(self, market: dict) -> sqlite3.Connection:
        path = Path(self.tmp.name) / f"resolution-{market['id']}.sqlite3"
        with patch.object(collector, "DB_PATH", path), \
             patch.object(collector, "prune_research_data"):
            db = collector.connect()
        collector.save_market(db, "2026-08-01T12:00:00+00:00", market, "Beijing")
        db.commit()
        return db

    def test_past_target_day_exact_100_is_only_provisional_before_close(self) -> None:
        market = self._resolution_market("winner-open")
        db = self._resolution_database(market)
        try:
            resolved = asyncio.run(collector.collect_resolutions(
                _ResolutionClient({"winner-open": market}), db,
                "2026-08-01T16:05:00+00:00",
            ))
            final_count = db.execute(
                "SELECT COUNT(*) FROM market_resolutions"
            ).fetchone()[0]
            provisional = db.execute(
                "SELECT state,market_active,market_closed FROM market_resolution_evidence"
            ).fetchone()
        finally:
            db.close()
        self.assertEqual(resolved, 0)
        self.assertEqual(final_count, 0)
        self.assertEqual(provisional, ("provisional", 1, 0))

    def test_same_target_day_exact_100_does_not_record_early(self) -> None:
        market = self._resolution_market("winner-same-day", target_day="August 2")
        db = self._resolution_database(market)
        try:
            resolved = asyncio.run(collector.collect_resolutions(
                _ResolutionClient({"winner-same-day": market}), db,
                "2026-08-01T16:05:00+00:00",
            ))
            count = db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0]
        finally:
            db.close()
        self.assertEqual(resolved, 0)
        self.assertEqual(count, 0)

    def test_past_target_day_displayed_100_is_only_provisional_before_close(self) -> None:
        market = self._resolution_market("near-winner", yes_price="0.999")
        db = self._resolution_database(market)
        try:
            resolved = asyncio.run(collector.collect_resolutions(
                _ResolutionClient({"near-winner": market}), db,
                "2026-08-01T16:05:00+00:00",
            ))
            final_count = db.execute(
                "SELECT COUNT(*) FROM market_resolutions"
            ).fetchone()[0]
            provisional = db.execute(
                "SELECT state,market_active,market_closed FROM market_resolution_evidence"
            ).fetchone()
        finally:
            db.close()
        self.assertEqual(resolved, 0)
        self.assertEqual(final_count, 0)
        self.assertEqual(provisional, ("provisional", 1, 0))

    def test_past_target_day_below_displayed_100_does_not_record_early(self) -> None:
        market = self._resolution_market("below-winner", yes_price="0.998")
        db = self._resolution_database(market)
        try:
            resolved = asyncio.run(collector.collect_resolutions(
                _ResolutionClient({"below-winner": market}), db,
                "2026-08-01T16:05:00+00:00",
            ))
            count = db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0]
        finally:
            db.close()
        self.assertEqual(resolved, 0)
        self.assertEqual(count, 0)

    def test_malformed_or_unavailable_resolution_does_not_write(self) -> None:
        malformed = self._resolution_market("malformed", outcomes="not-json")
        db = self._resolution_database(malformed)
        try:
            first = asyncio.run(collector.collect_resolutions(
                _ResolutionClient({"malformed": malformed}), db,
                "2026-08-01T16:05:00+00:00",
            ))
            second = asyncio.run(collector.collect_resolutions(
                _FailingClient(), db, "2026-08-01T16:10:00+00:00",
            ))
            count = db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0]
        finally:
            db.close()
        self.assertEqual((first, second, count), (0, 0, 0))

    def test_early_winner_evidence_is_idempotent_and_never_final(self) -> None:
        market = self._resolution_market("winner-repeat")
        db = self._resolution_database(market)
        client = _ResolutionClient({"winner-repeat": market})
        try:
            first = asyncio.run(collector.collect_resolutions(
                client, db, "2026-08-01T16:05:00+00:00",
            ))
            second = asyncio.run(collector.collect_resolutions(
                client, db, "2026-08-01T16:10:00+00:00",
            ))
            final_count = db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0]
            evidence_count = db.execute(
                "SELECT COUNT(*) FROM market_resolution_evidence"
            ).fetchone()[0]
        finally:
            db.close()
        self.assertEqual((first, second, final_count, evidence_count), (0, 0, 0, 1))

    def test_existing_legacy_final_is_not_requeried_during_adapter_rollout(self) -> None:
        market = self._resolution_market("legacy-final")
        db = self._resolution_database(market)
        db.execute(
            """INSERT INTO market_resolutions
            (market_id,city,target_date,bucket_label,yes_resolved,resolved_at,
             outcome_prices_json,resolution_source)
            VALUES (?,?,?,?,?,?,?,?)""",
            (
                "legacy-final",
                "Beijing",
                "2026-08-01",
                "30 C",
                1,
                "2026-08-01T16:00:00+00:00",
                '["1","0"]',
                "https://www.wunderground.com/weather/cn/beijing/ZBAA",
            ),
        )
        db.commit()
        client = _ResolutionClient({"legacy-final": market})
        try:
            resolved = asyncio.run(
                collector.collect_resolutions(
                    client, db, "2026-08-01T16:05:00+00:00"
                )
            )
            evidence_count = db.execute(
                "SELECT COUNT(*) FROM market_resolution_evidence"
            ).fetchone()[0]
        finally:
            db.close()
        self.assertEqual(resolved, 0)
        self.assertEqual(evidence_count, 0)
        self.assertEqual(client.requested, [])

    def test_provisional_winner_is_repolled_and_replaced_by_final_close(self) -> None:
        provisional = self._resolution_market("winner-transition")
        final = self._resolution_market("winner-transition", closed=True)
        db = self._resolution_database(provisional)
        try:
            first = asyncio.run(collector.collect_resolutions(
                _ResolutionClient({"winner-transition": provisional}), db,
                "2026-08-01T16:05:00+00:00",
            ))
            second = asyncio.run(collector.collect_resolutions(
                _ResolutionClient({"winner-transition": final}), db,
                "2026-08-01T16:10:00+00:00",
            ))
            states = db.execute(
                """SELECT state,market_active,market_closed
                     FROM market_resolution_evidence
                    WHERE market_id='winner-transition' ORDER BY observed_at"""
            ).fetchall()
            projection = db.execute(
                "SELECT resolved_at,yes_resolved FROM market_resolutions WHERE market_id=?",
                ("winner-transition",),
            ).fetchone()
        finally:
            db.close()
        self.assertEqual((first, second), (0, 1))
        self.assertEqual(states, [("provisional", 1, 0), ("final", 0, 1)])
        self.assertEqual(projection, ("2026-08-01T16:10:00+00:00", 1))

    def test_closed_market_resolution_path_remains_compatible(self) -> None:
        winner = self._resolution_market("closed-winner", closed=True)
        loser = self._resolution_market("closed-loser", yes_price="0", closed=True)
        db = self._resolution_database(winner)
        collector.save_market(db, "2026-08-01T12:00:01+00:00", loser, "Beijing")
        db.commit()
        try:
            resolved = asyncio.run(collector.collect_resolutions(
                _ResolutionClient({"closed-winner": winner, "closed-loser": loser}), db,
                "2026-08-01T16:05:00+00:00",
            ))
            rows = db.execute(
                "SELECT market_id,yes_resolved FROM market_resolutions ORDER BY market_id"
            ).fetchall()
        finally:
            db.close()
        self.assertEqual(resolved, 2)
        self.assertEqual(rows, [("closed-loser", 0), ("closed-winner", 1)])

    def test_supervisor_keeps_worker_alive_before_phase_deadline(self) -> None:
        now = datetime.now(UTC)
        detail = f"state=running; phase=market_search; deadline_at={(now + timedelta(seconds=30)).isoformat()}"
        self.assertIsNone(supervisor.collector_restart_reason(600, detail, now=now))

    def test_supervisor_restarts_after_phase_deadline_and_grace(self) -> None:
        now = datetime.now(UTC)
        detail = f"state=running; phase=market_search; deadline_at={(now - timedelta(seconds=46)).isoformat()}"
        self.assertEqual(supervisor.collector_restart_reason(200, detail, now=now),
                         "phase_deadline_exceeded:market_search")


class ResearchCitySourceTests(unittest.TestCase):
    NEW_RESEARCH_CITIES = {
        "Wuhan": "ZHHH",
        "Chongqing": "ZUCK",
        "Zhengzhou": "ZHCC",
    }
    RETIRED_CITIES = {"Jinan": "ZSJN", "Qingdao": "ZSQD"}

    @staticmethod
    def _event(city: str, station: str | None) -> dict:
        source = "" if station is None else (
            f"https://www.wunderground.com/weather/cn/{city.lower()}/{station}"
        )
        return {
            "id": f"{city}-{station}",
            "title": f"Highest temperature in {city} on August 1, 2026",
            "resolutionSource": source,
        }

    def test_city_roles_and_settlement_stations_are_centralized(self) -> None:
        self.assertEqual(
            {city: collector.CITY_ROLES[city.lower()] for city in self.NEW_RESEARCH_CITIES},
            {city: "research_only" for city in self.NEW_RESEARCH_CITIES},
        )
        self.assertEqual(
            {city: collector.CITY_SETTLEMENT_STATIONS[city.lower()] for city in self.NEW_RESEARCH_CITIES},
            self.NEW_RESEARCH_CITIES,
        )
        self.assertEqual(collector.CITY_ROLES["shenzhen"], "research_only")
        for city, station in self.RETIRED_CITIES.items():
            self.assertNotIn(city.lower(), collector.CITY_ROLES)
            self.assertEqual(collector.CITY_SETTLEMENT_STATIONS[city.lower()], station)

    def test_only_paired_city_and_station_can_be_discovered(self) -> None:
        for city, station in self.NEW_RESEARCH_CITIES.items():
            parsed = collector.station_and_city(self._event(city, station))
            self.assertIsNotNone(parsed)
            self.assertEqual(parsed[:2], (station, city))

        self.assertIsNone(collector.station_and_city(self._event("Wuhan", "ZUCK")))
        self.assertIsNone(collector.station_and_city(self._event("Chongqing", "ZHHH")))
        self.assertIsNone(collector.station_and_city(self._event("Qingdao", "ZBAA")))
        self.assertIsNone(collector.station_and_city(self._event("Unknown City", "ZHHH")))
        self.assertIsNone(collector.station_and_city(self._event("Wuhan", "ZZZZ")))
        self.assertIsNone(collector.station_and_city(self._event("Wuhan", None)))
        for city, station in self.RETIRED_CITIES.items():
            self.assertIsNone(collector.station_and_city(self._event(city, station)))

    def test_new_taf_stations_keep_the_existing_tx_parser(self) -> None:
        report = {
            "validTimeFrom": datetime(2026, 8, 1, 0, tzinfo=UTC).timestamp(),
            "rawTAF": "TAF ZHHH 010000Z 0100/0206 TX35/0106Z TX31/0118Z",
        }
        for city, station in self.NEW_RESEARCH_CITIES.items():
            self.assertEqual(collector.TAF_GRID_STATIONS[city][0], station)
            self.assertEqual(collector.taf_target_high(report, "2026-08-01"), 35.0)

    def test_verified_qxzx_sources_exclude_retired_cities(self) -> None:
        expected = {
            "Wuhan": "JCCN100054",
            "Chongqing": "JCCN100139",
            "Zhengzhou": "JCCN100052",
        }
        for city, aid in expected.items():
            configured = collector.weatherol_airport_for_city(city)
            self.assertIsNotNone(configured)
            self.assertEqual(configured[0], aid)
        self.assertIsNone(collector.weatherol_airport_for_city("Qingdao"))
        self.assertIsNone(collector.weatherol_airport_for_city("Jinan"))


if __name__ == "__main__":
    unittest.main()
