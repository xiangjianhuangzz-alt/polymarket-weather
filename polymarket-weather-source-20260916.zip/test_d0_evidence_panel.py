from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import textwrap
import unittest


ROOT = Path(__file__).resolve().parent
NODE_CANDIDATES = tuple(Path(value) for value in filter(None, (
    os.environ.get("CODEX_NODE_PATH"), shutil.which("node"),
    r"C:\Users\HP\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe",
)))
NODE_MODULE_CANDIDATES = tuple(Path(value) for value in filter(None, (
    os.environ.get("CODEX_NODE_MODULES"), os.environ.get("NODE_PATH"),
    r"C:\Users\HP\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules",
)))
BROWSER_CANDIDATES = tuple(Path(value) for value in filter(None, (
    os.environ.get("CODEX_BROWSER_PATH"),
    Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
    Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
    Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
    shutil.which("msedge"), shutil.which("chrome"), shutil.which("chromium"),
)))


class D0EvidencePanelDomTests(unittest.TestCase):
    def test_frozen_contract_in_executable_dom(self) -> None:
        node = next((path for path in NODE_CANDIDATES if path.exists()), None)
        modules = next((path for path in NODE_MODULE_CANDIDATES if path.exists()), None)
        browser = next((path for path in BROWSER_CANDIDATES if path.exists()), None)
        self.assertIsNotNone(node, "Node runtime unavailable; set CODEX_NODE_PATH")
        self.assertIsNotNone(modules, "Node modules unavailable; set CODEX_NODE_MODULES")
        self.assertIsNotNone(browser, "Chromium browser unavailable; set CODEX_BROWSER_PATH")
        script = textwrap.dedent(r"""
        const {chromium}=require('playwright'), assert=require('node:assert/strict');
        const url=process.env.D0_TEST_URL, executablePath=process.env.D0_BROWSER_PATH;
        const places=[['Beijing','北京','ZBAA','formal'],['Shanghai','上海','ZSPD','formal'],['Chengdu','成都','ZUUU','formal'],['Guangzhou','广州','ZGGG','formal'],['Shenzhen','深圳','ZGSZ','research_only'],['Wuhan','武汉','ZHHH','research_only'],['Chongqing','重庆','ZUCK','research_only'],['Jinan','济南','ZSJN','research_only'],['Qingdao','青岛','ZSQD','research_only'],['Zhengzhou','郑州','ZHCC','research_only']];
        const states=[['both_valid_equal','一致',0],['both_valid_delta','相差 1°C',1],['qxzx_only_valid','仅 QXZX 有效',null],['taf_only_valid','仅 TAF 有效',null],['both_waiting','均在等待',null],['source_anomaly','存在来源证据异常',null],['no_valid_evidence','无有效证据',null]];
        const longHash='a'.repeat(64),longPath='forecast/evidence/'.repeat(14)+'record.json';
        const configuredQxzx=new Set(['Beijing','Shanghai','Chengdu','Guangzhou','Shenzhen','Wuhan','Chongqing','Jinan','Zhengzhou']);
        function src(city,station,scope,key,date,extra={}){const unconfigured=key==='qxzx'&&!configuredQxzx.has(city),base={source_key:key,source:key==='taf'?'aviationweather_taf':unconfigured?null:'weatherol_'+city.toLowerCase(),source_label:key==='qxzx'?'QXZX':'TAF',source_role:key==='taf'?'independent_observation':scope==='formal'?'formal_paper_direction':'research_observation',city,station,target_date:date,city_scope:scope,policy_status:unconfigured?'policy_undetermined':'valid_d0',status:unconfigured?'policy_undetermined':'valid_d0',status_label:unconfigured?'当前政策不足以判定':'有效 D0',severity:unconfigured?'warning':'ok',reason_code:unconfigured?'qxzx_source_not_configured':'first_complete_d0_frozen',reason_text:unconfigured?'QXZX 机场来源尚未核验配置':'这是用于验证窄屏安全换行的较长中文状态原因，页面必须完整保留事实且不能撑破详情容器。',evidence_status:unconfigured?'policy_undetermined':'valid_d0',retention_state:unconfigured?'policy_undetermined':'retained',fetch_health:unconfigured?'not_configured':'ok',temperature_c:unconfigured?null:key==='qxzx'?31:30,forecast_bucket:unconfigured?null:key==='qxzx'?31:30,source_reported_at:unconfigured?null:key==='qxzx'?date+'T00:10:00+08:00':date+'T05:03:00+08:00',first_captured_at:unconfigured?null:key==='qxzx'?date+'T00:40:00+08:00':date+'T06:02:00+08:00',capture_delay_seconds:unconfigured?null:key==='qxzx'?1800:3540,frozen_at:unconfigured?null:date+'T06:02:00+08:00',latest_checked_at:unconfigured?null:date+'T08:30:00+08:00',grid_version:unconfigured?null:'g1',content_hash:unconfigured?null:longHash,expected_window_start:null,expected_window_end:null,grace_deadline:null,evaluation_at:date+'T08:30:00+08:00',last_attempt_at:null,last_attempt_status:unconfigured?'not_configured':'not_attributed',last_success_at:null,expected_attempt_seen:'unknown',policy_version:'d0-evidence-facts-v1',fetch:unconfigured?{status:'not_configured',requested_at:null,received_at:null,detail:'QXZX source is not configured'}:{status:'not_attributed',requested_at:null,received_at:null,detail:'fetch audit lacks target_date; no heuristic attribution'},limitations:unconfigured?['source_not_configured','qxzx_airport_aid_unverified']:[longPath],provenance:unconfigured?{kind:'source_configuration',configured:false,registry_status:null,immutable_frozen:false,detail_availability:'policy_undetermined',policy_version:'d0-evidence-facts-v1',source_table:null,registry_statuses:[],raw_reason:null,read_only:true}:{kind:'forecast_d0_registry',configured:true,registry_status:'valid_d0',immutable_frozen:true,source_path:longPath},...extra};return base}
        function panel(date,offset=1){return {schema:'d0_evidence.v2',ok:true,target_date:date,timezone:'Asia/Shanghai',page_updated_at:date+'T08:30:00+08:00',summary:{city_count:10,formal_city_count:4,research_only_city_count:6,qxzx_valid_city_count:9,taf_valid_city_count:10,both_valid_city_count:9,different_city_count:2,max_delta_c:1,anomalous_city_count:0,waiting_city_count:0},cities:places.map(([city,city_cn,station,scope],i)=>{const state=city==='Qingdao'?['taf_only_valid','仅 TAF 有效',null]:states[(offset+i)%7];return {city,city_label:city_cn,station,city_scope:scope,target_date:date,sources:[src(city,station,scope,'qxzx',date),src(city,station,scope,'taf',date)],comparison:{status:state[0],status_label:state[1],severity:state[0]==='source_anomaly'?'error':'neutral',delta_c:state[2]}}}),retention:{availability:'available'},provenance:{policy_version:'d0-evidence-facts-v1'}}}
        const legacyPanel=panel;
        function placesFor(date){return places.filter(x=>date<({Jinan:'2026-08-22',Qingdao:'2026-08-22',Zhengzhou:'2026-08-30'}[x[0]]||'9999-12-31'))}
        panel=function(date,offset=1){const result=legacyPanel(date,offset),scoped=new Set(placesFor(date).map(x=>x[0]));result.cities=result.cities.filter(x=>scoped.has(x.city));result.summary.city_count=result.cities.length;result.summary.research_only_city_count=result.cities.filter(x=>x.city_scope==='research_only').length;result.summary.qxzx_valid_city_count=result.cities.filter(x=>configuredQxzx.has(x.city)).length;result.summary.taf_valid_city_count=result.cities.length;result.summary.both_valid_city_count=result.summary.qxzx_valid_city_count;return result}
        function panelV1(date){const x=panel(date);x.schema='d0_evidence.v1';x.cities=x.cities.slice(0,5).map(row=>{const y=structuredClone(row);delete y.city_scope;delete y.target_date;y.sources.forEach(source=>delete source.city_scope);return y});x.summary={...x.summary,city_count:5};delete x.summary.formal_city_count;delete x.summary.research_only_city_count;return x}
        function detail(city,date){const place=places.find(x=>x[0]===city)||places[0],station=place[2],scope=place[3],unconfigured=!configuredQxzx.has(city);return {schema:'d0_evidence.v2',ok:true,city,city_label:place[1],station,city_scope:scope,target_date:date,sources:[src(city,station,scope,'qxzx',date),src(city,station,scope,'taf',date)],versions:[{source:'aviationweather_taf',city,station,target_date:date,temperature_c:30,source_reported_at:date+'T05:03:00+08:00',content_hash:longHash}],raw_evidence:[{source_key:'qxzx',availability:unconfigured?'not_configured':'hash_only',content_hash:unconfigured?null:longHash},{source_key:'taf',availability:'hash_only',content_hash:longHash}],comparison:{status:unconfigured?'taf_only_valid':'both_valid_delta',status_label:unconfigured?'仅 TAF 有效':'相差 1°C',severity:'neutral',delta_c:unconfigured?null:1},resolution:{status:'unavailable',quality_code:'no_yes_resolution',market_id:null,bucket_label:null,yes_resolved:null,forecast_bucket_delta_c:null,limitations:['no_yes_resolution']},validation:{kind:'mechanical_fact_delta',forecast_bucket_delta_c:null,model_conclusion:null},research:{availability:'unsupported_version',reasons:['factor_version_not_supported',longPath],provenance:{schema_version:'facts-only-v2',snapshot_id:null,factor_version:null,path_label_version:'path-label-v1',stratum_version:null,information_cutoff:null,generated_at:null,source_tables:['wp3_factor_snapshots'],read_only:true},model_output:{probability:.91},probability:'BANNED_PROBABILITY',candidate_mapping:'BANNED_CANDIDATE',path_label:'BANNED_PATH',entry:'BANNED_ENTRY',stop:'BANNED_STOP',strategy_direction:'BANNED_STRATEGY',trading_advice:'BANNED_ADVICE'},availability:{detail:'available',fetch_timeline:'not_attributed',raw_evidence:'hash_only'},provenance:{read_only:true,source_path:longPath}}}
        (async()=>{const browser=await chromium.launch({headless:true,executablePath});const page=await browser.newPage({viewport:{width:1440,height:900}});page.setDefaultTimeout(5000);
        await page.addInitScript(()=>{window.__calls=[];window.__resolve={};const snapshot={now:'2026-08-09T08:00:00+08:00',markets:[],forecasts:[],validations:[],actuals:[],services:{}};const pending=(key,call)=>{window.__calls.push(call);return new Promise(r=>window.__resolve[key]=r)};window.pywebview={api:{snapshot:async()=>snapshot,history:async()=>[],depth:async()=>[],d0_evidence_panel:d=>pending('v1p:'+d,['panel_v1',d]),d0_evidence_detail:(c,d)=>pending('v1d:'+c+':'+d,['detail_v1',c,d]),d0_evidence_panel_v2:d=>pending('p:'+d,['panel_v2',d]),d0_evidence_detail_v2:(c,d)=>pending('d:'+c+':'+d,['detail_v2',c,d])}}});
        await page.goto(url);await page.click('[data-tab="forecast"]');await page.waitForFunction(()=>window.__calls.length);const firstCall=await page.evaluate(()=>window.__calls[0]);if(firstCall[0]==='panel_v2')await page.evaluate(x=>window.__resolve['p:2026-08-09'](x),panel('2026-08-09'));else await page.evaluate(x=>window.__resolve['v1p:2026-08-09'](x),panelV1('2026-08-09'));await page.waitForFunction(()=>document.querySelectorAll('#d0Rows tr[data-city]').length||document.querySelector('#d0ContractError'));const migrationProbe=await page.evaluate(()=>({firstCall:window.__calls[0][0],rows:document.querySelectorAll('#d0Rows tr[data-city]').length,scopes:document.querySelectorAll('#d0Rows [data-city-scope]').length,contractError:!!document.querySelector('#d0ContractError')}));assert.deepEqual(migrationProbe,{firstCall:'panel_v2',rows:10,scopes:10,contractError:false});
        assert.equal(await page.textContent('#forecastPage .sectionTitle'),'D0 证据状态面板');assert.equal(await page.locator('#d0Rows tr[data-city]').count(),10);assert.equal(await page.locator('#d0Rows [data-source="qxzx"]').count(),10);assert.equal(await page.locator('#d0Rows [data-source="taf"]').count(),10);assert.deepEqual(await page.locator('#d0Rows tr[data-city]').evaluateAll(rows=>rows.map(x=>x.dataset.city)),places.map(x=>x[0]));assert.equal(await page.locator('#d0Rows [data-city-scope="formal"]').count(),4);assert.equal(await page.locator('#d0Rows [data-city-scope="research_only"]').count(),6);assert.equal(await page.getByText('仅研究',{exact:true}).count(),6);assert.match(await page.textContent('#d0Summary'),/十城总数[\s\S]*10[\s\S]*正式城市[\s\S]*4[\s\S]*仅研究城市[\s\S]*6[\s\S]*QXZX 有效[\s\S]*9[\s\S]*页面更新[\s\S]*08:30/);assert.match(await page.textContent('[data-city="Beijing"] [data-source="qxzx"]'),/来源时间（中国时间）[\s\S]*00:10/);for(const city of ['Wuhan','Chongqing','Jinan','Zhengzhou']){const qx=await page.textContent(`[data-city="${city}"] [data-source="qxzx"]`);assert.match(qx,new RegExp(`有效 D0[\\s\\S]*weatherol_${city.toLowerCase()}`));assert.equal(await page.getAttribute(`[data-city="${city}"] [data-source="qxzx"]`,'data-policy-status'),'valid_d0')}const qx=await page.textContent('[data-city="Qingdao"] [data-source="qxzx"]');assert.match(qx,/—[\s\S]*当前政策不足以判定[\s\S]*not_configured[\s\S]*qxzx_source_not_configured/);assert.doesNotMatch(qx,/0\.0°C|weatherol_qingdao|有效 D0/);assert.equal(await page.getAttribute('[data-city="Qingdao"] [data-source="qxzx"]','data-policy-status'),'policy_undetermined');assert.equal(await page.getAttribute('[data-city="Qingdao"] [data-comparison]','data-comparison'),'taf_only_valid')
        // An invalid date is itself a navigation attempt: it must cancel panel/detail work and clear facts.
        await page.click('[data-city="Beijing"] [data-detail-toggle]');await page.evaluate(x=>window.__resolve['d:Beijing:2026-08-09'](x),detail('Beijing','2026-08-09'));await page.waitForSelector('#d0Detail');
        await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-24')});await page.evaluate(()=>{window.d0EvidencePanel.loadDate('')});await page.waitForSelector('#d0Error');assert.equal(await page.locator('#d0Detail').count(),0);assert.equal(await page.locator('#d0Rows tr[data-city]').count(),0);await page.evaluate(x=>window.__resolve['p:2026-08-24'](x),panel('2026-08-24'));await page.waitForTimeout(20);assert.equal(await page.locator('#d0Rows tr[data-city]').count(),0);assert.match(await page.textContent('#d0Error'),/invalid_target_date/);
        const callsBeforeBadDate=await page.evaluate(()=>window.__calls.length);await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-02-30')});await page.waitForSelector('#d0Error');assert.equal(await page.evaluate(()=>window.__calls.length),callsBeforeBadDate);assert.equal(await page.locator('#d0Rows tr[data-city]').count(),0);assert.match(await page.textContent('#d0Error'),/invalid_target_date/);
        await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-13-01')});await page.waitForSelector('#d0Error');assert.equal(await page.evaluate(()=>window.__calls.length),callsBeforeBadDate);assert.equal(await page.locator('#d0Rows tr[data-city]').count(),0);assert.match(await page.textContent('#d0Error'),/invalid_target_date/);
        await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-25')});await page.evaluate(x=>window.__resolve['p:2026-08-25'](x),panel('2026-08-25'));await page.waitForSelector('#d0Rows tr[data-city="Beijing"]');
        // A malformed successful DTO is a contract failure, never missing business evidence.
        const corruptions=[
          x=>x.schema='d0_evidence.v1',
          x=>x.cities.pop(),
          x=>x.cities.push(structuredClone(x.cities[0])),
          x=>x.cities[0].city='Unknown',
          x=>x.cities[0].city_label='南京',
          x=>[x.cities[0],x.cities[1]]=[x.cities[1],x.cities[0]],
          x=>x.cities[0].station='ZZZZ',
          x=>x.cities[0].target_date='2026-08-01',
          x=>x.cities[0].city_scope='research_only',
          x=>x.cities[4].city_scope='unknown_scope',
          x=>delete x.cities[0].city_scope,
          x=>x.cities[0].sources=x.cities[0].sources.filter(s=>s.source_key!=='qxzx'),
          x=>x.cities[0].sources=x.cities[0].sources.filter(s=>s.source_key!=='taf'),
          x=>x.cities[0].sources.push(structuredClone(x.cities[0].sources[0])),
          x=>x.cities[0].sources.reverse(),
          x=>x.cities[0].sources[0].target_date='2026-08-01',
          x=>x.cities[0].sources[0].city_scope='research_only',
          x=>x.cities[0].sources[0].station='ZZZZ',
          x=>x.cities[0].sources[0].city='Shanghai',
          x=>delete x.cities[0].sources[0].reason_code,
          x=>x.cities[0].sources[0].provenance.configured=false,
          x=>x.cities[8].sources[0].source='weatherol_wuhan',
          x=>x.cities[8].sources[0].provenance.configured=true,
          x=>delete x.cities[0].comparison,
          x=>delete x.cities[0].sources[0].policy_status,
          x=>delete x.cities[0].sources[0].evidence_status,
          x=>delete x.cities[0].sources[0].retention_state,
          x=>{delete x.cities[0].sources[0].policy_status;delete x.cities[0].sources[0].status},
          x=>x.cities[0].comparison=null,
          x=>x.cities[0].comparison={},
          x=>x.cities[0].comparison=[],
          x=>x.cities[0].comparison.status='',
          x=>x.cities[0].comparison.status='unknown_comparison',
          x=>delete x.summary.formal_city_count,
          x=>x.summary.city_count=5
        ];
        for(let i=0;i<corruptions.length;i++){const d=new Date(Date.UTC(2026,6,i+1)).toISOString().slice(0,10),x=panel(d);corruptions[i](x);await page.evaluate(v=>{window.d0EvidencePanel.loadDate(v)},d);await page.evaluate(({d,x})=>window.__resolve['p:'+d](x),{d,x});await page.waitForSelector('#d0ContractError');assert.equal(await page.locator('#d0Rows tr[data-city]').count(),0);assert.equal((await page.textContent('#d0Summary')).trim(),'')}
        await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-10')});await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-11')});await page.evaluate(x=>window.__resolve['p:2026-08-11'](x),panel('2026-08-11',2));await page.waitForFunction(()=>document.querySelector('#d0TargetDate').value==='2026-08-11'&&!document.querySelector('#d0Loading'));await page.evaluate(x=>window.__resolve['p:2026-08-10'](x),panel('2026-08-10'));await page.waitForTimeout(20);assert.match(await page.textContent('#d0Summary'),/2026-08-11/);
        for(let i=0;i<7;i++){const d=`2026-08-${12+i}`;await page.evaluate(x=>{window.d0EvidencePanel.loadDate(x)},d);await page.evaluate(({d,x})=>window.__resolve['p:'+d](x),{d,x:panel(d,i)});await page.waitForFunction(x=>document.querySelector('#d0TargetDate').value===x&&!document.querySelector('#d0Loading'),d);assert.match(await page.textContent('[data-city="Beijing"] [data-comparison]'),new RegExp(states[i][1]))}
        const overdueFields=[['publication_overdue','waiting'],['waiting','publication_overdue'],['publication_overdue','publication_overdue']];let overdueDay=1;for(const sourceIndex of [0,1])for(const [policy,status] of overdueFields){const d=`2026-11-${String(overdueDay++).padStart(2,'0')}`,bad=panel(d);bad.cities[0].sources[sourceIndex].policy_status=policy;bad.cities[0].sources[sourceIndex].status=status;await page.evaluate(v=>{window.d0EvidencePanel.loadDate(v)},d);await page.evaluate(({d,bad})=>window.__resolve['p:'+d](bad),{d,bad});await page.waitForSelector('#d0ContractError');assert.match(await page.textContent('#d0ContractError'),/接口契约异常[\s\S]*publication_overdue/);assert.equal(await page.locator('#d0Rows tr[data-city]').count(),0);assert.equal((await page.textContent('#d0Summary')).trim(),'');assert.equal(await page.locator('[data-policy-status="publication_overdue"]').count(),0)}
        await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-21')});await page.evaluate(x=>window.__resolve['p:2026-08-21'](x),panel('2026-08-21'));await page.waitForFunction(()=>!document.querySelector('#d0Loading'));
        // Closing or changing date while detail is pending must invalidate its late response.
        await page.click('[data-city="Wuhan"] [data-detail-toggle]');assert.deepEqual(await page.evaluate(()=>window.__calls.at(-1)),['detail_v2','Wuhan','2026-08-21']);await page.click('#d0Detail [data-detail-close]');await page.evaluate(x=>window.__resolve['d:Wuhan:2026-08-21'](x),detail('Wuhan','2026-08-21'));await page.waitForTimeout(20);assert.equal(await page.locator('#d0Detail').count(),0);
        await page.click('[data-city="Wuhan"] [data-detail-toggle]');await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-23')});await page.evaluate(x=>window.__resolve['p:2026-08-23'](x),panel('2026-08-23'));await page.waitForSelector('#d0Rows tr[data-city="Wuhan"]');await page.evaluate(x=>window.__resolve['d:Wuhan:2026-08-21'](x),detail('Wuhan','2026-08-21'));await page.waitForTimeout(20);assert.equal(await page.locator('#d0Detail').count(),0);await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-21')});await page.evaluate(x=>window.__resolve['p:2026-08-21'](x),panel('2026-08-21'));await page.waitForSelector('#d0Rows tr[data-city="Wuhan"]');
        const badDetails=[detail('Beijing','2026-08-21'),detail('Shanghai','2026-08-20'),detail('Shanghai','2026-08-21'),detail('Shanghai','2026-08-21')];badDetails[0].city='Beijing';badDetails[1].target_date='2026-08-20';badDetails[2].sources[0].target_date='2026-08-20';badDetails[3].sources=badDetails[3].sources.filter(x=>x.source_key!=='qxzx');
        const detailMutations=[x=>x.schema='d0_evidence.v1',x=>x.city_label='南京',x=>{x.sources[0].policy_status='publication_overdue';x.sources[0].status='waiting'},x=>{x.sources[0].policy_status='waiting';x.sources[0].status='publication_overdue'},x=>{x.sources[1].policy_status='publication_overdue';x.sources[1].status='waiting'},x=>{x.sources[1].policy_status='waiting';x.sources[1].status='publication_overdue'},x=>delete x.sources[0].policy_status,x=>delete x.sources[0].evidence_status,x=>delete x.sources[0].retention_state,x=>{delete x.sources[0].policy_status;delete x.sources[0].status},x=>delete x.sources[0].reason_code,x=>x.sources[0].provenance.configured=false,x=>x.station='ZZZZ',x=>x.city_scope='research_only',x=>x.sources[0].city_scope='research_only',x=>x.sources[0].station='ZZZZ',x=>x.versions[0].city='Beijing',x=>x.versions=null,x=>x.raw_evidence=x.raw_evidence.slice(0,1),x=>x.raw_evidence[0].source_key='taf',x=>x.raw_evidence[0].content_hash='b'.repeat(64),x=>delete x.resolution,x=>x.resolution={},x=>x.resolution={status:'resolved',quality_code:null,market_id:null,bucket_label:null,yes_resolved:false,forecast_bucket_delta_c:null,limitations:[]},x=>x.resolution={status:'unavailable',quality_code:null,market_id:null,bucket_label:null,yes_resolved:null,forecast_bucket_delta_c:null,limitations:[]},x=>x.resolution.limitations=[],x=>delete x.validation,x=>x.validation={},x=>x.validation.model_conclusion='BANNED_BUY',x=>delete x.research,x=>delete x.availability,x=>x.comparison=null,x=>x.comparison={},x=>x.comparison=[],x=>x.comparison.status='',x=>x.comparison.status='unknown_comparison'];for(const mutate of detailMutations){const x=detail('Shanghai','2026-08-21');mutate(x);badDetails.push(x)}
        for(const x of badDetails){await page.click('[data-city="Shanghai"] [data-detail-toggle]');await page.evaluate(v=>window.__resolve['d:Shanghai:2026-08-21'](v),x);await page.waitForSelector('#d0DetailContractError');assert.doesNotMatch(await page.textContent('#d0Detail'),/31\.0°C|有效 D0|首份完整 D0 已冻结|aaaaaaaaaaaaaaaa/);assert.equal(await page.locator('#d0Rows tr[data-city]').count(),10)}
        const unconfiguredDetailMutations=[
          x=>x.versions.push({source:null,city:'Qingdao',station:'ZSQD',target_date:'2026-08-21',temperature_c:99,source_reported_at:'2026-08-21T23:59:00+08:00',content_hash:'f'.repeat(64)}),
          x=>{x.raw_evidence[0].availability='hash_only';x.raw_evidence[0].content_hash='f'.repeat(64)},
          x=>x.sources[0].provenance.configured=true
        ];
        for(const mutate of unconfiguredDetailMutations){const x=detail('Qingdao','2026-08-21');mutate(x);await page.click('[data-city="Qingdao"] [data-detail-toggle]');await page.evaluate(v=>window.__resolve['d:Qingdao:2026-08-21'](v),x);await page.waitForSelector('#d0DetailContractError');const body=await page.textContent('#d0Detail');assert.doesNotMatch(body,/99\.0°C|23:59|ffffffffffffffff|BANNED_BUY/);assert.equal(await page.locator('#d0Rows tr[data-city]').count(),10)}
        const resolutionCases=[
          [x=>x.resolution={status:'resolved',quality_code:null,market_id:'jn-yes',bucket_label:'37°C',yes_resolved:true,forecast_bucket_delta_c:null,limitations:[]},/唯一 YES：[\s\S]*37°C[\s\S]*事实差值 —/],
          [x=>{x.resolution={status:'resolved',quality_code:null,market_id:'jn-number',bucket_label:'38°C',yes_resolved:true,forecast_bucket_delta_c:1,limitations:[]};x.validation.forecast_bucket_delta_c=1},/唯一 YES：[\s\S]*38°C[\s\S]*事实差值 1°C[\s\S]*validation：[\s\S]*1°C/],
          [x=>x.resolution={status:'unavailable',quality_code:'no_yes_resolution',market_id:null,bucket_label:null,yes_resolved:null,forecast_bucket_delta_c:null,limitations:['no_yes_resolution']},/尚无可确认的唯一结算桶/],
          [x=>x.resolution={status:'unavailable',quality_code:'conflicting_yes_resolutions',market_id:null,bucket_label:null,yes_resolved:null,forecast_bucket_delta_c:null,limitations:['conflicting_yes_resolutions']},/结算事实存在冲突/],
          [x=>x.resolution={status:'resolved',quality_code:null,market_id:'jn-unknown',bucket_label:'unknown bucket',yes_resolved:true,forecast_bucket_delta_c:null,limitations:['unparseable_bucket_label']},/桶标签无法解析[\s\S]*不展示伪造差值/],
          [x=>x.resolution={status:'resolved',quality_code:null,market_id:'jn-null-label',bucket_label:null,yes_resolved:true,forecast_bucket_delta_c:null,limitations:['unparseable_bucket_label']},/结算桶 —[\s\S]*桶标签无法解析[\s\S]*不展示伪造差值/]
        ];
        for(const [mutate,expected] of resolutionCases){const x=detail('Jinan','2026-08-21');mutate(x);await page.click('[data-city="Jinan"] [data-detail-toggle]');await page.evaluate(v=>window.__resolve['d:Jinan:2026-08-21'](v),x);await page.waitForSelector('#d0Detail[data-city="Jinan"]');const body=await page.textContent('#d0Detail');assert.match(body,expected);assert.doesNotMatch(body,/BANNED_|市场永久不存在|事实差值 0/);await page.click('[data-detail-close]')}
        await page.click('[data-city="Beijing"] [data-detail-toggle]');await page.click('[data-city="Shanghai"] [data-detail-toggle]');assert.deepEqual(await page.evaluate(()=>window.__calls.at(-1)),['detail_v2','Shanghai','2026-08-21']);await page.evaluate(x=>window.__resolve['d:Shanghai:2026-08-21'](x),detail('Shanghai','2026-08-21'));await page.waitForSelector('#d0Detail[data-city="Shanghai"]');await page.evaluate(x=>window.__resolve['d:Beijing:2026-08-21'](x),detail('Beijing','2026-08-21'));await page.waitForTimeout(20);const dt=await page.textContent('#d0Detail');assert.match(dt,/正式[\s\S]*来源发布时间[\s\S]*首次捕获[\s\S]*采集延迟[\s\S]*证据状态[\s\S]*保留状态/);assert.match(dt,/尚无可确认的唯一结算桶[\s\S]*unsupported_version[\s\S]*factor_version_not_supported[\s\S]*path_label_version/);assert.doesNotMatch(dt,/91%|交易建议|策略方向|candidate_mapping|"path_label":|BANNED_PATH|BANNED_ENTRY|BANNED_STOP|收益/);await page.click('[data-detail-close]');assert.equal(await page.locator('#d0Detail').count(),0);
        await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-22')});await page.evaluate(()=>window.__resolve['p:2026-08-22']({schema:'d0_evidence.v2',ok:false,error:{code:'data_temporarily_unavailable',message:'busy',retryable:true}}));await page.waitForSelector('#d0Error');assert.equal(await page.locator('#d0Rows tr[data-city]').count(),0);await page.click('#d0Retry');assert.deepEqual(await page.evaluate(()=>window.__calls.at(-1)),['panel_v2','2026-08-22']);await page.evaluate(x=>window.__resolve['p:2026-08-22'](x),panel('2026-08-22'));await page.waitForSelector('#d0Rows tr[data-city="Zhengzhou"]');assert.equal(await page.locator('#d0Rows tr[data-city]').count(),8);assert.equal(await page.locator('[data-city="Jinan"], [data-city="Qingdao"]').count(),0);assert.match(await page.textContent('#d0Summary'),/八城总数[\s\S]*8[\s\S]*仅研究城市[\s\S]*4/);await page.evaluate(()=>{window.d0EvidencePanel.loadDate('2026-08-21')});await page.evaluate(x=>window.__resolve['p:2026-08-21'](x),panel('2026-08-21'));await page.waitForSelector('#d0Rows tr[data-city="Qingdao"]');await page.click('[data-city="Qingdao"] [data-detail-toggle]');await page.evaluate(x=>window.__resolve['d:Qingdao:2026-08-21'](x),detail('Qingdao','2026-08-21'));await page.waitForSelector('#d0Detail[data-city="Qingdao"][data-city-scope="research_only"]');assert.match(await page.textContent('#d0Detail'),/仅研究[\s\S]*QXZX[\s\S]*not_configured[\s\S]*qxzx_source_not_configured/);
        for(const width of [1440,900,390]){await page.setViewportSize({width,height:1300});const x=await page.evaluate(()=>{const q=document.querySelector('[data-city="Qingdao"] td:nth-child(2)'),t=document.querySelector('[data-city="Qingdao"] td:nth-child(3)'),qb=q.getBoundingClientRect(),tb=t.getBoundingClientRect(),page=document.querySelector('#forecastPage'),root=document.documentElement,cards=[...document.querySelectorAll('.d0DetailCard')],rows=[...document.querySelectorAll('#d0Rows tr[data-city]')],scope=document.querySelector('[data-city="Qingdao"] .d0Scope'),buttons=[document.querySelector('#d0Prev'),document.querySelector('#d0TargetDate'),document.querySelector('#d0Next'),document.querySelector('[data-detail-close]')],neighbors=['marketPage','health','city','buckets','actualBand','chart','asks','bids','biasPage','biasRows'].every(id=>document.getElementById(id));return {other:neighbors,nonempty:rows.length===10&&document.querySelector('#d0Summary').textContent.trim().length>0&&cards.length>0&&scope?.textContent.includes('仅研究'),sources:document.querySelectorAll('#d0Rows [data-source="qxzx"]').length===10&&document.querySelectorAll('#d0Rows [data-source="taf"]').length===10,overflow:page.scrollWidth>page.clientWidth+1||root.scrollWidth>root.clientWidth+1,cellOverflow:[q,t].some(e=>e.scrollWidth>e.clientWidth+1),cardOverflow:cards.some(e=>e.scrollWidth>e.clientWidth+1),rowOverflow:rows.some(e=>e.getBoundingClientRect().right>page.getBoundingClientRect().right+1),overlap:!(qb.right<=tb.left||tb.right<=qb.left||qb.bottom<=tb.top||tb.bottom<=qb.top),buttons:buttons.every(e=>{const r=e?.getBoundingClientRect();return e&&!e.disabled&&r.width>0&&r.height>0}),display:getComputedStyle(document.querySelector('#d0Table')).display}});assert.equal(x.other&&x.nonempty&&x.sources&&x.buttons,true);assert.equal(x.overflow||x.cellOverflow||x.cardOverflow||x.rowOverflow||x.overlap,false);if(width===390)assert.equal(x.display,'block')}
        // Non-contract top-level aliases must never shadow the validated sources array.
        const aliasCases=[
          ['2026-10-01','qxzx',{policy_status:'publication_overdue',status:'publication_overdue',status_label:'publication_overdue'}],
          ['2026-10-02','taf',{policy_status:'publication_overdue',status:'publication_overdue',status_label:'publication_overdue'}],
          ['2026-10-03','qxzx',{status:'waiting'}]
        ];
        for(const [d,key,alias] of aliasCases){const x=panel(d);x.cities[0][key]={...alias,temperature_c:88,source_reported_at:d+'T23:59:00+08:00',content_hash:'z'.repeat(64),provenance:{shadow_alias:true},limitations:['shadow-alias-must-not-render']};await page.evaluate(v=>{window.d0EvidencePanel.loadDate(v)},d);await page.evaluate(({d,x})=>window.__resolve['p:'+d](x),{d,x});await page.waitForFunction(v=>document.querySelector('#d0TargetDate').value===v&&!document.querySelector('#d0Loading'),d);const slot=await page.textContent(`[data-city="Beijing"] [data-source="${key}"]`);assert.doesNotMatch(slot,/publication_overdue|88\.0°C|23:59|shadow-alias/);assert.match(slot,key==='qxzx'?/31\.0°C[\s\S]*00:10/:/30\.0°C[\s\S]*05:03/);assert.equal(await page.locator('#d0ContractError').count(),0)}
        // T00 adversarial probes aggregate every penetration so one early failure cannot hide another.
        await page.setViewportSize({width:1440,height:1000});
        const penetrations={unconfigured:[],delta:[],research:[]};
        const recordDetailProbe=async(group,name,city,date,payload,forbidden=[])=>{await page.click(`[data-city="${city}"] [data-detail-toggle]`);await page.evaluate(({city,date,payload})=>window.__resolve[`d:${city}:${date}`](payload),{city,date,payload});await page.waitForFunction(()=>document.querySelector('#d0DetailContractError')||document.querySelector('#d0Detail .d0DetailGrid'));const rejected=!!(await page.$('#d0DetailContractError')),body=await page.textContent('#d0Detail'),rows=await page.locator('#d0Rows tr[data-city]').count(),leaked=forbidden.filter(value=>body.includes(value));if(!rejected||rows!==10||leaked.length)penetrations[group].push({name,rejected,rows,leaked});await page.click('#d0Detail [data-detail-close]')};
        const mainDate='2026-08-19',badMain=panel(mainDate),mainQx=badMain.cities[8].sources[0];mainQx.status_label='有效 D0';mainQx.reason_text='首份完整 D0 已冻结';mainQx.provenance.registry_status='valid_d0';mainQx.provenance.immutable_frozen=true;await page.evaluate(v=>{window.d0EvidencePanel.loadDate(v)},mainDate);await page.evaluate(({mainDate,badMain})=>window.__resolve['p:'+mainDate](badMain),{mainDate,badMain});await page.waitForFunction(()=>document.querySelector('#d0ContractError')||document.querySelectorAll('#d0Rows tr[data-city]').length);const mainRejected=!!(await page.$('#d0ContractError')),mainRows=await page.locator('#d0Rows tr[data-city]').count(),mainBody=await page.textContent('#forecastPage');if(!mainRejected||mainRows!==0||mainBody.includes('首份完整 D0 已冻结'))penetrations.unconfigured.push({name:'main_source_semantics',rejected:mainRejected,rows:mainRows,leaked:mainBody.includes('首份完整 D0 已冻结')});
        const probeDate='2026-08-20';await page.evaluate(v=>{window.d0EvidencePanel.loadDate(v)},probeDate);await page.evaluate(({probeDate,payload})=>window.__resolve['p:'+probeDate](payload),{probeDate,payload:panel(probeDate)});await page.waitForSelector('#d0Rows tr[data-city="Qingdao"]');
        const unconfiguredAttacks=[
          ['raw_temperature',x=>x.raw_evidence[0].temperature_c=99,['"temperature_c":99']],
          ['raw_source_time',x=>x.raw_evidence[0].source_reported_at=probeDate+'T23:59:00+08:00',['23:59']],
          ['raw_extra_hash',x=>x.raw_evidence[0].evidence_hash='forged-raw-hash-'+('f'.repeat(64)),['forged-raw-hash']],
          ['source_status_label',x=>x.sources[0].status_label='有效 D0',['有效 D0']],
          ['source_reason_text',x=>x.sources[0].reason_text='首份完整 D0 已冻结',['首份完整 D0 已冻结']],
          ['source_provenance',x=>{x.sources[0].provenance.registry_status='valid_d0';x.sources[0].provenance.immutable_frozen=true},['"registry_status":"valid_d0"','"immutable_frozen":true']]
        ];
        for(const [name,mutate,forbidden] of unconfiguredAttacks){const x=detail('Qingdao',probeDate);mutate(x);await recordDetailProbe('unconfigured',name,'Qingdao',probeDate,x,forbidden)}
        const resolvedDelta=(x,resolutionValue,validationValue)=>{x.resolution={status:'resolved',quality_code:null,market_id:'delta-native-type',bucket_label:'37°C',yes_resolved:true,forecast_bucket_delta_c:resolutionValue,limitations:[]};x.validation.forecast_bucket_delta_c=validationValue};
        const deltaAttacks=[
          ['native_true_pair',x=>resolvedDelta(x,true,true),['true°C']],
          ['native_false_pair',x=>resolvedDelta(x,false,false),['false°C']],
          ['numeric_string_pair',x=>resolvedDelta(x,'42','42'),['事实差值 42°C']],
          ['blank_string_pair',x=>resolvedDelta(x,'   ','   '),[]],
          ['array_pair',x=>{const value=[];resolvedDelta(x,value,value)},[]],
          ['object_pair',x=>{const value={};resolvedDelta(x,value,value)},[]],
          ['resolution_null_validation_42',x=>{x.resolution={status:'resolved',quality_code:null,market_id:'delta-null',bucket_label:'37°C',yes_resolved:true,forecast_bucket_delta_c:null,limitations:[]};x.validation.forecast_bucket_delta_c=42},['42°C']],
          ['resolution_42_validation_null',x=>{x.resolution={status:'resolved',quality_code:null,market_id:'delta-42',bucket_label:'42°C',yes_resolved:true,forecast_bucket_delta_c:42,limitations:[]};x.validation.forecast_bucket_delta_c=null},['42°C']],
          ['resolution_1_validation_2',x=>{x.resolution={status:'resolved',quality_code:null,market_id:'delta-mismatch',bucket_label:'38°C',yes_resolved:true,forecast_bucket_delta_c:1,limitations:[]};x.validation.forecast_bucket_delta_c=2},['2°C']],
          ['unavailable_validation_43',x=>x.validation.forecast_bucket_delta_c=43,['43°C']],
          ['unparseable_validation_44',x=>{x.resolution={status:'resolved',quality_code:null,market_id:'delta-unparseable',bucket_label:null,yes_resolved:true,forecast_bucket_delta_c:null,limitations:['unparseable_bucket_label']};x.validation.forecast_bucket_delta_c=44},['44°C']]
        ];
        for(const [name,mutate,forbidden] of deltaAttacks){const x=detail('Shanghai',probeDate);mutate(x);await recordDetailProbe('delta',name,'Shanghai',probeDate,x,forbidden)}
        const researchAttacks=[
          ['unknown_availability',x=>x.research.availability='91% BUY',['91% BUY']],
          ['provenance_probability',x=>x.research.provenance.probability='BANNED_PROBABILITY',['BANNED_PROBABILITY']],
          ['provenance_strategy',x=>x.research.provenance.strategy_direction='BANNED_BUY',['BANNED_BUY']],
          ['provenance_entry_stop',x=>{x.research.provenance.entry='BANNED_ENTRY';x.research.provenance.stop='BANNED_STOP'},['BANNED_ENTRY','BANNED_STOP']],
          ['provenance_orders_positions_profit',x=>{x.research.provenance.orders=['BANNED_ORDER'];x.research.provenance.positions=['BANNED_POSITION'];x.research.provenance.profit='BANNED_PROFIT'},['BANNED_ORDER','BANNED_POSITION','BANNED_PROFIT']],
          ['provenance_path_label',x=>x.research.provenance.path_label='BANNED_PATH',['BANNED_PATH']],
          ['object_reason',x=>x.research.reasons=[{probability:'BANNED_REASON_OBJECT'}],['BANNED_REASON_OBJECT']]
        ];
        for(const [name,mutate,forbidden] of researchAttacks){const x=detail('Shanghai',probeDate);mutate(x);await recordDetailProbe('research',name,'Shanghai',probeDate,x,forbidden)}
        assert.deepEqual(penetrations,{unconfigured:[],delta:[],research:[]},`T00 penetration evidence: ${JSON.stringify(penetrations)}`);
        await browser.close();console.log('DOM contract passed')})().catch(e=>{console.error(e.stack||e);process.exit(1)});
        """)
        env = os.environ.copy()
        env["NODE_PATH"] = str(modules)
        env["D0_TEST_URL"] = (ROOT / "ui" / "live.html").as_uri()
        env["D0_BROWSER_PATH"] = str(browser)
        with tempfile.TemporaryDirectory(prefix="d0-panel-dom-") as temp_dir:
            script_path = Path(temp_dir) / "d0_panel_dom.js"
            script_path.write_text(script, encoding="utf-8")
            try:
                result = subprocess.run(
                    [str(node), str(script_path)], cwd=ROOT, env=env, text=True,
                    encoding="utf-8", capture_output=True, timeout=60,
                )
            except subprocess.TimeoutExpired as exc:
                self.fail(
                    f"DOM test timed out\nstdout:\n{exc.stdout}\nstderr:\n{exc.stderr}"
                )
        self.assertEqual(result.returncode, 0, f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}")


if __name__ == "__main__":
    unittest.main()
