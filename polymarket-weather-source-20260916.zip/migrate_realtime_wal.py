"""Offline, content-preserving journal-mode migration for realtime.sqlite3.

This tool intentionally does *not* rebuild, copy, prune, vacuum, or alter
tables.  It exists to switch the already authoritative realtime store from
DELETE to WAL after all local readers and the sole quote writer are stopped.
The caller must restart services only after its postflight passes.
"""
from __future__ import annotations

import argparse
import json
import sqlite3
from contextlib import closing
from pathlib import Path

from db_paths import REALTIME_DB


def _table_counts(db: sqlite3.Connection) -> dict[str, int]:
    tables = [row[0] for row in db.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    )]
    return {name: int(db.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0]) for name in tables}


def inspect(database: Path) -> dict:
    if not database.exists():
        raise RuntimeError(f"missing database: {database}")
    with closing(sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=10)) as db:
        integrity = str(db.execute("PRAGMA integrity_check").fetchone()[0])
        journal = str(db.execute("PRAGMA journal_mode").fetchone()[0]).lower()
        counts = _table_counts(db)
    return {"path": str(database), "integrity": integrity, "journal_mode": journal,
            "size_bytes": database.stat().st_size, "table_counts": counts}


def migrate(database: Path) -> dict:
    """Switch journal mode only and fail if any pre/post invariant changes."""
    before = inspect(database)
    if before["integrity"] != "ok":
        raise RuntimeError(f"preflight integrity failed: {before['integrity']}")
    if before["journal_mode"] == "wal":
        return {"changed": False, "before": before, "after": before}
    with closing(sqlite3.connect(database, timeout=10)) as db:
        db.execute("PRAGMA busy_timeout=10000")
        mode = str(db.execute("PRAGMA journal_mode=WAL").fetchone()[0]).lower()
        if mode != "wal":
            raise RuntimeError(f"WAL switch refused: sqlite returned {mode}")
    after = inspect(database)
    if after["integrity"] != "ok":
        raise RuntimeError(f"postflight integrity failed: {after['integrity']}")
    if after["journal_mode"] != "wal":
        raise RuntimeError(f"postflight journal mode is {after['journal_mode']}, expected wal")
    if after["table_counts"] != before["table_counts"]:
        raise RuntimeError("table row counts changed during journal migration")
    return {"changed": True, "before": before, "after": after}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Offline WAL migration for realtime.sqlite3")
    parser.add_argument("--offline-confirmed", action="store_true",
                        help="required acknowledgement that dashboard and worker services are stopped")
    parser.add_argument("--database", type=Path, default=REALTIME_DB)
    args = parser.parse_args()
    if not args.offline_confirmed:
        raise SystemExit("Refusing migration: stop dashboard/workers first, then pass --offline-confirmed")
    print(json.dumps(migrate(args.database), ensure_ascii=False, indent=2))
