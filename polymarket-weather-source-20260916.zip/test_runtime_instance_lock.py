import os
import subprocess
import sys
import sysconfig
import tempfile
import unittest
from pathlib import Path

from runtime_instance_lock import AlreadyRunningError, InstanceLock, writer_lock


BASE = Path(__file__).resolve().parent
BASE_PYTHON = Path(getattr(sys, "_base_executable", sys.executable))


class RuntimeInstanceLockTests(unittest.TestCase):
    def test_duplicate_is_rejected_and_release_reacquires(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "writer.lock"
            first = InstanceLock(path).acquire()
            try:
                with self.assertRaises(AlreadyRunningError):
                    InstanceLock(path).acquire()
            finally:
                first.release()
            with InstanceLock(path):
                self.assertTrue(path.exists())

    def test_hard_process_exit_releases_kernel_lock(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "crash.lock"
            code = (
                "import sys,time;"
                "from pathlib import Path;"
                "from runtime_instance_lock import InstanceLock;"
                "lock=InstanceLock(Path(sys.argv[1])).acquire();"
                "print('LOCKED',flush=True);"
                "time.sleep(60)"
            )
            child = subprocess.Popen(
                [str(BASE_PYTHON), "-c", code, str(path)],
                cwd=BASE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            self.assertEqual(child.stdout.readline().strip(), "LOCKED")
            with self.assertRaises(AlreadyRunningError):
                InstanceLock(path).acquire()
            child.kill()
            child.communicate(timeout=10)
            with InstanceLock(path):
                pass

    def test_all_writer_entrypoints_refuse_a_duplicate_before_running(self) -> None:
        environment = os.environ.copy()
        # Worktrees intentionally do not duplicate the repository virtual
        # environment.  Reuse the site-packages of the interpreter running
        # pytest instead of assuming every worktree contains ``.venv``.
        venv_site = Path(sysconfig.get_paths()["purelib"])
        environment["PYTHONPATH"] = str(venv_site) + (
            os.pathsep + environment["PYTHONPATH"] if environment.get("PYTHONPATH") else ""
        )
        scripts = {
            "collector": "collector.py",
            "realtime_stream": "realtime_stream.py",
            "metar_collector": "metar_collector.py",
        }
        for service, script in scripts.items():
            owned_lock = None
            try:
                owned_lock = writer_lock(service).acquire()
            except AlreadyRunningError:
                # The full suite is also valid while the isolated runtime is
                # online.  In that case the real writer already supplies the
                # authoritative duplicate boundary; never disturb it.
                pass
            try:
                completed = subprocess.run(
                    [str(BASE_PYTHON), str(BASE / script)],
                    cwd=BASE,
                    env=environment,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=20,
                    check=False,
                )
                self.assertEqual(completed.returncode, 73)
            finally:
                if owned_lock is not None:
                    owned_lock.release()


if __name__ == "__main__":
    unittest.main()
