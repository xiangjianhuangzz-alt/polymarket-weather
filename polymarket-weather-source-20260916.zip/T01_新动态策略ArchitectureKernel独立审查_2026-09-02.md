# T01｜新动态策略ArchitectureKernel独立审查｜2026-09-02

## 1. 审查身份与结论

```text
TASK_ID=PWM-V8-AK-001
REVIEW_ROLE=T01_PRIMARY_INDEPENDENT_REVIEWER
REVIEW_OBJECT=T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md
AS_OF=2026-09-02T00:00:00Z
VERDICT=FAIL
STOP=YES
```

结论：Kernel候选身份可复核，但B01—B15并未全部在Kernel层面闭合，且发现新的架构级歧义。不得据此进入完整V8设计、实现、Git集成、部署、激活或任何交易/资金路径。

## 2. KERNEL_IDENTITY

### 2.1 基线核验

```text
BRANCH=codex/handoff-baseline-20260809
HEAD=13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
MANIFEST_STATUS=FROZEN
```

Manifest列出的三成员SHA256现场复算结果：

| 成员 | SHA256 | 结果 |
|---|---|---|
| `T00_V8_ArchitectureKernel任务合同_2026-09-02.md` | `6739d6eec891679d084042b3f683d93605f0e12a95d338a401b94b2c350e208e` | MATCH |
| `T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md` | `b0ccc9d82e8c8bfec06836abaf6914a4c4c7fbcf932a59fb9ce54140d7485988` | MATCH |
| `T00_新动态策略ArchitectureKernel设计自检_2026-09-02.md` | `c408415a01c362525e285af25ca4942a239a842da4544422ef7da3e992b06ab5` | MATCH |

### 2.2 工作树身份

工作树不是干净树：`CURRENT_ISSUES.md`、`README.md`、`TASK_CONTRACT.md`、`系统架构.md`、`项目索引.md`存在既有修改；并有大量未跟踪历史/设计文件和`backups/`目录。上述既有变化未归因于本审查，`backups/`未读取、未处理。

本审查只被授权新增本报告；未修改其他对象。

### 2.3 授权文档冲突

当前`TASK_CONTRACT.md`仍记录`Architecture Kernel独立审查=NOT_AUTHORIZED/NOT_RUN`，而本次用户消息明确授权本审查。按项目控制规则，最新明确用户指令优先，因此本审查继续执行；该冲突应由T00后续单独记录，不应被本报告解释为实现授权。

## 3. 权威输入与阅读范围

已完整读取：

```text
T00_V8_ArchitectureKernel任务合同_2026-09-02.md
T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md
T00_新动态策略ArchitectureKernel设计自检_2026-09-02.md
T00_新动态策略ArchitectureKernel设计Manifest_2026-09-02.md
T01_新动态策略端到端研究架构独立终审_v8.2_r1_2026-09-01.md
T00_V8.2_R1独立终审FAIL后续路线决策审查_2026-09-02.md
T00_新动态策略设计输入基线_2026-08-31.md
T00_V3唯一策略保留项_保守净优势公式归档_2026-08-30.md
PROJECT_EXECUTION_PROTOCOL.md
TASK_CONTRACT.md
CURRENT_ISSUES.md
README.md
项目索引.md
系统架构.md
```

关键位置：候选第3节Canonical Registry、第4节逐城数据库身份、第5节append-only与Decision、第6节ApprovedConfigSet、第7节PF/DV/任务/ACL、第8节M007与事件、第9节CLI/子进程/恢复、第10节B01—B15矩阵。

## 4. 状态分离

| 状态项 | 当前判断 |
|---|---|
| `KERNEL_IDENTITY` | PASS：branch、HEAD和三成员Hash匹配Manifest |
| `KERNEL_ARCHITECTURE_VALIDATED` | FAIL：B01—B15未全部闭合，存在新增架构阻断 |
| `COMPLETE_V8_DESIGN` | NO：候选明确不是完整V8设计 |
| `IMPLEMENTATION_AUTHORIZED` | NO |
| `DEPLOYMENT_AUTHORIZED` | NO |
| `SHADOW/PAPER/LIVE/FUNDS` | NO；继续关闭 |

Manifest的`FROZEN`只证明候选成员字节身份，不证明内容终审、实现、集成或部署。

## 5. B01—B15独立对抗审查

### B01｜Canonical规范来源唯一性

```text
BLOCKER_ID=B01
RESULT=FAIL
```

原始失败：R1中连续位置编号和不同文件分别拥有Schema、配置、部署、SQL权威，导致两个实现者可以按不同文本解释同一对象。

Kernel规则：候选§3.1—§3.4定义一个`CanonicalRegistry`、稳定ID、`normative_owner`、`DERIVED`生成物和反向Hash绑定。

反例：实现者一把§3.3的RegistryEntry当作唯一规范，另一个把§7固定PF/DV、§9固定CLI和§4数据库规则当作规范正文；二者都可声称生成物引用`registry_hash`，但候选没有提供实际完整Registry成员集、规则到Entry的封闭映射、规范Payload或机器拒绝对象。

结果：Registry结构被声明，但候选仍在Registry外直接定义大量规范规则，不能证明只有一个可执行规范来源。`normative_owner`本身也是规则，未展示其完整Registry实例。

证据位置：候选§3.1—§3.4、§7.1—§7.4、§9.1—§9.3；R1审计B01位置为审计文件§4/ B01。

残余依赖：必须在完整设计前提供封闭Registry成员集、每条规则的唯一Owner、冲突检测和生成器输入，否则允许两个物理实现。

### B02｜ApprovedConfigSet单一批准权威

```text
BLOCKER_ID=B02
RESULT=UNRESOLVED
```

原始失败：批准权威在单文件和三城Registry/跨库事务之间分裂。

Kernel规则：候选§6规定单一`ApprovedConfigSet`文件，Registry只读，不使用`ATTACH`或三份批准记录。

反例：三城只读事务分别在不同时间读取。实现者一允许混合三个时间点的Registry快照后发布；实现者二要求三库共享一个快照水位。两者都符合“分别打开三城只读事务”和“单文件发布”，但可产生不同批准集合。候选没有定义统一快照、水位或源Registry版本组。

结果：单一最终批准对象的方向明确，但批准文件如何唯一、安全地形成仍依赖未定义的快照一致性和路径/文件持久性机制。不能在Kernel层面证明唯一可实施。

证据位置：候选§6.1—§6.2，尤其步骤2、5—7；R1审计B02—B03。

残余依赖：完整设计必须明确三城输入快照绑定、发布提交点、断电持久性、最终文件读取者和失败恢复身份。当前只能保持`FILESYSTEM_PUBLICATION_UNPROVEN`。

### B03｜SQLite WAL跨库原子性

```text
BLOCKER_ID=B03
RESULT=PASS
```

原始失败：R1以WAL下三库`ATTACH`声称全局原子批准，SQLite崩溃时可能部分提交。

Kernel规则：候选§6删除`ATTACH`、三库批准表和跨库批准事务，三城只读后只创建一个最终配置文件。

反例：在第三城读取后、文件发布前崩溃。不会留下三城部分批准状态；最终批准权威仍只有文件，临时文件不被Runtime读取。

结果：Kernel层面已排除WAL跨库批准作为权威。该结论不证明同卷发布或断电持久性已实现。

证据位置：候选§6.2；R1审计B03。

残余依赖：完整设计和实现验证必须证明文件系统同卷no-replace、崩溃恢复及快照绑定。

### B04｜append-only和不可变证据

```text
BLOCKER_ID=B04
RESULT=PASS
```

原始失败：Evidence、Book、Publication和Decision缺少数据库级UPDATE/DELETE阻断。

Kernel规则：候选§5.1列出`IMMUTABLE_AFTER_INSERT`对象，并要求由Registry生成每张表的`BEFORE UPDATE`和`BEFORE DELETE`阻断Trigger；允许更新对象必须登记为`MUTABLE_OPERATIONAL`。

反例：直接执行Evidence或Book UPDATE/DELETE。只要生成物确实从`CONSTRAINT.IMMUTABLE.<TABLE>`生成，统一返回`E_IMMUTABLE`；`ON DELETE RESTRICT`不能替代Trigger。

结果：不可变集合和数据库级阻断的Kernel规则足以排除“仅靠应用层自律”的实现。候选同时区分历史Evidence与运行协调对象。

证据位置：候选§5.1—§5.2；R1审计B04。

残余依赖：完整设计仍需给出完整表清单、DDL、Trigger验证和迁移边界。

### B05｜逐城数据库身份和跨城污染

```text
BLOCKER_ID=B05
RESULT=PASS
```

原始失败：数据库和行没有正式身份，跨城行可直接提交。

Kernel规则：候选§4.1定义每库唯一`DatabaseIdentity`；§4.2要求每个业务表携带`identity_key,city`复合外键和城市Trigger；§4.3要求Repository参数、路径和Manifest城市一致，跨城写入失败关闭。

反例：向上海库插入北京Evidence行，或将上海Artifact引用到北京Qualification。复合外键、城市Trigger、Repository expected city和写入前事务检查均应拒绝，并将跨城错误映射为`ERROR.CROSS_CITY`。

结果：SQLite复合FK和Trigger在当前设计中是可实现的；候选也明确要求`foreign_keys=ON`和`foreign_key_check`。Kernel层面已给出单库身份、行身份和Repository身份的三层约束。

证据位置：候选§4.1—§4.3；R1审计B05。

残余依赖：必须在完整DDL中保证所有业务表都带复合键，并通过每库独立连接验证；当前不能把设计结果当作运行事实。

### B06｜Metrics固定字段集

```text
BLOCKER_ID=B06
RESULT=PASS
```

原始失败：Schema只限制18个属性数量，未限制属性名称，导致任意X001—X018可替代M001—M018。

Kernel规则：候选§7.1固定`M001`—`M018`，要求固定properties、required和`additionalProperties=false`。

反例：提交18个未登记属性名。固定名称和额外属性关闭应拒绝；仅数量满足不能进入。

结果：B06所需的字段名称闭包已明确。

证据位置：候选§7.1；R1审计B06。

残余依赖：类型、数值域和各指标业务含义仍属于完整设计内容。

### B07｜Preflight/Verification完整集合

```text
BLOCKER_ID=B07
RESULT=PASS
```

原始失败：空`checks`或人为设置`passed=true`可被Schema接受。

Kernel规则：候选§7.2固定PF001—PF016和DV001—DV008，要求完整、唯一、无额外成员；`passed`为所有检查结果的派生值，UNKNOWN、SKIP、空集合或任一失败都产生false。

反例：`checks=[]; passed=true`或漏掉PF013。固定集合、唯一性和派生规则应拒绝。

结果：B07在Kernel层面已从数量检查升级为完整集合和结果派生。

证据位置：候选§7.2；R1审计B07。

残余依赖：具体Schema/生成器和每项检查的实体证据仍未实现。

### B08｜任务和ACL输入包完整性

```text
BLOCKER_ID=B08
RESULT=PASS
```

原始失败：任务URI、时间限制、任务成员和ACL成员可错位或缺失，但DeploymentBundle仍可被视为合法。

Kernel规则：候选§7.3固定Evidence、Runtime、Observer三项任务map、URI、时间和禁用属性；§7.4固定ACL目标集合。

反例：三个Evidence任务、Runtime任务缺失、任务URI与时间限制错配，或只放一个ACL ACE。固定map、交叉键和目标inventory应拒绝。

结果：B08关于成员集合和目标集合的Kernel约束已明确。具体rights、owner和inheritance不属于本Kernel的完整部署规格，但不能据此部署。

证据位置：候选§7.3—§7.4；R1审计B08。

残余依赖：完整部署设计需给出每个ACL target的精确rights、owner和inheritance。

### B09｜M007统计含义与非恒真性

```text
BLOCKER_ID=B09
RESULT=FAIL
```

原始失败：旧M007以`p_lcb<=1`类条件衡量coverage，任何合法概率都可能恒真。

Kernel规则：候选§8.1改为：

```text
z[d,b] = p_lcb[d,b] - y[d,b]
M007 = max_group UCB_alpha(mean(p_lcb-y))
```

反例：构造一个完全未校准模型：所有真实bucket的`p_lcb=0`，所有其他bucket也为0。真实bucket的`z=-1`，非真实bucket的`z=0`，M007不产生正的under-coverage惩罚，却代表真实bucket覆盖率为0。相反，若把概率质量错误地放在非真实bucket，`p_lcb-y`可能变大，但这衡量的是错误分布质量，不是LCB对真实结果的覆盖短fall。

结果：新指标虽然不再是简单的概率上界恒真式，但符号方向使其不能证明“真实结果被LCB覆盖”。候选没有定义事件级coverage indicator、损失方向、聚合样本和阈值判定之间的严格关系。该问题直接影响Qualification，不是可延后的文件细节。

证据位置：候选§8.1第443—460行；R1审计B09；V3归档§2.2及设计输入基线§7.7。

残余依赖：必须重新定义非恒真的coverage/shortfall统计量、失败反例、cluster bootstrap和未冻结阈值语义；在此之前不得把M007用于资格。

### B10｜30秒safe recheck、事件身份和bootstrap family

```text
BLOCKER_ID=B10
RESULT=FAIL
```

原始失败：30秒核对是否生成事件、是否重算模型和是否增加bootstrap family存在两种解释。

Kernel规则：候选§8.2规定仅状态变化产生RuntimeEvent，使用`city+transition_kind+before_state_hash+after_state_hash+effective_at`去重；无变化只更新health，事件和family不增加。

反例：同一来源事实在t1和t2被重复观察，状态内容相同，但一个实现把`effective_at`设为来源时间，另一个设为观察时间。两者均符合文字，结果分别是一个event_id或两个event_id；由于seed包含event_id，bootstrap结果和daily family count不同。另一个反例是进程重启后丢失临时去重缓存，重新生成不同event_id。

结果：候选未规定`effective_at`的唯一来源、持久化事实ID、跨重启去重锚点和事件链水位。safe recheck与bootstrap统计仍可产生不同实现。

证据位置：候选§8.2第462—483行；R1审计B10；设计输入基线§7.4、§7.14。

残余依赖：必须固定来源事实ID/游标、事件规范化Payload、跨重启去重、event chain水位和family计数提交点。

### B11｜DecisionInvalidation与CurrentCandidateSlot

```text
BLOCKER_ID=B11
RESULT=FAIL
```

原始失败：append-only Decision无法唯一表达旧候选已失效，可能出现多个同时有效的`YES_CANDIDATE`。

Kernel规则：候选§5.3增加append-only`DecisionInvalidation`，并定义：

```text
Decision.state=YES_CANDIDATE
AND NOT EXISTS Invalidation(invalidated_decision_id=Decision.decision_id)
```

反例：D1已经是`YES_CANDIDATE`；CurrentCandidateSlot随后被清空、损坏或指向NULL；新事件插入D2但没有一个既存slot指向D1可触发D1的invalidation。按候选谓词，D1和D2都没有对应Invalidation，均仍是有效候选。另一个实现者则只把slot当前值当作有效候选，两者得到不同结果。

结果：`CurrentCandidateSlot`是可变运行表，但未被明确纳入唯一的mutable registry；有效候选谓词没有绑定slot唯一性、窗口状态或单一事件链水位。恢复规则只能比较slot与历史，不能消除多个满足谓词的Decision。

证据位置：候选§5.3第243—277行；R1审计B11。

残余依赖：必须定义唯一当前候选关系、Decision与Invalidation的城市/事件复合FK、失效提交顺序、窗口关闭行为和恢复重建算法。

### B12｜CLI退出码唯一性

```text
BLOCKER_ID=B12
RESULT=FAIL
```

原始失败：正文和登记使用两套互斥退出码，Guardian无法唯一解释恢复或停止。

Kernel规则：候选§9.1列出0、2、3三个退出码，并禁止4—7。

反例：城市失败、lease冲突、未资格、Schema失败和可重试来源失败只被要求写入结构化ErrorCode，但没有固定各自映射到2还是3。一个实现者将lease冲突归为声明性拒绝，另一个归为意外失败；两个CLI均符合0/2/3集合，但Guardian行为不同。

结果：退出码集合唯一，但ErrorCode→退出码→Guardian动作的映射不唯一，B12仍未闭合。

证据位置：候选§9.1第486—497行；R1审计B12。

残余依赖：必须登记封闭ErrorCode、退出码、retryable、health和Guardian动作的逐项映射。

### B13｜spawn owner、子进程能力和恢复ID

```text
BLOCKER_ID=B13
RESULT=FAIL
```

原始失败：网络零权限与spawn例外指向错误文件，导致Worker可能获得未登记子进程能力，或Guardian无法启动所需Worker。

Kernel规则：候选§9.2规定只有Evidence Guardian和Runtime Guardian拥有`FIXED_CHILD_CONTROL`，各自启动三个逐城Worker，其他模块无spawn能力。

反例：Evidence Guardian崩溃于Worker已启动但状态未提交的时点。一个实现按parent PID恢复原Worker，另一个按模块名重新spawn；两者都符合固定入口和固定模块，但没有`RECOVERY_ID`、child identity、spawn attempt序列或幂等恢复记录来决定哪个实例合法。候选也未定义Guardian对每个Worker的唯一owner记录及恢复提交点。

结果：spawn入口数量和方向已比R1明确，但恢复身份、恢复ID、child lease和崩溃后唯一实例规则缺失，仍允许两种生命周期实现。

证据位置：候选§9.2第498—508行；R1审计B13；设计输入基线§7.14。

残余依赖：必须冻结`RECOVERY_ID`、parent/child identity、spawn attempt、lease、恢复提交顺序和重复实例处理。

### B14｜ACL与部署目标集合

```text
BLOCKER_ID=B14
RESULT=FAIL
```

原始失败：ACL目标、父目录和数据库数量不闭合，部署器无法判断漏项。

Kernel规则：候选§7.4声称ACL inventory恰好包含10个目录和10个数据库文件。

反例：按候选逐行清点目录：

```text
release_root
runtime_root/system
runtime_root/cities
runtime_root/cities/SHANGHAI
runtime_root/cities/BEIJING
runtime_root/cities/GUANGZHOU
runtime_root/config
runtime_root/status
runtime_root/locks
```

实际只有9个目录。候选没有列出`runtime_root`父目录，却声称总数为10。实现者一补入父目录，另一实现者补入其他目标；两者都可声称满足“10个目录”。数据库文件清单为`system.db + 3×3城市库 = 10`，但目录清单与计数直接矛盾。

结果：B14直接失败。当前不能形成精确ACL矩阵、继承边界或部署回滚目标。

证据位置：候选§7.4第412—441行，目录列于第414—426行；R1审计B14。

残余依赖：先纠正并冻结目录全集、父子关系、rights、owner、inheritance，再由独立验证复核。

### B15｜恢复状态、事务和PathPolicy唯一性

```text
BLOCKER_ID=B15
RESULT=FAIL
```

原始失败：breaker状态、health表、事务ID和PathPolicy引用存在多套名称，恢复无法唯一重建。

Kernel规则：候选§9.3固定`TABLE.EVIDENCE.HEALTH`、`CLOSED|OPEN|HALF_OPEN`、稳定事务ID和`POLICY.PATHS`。

反例：breaker进入`HALF_OPEN`后，候选没有定义进入条件、试探动作、超时、成功提交和回退条件。一个实现将状态保存在`evidence_health`，另一个保存于未明确的运行health表；两者都使用同一稳定名称。`POLICY.PATHS`也只有名称，没有封闭payload和恢复ID。

结果：稳定名称解决了部分命名漂移，但没有唯一的状态转换、事务Payload、PathPolicy对象和恢复记录，仍允许不同恢复架构。

证据位置：候选§9.3第509—524行；R1审计B15。

残余依赖：必须冻结HALF_OPEN状态机、health对象、事务Payload、PathPolicy字段、恢复ID和崩溃重建顺序。

## 6. 新增架构级阻断

### N01｜Canonical Registry仍是声明而非可执行唯一源

与B01直接相关，但具有全局影响：候选在§3外继续直接定义DatabaseIdentity、PF/DV、任务、ACL、M007、退出码和恢复名称。没有完整Registry实例和机器分类/生成契约，未来实现者仍可选择正文中的不同规则来源。

### N02｜ApprovedConfigSet快照与发布安全未闭合

与B02/B03相关：单文件消除了三库批准权威，但三城读取是否属于同一逻辑输入快照、配置文件是否已持久化、崩溃后如何区分已发布和未发布，仍未由Kernel唯一规定。

### N03｜mutable运行表集合不完整

候选列出cursor、lease、breaker、health和city/system current state，但未明确`CurrentCandidateSlot`、DecisionInvalidation、receipt、事件链水位分别属于不可变Evidence还是可变运行对象。该遗漏直接影响B04、B11和恢复算法。

### N04｜固定清单内部计数矛盾

候选声称10个目录，实际列出9个目录；这使ACL Hash、部署Preflight和回滚目标无法唯一生成，不能视为普通排版问题。

### N05｜事件与30秒核对的bootstrap独立性不足

事件去重键中的`effective_at`来源未固定，event_id跨重启的稳定性未证明，导致同一target-day可能产生不同seed和family count。

### N06｜退出码与恢复动作未形成闭合函数

0/2/3集合本身不够；ErrorCode、retryable、health、Guardian动作和恢复ID没有封闭映射。

## 7. 业务不变量保护

当前候选未改写下列冻结业务方向，但其未闭合问题仍会影响未来实现安全性：

```text
SIDE=BUY_YES_ONLY
DECISION_FORMULA=E_conservative(B,t)=P_LCB(B|I_t)-C_executable(B,t)
MARKET_PRICE_IN_WEATHER_MODEL=NO
WINDOW=Asia/Shanghai [07:00:00,16:00:00)
STRICT_AS_OF=REQUIRED
CITIES=SHANGHAI,BEIJING,GUANGZHOU
CITY_END_TO_END_INDEPENDENCE=REQUIRED
SHADOW/PAPER/LIVE/FUNDS=DISABLED
```

来源与站点边界仍显示为：

```text
SHANGHAI=weatherol_shanghai/weatherol_d0, ZSPD
BEIJING=TAF, ZBAA
GUANGZHOU=TAF, ZGGG
```

M007方向错误、跨城身份、市场目标和事件身份问题可能在未来破坏上述不变量，因此不能以“未改写公式”作为架构通过依据。

## 8. 证据与文件变更

### 8.1 使用的命令/检查

```text
git branch --show-current
git rev-parse HEAD
git status --short
Get-FileHash -Algorithm SHA256 <three Manifest members>
Get-Content -Encoding UTF8 <all listed review files>
Select-String <candidate headings and B01-B15 locations>
```

未运行测试、未执行SQLite、未访问服务、未读取或处理`backups/`，未进行网络主动探测。

### 8.2 修改边界

```text
ONLY_REPORT_CREATED=YES
OTHER_FILES_MODIFIED_BY_T01=NO
GIT_WRITE=NO
DATABASE_WRITE=NO
CONFIG_WRITE=NO
SERVICE_OPERATION=NO
```

本报告本身的最终SHA256不在报告内自绑定；T00可在消息实体和文件形成后另行计算并写入外部审计记录。

## 9. 最终交回T00

```text
KERNEL_IDENTITY=PASS
KERNEL_ARCHITECTURE_VALIDATED=FAIL
COMPLETE_V8_DESIGN=NO
IMPLEMENTATION_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
NEXT_STAGE=STOP
```

必须先解决B01、B02、B09、B10、B11、B12、B13、B14、B15及N01—N06，再由新的独立审查重新判定。当前停止并交回T00。
