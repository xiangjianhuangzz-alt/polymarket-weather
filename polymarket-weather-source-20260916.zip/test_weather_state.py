import asyncio
import sqlite3
import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path

import collector


class _Response:
    def __init__(self, payload):
        self.payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self.payload


class _Client:
    def __init__(self, payload):
        self.payload = payload

    async def get(self, *_args, **_kwargs):
        return _Response(self.payload)


def _payload(temp="30.0"):
    return {"returnCode": "0", "list": [
        {"fastEle": "TEM", "value": temp}, {"fastEle": "RHU", "value": "65"},
        {"fastEle": "TCDC", "value": "70"}, {"fastEle": "WINS", "value": "3"},
        {"fastEle": "WIND", "value": "90"}, {"fastEle": "PRE_1H", "value": "0"},
        {"fastEle": "PRE_3H", "value": "0"}, {"fastEle": "PRE_12H", "value": "1"},
        {"fastEle": "PRE_24H", "value": "2"},
    ]}


class WeatherStateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_path = collector.DB_PATH
        collector.DB_PATH = Path(self.tmp.name) / "research.sqlite3"
        self.db = collector.connect()

    def tearDown(self):
        self.db.close()
        collector.DB_PATH = self.old_path
        self.tmp.cleanup()

    def test_d0_uses_source_release_time_not_midnight_capture(self):
        # A 23:15 source release collected at 00:00 is a carry-over.
        status = collector.register_d0_candidate(
            self.db, source="weatherol_beijing", city="Beijing", station="ZBAA",
            target_date="2026-07-23", high=30.9,
            captured_at="2026-07-22T16:00:07+00:00",
            source_reported_at="2026-07-22T23:15:00+08:00",
            grid_version="weatherol-airport:ZBAA")
        self.assertEqual(status, "delayed_carry")

        # A genuine target-day release freezes the D0 value using floor buckets.
        status = collector.register_d0_candidate(
            self.db, source="weatherol_beijing", city="Beijing", station="ZBAA",
            target_date="2026-07-23", high=31.00000001,
            captured_at="2026-07-22T16:10:10+00:00",
            source_reported_at="2026-07-23T00:10:00+08:00",
            grid_version="weatherol-airport:ZBAA")
        self.assertEqual(status, "valid_d0")
        row = self.db.execute("SELECT status,forecast_high_c,forecast_bucket FROM forecast_d0_registry").fetchone()
        self.assertEqual(row, ("valid_d0", 31.00000001, 31))

        # Later intraday revisions must not overwrite the frozen D0.
        collector.register_d0_candidate(
            self.db, source="weatherol_beijing", city="Beijing", station="ZBAA",
            target_date="2026-07-23", high=33.0,
            captured_at="2026-07-23T02:00:10+00:00",
            source_reported_at="2026-07-23T10:00:00+08:00",
            grid_version="weatherol-airport:ZBAA")
        self.assertEqual(self.db.execute("SELECT forecast_high_c FROM forecast_d0_registry").fetchone()[0], 31.00000001)

    def test_d0_rejects_missing_or_future_source_clock(self):
        missing, _, _ = collector.d0_candidate_status("2026-07-23", None, "2026-07-22T16:00:00+00:00")
        future, _, _ = collector.d0_candidate_status("2026-07-23", "2026-07-23T01:00:00+08:00", "2026-07-22T16:00:00+00:00")
        midnight, _, _ = collector.d0_candidate_status("2026-07-23", "2026-07-23T00:00:00+08:00", "2026-07-22T16:00:00+00:00")
        self.assertEqual(missing, "source_time_missing")
        self.assertEqual(future, "source_clock_skew")
        self.assertEqual(midnight, "midnight_not_after")

    def test_midnight_d0_repair_selects_first_later_release(self):
        self.db.execute("""INSERT INTO forecast_d0_registry
          (source,city,station,target_date,grid_version,status,forecast_high_c,forecast_bucket,
           source_reported_at,first_captured_at,capture_delay_seconds,content_hash,reason,frozen_at,latest_checked_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          ("weatherol_chengdu", "Chengdu", "ZUUU", "2026-07-23", "weatherol-airport:ZUUU",
           "valid_d0", 37.0, 37, "2026-07-23T00:00:00+08:00", "2026-07-22T16:28:00+00:00",
           0, "old", "old", "2026-07-22T16:28:00+00:00", "2026-07-22T16:28:00+00:00"))
        self.db.execute("""INSERT INTO forecast_update_values VALUES (?,?,?,?,?,?,?)""",
          ("weatherol_chengdu", "Chengdu", "ZUUU", "2026-07-23T00:10:00+08:00",
           "2026-07-22T16:30:00+00:00", "2026-07-23", 38.2))
        self.db.execute("DELETE FROM collector_migrations WHERE name='d0_strict_after_midnight_v1'")
        collector.repair_d0_strict_after_midnight(self.db)
        row = self.db.execute("""SELECT status,forecast_high_c,forecast_bucket,source_reported_at
          FROM forecast_d0_registry""").fetchone()
        self.assertEqual(row, ("valid_d0", 38.2, 38, "2026-07-23T00:10:00+08:00"))

    def test_scheduled_forecast_window_records_success_and_missing_attempt(self):
        start = "2026-07-23T00:57:00+00:00"
        self.db.execute("""INSERT INTO forecast_fetch_audits VALUES (?,?,?,?,?,?,?,?)""",
                        ("2026-07-23T00:57:01+00:00", "2026-07-23T00:57:02+00:00",
                         "weatherol_beijing", "Beijing", "ZBAA", "ok", None,
                         "2026-07-23T08:55:00+08:00"))
        collector.record_forecast_delivery_windows(
            self.db, scheduled_at=start, schedule_kind="precision",
            cities={"Beijing", "Shanghai"}, cycle_started_at=start)
        rows = self.db.execute("""SELECT city,status,source_reported_at FROM forecast_delivery_windows
          ORDER BY city""").fetchall()
        self.assertEqual(rows[0], ("Beijing", "ok", "2026-07-23T08:55:00+08:00"))
        self.assertEqual(rows[1][0:2], ("Shanghai", "not_attempted"))


if __name__ == "__main__":
    unittest.main()
