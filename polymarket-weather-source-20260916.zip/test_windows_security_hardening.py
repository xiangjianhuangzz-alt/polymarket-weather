from __future__ import annotations

import json
from pathlib import Path
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parent
SCRIPT = ROOT / "windows_security_hardening.ps1"


class WindowsSecurityHardeningTests(unittest.TestCase):
    def test_apply_then_audit_produces_exact_protected_acl(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / ".env").write_text("PRIVATE_KEY=test-only\n", encoding="utf-8")
            for name in ("control", "locks", "services"):
                (root / "data" / "runtime" / name).mkdir(parents=True, exist_ok=True)
            command = [
                "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-File", str(SCRIPT), "-Mode", "Apply", "-RootPath", str(root),
            ]
            applied = subprocess.run(command, text=True, encoding="utf-8", capture_output=True,
                                     timeout=60, check=False)
            self.assertEqual(applied.returncode, 0, applied.stdout + applied.stderr)
            audited = subprocess.run(
                [*command[:6], "-Mode", "Audit", "-RootPath", str(root)],
                text=True, encoding="utf-8", capture_output=True, timeout=60, check=False,
            )
            self.assertEqual(audited.returncode, 0, audited.stdout + audited.stderr)
            results = json.loads(audited.stdout)
            self.assertEqual(len(results), 4)
            self.assertTrue(all(item["exists"] and item["protected"] for item in results))
            self.assertTrue(all(item["unexpected"] == [] for item in results))


if __name__ == "__main__":
    unittest.main()
