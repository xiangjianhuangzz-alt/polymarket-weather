"""Single source of truth for the isolated local SQLite stores.

The separation is intentional rather than cosmetic: a service may write only
to the database named by its role.  Consumers always open those databases in
read-only mode.
"""
from pathlib import Path


BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
RESEARCH_DB = DATA / "research.sqlite3"
REALTIME_DB = DATA / "realtime.sqlite3"
PAPER_DB = DATA / "paper.sqlite3"
# Airport actual observations are deliberately isolated from forecasts, quotes
# and the paper ledger.  The METAR worker is its sole writer.
OBSERVATIONS_DB = DATA / "observations.sqlite3"
