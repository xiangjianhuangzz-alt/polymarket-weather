import tempfile
import unittest
import sqlite3
from contextlib import closing
from datetime import UTC, datetime, timedelta
from pathlib import Path

from paper_trading import PaperBroker, PaperError


MARKET = {"id": "m1", "token": "t1", "city": "Beijing", "date": "2026-07-21", "bucket": "31°C"}


class PaperBrokerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.broker = PaperBroker(Path(self.tmp.name) / "paper.sqlite3")

    def tearDown(self):
        self.tmp.cleanup()

    def quote(self, bid=.20, ask=.22, bid_size=100, ask_size=100, age=0):
        stamp = (datetime.now(UTC) - timedelta(seconds=age)).isoformat()
        self.broker.sync_quote_marks({"t1": (bid, ask, bid_size, ask_size, stamp)})

    def test_stale_quote_is_rejected(self):
        self.quote(age=31)
        with self.assertRaises(PaperError):
            self.broker.place(MARKET, "BUY", "LIMIT", 5, .21, "test")

    def test_resting_limit_then_fill_on_new_current_mark(self):
        self.quote()
        self.broker.place(MARKET, "BUY", "LIMIT", 5, .21, "test")
        self.assertEqual(self.broker.snapshot()["orders"][0]["status"], "OPEN")
        self.quote(bid=.20, ask=.21)
        self.broker.process_open_orders()
        state = self.broker.snapshot()
        self.assertEqual(state["orders"][0]["status"], "FILLED")
        self.assertEqual(state["positions"][0]["quantity"], 5)

    def test_zero_displayed_size_does_not_fill(self):
        self.quote(bid=.20, ask=.22, ask_size=0)
        self.broker.place(MARKET, "BUY", "LIMIT", 5, .22, "test")
        self.assertEqual(self.broker.snapshot()["orders"][0]["status"], "OPEN")

    def test_displayed_depth_is_not_claimed_as_full_fill(self):
        self.quote(bid=.20, ask=.21, ask_size=6)
        self.broker.place(MARKET, "BUY", "LIMIT", 5, .21, "test")
        self.assertEqual(self.broker.snapshot()["orders"][0]["status"], "PARTIAL")

    def test_reset_retains_filled_history(self):
        self.quote(bid=.20, ask=.21)
        self.broker.place(MARKET, "BUY", "LIMIT", 5, .21, "test")
        self.broker.process_open_orders()
        result = self.broker.reset_current_exposure(cash=1000, reason="operator_reset")
        self.assertTrue(result["ok"])
        self.assertEqual(self.broker.snapshot()["positions"], [])

    def test_reopen_recovers_orders_fills_and_position(self):
        """A process restart must not lose the independent paper ledger."""
        self.quote(bid=.20, ask=.21, ask_size=20)
        self.broker.place(MARKET, "BUY", "LIMIT", 5, .21, "restart_recovery")
        database = self.broker.database
        restarted = PaperBroker(database)
        recovered = restarted.snapshot()
        self.assertEqual(recovered["orders"][0]["status"], "FILLED")
        self.assertEqual(recovered["positions"][0]["quantity"], 5)
        self.assertEqual(len(recovered["fills"]), 1)

    def test_immediate_cross_is_taker_and_weather_fee_is_charged(self):
        self.quote(bid=.39, ask=.40, ask_size=20)
        result = self.broker.place(MARKET, "BUY", "LIMIT", 5, .40, "taker_fee")
        state = self.broker.snapshot()
        self.assertEqual(result["status"], "FILLED")
        self.assertEqual(state["fills"][0]["liquidity_role"], "taker")
        self.assertAlmostEqual(state["fills"][0]["total_fee"], .06, places=6)
        self.assertAlmostEqual(state["account"]["cash"], 997.94, places=6)
        self.assertAlmostEqual(state["account"]["fees_paid"], .06, places=6)

    def test_resting_limit_fill_is_maker_and_has_no_platform_fee(self):
        self.quote(bid=.38, ask=.40, ask_size=20)
        self.broker.place(MARKET, "BUY", "LIMIT", 5, .39, "maker_fee")
        self.quote(bid=.38, ask=.39, ask_size=20)
        self.broker.process_open_orders()
        fill = self.broker.snapshot()["fills"][0]
        self.assertEqual(fill["liquidity_role"], "maker")
        self.assertEqual(fill["platform_fee"], 0)
        self.assertEqual(fill["total_fee"], 0)

    def test_fak_partially_fills_then_cancels_remainder(self):
        self.quote(bid=.20, ask=.22, ask_size=6)
        result = self.broker.place(
            MARKET, "BUY", "LIMIT", 5, .22, "fak_partial", time_in_force="FAK",
        )
        self.assertEqual(result["status"], "CANCELLED")
        self.assertEqual(result["filled_quantity"], 3)
        self.assertEqual(result["cancel_reason"], "fak_remainder_cancelled")
        self.assertEqual(self.broker.open_orders(), [])

    def test_fok_cancels_without_fill_when_full_size_is_unavailable(self):
        self.quote(bid=.20, ask=.22, ask_size=6)
        result = self.broker.place(
            MARKET, "BUY", "LIMIT", 5, .22, "fok_no_fill", time_in_force="FOK",
        )
        self.assertEqual(result["status"], "CANCELLED")
        self.assertEqual(result["filled_quantity"], 0)
        self.assertEqual(self.broker.snapshot()["positions"], [])

    def test_market_worst_price_prevents_unbounded_slippage(self):
        self.quote(bid=.20, ask=.22, ask_size=100)
        with self.assertRaisesRegex(PaperError, "worst_price"):
            self.broker.place(
                MARKET, "BUY", "MARKET", 5, None, "guarded_market",
                time_in_force="FOK", worst_price=.21,
            )

        result = self.broker.place(
            MARKET, "BUY", "MARKET", 5, None, "guarded_market",
            time_in_force="FOK", worst_price=.22,
        )
        self.assertEqual(result["status"], "FILLED")
        self.assertAlmostEqual(
            self.broker.snapshot()["orders"][0]["worst_price"], .22,
        )

    def test_fak_sell_partial_fill_never_creates_subminimum_residual(self):
        self.quote(bid=.20, ask=.22, bid_size=100, ask_size=100)
        self.broker.place(MARKET, "BUY", "MARKET", 10, None, "seed")
        self.quote(bid=.30, ask=.31, bid_size=12, ask_size=100)

        first = self.broker.exit_all(MARKET, "risk_exit")
        state = self.broker.snapshot()
        self.assertEqual(first["status"], "CANCELLED")
        self.assertEqual(first["filled_quantity"], 5)
        self.assertEqual(state["positions"][0]["quantity"], 5)

        self.quote(bid=.30, ask=.31, bid_size=10, ask_size=100)
        second = self.broker.exit_all(MARKET, "risk_exit_retry")
        self.assertEqual(second["status"], "FILLED")
        self.assertEqual(self.broker.snapshot()["positions"], [])

    def test_resolution_settles_position_once_at_binary_payout(self):
        self.quote(bid=.19, ask=.20, bid_size=100, ask_size=100)
        self.broker.place(MARKET, "BUY", "MARKET", 10, None, "seed")
        before = self.broker.snapshot()
        resolution = {
            "market_id": MARKET["id"], "yes_resolved": 1,
            "resolved_at": "2026-07-22T00:01:00+00:00",
        }

        first = self.broker.settle_resolved_positions([resolution])
        after = self.broker.snapshot()
        second = self.broker.settle_resolved_positions([resolution])

        self.assertEqual(len(first), 1)
        self.assertEqual(first[0]["payout_per_share"], 1.0)
        self.assertEqual(first[0]["quantity"], 10.0)
        self.assertEqual(after["positions"], [])
        self.assertAlmostEqual(
            after["account"]["cash"], before["account"]["cash"] + 10,
        )
        self.assertAlmostEqual(
            after["account"]["realized_pnl"],
            before["account"]["realized_pnl"] + 8,
        )
        self.assertEqual(second, [])
        self.assertEqual(len(after["settlements"]), 1)

    def test_losing_resolution_settles_position_at_zero_payout(self):
        self.quote(bid=.19, ask=.20, bid_size=100, ask_size=100)
        self.broker.place(MARKET, "BUY", "MARKET", 10, None, "seed")
        before = self.broker.snapshot()

        settled = self.broker.settle_resolved_positions([{
            "market_id": MARKET["id"], "yes_resolved": 0,
            "resolved_at": "2026-07-22T00:01:00+00:00",
        }])
        after = self.broker.snapshot()

        self.assertEqual(len(settled), 1)
        self.assertEqual(settled[0]["payout_per_share"], 0.0)
        self.assertEqual(after["positions"], [])
        self.assertAlmostEqual(
            after["account"]["cash"], before["account"]["cash"],
        )
        self.assertAlmostEqual(
            after["account"]["realized_pnl"],
            before["account"]["realized_pnl"] - 2,
        )
        self.assertEqual(len(after["settlements"]), 1)

    def test_post_only_cross_is_rejected(self):
        self.quote(bid=.20, ask=.22)
        with self.assertRaisesRegex(PaperError, "post-only"):
            self.broker.place(
                MARKET, "BUY", "LIMIT", 5, .22, "post_only", post_only=True,
            )

    def test_gtd_requires_official_sixty_second_security_threshold(self):
        self.quote(bid=.20, ask=.22)
        too_soon = (datetime.now(UTC) + timedelta(seconds=30)).isoformat()
        with self.assertRaisesRegex(PaperError, "60秒"):
            self.broker.place(
                MARKET, "BUY", "LIMIT", 5, .21, "gtd_too_soon",
                time_in_force="GTD", expires_at=too_soon,
            )
        valid = (datetime.now(UTC) + timedelta(seconds=90)).isoformat()
        result = self.broker.place(
            MARKET, "BUY", "LIMIT", 5, .21, "gtd_valid",
            time_in_force="GTD", expires_at=valid,
        )
        self.assertEqual(result["status"], "OPEN")

    def test_market_minimum_and_tick_are_validated_but_size_need_not_be_multiple(self):
        self.quote(bid=.20, ask=.22)
        with self.assertRaisesRegex(PaperError, "minimum"):
            self.broker.place(MARKET, "BUY", "LIMIT", 4, .21, "too_small")
        with self.assertRaisesRegex(PaperError, "tick_size"):
            self.broker.place(MARKET, "BUY", "LIMIT", 5, .215, "bad_tick")
        result = self.broker.place(MARKET, "BUY", "LIMIT", 7, .21, "valid_non_multiple")
        self.assertEqual(result["status"], "OPEN")

    def test_buy_and_sell_cash_and_realized_pnl_are_net_of_fees(self):
        self.quote(bid=.39, ask=.40, bid_size=20, ask_size=20)
        self.broker.place(MARKET, "BUY", "LIMIT", 5, .40, "buy")
        self.quote(bid=.50, ask=.51, bid_size=20, ask_size=20)
        result = self.broker.exit_all(MARKET, "exit")
        state = self.broker.snapshot()
        self.assertEqual(result["status"], "FILLED")
        self.assertAlmostEqual(state["account"]["cash"], 1000.3775, places=6)
        self.assertAlmostEqual(state["account"]["realized_pnl"], .3775, places=6)
        self.assertAlmostEqual(state["account"]["fees_paid"], .1225, places=6)

    def test_legacy_ledger_is_migrated_without_losing_account(self):
        legacy = Path(self.tmp.name) / "legacy.sqlite3"
        with closing(sqlite3.connect(legacy)) as db, db:
            db.executescript("""
              CREATE TABLE paper_accounts (
                account_id TEXT PRIMARY KEY,created_at TEXT NOT NULL,
                starting_cash REAL NOT NULL,cash REAL NOT NULL,
                realized_pnl REAL NOT NULL DEFAULT 0,status TEXT NOT NULL);
              CREATE TABLE paper_orders (
                order_id TEXT PRIMARY KEY,account_id TEXT NOT NULL,created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,market_id TEXT NOT NULL,token_id TEXT NOT NULL,
                city TEXT NOT NULL,target_date TEXT NOT NULL,bucket TEXT NOT NULL,
                side TEXT NOT NULL,order_type TEXT NOT NULL,quantity REAL NOT NULL,
                limit_price REAL,status TEXT NOT NULL,filled_quantity REAL NOT NULL DEFAULT 0,
                avg_fill_price REAL,reason TEXT NOT NULL,last_quote_at TEXT);
              CREATE TABLE paper_positions (
                account_id TEXT NOT NULL,token_id TEXT NOT NULL,market_id TEXT NOT NULL,
                city TEXT NOT NULL,target_date TEXT NOT NULL,bucket TEXT NOT NULL,
                quantity REAL NOT NULL,avg_cost REAL NOT NULL,realized_pnl REAL NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL,PRIMARY KEY(account_id,token_id));
              CREATE TABLE paper_fills (
                fill_id TEXT PRIMARY KEY,order_id TEXT NOT NULL,filled_at TEXT NOT NULL,
                side TEXT NOT NULL,quantity REAL NOT NULL,price REAL NOT NULL,
                notional REAL NOT NULL,quote_at TEXT NOT NULL,reason TEXT NOT NULL);
              CREATE TABLE paper_quote_marks (
                token_id TEXT PRIMARY KEY,best_bid REAL,best_ask REAL,
                bid_size REAL,ask_size REAL,captured_at TEXT NOT NULL);
              CREATE TABLE paper_sessions (
                session_id TEXT PRIMARY KEY,target_date TEXT NOT NULL UNIQUE,
                started_at TEXT NOT NULL,starting_cash REAL NOT NULL,
                rules_json TEXT NOT NULL,status TEXT NOT NULL,note TEXT);
              INSERT INTO paper_accounts VALUES ('research','2026-01-01',1000,777,3,'ACTIVE');
            """)
        migrated = PaperBroker(legacy)
        state = migrated.snapshot()
        self.assertEqual(state["account"]["cash"], 777)
        self.assertEqual(state["account"]["fees_paid"], 0)
        with closing(sqlite3.connect(legacy)) as db:
            order_columns = {row[1] for row in db.execute("PRAGMA table_info(paper_orders)")}
            fill_columns = {row[1] for row in db.execute("PRAGMA table_info(paper_fills)")}
        self.assertIn("time_in_force", order_columns)
        self.assertIn("fee_schedule_version", order_columns)
        self.assertIn("total_fee", fill_columns)


if __name__ == "__main__":
    unittest.main()
