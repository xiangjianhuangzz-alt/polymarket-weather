"""Read-only repository connection identity verification foundation."""

from __future__ import annotations

from dataclasses import dataclass
import sqlite3

from ..canonical import CANONICAL_ENCODING_ID, parse_canonical_time_v1, validate_hash_v1
from ..contracts import City, DatabaseRole


class RepositoryIdentityError(RuntimeError):
    """Raised when a connection cannot prove its expected database identity."""


@dataclass(frozen=True, slots=True)
class DatabaseIdentity:
    singleton: int
    database_uid: str
    city: City | None
    database_role: DatabaseRole
    schema_version: str
    created_at: str

    def __post_init__(self) -> None:
        if isinstance(self.singleton, bool) or self.singleton != 1:
            raise ValueError("DatabaseIdentity singleton must equal integer 1")
        if not isinstance(self.database_uid, str) or not self.database_uid:
            raise ValueError("database_uid must be a non-empty string")
        if not isinstance(self.database_role, DatabaseRole):
            raise TypeError("database_role must be a frozen DatabaseRole value")
        system_identity = self.city is None and self.database_role is DatabaseRole.SYSTEM
        city_identity = isinstance(self.city, City) and self.database_role in {
            DatabaseRole.EVIDENCE,
            DatabaseRole.REGISTRY,
            DatabaseRole.RUNTIME,
        }
        if not (system_identity or city_identity):
            raise ValueError("invalid city and database_role identity combination")
        if not isinstance(self.schema_version, str) or not self.schema_version:
            raise ValueError("schema_version must be a non-empty string")
        parse_canonical_time_v1(self.created_at)


def verify_connection_identity(
    connection: sqlite3.Connection,
    expected: DatabaseIdentity,
    *,
    expected_schema_version: str,
    expected_schema_hash: str,
    expected_canonical_encoding_id: str = CANONICAL_ENCODING_ID,
) -> DatabaseIdentity:
    """Fail closed unless the connection proves the exact expected foundation identity."""
    if not isinstance(connection, sqlite3.Connection):
        raise TypeError("connection must be sqlite3.Connection")
    if not isinstance(expected, DatabaseIdentity):
        raise TypeError("expected must be DatabaseIdentity")
    validate_hash_v1(expected_schema_hash)
    if not isinstance(expected_canonical_encoding_id, str) or not expected_canonical_encoding_id:
        raise ValueError("expected_canonical_encoding_id must be a non-empty string")
    if expected.schema_version != expected_schema_version:
        raise ValueError("expected database and schema metadata versions must match")

    try:
        foreign_keys_row = connection.execute("PRAGMA foreign_keys").fetchone()
        schema_row = connection.execute(
            "SELECT schema_version, canonical_encoding_id, schema_hash "
            "FROM schema_metadata WHERE singleton_id = 1"
        ).fetchone()
        identity_rows = connection.execute(
            "SELECT singleton, database_uid, city, database_role, schema_version, created_at "
            "FROM database_identity WHERE singleton = 1"
        ).fetchmany(2)
    except sqlite3.Error as exc:
        raise RepositoryIdentityError("database identity foundation is unreadable") from exc

    if foreign_keys_row != (1,):
        raise RepositoryIdentityError("connection must have PRAGMA foreign_keys=1")
    if schema_row != (
        expected_schema_version,
        expected_canonical_encoding_id,
        expected_schema_hash,
    ):
        raise RepositoryIdentityError("schema identity does not match the expected identity")
    if len(identity_rows) != 1:
        raise RepositoryIdentityError("database identity must contain exactly one singleton row")
    identity_row = identity_rows[0]

    try:
        actual = DatabaseIdentity(
            singleton=identity_row[0],
            database_uid=identity_row[1],
            city=City(identity_row[2]) if identity_row[2] is not None else None,
            database_role=DatabaseRole(identity_row[3]),
            schema_version=identity_row[4],
            created_at=identity_row[5],
        )
    except (TypeError, ValueError) as exc:
        raise RepositoryIdentityError("database identity row is invalid") from exc

    if actual != expected:
        raise RepositoryIdentityError("connection database identity does not match expected identity")
    return actual
