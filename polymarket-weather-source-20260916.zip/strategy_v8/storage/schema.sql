-- WP-02-FOUNDATION only: metadata and database identity, with no business tables.
CREATE TABLE schema_metadata (
    singleton_id INTEGER PRIMARY KEY CHECK (singleton_id = 1),
    schema_version TEXT NOT NULL,
    canonical_encoding_id TEXT NOT NULL,
    schema_hash TEXT NOT NULL CHECK (
        length(schema_hash) = 64 AND schema_hash = lower(schema_hash)
    )
) STRICT;

CREATE TABLE database_identity (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    database_uid TEXT NOT NULL UNIQUE CHECK (length(database_uid) > 0),
    city TEXT,
    database_role TEXT NOT NULL CHECK (
        database_role IN ('SYSTEM', 'EVIDENCE', 'REGISTRY', 'RUNTIME')
    ),
    schema_version TEXT NOT NULL CHECK (length(schema_version) > 0),
    created_at TEXT NOT NULL CHECK (length(created_at) = 27),
    CHECK (
        (city IS NULL AND database_role = 'SYSTEM')
        OR
        (city IN ('BEIJING', 'GUANGZHOU', 'SHANGHAI')
         AND database_role IN ('EVIDENCE', 'REGISTRY', 'RUNTIME'))
    )
) STRICT;

CREATE TRIGGER schema_metadata_no_update
BEFORE UPDATE ON schema_metadata
BEGIN
    SELECT RAISE(ABORT, 'schema_metadata is immutable');
END;

CREATE TRIGGER schema_metadata_no_delete
BEFORE DELETE ON schema_metadata
BEGIN
    SELECT RAISE(ABORT, 'schema_metadata is immutable');
END;

CREATE TRIGGER database_identity_no_update
BEFORE UPDATE ON database_identity
BEGIN
    SELECT RAISE(ABORT, 'database_identity is immutable');
END;

CREATE TRIGGER database_identity_no_delete
BEFORE DELETE ON database_identity
BEGIN
    SELECT RAISE(ABORT, 'database_identity is immutable');
END;
