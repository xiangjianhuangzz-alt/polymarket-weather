"""Frozen identities and non-executable VS-01 input/output skeleton."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping
import unicodedata

from .canonical import canonical_encode, parse_canonical_time_v1, validate_hash_v1
from .errors import ErrorCode, OutcomeClass, outcome_class_for


VS01_SKELETON_ONLY = True
VS01_EXECUTABLE = False


class City(str, Enum):
    BEIJING = "BEIJING"
    GUANGZHOU = "GUANGZHOU"
    SHANGHAI = "SHANGHAI"


class DatabaseRole(str, Enum):
    SYSTEM = "SYSTEM"
    EVIDENCE = "EVIDENCE"
    REGISTRY = "REGISTRY"
    RUNTIME = "RUNTIME"


def _schema_version(value: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError("schema_version must be a non-empty string")
    if unicodedata.normalize("NFC", value) != value:
        raise ValueError("schema_version must already be Unicode NFC")
    return value


def _freeze_contract(value: Any) -> Any:
    if isinstance(value, Mapping):
        if any(not isinstance(key, str) for key in value):
            raise TypeError("contract object keys must be strings")
        return MappingProxyType({key: _freeze_contract(item) for key, item in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_contract(item) for item in value)
    if value is None or isinstance(value, (bool, str, int, float)):
        canonical_encode(value)
        return value
    raise TypeError(f"unsupported contract value type: {type(value).__name__}")


def _frozen_mapping(value: Mapping[str, Any]) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("contract payload must be a mapping")
    canonical_encode(value)
    return _freeze_contract(value)


@dataclass(frozen=True, slots=True)
class VS01DependencySet:
    approved_config_set_hash: str
    as_of_identity_hash: str
    input_identity_hash: str

    def __post_init__(self) -> None:
        validate_hash_v1(self.approved_config_set_hash)
        validate_hash_v1(self.as_of_identity_hash)
        validate_hash_v1(self.input_identity_hash)


@dataclass(frozen=True, slots=True)
class VS01Request:
    schema_version: str
    city: City
    evaluation_as_of_utc: str
    dependencies: VS01DependencySet
    input_contract: Mapping[str, Any]

    def __post_init__(self) -> None:
        _schema_version(self.schema_version)
        if not isinstance(self.city, City):
            raise TypeError("city must be a frozen City value")
        parse_canonical_time_v1(self.evaluation_as_of_utc)
        if not isinstance(self.dependencies, VS01DependencySet):
            raise TypeError("dependencies must be VS01DependencySet")
        object.__setattr__(self, "input_contract", _frozen_mapping(self.input_contract))


@dataclass(frozen=True, slots=True)
class VS01Result:
    schema_version: str
    request_hash: str
    error_code: ErrorCode
    outcome_class: OutcomeClass
    output_contract: Mapping[str, Any]

    def __post_init__(self) -> None:
        _schema_version(self.schema_version)
        validate_hash_v1(self.request_hash)
        if not isinstance(self.error_code, ErrorCode):
            raise TypeError("error_code must be a frozen ErrorCode value")
        if not isinstance(self.outcome_class, OutcomeClass):
            raise TypeError("outcome_class must be a frozen OutcomeClass value")
        if self.outcome_class is not outcome_class_for(self.error_code):
            raise ValueError("outcome_class does not match error_code")
        object.__setattr__(self, "output_contract", _frozen_mapping(self.output_contract))
