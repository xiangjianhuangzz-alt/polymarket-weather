"""Foundational contracts for the V8 strategy candidate."""

from .canonical import (
    ExactDecimalV1,
    ScaledE12,
    canonical_encode,
    canonical_time_v1,
    hash_v1,
    parse_canonical_time_v1,
    validate_exact_fields,
)
from .contracts import (
    City,
    DatabaseRole,
    VS01DependencySet,
    VS01Request,
    VS01Result,
    VS01_EXECUTABLE,
    VS01_SKELETON_ONLY,
)
from .errors import ErrorCode, OutcomeClass, outcome_class_for

__all__ = [
    "City",
    "DatabaseRole",
    "ErrorCode",
    "ExactDecimalV1",
    "OutcomeClass",
    "ScaledE12",
    "VS01DependencySet",
    "VS01Request",
    "VS01Result",
    "VS01_EXECUTABLE",
    "VS01_SKELETON_ONLY",
    "canonical_encode",
    "canonical_time_v1",
    "hash_v1",
    "outcome_class_for",
    "parse_canonical_time_v1",
    "validate_exact_fields",
]
