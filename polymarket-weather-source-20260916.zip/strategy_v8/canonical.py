"""Canonical encoding, hashing, decimal, and UTC-time foundations."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import math
import re
import unicodedata
from collections.abc import Collection, Mapping
from typing import Any


CANONICAL_ENCODING_ID = "PWM-CANONICAL-UTF8-NFC-LF-JCS-V1"
_EXACT_DECIMAL_RE = re.compile(r"^-?(0|[1-9][0-9]*)(\.[0-9]*[1-9])?$")
_CANONICAL_TIME_RE = re.compile(
    r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{6}Z$"
)
_HEX64_RE = re.compile(r"^[0-9a-f]{64}$")
_MAX_SAFE_JSON_INTEGER = (1 << 53) - 1


def _require_nfc(value: str, label: str) -> str:
    if unicodedata.normalize("NFC", value) != value:
        raise ValueError(f"{label} must already be Unicode NFC")
    return value


def _canonical_value(value: Any) -> Any:
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, str):
        return _require_nfc(value, "string")
    if isinstance(value, int):
        if -_MAX_SAFE_JSON_INTEGER <= value <= _MAX_SAFE_JSON_INTEGER:
            return value
        try:
            as_binary64 = float(value)
        except OverflowError as exc:
            raise ValueError("integer is outside the finite JSON number range") from exc
        if not math.isfinite(as_binary64):
            raise ValueError("integer is outside the finite JSON number range")
        return as_binary64
    if isinstance(value, float):
        if not math.isfinite(value) or value == 0.0 and math.copysign(1.0, value) < 0:
            raise ValueError("non-finite and negative-zero JSON numbers are forbidden")
        return value
    if isinstance(value, ExactDecimalV1):
        return value.value
    if isinstance(value, ScaledE12):
        return value.value
    if isinstance(value, (list, tuple)):
        return [_canonical_value(item) for item in value]
    if isinstance(value, Mapping):
        if any(not isinstance(key, str) for key in value):
            raise TypeError("canonical object keys must be strings")
        normalized = [(_require_nfc(key, "object key"), item) for key, item in value.items()]
        normalized.sort(key=lambda pair: pair[0].encode("utf-16-be", "surrogatepass"))
        return {key: _canonical_value(item) for key, item in normalized}
    raise TypeError(f"unsupported canonical value type: {type(value).__name__}")


def _serialize_number(value: int | float) -> str:
    if isinstance(value, int):
        return str(value)
    if value == 0.0:
        return "0"

    negative = value < 0
    magnitude = -value if negative else value
    shortest = repr(magnitude).lower()
    decimal = Decimal(shortest)
    if Decimal("1e-6") <= decimal < Decimal("1e21"):
        rendered = format(decimal, "f")
        if "." in rendered:
            rendered = rendered.rstrip("0").rstrip(".")
    else:
        digits = decimal.as_tuple().digits
        coefficient = "".join(str(digit) for digit in digits).rstrip("0") or "0"
        exponent = decimal.adjusted()
        rendered = coefficient[0]
        if len(coefficient) > 1:
            rendered += "." + coefficient[1:]
        rendered += "e" + ("+" if exponent >= 0 else "") + str(exponent)
    return ("-" if negative else "") + rendered


def _serialize_canonical(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, (int, float)):
        return _serialize_number(value)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, list):
        return "[" + ",".join(_serialize_canonical(item) for item in value) + "]"
    if isinstance(value, dict):
        return "{" + ",".join(
            json.dumps(key, ensure_ascii=False) + ":" + _serialize_canonical(item)
            for key, item in value.items()
        ) + "}"
    raise TypeError(f"unsupported canonical value type: {type(value).__name__}")


def canonical_encode(payload: Any) -> bytes:
    """Encode an RFC 8785 JCS value as NFC UTF-8 bytes."""
    canonical = _canonical_value(payload)
    return _serialize_canonical(canonical).encode("utf-8")


def hash_v1(domain: str, payload: Any) -> str:
    """Return SHA256(UTF8_NFC(domain) || 0x00 || canonical(payload))."""
    domain_bytes = _require_nfc(domain, "domain").encode("utf-8")
    return hashlib.sha256(domain_bytes + b"\x00" + canonical_encode(payload)).hexdigest()


def validate_hash_v1(value: str) -> str:
    if not isinstance(value, str) or _HEX64_RE.fullmatch(value) is None:
        raise ValueError("HashV1 must be lowercase hexadecimal with exactly 64 characters")
    return value


@dataclass(frozen=True, slots=True)
class ExactDecimalV1:
    """A canonical base-10 value whose identity is its exact JSON string."""

    value: str

    def __post_init__(self) -> None:
        if not isinstance(self.value, str) or _EXACT_DECIMAL_RE.fullmatch(self.value) is None:
            raise ValueError("invalid ExactDecimalV1 representation")
        if Decimal(self.value).is_zero() and self.value.startswith("-"):
            raise ValueError("negative zero is forbidden")

    @property
    def decimal(self) -> Decimal:
        return Decimal(self.value)

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, slots=True)
class ScaledE12:
    """An integer probability/unit-cost identity scaled by 10^12."""

    value: int

    SCALE = 1_000_000_000_000

    def __post_init__(self) -> None:
        if isinstance(self.value, bool) or not isinstance(self.value, int):
            raise TypeError("ScaledE12 must be an integer")
        if not 0 <= self.value <= self.SCALE:
            raise ValueError("ScaledE12 must be between 0 and 10^12 inclusive")

    def display(self) -> str:
        return f"{self.value // self.SCALE}.{self.value % self.SCALE:012d}"


def canonical_time_v1(value: datetime) -> str:
    if not isinstance(value, datetime) or value.tzinfo is None:
        raise ValueError("an aware datetime is required")
    utc = value.astimezone(timezone.utc)
    return utc.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def parse_canonical_time_v1(value: str) -> datetime:
    if not isinstance(value, str) or _CANONICAL_TIME_RE.fullmatch(value) is None:
        raise ValueError("invalid CanonicalTimeV1 representation")
    try:
        parsed = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)
    except ValueError as exc:
        raise ValueError("CanonicalTimeV1 must be a valid Gregorian UTC instant") from exc
    if canonical_time_v1(parsed) != value:
        raise ValueError("non-canonical CanonicalTimeV1 representation")
    return parsed


def validate_exact_fields(
    value: Mapping[str, Any], expected_fields: Collection[str]
) -> Mapping[str, Any]:
    """Reject missing, duplicate-in-contract, and unknown field names."""
    if not isinstance(value, Mapping):
        raise TypeError("value must be a mapping")
    expected = tuple(expected_fields)
    if len(expected) != len(set(expected)):
        raise ValueError("expected field contract contains duplicates")
    actual = set(value)
    required = set(expected)
    missing = sorted(required - actual)
    unknown = sorted(actual - required)
    if missing or unknown:
        raise ValueError(f"exact-field mismatch: missing={missing}, unknown={unknown}")
    return value
