import json
import unittest
from pathlib import Path


BASE = Path(__file__).resolve().parent
PACKAGE = BASE / "runtime_tasks"


class RuntimeTaskPackageTests(unittest.TestCase):
    def setUp(self) -> None:
        self.manifest = json.loads(
            (PACKAGE / "runtime_tasks.json").read_text(encoding="utf-8")
        )
        self.script = (PACKAGE / "Register-DisabledRuntimeTasks.ps1").read_text(
            encoding="utf-8"
        )

    def test_manifest_contains_only_active_runtime_services(self) -> None:
        services = [task["service"] for task in self.manifest["tasks"]]
        self.assertEqual(
            services,
            [
                "collector",
                "realtime_stream",
                "metar_collector",
                "runtime_observer",
            ],
        )
        self.assertNotIn("auto_simulator", services)
        self.assertEqual(len(services), len(set(services)))
        rescue_services = [
            task["service"] for task in self.manifest["tasks"]
            if task["rescue_trigger"]
        ]
        self.assertEqual(rescue_services, ["runtime_observer"])
        self.assertFalse(self.manifest["settings"]["enabled"])
        self.assertEqual(self.manifest["registration_mode"], "disabled_only")

    def test_actions_reference_existing_safe_entrypoints(self) -> None:
        forbidden = ("service_supervisor", "bot.py", "LIVE_TRADING", "PRIVATE_KEY")
        for task in self.manifest["tasks"]:
            arguments = task["arguments"]
            self.assertFalse(any(token in arguments for token in forbidden))
            script_path = Path(arguments.split('"')[1])
            # An isolated worktree does not alter the main deployment path
            # until integration.  Validate the tracked entrypoint by name.
            self.assertTrue(
                script_path.is_file() or (BASE / script_path.name).is_file(),
                task["name"],
            )
        self.assertTrue(Path(self.manifest["python_executable"]).is_file())
        self.assertEqual(Path(self.manifest["python_executable"]).name.lower(), "pythonw.exe")
        self.assertTrue(Path(self.manifest["working_directory"]).is_dir())

    def test_registration_script_cannot_enable_or_start_tasks(self) -> None:
        self.assertIn('[string]$Mode = "Audit"', self.script)
        self.assertIn("-Disable", self.script)
        self.assertIn("REGISTER_DISABLED_RUNTIME_TASKS", self.script)
        self.assertNotIn("Enable-ScheduledTask", self.script)
        self.assertNotIn("Start-ScheduledTask", self.script)
        self.assertNotIn("-Force", self.script)
        self.assertNotIn("Unregister-ScheduledTask", self.script)

    def test_task_settings_are_non_disruptive(self) -> None:
        settings = self.manifest["settings"]
        self.assertEqual(settings["multiple_instances"], "IgnoreNew")
        self.assertEqual(settings["rescue_interval_minutes"], 1)
        self.assertGreaterEqual(settings["rescue_duration_days"], 365)
        self.assertEqual(settings["execution_time_limit"], "PT0S")
        self.assertTrue(settings["allow_start_on_batteries"])
        self.assertFalse(settings["stop_when_switching_to_batteries"])
        self.assertFalse(settings["run_only_if_network_available"])
        self.assertEqual(settings["run_level"], "Limited")
        self.assertIn("$RescueTrigger = New-ScheduledTaskTrigger", self.script)
        self.assertIn("-RepetitionInterval", self.script)
        self.assertIn("$TaskTriggers = if ($Task.rescue_trigger)", self.script)
        self.assertIn("@($LogonTrigger, $RescueTrigger)", self.script)
        self.assertIn("@($LogonTrigger)", self.script)
        self.assertIn("-Trigger $TaskTriggers", self.script)


if __name__ == "__main__":
    unittest.main()
