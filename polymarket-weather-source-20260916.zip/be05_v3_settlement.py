"""Fail-closed market settlement evidence for BE-05 V3.

The collector may observe a near-certain price after a target day has ended
while the market is still open.  That observation is useful research evidence,
but it is not a final settlement.  This module keeps provisional and final
observations separate and exposes only cryptographically self-consistent,
closed-market facts to V3 research, shadow, and paper consumers.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Sequence


CITY_SETTLEMENT_STATIONS = {
    "Beijing": "ZBAA",
    "Shanghai": "ZSPD",
    "Chengdu": "ZUUU",
    "Guangzhou": "ZGGG",
    "Shenzhen": "ZGSZ",
    "Wuhan": "ZHHH",
    "Chongqing": "ZUCK",
    "Jinan": "ZSJN",
    "Qingdao": "ZSQD",
    "Zhengzhou": "ZHCC",
}
_BUCKET_RE = re.compile(
    r"^-?\d+(?:\.\d+)?\s*(?:°|º|掳)?\s*C(?:\s+or\s+(?:higher|lower|below))?$",
    re.IGNORECASE,
)
_SCHEMA_COLUMNS = {
    "resolution_evidence_id",
    "observed_at",
    "market_id",
    "city",
    "station",
    "target_date",
    "question",
    "bucket_label",
    "yes_resolved",
    "yes_price",
    "outcome_prices_json",
    "resolution_source",
    "market_active",
    "market_closed",
    "state",
    "evidence_hash",
}


def ensure_settlement_schema(connection: sqlite3.Connection) -> None:
    """Install the append-only settlement ledger in the Collector-owned DB."""

    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS market_resolution_evidence (
          resolution_evidence_id TEXT PRIMARY KEY,
          observed_at TEXT NOT NULL,
          market_id TEXT NOT NULL,
          city TEXT NOT NULL,
          station TEXT NOT NULL,
          target_date TEXT NOT NULL,
          question TEXT NOT NULL,
          bucket_label TEXT NOT NULL,
          yes_resolved INTEGER,
          yes_price TEXT NOT NULL,
          outcome_prices_json TEXT NOT NULL,
          resolution_source TEXT NOT NULL,
          market_active INTEGER NOT NULL,
          market_closed INTEGER NOT NULL,
          state TEXT NOT NULL CHECK(state IN ('provisional','final')),
          evidence_hash TEXT NOT NULL,
          UNIQUE(market_id,state,evidence_hash)
        );
        CREATE INDEX IF NOT EXISTS idx_resolution_evidence_market_state
          ON market_resolution_evidence(market_id,state,observed_at);
        CREATE INDEX IF NOT EXISTS idx_resolution_evidence_city_date
          ON market_resolution_evidence(city,target_date,state,observed_at);
        """
    )


def _aware_iso(value: object) -> str | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.isoformat()


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _normalized_payload(
    *,
    market_id: str,
    city: str,
    station: str,
    target_date: str,
    question: str,
    bucket_label: str,
    yes_resolved: int | None,
    yes_price: str,
    outcome_prices_json: str,
    market_active: bool,
    market_closed: bool,
    state: str,
    resolution_source: str,
) -> dict[str, Any]:
    return {
        "bucket_label": bucket_label,
        "city": city,
        "market_active": int(market_active),
        "market_closed": int(market_closed),
        "market_id": market_id,
        "outcome_prices_json": outcome_prices_json,
        "question": question,
        "resolution_source": resolution_source,
        "state": state,
        "station": station,
        "target_date": target_date,
        "yes_price": yes_price,
        "yes_resolved": yes_resolved,
    }


def _payload_hash(payload: dict[str, Any]) -> str:
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _validated_prices(raw: object, yes_price: object) -> tuple[str, str] | None:
    if not isinstance(raw, str):
        return None
    try:
        values = json.loads(raw)
        price = Decimal(str(yes_price))
    except (json.JSONDecodeError, InvalidOperation, TypeError, ValueError):
        return None
    if not isinstance(values, list) or len(values) != 2 or not price.is_finite():
        return None
    normalized: list[str] = []
    for value in values:
        if isinstance(value, bool):
            return None
        try:
            decimal = Decimal(str(value))
        except (InvalidOperation, TypeError, ValueError):
            return None
        if not decimal.is_finite() or decimal < 0 or decimal > 1:
            return None
        normalized.append(format(decimal, "f"))
    if price < 0 or price > 1:
        return None
    return _canonical_json(normalized), format(price, "f")


def append_resolution_evidence(
    connection: sqlite3.Connection,
    *,
    observed_at: str,
    market_id: str,
    city: str,
    station: str,
    target_date: str,
    question: str,
    bucket_label: str,
    yes_resolved: int | None,
    yes_price: object,
    outcome_prices_json: str,
    resolution_source: str,
    market_active: bool,
    market_closed: bool,
    state: str,
) -> bool:
    """Append one validated observation; identical content is idempotent."""

    timestamp = _aware_iso(observed_at)
    if timestamp is None or not market_id or not question:
        return False
    if city not in CITY_SETTLEMENT_STATIONS or station != CITY_SETTLEMENT_STATIONS[city]:
        return False
    try:
        date.fromisoformat(target_date)
    except (TypeError, ValueError):
        return False
    if not isinstance(bucket_label, str) or not _BUCKET_RE.fullmatch(bucket_label.strip()):
        return False
    if type(market_active) is not bool or type(market_closed) is not bool:
        return False
    if state == "final":
        # Gamma's ``active`` flag is not the inverse of ``closed``.  A resolved
        # market can legitimately be active=true, closed=true; preserve that
        # upstream fact and use the explicit closed flag as the finality gate.
        if not market_closed or yes_resolved not in {0, 1}:
            return False
    elif state == "provisional":
        if not market_active or market_closed or yes_resolved != 1:
            return False
    else:
        return False
    prices = _validated_prices(outcome_prices_json, yes_price)
    if prices is None:
        return False
    normalized_prices, normalized_yes_price = prices
    if state == "final":
        try:
            final_prices = json.loads(normalized_prices)
            final_decimals = [Decimal(str(value)) for value in final_prices]
        except (InvalidOperation, TypeError, ValueError, json.JSONDecodeError):
            return False
        if (not isinstance(final_prices, list) or len(final_decimals) != 2
                or any(value not in {Decimal("0"), Decimal("1")} for value in final_decimals)
                or sum(final_decimals) != Decimal("1")
                or (yes_resolved == 1 and normalized_yes_price != "1")
                or (yes_resolved == 0 and normalized_yes_price != "0")):
            return False
    payload = _normalized_payload(
        market_id=market_id,
        city=city,
        station=station,
        target_date=target_date,
        question=question,
        bucket_label=bucket_label.strip(),
        yes_resolved=yes_resolved,
        yes_price=normalized_yes_price,
        outcome_prices_json=normalized_prices,
        market_active=market_active,
        market_closed=market_closed,
        state=state,
        resolution_source=resolution_source,
    )
    evidence_hash = _payload_hash(payload)
    evidence_id = f"resolution:{market_id}:{state}:{evidence_hash}"
    changed = connection.execute(
        """INSERT OR IGNORE INTO market_resolution_evidence
        (resolution_evidence_id,observed_at,market_id,city,station,target_date,
         question,bucket_label,yes_resolved,yes_price,outcome_prices_json,
         resolution_source,market_active,market_closed,state,evidence_hash)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            evidence_id,
            timestamp,
            market_id,
            city,
            station,
            target_date,
            question,
            bucket_label.strip(),
            yes_resolved,
            normalized_yes_price,
            normalized_prices,
            resolution_source,
            int(market_active),
            int(market_closed),
            state,
            evidence_hash,
        ),
    ).rowcount
    return bool(changed)


def _table_is_compatible(connection: sqlite3.Connection) -> bool:
    try:
        columns = {
            str(row[1])
            for row in connection.execute("PRAGMA table_info(market_resolution_evidence)")
        }
    except sqlite3.Error:
        return False
    return _SCHEMA_COLUMNS <= columns


def final_market_resolutions(
    connection: sqlite3.Connection,
    *,
    market_ids: Sequence[str] | None = None,
    city: str | None = None,
    target_date: str | None = None,
) -> list[dict[str, Any]]:
    """Return only final, self-consistent, non-conflicting market payouts."""

    if not _table_is_compatible(connection):
        return []
    clauses = ["state='final'"]
    parameters: list[Any] = []
    if market_ids is not None:
        unique_ids = list(dict.fromkeys(str(value) for value in market_ids if str(value)))
        if not unique_ids:
            return []
        clauses.append("market_id IN (" + ",".join("?" for _ in unique_ids) + ")")
        parameters.extend(unique_ids)
    if city is not None:
        clauses.append("city=?")
        parameters.append(city)
    if target_date is not None:
        clauses.append("target_date=?")
        parameters.append(target_date)
    try:
        rows = connection.execute(
            """SELECT observed_at,market_id,city,station,target_date,question,
                      bucket_label,yes_resolved,yes_price,outcome_prices_json,
                      resolution_source,market_active,market_closed,state,evidence_hash
                 FROM market_resolution_evidence
                WHERE """
            + " AND ".join(clauses)
            + " ORDER BY market_id,observed_at,evidence_hash",
            parameters,
        ).fetchall()
    except sqlite3.Error:
        return []
    grouped: dict[str, list[tuple[Any, ...]]] = {}
    for row in rows:
        grouped.setdefault(str(row[1]), []).append(tuple(row))
    accepted: list[dict[str, Any]] = []
    for market_id, candidates in grouped.items():
        valid: list[dict[str, Any]] = []
        for row in candidates:
            (
                observed_at,
                _market_id,
                row_city,
                station,
                row_target_date,
                question,
                bucket,
                yes_resolved,
                yes_price,
                prices,
                source,
                active,
                closed,
                state,
                evidence_hash,
            ) = row
            if _aware_iso(observed_at) is None or state != "final":
                continue
            if (type(active) is not int or active not in {0, 1}
                    or type(closed) is not int or closed != 1):
                continue
            if yes_resolved not in {0, 1}:
                continue
            normalized_prices = _validated_prices(prices, yes_price)
            if normalized_prices is None:
                continue
            if row_city not in CITY_SETTLEMENT_STATIONS:
                continue
            if station != CITY_SETTLEMENT_STATIONS[row_city]:
                continue
            try:
                date.fromisoformat(str(row_target_date))
            except ValueError:
                continue
            if not isinstance(bucket, str) or not _BUCKET_RE.fullmatch(bucket.strip()):
                continue
            payload = _normalized_payload(
                market_id=market_id,
                city=str(row_city),
                station=str(station),
                target_date=str(row_target_date),
                question=str(question),
                bucket_label=bucket.strip(),
                yes_resolved=int(yes_resolved),
                yes_price=normalized_prices[1],
                outcome_prices_json=normalized_prices[0],
                market_active=bool(active),
                market_closed=True,
                state="final",
                resolution_source=str(source),
            )
            if not isinstance(evidence_hash, str) or not math.isfinite(float(yes_price)):
                continue
            if _payload_hash(payload) != evidence_hash:
                continue
            try:
                final_prices = json.loads(normalized_prices[0])
                final_decimals = [Decimal(str(value)) for value in final_prices]
            except (InvalidOperation, TypeError, ValueError, json.JSONDecodeError):
                continue
            if (len(final_decimals) != 2
                    or any(value not in {Decimal("0"), Decimal("1")} for value in final_decimals)
                    or sum(final_decimals) != Decimal("1")
                    or (int(yes_resolved) == 1 and normalized_prices[1] != "1")
                    or (int(yes_resolved) == 0 and normalized_prices[1] != "0")):
                continue
            valid.append(
                {
                    "market_id": market_id,
                    "city": str(row_city),
                    "station": str(station),
                    "target_date": str(row_target_date),
                    "bucket_label": bucket.strip(),
                    "yes_resolved": int(yes_resolved),
                    "resolved_at": str(observed_at),
                    "resolution_source": str(source),
                    "resolution_hash": str(evidence_hash),
                }
            )
        identities = {
            (
                item["city"],
                item["station"],
                item["target_date"],
                item["bucket_label"],
                item["yes_resolved"],
                item["resolution_source"],
                item["resolution_hash"],
            )
            for item in valid
        }
        if len(identities) == 1:
            accepted.append(valid[-1])
    return sorted(accepted, key=lambda item: item["market_id"])


def final_resolution_map(
    connection: sqlite3.Connection,
    market_ids: Iterable[str],
    *,
    city: str,
    target_date: str,
) -> dict[str, dict[str, Any]]:
    rows = final_market_resolutions(
        connection,
        market_ids=list(market_ids),
        city=city,
        target_date=target_date,
    )
    return {str(row["market_id"]): row for row in rows}
