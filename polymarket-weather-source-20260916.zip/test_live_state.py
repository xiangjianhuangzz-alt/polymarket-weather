import asyncio
import json
import logging
import threading
import time
import unittest
from unittest.mock import Mock, patch

import websockets

import realtime_stream as stream
from realtime_stream import LiveStateHub


class _ClosedClient:
    closed = True


class _FailingClient:
    closed = False

    async def send(self, _payload):
        raise ConnectionError("local client disconnected")


class _SlowClient:
    closed = False

    def __init__(self):
        self.release = asyncio.Event()

    async def send(self, _payload):
        await self.release.wait()


class LiveStateHubTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.hub = LiveStateHub()
        # A random free port avoids touching the production shadow listener.
        self.hub.server = await websockets.serve(self.hub._client, "127.0.0.1", 0)
        self.port = self.hub.server.sockets[0].getsockname()[1]

    async def asyncTearDown(self):
        await self.hub.close()

    async def test_snapshot_then_delta_is_read_only(self):
        event = {"captured_at": "2026-07-22T00:00:00+00:00", "market": "m", "token": "t",
                 "bid": .2, "ask": .21, "bid_size": 10, "ask_size": 12,
                 "reason": "initial", "depth_fresh": True}
        self.hub.record_quote(event)
        async with websockets.connect(f"ws://127.0.0.1:{self.port}") as client:
            snapshot = json.loads(await client.recv())
            self.assertEqual(snapshot["type"], "snapshot")
            self.assertEqual(snapshot["token_count"], 1)
            self.assertEqual(snapshot["quotes"][0]["token_id"], "t")
            event["bid"] = .22
            event["captured_at"] = "2026-07-22T00:00:05+00:00"
            self.hub.record_quote(event)
            delta = json.loads(await client.recv())
            self.assertEqual(delta["type"], "bbo")
            self.assertEqual(delta["bid"], .22)
            await client.send("ping")
            self.assertEqual(json.loads(await client.recv())["type"], "pong")

    async def test_universe_switch_prunes_old_quotes_and_resyncs_client(self):
        self.hub.record_quote({"captured_at": "2026-07-22T00:00:00+00:00", "market": "old-market", "token": "old",
                               "bid": .2, "ask": .21, "bid_size": 1, "ask_size": 1,
                               "reason": "initial", "depth_fresh": True})
        self.hub.record_quote({"captured_at": "2026-07-22T00:00:00+00:00", "market": "active-market", "token": "active",
                               "bid": .3, "ask": .31, "bid_size": 1, "ask_size": 1,
                               "reason": "initial", "depth_fresh": True})
        async with websockets.connect(f"ws://127.0.0.1:{self.port}") as client:
            initial = json.loads(await client.recv())
            self.assertEqual(initial["token_count"], 2)
            self.hub.set_universe({"active": "active-market"})
            replacement = json.loads(await asyncio.wait_for(client.recv(), timeout=1))
            self.assertEqual(replacement["type"], "snapshot")
            self.assertEqual(replacement["token_count"], 1)
            self.assertEqual([quote["token_id"] for quote in replacement["quotes"]], ["active"])

    async def test_upstream_status_is_independent_from_quote_ticks(self):
        self.hub.record_stream_status(True, "connected")
        snapshot = self.hub.snapshot()

        self.assertTrue(snapshot["upstream"]["connected"])
        self.assertEqual(snapshot["schema"], 2)
        self.assertEqual(snapshot["stream_id"], self.hub.stream_id)

        self.hub.record_stream_status(False, "network reset")
        self.assertFalse(self.hub.snapshot()["upstream"]["connected"])

    async def test_closed_local_listener_recovers_without_upstream_restart(self):
        self.hub.server.close()
        await self.hub.server.wait_closed()
        self.hub.last_listener_attempt = -100.0

        with patch.object(stream, "STATE_HUB_PORT", 0):
            recovered = await self.hub.ensure_listener()

        self.assertTrue(recovered)
        self.assertTrue(self.hub.server.is_serving())
        self.assertEqual(self.hub.listener_restart_count, 1)

    async def test_closed_client_is_pruned_before_next_broadcast(self):
        client = _ClosedClient()
        self.hub.clients.add(client)

        with patch.object(stream.websockets, "broadcast") as legacy_broadcast:
            self.hub.record_stream_status(True, "connected")

        self.assertNotIn(client, self.hub.clients)
        legacy_broadcast.assert_not_called()

    async def test_failed_clients_emit_one_rate_limited_aggregate_warning(self):
        clients = [_FailingClient() for _ in range(8)]
        with patch.object(logging, "warning") as warning:
            for client in clients:
                self.hub._register_client(client)
            for sequence in range(100):
                self.hub.record_stream_status(True, f"tick={sequence}")
            await asyncio.sleep(0.05)

        self.assertEqual(self.hub.clients, set())
        self.assertEqual(self.hub.client_send_failures, len(clients))
        self.assertEqual(warning.call_count, 1)

    async def test_slow_client_never_delays_stream_heartbeat(self):
        client = _SlowClient()
        self.hub._register_client(client)
        writer = Mock()
        writer.submit_diagnostic.return_value = True
        progress = Mock()
        state = stream.StreamState(
            None, {}, writer, self.hub, "hash", stream.MarketProtocolShadow(),
            progress=progress,
        )

        started = time.monotonic()
        for sequence in range(self.hub.client_queue_size + 2):
            self.hub.record_stream_status(True, f"tick={sequence}")
        state.heartbeat("still live", force=True)

        self.assertLess(time.monotonic() - started, 0.1)
        writer.submit_diagnostic.assert_called_once()
        progress.publish.assert_called_once()
        client.release.set()

    async def test_slow_client_send_is_bounded_and_pruned(self):
        client = _SlowClient()
        with patch.object(stream, "STATE_HUB_CLIENT_SEND_DEADLINE_SECONDS", 0.01):
            self.hub._register_client(client)
            self.hub.record_stream_status(True, "tick")
            await asyncio.sleep(0.04)
        self.assertNotIn(client, self.hub.clients)
        self.assertEqual(self.hub.client_send_failures, 1)

    async def test_reconcile_deadline_does_not_pause_event_loop(self):
        blocker = asyncio.Event()

        def blocked_read(_path_shadow):
            while not blocker.is_set():
                time.sleep(0.01)
            return {"state": "shadow", "memory_tokens": 0}

        with patch.object(self.hub, "_reconcile_snapshot", side_effect=blocked_read):
            self.assertTrue(self.hub.schedule_reconcile(timeout=0.02, force=True))
            ticks = 0
            deadline = asyncio.get_running_loop().time() + 0.05
            while asyncio.get_running_loop().time() < deadline:
                ticks += 1
                await asyncio.sleep(0)
            await asyncio.sleep(0.03)

        blocker.set()
        self.assertGreater(ticks, 10)
        self.assertEqual(self.hub.shadow["state"], "reconcile_timeout")

    async def test_warmup_queries_in_worker_and_applies_on_event_loop(self):
        loop_thread = threading.get_ident()
        query_threads = []
        apply_threads = []
        rows = (("token", "market", "2026-08-09T00:00:00+00:00",
                 .2, .21, 10, 12, "initial", 1),)
        manifest = Mock()
        manifest.legacy_tuple.return_value = (["token"], {"token": "market"}, "hash")
        writer = Mock()

        def query_rows(_tokens):
            query_threads.append(threading.get_ident())
            return rows

        original_record = self.hub.record_quote

        def record_on_loop(event):
            apply_threads.append(threading.get_ident())
            original_record(event)

        with patch.object(stream, "subscription_manifest", return_value=manifest), \
             patch.object(self.hub, "read_persisted_rows", side_effect=query_rows, create=True), \
             patch.object(self.hub, "record_quote", side_effect=record_on_loop):
            _manifest, warmed = await stream.prepare_startup(self.hub, writer, timeout=0.5)

        self.assertEqual(warmed, 1)
        self.assertEqual(len(query_threads), 1)
        self.assertNotEqual(query_threads[0], loop_thread)
        self.assertEqual(apply_threads, [loop_thread])
        writer.start.assert_called_once()

    async def test_warmup_with_client_touches_queue_only_on_event_loop(self):
        loop_thread = threading.get_ident()
        client = _SlowClient()
        self.hub._register_client(client)
        queue_threads = []
        queue_for_client = self.hub.client_queues[client]
        original_put = queue_for_client.put_nowait

        def checked_put(payload):
            queue_threads.append(threading.get_ident())
            return original_put(payload)

        rows = (("token", "market", "2026-08-09T00:00:00+00:00",
                 .2, .21, 10, 12, "initial", 1),)
        manifest = Mock()
        manifest.legacy_tuple.return_value = (["token"], {"token": "market"}, "hash")
        with patch.object(stream, "subscription_manifest", return_value=manifest), \
             patch.object(self.hub, "read_persisted_rows", return_value=rows, create=True), \
             patch.object(queue_for_client, "put_nowait", side_effect=checked_put):
            await stream.prepare_startup(self.hub, Mock(), timeout=0.5)

        # One queue notification is the universe snapshot; the second is the
        # warmed BBO. Both must be emitted by the owning event-loop thread.
        self.assertGreaterEqual(len(queue_threads), 2)
        self.assertEqual(set(queue_threads), {loop_thread})
        client.release.set()

    async def test_warmup_snapshot_preserves_original_bbo_semantics(self):
        rows = (("token", "market", "2026-08-09T00:00:00+00:00",
                 .2, .21, 10, 12, "heartbeat", 1),)

        warmed = self.hub.apply_persisted_rows(rows)
        snapshot = self.hub.snapshot()

        self.assertEqual(warmed, 1)
        self.assertEqual(snapshot["token_count"], 1)
        quote = snapshot["quotes"][0]
        self.assertEqual(quote["token_id"], "token")
        self.assertEqual(quote["market_id"], "market")
        self.assertEqual(quote["captured_at"], "2026-08-09T00:00:00+00:00")
        self.assertEqual((quote["bid"], quote["ask"]), (.2, .21))
        self.assertEqual(quote["reason"], "heartbeat")
        self.assertTrue(quote["depth_fresh"])


if __name__ == "__main__":
    unittest.main()
