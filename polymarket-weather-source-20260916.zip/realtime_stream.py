"""Real-time Polymarket CLOB stream for the current tracked market universe.

This program records data only. It never has wallet credentials and cannot trade.
"""
from __future__ import annotations

import asyncio
import atexit
import contextlib
import hashlib
import json
import logging
import math
import os
import queue
import re
import sqlite3
import stat
import threading
import time
import unicodedata
import uuid
from collections import deque
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

import websockets
import httpx
from db_paths import REALTIME_DB, RESEARCH_DB
from runtime_status import WorkerProgressPublisher
from ui_events import ensure_realtime_events

BASE = Path(__file__).resolve().parent
# The websocket stream is the *only* writer of this database.  Market
# subscriptions are read from RESEARCH_DB below; never write them here.
DB = REALTIME_DB
WS = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
CLOB_BOOKS_URL = "https://clob.polymarket.com/books"
CHINA_TZ = timezone(timedelta(hours=8))
# Full intraday replay comes from compact 1/5-minute bars.  Raw BBO/depth is
# only short-lived evidence and has both time and row ceilings.
CAPACITY_MODEL_TOKEN_COUNT = 308
CAPACITY_NORMAL_RAW_ROWS_PER_HOUR = 73_877
CAPACITY_STRESS_MULTIPLIER = 2
CAPACITY_STRESS_LOGICAL_SECONDS = 5 * 60
CAPACITY_SAFETY_FACTOR = 1.25
CAPACITY_DEPTH_LEVELS_PER_SNAPSHOT = 10
RAW_QUOTE_MINIMUM_RETENTION_HOURS = 6
DEPTH_MINIMUM_RETENTION_HOURS = 6
MINUTE_BAR_MINIMUM_RETENTION_DAYS = 6
FIVE_MINUTE_BAR_MINIMUM_RETENTION_DAYS = 7
CAPACITY_ROUNDING_ROWS = 100_000
DEPTH_SNAPSHOT_SECONDS = float(os.getenv("DEPTH_SNAPSHOT_SECONDS", "300"))


def _effective_retention_period(configured: int | str, minimum: int) -> int:
    """Honor a longer explicit window while enforcing the scheme-A floor."""
    return max(int(minimum), int(configured))


def _rounded_capacity_rows(required_rows: float) -> int:
    required = max(0, math.ceil(required_rows))
    quantum = max(1, int(CAPACITY_ROUNDING_ROWS))
    return ((required + quantum - 1) // quantum) * quantum


def retention_capacity_plan() -> dict[str, Any]:
    """Return the frozen 308-token hot-store model used by code and tests.

    Raw/depth ceilings protect a full six hours at twice the observed/modelled
    ingress rate plus 25% safety margin.  BBO frequency does not multiply bar
    cardinality because bars upsert one token/bucket row, so compact products
    require their SLA cardinality plus the same safety margin.
    """
    raw_minimum = (
        CAPACITY_NORMAL_RAW_ROWS_PER_HOUR
        * RAW_QUOTE_MINIMUM_RETENTION_HOURS
    )
    raw_stress_required = (
        raw_minimum * CAPACITY_STRESS_MULTIPLIER * CAPACITY_SAFETY_FACTOR
    )
    depth_normal_rows_per_hour = math.ceil(
        CAPACITY_MODEL_TOKEN_COUNT
        * CAPACITY_DEPTH_LEVELS_PER_SNAPSHOT
        * 3600
        / max(1.0, DEPTH_SNAPSHOT_SECONDS)
    )
    depth_minimum = (
        depth_normal_rows_per_hour * DEPTH_MINIMUM_RETENTION_HOURS
    )
    depth_stress_required = (
        depth_minimum * CAPACITY_STRESS_MULTIPLIER * CAPACITY_SAFETY_FACTOR
    )
    minute_minimum = (
        CAPACITY_MODEL_TOKEN_COUNT
        * 60
        * 24
        * MINUTE_BAR_MINIMUM_RETENTION_DAYS
    )
    five_minute_minimum = (
        CAPACITY_MODEL_TOKEN_COUNT
        * 12
        * 24
        * FIVE_MINUTE_BAR_MINIMUM_RETENTION_DAYS
    )
    return {
        "token_count": CAPACITY_MODEL_TOKEN_COUNT,
        "stress_multiplier": CAPACITY_STRESS_MULTIPLIER,
        "stress_logical_seconds": CAPACITY_STRESS_LOGICAL_SECONDS,
        "safety_factor": CAPACITY_SAFETY_FACTOR,
        "raw": {
            "normal_rows_per_hour": CAPACITY_NORMAL_RAW_ROWS_PER_HOUR,
            "minimum_rows": raw_minimum,
            "stress_required_rows": math.ceil(raw_stress_required),
            "ceiling": _rounded_capacity_rows(raw_stress_required),
        },
        "depth": {
            "normal_rows_per_hour": depth_normal_rows_per_hour,
            "minimum_rows": depth_minimum,
            "stress_required_rows": math.ceil(depth_stress_required),
            "ceiling": _rounded_capacity_rows(depth_stress_required),
        },
        "minute_bar": {
            "minimum_rows": minute_minimum,
            "ceiling": _rounded_capacity_rows(
                minute_minimum * CAPACITY_SAFETY_FACTOR
            ),
        },
        "five_minute_bar": {
            "minimum_rows": five_minute_minimum,
            "ceiling": _rounded_capacity_rows(
                five_minute_minimum * CAPACITY_SAFETY_FACTOR
            ),
        },
    }


_CAPACITY_PLAN = retention_capacity_plan()
RAW_QUOTE_RETENTION_HOURS = _effective_retention_period(
    os.getenv(
        "RAW_QUOTE_RETENTION_HOURS",
        str(RAW_QUOTE_MINIMUM_RETENTION_HOURS),
    ),
    RAW_QUOTE_MINIMUM_RETENTION_HOURS,
)
DEPTH_RETENTION_HOURS = _effective_retention_period(
    os.getenv(
        "DEPTH_RETENTION_HOURS",
        str(DEPTH_MINIMUM_RETENTION_HOURS),
    ),
    DEPTH_MINIMUM_RETENTION_HOURS,
)
MINUTE_BAR_RETENTION_DAYS = _effective_retention_period(
    os.getenv(
        "MINUTE_BAR_RETENTION_DAYS",
        str(MINUTE_BAR_MINIMUM_RETENTION_DAYS),
    ),
    MINUTE_BAR_MINIMUM_RETENTION_DAYS,
)
FIVE_MINUTE_BAR_RETENTION_DAYS = _effective_retention_period(
    os.getenv(
        "FIVE_MINUTE_BAR_RETENTION_DAYS",
        str(FIVE_MINUTE_BAR_MINIMUM_RETENTION_DAYS),
    ),
    FIVE_MINUTE_BAR_MINIMUM_RETENTION_DAYS,
)
MAX_RAW_QUOTE_ROWS = max(
    int(_CAPACITY_PLAN["raw"]["ceiling"]),
    int(os.getenv("MAX_RAW_QUOTE_ROWS", str(_CAPACITY_PLAN["raw"]["ceiling"]))),
)
MAX_DEPTH_ROWS = max(
    int(_CAPACITY_PLAN["depth"]["ceiling"]),
    int(os.getenv("MAX_DEPTH_ROWS", str(_CAPACITY_PLAN["depth"]["ceiling"]))),
)
# A time window alone can still grow without bound as more markets/tokens are
# discovered.  These are hard ceilings for the compact replay products.
MAX_MINUTE_BAR_ROWS = max(
    int(_CAPACITY_PLAN["minute_bar"]["ceiling"]),
    int(os.getenv(
        "MAX_MINUTE_BAR_ROWS", str(_CAPACITY_PLAN["minute_bar"]["ceiling"])
    )),
)
MAX_FIVE_MINUTE_BAR_ROWS = max(
    int(_CAPACITY_PLAN["five_minute_bar"]["ceiling"]),
    int(os.getenv(
        "MAX_FIVE_MINUTE_BAR_ROWS",
        str(_CAPACITY_PLAN["five_minute_bar"]["ceiling"]),
    )),
)
LATEST_PROJECTION_RETENTION_HOURS = int(os.getenv("LATEST_PROJECTION_RETENTION_HOURS", "24"))
BBO_HEARTBEAT_SECONDS = float(os.getenv("BBO_HEARTBEAT_SECONDS", "15"))
BBO_PRICE_WRITE_SECONDS = float(os.getenv("BBO_PRICE_WRITE_SECONDS", "5"))
BBO_SIZE_CHANGE_MIN = float(os.getenv("BBO_SIZE_CHANGE_MIN", "5"))
BBO_SIZE_CHANGE_RATIO = float(os.getenv("BBO_SIZE_CHANGE_RATIO", "0.10"))
BBO_SIZE_WRITE_SECONDS = float(os.getenv("BBO_SIZE_WRITE_SECONDS", "30"))
BBO_HEARTBEAT_SCAN_SECONDS = 5.0
# One row is replaced in-place every five seconds.  This proves a live stream
# without multiplying BBO history; quiet-book BBO heartbeats remain at 15s.
HEARTBEAT_INTERVAL_SECONDS = 5.0
MAINTENANCE_INTERVAL_SECONDS = 600.0
PRUNE_BATCH_ROWS = int(os.getenv("PRUNE_BATCH_ROWS", "5000"))
# Online cleanup runs on the sole realtime SQLite writer.  A mistaken .env
# value must never turn one housekeeping slice into a 100k-row hot-path delete.
# This is a code-level safety ceiling, not a tuning knob.
MAX_ONLINE_PRUNE_BATCH_ROWS = 1000
ROW_CAP_ENFORCE_SECONDS = float(os.getenv("ROW_CAP_ENFORCE_SECONDS", "5"))
ROW_CAP_HEADROOM = int(os.getenv("ROW_CAP_HEADROOM", "1000"))
MAINTENANCE_BUDGET_SECONDS = float(os.getenv("MAINTENANCE_BUDGET_SECONDS", "0.10"))
MAINTENANCE_PROGRESS_OPS = int(os.getenv("MAINTENANCE_PROGRESS_OPS", "1000"))
MAINTENANCE_RETRY_SECONDS = float(os.getenv("MAINTENANCE_RETRY_SECONDS", "5"))
# The collector publishes immutable manifests while city markets open
# progressively.  Additions are subscribed on the existing connection.  A
# smaller intraday manifest is never trusted; rollover removal is permitted
# only for past target dates after the same candidate is observed twice.
SUBSCRIPTION_CHECK_INTERVAL_SECONDS = 15.0
ROLLBACK_REQUEST_PATH = (
    BASE / "data" / "runtime" / "control"
    / "universe_rollback_request.v1.json"
)
ROLLBACK_REQUEST_SCHEMA = "universe_rollback_request.v1"
ROLLBACK_REQUEST_MAX_BYTES = 8 * 1024
ROLLBACK_REQUEST_MAX_LIFETIME_SECONDS = 15 * 60
ROLLBACK_REQUEST_CHECK_INTERVAL_SECONDS = 5.0
ROLLBACK_REQUEST_READ_DEADLINE_SECONDS = 1.0
ROLLBACK_REQUEST_WARNING_INTERVAL_SECONDS = 30.0
# Collector and Realtime share the frozen China-time rollover window [00:00, 06:00).
# Keeping this code-level boundary prevents a runtime environment override from
# making publication and subscription acceptance disagree.
ROLLOVER_END_HOUR = 6
DYNAMIC_UNIVERSE_ENABLED = os.getenv(
    "DYNAMIC_UNIVERSE_ENABLED", "1"
).lower() in {"1", "true", "yes"}
STATE_HUB_ENABLED = os.getenv("STATE_HUB_ENABLED", "1").lower() in {"1", "true", "yes"}
DIRECT_LIVE_BBO_ENABLED = os.getenv(
    "DIRECT_LIVE_BBO_ENABLED", "1"
).lower() in {"1", "true", "yes"}
STATE_HUB_HOST = "127.0.0.1"
STATE_HUB_PORT = int(os.getenv("STATE_HUB_PORT", "8765"))
STATE_HUB_RECONCILE_SECONDS = float(os.getenv("STATE_HUB_RECONCILE_SECONDS", "30"))
STATE_HUB_READ_DEADLINE_SECONDS = float(os.getenv("STATE_HUB_READ_DEADLINE_SECONDS", "1"))
STATE_HUB_CLIENT_QUEUE_SIZE = 1024
STATE_HUB_CLIENT_WARNING_SECONDS = 30.0
# Drive maintenance while Polymarket's book is quiet.  StreamState still
# persists unchanged BBOs only on its own heartbeat schedule, so this does
# not increase quote-retention growth.
RECEIVE_MAINTENANCE_SECONDS = float(os.getenv("RECEIVE_MAINTENANCE_SECONDS", "5"))
# Polymarket's market channel requires an application-level text PING every
# ten seconds.  Keep the existing WebSocket control-frame heartbeat during the
# validation period; the text heartbeat below is observational and cannot
# change quote acceptance or consumer state.
APP_PING_INTERVAL_SECONDS = float(os.getenv("APP_PING_INTERVAL_SECONDS", "10"))
APP_PONG_STALE_SECONDS = float(os.getenv("APP_PONG_STALE_SECONDS", "30"))
# Every await on the upstream market control path must finish well before the
# guardian's stale-heartbeat window.  This is intentionally fixed rather than
# environment-configurable: a runtime override must never turn a safety
# deadline back into an unbounded wait.
STREAM_CONTROL_DEADLINE_SECONDS = 10.0
STATE_HUB_CLIENT_SEND_DEADLINE_SECONDS = 2.0
EXCHANGE_CLOCK_FUTURE_TOLERANCE_MS = float(
    os.getenv("EXCHANGE_CLOCK_FUTURE_TOLERANCE_MS", "5000")
)


async def _await_stream_control(
    operation: Any,
    stage: str,
    *,
    timeout: float = STREAM_CONTROL_DEADLINE_SECONDS,
) -> Any:
    bounded_timeout = min(
        STREAM_CONTROL_DEADLINE_SECONDS, max(0.01, float(timeout))
    )
    try:
        return await asyncio.wait_for(operation, timeout=bounded_timeout)
    except TimeoutError as exc:
        raise TimeoutError(f"{stage}_timeout") from exc


class AsyncSingleFlightRead:
    """Retain one to-thread read across caller deadlines until it is consumed."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.task: asyncio.Task[Any] | None = None
        self.starts = 0

    @property
    def in_flight(self) -> bool:
        # A completed result remains owned by this flight until the event loop
        # consumes it, so a second read cannot overtake the first result.
        return self.task is not None

    @property
    def done(self) -> bool:
        return self.task is not None and self.task.done()

    async def get(self, operation: Any, *args: Any, timeout: float) -> Any:
        if self.task is None:
            self.starts += 1
            self.task = asyncio.create_task(
                asyncio.to_thread(operation, *args),
                name=f"sqlite-read-{self.name}",
            )
        task = self.task
        try:
            result = await asyncio.wait_for(
                asyncio.shield(task), timeout=max(0.01, timeout)
            )
        except TimeoutError:
            # A SQLite call already executing in a worker cannot be cancelled.
            # Retain it so every retry observes this same underlying flight.
            raise
        except BaseException:
            if task.done():
                self.task = None
            raise
        self.task = None
        return result


class RollbackRequestError(ValueError):
    """A fixed-path rollback request failed its strict fail-closed contract."""


@dataclass(frozen=True)
class UniverseRollbackRequest:
    schema: str
    operation_id: str
    expected_current_hash: str
    target_previous_hash: str
    not_before: str
    expires_at: str
    reason: str

    @property
    def fingerprint(self) -> str:
        payload = {
            field: getattr(self, field)
            for field in (
                "schema", "operation_id", "expected_current_hash",
                "target_previous_hash", "not_before", "expires_at", "reason",
            )
        }
        encoded = json.dumps(
            payload, ensure_ascii=True, separators=(",", ":"), sort_keys=True,
        ).encode("ascii")
        return hashlib.sha256(encoded).hexdigest()


ROLLBACK_REQUEST_FIELDS = frozenset({
    "schema", "operation_id", "expected_current_hash",
    "target_previous_hash", "not_before", "expires_at", "reason",
})


def _rollback_json_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise RollbackRequestError(f"duplicate JSON key: {key}")
        value[key] = item
    return value


def _reject_json_constant(value: str) -> Any:
    raise RollbackRequestError(f"non-finite JSON value: {value}")


def _rollback_request_time(value: str, field: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise RollbackRequestError(f"{field} is not ISO time") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise RollbackRequestError(f"{field} must include a timezone")
    return parsed.astimezone(UTC)


def parse_rollback_request_payload(
    payload: Any,
    *,
    now: datetime | None = None,
) -> UniverseRollbackRequest:
    """Validate the complete native DTO without coercion or field projection."""
    if type(payload) is not dict or set(payload) != ROLLBACK_REQUEST_FIELDS:
        raise RollbackRequestError("rollback request fields are not exact")
    if any(
        type(payload[field]) is not str
        or not payload[field]
        or payload[field] != payload[field].strip()
        for field in ROLLBACK_REQUEST_FIELDS
    ):
        raise RollbackRequestError("rollback request fields must be native strings")
    request = UniverseRollbackRequest(**payload)
    if request.schema != ROLLBACK_REQUEST_SCHEMA:
        raise RollbackRequestError("rollback request schema is unsupported")
    if (
        len(request.operation_id) > 128
        or re.fullmatch(r"[A-Za-z0-9._:-]+", request.operation_id) is None
    ):
        raise RollbackRequestError("rollback operation_id is invalid")
    if not all(
        re.fullmatch(r"[0-9a-f]{64}", value) is not None
        for value in (
            request.expected_current_hash, request.target_previous_hash,
        )
    ):
        raise RollbackRequestError("rollback hash is invalid")
    if request.expected_current_hash == request.target_previous_hash:
        raise RollbackRequestError("rollback current and target hashes match")
    if (
        len(request.reason) > 256
        or any(unicodedata.category(character) == "Cc" for character in request.reason)
    ):
        raise RollbackRequestError("rollback reason is invalid")
    not_before = _rollback_request_time(request.not_before, "not_before")
    expires_at = _rollback_request_time(request.expires_at, "expires_at")
    reference = now or datetime.now(UTC)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise RollbackRequestError("rollback validation time must be timezone-aware")
    reference = reference.astimezone(UTC)
    if not not_before <= reference < expires_at:
        raise RollbackRequestError("rollback request is not active")
    lifetime = (expires_at - not_before).total_seconds()
    if lifetime <= 0 or lifetime > ROLLBACK_REQUEST_MAX_LIFETIME_SECONDS:
        raise RollbackRequestError("rollback request lifetime exceeds 15 minutes")
    return request


def read_rollback_request_file(
    path: str | os.PathLike[str] = ROLLBACK_REQUEST_PATH,
    now: datetime | None = None,
) -> UniverseRollbackRequest | None:
    """Read the one fixed local control file; never mutate or clean it."""
    request_path = Path(path)
    try:
        before = request_path.lstat()
    except FileNotFoundError:
        return None
    if stat.S_ISLNK(before.st_mode) or not stat.S_ISREG(before.st_mode):
        raise RollbackRequestError("rollback request is not a regular file")
    if before.st_size <= 0 or before.st_size > ROLLBACK_REQUEST_MAX_BYTES:
        raise RollbackRequestError("rollback request size is invalid")
    try:
        with request_path.open("rb") as handle:
            opened = os.fstat(handle.fileno())
            if not stat.S_ISREG(opened.st_mode):
                raise RollbackRequestError("opened rollback request is not regular")
            if (
                (before.st_dev, before.st_ino) != (opened.st_dev, opened.st_ino)
            ):
                raise RollbackRequestError("rollback request changed during open")
            raw = handle.read(ROLLBACK_REQUEST_MAX_BYTES + 1)
    except FileNotFoundError as exc:
        raise RollbackRequestError("rollback request changed during read") from exc
    if not raw or len(raw) > ROLLBACK_REQUEST_MAX_BYTES:
        raise RollbackRequestError("rollback request size is invalid")
    try:
        text = raw.decode("utf-8", errors="strict")
        payload = json.loads(
            text,
            object_pairs_hook=_rollback_json_pairs,
            parse_constant=_reject_json_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RollbackRequestError("rollback request is not strict UTF-8 JSON") from exc
    return parse_rollback_request_payload(payload, now=now)


ROW_COUNT_SPECS = {
    "book_snapshots": "SELECT COUNT(*) FROM book_snapshots",
    "orderbook_levels": "SELECT COUNT(*) FROM orderbook_levels",
    "book_price_bars:60": (
        "SELECT COUNT(*) FROM book_price_bars WHERE interval_seconds=60"
    ),
    "book_price_bars:300": (
        "SELECT COUNT(*) FROM book_price_bars WHERE interval_seconds=300"
    ),
}


def ensure_realtime_row_counts(db: sqlite3.Connection) -> None:
    """Install transaction-consistent row counters once per realtime DB.

    Existing databases pay one controlled bootstrap count per missing key.
    Normal maintenance reads four one-row counters and never rescans a live
    history table.
    """
    db.execute("""CREATE TABLE IF NOT EXISTS realtime_row_counts (
      table_key TEXT PRIMARY KEY, row_count INTEGER NOT NULL CHECK(row_count>=0),
      initialized_at TEXT NOT NULL)""")
    initialized_at = datetime.now(UTC).isoformat()
    for table_key, count_sql in ROW_COUNT_SPECS.items():
        exists = db.execute(
            "SELECT 1 FROM realtime_row_counts WHERE table_key=?", (table_key,)
        ).fetchone()
        if not exists:
            row_count = int(db.execute(count_sql).fetchone()[0])
            db.execute(
                "INSERT INTO realtime_row_counts VALUES (?,?,?)",
                (table_key, row_count, initialized_at),
            )

    triggers = {
        "trg_book_snapshots_count_insert": """
          CREATE TRIGGER IF NOT EXISTS trg_book_snapshots_count_insert
          AFTER INSERT ON book_snapshots BEGIN
            UPDATE realtime_row_counts SET row_count=row_count+1
            WHERE table_key='book_snapshots';
          END""",
        "trg_book_snapshots_count_delete": """
          CREATE TRIGGER IF NOT EXISTS trg_book_snapshots_count_delete
          AFTER DELETE ON book_snapshots BEGIN
            UPDATE realtime_row_counts SET row_count=MAX(0,row_count-1)
            WHERE table_key='book_snapshots';
          END""",
        "trg_orderbook_levels_count_insert": """
          CREATE TRIGGER IF NOT EXISTS trg_orderbook_levels_count_insert
          AFTER INSERT ON orderbook_levels BEGIN
            UPDATE realtime_row_counts SET row_count=row_count+1
            WHERE table_key='orderbook_levels';
          END""",
        "trg_orderbook_levels_count_delete": """
          CREATE TRIGGER IF NOT EXISTS trg_orderbook_levels_count_delete
          AFTER DELETE ON orderbook_levels BEGIN
            UPDATE realtime_row_counts SET row_count=MAX(0,row_count-1)
            WHERE table_key='orderbook_levels';
          END""",
        "trg_minute_bars_count_insert": """
          CREATE TRIGGER IF NOT EXISTS trg_minute_bars_count_insert
          AFTER INSERT ON book_price_bars WHEN NEW.interval_seconds=60 BEGIN
            UPDATE realtime_row_counts SET row_count=row_count+1
            WHERE table_key='book_price_bars:60';
          END""",
        "trg_minute_bars_count_delete": """
          CREATE TRIGGER IF NOT EXISTS trg_minute_bars_count_delete
          AFTER DELETE ON book_price_bars WHEN OLD.interval_seconds=60 BEGIN
            UPDATE realtime_row_counts SET row_count=MAX(0,row_count-1)
            WHERE table_key='book_price_bars:60';
          END""",
        "trg_five_minute_bars_count_insert": """
          CREATE TRIGGER IF NOT EXISTS trg_five_minute_bars_count_insert
          AFTER INSERT ON book_price_bars WHEN NEW.interval_seconds=300 BEGIN
            UPDATE realtime_row_counts SET row_count=row_count+1
            WHERE table_key='book_price_bars:300';
          END""",
        "trg_five_minute_bars_count_delete": """
          CREATE TRIGGER IF NOT EXISTS trg_five_minute_bars_count_delete
          AFTER DELETE ON book_price_bars WHEN OLD.interval_seconds=300 BEGIN
            UPDATE realtime_row_counts SET row_count=MAX(0,row_count-1)
            WHERE table_key='book_price_bars:300';
          END""",
    }
    for trigger_sql in triggers.values():
        db.execute(trigger_sql)


def connect() -> sqlite3.Connection:
    # Do not change journal_mode at runtime.  It is a database-wide operation
    # requiring an exclusive lock; WAL has already been enabled by the schema
    # bootstrap and the stream should coexist with dashboard readers.
    db = sqlite3.connect(DB, timeout=30)
    db.execute("PRAGMA busy_timeout=30000")
    db.execute("PRAGMA journal_size_limit=67108864")  # cap retained WAL at 64 MiB
    db.execute("PRAGMA wal_autocheckpoint=1000")
    db.execute("""CREATE TABLE IF NOT EXISTS service_heartbeats
      (service TEXT PRIMARY KEY, updated_at TEXT NOT NULL, detail TEXT)""")
    db.execute("""CREATE TABLE IF NOT EXISTS book_price_bars (
      interval_seconds INTEGER NOT NULL, bucket_at TEXT NOT NULL,
      market_id TEXT NOT NULL, token_id TEXT NOT NULL,
      open_mid REAL, high_mid REAL, low_mid REAL, close_mid REAL,
      close_bid REAL, close_ask REAL, close_bid_size REAL, close_ask_size REAL,
      min_spread REAL, max_spread REAL, sample_count INTEGER NOT NULL DEFAULT 0,
      last_event_at TEXT NOT NULL,
      PRIMARY KEY (interval_seconds, bucket_at, token_id))""")
    db.execute("""CREATE TABLE IF NOT EXISTS book_snapshots (
      captured_at TEXT NOT NULL, market_id TEXT NOT NULL, token_id TEXT NOT NULL,
      best_bid REAL, best_ask REAL, bid_size REAL, ask_size REAL,
      event_reason TEXT NOT NULL DEFAULT 'stream', depth_fresh INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (captured_at, token_id))""")
    db.execute("""CREATE TABLE IF NOT EXISTS orderbook_levels (
      captured_at TEXT NOT NULL, market_id TEXT NOT NULL, token_id TEXT NOT NULL,
      side TEXT NOT NULL, price REAL NOT NULL, size REAL NOT NULL,
      PRIMARY KEY (captured_at, token_id, side, price))""")
    db.execute("""CREATE TABLE IF NOT EXISTS strategy_checkpoints (
      checkpoint_id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
      market_id TEXT NOT NULL, token_id TEXT NOT NULL, action TEXT NOT NULL,
      reason TEXT NOT NULL, best_bid REAL, best_ask REAL,
      bid_size REAL, ask_size REAL, depth_json TEXT,
      quote_captured_at TEXT, metadata_json TEXT)""")
    columns = {row[1] for row in db.execute("PRAGMA table_info(book_snapshots)")}
    if "event_reason" not in columns:
        db.execute("ALTER TABLE book_snapshots ADD COLUMN event_reason TEXT NOT NULL DEFAULT 'legacy'")
    if "depth_fresh" not in columns:
        db.execute("ALTER TABLE book_snapshots ADD COLUMN depth_fresh INTEGER NOT NULL DEFAULT 0")
    db.execute("CREATE INDEX IF NOT EXISTS idx_bars_token_time ON book_price_bars(token_id, interval_seconds, bucket_at)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_strategy_checkpoints_time ON strategy_checkpoints(created_at, token_id)")
    db.execute("""CREATE TABLE IF NOT EXISTS latest_orderbook_levels (
      token_id TEXT NOT NULL, market_id TEXT NOT NULL, snapshot_at TEXT NOT NULL,
      side TEXT NOT NULL, price REAL NOT NULL, size REAL NOT NULL,
      PRIMARY KEY (token_id,side,price))""")
    db.execute("""CREATE TABLE IF NOT EXISTS latest_bbo (
      token_id TEXT PRIMARY KEY, market_id TEXT NOT NULL, captured_at TEXT NOT NULL,
      best_bid REAL, best_ask REAL, bid_size REAL, ask_size REAL,
      event_reason TEXT NOT NULL, depth_fresh INTEGER NOT NULL DEFAULT 0)""")
    db.execute("""CREATE TABLE IF NOT EXISTS market_rule_snapshots (
      captured_at TEXT NOT NULL, market_id TEXT NOT NULL, token_id TEXT NOT NULL,
      tick_size TEXT NOT NULL, min_order_size TEXT NOT NULL,
      neg_risk INTEGER NOT NULL CHECK(neg_risk IN (0,1)), book_hash TEXT NOT NULL,
      PRIMARY KEY (captured_at,token_id))""")
    db.execute("""CREATE TABLE IF NOT EXISTS latest_market_rules (
      token_id TEXT PRIMARY KEY, market_id TEXT NOT NULL, captured_at TEXT NOT NULL,
      tick_size TEXT NOT NULL, min_order_size TEXT NOT NULL,
      neg_risk INTEGER NOT NULL CHECK(neg_risk IN (0,1)), book_hash TEXT NOT NULL)""")
    db.execute(
        "CREATE INDEX IF NOT EXISTS idx_market_rules_token_time "
        "ON market_rule_snapshots(token_id,captured_at)"
    )
    db.execute("""CREATE TABLE IF NOT EXISTS stream_connection_events (
      event_at TEXT NOT NULL, event_type TEXT NOT NULL, detail TEXT,
      universe_hash TEXT, token_count INTEGER, added_tokens_json TEXT,
      removed_tokens_json TEXT,
      PRIMARY KEY (event_at, event_type))""")
    db.execute("""CREATE TABLE IF NOT EXISTS stream_protocol_shadow (
      service TEXT PRIMARY KEY, updated_at TEXT NOT NULL, metrics_json TEXT NOT NULL)""")
    db.execute("""CREATE TABLE IF NOT EXISTS stream_path_shadow (
      service TEXT PRIMARY KEY, updated_at TEXT NOT NULL, metrics_json TEXT NOT NULL)""")
    db.execute("CREATE INDEX IF NOT EXISTS idx_stream_connection_events_time ON stream_connection_events(event_at DESC)")
    # The quote revision is transaction-bound; the high-frequency payload
    # itself remains in the bounded local state hub, not this event outbox.
    ensure_realtime_row_counts(db)
    ensure_realtime_events(db)
    db.commit()
    return db


def runtime_heartbeat(
    writer: "PersistenceWriter",
    detail: str,
    progress: WorkerProgressPublisher | None = None,
) -> bool:
    """Queue a replaceable service state through the sole SQLite writer."""
    accepted = writer.submit_service_state(detail)
    if progress is not None:
        progress.publish("connecting", detail=detail)
    return accepted


def record_connection_event(writer: "PersistenceWriter", event_type: str, detail: str, *, universe_hash: str | None = None,
                            token_count: int | None = None, added: list[str] | None = None,
                            removed: list[str] | None = None) -> bool:
    """Queue a durable connection transition through the sole SQLite writer."""
    return writer.submit_connection_event(
        event_type,
        detail,
        universe_hash=universe_hash,
        token_count=token_count,
        added=added,
        removed=removed,
    )


class MaintenanceYielded(RuntimeError):
    """Cooperative housekeeping stop; live quotes always have priority."""


class UniverseReconnectRequired(ConnectionError):
    """The remote subscription may have changed; discard this websocket."""

    def __init__(
        self, message: str, *, recovery_manifest: "UniverseManifest",
    ) -> None:
        validated = revalidate_recovery_manifest(recovery_manifest)
        if validated is None:
            raise ValueError("reconnect recovery manifest is not independently valid")
        super().__init__(message)
        self.recovery_manifest = validated
        self.recovery_hash = validated.token_hash


def _maintenance_checkpoint(should_yield: Any | None) -> None:
    if should_yield is not None and should_yield():
        raise MaintenanceYielded("live quote waiting or maintenance budget exhausted")


def _online_prune_batch_rows() -> int:
    return max(1, min(int(PRUNE_BATCH_ROWS), int(MAX_ONLINE_PRUNE_BATCH_ROWS)))


def _five_minute_bucket_sql(timestamp_expression: str) -> str:
    """Map a UTC ISO timestamp to the exact stored 300-second bucket key."""
    return (
        f"strftime('%Y-%m-%dT%H:',{timestamp_expression}) || "
        f"printf('%02d:00+00:00',"
        f"(CAST(strftime('%M',{timestamp_expression}) AS INTEGER)/5)*5)"
    )


def _delete_over_cap(
    db: sqlite3.Connection,
    table: str,
    order_column: str,
    ceiling: int,
    *,
    counter_key: str,
    where_sql: str = "",
    where_params: tuple[Any, ...] = (),
    should_yield: Any | None = None,
) -> int:
    """Delete one bounded oldest batch using a transaction-consistent count.

    The count is maintained by triggers in the same transaction as each row
    mutation.  No recurring full-table scan or large OFFSET is needed.
    """
    _maintenance_checkpoint(should_yield)
    counter = db.execute(
        "SELECT row_count FROM realtime_row_counts WHERE table_key=?",
        (counter_key,),
    ).fetchone()
    if counter is None:
        raise RuntimeError(f"missing realtime row counter: {counter_key}")
    excess = max(0, int(counter[0]) - max(0, int(ceiling)))
    if excess <= 0:
        return 0
    where = f"WHERE {where_sql}" if where_sql else ""
    cursor = db.execute(
        f"""DELETE FROM {table} WHERE rowid IN (
          SELECT rowid FROM {table} {where}
          ORDER BY {order_column} ASC LIMIT ?)""",
        (*where_params, min(_online_prune_batch_rows(), excess)),
    )
    _maintenance_checkpoint(should_yield)
    return max(0, int(cursor.rowcount))


CAPACITY_PHASES = ("raw", "depth", "bar60", "bar300")
RETENTION_PHASES = ("raw_time", "depth_time", "bar60_time", "bar300_time", "latest")


def _utc_reference(now: datetime | None = None) -> datetime:
    reference = now or datetime.now(UTC)
    if reference.tzinfo is None:
        reference = reference.replace(tzinfo=UTC)
    return reference.astimezone(UTC)


def _minimum_retention_cutoff(phase: str, now: datetime | None = None) -> str:
    reference = _utc_reference(now)
    windows = {
        "raw": timedelta(hours=RAW_QUOTE_RETENTION_HOURS),
        "depth": timedelta(hours=DEPTH_RETENTION_HOURS),
        "bar60": timedelta(days=MINUTE_BAR_RETENTION_DAYS),
        "bar300": timedelta(days=FIVE_MINUTE_BAR_RETENTION_DAYS),
    }
    try:
        window = windows[phase]
    except KeyError as exc:
        raise ValueError(f"unknown capacity maintenance phase: {phase}") from exc
    return (reference - window).isoformat()


def enforce_row_cap_phase(
    db: sqlite3.Connection,
    phase: str,
    *,
    should_yield: Any | None = None,
    headroom: bool = True,
    now: datetime | None = None,
) -> int:
    """Close one row ceiling without deleting inside the frozen SLA window."""
    specs = {
        "raw": (
            "book_snapshots", "captured_at", MAX_RAW_QUOTE_ROWS,
            "book_snapshots", "captured_at < ?",
        ),
        "depth": (
            "orderbook_levels", "captured_at", MAX_DEPTH_ROWS,
            "orderbook_levels", "captured_at < ?",
        ),
        "bar60": (
            "book_price_bars", "bucket_at", MAX_MINUTE_BAR_ROWS,
            "book_price_bars:60", "interval_seconds=60 AND bucket_at < ?",
        ),
        "bar300": (
            "book_price_bars", "bucket_at", MAX_FIVE_MINUTE_BAR_ROWS,
            "book_price_bars:300", "interval_seconds=300 AND bucket_at < ?",
        ),
    }
    try:
        table, order_column, ceiling, counter_key, where_sql = specs[phase]
    except KeyError as exc:
        raise ValueError(f"unknown capacity maintenance phase: {phase}") from exc
    cutoff = _minimum_retention_cutoff(phase, now)
    target = max(
        0,
        int(ceiling) - (max(0, int(ROW_CAP_HEADROOM)) if headroom else 0),
    )
    return _delete_over_cap(
        db, table, order_column, target, counter_key=counter_key,
        where_sql=where_sql, where_params=(cutoff,),
        should_yield=should_yield,
    )


def prune_retention_phase(
    db: sqlite3.Connection,
    phase: str,
    *,
    should_yield: Any | None = None,
    now: datetime | None = None,
) -> int:
    """Run one time-retention/projection phase without bundling other deletes."""
    batch_rows = _online_prune_batch_rows()
    reference = _utc_reference(now)
    quote_cutoff = (
        reference - timedelta(hours=RAW_QUOTE_RETENTION_HOURS)
    ).isoformat()
    _maintenance_checkpoint(should_yield)
    if phase == "raw_time":
        bucket_sql = _five_minute_bucket_sql("raw.captured_at")
        cursor = db.execute(f"""DELETE FROM book_snapshots WHERE rowid IN (
          SELECT raw.rowid FROM book_snapshots AS raw WHERE captured_at < ? AND EXISTS (
            SELECT 1 FROM book_price_bars b WHERE b.token_id=raw.token_id AND b.interval_seconds=300
              AND b.bucket_at={bucket_sql})
          ORDER BY raw.captured_at ASC LIMIT ?)""", (quote_cutoff, batch_rows))
        _maintenance_checkpoint(should_yield)
        return max(0, int(cursor.rowcount))

    depth_cutoff = (
        reference - timedelta(hours=DEPTH_RETENTION_HOURS)
    ).isoformat()
    if phase == "depth_time":
        bucket_sql = _five_minute_bucket_sql("raw.captured_at")
        cursor = db.execute(f"""DELETE FROM orderbook_levels WHERE rowid IN (
          SELECT raw.rowid FROM orderbook_levels AS raw WHERE captured_at < ? AND EXISTS (
            SELECT 1 FROM book_price_bars b WHERE b.token_id=raw.token_id AND b.interval_seconds=300
              AND b.bucket_at={bucket_sql})
          ORDER BY raw.captured_at ASC LIMIT ?)""", (depth_cutoff, batch_rows))
        _maintenance_checkpoint(should_yield)
        return max(0, int(cursor.rowcount))

    minute_cutoff = (
        reference - timedelta(days=MINUTE_BAR_RETENTION_DAYS)
    ).isoformat()
    if phase == "bar60_time":
        cursor = db.execute("""DELETE FROM book_price_bars WHERE rowid IN (
          SELECT rowid FROM book_price_bars
          WHERE interval_seconds=60 AND bucket_at < ?
          ORDER BY bucket_at ASC LIMIT ?)""", (minute_cutoff, batch_rows))
        _maintenance_checkpoint(should_yield)
        return max(0, int(cursor.rowcount))

    five_minute_cutoff = (
        reference - timedelta(days=FIVE_MINUTE_BAR_RETENTION_DAYS)
    ).isoformat()
    if phase == "bar300_time":
        cursor = db.execute("""DELETE FROM book_price_bars WHERE rowid IN (
          SELECT rowid FROM book_price_bars
          WHERE interval_seconds=300 AND bucket_at < ?
          ORDER BY bucket_at ASC LIMIT ?)""", (five_minute_cutoff, batch_rows))
        _maintenance_checkpoint(should_yield)
        return max(0, int(cursor.rowcount))

    if phase != "latest":
        raise ValueError(f"unknown retention maintenance phase: {phase}")

    deleted = 0
    # ``latest_*`` is a live projection, never long-term evidence.  Remove a
    # closed token only when it is both old and absent from the last completed
    # collector manifest.  Failure to read that manifest is deliberately a
    # no-op, not a risky broad delete.
    active_tokens = published_token_ids()
    _maintenance_checkpoint(should_yield)
    if active_tokens is not None:
        cutoff = (
            reference - timedelta(hours=LATEST_PROJECTION_RETENTION_HOURS)
        ).isoformat()
        if active_tokens:
            marks = ",".join("?" for _ in active_tokens)
            cursor = db.execute(f"""DELETE FROM latest_bbo WHERE rowid IN (
              SELECT rowid FROM latest_bbo WHERE captured_at < ?
                AND token_id NOT IN ({marks}) ORDER BY captured_at ASC LIMIT ?)""",
                                (cutoff, *sorted(active_tokens), batch_rows))
            deleted += max(0, int(cursor.rowcount))
            cursor = db.execute(f"""DELETE FROM latest_orderbook_levels WHERE rowid IN (
              SELECT rowid FROM latest_orderbook_levels WHERE snapshot_at < ?
                AND token_id NOT IN ({marks}) ORDER BY snapshot_at ASC LIMIT ?)""",
                                (cutoff, *sorted(active_tokens), batch_rows))
            deleted += max(0, int(cursor.rowcount))
    _maintenance_checkpoint(should_yield)
    return deleted


def prune_old_prices(
    db: sqlite3.Connection,
    *,
    should_yield: Any | None = None,
) -> int:
    """Compatibility/offline cycle; the live writer commits each phase alone."""
    deleted = 0
    for phase in RETENTION_PHASES:
        deleted += prune_retention_phase(db, phase, should_yield=should_yield)
    for phase in CAPACITY_PHASES:
        deleted += enforce_row_cap_phase(
            db, phase, should_yield=should_yield, headroom=False,
        )
    return deleted


def enforce_near_term_row_caps(
    db: sqlite3.Connection,
    *,
    should_yield: Any | None = None,
) -> int:
    """Keep bursty writes below the advertised hard ceilings between prunes.

    The regular retention job retains by time and is intentionally infrequent.
    This tiny guard runs only every few seconds and trims to a small buffer
    below the ceiling, so a normal websocket burst cannot make any retained
    replay product grow without bound.
    """
    deleted = 0
    for phase in CAPACITY_PHASES:
        deleted += enforce_row_cap_phase(db, phase, should_yield=should_yield)
    return deleted


def upsert_price_bar(db: sqlite3.Connection, interval_seconds: int, captured_at: datetime,
                     market: str, token: str, bid: float | None, ask: float | None,
                     bid_size: float | None, ask_size: float | None) -> None:
    bucket_epoch = int(captured_at.timestamp()) // interval_seconds * interval_seconds
    bucket_at = datetime.fromtimestamp(bucket_epoch, UTC).isoformat()
    mid = (bid + ask) / 2 if bid is not None and ask is not None else None
    spread = ask - bid if bid is not None and ask is not None else None
    db.execute("""INSERT INTO book_price_bars (
      interval_seconds,bucket_at,market_id,token_id,open_mid,high_mid,low_mid,close_mid,
      close_bid,close_ask,close_bid_size,close_ask_size,min_spread,max_spread,sample_count,last_event_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?)
      ON CONFLICT(interval_seconds,bucket_at,token_id) DO UPDATE SET
        open_mid=COALESCE(open_mid,excluded.open_mid),
        high_mid=CASE WHEN excluded.high_mid IS NULL THEN high_mid WHEN high_mid IS NULL OR excluded.high_mid>high_mid THEN excluded.high_mid ELSE high_mid END,
        low_mid=CASE WHEN excluded.low_mid IS NULL THEN low_mid WHEN low_mid IS NULL OR excluded.low_mid<low_mid THEN excluded.low_mid ELSE low_mid END,
        close_mid=COALESCE(excluded.close_mid,close_mid),
        close_bid=COALESCE(excluded.close_bid,close_bid), close_ask=COALESCE(excluded.close_ask,close_ask),
        close_bid_size=COALESCE(excluded.close_bid_size,close_bid_size),
        close_ask_size=COALESCE(excluded.close_ask_size,close_ask_size),
        min_spread=CASE WHEN excluded.min_spread IS NULL THEN min_spread WHEN min_spread IS NULL OR excluded.min_spread<min_spread THEN excluded.min_spread ELSE min_spread END,
        max_spread=CASE WHEN excluded.max_spread IS NULL THEN max_spread WHEN max_spread IS NULL OR excluded.max_spread>max_spread THEN excluded.max_spread ELSE max_spread END,
        sample_count=sample_count+1,last_event_at=excluded.last_event_at""",
      (interval_seconds,bucket_at,market,token,mid,mid,mid,mid,bid,ask,bid_size,ask_size,
       spread,spread,captured_at.isoformat()))


def persist_quote_event(db: sqlite3.Connection, event: dict[str, Any]) -> None:
    captured_at = str(event["captured_at"])
    db.execute("""INSERT INTO book_snapshots
      (captured_at,market_id,token_id,best_bid,best_ask,bid_size,ask_size,event_reason,depth_fresh)
      VALUES (?,?,?,?,?,?,?,?,?)
      ON CONFLICT(captured_at,token_id) DO UPDATE SET
        market_id=excluded.market_id,best_bid=excluded.best_bid,
        best_ask=excluded.best_ask,bid_size=excluded.bid_size,
        ask_size=excluded.ask_size,event_reason=excluded.event_reason,
        depth_fresh=excluded.depth_fresh""",
      (captured_at,event["market"],event["token"],event["bid"],event["ask"],
       event["bid_size"],event["ask_size"],event["reason"],int(bool(event["depth_fresh"]))))
    # The live dashboard and paper engine need only the current BBO.  Keep it
    # in a bounded one-row-per-token projection so they never aggregate the
    # multi-gigabyte history table in the hot path.
    db.execute("""INSERT INTO latest_bbo
      (token_id,market_id,captured_at,best_bid,best_ask,bid_size,ask_size,event_reason,depth_fresh)
      VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(token_id) DO UPDATE SET
      market_id=excluded.market_id,captured_at=excluded.captured_at,
      best_bid=excluded.best_bid,best_ask=excluded.best_ask,
      bid_size=excluded.bid_size,ask_size=excluded.ask_size,
      event_reason=excluded.event_reason,depth_fresh=excluded.depth_fresh""",
      (event["token"],event["market"],captured_at,event["bid"],event["ask"],event["bid_size"],
       event["ask_size"],event["reason"],int(bool(event["depth_fresh"]))))
    rules = event.get("market_rules")
    if isinstance(rules, dict):
        current = db.execute(
            """SELECT market_id,tick_size,min_order_size,neg_risk
                 FROM latest_market_rules WHERE token_id=?""",
            (event["token"],),
        ).fetchone()
        rule_state = (
            event["market"], rules["tick_size"], rules["min_order_size"],
            int(rules["neg_risk"]),
        )
        if current is not None and tuple(current) == rule_state:
            rules = None
    if isinstance(rules, dict):
        values = (
            captured_at,
            event["market"],
            event["token"],
            rules["tick_size"],
            rules["min_order_size"],
            int(rules["neg_risk"]),
            rules["book_hash"],
        )
        db.execute(
            """INSERT OR IGNORE INTO market_rule_snapshots
            (captured_at,market_id,token_id,tick_size,min_order_size,neg_risk,book_hash)
            VALUES (?,?,?,?,?,?,?)""",
            values,
        )
        db.execute(
            """INSERT INTO latest_market_rules
            (captured_at,market_id,token_id,tick_size,min_order_size,neg_risk,book_hash)
            VALUES (?,?,?,?,?,?,?) ON CONFLICT(token_id) DO UPDATE SET
              captured_at=excluded.captured_at,market_id=excluded.market_id,
              tick_size=excluded.tick_size,min_order_size=excluded.min_order_size,
              neg_risk=excluded.neg_risk,book_hash=excluded.book_hash""",
            values,
        )
    captured_dt = datetime.fromisoformat(captured_at)
    for interval in (60, 300):
        upsert_price_bar(db, interval, captured_dt, event["market"], event["token"],
                         event["bid"], event["ask"], event["bid_size"], event["ask_size"])
    for side, price, size in event.get("levels", []):
        db.execute("""INSERT INTO orderbook_levels
          (captured_at,market_id,token_id,side,price,size) VALUES (?,?,?,?,?,?)
          ON CONFLICT(captured_at,token_id,side,price) DO UPDATE SET
            market_id=excluded.market_id,size=excluded.size""",
          (captured_at,event["market"],event["token"],side,price,size))
    latest_levels = event.get("latest_levels", [])
    if latest_levels:
        db.execute("DELETE FROM latest_orderbook_levels WHERE token_id=?", (event["token"],))
        db.executemany("""INSERT INTO latest_orderbook_levels
          (token_id,market_id,snapshot_at,side,price,size) VALUES (?,?,?,?,?,?)""",
          [(event["token"],event["market"],captured_at,side,price,size)
           for side,price,size in latest_levels])


class PersistenceWriter:
    """Keep SQLite latency away from the websocket receive path."""
    def __init__(self, maxsize: int = 20000, on_committed: Any | None = None) -> None:
        self.events: queue.Queue[dict[str, Any] | None] = queue.Queue(maxsize=maxsize)
        self.thread = threading.Thread(target=self._run, name="quote-persistence", daemon=True)
        self.stopping = threading.Event()
        self.dropped_heartbeats = 0
        self.dropped_critical = 0
        self.last_error: str | None = None
        # Called only after the SQLite transaction containing the quote batch
        # commits.  It must be non-blocking (the runtime passes an event-loop
        # scheduler), so persistence never waits on dashboard clients.
        self.on_committed = on_committed
        self._maintenance_lock = threading.Lock()
        self._maintenance_metrics: dict[str, Any] = {
            "kind": "none",
            "status": "never",
            "duration_ms": 0.0,
            "rows_deleted": 0,
            "rows_deleted_total": 0,
            "queue_before": 0,
            "queue_after": 0,
            "queue_peak": 0,
            "runs": 0,
            "preemptions": 0,
            "overruns": 0,
            "failures": 0,
            "completed_at": None,
        }
        self._capacity_phase_index = 0
        self._retention_phase_index = 0

    def start(self) -> None:
        self.thread.start()

    def _observe_queue_depth(self) -> None:
        depth = self.events.qsize()
        with self._maintenance_lock:
            if depth > int(self._maintenance_metrics["queue_peak"]):
                self._maintenance_metrics["queue_peak"] = depth

    def submit(self, event: dict[str, Any]) -> bool:
        if self.stopping.is_set() or not self.thread.is_alive():
            self.dropped_critical += int(event.get("reason") != "heartbeat")
            return False
        try:
            self.events.put_nowait(event)
            self._observe_queue_depth()
            return True
        except queue.Full:
            if event.get("reason") == "heartbeat":
                self.dropped_heartbeats += 1
                return False
            try:
                self.events.put(event, timeout=0.25)
                self._observe_queue_depth()
                return True
            except queue.Full:
                self.dropped_critical += 1
                logging.error("persistence queue full; critical quote event rejected token=%s", event.get("token"))
                return False

    def submit_diagnostic(
        self,
        detail: str,
        protocol: dict[str, Any],
        path_shadow: dict[str, Any],
    ) -> bool:
        return self.submit({
            "_kind": "diagnostic",
            "reason": "heartbeat",
            "occurred_at": datetime.now(UTC).isoformat(),
            "detail": str(detail)[:500],
            "protocol": dict(protocol),
            "path_shadow": dict(path_shadow),
        })

    def submit_service_state(self, detail: str) -> bool:
        return self.submit({
            "_kind": "service_state",
            "reason": "heartbeat",
            "occurred_at": datetime.now(UTC).isoformat(),
            "detail": str(detail)[:500],
        })

    def submit_connection_event(
        self,
        event_type: str,
        detail: str,
        *,
        universe_hash: str | None = None,
        token_count: int | None = None,
        added: list[str] | None = None,
        removed: list[str] | None = None,
    ) -> bool:
        return self.submit({
            "_kind": "connection_event",
            "reason": "connection_event",
            "occurred_at": datetime.now(UTC).isoformat(),
            "event_type": str(event_type),
            "detail": str(detail)[:500],
            "universe_hash": universe_hash,
            "token_count": token_count,
            "added": list(added or []),
            "removed": list(removed or []),
        })

    def submit_market_rules(
        self,
        *,
        token_id: str,
        market_id: str,
        captured_at: str,
        rules: dict[str, Any],
    ) -> bool:
        return self.submit({
            "_kind": "market_rules",
            "reason": "market_rules",
            "occurred_at": captured_at,
            "token": token_id,
            "market": market_id,
            "market_rules": dict(rules),
        })

    @staticmethod
    def _persist_control_event(db: sqlite3.Connection, event: dict[str, Any]) -> None:
        kind = event.get("_kind")
        occurred_at = str(event.get("occurred_at") or datetime.now(UTC).isoformat())
        if kind in {"diagnostic", "service_state"}:
            db.execute(
                "INSERT OR REPLACE INTO service_heartbeats VALUES (?,?,?)",
                ("realtime_stream", occurred_at, str(event.get("detail") or "")[:500]),
            )
            if kind == "diagnostic":
                db.execute(
                    """INSERT OR REPLACE INTO stream_protocol_shadow
                    (service,updated_at,metrics_json) VALUES (?,?,?)""",
                    (
                        "market_channel",
                        occurred_at,
                        json.dumps(event.get("protocol") or {}, separators=(",", ":")),
                    ),
                )
                db.execute(
                    """INSERT OR REPLACE INTO stream_path_shadow
                    (service,updated_at,metrics_json) VALUES (?,?,?)""",
                    (
                        "ingress_commit",
                        occurred_at,
                        json.dumps(event.get("path_shadow") or {}, separators=(",", ":")),
                    ),
                )
            return
        if kind == "connection_event":
            db.execute(
                """INSERT INTO stream_connection_events
                (event_at,event_type,detail,universe_hash,token_count,added_tokens_json,removed_tokens_json)
                VALUES (?,?,?,?,?,?,?)""",
                (
                    occurred_at,
                    str(event.get("event_type") or "unknown"),
                    str(event.get("detail") or "")[:500],
                    event.get("universe_hash"),
                    event.get("token_count"),
                    json.dumps(event.get("added") or []),
                    json.dumps(event.get("removed") or []),
                ),
            )
            return
        if kind == "market_rules":
            rules = event.get("market_rules")
            if not isinstance(rules, dict):
                raise ValueError("market rules payload missing")
            captured_at = occurred_at
            current = db.execute(
                """SELECT market_id,tick_size,min_order_size,neg_risk
                     FROM latest_market_rules WHERE token_id=?""",
                (event["token"],),
            ).fetchone()
            state = (
                event["market"], rules["tick_size"], rules["min_order_size"],
                int(rules["neg_risk"]),
            )
            if current is not None and tuple(current) == state:
                return
            values = (
                captured_at, event["market"], event["token"],
                rules["tick_size"], rules["min_order_size"],
                int(rules["neg_risk"]), rules["book_hash"],
            )
            db.execute(
                """INSERT OR IGNORE INTO market_rule_snapshots
                (captured_at,market_id,token_id,tick_size,min_order_size,neg_risk,book_hash)
                VALUES (?,?,?,?,?,?,?)""",
                values,
            )
            db.execute(
                """INSERT INTO latest_market_rules
                (captured_at,market_id,token_id,tick_size,min_order_size,neg_risk,book_hash)
                VALUES (?,?,?,?,?,?,?) ON CONFLICT(token_id) DO UPDATE SET
                  captured_at=excluded.captured_at,market_id=excluded.market_id,
                  tick_size=excluded.tick_size,min_order_size=excluded.min_order_size,
                  neg_risk=excluded.neg_risk,book_hash=excluded.book_hash""",
                values,
            )
            return
        raise ValueError(f"unknown persistence control event: {kind}")

    def close(self) -> None:
        if self.stopping.is_set():
            return
        self.stopping.set()
        try:
            self.events.put_nowait(None)
        except queue.Full:
            pass
        self.thread.join(timeout=10)

    def health(self) -> str:
        """Separate a recoverable SQLite retry from a dead writer thread."""
        if not self.thread.is_alive():
            return "dead"
        return "retrying" if self.last_error else "ok"

    def maintenance_snapshot(self) -> dict[str, Any]:
        with self._maintenance_lock:
            return dict(self._maintenance_metrics)

    def maintenance_status_fragment(self) -> str:
        metrics = self.maintenance_snapshot()
        return (
            f"maint={metrics['kind']}:{metrics['status']}:"
            f"{metrics['duration_ms']:.0f}ms:rows={metrics['rows_deleted']}:"
            f"total={metrics['rows_deleted_total']}:peak={metrics['queue_peak']}:"
            f"q={metrics['queue_before']}/{metrics['queue_after']}:"
            f"p={metrics['preemptions']}:o={metrics['overruns']}:f={metrics['failures']}"
        )

    def _record_maintenance(
        self,
        *,
        kind: str,
        status: str,
        started: float,
        rows_deleted: int,
        queue_before: int,
    ) -> None:
        duration_ms = max(0.0, (time.monotonic() - started) * 1000.0)
        queue_after = self.events.qsize()
        with self._maintenance_lock:
            metrics = dict(self._maintenance_metrics)
            metrics.update({
                "kind": kind,
                "status": status,
                "duration_ms": duration_ms,
                "rows_deleted": max(0, int(rows_deleted)),
                "queue_before": max(0, int(queue_before)),
                "queue_after": max(0, int(queue_after)),
                "completed_at": datetime.now(UTC).isoformat(),
            })
            if status == "ok":
                metrics["runs"] = int(metrics["runs"]) + 1
                metrics["rows_deleted_total"] = (
                    int(metrics["rows_deleted_total"])
                    + max(0, int(rows_deleted))
                )
            elif status == "preempted":
                metrics["preemptions"] = int(metrics["preemptions"]) + 1
            elif status == "budget_exceeded":
                metrics["overruns"] = int(metrics["overruns"]) + 1
            else:
                metrics["failures"] = int(metrics["failures"]) + 1
            metrics["queue_peak"] = max(
                int(metrics["queue_peak"]),
                max(0, int(queue_before)),
                max(0, int(queue_after)),
            )
            self._maintenance_metrics = metrics
        logging.info(
            "quote persistence maintenance kind=%s status=%s duration_ms=%.1f "
            "rows_deleted=%d queue_before=%d queue_after=%d",
            kind, status, duration_ms, rows_deleted, queue_before, queue_after,
        )

    def _run_bounded_maintenance(
        self,
        db: sqlite3.Connection,
        kind: str,
        operation: Any,
        *,
        checkpoint: bool = False,
    ) -> bool:
        """Run one housekeeping transaction that yields to pending quotes."""
        started = time.monotonic()
        deadline = started + max(0.01, MAINTENANCE_BUDGET_SECONDS)
        queue_before = self.events.qsize()

        def should_yield() -> bool:
            return (
                self.stopping.is_set()
                or not self.events.empty()
                or time.monotonic() >= deadline
            )

        def progress_handler() -> int:
            return 1 if should_yield() else 0

        rows_deleted = 0
        db.set_progress_handler(progress_handler, max(1, MAINTENANCE_PROGRESS_OPS))
        try:
            rows_deleted = int(operation(db, should_yield=should_yield) or 0)
            _maintenance_checkpoint(should_yield)
            db.commit()
            if checkpoint and not should_yield():
                try:
                    db.execute("PRAGMA wal_checkpoint(PASSIVE)")
                except sqlite3.OperationalError as exc:
                    if "interrupted" not in str(exc).lower():
                        raise
            self.last_error = None
            self._record_maintenance(
                kind=kind, status="ok", started=started,
                rows_deleted=rows_deleted, queue_before=queue_before,
            )
            return True
        except MaintenanceYielded:
            db.rollback()
            status = "budget_exceeded" if time.monotonic() >= deadline else "preempted"
            self._record_maintenance(
                kind=kind, status=status, started=started,
                rows_deleted=0, queue_before=queue_before,
            )
            return False
        except sqlite3.OperationalError as exc:
            db.rollback()
            if "interrupted" in str(exc).lower() and should_yield():
                self._record_maintenance(
                    kind=kind, status="preempted", started=started,
                    rows_deleted=0, queue_before=queue_before,
                )
                return False
            self.last_error = f"maintenance: {exc}"
            self._record_maintenance(
                kind=kind, status="failed", started=started,
                rows_deleted=0, queue_before=queue_before,
            )
            logging.exception("quote persistence %s maintenance failed", kind)
            return False
        except Exception as exc:
            db.rollback()
            self.last_error = f"maintenance: {exc}"
            self._record_maintenance(
                kind=kind, status="failed", started=started,
                rows_deleted=0, queue_before=queue_before,
            )
            logging.exception("quote persistence %s maintenance failed", kind)
            return False
        finally:
            db.set_progress_handler(None, 0)

    def _run(self) -> None:
        db: sqlite3.Connection | None = None
        while db is None and not self.stopping.is_set():
            try:
                db = connect()
                db.row_factory = sqlite3.Row
                self.last_error = None
            except sqlite3.Error as exc:
                self.last_error = str(exc)
                logging.warning("quote persistence waiting for database: %s", exc)
                time.sleep(1)
        if db is None:
            return
        # Give the websocket a short initial-order-book burst, then enforce
        # retention promptly.  Waiting the normal ten-minute interval here
        # would allow a restarted writer to exceed a stated row ceiling.
        last_maintenance = time.monotonic() - MAINTENANCE_INTERVAL_SECONDS + 30.0
        last_row_cap_enforcement = 0.0
        last_retention_slice = 0.0
        retention_cycle_active = False
        try:
            while True:
                maintenance_ran = False
                try:
                    first = self.events.get(timeout=0.5)
                except queue.Empty:
                    first = None
                if first is None and self.stopping.is_set() and self.events.empty():
                    break
                batch: list[dict[str, Any]] = []
                if first is not None:
                    batch.append(first)
                while len(batch) < 500:
                    try:
                        item = self.events.get_nowait()
                    except queue.Empty:
                        break
                    if item is not None:
                        batch.append(item)
                if batch:
                    # A websocket burst may contain several superseded BBO
                    # states for one token.  Persisting each one adds no value
                    # to a five-second research series and can starve SQLite.
                    quote_events = [event for event in batch if not event.get("_kind")]
                    control_events = [event for event in batch if event.get("_kind")]
                    newest_by_token = {
                        str(event["token"]): event for event in quote_events
                    }
                    # Health/shadow rows are replaceable, while connection
                    # transitions are audit evidence and retain their order.
                    latest_controls: dict[str, dict[str, Any]] = {}
                    audit_controls: list[dict[str, Any]] = []
                    for event in control_events:
                        if event.get("_kind") in {"connection_event", "market_rules"}:
                            audit_controls.append(event)
                        else:
                            latest_controls[str(event.get("_kind"))] = event
                    batch = (
                        list(newest_by_token.values())
                        + list(latest_controls.values())
                        + audit_controls
                    )
                    quote_events = [event for event in batch if not event.get("_kind")]
                    try:
                        for event in batch:
                            if event.get("_kind"):
                                self._persist_control_event(db, event)
                            else:
                                persist_quote_event(db, event)
                        # The paper ledger is deliberately not touched here.
                        # Quote persistence owns realtime.sqlite3; the auto
                        # simulator reads its bounded projection and writes to
                        # its separate paper.sqlite3 ledger.
                        db.commit()
                        # Acknowledge the quote transaction immediately after
                        # it is durable.  Retention/cap maintenance below is a
                        # separate transaction and must not inflate commit lag
                        # or create false stale-pending alarms.
                        if self.on_committed:
                            for event in quote_events:
                                try:
                                    self.on_committed(event)
                                except Exception:
                                    logging.exception("post-commit quote notification failed")
                        self.last_error = None
                    except sqlite3.OperationalError as exc:
                        db.rollback()
                        self.last_error = str(exc)
                        logging.warning("quote persistence temporarily locked; retrying %d current token states: %s", len(batch), exc)
                        # A collector migration or checkpoint can briefly lock
                        # SQLite. Requeue the batch instead of losing evidence.
                        for event in batch:
                            try:
                                self.events.put_nowait(event)
                            except queue.Full:
                                if event.get("reason") == "heartbeat":
                                    self.dropped_heartbeats += 1
                                else:
                                    self.dropped_critical += 1
                        time.sleep(0.5)
                    except Exception as exc:
                        db.rollback()
                        self.last_error = str(exc)
                        logging.exception("quote persistence batch failed")
                        # Preserve quote events for a transient unexpected
                        # failure. The supervisor will restart this worker if
                        # the writer state remains unhealthy.
                        for event in batch:
                            try:
                                self.events.put_nowait(event)
                            except queue.Full:
                                self.dropped_critical += 1
                        time.sleep(0.5)
                monotonic_now = time.monotonic()
                # Capacity backlog must continue draining after a producer
                # becomes quiet.  Keep the original empty-queue gate, budget,
                # preemption and four-phase rotation, but do not require a
                # newly committed quote batch to trigger the next slice.
                if (
                    monotonic_now - last_row_cap_enforcement >= ROW_CAP_ENFORCE_SECONDS
                    and self.events.empty()
                ):
                    phase = CAPACITY_PHASES[self._capacity_phase_index]
                    completed = self._run_bounded_maintenance(
                        db, f"capacity/{phase}",
                        lambda connection, *, should_yield, selected=phase:
                            enforce_row_cap_phase(
                                connection, selected,
                                should_yield=should_yield,
                            ),
                    )
                    maintenance_ran = True
                    if completed:
                        self._capacity_phase_index = (
                            self._capacity_phase_index + 1
                        ) % len(CAPACITY_PHASES)
                    last_row_cap_enforcement = (
                        monotonic_now
                        if completed
                        else monotonic_now - ROW_CAP_ENFORCE_SECONDS
                        + min(MAINTENANCE_RETRY_SECONDS, ROW_CAP_ENFORCE_SECONDS)
                    )
                if monotonic_now - last_maintenance >= MAINTENANCE_INTERVAL_SECONDS:
                    retention_cycle_active = True
                if (
                    retention_cycle_active
                    and not maintenance_ran
                    and monotonic_now - last_retention_slice >= MAINTENANCE_RETRY_SECONDS
                    and self.events.empty()
                ):
                    phase = RETENTION_PHASES[self._retention_phase_index]
                    completed = self._run_bounded_maintenance(
                        db, f"retention/{phase}",
                        lambda connection, *, should_yield, selected=phase:
                            prune_retention_phase(
                                connection, selected,
                                should_yield=should_yield,
                            ),
                        checkpoint=phase == RETENTION_PHASES[-1],
                    )
                    last_retention_slice = monotonic_now
                    if completed:
                        rows_deleted = int(
                            self.maintenance_snapshot()["rows_deleted"]
                        )
                        # A full slice means this phase still may have a
                        # backlog.  Commit its progress and revisit it rather
                        # than rolling completed work back with later phases.
                        if rows_deleted < _online_prune_batch_rows():
                            self._retention_phase_index += 1
                            if self._retention_phase_index >= len(RETENTION_PHASES):
                                self._retention_phase_index = 0
                                retention_cycle_active = False
                                last_maintenance = monotonic_now
                    # TRUNCATE is deliberately forbidden online. PASSIVE is
                    # attempted only after the final independently committed
                    # projection phase.
        finally:
            db.close()


@dataclass(frozen=True)
class UniverseManifest:
    assets: tuple[str, ...]
    token_market: dict[str, str]
    token_hash: str
    token_target_date: dict[str, str]
    publication_id: str = ""
    published_at: str = ""
    reason: str = ""
    format: str = "legacy_literal"
    members: tuple[dict[str, Any], ...] = ()
    accepted_legacy: bool = False

    @property
    def member_by_token(self) -> dict[str, dict[str, Any]]:
        return {
            member["token_id"]: member
            for member in self.members
            if isinstance(member, dict) and isinstance(member.get("token_id"), str)
        }

    @property
    def target_dates(self) -> frozenset[str]:
        return frozenset(self.token_target_date.values())

    def legacy_tuple(self) -> tuple[list[str], dict[str, str], str]:
        return list(self.assets), dict(self.token_market), self.token_hash


@dataclass(frozen=True)
class UniverseChange:
    manifest: UniverseManifest
    added: tuple[str, ...]
    removed: tuple[str, ...]
    metadata_only: bool = False
    format_transition: str | None = None


@dataclass(frozen=True)
class ExplicitRollbackPlan:
    change: UniverseChange
    expected_current_hash: str
    pinned_hash: str

    @property
    def target(self) -> UniverseManifest:
        return self.change.manifest


CITY_ATTRIBUTION_MATRIX = {
    "Beijing": ("formal", "ZBAA"),
    "Shanghai": ("formal", "ZSPD"),
    "Chengdu": ("formal", "ZUUU"),
    "Guangzhou": ("formal", "ZGGG"),
    "Shenzhen": ("research_only", "ZGSZ"),
    "Wuhan": ("research_only", "ZHHH"),
    "Chongqing": ("research_only", "ZUCK"),
}
RETIRED_CITY_ATTRIBUTION_MATRIX = {
    "Zhengzhou": ("research_only", "ZHCC"),
}
CITY_RETIREMENT_DATES = {
    "Zhengzhou": "2026-08-30",
}
V1_SCHEMA = "research_market_attribution.v1"
V1_REQUIRED_FIELDS = (
    "schema", "token_id", "market_id", "city", "city_scope", "station",
    "target_date", "outcome", "event_id", "source_scan_id",
    "attribution_status",
)
V1_EXCLUSIVE_FIELDS = frozenset({
    "city_scope", "station", "outcome", "event_id", "source_scan_id",
    "attribution_status",
})
IMMUTABLE_ATTRIBUTION_FIELDS = (
    "market_id", "city", "city_scope", "station", "target_date", "outcome",
    "event_id",
)


def _native_nonempty_string(value: Any) -> bool:
    return type(value) is str and bool(value) and value == value.strip()


def _strict_iso_date(value: Any) -> bool:
    if not _native_nonempty_string(value) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return False
    try:
        return datetime.strptime(value, "%Y-%m-%d").date().isoformat() == value
    except ValueError:
        return False


def _classify_and_validate_members(
    members: list[Any], token_hash: str, accepted_legacy_hashes: set[str],
    *, now_cn: datetime | None = None,
) -> tuple[str, dict[str, str], dict[str, str]] | None:
    if not members or any(type(member) is not dict for member in members):
        return None
    schema_presence = tuple("schema" in member for member in members)
    if any(schema_presence) and not all(schema_presence):
        return None
    if any(
        "schema" not in member and V1_EXCLUSIVE_FIELDS.intersection(member)
        for member in members
    ):
        return None
    manifest_format = V1_SCHEMA if all(schema_presence) else "legacy"
    if manifest_format == "legacy" and token_hash not in accepted_legacy_hashes:
        return None
    token_market: dict[str, str] = {}
    token_target_date: dict[str, str] = {}
    markets: set[str] = set()
    tokens: set[str] = set()
    source_scan_id: str | None = None
    today = (now_cn or datetime.now(CHINA_TZ)).date().isoformat()
    for member in members:
        if manifest_format == V1_SCHEMA:
            if set(V1_REQUIRED_FIELDS) - set(member):
                return None
            if any(not _native_nonempty_string(member[field]) for field in V1_REQUIRED_FIELDS):
                return None
            if member["schema"] != V1_SCHEMA:
                return None
            token = member["token_id"]
            if not token.isascii() or not token.isdecimal():
                return None
            if member["outcome"] != "Yes" or member["attribution_status"] != "verified":
                return None
            expected = {
                **CITY_ATTRIBUTION_MATRIX,
                **RETIRED_CITY_ATTRIBUTION_MATRIX,
            }.get(member["city"])
            if expected != (member["city_scope"], member["station"]):
                return None
            if source_scan_id is None:
                source_scan_id = member["source_scan_id"]
            elif source_scan_id != member["source_scan_id"]:
                return None
        else:
            if any(key not in member for key in ("token_id", "market_id", "city", "target_date")):
                return None
            if any(not _native_nonempty_string(member[key]) for key in (
                "token_id", "market_id", "city", "target_date",
            )):
                return None
            token = member["token_id"]
        market = member["market_id"]
        target_date = member["target_date"]
        if not _strict_iso_date(target_date) or token in tokens or market in markets:
            return None
        tokens.add(token)
        markets.add(market)
        retirement_date = CITY_RETIREMENT_DATES.get(member["city"])
        if retirement_date is not None and today >= retirement_date:
            continue
        token_market[token] = market
        token_target_date[token] = target_date
    return manifest_format, token_market, token_target_date


def _manifest_from_row(
    row: tuple[Any, ...] | None,
    *,
    accepted_legacy_hashes: set[str] | None = None,
    now_cn: datetime | None = None,
) -> UniverseManifest | None:
    if not row:
        return None
    if len(row) != 6:
        return None
    publication_id, published_at, token_hash, token_count, raw_members, reason = row
    accepted_legacy_hashes = set(accepted_legacy_hashes or ())
    try:
        if any(not _native_nonempty_string(value) for value in (
            publication_id, published_at, token_hash, raw_members, reason,
        )):
            return None
        if type(token_count) is not int or token_count <= 0 or reason != "complete_scan":
            return None
        published = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
        if published.tzinfo is None or published.utcoffset() is None:
            return None
        if not re.fullmatch(r"[0-9a-f]{64}", token_hash):
            return None
        if publication_id != f"{published_at}:{token_hash[:12]}":
            return None
        members = json.loads(raw_members)
        if type(members) is not list or not members or len(members) != token_count:
            logging.warning("reject empty market universe manifest %s", publication_id)
            return None
        canonical = json.dumps(members, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
        if hashlib.sha256(canonical.encode()).hexdigest() != token_hash:
            logging.warning("reject invalid market universe manifest %s", publication_id)
            return None
        expected_order = sorted(
            members,
            key=lambda item: (
                str(item.get("token_id", "")) if isinstance(item, dict) else "",
                str(item.get("market_id", "")) if isinstance(item, dict) else "",
            ),
        )
        if members != expected_order:
            logging.warning("reject out-of-order market universe manifest %s", publication_id)
            return None
        validated = _classify_and_validate_members(
            members, token_hash, accepted_legacy_hashes, now_cn=now_cn,
        )
        if validated is None:
            logging.warning("reject malformed or untrusted market universe manifest %s", publication_id)
            return None
        manifest_format, token_market, token_target_date = validated
        return UniverseManifest(
            tuple(sorted(token_market)),
            token_market,
            token_hash,
            token_target_date,
            publication_id,
            published_at,
            reason,
            manifest_format,
            tuple(dict(member) for member in members),
            manifest_format == "legacy" and token_hash in accepted_legacy_hashes,
        )
    except (json.JSONDecodeError, TypeError, KeyError, ValueError, OverflowError) as exc:
        logging.warning("market universe manifest %s unavailable: %s", publication_id, exc)
        return None


def revalidate_recovery_manifest(
    manifest: UniverseManifest | None,
) -> UniverseManifest | None:
    """Rebuild immutable recovery evidence without consulting a newer publication."""
    if type(manifest) is not UniverseManifest:
        return None
    if manifest.format == "legacy_literal":
        # This frozen process-local fallback can only restore the exact assets
        # already in use.  It is never promoted to a publication or accepted
        # as an explicit rollback target, and no missing attribution is made up.
        if (
            not _native_nonempty_string(manifest.token_hash)
            or not manifest.assets
            or manifest.assets != tuple(sorted(set(manifest.assets)))
            or set(manifest.assets) != set(manifest.token_market)
            or any(
                not _native_nonempty_string(token)
                or not _native_nonempty_string(manifest.token_market[token])
                for token in manifest.assets
            )
            or len(set(manifest.token_market.values())) != len(manifest.assets)
            or any(
                token not in manifest.token_market or not _strict_iso_date(target)
                for token, target in manifest.token_target_date.items()
            )
        ):
            return None
        return UniverseManifest(
            tuple(manifest.assets),
            dict(manifest.token_market),
            manifest.token_hash,
            dict(manifest.token_target_date),
            format="legacy_literal",
        )
    if manifest.format not in {"legacy", V1_SCHEMA}:
        return None
    if manifest.format == "legacy" and not manifest.accepted_legacy:
        return None
    if not manifest.members:
        return None
    members = [dict(member) for member in manifest.members]
    raw_members = json.dumps(
        members, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
    )
    parsed = _manifest_from_row(
        (
            manifest.publication_id,
            manifest.published_at,
            manifest.token_hash,
            len(members),
            raw_members,
            manifest.reason,
        ),
        accepted_legacy_hashes=(
            {manifest.token_hash} if manifest.format == "legacy" else set()
        ),
    )
    if parsed is None:
        return None
    if (
        parsed.format != manifest.format
        or parsed.assets != manifest.assets
        or parsed.token_market != manifest.token_market
        or parsed.token_target_date != manifest.token_target_date
        or parsed.members != manifest.members
        or parsed.accepted_legacy != manifest.accepted_legacy
    ):
        return None
    return parsed


def accepted_universe_hash_chain() -> list[str]:
    """Return newest-first distinct accepted hashes from the immutable event chain."""
    try:
        with contextlib.closing(
            sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=2)
        ) as db:
            exists = db.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='stream_connection_events'"
            ).fetchone()
            if not exists:
                return []
            rows = db.execute("""SELECT universe_hash FROM stream_connection_events
              WHERE event_type IN ('connected','universe_changed','universe_rollback')
                AND universe_hash IS NOT NULL ORDER BY event_at DESC""").fetchall()
        chain: list[str] = []
        for row in rows:
            value = row[0]
            if type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value):
                if not chain or chain[-1] != value:
                    chain.append(value)
        return chain
    except sqlite3.Error as exc:
        logging.warning("accepted market universe chain unavailable: %s", exc)
        return []


def accepted_universe_rollback_chain() -> list[str]:
    """Return the accepted asset-version chain with source-scan noise folded.

    The immutable event history remains untouched.  This stricter derived view
    is used only by explicit rollback planning and fails closed if any accepted
    publication cannot be resolved and revalidated by its exact hash.
    """
    raw_chain = accepted_universe_hash_chain()
    if not raw_chain:
        return []
    manifests: list[UniverseManifest] = []
    for token_hash in raw_chain:
        manifest = published_universe_manifest(token_hash)
        if manifest is None or manifest.token_hash != token_hash:
            return []
        manifests.append(manifest)
    logical_chain = [raw_chain[0]]
    newer = manifests[0]
    for token_hash, older in zip(raw_chain[1:], manifests[1:]):
        if _metadata_only_v1_update(older, newer):
            continue
        logical_chain.append(token_hash)
        newer = older
    return logical_chain


def published_universe_manifest(token_hash: str | None = None) -> UniverseManifest | None:
    """Read one completed collector manifest, never an in-progress scan."""
    try:
        with contextlib.closing(sqlite3.connect(f"file:{RESEARCH_DB}?mode=ro", uri=True, timeout=2)) as db:
            if token_hash:
                row = db.execute(
                    """SELECT publication_id,published_at,token_hash,token_count,members_json,reason
                       FROM market_universe_publications
                       WHERE token_hash=?
                       ORDER BY published_at DESC LIMIT 1""",
                    (token_hash,),
                ).fetchone()
            else:
                row = db.execute(
                    """SELECT publication_id,published_at,token_hash,token_count,members_json,reason
                       FROM market_universe_publications
                       ORDER BY published_at DESC LIMIT 1"""
                ).fetchone()
        return _manifest_from_row(
            row, accepted_legacy_hashes=set(accepted_universe_hash_chain())
        )
    except sqlite3.Error as exc:
        logging.warning("published market universe unavailable: %s", exc)
        return None


def published_universe() -> tuple[list[str], dict[str, str], str] | None:
    """Backward-compatible latest completed manifest view."""
    manifest = published_universe_manifest()
    return manifest.legacy_tuple() if manifest else None


def last_accepted_universe_manifest() -> UniverseManifest | None:
    """Recover the last universe successfully accepted by the live stream."""
    try:
        chain = accepted_universe_hash_chain()
        return published_universe_manifest(chain[0]) if chain else None
    except sqlite3.Error as exc:
        logging.warning("accepted market universe recovery unavailable: %s", exc)
        return None


def latest_manifest_repeated(token_hash: str, *, count: int = 2) -> bool:
    """Require consecutive completed scans before a restart-time rollover."""
    if count <= 1:
        return True
    try:
        with contextlib.closing(sqlite3.connect(f"file:{RESEARCH_DB}?mode=ro", uri=True, timeout=2)) as db:
            rows = db.execute(
                """SELECT publication_id,published_at,token_hash,token_count,members_json,reason
                   FROM market_universe_publications
                   ORDER BY published_at DESC LIMIT ?""",
                (count,),
            ).fetchall()
        accepted = set(accepted_universe_hash_chain())
        manifests = [
            _manifest_from_row(tuple(row), accepted_legacy_hashes=accepted)
            for row in rows
        ]
        return (
            len(manifests) == count
            and all(manifest is not None for manifest in manifests)
            and all(manifest.token_hash == token_hash for manifest in manifests if manifest)
        )
    except sqlite3.Error as exc:
        logging.warning("manifest repetition check unavailable: %s", exc)
        return False


def _member_identity_equal(
    current: UniverseManifest, candidate: UniverseManifest, token: str
) -> bool:
    if current.token_market.get(token) != candidate.token_market.get(token):
        return False
    if current.token_target_date.get(token) != candidate.token_target_date.get(token):
        return False
    current_member = current.member_by_token.get(token)
    candidate_member = candidate.member_by_token.get(token)
    if current.format == V1_SCHEMA and candidate.format == V1_SCHEMA:
        if current_member is None or candidate_member is None:
            return False
        return all(
            current_member.get(field) == candidate_member.get(field)
            for field in IMMUTABLE_ATTRIBUTION_FIELDS
        )
    if current.format == "legacy" and candidate.format in {"legacy", V1_SCHEMA}:
        if current_member is None or candidate_member is None:
            return False
        return all(
            current_member.get(field) == candidate_member.get(field)
            for field in ("market_id", "city", "target_date")
        )
    # Preserve the frozen process-local fallback for ordinary asset changes;
    # it has no member attribution and therefore can never qualify for the
    # explicit zero-asset format-upgrade path below.
    return current.format == "legacy_literal" and candidate.format in {
        "legacy", V1_SCHEMA,
    }


def _metadata_only_v1_update(
    current: UniverseManifest, candidate: UniverseManifest
) -> bool:
    if current.format != V1_SCHEMA or candidate.format != V1_SCHEMA:
        return False
    if set(current.assets) != set(candidate.assets):
        return False
    current_scans = {
        member.get("source_scan_id") for member in current.members
        if isinstance(member, dict)
    }
    candidate_scans = {
        member.get("source_scan_id") for member in candidate.members
        if isinstance(member, dict)
    }
    if (
        len(current_scans) != 1
        or len(candidate_scans) != 1
        or current_scans == candidate_scans
    ):
        return False
    for token in current.assets:
        old = dict(current.member_by_token.get(token) or {})
        new = dict(candidate.member_by_token.get(token) or {})
        old.pop("source_scan_id", None)
        new.pop("source_scan_id", None)
        if old != new:
            return False
    return True


def _same_legacy_v1_asset_facts(
    legacy: UniverseManifest, candidate_v1: UniverseManifest
) -> bool:
    """Compare only facts a legacy publication actually owns, without synthesis."""
    if legacy.format != "legacy" or candidate_v1.format != V1_SCHEMA:
        return False
    if (
        revalidate_recovery_manifest(legacy) != legacy
        or revalidate_recovery_manifest(candidate_v1) != candidate_v1
        or legacy.assets != candidate_v1.assets
        or legacy.token_market != candidate_v1.token_market
        or legacy.token_target_date != candidate_v1.token_target_date
    ):
        return False
    legacy_members = legacy.member_by_token
    v1_members = candidate_v1.member_by_token
    if set(legacy_members) != set(legacy.assets) or set(v1_members) != set(candidate_v1.assets):
        return False
    return all(
        all(
            legacy_members[token].get(field) == v1_members[token].get(field)
            for field in ("market_id", "city", "target_date")
        )
        for token in legacy.assets
    )


def validate_universe_transition(
    current: UniverseManifest,
    candidate: UniverseManifest,
    *,
    now_cn: datetime,
    shrink_confirmed: bool = False,
    forward_mixed_confirmed: bool = False,
    explicit_rollback: bool = False,
) -> UniverseChange | None:
    """Pure safety gate shared by startup, dynamic updates and rollback."""
    if candidate.token_hash == current.token_hash:
        return UniverseChange(candidate, (), ())
    if current.format == V1_SCHEMA and candidate.format != V1_SCHEMA and not explicit_rollback:
        return None
    current_tokens, updated_tokens = set(current.assets), set(candidate.assets)
    shared = current_tokens & updated_tokens
    for token in shared:
        if explicit_rollback and candidate.format == "legacy":
            current_member = current.member_by_token.get(token)
            candidate_member = candidate.member_by_token.get(token)
            if current_member is None or candidate_member is None or any(
                current_member.get(field) != candidate_member.get(field)
                for field in ("market_id", "city", "target_date")
            ):
                return None
        elif not _member_identity_equal(current, candidate, token):
            return None
    current_market_token = {market: token for token, market in current.token_market.items()}
    candidate_market_token = {market: token for token, market in candidate.token_market.items()}
    if any(
        current_market_token[market] != candidate_market_token[market]
        for market in set(current_market_token) & set(candidate_market_token)
    ):
        return None
    added = tuple(sorted(updated_tokens - current_tokens))
    removed = tuple(sorted(current_tokens - updated_tokens))
    if not added and not removed:
        if (
            current.format == "legacy"
            and candidate.format == V1_SCHEMA
            and _same_legacy_v1_asset_facts(current, candidate)
        ):
            return UniverseChange(
                candidate, (), (), format_transition="legacy_to_v1",
            )
        if (
            explicit_rollback
            and current.format == V1_SCHEMA
            and candidate.format == "legacy"
            and _same_legacy_v1_asset_facts(candidate, current)
        ):
            return UniverseChange(
                candidate, (), (), format_transition="v1_to_legacy_rollback",
            )
        if _metadata_only_v1_update(current, candidate):
            return UniverseChange(candidate, (), (), metadata_only=True)
        return None
    if explicit_rollback:
        return UniverseChange(candidate, added, removed)
    today = now_cn.date().isoformat()
    if added and not removed:
        if any(candidate.token_target_date[token] < today for token in added):
            return None
        return UniverseChange(candidate, added, ())
    rollover_window = 0 <= now_cn.hour < ROLLOVER_END_HOUR
    candidate_has_past = any(target < today for target in candidate.target_dates)
    if added and removed:
        if candidate.format != V1_SCHEMA:
            return None
        if current.format == V1_SCHEMA:
            format_transition = "forward_mixed_rollover"
        elif current.format == "legacy" and current.accepted_legacy:
            format_transition = "legacy_to_v1_forward_mixed"
        else:
            return None
        if (
            not rollover_window
            or candidate_has_past
            or revalidate_recovery_manifest(current) != current
            or revalidate_recovery_manifest(candidate) != candidate
            or any(candidate.token_target_date[token] < today for token in added)
            or not all(
                current.token_target_date.get(token, today) < today
                for token in removed
            )
            or not forward_mixed_confirmed
        ):
            return None
        return UniverseChange(
            candidate, added, removed,
            format_transition=format_transition,
        )
    if not removed:
        return None
    removed_are_past = all(
        current.token_target_date.get(token, today) < today for token in removed
    )
    if not rollover_window or candidate_has_past or not removed_are_past:
        return None
    if not shrink_confirmed:
        return None
    return UniverseChange(candidate, (), removed)


def select_startup_universe(
    accepted: UniverseManifest | None,
    candidate: UniverseManifest | None,
    *,
    now_cn: datetime | None = None,
) -> UniverseManifest | None:
    """Use the normal transition gate at startup; never trust a wider shortcut."""
    if accepted is None:
        return candidate
    if candidate is None:
        return accepted
    now_cn = now_cn or datetime.now(CHINA_TZ)
    change = validate_universe_transition(
        accepted,
        candidate,
        now_cn=now_cn,
        shrink_confirmed=latest_manifest_repeated(candidate.token_hash),
    )
    return change.manifest if change is not None else accepted


def startup_universe() -> UniverseManifest | None:
    """Choose a restart-safe universe without regressing on a transient shrink."""
    candidate = published_universe_manifest()
    accepted = last_accepted_universe_manifest()
    return select_startup_universe(accepted, candidate)


def published_token_ids() -> set[str] | None:
    universe = published_universe()
    return set(universe[0]) if universe is not None else None


def legacy_subscriptions() -> tuple[list[str], dict[str, str]]:
    """Compatibility fallback used only before the collector publishes once."""
    db = sqlite3.connect(f"file:{RESEARCH_DB}?mode=ro", uri=True)
    try:
        rows = db.execute("""
          SELECT m.market_id,m.question,m.tokens_json,m.outcomes_json FROM market_snapshots m
          JOIN (SELECT market_id,MAX(captured_at) AS captured_at FROM market_snapshots GROUP BY market_id) last
            ON last.market_id=m.market_id AND last.captured_at=m.captured_at
          WHERE m.active=1 AND m.closed=0
        """).fetchall()
    finally:
        db.close()
    token_market: dict[str, str] = {}
    allowed_days = {(datetime.now(CHINA_TZ).date() + timedelta(days=offset)).isoformat() for offset in range(3)}
    for market_id, question, raw, outcomes_raw in rows:
        # Questions use "on July 18".  Do not leave an older active event in
        # the stream merely because Gamma has not yet marked it closed.
        import re
        match = re.search(r"on ([A-Za-z]+) (\d{1,2})(?:, (\d{4}))?", str(question))
        if not match:
            continue
        month, day, year = match.groups()
        try:
            target = datetime.strptime(f"{month} {day} {year or datetime.now(CHINA_TZ).year}", "%B %d %Y").date().isoformat()
        except ValueError:
            continue
        if target not in allowed_days:
            continue
        tokens, outcomes = json.loads(raw or "[]"), json.loads(outcomes_raw or "[]")
        try:
            yes_index = [str(value).lower() for value in outcomes].index("yes")
            token_market[str(tokens[yes_index])] = str(market_id)
        except (ValueError, IndexError):
            logging.warning("skip market %s: missing explicit YES token", market_id)
    return sorted(token_market), token_market


def subscription_manifest() -> UniverseManifest:
    """Return the restart-safe startup manifest."""
    universe = startup_universe()
    if universe is not None:
        return universe
    assets, token_market = legacy_subscriptions()
    return UniverseManifest(tuple(assets), token_market, "legacy", {})


def subscriptions() -> tuple[list[str], dict[str, str], str]:
    """Backward-compatible restart-safe subscription tuple."""
    return subscription_manifest().legacy_tuple()


def best(levels: dict[float, float], side: str) -> tuple[float | None, float | None]:
    live = {price: size for price, size in levels.items() if size > 0}
    if not live:
        return None, None
    price = max(live) if side == "bid" else min(live)
    return price, live[price]


def validated_book_rules(data: dict[str, Any]) -> dict[str, Any] | None:
    """Return strict execution metadata from one official CLOB book response.

    Partial or malformed metadata is never replaced with constants.  Quotes
    may still be observed, but execution consumers must abstain until a full
    book event supplies all required rules.
    """

    tick_raw = data.get("tick_size", data.get("tickSize"))
    minimum_raw = data.get("min_order_size", data.get("minOrderSize"))
    neg_risk = data.get("neg_risk", data.get("negRisk"))
    book_hash = data.get("hash")
    if type(neg_risk) is not bool or not isinstance(book_hash, str) or not book_hash:
        return None
    try:
        tick = Decimal(str(tick_raw))
        minimum = Decimal(str(minimum_raw))
    except (InvalidOperation, TypeError, ValueError):
        return None
    if (
        not tick.is_finite()
        or not minimum.is_finite()
        or tick <= 0
        or tick >= 1
        or minimum <= 0
    ):
        return None
    return {
        "tick_size": format(tick.normalize(), "f"),
        "min_order_size": format(minimum.normalize(), "f"),
        "neg_risk": neg_risk,
        "book_hash": book_hash,
    }


async def fetch_market_rules(
    writer: PersistenceWriter,
    token_market: dict[str, str],
    *,
    client: httpx.AsyncClient | None = None,
) -> dict[str, dict[str, Any]]:
    """Fetch each token's execution metadata once per admission event.

    The WebSocket market channel intentionally omits these fields.  The
    official batch ``/books`` endpoint is therefore used at startup and only
    for newly admitted tokens, never as a quote-polling loop.
    """

    tokens = sorted(token_market)
    if not tokens:
        return {}
    owned = client is None
    active_client = client or httpx.AsyncClient(timeout=10)
    accepted: dict[str, dict[str, Any]] = {}
    try:
        for start in range(0, len(tokens), 100):
            chunk = tokens[start:start + 100]
            response = await active_client.post(
                CLOB_BOOKS_URL,
                json=[{"token_id": token_id} for token_id in chunk],
                headers={"User-Agent": "temperature-research-realtime/1.0"},
            )
            response.raise_for_status()
            payload = response.json()
            if not isinstance(payload, list):
                raise ValueError("market rules response must be a list")
            captured_at = datetime.now(UTC).isoformat()
            for item in payload:
                if not isinstance(item, dict):
                    continue
                token_id = item.get("asset_id")
                if not isinstance(token_id, str) or token_id not in token_market:
                    continue
                rules = validated_book_rules(item)
                if rules is None:
                    continue
                if not writer.submit_market_rules(
                    token_id=token_id,
                    market_id=token_market[token_id],
                    captured_at=captured_at,
                    rules=rules,
                ):
                    raise RuntimeError("market rules persistence queue rejected")
                accepted[token_id] = rules
    finally:
        if owned:
            await active_client.aclose()
    return accepted


class LiveStateHub:
    """Bounded local live-state projection, initially operated in shadow mode.

    It receives the same accepted BBO events that are sent to the persistence
    writer, but has no ability to submit orders or alter the external feed. A
    future dashboard/strategy can consume its local WebSocket deltas after
    shadow reconciliation proves it agrees with ``latest_bbo``.
    """
    def __init__(self) -> None:
        self.quotes: dict[str, dict[str, Any]] = {}
        self.token_market: dict[str, str] = {}
        self.clients: set[Any] = set()
        self.client_queue_size = STATE_HUB_CLIENT_QUEUE_SIZE
        self.client_queues: dict[Any, asyncio.Queue[str]] = {}
        self.client_senders: dict[Any, asyncio.Task[None]] = {}
        self.client_send_failures = 0
        self.client_warning_suppressed = 0
        self.last_client_warning = 0.0
        self.server: Any | None = None
        self.last_listener_attempt = 0.0
        self.listener_restart_count = 0
        self.stream_id = uuid.uuid4().hex
        self.sequence = 0
        self.upstream: dict[str, Any] = {
            "connected": False,
            "detail": "starting",
            "updated_at": datetime.now(UTC).isoformat(),
        }
        self.last_reconcile = 0.0
        self.reconcile_task: asyncio.Task[None] | None = None
        self.startup_manifest_read = AsyncSingleFlightRead("startup-manifest")
        self.startup_warmup_read = AsyncSingleFlightRead("startup-warmup")
        self.reconnect_manifest_read = AsyncSingleFlightRead("reconnect-manifest")
        self.startup_manifest: UniverseManifest | None = None
        self.startup_warmup_rows: tuple[tuple[Any, ...], ...] | None = None
        self.startup_universe_set = False
        self.startup_warmed = 0
        self.startup_complete = False
        self.shadow: dict[str, Any] = {"state": "starting", "memory_tokens": 0,
                                       "database_tokens": None, "database_lag_seconds": None}

    async def start(self) -> bool:
        if not STATE_HUB_ENABLED:
            self.shadow["state"] = "disabled"
            return False
        if self.server is not None and self.server.is_serving():
            return True
        try:
            self.server = await websockets.serve(self._client, STATE_HUB_HOST, STATE_HUB_PORT,
                                                 ping_interval=20, ping_timeout=20,
                                                 max_size=1_000_000)
            self.shadow["state"] = "shadow"
            logging.info("local live-state hub listening on ws://%s:%s", STATE_HUB_HOST, STATE_HUB_PORT)
            return True
        except OSError as exc:
            # The primary collector must continue even if a local diagnostic
            # listener cannot start (for example, a stale developer process).
            self.shadow.update(state="unavailable", error=str(exc))
            logging.warning("local live-state hub disabled: %s", exc)
            return False

    async def ensure_listener(self) -> bool:
        """Recover only the local read-only listener if Windows drops accept().

        The Polymarket connection and SQLite writer stay untouched.  A failed
        local accept socket must not require restarting the upstream stream or
        creating a second quote writer.
        """
        if not STATE_HUB_ENABLED:
            return False
        if self.server is not None and self.server.is_serving():
            return True
        monotonic_now = time.monotonic()
        if monotonic_now - self.last_listener_attempt < 3.0:
            return False
        self.last_listener_attempt = monotonic_now
        if self.server is not None:
            with contextlib.suppress(Exception):
                self.server.close()
                await self.server.wait_closed()
            self.server = None
        recovered = await self.start()
        if recovered:
            self.listener_restart_count += 1
            logging.warning(
                "local live-state listener recovered without restarting upstream"
            )
        return recovered

    async def close(self) -> None:
        if self.server is not None:
            self.server.close()
            await self.server.wait_closed()
        for task in list(self.client_senders.values()):
            task.cancel()
        if self.client_senders:
            await asyncio.gather(*self.client_senders.values(), return_exceptions=True)
        self.client_senders.clear()
        self.client_queues.clear()
        for client in list(self.clients):
            with contextlib.suppress(Exception):
                await client.close(code=1001, reason="state hub stopping")
        self.clients.clear()
        if self.reconcile_task is not None:
            self.reconcile_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.reconcile_task

    def snapshot(self) -> dict[str, Any]:
        return {"type": "snapshot", "schema": 2, "stream_id": self.stream_id,
                "sequence": self.sequence,
                "captured_at": datetime.now(UTC).isoformat(),
                "quotes": list(self.quotes.values()),
                "token_count": len(self.quotes), "shadow": dict(self.shadow),
                "upstream": dict(self.upstream)}

    async def _client(self, websocket: Any) -> None:
        try:
            await asyncio.wait_for(
                websocket.send(json.dumps(self.snapshot(), separators=(",", ":"))),
                timeout=STATE_HUB_CLIENT_SEND_DEADLINE_SECONDS,
            )
            self._register_client(websocket)
            async for raw in websocket:
                # Read-only protocol.  Accept only a cheap ping so an unknown
                # local client can never mutate market/strategy state.
                if raw == "ping":
                    self._enqueue_client(websocket, '{"type":"pong"}')
        except Exception:
            pass
        finally:
            self._drop_client(websocket)

    @staticmethod
    def _is_closed(client: Any) -> bool:
        if bool(getattr(client, "closed", False)):
            return True
        state = getattr(client, "state", None)
        return str(getattr(state, "name", state)).upper() in {"CLOSED", "CLOSING"}

    def _register_client(self, client: Any) -> None:
        if self._is_closed(client) or client in self.clients:
            return
        self.clients.add(client)
        self.client_queues[client] = asyncio.Queue(maxsize=self.client_queue_size)
        self.client_senders[client] = asyncio.create_task(
            self._client_sender(client), name="live-state-client-sender"
        )

    async def _client_sender(self, client: Any) -> None:
        try:
            queue_for_client = self.client_queues[client]
            while True:
                payload = await queue_for_client.get()
                await asyncio.wait_for(
                    client.send(payload), timeout=STATE_HUB_CLIENT_SEND_DEADLINE_SECONDS,
                )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._drop_client(client, exc)

    def _warn_client_failure(self, exc: BaseException | None) -> None:
        self.client_send_failures += 1
        monotonic_now = time.monotonic()
        if (
            self.last_client_warning
            and monotonic_now - self.last_client_warning < STATE_HUB_CLIENT_WARNING_SECONDS
        ):
            self.client_warning_suppressed += 1
            return
        suppressed = self.client_warning_suppressed
        self.client_warning_suppressed = 0
        self.last_client_warning = monotonic_now
        logging.warning(
            "state hub client send failure; total=%d suppressed=%d error=%s",
            self.client_send_failures,
            suppressed,
            type(exc).__name__ if exc is not None else "closed_or_slow",
        )

    def _drop_client(self, client: Any, exc: BaseException | None = None) -> None:
        was_registered = client in self.clients
        self.clients.discard(client)
        self.client_queues.pop(client, None)
        sender = self.client_senders.pop(client, None)
        current = asyncio.current_task()
        if sender is not None and sender is not current:
            sender.cancel()
        if was_registered and exc is not None:
            self._warn_client_failure(exc)

    def _broadcast_payload(self, payload: dict[str, Any]) -> None:
        if not self.clients:
            return
        encoded = json.dumps(payload, separators=(",", ":"))
        for client in list(self.clients):
            if self._is_closed(client):
                self._drop_client(client)
                continue
            self._enqueue_client(client, encoded)

    def _enqueue_client(self, client: Any, encoded: str) -> None:
        queue_for_client = self.client_queues.get(client)
        if queue_for_client is None:
            self._drop_client(client)
            return
        try:
            queue_for_client.put_nowait(encoded)
        except asyncio.QueueFull as exc:
            self._drop_client(client, exc)

    def set_universe(self, token_market: dict[str, str]) -> None:
        """Atomically replace the active universe and discard retired quotes.

        ``latest_bbo`` intentionally retains some historical rows for audit,
        whereas the in-memory hub must represent *only* currently subscribed
        tokens.  Broadcasting a replacement snapshot is essential: connected
        dashboard clients otherwise have no deletion event and can keep old
        tokens indefinitely.
        """
        self.token_market = dict(token_market)
        allowed = set(self.token_market)
        self.quotes = {token: quote for token, quote in self.quotes.items() if token in allowed}
        self.publish_snapshot()

    def publish_snapshot(self) -> None:
        """Resynchronise connected read-only clients after a universe switch."""
        self._broadcast_payload(self.snapshot())

    def seed_from_persisted(self) -> int:
        """Warm a restarted hub from committed current-market BBO rows.

        The original capture timestamp is preserved, so the dashboard's quote
        freshness rule can still reject an old value.  This prevents a restart
        from publishing an empty state until the next exchange message arrives.
        """
        rows = self.read_persisted_rows(tuple(self.token_market))
        return self.apply_persisted_rows(rows)

    @staticmethod
    def read_persisted_rows(tokens: tuple[str, ...]) -> tuple[tuple[Any, ...], ...]:
        """Read immutable warmup rows; safe to call only in a worker thread."""
        if not tokens:
            return ()
        try:
            with contextlib.closing(
                sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=2)
            ) as db:
                marks = ",".join("?" for _ in tokens)
                rows = db.execute(f"""SELECT token_id,market_id,captured_at,best_bid,best_ask,bid_size,ask_size,event_reason,depth_fresh
                  FROM latest_bbo WHERE token_id IN ({marks})""", tokens).fetchall()
            return tuple(tuple(row) for row in rows)
        except sqlite3.Error as exc:
            logging.warning("state hub warmup skipped: %s", exc)
            return ()

    def apply_persisted_rows(self, rows: tuple[tuple[Any, ...], ...]) -> int:
        """Apply warmup rows on the owning event loop, preserving BBO schema."""
        for token, market, captured_at, bid, ask, bid_size, ask_size, reason, depth_fresh in rows:
            self.record_quote({
                "token": token,
                "market": market,
                "captured_at": captured_at,
                "bid": bid,
                "ask": ask,
                "bid_size": bid_size,
                "ask_size": ask_size,
                "reason": reason,
                "depth_fresh": bool(depth_fresh),
            })
        return len(rows)

    def record_quote(self, event: dict[str, Any]) -> None:
        self.sequence += 1
        published_at = datetime.now(UTC)
        exchange_at = event.get("exchange_at")
        received_at = event.get("received_at") or event.get("captured_at")
        source_to_receive_ms = None
        source_to_hub_ms = None
        if exchange_at:
            try:
                exchange_stamp = datetime.fromisoformat(
                    str(exchange_at).replace("Z", "+00:00")
                )
                if exchange_stamp.tzinfo is None:
                    exchange_stamp = exchange_stamp.replace(tzinfo=UTC)
                received_stamp = datetime.fromisoformat(
                    str(received_at).replace("Z", "+00:00")
                )
                if received_stamp.tzinfo is None:
                    received_stamp = received_stamp.replace(tzinfo=UTC)
                source_to_receive_ms = max(
                    0.0,
                    (received_stamp.astimezone(UTC) - exchange_stamp.astimezone(UTC)).total_seconds()
                    * 1000.0,
                )
                source_to_hub_ms = max(
                    0.0,
                    (published_at - exchange_stamp.astimezone(UTC)).total_seconds() * 1000.0,
                )
            except (TypeError, ValueError):
                exchange_at = None
        payload = {"type": "bbo", "schema": 2, "stream_id": self.stream_id,
                   "sequence": self.sequence,
                   "token_id": str(event["token"]), "market_id": str(event["market"]),
                   "captured_at": str(event["captured_at"]), "bid": event["bid"], "ask": event["ask"],
                   "bid_size": event["bid_size"], "ask_size": event["ask_size"],
                   "reason": event["reason"], "depth_fresh": bool(event["depth_fresh"]),
                   "exchange_at": str(exchange_at) if exchange_at else None,
                   "received_at": str(received_at) if received_at else None,
                   "published_at": published_at.isoformat(),
                   "source_to_receive_ms": (
                       round(source_to_receive_ms, 3)
                       if source_to_receive_ms is not None else None
                   ),
                   "source_to_hub_ms": (
                       round(source_to_hub_ms, 3)
                       if source_to_hub_ms is not None else None
                   ),
                   "levels": list(event.get("live_levels") or event.get("latest_levels") or [])}
        self.quotes[payload["token_id"]] = payload
        self._broadcast_payload(payload)

    def record_stream_status(self, connected: bool, detail: str) -> None:
        """Publish upstream connectivity without manufacturing a quote tick."""
        self.sequence += 1
        self.upstream = {
            "connected": bool(connected),
            "detail": str(detail)[:240],
            "updated_at": datetime.now(UTC).isoformat(),
        }
        payload = {
            "type": "status",
            "schema": 2,
            "stream_id": self.stream_id,
            "sequence": self.sequence,
            "upstream": dict(self.upstream),
        }
        self._broadcast_payload(payload)

    def _reconcile_snapshot(
        self, path_shadow: "IngressCommitShadow | None" = None
    ) -> dict[str, Any]:
        """Read one reconciliation snapshot outside the market event loop."""
        monotonic_now = time.monotonic()
        try:
            with contextlib.closing(
                sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=2)
            ) as db:
                # ``latest_bbo`` retains tokens from recently closed markets for
                # audit. Reconcile only the current subscription universe.
                tokens = list(self.token_market)
                if tokens:
                    marks = ",".join("?" for _ in tokens)
                    rows = db.execute(f"""SELECT token_id,market_id,captured_at,best_bid,best_ask,
                                                bid_size,ask_size
                                          FROM latest_bbo WHERE token_id IN ({marks})""", tokens).fetchall()
                else:
                    rows = db.execute("""SELECT token_id,market_id,captured_at,best_bid,best_ask,
                                                bid_size,ask_size FROM latest_bbo""").fetchall()
            persisted = {
                str(token): {
                    "market_id": str(market), "captured_at": str(captured_at),
                    "bid": bid, "ask": ask, "bid_size": bid_size,
                    "ask_size": ask_size,
                }
                for token, market, captured_at, bid, ask, bid_size, ask_size in rows
            }
            latest_at = max(
                (value["captured_at"] for value in persisted.values()),
                default=None,
            )
            latest = None
            if latest_at:
                # SQLite stores ISO strings.  Treat a timestamp without an
                # offset as UTC, and accept the RFC3339 ``Z`` spelling too.
                latest = datetime.fromisoformat(str(latest_at).replace("Z", "+00:00"))
                if latest.tzinfo is None:
                    latest = latest.replace(tzinfo=UTC)
            lag = (datetime.now(UTC) - latest).total_seconds() if latest else None
            db_count = len(persisted)
            value_mismatches = 0
            expected_ahead = 0
            for token in set(self.quotes) | set(persisted):
                memory = self.quotes.get(token)
                durable = persisted.get(token)
                matches = memory is not None and durable is not None and not any(
                    memory.get(key) != durable.get(key) for key in (
                    "market_id", "bid", "ask", "bid_size", "ask_size",
                    )
                )
                if matches:
                    continue
                memory_at = (
                    datetime.fromisoformat(
                        str(memory.get("captured_at")).replace("Z", "+00:00")
                    )
                    if memory is not None and memory.get("captured_at") else None
                )
                durable_at = (
                    datetime.fromisoformat(
                        str(durable.get("captured_at")).replace("Z", "+00:00")
                    )
                    if durable is not None and durable.get("captured_at") else None
                )
                direct_live_ahead = bool(
                    DIRECT_LIVE_BBO_ENABLED
                    and memory_at is not None
                    and durable_at is not None
                    and memory_at > durable_at
                    and (datetime.now(UTC) - memory_at.astimezone(UTC)).total_seconds()
                    <= max(20.0, BBO_HEARTBEAT_SECONDS + BBO_HEARTBEAT_SCAN_SECONDS)
                )
                if direct_live_ahead or (
                    memory is not None and path_shadow is not None
                    and path_shadow.is_expected_ahead(
                        token, memory, monotonic_now=monotonic_now
                    )
                ):
                    expected_ahead += 1
                else:
                    value_mismatches += 1
            healthy = (
                value_mismatches == 0
                and (lag is None or lag <= 20)
            )
            return {
                "state": ("ahead" if expected_ahead else "shadow") if healthy else "mismatch",
                "memory_tokens": len(self.quotes),
                "database_tokens": db_count,
                "value_mismatches": value_mismatches,
                "expected_ahead_tokens": expected_ahead,
                "database_lag_seconds": round(lag, 1) if lag is not None else None,
            }
        except Exception as exc:
            return {"state": "reconcile_error", "memory_tokens": len(self.quotes),
                    "database_tokens": None, "value_mismatches": None,
                    "database_lag_seconds": None, "error": type(exc).__name__}

    def reconcile(self, path_shadow: "IngressCommitShadow | None" = None) -> None:
        """Synchronous compatibility entry point for offline tools and tests."""
        monotonic_now = time.monotonic()
        if monotonic_now - self.last_reconcile < STATE_HUB_RECONCILE_SECONDS:
            return
        self.last_reconcile = monotonic_now
        self.shadow = self._reconcile_snapshot(path_shadow)

    def schedule_reconcile(
        self,
        path_shadow: "IngressCommitShadow | None" = None,
        *,
        timeout: float = STATE_HUB_READ_DEADLINE_SECONDS,
        force: bool = False,
    ) -> bool:
        """Schedule at most one bounded SQLite read without pausing quotes."""
        monotonic_now = time.monotonic()
        if not force and monotonic_now - self.last_reconcile < STATE_HUB_RECONCILE_SECONDS:
            return False
        if self.reconcile_task is not None and not self.reconcile_task.done():
            return False
        self.last_reconcile = monotonic_now
        self.reconcile_task = asyncio.create_task(
            self._run_reconcile(path_shadow, max(0.01, timeout)),
            name="live-state-reconcile",
        )
        return True

    async def _run_reconcile(
        self, path_shadow: "IngressCommitShadow | None", timeout: float
    ) -> None:
        worker = asyncio.create_task(asyncio.to_thread(self._reconcile_snapshot, path_shadow))
        try:
            self.shadow = await asyncio.wait_for(asyncio.shield(worker), timeout=timeout)
        except TimeoutError:
            self.shadow = {
                "state": "reconcile_timeout",
                "memory_tokens": len(self.quotes),
                "database_tokens": None,
                "value_mismatches": None,
                "database_lag_seconds": None,
            }
            # Keep this task in flight until the one underlying read exits. This
            # prevents a lock episode from creating an unbounded thread backlog.
            with contextlib.suppress(Exception):
                await worker
        except Exception as exc:
            self.shadow = {
                "state": "reconcile_error",
                "memory_tokens": len(self.quotes),
                "database_tokens": None,
                "value_mismatches": None,
                "database_lag_seconds": None,
                "error": type(exc).__name__,
            }

    def status_fragment(self, path_shadow: "IngressCommitShadow | None" = None) -> str:
        if STATE_HUB_ENABLED and (
            self.server is None or not self.server.is_serving()
        ):
            self.shadow["state"] = "listener_down"
        return (f"state_hub={self.shadow.get('state')} mem={self.shadow.get('memory_tokens')} "
                f"db={self.shadow.get('database_tokens')} clients={len(self.clients)} "
                f"listener_restarts={self.listener_restart_count}")


class IngressCommitShadow:
    """Compare immediate accepted BBOs with asynchronous durable commits.

    This state is never exposed to the dashboard or strategy.  It proves that
    a future in-memory hot path can stay ahead of SQLite without silently
    diverging from the durable audit path.
    """

    _VALUE_KEYS = (
        "market", "captured_at", "bid", "ask", "bid_size", "ask_size",
        "reason", "depth_fresh",
    )

    def __init__(self, *, pending_stale_seconds: float = 5.0) -> None:
        self.pending_stale_seconds = pending_stale_seconds
        self.sequence = 0
        self.token_market: dict[str, str] = {}
        self.ingress: dict[str, dict[str, Any]] = {}
        self.committed_sequence: dict[str, int] = {}
        self.accepted_count = 0
        self.rejected_count = 0
        self.committed_count = 0
        self.unknown_commit_count = 0
        self.out_of_order_count = 0
        self.value_mismatch_count = 0
        self.retired_commit_count = 0
        self.retired_tokens: set[str] = set()
        self.commit_lag_sum_ms = 0.0
        self.last_commit_lag_ms: float | None = None
        self.max_commit_lag_ms: float | None = None

    def set_universe(self, token_market: dict[str, str]) -> None:
        previous = set(self.token_market)
        self.token_market = dict(token_market)
        allowed = set(self.token_market)
        self.retired_tokens.update(previous - allowed)
        self.retired_tokens.difference_update(allowed)
        self.ingress = {
            token: event for token, event in self.ingress.items()
            if token in allowed
        }
        self.committed_sequence = {
            token: sequence for token, sequence in self.committed_sequence.items()
            if token in allowed
        }

    def record_ingress(self, event: dict[str, Any], *,
                       monotonic_now: float | None = None) -> None:
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        self.sequence += 1
        event["_shadow_sequence"] = self.sequence
        event["_shadow_ingress_monotonic"] = monotonic_now
        token = str(event["token"])
        self.ingress[token] = {
            **{key: event.get(key) for key in self._VALUE_KEYS},
            "sequence": self.sequence,
            "ingress_monotonic": monotonic_now,
        }
        self.accepted_count += 1

    def record_rejection(self, event: dict[str, Any]) -> None:
        token = str(event.get("token") or "")
        sequence = int(event.get("_shadow_sequence") or 0)
        latest = self.ingress.get(token)
        if latest and int(latest["sequence"]) == sequence:
            self.ingress.pop(token, None)
        self.accepted_count = max(0, self.accepted_count - 1)
        self.rejected_count += 1

    def record_commit(self, event: dict[str, Any], *,
                      monotonic_now: float | None = None) -> None:
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        token = str(event.get("token") or "")
        sequence = int(event.get("_shadow_sequence") or 0)
        ingress_monotonic = event.get("_shadow_ingress_monotonic")
        if not token or sequence <= 0 or ingress_monotonic is None:
            self.unknown_commit_count += 1
            return
        if token in self.retired_tokens:
            # The persistence worker may complete an event already queued
            # before a rollover unsubscribe.  It remains valid durable history,
            # but must not recreate retired live-state or a false mismatch.
            self.retired_commit_count += 1
            return
        previous = self.committed_sequence.get(token, 0)
        if sequence <= previous:
            self.out_of_order_count += 1
            return
        latest = self.ingress.get(token)
        if latest and int(latest["sequence"]) == sequence:
            if any(event.get(key) != latest.get(key) for key in self._VALUE_KEYS):
                self.value_mismatch_count += 1
        elif latest and sequence > int(latest["sequence"]):
            # A durable event can never be newer than the latest accepted
            # in-memory event for the same token.
            self.out_of_order_count += 1
        self.committed_sequence[token] = sequence
        self.committed_count += 1
        lag_ms = max(0.0, (monotonic_now - float(ingress_monotonic)) * 1000.0)
        self.last_commit_lag_ms = lag_ms
        self.max_commit_lag_ms = (
            lag_ms if self.max_commit_lag_ms is None
            else max(self.max_commit_lag_ms, lag_ms)
        )
        self.commit_lag_sum_ms += lag_ms

    def is_expected_ahead(self, token: str, memory: dict[str, Any], *,
                          monotonic_now: float | None = None) -> bool:
        """True only while this exact in-memory value awaits durable commit."""
        latest = self.ingress.get(str(token))
        if not latest:
            return False
        if int(latest["sequence"]) <= self.committed_sequence.get(str(token), 0):
            return False
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        if monotonic_now - float(latest["ingress_monotonic"]) > self.pending_stale_seconds:
            return False
        mapped = {
            "market": memory.get("market_id"),
            "captured_at": memory.get("captured_at"),
            "bid": memory.get("bid"),
            "ask": memory.get("ask"),
            "bid_size": memory.get("bid_size"),
            "ask_size": memory.get("ask_size"),
            "reason": memory.get("reason"),
            "depth_fresh": memory.get("depth_fresh"),
        }
        return all(latest.get(key) == mapped.get(key) for key in self._VALUE_KEYS)

    def snapshot(self, *, monotonic_now: float | None = None) -> dict[str, Any]:
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        pending = []
        for token, event in self.ingress.items():
            if int(event["sequence"]) > self.committed_sequence.get(token, 0):
                pending.append((token, max(
                    0.0, monotonic_now - float(event["ingress_monotonic"])
                )))
        stale_pending = [
            token for token, age in pending if age > self.pending_stale_seconds
        ]
        oldest_pending = max((age for _, age in pending), default=None)
        hard_mismatches = (
            self.rejected_count
            + self.unknown_commit_count
            + self.out_of_order_count
            + self.value_mismatch_count
        )
        state = (
            "mismatch" if hard_mismatches or stale_pending
            else "shadow"
        )
        average_lag = (
            self.commit_lag_sum_ms / self.committed_count
            if self.committed_count else None
        )
        return {
            "mode": "shadow",
            "state": state,
            "active_tokens": len(self.token_market),
            "ingress_tokens": len(self.ingress),
            "accepted": self.accepted_count,
            "rejected": self.rejected_count,
            "committed": self.committed_count,
            "pending_tokens": len(pending),
            "stale_pending_tokens": len(stale_pending),
            "oldest_pending_ms": (
                round(oldest_pending * 1000.0, 3)
                if oldest_pending is not None else None
            ),
            "unknown_commits": self.unknown_commit_count,
            "out_of_order_commits": self.out_of_order_count,
            "value_mismatches": self.value_mismatch_count,
            "retired_commits": self.retired_commit_count,
            "last_commit_lag_ms": (
                round(self.last_commit_lag_ms, 3)
                if self.last_commit_lag_ms is not None else None
            ),
            "average_commit_lag_ms": (
                round(average_lag, 3) if average_lag is not None else None
            ),
            "max_commit_lag_ms": (
                round(self.max_commit_lag_ms, 3)
                if self.max_commit_lag_ms is not None else None
            ),
        }

    def status_fragment(self) -> str:
        metrics = self.snapshot()
        return (
            f"path={metrics['state']} pending={metrics['pending_tokens']}/"
            f"{metrics['stale_pending_tokens']} "
            f"commit_ms={metrics['last_commit_lag_ms']} "
            f"path_bad={metrics['unknown_commits'] + metrics['out_of_order_commits'] + metrics['value_mismatches']}"
        )


class MarketProtocolShadow:
    """Observe official market-channel heartbeat and event clocks.

    These metrics are deliberately isolated from BBO acceptance.  In
    particular, an exchange timestamp is never substituted for the local
    ``captured_at`` clock while this class remains in shadow mode.
    """

    def __init__(self, *, ping_interval: float = APP_PING_INTERVAL_SECONDS,
                 pong_stale_seconds: float = APP_PONG_STALE_SECONDS) -> None:
        self.ping_interval = ping_interval
        self.pong_stale_seconds = pong_stale_seconds
        self.connected = False
        self.connection_count = 0
        self.last_ping_monotonic: float | None = None
        self.pending_pings: deque[float] = deque()
        self.pings_sent = 0
        self.pongs_received = 0
        self.unsolicited_pongs = 0
        self.last_pong_rtt_ms: float | None = None
        self.max_pong_rtt_ms: float | None = None
        self.event_count = 0
        self.timestamp_valid = 0
        self.timestamp_missing = 0
        self.timestamp_invalid = 0
        self.timestamp_future = 0
        self.event_age_sum_ms = 0.0
        self.last_event_age_ms: float | None = None
        self.max_event_age_ms: float | None = None
        self.last_exchange_event_at: str | None = None

    @staticmethod
    def parse_exchange_timestamp(raw: Any) -> datetime | None:
        """Parse the market channel's documented Unix-millisecond clock."""
        if raw is None or isinstance(raw, bool):
            return None
        try:
            milliseconds = float(str(raw).strip())
        except (TypeError, ValueError):
            return None
        # Market events document a 13-digit Unix-millisecond timestamp.
        # Reject seconds, zero, infinities and implausible extra precision
        # rather than silently converting the wrong unit.
        if not 100_000_000_000 <= milliseconds < 100_000_000_000_000:
            return None
        try:
            return datetime.fromtimestamp(milliseconds / 1000.0, UTC)
        except (OverflowError, OSError, ValueError):
            return None

    def on_connect(self) -> None:
        self.connected = True
        self.connection_count += 1
        self.last_ping_monotonic = None
        self.pending_pings.clear()

    def on_disconnect(self) -> None:
        self.connected = False
        self.pending_pings.clear()

    async def maybe_send_ping(
        self,
        websocket: Any,
        *,
        force: bool = False,
        monotonic_now: float | None = None,
        timeout: float = STREAM_CONTROL_DEADLINE_SECONDS,
    ) -> bool:
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        if (not force and self.last_ping_monotonic is not None
                and monotonic_now - self.last_ping_monotonic < self.ping_interval):
            return False
        await _await_stream_control(
            websocket.send("PING"), "market_ping", timeout=timeout
        )
        self.last_ping_monotonic = monotonic_now
        self.pending_pings.append(monotonic_now)
        # Bound diagnostic state even if the remote endpoint never responds.
        while len(self.pending_pings) > 12:
            self.pending_pings.popleft()
        self.pings_sent += 1
        return True

    def observe_text(self, raw: Any, *, monotonic_now: float | None = None) -> bool:
        """Consume only the documented PONG text without hiding other input."""
        if isinstance(raw, bytes):
            with contextlib.suppress(UnicodeDecodeError):
                raw = raw.decode("utf-8")
        if not isinstance(raw, str) or raw.strip().upper() != "PONG":
            return False
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        self.pongs_received += 1
        if self.pending_pings:
            sent_at = self.pending_pings.popleft()
            rtt_ms = max(0.0, (monotonic_now - sent_at) * 1000.0)
            self.last_pong_rtt_ms = rtt_ms
            self.max_pong_rtt_ms = (
                rtt_ms if self.max_pong_rtt_ms is None
                else max(self.max_pong_rtt_ms, rtt_ms)
            )
        else:
            self.unsolicited_pongs += 1
        return True

    def observe_event(self, payload: dict[str, Any], *,
                      received_at: datetime | None = None) -> datetime | None:
        self.event_count += 1
        raw_timestamp = payload.get("timestamp")
        if raw_timestamp is None:
            self.timestamp_missing += 1
            return None
        exchange_at = self.parse_exchange_timestamp(raw_timestamp)
        if exchange_at is None:
            self.timestamp_invalid += 1
            return None
        received_at = received_at or datetime.now(UTC)
        if received_at.tzinfo is None:
            received_at = received_at.replace(tzinfo=UTC)
        event_age_ms = (received_at.astimezone(UTC) - exchange_at).total_seconds() * 1000.0
        if event_age_ms < -EXCHANGE_CLOCK_FUTURE_TOLERANCE_MS:
            self.timestamp_future += 1
            return None
        self.timestamp_valid += 1
        self.event_age_sum_ms += event_age_ms
        self.last_event_age_ms = event_age_ms
        self.max_event_age_ms = (
            event_age_ms if self.max_event_age_ms is None
            else max(self.max_event_age_ms, event_age_ms)
        )
        self.last_exchange_event_at = exchange_at.isoformat()
        return exchange_at

    def snapshot(self, *, monotonic_now: float | None = None) -> dict[str, Any]:
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        oldest_pending_seconds = (
            max(0.0, monotonic_now - self.pending_pings[0])
            if self.pending_pings else None
        )
        pong_is_late = (
            oldest_pending_seconds is not None
            and oldest_pending_seconds > self.pong_stale_seconds
        )
        pong_state = (
            "late" if pong_is_late
            else "waiting" if self.pongs_received == 0
            else "ok"
        )
        coverage = self.timestamp_valid / self.event_count if self.event_count else None
        average_age = (
            self.event_age_sum_ms / self.timestamp_valid
            if self.timestamp_valid else None
        )
        return {
            "mode": "shadow",
            "connected": self.connected,
            "connection_count": self.connection_count,
            "ping_state": pong_state,
            "pings_sent": self.pings_sent,
            "pongs_received": self.pongs_received,
            "pending_pings": len(self.pending_pings),
            "oldest_pending_seconds": (
                round(oldest_pending_seconds, 3)
                if oldest_pending_seconds is not None else None
            ),
            "last_pong_rtt_ms": (
                round(self.last_pong_rtt_ms, 3)
                if self.last_pong_rtt_ms is not None else None
            ),
            "max_pong_rtt_ms": (
                round(self.max_pong_rtt_ms, 3)
                if self.max_pong_rtt_ms is not None else None
            ),
            "events": self.event_count,
            "timestamp_valid": self.timestamp_valid,
            "timestamp_missing": self.timestamp_missing,
            "timestamp_invalid": self.timestamp_invalid,
            "timestamp_future": self.timestamp_future,
            "timestamp_coverage": round(coverage, 6) if coverage is not None else None,
            "last_exchange_event_at": self.last_exchange_event_at,
            "last_event_age_ms": (
                round(self.last_event_age_ms, 3)
                if self.last_event_age_ms is not None else None
            ),
            "average_event_age_ms": (
                round(average_age, 3) if average_age is not None else None
            ),
            "max_event_age_ms": (
                round(self.max_event_age_ms, 3)
                if self.max_event_age_ms is not None else None
            ),
        }

    def status_fragment(self) -> str:
        metrics = self.snapshot()
        return (
            f"protocol=shadow pong={metrics['ping_state']} "
            f"ping={metrics['pongs_received']}/{metrics['pings_sent']} "
            f"ts={metrics['timestamp_valid']}/{metrics['events']} "
            f"age_ms={metrics['last_event_age_ms']} bad_ts="
            f"{metrics['timestamp_invalid'] + metrics['timestamp_future']}"
        )


class StreamState:
    def __init__(self, db: sqlite3.Connection | None, token_market: dict[str, str], writer: PersistenceWriter,
                 hub: LiveStateHub, universe_hash: str,
                 protocol: MarketProtocolShadow | None = None,
                 path_shadow: IngressCommitShadow | None = None,
                 token_target_date: dict[str, str] | None = None,
                 progress: WorkerProgressPublisher | None = None,
                 manifest: UniverseManifest | None = None) -> None:
        # ``db`` remains in the constructor only for compatibility with the
        # deterministic unit fixtures. Runtime code passes None: all realtime
        # SQLite mutations belong to PersistenceWriter's single connection.
        self.db = db
        self.token_market = dict(token_market)
        self.token_target_date = dict(token_target_date or {})
        self.writer = writer
        self.hub = hub
        self.protocol = protocol or MarketProtocolShadow()
        self.path_shadow = path_shadow or IngressCommitShadow()
        self.path_shadow.set_universe(token_market)
        self.books: dict[str, dict[str, dict[float, float]]] = {}
        self.market_rules: dict[str, dict[str, Any]] = {}
        self.last_bbo_write: dict[str, float] = {}
        self.last_persisted_bbo_state: dict[
            str, tuple[float | None, float | None, float | None, float | None]
        ] = {}
        self.last_live_bbo_state: dict[
            str, tuple[float | None, float | None, float | None, float | None]
        ] = {}
        self.last_live_levels: dict[str, tuple[tuple[str, float, float], ...]] = {}
        self.latest_bbo: dict[str, tuple[float | None, float | None, float | None, float | None]] = {}
        self.last_persisted_captured_at: dict[str, datetime] = {}
        self.last_live_captured_at: dict[str, datetime] = {}
        self.last_live_exchange_at: dict[str, datetime] = {}
        self.last_depth_write: dict[str, float] = {}
        self.last_bbo_heartbeat_scan = 0.0
        self.last_heartbeat = 0.0
        self.last_maintenance = 0.0
        self.last_subscription_check = 0.0
        self.dynamic_manifest_read = AsyncSingleFlightRead("dynamic-manifest")
        self.pending_shrink_hash: str | None = None
        self.pending_shrink_count = 0
        self.pending_forward_rollover_hash: str | None = None
        self.pending_forward_rollover_current_hash: str | None = None
        self.pending_forward_rollover_transition: str | None = None
        self.pending_forward_rollover_count = 0
        self.universe_hash = universe_hash
        self.progress = progress
        self.manifest = manifest or UniverseManifest(
            tuple(sorted(token_market)), dict(token_market), universe_hash,
            dict(token_target_date or {}), format="legacy_literal",
        )

    def heartbeat(self, detail: str, *, force: bool = False) -> None:
        monotonic_now = time.monotonic()
        if not force and monotonic_now - self.last_heartbeat < HEARTBEAT_INTERVAL_SECONDS:
            return
        accepted = self.writer.submit_diagnostic(
            detail,
            self.protocol.snapshot(),
            self.path_shadow.snapshot(),
        )
        if self.progress is not None:
            self.progress.publish("connected", detail=detail)
        if accepted:
            self.last_heartbeat = monotonic_now

    def maintain(self) -> None:
        """Compatibility no-op; writer thread owns all SQLite maintenance."""
        self.last_maintenance = time.monotonic()

    def subscription_update(self, *, now_cn: datetime | None = None,
                            monotonic_now: float | None = None) -> UniverseChange | None:
        """Plan a fail-closed dynamic update from the latest atomic manifest."""
        if not DYNAMIC_UNIVERSE_ENABLED:
            return None
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        if monotonic_now - self.last_subscription_check < SUBSCRIPTION_CHECK_INTERVAL_SECONDS:
            return None
        self.last_subscription_check = monotonic_now
        now_cn = now_cn or datetime.now(CHINA_TZ)
        candidate = published_universe_manifest()
        if candidate is None or not candidate.assets:
            self._clear_pending_forward_rollover()
            return None
        return self.plan_subscription_update(candidate, now_cn=now_cn)

    def _clear_pending_forward_rollover(self) -> None:
        self.pending_forward_rollover_hash = None
        self.pending_forward_rollover_current_hash = None
        self.pending_forward_rollover_transition = None
        self.pending_forward_rollover_count = 0

    def plan_subscription_update(
        self, candidate: UniverseManifest, *, now_cn: datetime
    ) -> UniverseChange | None:
        """Plan an already-read manifest on the event-loop thread."""
        if candidate.token_hash == self.universe_hash:
            self._clear_pending_forward_rollover()
            return None
        current = self.manifest
        if current.token_hash != self.universe_hash:
            self.pending_shrink_hash = None
            self.pending_shrink_count = 0
            self._clear_pending_forward_rollover()
            return None
        added = set(candidate.assets) - set(current.assets)
        removed = set(current.assets) - set(candidate.assets)
        shrink_confirmed = False
        forward_mixed_confirmed = False
        if removed and not added:
            eligible = validate_universe_transition(
                current, candidate, now_cn=now_cn, shrink_confirmed=True,
            )
            if eligible is None:
                self.pending_shrink_hash = None
                self.pending_shrink_count = 0
                return None
            if self.pending_shrink_hash == candidate.token_hash:
                self.pending_shrink_count += 1
            else:
                self.pending_shrink_hash = candidate.token_hash
                self.pending_shrink_count = 1
            shrink_confirmed = self.pending_shrink_count >= 2
        else:
            self.pending_shrink_hash = None
            self.pending_shrink_count = 0
        if added and removed:
            eligible = validate_universe_transition(
                current, candidate, now_cn=now_cn,
                forward_mixed_confirmed=True,
            )
            if eligible is None:
                self._clear_pending_forward_rollover()
                return None
            if (
                self.pending_forward_rollover_hash == candidate.token_hash
                and self.pending_forward_rollover_current_hash == current.token_hash
                and self.pending_forward_rollover_transition == eligible.format_transition
            ):
                self.pending_forward_rollover_count += 1
            else:
                self.pending_forward_rollover_hash = candidate.token_hash
                self.pending_forward_rollover_current_hash = current.token_hash
                self.pending_forward_rollover_transition = eligible.format_transition
                self.pending_forward_rollover_count = 1
            forward_mixed_confirmed = self.pending_forward_rollover_count >= 2
        else:
            self._clear_pending_forward_rollover()
        change = validate_universe_transition(
            current, candidate, now_cn=now_cn,
            shrink_confirmed=shrink_confirmed,
            forward_mixed_confirmed=forward_mixed_confirmed,
        )
        if change is None:
            return None
        if change.removed and not (shrink_confirmed or forward_mixed_confirmed):
            return None
        if change.removed:
            self.pending_shrink_hash = None
            self.pending_shrink_count = 0
            self._clear_pending_forward_rollover()
        return change

    def apply_universe(self, manifest: UniverseManifest) -> None:
        """Commit an update locally only after the websocket send succeeds."""
        allowed = set(manifest.assets)
        self.token_market = dict(manifest.token_market)
        self.token_target_date = dict(manifest.token_target_date)
        self.universe_hash = manifest.token_hash
        self.manifest = manifest
        self.pending_shrink_hash = None
        self.pending_shrink_count = 0
        self._clear_pending_forward_rollover()
        self.books = {token: value for token, value in self.books.items() if token in allowed}
        self.market_rules = {
            token: value for token, value in self.market_rules.items() if token in allowed
        }
        self.last_bbo_write = {
            token: value for token, value in self.last_bbo_write.items() if token in allowed
        }
        self.last_persisted_bbo_state = {
            token: value for token, value in self.last_persisted_bbo_state.items()
            if token in allowed
        }
        self.last_live_bbo_state = {
            token: value for token, value in self.last_live_bbo_state.items()
            if token in allowed
        }
        self.last_live_levels = {
            token: value for token, value in self.last_live_levels.items()
            if token in allowed
        }
        self.latest_bbo = {
            token: value for token, value in self.latest_bbo.items() if token in allowed
        }
        self.last_persisted_captured_at = {
            token: value for token, value in self.last_persisted_captured_at.items()
            if token in allowed
        }
        self.last_live_captured_at = {
            token: value for token, value in self.last_live_captured_at.items()
            if token in allowed
        }
        self.last_live_exchange_at = {
            token: value for token, value in self.last_live_exchange_at.items()
            if token in allowed
        }
        self.last_depth_write = {
            token: value for token, value in self.last_depth_write.items() if token in allowed
        }
        self.hub.set_universe(self.token_market)
        self.path_shadow.set_universe(self.token_market)

    def write_bbo(self, token: str, bid: float | None, ask: float | None,
                  bid_size: float | None = None, ask_size: float | None = None,
                  *, depth_fresh: bool = False,
                  exchange_at: datetime | None = None,
                  received_at: datetime | None = None,
                  market_rules: dict[str, Any] | None = None) -> bool:
        market = self.token_market.get(token)
        if not market:
            return False
        previous_rules = self.market_rules.get(token)
        if market_rules is not None:
            self.market_rules[token] = dict(market_rules)
        rules = self.market_rules.get(token)
        def rule_values(value: dict[str, Any] | None) -> tuple[Any, Any, Any] | None:
            if value is None:
                return None
            return (value.get("tick_size"), value.get("min_order_size"), value.get("neg_risk"))
        rules_changed = market_rules is not None and rule_values(previous_rules) != rule_values(rules)
        # Reject the artificial outer quotes which are not executable signal.
        if bid is not None and ask is not None and bid <= 0.001 and ask >= 0.999:
            return False
        monotonic_now = time.monotonic()
        received_at = received_at or datetime.now(UTC)
        if received_at.tzinfo is None:
            received_at = received_at.replace(tzinfo=UTC)
        received_at = received_at.astimezone(UTC)
        if exchange_at is not None:
            if exchange_at.tzinfo is None:
                exchange_at = exchange_at.replace(tzinfo=UTC)
            exchange_at = exchange_at.astimezone(UTC)
        previous_latest = self.latest_bbo.get(token)
        if previous_latest:
            if bid_size is None:
                bid_size = previous_latest[2]
            if ask_size is None:
                ask_size = previous_latest[3]
        state = (bid, ask, bid_size, ask_size)
        self.latest_bbo[token] = state
        live_levels: list[tuple[str, float, float]] = []
        book = self.books.get(token)
        if depth_fresh and book:
            for side, reverse in (("bid", True), ("ask", False)):
                live_levels.extend(
                    (side, price, size)
                    for price, size in sorted(
                        ((p, s) for p, s in book[side].items() if s > 0),
                        reverse=reverse,
                    )[:5]
                )
        live_levels_key = tuple(live_levels)
        previous_live = self.last_live_bbo_state.get(token)
        live_changed = (
            previous_live != state
            or (bool(live_levels) and self.last_live_levels.get(token) != live_levels_key)
            or rules_changed
        )
        previous_exchange_at = self.last_live_exchange_at.get(token)
        live_confirmed = (
            exchange_at is not None
            and (previous_exchange_at is None or exchange_at > previous_exchange_at)
        )
        live_published = False
        if DIRECT_LIVE_BBO_ENABLED and (live_changed or live_confirmed):
            live_captured_at = received_at
            previous_live_at = self.last_live_captured_at.get(token)
            if previous_live_at is not None and live_captured_at <= previous_live_at:
                live_captured_at = previous_live_at + timedelta(microseconds=1)
            self.last_live_captured_at[token] = live_captured_at
            live_event = {
                "captured_at": live_captured_at.isoformat(),
                "received_at": received_at.isoformat(),
                "exchange_at": exchange_at.isoformat() if exchange_at else None,
                "market": market,
                "token": token,
                "bid": bid,
                "ask": ask,
                "bid_size": bid_size,
                "ask_size": ask_size,
                "reason": (
                    "initial" if previous_live is None
                    else "price_change" if previous_live[:2] != state[:2]
                    else "book_change" if live_changed
                    else "confirmation"
                ),
                "depth_fresh": bool(live_levels),
                "live_levels": live_levels,
                "market_rules": rules,
            }
            self.hub.record_quote(live_event)
            self.last_live_bbo_state[token] = state
            if live_levels:
                self.last_live_levels[token] = live_levels_key
            if exchange_at is not None:
                self.last_live_exchange_at[token] = exchange_at
            live_published = True

        previous = self.last_persisted_bbo_state.get(token)
        initial = previous is None
        price_changed = previous is not None and previous[:2] != state[:2]

        def size_changed(old: float | None, new: float | None) -> bool:
            if old is None or new is None:
                return old != new
            absolute = abs(new - old)
            relative = absolute / max(abs(old), 1e-9)
            return absolute >= BBO_SIZE_CHANGE_MIN or relative >= BBO_SIZE_CHANGE_RATIO

        material_size_change = previous is not None and (
            size_changed(previous[2], state[2]) or size_changed(previous[3], state[3])
        )
        seconds_since_write = monotonic_now - self.last_bbo_write.get(token, 0.0)
        price_write_due = seconds_since_write >= BBO_PRICE_WRITE_SECONDS
        size_write_due = seconds_since_write >= BBO_SIZE_WRITE_SECONDS
        material_size_change = material_size_change and size_write_due
        heartbeat_due = seconds_since_write >= BBO_HEARTBEAT_SECONDS
        # Retain a precise, bounded time series instead of every websocket tick:
        # price changes coalesce for five seconds, while all quiet books still
        # receive a 15-second heartbeat to prove continuity and freshness.
        if not (
            initial or rules_changed or (price_changed and price_write_due)
            or material_size_change or heartbeat_due
        ):
            return live_published
        reason = (
            "initial" if initial else "rules_change" if rules_changed
            else "price_change" if price_changed else "size_change"
            if material_size_change else "heartbeat"
        )
        captured_at = received_at
        previous_captured_at = self.last_persisted_captured_at.get(token)
        if previous_captured_at is not None and captured_at <= previous_captured_at:
            captured_at = previous_captured_at + timedelta(microseconds=1)
        self.last_persisted_captured_at[token] = captured_at
        levels: list[tuple[str, float, float]] = []
        latest_levels = live_levels if reason != "heartbeat" else []
        depth_due = monotonic_now - self.last_depth_write.get(token, 0.0) >= DEPTH_SNAPSHOT_SECONDS
        if depth_due:
            levels = latest_levels
        event = {"captured_at": captured_at.isoformat(), "market": market, "token": token,
            "bid": bid, "ask": ask, "bid_size": bid_size, "ask_size": ask_size,
            "reason": reason, "depth_fresh": bool(latest_levels), "levels": levels,
            "latest_levels": latest_levels,
            "received_at": received_at.isoformat(),
            "exchange_at": exchange_at.isoformat() if exchange_at else None,
            "market_rules": rules}
        # This internal shadow is intentionally recorded before SQLite.  It
        # isn't broadcast and cannot affect dashboard or strategy consumers.
        self.path_shadow.record_ingress(event)
        accepted = self.writer.submit(event)
        if not accepted:
            self.path_shadow.record_rejection(event)
            return live_published
        # Rollback compatibility only: the normal direct path has already
        # published without waiting for queue capacity or SQLite.
        if not DIRECT_LIVE_BBO_ENABLED:
            self.hub.record_quote(event)
            self.last_live_bbo_state[token] = state
            if latest_levels:
                self.last_live_levels[token] = tuple(latest_levels)
        self.last_bbo_write[token] = monotonic_now
        self.last_persisted_bbo_state[token] = state
        if levels:
            self.last_depth_write[token] = monotonic_now
        return True

    def flush_bbo_heartbeats(self) -> None:
        """Persist one unchanged BBO per minute for every known token."""
        monotonic_now = time.monotonic()
        if monotonic_now - self.last_bbo_heartbeat_scan < BBO_HEARTBEAT_SCAN_SECONDS:
            return
        self.last_bbo_heartbeat_scan = monotonic_now
        for token, state in list(self.latest_bbo.items()):
            if monotonic_now - self.last_bbo_write.get(token, 0.0) < BBO_HEARTBEAT_SECONDS:
                continue
            self.write_bbo(token, *state, depth_fresh=False)

    def snapshot_book(self, token: str, bids: list[dict[str, Any]], asks: list[dict[str, Any]],
                      *, exchange_at: datetime | None = None,
                      received_at: datetime | None = None,
                      market_rules: dict[str, Any] | None = None) -> None:
        book = {"bid": {}, "ask": {}}
        for side, levels in (("bid", bids), ("ask", asks)):
            for item in levels:
                try:
                    book[side][float(item["price"])] = float(item.get("size", 0))
                except (KeyError, TypeError, ValueError):
                    continue
        self.books[token] = book
        bid, bid_size = best(book["bid"], "bid")
        ask, ask_size = best(book["ask"], "ask")
        self.write_bbo(
            token, bid, ask, bid_size, ask_size, depth_fresh=True,
            exchange_at=exchange_at, received_at=received_at,
            market_rules=market_rules,
        )

    def price_change(self, item: dict[str, Any], *,
                     exchange_at: datetime | None = None,
                     received_at: datetime | None = None) -> None:
        token = str(item.get("asset_id") or item.get("assetId") or "")
        if token not in self.token_market:
            return
        book = self.books.setdefault(token, {"bid": {}, "ask": {}})
        try:
            raw_side = str(item.get("side", "")).lower()
            side = {"buy": "bid", "sell": "ask"}.get(raw_side, raw_side)
            if side not in book:
                return
            price, size = float(item["price"]), float(item.get("size", 0))
        except (KeyError, TypeError, ValueError):
            return
        book[side][price] = size
        bid, bid_size = best(book["bid"], "bid")
        ask, ask_size = best(book["ask"], "ask")
        self.write_bbo(
            token, bid, ask, bid_size, ask_size, depth_fresh=True,
            exchange_at=exchange_at, received_at=received_at,
        )

    def handle(self, data: dict[str, Any], *,
               received_at: datetime | None = None) -> None:
        received_at = received_at or datetime.now(UTC)
        exchange_at = self.protocol.observe_event(data, received_at=received_at)
        kind = data.get("event_type")
        if kind == "book":
            token = str(data.get("asset_id") or data.get("assetId") or "")
            self.snapshot_book(
                token, data.get("bids", []), data.get("asks", []),
                exchange_at=exchange_at, received_at=received_at,
                market_rules=validated_book_rules(data),
            )
        elif kind == "best_bid_ask":
            token = str(data.get("asset_id") or data.get("assetId") or "")
            try:
                bid = float(data["best_bid"]) if data.get("best_bid") is not None else None
                ask = float(data["best_ask"]) if data.get("best_ask") is not None else None
            except (TypeError, ValueError):
                return
            self.write_bbo(
                token, bid, ask,
                exchange_at=exchange_at, received_at=received_at,
            )
        elif kind == "price_change":
            for item in data.get("price_changes", []):
                self.price_change(
                    item, exchange_at=exchange_at, received_at=received_at
                )
        elif kind == "tick_size_change":
            token = str(data.get("asset_id") or data.get("assetId") or "")
            current = self.market_rules.get(token)
            try:
                new_tick = Decimal(str(data.get("new_tick_size")))
            except (InvalidOperation, TypeError, ValueError):
                new_tick = Decimal("0")
            if (
                current is not None and new_tick.is_finite()
                and Decimal("0") < new_tick < Decimal("1")
            ):
                updated = dict(current)
                updated["tick_size"] = format(new_tick.normalize(), "f")
                stamp = received_at.astimezone(UTC).isoformat()
                if self.writer.submit_market_rules(
                    token_id=token,
                    market_id=self.token_market[token],
                    captured_at=stamp,
                    rules=updated,
                ):
                    self.market_rules[token] = updated
        self.flush_bbo_heartbeats()


async def apply_manifest_candidate(
    websocket: Any,
    state: StreamState,
    candidate: UniverseManifest,
    *,
    now_cn: datetime | None = None,
) -> UniverseChange | None:
    """Send, durably enqueue acceptance, then apply one normal transition."""
    now_cn = now_cn or datetime.now(CHINA_TZ)
    change = state.plan_subscription_update(candidate, now_cn=now_cn)
    if change is None:
        return None
    recovery_manifest = None
    if change.added or change.removed:
        recovery_manifest = revalidate_recovery_manifest(state.manifest)
        if recovery_manifest is None:
            logging.error(
                "reject remote universe change without validated recovery manifest"
            )
            return None
    remote_operations = await _send_universe_change(
        websocket, change, recovery_manifest=recovery_manifest,
    )
    if change.format_transition in {
        "forward_mixed_rollover", "legacy_to_v1_forward_mixed",
    }:
        audit_detail = json.dumps({
            "transition": change.format_transition,
            "from_hash": state.universe_hash,
            "to_hash": change.manifest.token_hash,
            "token_count": len(change.manifest.assets),
            "added": list(change.added),
            "removed": list(change.removed),
            "remapped": [],
            "reason": (
                "safe legacy to v1 forward mixed rollover"
                if change.format_transition == "legacy_to_v1_forward_mixed"
                else "safe forward mixed rollover"
            ),
        }, ensure_ascii=True, separators=(",", ":"), sort_keys=True)
    else:
        audit_detail = (
            "legacy_to_v1 zero-asset format upgrade"
            if change.format_transition == "legacy_to_v1"
            else "dynamic websocket subscription updated"
        )
    try:
        accepted = record_connection_event(
            state.writer,
            "universe_changed",
            audit_detail,
            universe_hash=change.manifest.token_hash,
            token_count=len(change.manifest.assets),
            added=list(change.added),
            removed=list(change.removed),
        )
    except Exception as exc:
        if remote_operations:
            raise UniverseReconnectRequired(
                "universe audit failed after remote subscription change",
                recovery_manifest=recovery_manifest,
            ) from exc
        logging.warning("metadata-only universe audit unavailable: %s", exc)
        return None
    if not accepted:
        if remote_operations:
            raise UniverseReconnectRequired(
                "universe audit rejected after remote subscription change",
                recovery_manifest=recovery_manifest,
            )
        return None
    try:
        state.apply_universe(change.manifest)
    except Exception as exc:
        if remote_operations:
            raise UniverseReconnectRequired(
                "local universe apply failed after remote subscription change",
                recovery_manifest=recovery_manifest,
            ) from exc
        raise
    return change


async def _send_universe_change(
    websocket: Any,
    change: UniverseChange,
    *,
    recovery_manifest: UniverseManifest | None = None,
    timeout: float = STREAM_CONTROL_DEADLINE_SECONDS,
) -> int:
    """Send ordered asset operations and flag a partially changed socket."""
    operations = (
        (change.added, "subscribe"),
        (change.removed, "unsubscribe"),
    )
    completed = 0
    for tokens, operation in operations:
        if not tokens:
            continue
        try:
            await _await_stream_control(
                websocket.send(json.dumps(
                    {"assets_ids": list(tokens), "operation": operation},
                    separators=(",", ":"),
                )),
                f"universe_{operation}",
                timeout=timeout,
            )
        except Exception as exc:
            if completed:
                if recovery_manifest is None:
                    raise RuntimeError(
                        "partial universe change lacks recovery evidence"
                    ) from exc
                raise UniverseReconnectRequired(
                    "partial remote universe change requires reconnect",
                    recovery_manifest=recovery_manifest,
                ) from exc
            raise
        completed += 1
    return completed


async def apply_subscription_update(websocket: Any, state: StreamState, *,
                                    now_cn: datetime | None = None,
                                    monotonic_now: float | None = None,
                                    writer: PersistenceWriter | None = None) -> UniverseChange | None:
    """Apply one planned manifest change without reconnecting the feed."""
    if not DYNAMIC_UNIVERSE_ENABLED:
        return None
    monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
    now_cn = now_cn or datetime.now(CHINA_TZ)
    read = state.dynamic_manifest_read
    if read.in_flight and not read.done:
        # The previous deadline expired, but its SQLite thread still owns this
        # flight. Poll without waiting or starting an overlapping read.
        return None
    if not read.in_flight:
        if monotonic_now - state.last_subscription_check < SUBSCRIPTION_CHECK_INTERVAL_SECONDS:
            return None
        state.last_subscription_check = monotonic_now
    try:
        candidate = await read.get(
            published_universe_manifest,
            timeout=STATE_HUB_READ_DEADLINE_SECONDS,
        )
    except TimeoutError:
        state._clear_pending_forward_rollover()
        logging.warning("market universe refresh exceeded read deadline; retaining current universe")
        return None
    except Exception as exc:
        state._clear_pending_forward_rollover()
        logging.warning("market universe refresh unavailable: %s", exc)
        return None
    if candidate is None or not candidate.assets:
        state._clear_pending_forward_rollover()
        return None
    change = await apply_manifest_candidate(
        websocket, state, candidate, now_cn=now_cn,
    )
    if change is None:
        return None
    logging.info(
        "market universe updated in-place tokens=%d added=%d removed=%d",
        len(change.manifest.assets), len(change.added), len(change.removed),
    )
    if writer is not None and change.added:
        added_market = {
            token_id: change.manifest.token_market[token_id]
            for token_id in change.added
        }
        try:
            state.market_rules.update(
                await fetch_market_rules(writer, added_market)
            )
        except Exception as exc:
            logging.warning(
                "new-token market rules unavailable; execution remains fail closed: %s",
                exc,
            )
    return change


def plan_explicit_rollback(
    state: StreamState,
    *,
    expected_current_hash: str,
    target_previous_hash: str,
) -> ExplicitRollbackPlan | None:
    """Pin only the adjacent accepted predecessor; never consult latest."""
    if not all(
        type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value)
        for value in (expected_current_hash, target_previous_hash)
    ):
        return None
    chain = accepted_universe_rollback_chain()
    if state.universe_hash == target_previous_hash:
        if (
            len(chain) < 2
            or chain[0] != target_previous_hash
            or chain[1] != expected_current_hash
        ):
            return None
        target = published_universe_manifest(target_previous_hash)
        if target is None or target.token_hash != target_previous_hash:
            return None
        change = validate_universe_transition(
            state.manifest,
            target,
            now_cn=datetime.now(CHINA_TZ),
            explicit_rollback=True,
        )
        if change is None:
            return None
        return ExplicitRollbackPlan(
            change, expected_current_hash, target_previous_hash,
        )
    if state.universe_hash != expected_current_hash:
        return None
    if len(chain) < 2 or chain[0] != expected_current_hash or chain[1] != target_previous_hash:
        return None
    target = published_universe_manifest(target_previous_hash)
    if target is None or target.token_hash != target_previous_hash:
        return None
    change = validate_universe_transition(
        state.manifest,
        target,
        now_cn=datetime.now(CHINA_TZ),
        explicit_rollback=True,
    )
    if change is None:
        return None
    return ExplicitRollbackPlan(change, expected_current_hash, target_previous_hash)


async def apply_explicit_rollback(
    websocket: Any,
    state: StreamState,
    writer: PersistenceWriter,
    *,
    expected_current_hash: str,
    target_previous_hash: str,
    frozen_plan: ExplicitRollbackPlan | None = None,
    operation_id: str = "offline",
    reason: str = "adjacent_accepted_hash_pin",
) -> UniverseChange | None:
    """Execute one already-gated adjacent rollback through the sole writer."""
    if (
        type(operation_id) is not str
        or re.fullmatch(r"[A-Za-z0-9._:-]{1,128}", operation_id) is None
        or type(reason) is not str
        or not 1 <= len(reason) <= 256
        or reason != reason.strip()
        or any(unicodedata.category(character) == "Cc" for character in reason)
    ):
        return None
    if frozen_plan is None:
        plan = plan_explicit_rollback(
            state,
            expected_current_hash=expected_current_hash,
            target_previous_hash=target_previous_hash,
        )
    elif (
        type(frozen_plan) is not ExplicitRollbackPlan
        or frozen_plan.expected_current_hash != expected_current_hash
        or frozen_plan.pinned_hash != target_previous_hash
        or frozen_plan.target.token_hash != target_previous_hash
        or state.universe_hash not in {
            expected_current_hash, target_previous_hash,
        }
    ):
        return None
    else:
        plan = frozen_plan
    if plan is None:
        return None
    change = plan.change
    if state.universe_hash == target_previous_hash:
        return change
    recovery_manifest = None
    if change.added or change.removed:
        recovery_manifest = revalidate_recovery_manifest(state.manifest)
        if recovery_manifest is None:
            logging.error(
                "reject rollback without validated current recovery manifest"
            )
            return None
    remote_operations = await _send_universe_change(
        websocket, change, recovery_manifest=recovery_manifest,
    )
    detail = "explicit_rollback " + json.dumps(
        {
            "format_transition": change.format_transition or "asset_change",
            "from_hash": expected_current_hash,
            "operation_id": operation_id,
            "reason": reason,
            "to_hash": target_previous_hash,
        },
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    )
    try:
        accepted = record_connection_event(
            writer,
            "universe_rollback",
            detail,
            universe_hash=target_previous_hash,
            token_count=len(change.manifest.assets),
            added=list(change.added),
            removed=list(change.removed),
        )
    except Exception as exc:
        if remote_operations:
            raise UniverseReconnectRequired(
                "rollback audit failed after remote subscription change",
                recovery_manifest=recovery_manifest,
            ) from exc
        logging.warning("metadata-only rollback audit unavailable: %s", exc)
        return None
    if not accepted:
        if remote_operations:
            raise UniverseReconnectRequired(
                "rollback audit rejected after remote subscription change",
                recovery_manifest=recovery_manifest,
            )
        return None
    try:
        state.apply_universe(change.manifest)
    except Exception as exc:
        if remote_operations:
            raise UniverseReconnectRequired(
                "rollback apply failed after remote subscription change",
                recovery_manifest=recovery_manifest,
            ) from exc
        raise
    return change


class RollbackRequestOperator:
    """Read and execute the fixed rollback request without blocking quotes."""

    def __init__(
        self,
        request_path: str | os.PathLike[str] = ROLLBACK_REQUEST_PATH,
        *,
        read_timeout: float = ROLLBACK_REQUEST_READ_DEADLINE_SECONDS,
        check_interval: float = ROLLBACK_REQUEST_CHECK_INTERVAL_SECONDS,
        warning_interval: float = ROLLBACK_REQUEST_WARNING_INTERVAL_SECONDS,
    ) -> None:
        self.request_path = Path(request_path)
        self.read_timeout = max(0.01, float(read_timeout))
        self.check_interval = max(0.01, float(check_interval))
        self.warning_interval = max(0.0, float(warning_interval))
        self.reader = AsyncSingleFlightRead("rollback-request")
        self.last_check = float("-inf")
        self.dynamic_hold = False
        self._warnings: dict[str, float] = {}
        self._operation_fingerprints: dict[str, str] = {}
        self._completed_fingerprints: set[str] = set()

    def _warning(self, key: str, message: str, monotonic_now: float) -> None:
        previous = self._warnings.get(key)
        if (
            previous is not None
            and monotonic_now - previous < self.warning_interval
        ):
            return
        self._warnings[key] = monotonic_now
        logging.warning("rollback request %s", message[:512])

    async def read_due(
        self,
        *,
        now: datetime | None = None,
        monotonic_now: float | None = None,
    ) -> UniverseRollbackRequest | None:
        monotonic_now = (
            time.monotonic() if monotonic_now is None else monotonic_now
        )
        if self.reader.in_flight and not self.reader.done:
            # The worker thread survives the caller deadline.  Keep this same
            # flight pinned.  An unread/unknown request cannot freeze ordinary
            # dynamic checks; only a fully validated active request owns that
            # hold.
            return None
        if not self.reader.in_flight:
            if monotonic_now - self.last_check < self.check_interval:
                return None
            self.last_check = monotonic_now
        started_at = now or datetime.now(UTC)
        try:
            request = await self.reader.get(
                read_rollback_request_file,
                self.request_path,
                started_at,
                timeout=self.read_timeout,
            )
        except TimeoutError:
            self._warning(
                "timeout", "read exceeded deadline; retaining single flight",
                monotonic_now,
            )
            return None
        except RollbackRequestError as exc:
            self.dynamic_hold = False
            self._warning("invalid", f"rejected: {exc}", monotonic_now)
            return None
        except Exception as exc:
            self.dynamic_hold = False
            self._warning(
                "unavailable", f"read unavailable: {type(exc).__name__}: {exc}",
                monotonic_now,
            )
            return None
        if request is not None:
            payload = {
                field: getattr(request, field)
                for field in ROLLBACK_REQUEST_FIELDS
            }
            try:
                request = parse_rollback_request_payload(
                    payload,
                    now=now if now is not None else datetime.now(UTC),
                )
            except RollbackRequestError as exc:
                self.dynamic_hold = False
                self._warning(
                    "invalid", f"rejected at consumption: {exc}", monotonic_now,
                )
                return None
        self.dynamic_hold = request is not None
        return request

    async def poll(
        self,
        websocket: Any,
        state: StreamState,
        writer: PersistenceWriter,
        *,
        now: datetime | None = None,
        monotonic_now: float | None = None,
    ) -> UniverseChange | None:
        """Execute only a validated adjacent plan on one active connection."""
        if (
            websocket is None
            or not isinstance(state, StreamState)
            or getattr(websocket, "closed", False) is True
        ):
            return None
        monotonic_now = (
            time.monotonic() if monotonic_now is None else monotonic_now
        )
        request = await self.read_due(
            now=now, monotonic_now=monotonic_now,
        )
        if request is None:
            return None
        fingerprint = request.fingerprint
        previous = self._operation_fingerprints.get(request.operation_id)
        if previous is not None and previous != fingerprint:
            self._warning(
                f"operation-conflict:{request.operation_id}",
                f"operation_id conflict: {request.operation_id}",
                monotonic_now,
            )
            return None
        self._operation_fingerprints.setdefault(
            request.operation_id, fingerprint,
        )
        if fingerprint in self._completed_fingerprints:
            return None
        plan = plan_explicit_rollback(
            state,
            expected_current_hash=request.expected_current_hash,
            target_previous_hash=request.target_previous_hash,
        )
        if plan is None:
            self._warning(
                f"plan:{fingerprint}",
                "plan rejected or expected current not yet accepted",
                monotonic_now,
            )
            return None
        change = await apply_explicit_rollback(
            websocket,
            state,
            writer,
            expected_current_hash=request.expected_current_hash,
            target_previous_hash=request.target_previous_hash,
            frozen_plan=plan,
            operation_id=request.operation_id,
            reason=request.reason,
        )
        if change is None:
            self._warning(
                f"execution:{fingerprint}",
                "validated rollback was not accepted",
                monotonic_now,
            )
            return None
        self._completed_fingerprints.add(fingerprint)
        return change


def publish_stream_health(
    state: StreamState,
    writer: PersistenceWriter,
    hub: LiveStateHub,
    path_shadow: IngressCommitShadow,
) -> None:
    """Publish liveness first, then schedule optional SQLite reconciliation."""
    detail = (
        f"live tokens={len(state.token_market)} queue={writer.events.qsize()} "
        f"dropped={writer.dropped_critical} writer={writer.health()} "
        f"{writer.maintenance_status_fragment()} {hub.status_fragment(path_shadow)} "
        f"{state.protocol.status_fragment()} {path_shadow.status_fragment()}"
    )
    state.heartbeat(detail)
    hub.schedule_reconcile(path_shadow)


async def read_reconnect_manifest(
    hub: LiveStateHub,
    progress: WorkerProgressPublisher,
    *,
    timeout: float = STATE_HUB_READ_DEADLINE_SECONDS,
) -> UniverseManifest:
    """Read one reconnect manifest without overlapping timed-out threads."""
    progress.publish("connecting", detail="reading reconnect market universe")
    try:
        return await hub.reconnect_manifest_read.get(
            subscription_manifest, timeout=timeout
        )
    except TimeoutError:
        progress.publish(
            "connecting",
            detail="reconnect market universe read still pending",
        )
        raise


class ReconnectRecoveryPin:
    """Own one immutable pre-change manifest until connected audit accepts it."""

    def __init__(self) -> None:
        self.manifest: UniverseManifest | None = None

    @property
    def active(self) -> bool:
        return self.manifest is not None

    @property
    def recovery_hash(self) -> str | None:
        return self.manifest.token_hash if self.manifest is not None else None

    def capture(self, error: UniverseReconnectRequired) -> None:
        if type(error) is not UniverseReconnectRequired:
            raise TypeError("pinned recovery requires UniverseReconnectRequired")
        validated = revalidate_recovery_manifest(error.recovery_manifest)
        if validated is None or validated.token_hash != error.recovery_hash:
            raise ValueError("reconnect recovery evidence is invalid")
        self.manifest = validated

    async def select(
        self,
        hub: LiveStateHub,
        progress: WorkerProgressPublisher,
    ) -> UniverseManifest:
        if self.manifest is None:
            return await read_reconnect_manifest(hub, progress)
        validated = revalidate_recovery_manifest(self.manifest)
        if validated is None or validated.token_hash != self.manifest.token_hash:
            raise RuntimeError("pinned recovery manifest failed revalidation")
        self.manifest = validated
        progress.publish(
            "connecting",
            detail=f"retrying pinned market universe {validated.token_hash}",
        )
        return validated

    def confirm_connected(
        self,
        writer: PersistenceWriter,
        manifest: UniverseManifest,
    ) -> bool:
        pinned = self.manifest
        if pinned is not None and (
            manifest.token_hash != pinned.token_hash
            or revalidate_recovery_manifest(manifest) != pinned
        ):
            raise RuntimeError("connected manifest does not match pinned recovery")
        detail = (
            "pinned recovery websocket connected"
            if pinned is not None else "websocket connected"
        )
        try:
            accepted = record_connection_event(
                writer,
                "connected",
                detail,
                universe_hash=manifest.token_hash,
                token_count=len(manifest.assets),
            )
        except Exception as exc:
            if pinned is not None:
                raise UniverseReconnectRequired(
                    "pinned recovery connected audit failed",
                    recovery_manifest=pinned,
                ) from exc
            raise ConnectionError("connected audit failed") from exc
        if not accepted:
            if pinned is not None:
                raise UniverseReconnectRequired(
                    "pinned recovery connected audit rejected",
                    recovery_manifest=pinned,
                )
            raise ConnectionError("connected audit rejected")
        if pinned is not None:
            self.manifest = None
        return True


async def prepare_startup(
    hub: LiveStateHub,
    writer: PersistenceWriter,
    *,
    timeout: float = STATE_HUB_READ_DEADLINE_SECONDS,
) -> tuple[UniverseManifest, int]:
    """Finish startup-only reads before opening the sole writable connection."""
    if hub.startup_complete and hub.startup_manifest is not None:
        return hub.startup_manifest, hub.startup_warmed
    if hub.startup_manifest is None:
        hub.startup_manifest = await hub.startup_manifest_read.get(
            subscription_manifest, timeout=timeout
        )
    manifest = hub.startup_manifest
    _assets, token_market, _universe_hash = manifest.legacy_tuple()
    if not hub.startup_universe_set:
        hub.set_universe(token_market)
        hub.startup_universe_set = True
    if hub.startup_warmup_rows is None:
        hub.startup_warmup_rows = await hub.startup_warmup_read.get(
            hub.read_persisted_rows,
            tuple(token_market),
            timeout=timeout,
        )
    hub.startup_warmed = hub.apply_persisted_rows(hub.startup_warmup_rows)
    writer.start()
    hub.startup_complete = True
    return manifest, hub.startup_warmed


async def run() -> None:
    hub = LiveStateHub()
    await hub.start()
    protocol = MarketProtocolShadow()
    path_shadow = IngressCommitShadow()
    loop = asyncio.get_running_loop()

    def committed_on_loop(event: dict[str, Any]) -> None:
        # Durable acknowledgement is audit-only.  The dashboard has already
        # received the accepted event from the canonical in-memory path.
        path_shadow.record_commit(event)

    writer = PersistenceWriter(
        on_committed=lambda event: loop.call_soon_threadsafe(
            committed_on_loop, event
        )
    )
    progress = WorkerProgressPublisher(
        BASE / "data" / "runtime" / "services" / "realtime_stream.worker.json",
        "realtime_stream",
    )
    progress.start()
    atexit.register(progress.close)
    initial_manifest: UniverseManifest | None = None
    recovery_pin = ReconnectRecoveryPin()
    rollback_operator = RollbackRequestOperator()
    warmed = 0
    while initial_manifest is None:
        progress.publish("connecting", detail="preparing realtime startup reads")
        try:
            initial_manifest, warmed = await prepare_startup(hub, writer)
        except Exception as exc:
            logging.warning("realtime startup read unavailable: %s", exc)
            await asyncio.sleep(5)
    atexit.register(writer.close)
    try:
        while True:
            try:
                runtime_heartbeat(writer, "connecting to Polymarket CLOB", progress)
                if recovery_pin.active:
                    manifest = await recovery_pin.select(hub, progress)
                elif initial_manifest is not None:
                    manifest = initial_manifest
                    initial_manifest = None
                else:
                    manifest = await recovery_pin.select(hub, progress)
                assets, token_market, universe_hash = manifest.legacy_tuple()
                if not assets:
                    runtime_heartbeat(
                        writer,
                        "waiting for current target-city market tokens",
                        progress,
                    )
                    logging.info("no current target-city tokens; retrying in 30s")
                    await asyncio.sleep(30)
                    continue
                hub.set_universe(token_market)
                state = StreamState(
                    None, token_market, writer, hub, universe_hash,
                    protocol, path_shadow, manifest.token_target_date, progress,
                    manifest,
                )
                try:
                    state.market_rules.update(
                        await fetch_market_rules(writer, token_market)
                    )
                except Exception as exc:
                    logging.warning(
                        "startup market rules unavailable; execution remains fail closed: %s",
                        exc,
                    )
                async with websockets.connect(
                    WS,
                    ping_interval=20,
                    ping_timeout=20,
                    open_timeout=STREAM_CONTROL_DEADLINE_SECONDS,
                    close_timeout=STREAM_CONTROL_DEADLINE_SECONDS,
                ) as ws:
                    await _await_stream_control(
                        ws.send(json.dumps({
                            "assets_ids": assets,
                            "type": "market",
                            "custom_feature_enabled": True,
                        })),
                        "initial_subscription",
                    )
                    recovery_pin.confirm_connected(writer, manifest)
                    protocol.on_connect()
                    hub.record_stream_status(True, "Polymarket market channel connected")
                    await protocol.maybe_send_ping(ws, force=True)
                    state.heartbeat(f"connected tokens={len(assets)}", force=True)
                    logging.info("stream connected: %d current temperature tokens; hub warmed=%d", len(assets), warmed)
                    while True:
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=RECEIVE_MAINTENANCE_SECONDS)
                        except TimeoutError:
                            await hub.ensure_listener()
                            hub.record_stream_status(True, "Polymarket market channel heartbeat")
                            await protocol.maybe_send_ping(ws)
                            state.flush_bbo_heartbeats()
                            state.maintain()
                            publish_stream_health(state, writer, hub, path_shadow)
                            await rollback_operator.poll(ws, state, writer)
                            if not rollback_operator.dynamic_hold:
                                await apply_subscription_update(ws, state, writer=writer)
                            continue
                        received_at = datetime.now(UTC)
                        if protocol.observe_text(raw):
                            await protocol.maybe_send_ping(ws)
                            publish_stream_health(state, writer, hub, path_shadow)
                            continue
                        payload = json.loads(raw)
                        for item in payload if isinstance(payload, list) else [payload]:
                            if isinstance(item, dict):
                                state.handle(item, received_at=received_at)
                        await protocol.maybe_send_ping(ws)
                        publish_stream_health(state, writer, hub, path_shadow)
                        state.maintain()
                        await hub.ensure_listener()
                        await rollback_operator.poll(ws, state, writer)
                        if not rollback_operator.dynamic_hold:
                            await apply_subscription_update(ws, state, writer=writer)
            except UniverseReconnectRequired as exc:
                recovery_pin.capture(exc)
                protocol.on_disconnect()
                hub.record_stream_status(
                    False,
                    f"pinned recovery {exc.recovery_hash}: {type(exc).__name__}: {exc}",
                )
                runtime_heartbeat(
                    writer,
                    f"reconnecting pinned {exc.recovery_hash} after {type(exc).__name__}: {exc}",
                    progress,
                )
                record_connection_event(
                    writer, "disconnected", f"{type(exc).__name__}: {exc}"
                )
                logging.warning(
                    "stream reconnecting with pinned recovery %s after error: %s",
                    exc.recovery_hash,
                    exc,
                )
                await asyncio.sleep(5)
            except Exception as exc:
                protocol.on_disconnect()
                hub.record_stream_status(
                    False, f"{type(exc).__name__}: {exc}"
                )
                runtime_heartbeat(
                    writer,
                    f"reconnecting after {type(exc).__name__}: {exc}",
                    progress,
                )
                record_connection_event(
                    writer, "disconnected", f"{type(exc).__name__}: {exc}"
                )
                logging.warning("stream reconnecting after error: %s", exc)
                await asyncio.sleep(5)
    finally:
        await hub.close()
        progress.close()
        writer.close()


if __name__ == "__main__":
    from runtime_logging import configure_runtime_logging
    from runtime_instance_lock import AlreadyRunningError, DUPLICATE_INSTANCE_EXIT, writer_lock

    instance = writer_lock("realtime_stream")
    try:
        instance.acquire()
    except AlreadyRunningError:
        raise SystemExit(DUPLICATE_INSTANCE_EXIT)
    configure_runtime_logging("realtime_stream")
    try:
        with instance:
            if os.name == "nt":
                # The selector loop avoids a Windows IOCP accept failure that
                # can kill only the local read-only listener after reconnects.
                asyncio.set_event_loop_policy(
                    asyncio.WindowsSelectorEventLoopPolicy()
                )
            asyncio.run(run())
    except BaseException:
        logging.exception("realtime stream fatal error")
        raise
