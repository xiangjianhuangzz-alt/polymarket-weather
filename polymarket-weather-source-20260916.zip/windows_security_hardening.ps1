param(
    [ValidateSet('Audit', 'Apply')]
    [string]$Mode = 'Audit',
    [string]$RootPath = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $RootPath).Path
$identity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$allowed = @(
    $identity,
    'NT AUTHORITY\SYSTEM',
    'BUILTIN\Administrators'
)
$targets = @(
    (Join-Path $root '.env'),
    (Join-Path $root 'data\runtime\control'),
    (Join-Path $root 'data\runtime\locks'),
    (Join-Path $root 'data\runtime\services')
)

function Set-ExactAcl([string]$Path) {
    $item = Get-Item -LiteralPath $Path -Force
    if ($item.PSIsContainer) {
        $acl = [Security.AccessControl.DirectorySecurity]::new()
        $inheritance = [Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit'
    } else {
        $acl = [Security.AccessControl.FileSecurity]::new()
        $inheritance = [Security.AccessControl.InheritanceFlags]::None
    }
    $acl.SetAccessRuleProtection($true, $false)
    $acl.SetOwner([Security.Principal.NTAccount]::new($identity))
    foreach ($principal in $allowed) {
        $rule = [Security.AccessControl.FileSystemAccessRule]::new(
            $principal,
            [Security.AccessControl.FileSystemRights]::FullControl,
            $inheritance,
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow
        )
        $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}

$results = @()
foreach ($target in $targets) {
    if (-not (Test-Path -LiteralPath $target)) {
        $results += [ordered]@{ path = $target; exists = $false; protected = $false; unexpected = @() }
        continue
    }
    if ($Mode -eq 'Apply') {
        Set-ExactAcl -Path $target
    }
    $acl = Get-Acl -LiteralPath $target
    $unexpected = @($acl.Access | Where-Object {
        $_.AccessControlType -ne 'Allow' -or $_.IdentityReference.Value -notin $allowed
    } | ForEach-Object { $_.IdentityReference.Value })
    $results += [ordered]@{
        path = $target
        exists = $true
        protected = [bool]$acl.AreAccessRulesProtected
        unexpected = $unexpected
    }
}

$failed = @($results | Where-Object { $_.exists -and (-not $_.protected -or $_.unexpected.Count -gt 0) })
$results | ConvertTo-Json -Depth 4
if ($failed.Count -gt 0) { exit 2 }
