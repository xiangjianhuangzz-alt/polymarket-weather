from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import collector
import realtime_stream as stream


CITY_MATRIX = {
    "Beijing": ("formal", "ZBAA"),
    "Shanghai": ("formal", "ZSPD"),
    "Chengdu": ("formal", "ZUUU"),
    "Guangzhou": ("formal", "ZGGG"),
    "Shenzhen": ("research_only", "ZGSZ"),
    "Wuhan": ("research_only", "ZHHH"),
    "Chongqing": ("research_only", "ZUCK"),
    "Zhengzhou": ("research_only", "ZHCC"),
}
SCAN_ID = "t00-v1-offline-drill"
SCANNED_AT = "2026-08-10T17:30:00+00:00"
DRILL_NOW = datetime.fromisoformat("2026-08-11T01:31:00+08:00")


def _canonical_hash(members: list[dict]) -> str:
    encoded = json.dumps(
        members, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
    )
    return hashlib.sha256(encoded.encode()).hexdigest()


def _source(city: str, station: str) -> str:
    return f"https://www.wunderground.com/weather/cn/{city.lower()}/{station}"


def _verified_record(
    city: str,
    station: str,
    target_date: str,
    index: int,
    bucket: int,
) -> dict:
    target = datetime.fromisoformat(target_date).date()
    day = f"{target.strftime('%B')} {target.day}"
    yes_token = str(1_000_000 + index)
    no_token = str(2_000_000 + index)
    event = {
        "id": f"event-{city.lower()}-{target_date}",
        "title": f"Highest temperature in {city} on {day}",
        "resolutionSource": _source(city, station),
        "active": True,
        "closed": False,
        "_query_city": city,
        "_query_target_date": target_date,
    }
    market = {
        "id": f"market-{index:04d}",
        "question": (
            f"Will the highest temperature in {city} be {bucket} C on {day}?"
        ),
        "resolutionSource": _source(city, station),
        "outcomes": json.dumps(["Yes", "No"]),
        "clobTokenIds": json.dumps([yes_token, no_token]),
        "groupItemTitle": f"{bucket} C",
        "active": True,
        "closed": False,
    }
    record = collector.attribute_research_market(
        event, market, scan_id=SCAN_ID, scanned_at=SCANNED_AT,
    )
    if record["attribution_status"] != "verified":
        raise AssertionError(record)
    return record


def _candidate_records_and_statuses() -> tuple[list[dict], list[dict]]:
    cities = list(CITY_MATRIX)
    verified_points = {
        *((city, "2026-08-11") for city in cities),
        *((city, "2026-08-12") for city in cities[:8]),
    }
    records: list[dict] = []
    index = 0
    for city, target_date in sorted(verified_points):
        station = CITY_MATRIX[city][1]
        for bucket in range(20, 31):
            records.append(
                _verified_record(city, station, target_date, index, bucket)
            )
            index += 1
    statuses = list(records)
    for city in cities:
        station = CITY_MATRIX[city][1]
        for target_date in ("2026-08-11", "2026-08-12", "2026-08-13"):
            if (city, target_date) in verified_points:
                continue
            statuses.append(
                collector.research_attribution_status(
                    "no_active_market",
                    "no_exact_active_event",
                    scan_id=SCAN_ID,
                    scanned_at=SCANNED_AT,
                    city=city,
                    station=station,
                    target_date=target_date,
                )
            )
    return records, statuses


def _legacy_members(candidate_members: list[dict]) -> list[dict]:
    shared = [
        {
            "token_id": member["token_id"],
            "market_id": member["market_id"],
            "city": member["city"],
            "target_date": member["target_date"],
        }
        for member in candidate_members
    ]
    expired: list[dict] = []
    # Keep the historical accepted universe at 308 assets even though the new
    # active candidate contains only the eight-city matrix.
    for index in range(132):
        city = list(CITY_MATRIX)[index % len(CITY_MATRIX)]
        expired.append({
            "token_id": str(3_000_000 + index),
            "market_id": f"expired-market-{index:03d}",
            "city": city,
            "target_date": "2026-08-10",
        })
    return sorted(shared + expired, key=lambda item: (item["token_id"], item["market_id"]))


def _legacy_forward_mixed_members(candidate_members: list[dict]) -> list[dict]:
    """Return 88 shared current assets plus 220 expired legacy assets."""
    shared = [
        {
            "token_id": member["token_id"],
            "market_id": member["market_id"],
            "city": member["city"],
            "target_date": member["target_date"],
        }
        for member in candidate_members[:88]
    ]
    expired: list[dict] = []
    for index in range(220):
        city = list(CITY_MATRIX)[index % len(CITY_MATRIX)]
        expired.append({
            "token_id": str(3_000_000 + index),
            "market_id": f"forward-expired-market-{index:03d}",
            "city": city,
            "target_date": "2026-08-10",
        })
    return sorted(shared + expired, key=lambda item: (item["token_id"], item["market_id"]))


def _create_research_database(path: Path) -> None:
    with closing(sqlite3.connect(path)) as db:
        db.execute(
            """CREATE TABLE market_universe_publications (
            publication_id TEXT PRIMARY KEY,
            published_at TEXT NOT NULL,
            token_hash TEXT NOT NULL,
            token_count INTEGER NOT NULL,
            members_json TEXT NOT NULL,
            reason TEXT NOT NULL)"""
        )
        db.commit()


def _create_realtime_database(path: Path) -> None:
    with closing(sqlite3.connect(path)) as db:
        db.execute(
            """CREATE TABLE stream_connection_events (
            event_at TEXT NOT NULL,
            event_type TEXT NOT NULL,
            detail TEXT,
            universe_hash TEXT,
            token_count INTEGER,
            added_tokens_json TEXT,
            removed_tokens_json TEXT)"""
        )
        db.commit()


class _Socket:
    def __init__(self) -> None:
        self.closed = False
        self.sent: list[dict] = []

    async def send(self, raw: str) -> None:
        self.sent.append(json.loads(raw))


class _AuditWriter:
    def __init__(self, database: Path) -> None:
        self.database = database
        self.accept = True
        self.events: list[dict] = []
        self.sequence = 0

    def submit_connection_event(
        self,
        event_type: str,
        detail: str,
        *,
        universe_hash: str | None = None,
        token_count: int | None = None,
        added: list[str] | None = None,
        removed: list[str] | None = None,
    ) -> bool:
        event = {
            "event_type": event_type,
            "detail": detail,
            "universe_hash": universe_hash,
            "token_count": token_count,
            "added": list(added or []),
            "removed": list(removed or []),
        }
        self.events.append(event)
        if not self.accept:
            return False
        self.sequence += 1
        event_at = (
            datetime.fromisoformat("2026-08-10T17:40:00+00:00")
            + timedelta(seconds=self.sequence)
        ).isoformat()
        with closing(sqlite3.connect(self.database)) as db:
            db.execute(
                "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                (
                    event_at,
                    event_type,
                    detail,
                    universe_hash,
                    token_count,
                    json.dumps(event["added"]),
                    json.dumps(event["removed"]),
                ),
            )
            db.commit()
        return True


class _Progress:
    def __init__(self) -> None:
        self.events: list[tuple[str, str]] = []

    def publish(self, state: str, *, detail: str) -> None:
        self.events.append((state, detail))


class V1PublicationRollbackOfflineDrill(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addAsyncCleanup(self._cleanup)
        root = Path(self.tmp.name)
        self.research = root / "research.sqlite3"
        self.realtime = root / "realtime.sqlite3"
        self.approval = root / "approval.json"
        self.rollback = root / "rollback.json"
        _create_research_database(self.research)
        _create_realtime_database(self.realtime)

        records, self.statuses = _candidate_records_and_statuses()
        provisional = collector.build_research_universe_candidate(records)
        self.legacy_members = _legacy_members(provisional["members"])
        self.legacy_hash = _canonical_hash(self.legacy_members)
        with closing(sqlite3.connect(self.research)) as db:
            collector.publish_market_universe(
                db,
                "2026-08-10T17:00:00+00:00",
                self.legacy_members,
                "complete_scan",
            )
            db.commit()
        with closing(sqlite3.connect(self.realtime)) as db:
            db.execute(
                "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                (
                    "2026-08-10T17:05:00+00:00",
                    "connected",
                    "offline legacy accepted",
                    self.legacy_hash,
                    len(self.legacy_members),
                    "[]",
                    "[]",
                ),
            )
            db.commit()
        accepted = collector.load_accepted_research_universe_members_read_only(
            self.research, expected_accepted_hash=self.legacy_hash,
        )
        self.candidate = collector.build_research_universe_candidate(
            records, accepted_members=accepted,
        )
        self.removed = self.candidate["diff"]["removed"]
        self.approval_payload = {
            "schema": "universe_publication_approval.v1",
            "operation_id": "T00:v1-offline-drill.1",
            "expected_current_hash": self.legacy_hash,
            "approved_candidate_hash": self.candidate["token_hash"],
            "approved_token_count": self.candidate["token_count"],
            "approved_added_count": 0,
            "approved_removed_count": len(self.removed),
            "approved_remapped_count": 0,
            "approved_removed_token_hash": collector._removed_token_hash(self.removed),
            "allowed_removed_target_dates": ["2026-08-10"],
            "not_before": "2026-08-11T01:25:00+08:00",
            "expires_at": "2026-08-11T01:35:00+08:00",
        }
        self._write(self.approval, self.approval_payload)
        self.patches = (
            patch.object(collector, "DB_PATH", self.research),
            patch.object(collector, "REALTIME_DB", self.realtime),
            patch.object(stream, "RESEARCH_DB", self.research),
            patch.object(stream, "DB", self.realtime),
        )
        for active_patch in self.patches:
            active_patch.start()

    async def _cleanup(self) -> None:
        for active_patch in reversed(getattr(self, "patches", ())):
            active_patch.stop()
        self.tmp.cleanup()

    @staticmethod
    def _write(path: Path, payload: dict) -> None:
        path.write_text(
            json.dumps(payload, separators=(",", ":"), sort_keys=True),
            encoding="utf-8",
        )

    def _publication_count(self) -> int:
        with closing(sqlite3.connect(self.research)) as db:
            return db.execute(
                "SELECT COUNT(*) FROM market_universe_publications"
            ).fetchone()[0]

    async def test_exact_approval_publish_accept_rollback_and_pinned_recovery(self) -> None:
        self.assertEqual(len(self.legacy_members), 308)
        self.assertEqual(self.candidate["token_count"], 176)
        self.assertEqual(len(self.removed), 132)
        self.assertEqual(self.candidate["diff"]["added"], ())
        self.assertEqual(self.candidate["diff"]["remapped"], ())
        self.assertEqual(
            set(self.candidate["distributions"]["cities"]), set(CITY_MATRIX),
        )

        authorized = collector.authorize_research_universe_publication(
            [status for status in self.statuses if status["attribution_status"] == "verified"],
            self.statuses,
            approval_path=self.approval,
            realtime_database_path=self.realtime,
            research_database_path=self.research,
            now=DRILL_NOW,
        )
        self.assertFalse(authorized["already_published"])
        self.assertEqual(
            authorized["candidate"]["token_hash"], self.candidate["token_hash"],
        )
        with closing(sqlite3.connect(self.research)) as db:
            collector.publish_market_universe(
                db,
                "2026-08-10T17:31:00+00:00",
                authorized["candidate"]["members"],
                "complete_scan",
            )
            db.commit()
        self.assertEqual(self._publication_count(), 2)

        drifted = dict(self.approval_payload)
        drifted["approved_candidate_hash"] = "f" * 64
        self._write(self.approval, drifted)
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.authorize_research_universe_publication(
                [status for status in self.statuses if status["attribution_status"] == "verified"],
                self.statuses,
                approval_path=self.approval,
                realtime_database_path=self.realtime,
                research_database_path=self.research,
                now=DRILL_NOW,
            )
        self.assertEqual(self._publication_count(), 2)

        legacy = stream.published_universe_manifest(self.legacy_hash)
        candidate = stream.published_universe_manifest(self.candidate["token_hash"])
        self.assertIsNotNone(legacy)
        self.assertIsNotNone(candidate)
        self.assertEqual(legacy.format, "legacy")
        self.assertEqual(candidate.format, "research_market_attribution.v1")
        self.assertEqual(len(legacy.assets), 308)
        self.assertEqual(len(candidate.assets), 176)

        hub = stream.LiveStateHub()
        hub.set_universe(legacy.token_market)
        writer = _AuditWriter(self.realtime)
        state = stream.StreamState(
            None,
            legacy.token_market,
            writer,
            hub,
            legacy.token_hash,
            token_target_date=legacy.token_target_date,
            manifest=legacy,
        )
        socket = _Socket()
        rollover_now = datetime.fromisoformat("2026-08-11T01:32:00+08:00")

        first = await stream.apply_manifest_candidate(
            socket, state, candidate, now_cn=rollover_now,
        )
        self.assertIsNone(first)
        self.assertEqual(socket.sent, [])
        self.assertEqual(state.universe_hash, self.legacy_hash)

        accepted_change = await stream.apply_manifest_candidate(
            socket, state, candidate, now_cn=rollover_now,
        )
        self.assertIsNotNone(accepted_change)
        self.assertEqual(len(accepted_change.removed), 132)
        self.assertEqual(socket.sent[0]["operation"], "unsubscribe")
        self.assertEqual(len(socket.sent[0]["assets_ids"]), 132)
        self.assertEqual(writer.events[-1]["event_type"], "universe_changed")
        self.assertEqual(state.universe_hash, candidate.token_hash)
        self.assertEqual(len(state.token_market), 176)
        self.assertEqual(len(hub.token_market), 176)

        rollback_payload = {
            "schema": "universe_rollback_request.v1",
            "operation_id": "T00:v1-offline-drill.rollback",
            "expected_current_hash": candidate.token_hash,
            "target_previous_hash": legacy.token_hash,
            "not_before": "2026-08-10T17:32:00+00:00",
            "expires_at": "2026-08-10T17:42:00+00:00",
            "reason": "offline adjacent rollback rehearsal",
        }
        self._write(self.rollback, rollback_payload)
        rollback_socket = _Socket()
        operator = stream.RollbackRequestOperator(self.rollback)
        rolled_back = await operator.poll(
            rollback_socket,
            state,
            writer,
            now=datetime.fromisoformat("2026-08-10T17:35:00+00:00"),
            monotonic_now=5.0,
        )
        self.assertIsNotNone(rolled_back)
        self.assertEqual(len(rolled_back.added), 132)
        self.assertEqual(rollback_socket.sent[0]["operation"], "subscribe")
        self.assertEqual(writer.events[-1]["event_type"], "universe_rollback")
        self.assertEqual(state.universe_hash, legacy.token_hash)
        self.assertEqual(len(hub.token_market), 308)

        # Recreate the accepted adjacent v1 -> legacy edge, then reject audit
        # after the remote subscribe succeeds.  The pin must recover v1.
        writer.submit_connection_event(
            "universe_changed",
            "offline v1 current fixture",
            universe_hash=candidate.token_hash,
            token_count=len(candidate.assets),
            added=[],
            removed=list(self.removed),
        )
        state.apply_universe(candidate)
        hub.set_universe(candidate.token_market)
        self._write(self.rollback, {
            **rollback_payload,
            "operation_id": "T00:v1-offline-drill.rollback-failure",
        })
        writer.accept = False
        failure_socket = _Socket()
        failure_operator = stream.RollbackRequestOperator(self.rollback)
        with self.assertRaises(stream.UniverseReconnectRequired) as caught:
            await failure_operator.poll(
                failure_socket,
                state,
                writer,
                now=datetime.fromisoformat("2026-08-10T17:36:00+00:00"),
                monotonic_now=10.0,
            )
        error = caught.exception
        self.assertEqual(error.recovery_hash, candidate.token_hash)
        self.assertEqual(state.universe_hash, candidate.token_hash)
        self.assertEqual(len(failure_socket.sent), 1)
        self.assertEqual(failure_socket.sent[0]["operation"], "subscribe")

        pin = stream.ReconnectRecoveryPin()
        pin.capture(error)
        progress = _Progress()
        with patch.object(
            stream,
            "read_reconnect_manifest",
            side_effect=AssertionError("latest selection must not run while pinned"),
        ):
            selected = await pin.select(hub, progress)
        self.assertEqual(selected.token_hash, candidate.token_hash)
        self.assertEqual(pin.recovery_hash, candidate.token_hash)
        self.assertTrue(progress.events)

    async def test_forward_mixed_v2_publish_double_observe_accept_and_rollback(self) -> None:
        """Seal the exact BE-02 v2 -> BE-04 forward-mixed -> rollback chain."""
        records = [
            status for status in self.statuses
            if status["attribution_status"] == "verified"
        ]
        provisional = collector.build_research_universe_candidate(records)
        legacy_members = _legacy_forward_mixed_members(provisional["members"])
        legacy_hash = _canonical_hash(legacy_members)

        with closing(sqlite3.connect(self.research)) as db:
            db.execute("DELETE FROM market_universe_publications")
            collector.publish_market_universe(
                db,
                "2026-08-10T17:00:00+00:00",
                legacy_members,
                "complete_scan",
            )
            db.commit()
        with closing(sqlite3.connect(self.realtime)) as db:
            db.execute("DELETE FROM stream_connection_events")
            db.execute(
                "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                (
                    "2026-08-10T17:05:00+00:00",
                    "connected",
                    "offline forward-mixed legacy accepted",
                    legacy_hash,
                    len(legacy_members),
                    "[]",
                    "[]",
                ),
            )
            db.commit()

        accepted = collector.load_accepted_research_universe_members_read_only(
            self.research,
            expected_accepted_hash=legacy_hash,
        )
        candidate = collector.build_research_universe_candidate(
            records,
            accepted_members=accepted,
        )
        added = candidate["diff"]["added"]
        removed = candidate["diff"]["removed"]
        self.assertEqual(len(legacy_members), 308)
        self.assertEqual(candidate["token_count"], 176)
        self.assertEqual(len(added), 88)
        self.assertEqual(len(removed), 220)
        self.assertEqual(candidate["diff"]["remapped"], ())

        added_by_token = {
            member["token_id"]: member for member in candidate["members"]
        }
        removed_by_token = {
            member["token_id"]: member for member in accepted
        }
        approval_payload = {
            "schema": "universe_publication_approval.v2",
            "operation_id": "T00:forward-mixed-e2e.1",
            "transition": "legacy_to_v1_forward_mixed",
            "expected_current_hash": legacy_hash,
            "approved_candidate_hash": candidate["token_hash"],
            "approved_token_count": candidate["token_count"],
            "approved_added_count": len(added),
            "approved_removed_count": len(removed),
            "approved_remapped_count": 0,
            "approved_added_token_hash": collector._removed_token_hash(added),
            "approved_removed_token_hash": collector._removed_token_hash(removed),
            "allowed_added_target_dates": sorted({
                added_by_token[token]["target_date"] for token in added
            }),
            "allowed_removed_target_dates": sorted({
                removed_by_token[token]["target_date"] for token in removed
            }),
            "not_before": "2026-08-11T01:25:00+08:00",
            "expires_at": "2026-08-11T01:35:00+08:00",
        }
        self._write(self.approval, approval_payload)

        authorized = collector.authorize_research_universe_publication(
            records,
            self.statuses,
            approval_path=self.approval,
            realtime_database_path=self.realtime,
            research_database_path=self.research,
            now=DRILL_NOW,
        )
        self.assertFalse(authorized["already_published"])
        with closing(sqlite3.connect(self.research)) as db:
            collector.publish_market_universe(
                db,
                "2026-08-10T17:31:00+00:00",
                authorized["candidate"]["members"],
                "complete_scan",
            )
            db.commit()

        # A one-field approval drift cannot produce another publication.
        drifted = dict(approval_payload)
        drifted["approved_added_token_hash"] = "f" * 64
        self._write(self.approval, drifted)
        before_count = self._publication_count()
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.authorize_research_universe_publication(
                records,
                self.statuses,
                approval_path=self.approval,
                realtime_database_path=self.realtime,
                research_database_path=self.research,
                now=DRILL_NOW,
            )
        self.assertEqual(self._publication_count(), before_count)

        legacy = stream.published_universe_manifest(legacy_hash)
        target = stream.published_universe_manifest(candidate["token_hash"])
        self.assertIsNotNone(legacy)
        self.assertIsNotNone(target)
        self.assertEqual(legacy.format, "legacy")
        self.assertEqual(target.format, "research_market_attribution.v1")

        hub = stream.LiveStateHub()
        hub.set_universe(legacy.token_market)
        writer = _AuditWriter(self.realtime)
        state = stream.StreamState(
            None,
            legacy.token_market,
            writer,
            hub,
            legacy.token_hash,
            token_target_date=legacy.token_target_date,
            manifest=legacy,
        )
        socket = _Socket()
        rollover_now = datetime.fromisoformat("2026-08-11T01:32:00+08:00")

        first = await stream.apply_manifest_candidate(
            socket,
            state,
            target,
            now_cn=rollover_now,
        )
        self.assertIsNone(first)
        self.assertEqual(socket.sent, [])
        self.assertEqual(state.universe_hash, legacy_hash)

        change = await stream.apply_manifest_candidate(
            socket,
            state,
            target,
            now_cn=rollover_now,
        )
        self.assertIsNotNone(change)
        self.assertEqual(change.format_transition, "legacy_to_v1_forward_mixed")
        self.assertEqual(len(change.added), 88)
        self.assertEqual(len(change.removed), 220)
        self.assertEqual(
            [message["operation"] for message in socket.sent],
            ["subscribe", "unsubscribe"],
        )
        self.assertEqual(writer.events[-1]["event_type"], "universe_changed")
        self.assertEqual(state.universe_hash, target.token_hash)
        self.assertEqual(len(state.token_market), 176)
        self.assertEqual(len(hub.token_market), 176)

        rollback_payload = {
            "schema": "universe_rollback_request.v1",
            "operation_id": "T00:forward-mixed-e2e.rollback",
            "expected_current_hash": target.token_hash,
            "target_previous_hash": legacy.token_hash,
            "not_before": "2026-08-10T17:32:00+00:00",
            "expires_at": "2026-08-10T17:42:00+00:00",
            "reason": "offline forward-mixed adjacent rollback rehearsal",
        }
        self._write(self.rollback, rollback_payload)
        rollback_socket = _Socket()
        operator = stream.RollbackRequestOperator(self.rollback)
        rolled_back = await operator.poll(
            rollback_socket,
            state,
            writer,
            now=datetime.fromisoformat("2026-08-10T17:35:00+00:00"),
            monotonic_now=5.0,
        )
        self.assertIsNotNone(rolled_back)
        self.assertEqual(len(rolled_back.added), 220)
        self.assertEqual(len(rolled_back.removed), 88)
        self.assertEqual(
            [message["operation"] for message in rollback_socket.sent],
            ["subscribe", "unsubscribe"],
        )
        self.assertEqual(writer.events[-1]["event_type"], "universe_rollback")
        self.assertEqual(state.universe_hash, legacy.token_hash)
        self.assertEqual(len(hub.token_market), 308)


if __name__ == "__main__":
    unittest.main()
