"""Backfill compact market bars before raw quote retention is enabled."""
from __future__ import annotations

from datetime import datetime

from realtime_stream import connect, upsert_price_bar


def main() -> None:
    db = connect()
    last_rowid = 0
    processed = 0
    try:
        while True:
            rows = db.execute("""SELECT rowid,captured_at,market_id,token_id,
              best_bid,best_ask,bid_size,ask_size FROM book_snapshots
              WHERE rowid>? ORDER BY rowid LIMIT 5000""", (last_rowid,)).fetchall()
            if not rows:
                break
            for rowid, captured_at, market, token, bid, ask, bid_size, ask_size in rows:
                stamp = datetime.fromisoformat(captured_at.replace("Z", "+00:00"))
                for interval in (60, 300):
                    upsert_price_bar(db, interval, stamp, market, token, bid, ask, bid_size, ask_size)
                last_rowid = rowid
                processed += 1
            db.commit()
            if processed % 50000 == 0:
                print(f"backfilled {processed} quote rows", flush=True)
        print(f"backfill complete: {processed} quote rows", flush=True)
    finally:
        db.close()


if __name__ == "__main__":
    main()
