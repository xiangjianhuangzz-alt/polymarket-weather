"""Independent, read-only-source METAR/SPECI collector.

This service is intentionally separate from ``collector.py``.  It reads the
public Aviation Weather feed and is the *only* writer of observations.sqlite3.
It never writes forecasts, quotes, settlements, or the paper ledger.
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import re
import sqlite3
import time
import urllib.parse
import urllib.request
from datetime import UTC, datetime
from pathlib import Path
from statistics import median
from typing import Any, Callable

from db_paths import OBSERVATIONS_DB
from ui_events import ensure_observations_events, publish_event

POLL_SECONDS = 60
BACKFILL_HOURS = 6
HTTP_TIMEOUT_SECONDS = 20
MAX_REPORT_AGE_SECONDS = 24 * 60 * 60
MAX_REPORT_FUTURE_SECONDS = 5 * 60
MIN_TEMPERATURE_C = -100.0
MAX_TEMPERATURE_C = 70.0

# Shenzhen is stored and visible, but is deliberately not eligible to drive an
# automatic risk exclusion until its known settlement-source discrepancy is
# separately resolved.
STATIONS = {
    "ZBAA": {"city": "Beijing", "scope": "risk_exclusion"},
    "ZSPD": {"city": "Shanghai", "scope": "risk_exclusion"},
    "ZUUU": {"city": "Chengdu", "scope": "risk_exclusion"},
    "ZGGG": {"city": "Guangzhou", "scope": "risk_exclusion"},
    "ZGSZ": {"city": "Shenzhen", "scope": "research_only"},
    "ZHHH": {"city": "Wuhan", "scope": "research_only"},
    "ZUCK": {"city": "Chongqing", "scope": "research_only"},
}


def utc_now() -> datetime:
    return datetime.now(UTC)


def iso_now() -> str:
    return utc_now().isoformat()


def parse_stamp(value: str | None) -> datetime | None:
    if not isinstance(value, str) or not value or value != value.strip():
        return None
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if stamp.tzinfo is None or stamp.utcoffset() is None:
            return None
        stamp = stamp.astimezone(UTC)
        if not 2000 <= stamp.year <= 2100:
            return None
        return stamp
    except (OverflowError, ValueError):
        return None


def strict_optional_number(value: Any, *, minimum: float, maximum: float) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("numeric fact must be a native finite number")
    number = float(value)
    if not math.isfinite(number) or not minimum <= number <= maximum:
        raise ValueError("numeric fact is outside the accepted range")
    return number


def connect(path: Path = OBSERVATIONS_DB) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=30000")
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=NORMAL")
    db.execute("""CREATE TABLE IF NOT EXISTS metar_observations (
      observation_id INTEGER PRIMARY KEY AUTOINCREMENT,
      station TEXT NOT NULL, city TEXT NOT NULL, decision_scope TEXT NOT NULL,
      report_time TEXT NOT NULL, received_at TEXT NOT NULL,
      report_type TEXT NOT NULL, temperature_c REAL,
      wind_mps REAL, visibility_km REAL, conditions TEXT,
      raw_observation TEXT NOT NULL, raw_hash TEXT NOT NULL,
      source TEXT NOT NULL DEFAULT 'aviationweather_metar',
      UNIQUE(station, report_time, raw_hash)
    )""")
    db.execute("CREATE INDEX IF NOT EXISTS idx_metar_station_report ON metar_observations(station,report_time DESC)")
    db.execute("""CREATE TABLE IF NOT EXISTS metar_live_status (
      station TEXT PRIMARY KEY, city TEXT NOT NULL, decision_scope TEXT NOT NULL,
      last_attempt_at TEXT NOT NULL, last_success_at TEXT,
      last_report_at TEXT, last_report_temperature_c REAL,
      state TEXT NOT NULL, detail TEXT, updated_at TEXT NOT NULL
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS service_heartbeats
      (service TEXT PRIMARY KEY, updated_at TEXT NOT NULL, detail TEXT)""")
    ensure_observations_events(db)
    return db


def raw_fields(raw: str) -> tuple[float | None, float | None, str]:
    """Extract only display facts that are explicit in the source METAR text."""
    text = raw.upper()
    wind = re.search(r"(?:\d{3}|VRB)(\d{2,3})(?:G\d{2,3})?MPS", text)
    visibility = None
    if "CAVOK" in text:
        visibility = 10.0
    else:
        vis = re.search(r"\b(\d{4})\b", text)
        if vis:
            metres = int(vis.group(1))
            if 500 <= metres <= 9999:
                visibility = round(metres / 1000, 1)
    if "TS" in text:
        condition = "雷暴"
    elif "SHRA" in text or "-RA" in text or " RA" in text:
        condition = "降雨"
    elif "CAVOK" in text or "NSC" in text or "SKC" in text:
        condition = "晴"
    elif any(token in text for token in ("OVC", "BKN", "SCT", "FEW")):
        condition = "多云"
    else:
        condition = "未解析"
    return (float(wind.group(1)) if wind else None, visibility, condition)


def normalise(item: dict[str, Any], received_at: str) -> dict[str, Any] | None:
    station = str(item.get("icaoId") or "").upper()
    if station not in STATIONS:
        return None
    report_stamp = parse_stamp(item.get("reportTime"))
    received_stamp = parse_stamp(received_at)
    if report_stamp is None or received_stamp is None:
        return None
    age_seconds = (received_stamp - report_stamp).total_seconds()
    if age_seconds < -MAX_REPORT_FUTURE_SECONDS or age_seconds > MAX_REPORT_AGE_SECONDS:
        return None
    raw = str(item.get("rawOb") or "").strip()
    if not raw:
        return None
    raw_identity = re.match(r"^(METAR|SPECI)\s+([A-Z0-9]{4})\b", raw.upper())
    if raw_identity is None or raw_identity.group(2) != station:
        return None
    try:
        temperature = strict_optional_number(
            item.get("temp"), minimum=MIN_TEMPERATURE_C, maximum=MAX_TEMPERATURE_C,
        )
    except ValueError:
        return None
    wind, visibility, condition = raw_fields(raw)
    raw_hash = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    kind = "SPECI" if raw.upper().startswith("SPECI") else "METAR"
    return {"station": station, "city": STATIONS[station]["city"],
            "decision_scope": STATIONS[station]["scope"], "report_time": report_stamp.isoformat(),
            "received_at": received_stamp.isoformat(), "report_type": kind,
            "temperature_c": temperature, "wind_mps": wind,
            "visibility_km": visibility, "conditions": condition,
            "raw_observation": raw, "raw_hash": raw_hash}


def fetch_reports() -> list[dict[str, Any]]:
    query = urllib.parse.urlencode({"ids": ",".join(STATIONS), "format": "json", "hours": BACKFILL_HOURS})
    request = urllib.request.Request(
        f"https://aviationweather.gov/api/data/metar?{query}",
        headers={"User-Agent": "temperature-market-research/1.0"},
    )
    with urllib.request.urlopen(request, timeout=HTTP_TIMEOUT_SECONDS) as response:
        payload = json.loads(response.read())
    if not isinstance(payload, list):
        raise ValueError("METAR response is not a list")
    return [item for item in payload if isinstance(item, dict)]


def expected_max_age_seconds(db: sqlite3.Connection, station: str) -> int:
    """Use observed station cadence; hourly stations are not falsely stale."""
    rows = db.execute("""SELECT report_time FROM metar_observations WHERE station=?
                       ORDER BY report_time DESC LIMIT 9""", (station,)).fetchall()
    stamps = [parse_stamp(row[0]) for row in rows]
    intervals = [(stamps[i] - stamps[i + 1]).total_seconds() for i in range(len(stamps) - 1)
                 if stamps[i] and stamps[i + 1] and 60 <= (stamps[i] - stamps[i + 1]).total_seconds() <= 7200]
    cadence = median(intervals) if intervals else 3600
    return int(max(45 * 60, min(180 * 60, cadence * 2.5)))


def upsert_status(db: sqlite3.Connection, station: str, *, state: str, detail: str,
                  report: dict[str, Any] | None, attempted_at: str, success: bool) -> bool:
    previous = db.execute("SELECT state FROM metar_live_status WHERE station=?", (station,)).fetchone()
    meta = STATIONS[station]
    db.execute("""INSERT INTO metar_live_status
      (station,city,decision_scope,last_attempt_at,last_success_at,last_report_at,
       last_report_temperature_c,state,detail,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(station) DO UPDATE SET city=excluded.city,decision_scope=excluded.decision_scope,
       last_attempt_at=excluded.last_attempt_at,last_success_at=CASE WHEN ? THEN excluded.last_success_at ELSE metar_live_status.last_success_at END,
       last_report_at=COALESCE(excluded.last_report_at,metar_live_status.last_report_at),
       last_report_temperature_c=COALESCE(excluded.last_report_temperature_c,metar_live_status.last_report_temperature_c),
       state=excluded.state,detail=excluded.detail,updated_at=excluded.updated_at""",
      (station, meta["city"], meta["scope"], attempted_at, attempted_at if success else None,
       report["report_time"] if report else None, report["temperature_c"] if report else None,
       state, detail[:500], attempted_at, 1 if success else 0))
    return previous is None or str(previous[0]) != state


def prune(db: sqlite3.Connection, *, now: datetime | None = None, keep_days: int = 14) -> None:
    cutoff = (now or utc_now()).timestamp() - keep_days * 86400
    db.execute("DELETE FROM metar_observations WHERE unixepoch(report_time) < ?", (cutoff,))


def run_cycle(fetcher: Callable[[], list[dict[str, Any]]] = fetch_reports,
              database: Path = OBSERVATIONS_DB, *, now: datetime | None = None) -> dict[str, Any]:
    """Perform one isolated cycle; exposed for deterministic tests and POC."""
    attempted_at = (now or utc_now()).isoformat()
    db = connect(database)
    try:
        try:
            payload = fetcher()
        except Exception as exc:
            transitions = []
            for station in STATIONS:
                if upsert_status(db, station, state="unavailable", detail=f"fetch_error:{type(exc).__name__}",
                                 report=None, attempted_at=attempted_at, success=False):
                    transitions.append(station)
            for station in transitions:
                publish_event(db, "actuals", f"{station}:unavailable")
            db.execute("INSERT OR REPLACE INTO service_heartbeats VALUES (?,?,?)",
                       ("metar_collector", attempted_at, f"state=error; error={type(exc).__name__}"))
            db.commit()
            return {"ok": False, "error": str(exc), "new": 0}
        received_at = attempted_at
        reports = [candidate for item in payload if (candidate := normalise(item, received_at))]
        newest: dict[str, dict[str, Any]] = {}
        new_rows = 0
        for report in sorted(reports, key=lambda x: (x["station"], x["report_time"], x["raw_hash"])):
            cursor = db.execute("""INSERT OR IGNORE INTO metar_observations
              (station,city,decision_scope,report_time,received_at,report_type,temperature_c,
               wind_mps,visibility_km,conditions,raw_observation,raw_hash)
              VALUES (:station,:city,:decision_scope,:report_time,:received_at,:report_type,:temperature_c,
               :wind_mps,:visibility_km,:conditions,:raw_observation,:raw_hash)""", report)
            new_rows += int(cursor.rowcount > 0)
            old = newest.get(report["station"])
            if old is None or (report["report_time"], report["raw_hash"]) > (old["report_time"], old["raw_hash"]):
                newest[report["station"]] = report
        transitions = []
        stamp_now = now or utc_now()
        for station in STATIONS:
            report = newest.get(station)
            if report is None:
                state, detail = "unavailable", "provider_missing_station"
            elif report["temperature_c"] is None:
                state, detail = "unavailable", "temperature_unavailable"
            else:
                age = (stamp_now - parse_stamp(report["report_time"])).total_seconds()
                limit = expected_max_age_seconds(db, station)
                state = "healthy" if age <= limit else "delayed"
                detail = f"report_age={max(0, int(age))}s; expected_max_age={limit}s"
            if upsert_status(db, station, state=state, detail=detail, report=report,
                             attempted_at=attempted_at, success=True):
                transitions.append(station)
        for station in transitions:
            publish_event(db, "actuals", f"{station}:{newest.get(station, {}).get('report_time', 'state')}")
        prune(db, now=stamp_now)
        db.execute("INSERT OR REPLACE INTO service_heartbeats VALUES (?,?,?)",
                   ("metar_collector", attempted_at, f"state=running; new={new_rows}; reports={len(reports)}"))
        db.commit()
        return {"ok": True, "new": new_rows, "reports": len(reports)}
    finally:
        db.close()


def main() -> None:
    while True:
        result = run_cycle()
        logging.info("METAR cycle: %s", result)
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":  # pragma: no cover - long-running service
    from runtime_instance_lock import AlreadyRunningError, DUPLICATE_INSTANCE_EXIT, writer_lock
    from runtime_logging import configure_runtime_logging

    instance = writer_lock("metar_collector")
    try:
        instance.acquire()
    except AlreadyRunningError:
        raise SystemExit(DUPLICATE_INSTANCE_EXIT)
    configure_runtime_logging("metar_collector")
    try:
        with instance:
            main()
    except BaseException:
        logging.exception("METAR collector fatal error")
        raise
