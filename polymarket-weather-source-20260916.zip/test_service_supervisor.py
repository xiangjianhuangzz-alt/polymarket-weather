from __future__ import annotations

import json
import os
import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import patch

import service_supervisor as supervisor


class SupervisorLockTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.runtime = Path(self.tmp.name)
        self.lock = self.runtime / "supervisor.lock"
        self.status = self.runtime / "supervisor_status.json"
        self.patches = [
            patch.object(supervisor, "RUNTIME_DIR", self.runtime),
            patch.object(supervisor, "LOCK", self.lock),
            patch.object(supervisor, "STATUS", self.status),
        ]
        for item in self.patches:
            item.start()

    def tearDown(self) -> None:
        for item in reversed(self.patches):
            item.stop()
        self.tmp.cleanup()

    def test_dead_owner_is_reclaimed_even_with_fresh_status(self) -> None:
        self.lock.write_text(json.dumps({"pid": 777, "instance_id": "old"}), encoding="utf-8")
        self.status.write_text(json.dumps({"updated_at": datetime.now(UTC).isoformat()}), encoding="utf-8")
        with patch.object(supervisor, "pid_exists", return_value=False):
            self.assertTrue(supervisor.acquire_lock())
        owner = json.loads(self.lock.read_text(encoding="utf-8"))
        self.assertEqual(owner["pid"], os.getpid())
        self.assertEqual(owner["instance_id"], supervisor.SUPERVISOR_INSTANCE_ID)

    def test_live_owner_is_never_reclaimed(self) -> None:
        self.lock.write_text(json.dumps({"pid": 777, "instance_id": "live"}), encoding="utf-8")
        with patch.object(supervisor, "pid_exists", return_value=True):
            self.assertFalse(supervisor.acquire_lock())
        self.assertEqual(json.loads(self.lock.read_text(encoding="utf-8"))["pid"], 777)

    def test_malformed_lock_fails_closed(self) -> None:
        self.lock.write_text("not-a-lock", encoding="utf-8")
        self.assertFalse(supervisor.acquire_lock())

    def test_status_carries_current_supervisor_identity(self) -> None:
        supervisor.write_status({})
        status = json.loads(self.status.read_text(encoding="utf-8"))
        self.assertEqual(status["supervisor_pid"], os.getpid())
        self.assertEqual(status["supervisor_instance_id"], supervisor.SUPERVISOR_INSTANCE_ID)

    def test_isolated_topology_refuses_legacy_aggregate_start(self) -> None:
        with patch.dict(os.environ, {"RUNTIME_TOPOLOGY": "isolated"}), \
             patch.object(supervisor, "acquire_lock") as acquire, \
             patch.object(supervisor, "configure_runtime_logging"):
            supervisor.main()
        acquire.assert_not_called()
