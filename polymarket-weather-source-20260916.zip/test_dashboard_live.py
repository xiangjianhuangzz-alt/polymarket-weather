from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

from dashboard_live import LiveDashboard


class DashboardPushLoggingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.dashboard = LiveDashboard.__new__(LiveDashboard)
        self.dashboard._next_push_error_log = 0.0
        self.dashboard._suppressed_push_errors = 0

    def test_push_errors_are_rate_limited_and_counted(self) -> None:
        with patch("dashboard_live.logging.warning") as warning:
            self.dashboard._record_push_error(ValueError("first"), monotonic_now=10.0)
            self.dashboard._record_push_error(ValueError("second"), monotonic_now=20.0)
            self.dashboard._record_push_error(ValueError("third"), monotonic_now=71.0)
        self.assertEqual(warning.call_count, 2)
        self.assertIn(1, warning.call_args_list[1].args)

    def test_logging_failure_never_escapes_into_push_loop(self) -> None:
        with patch("dashboard_live.logging.warning",
                   side_effect=RuntimeError("logging unavailable")):
            self.dashboard._record_push_error(
                ValueError("push failed"), monotonic_now=10.0
            )


class DashboardLegacyPaperRemovalContractTests(unittest.TestCase):
    def test_v2_paper_ui_and_realtime_patch_path_are_absent(self) -> None:
        source = (Path(__file__).resolve().parent / "ui" / "live.html").read_text(
            encoding="utf-8"
        )
        for legacy_marker in (
            "paper_snapshot",
            "function applyPaperQuoteDeltas",
            "applyPaperQuoteDeltas(n.quotes)",
            "data-paper-token",
            "paper_refresh",
            "自动模拟交易（本地纸面）",
        ):
            self.assertNotIn(legacy_marker, source)


class DashboardOrderBookContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = (Path(__file__).resolve().parent / "ui" / "live.html").read_text(
            encoding="utf-8"
        )

    def test_orderbook_selects_best_levels_before_reversing_asks(self) -> None:
        self.assertIn(".sort((a,b)=>a.price-b.price).slice(0,5).reverse()", self.source)
        self.assertIn(".sort((a,b)=>b.price-a.price).slice(0,5)", self.source)

    def test_orderbook_filters_invalid_prices_and_sizes(self) -> None:
        self.assertIn("x.price>0&&x.price<1&&x.size>0", self.source)
        self.assertIn("Number.isFinite(x.price)&&Number.isFinite(x.size)", self.source)

    def test_orderbook_displays_shares_and_usd_notional(self) -> None:
        self.assertIn("<span>名义金额</span>", self.source)
        self.assertIn("style:'currency',currency:'USD'", self.source)
        self.assertIn("Number(p)*Number(s)", self.source)
        self.assertIn("maximumFractionDigits:2", self.source)

    def test_orderbook_marks_depth_that_disagrees_with_bbo(self) -> None:
        self.assertIn("盘口深度更新中", self.source)
        self.assertIn("classList.toggle('stale',!matches)", self.source)


if __name__ == "__main__":
    unittest.main()
