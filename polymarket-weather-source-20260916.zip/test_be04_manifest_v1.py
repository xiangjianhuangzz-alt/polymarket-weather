import asyncio
import hashlib
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import Mock, patch

import realtime_stream as stream


CITY_MATRIX = {
    "Beijing": ("formal", "ZBAA"),
    "Shanghai": ("formal", "ZSPD"),
    "Chengdu": ("formal", "ZUUU"),
    "Guangzhou": ("formal", "ZGGG"),
    "Shenzhen": ("research_only", "ZGSZ"),
    "Wuhan": ("research_only", "ZHHH"),
    "Chongqing": ("research_only", "ZUCK"),
}


def v1_member(token="100", market="market-100", city="Beijing", **changes):
    scope, station = CITY_MATRIX[city]
    member = {
        "schema": "research_market_attribution.v1",
        "token_id": token,
        "market_id": market,
        "city": city,
        "city_scope": scope,
        "station": station,
        "target_date": "2026-08-10",
        "outcome": "Yes",
        "event_id": "event-1",
        "source_scan_id": "scan-1",
        "attribution_status": "verified",
    }
    member.update(changes)
    return member


def legacy_member(token="100", market="market-100", city="Beijing", **changes):
    member = {
        "token_id": token,
        "market_id": market,
        "city": city,
        "target_date": "2026-08-10",
    }
    member.update(changes)
    return member


def publication_row(members, **changes):
    raw = json.dumps(members, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    published_at = "2026-08-10T00:00:00+00:00"
    values = {
        "publication_id": f"{published_at}:{token_hash[:12]}",
        "published_at": published_at,
        "token_hash": token_hash,
        "token_count": len(members),
        "members_json": raw,
        "reason": "complete_scan",
    }
    values.update(changes)
    return tuple(values[key] for key in (
        "publication_id", "published_at", "token_hash", "token_count",
        "members_json", "reason",
    ))


class ManifestV1StructureTests(unittest.TestCase):
    def parse(self, members, *, accepted=(), **changes):
        return stream._manifest_from_row(
            publication_row(members, **changes),
            accepted_legacy_hashes=set(accepted),
        )

    def test_homogeneous_v1_and_all_eight_city_bindings_pass(self):
        members = [
            v1_member(str(100 + index), f"market-{index}", city,
                      event_id=f"event-{index}")
            for index, city in enumerate(CITY_MATRIX)
        ]
        members.sort(key=lambda item: (item["token_id"], item["market_id"]))
        manifest = self.parse(members)
        self.assertIsNotNone(manifest)
        self.assertEqual(manifest.format, "research_market_attribution.v1")
        self.assertEqual(len(manifest.assets), 7)

    def test_retired_zhengzhou_is_removed_from_runtime_view_after_cutoff(self):
        members = [
            v1_member("100", "market-100"),
            {
                **v1_member("101", "market-101"),
                "city": "Zhengzhou",
                "city_scope": "research_only",
                "station": "ZHCC",
                "target_date": "2026-08-30",
            },
        ]
        members.sort(key=lambda item: (item["token_id"], item["market_id"]))

        manifest = stream._manifest_from_row(
            publication_row(members),
            now_cn=datetime(2026, 8, 30, tzinfo=stream.CHINA_TZ),
        )

        self.assertIsNotNone(manifest)
        self.assertEqual(manifest.assets, ("100",))
        self.assertEqual(set(manifest.token_market), {"100"})
        self.assertEqual(len(manifest.members), 2)

    def test_zhengzhou_remains_in_runtime_view_before_cutoff(self):
        member = {
            **v1_member("101", "market-101"),
            "city": "Zhengzhou",
            "city_scope": "research_only",
            "station": "ZHCC",
            "target_date": "2026-08-29",
        }

        manifest = stream._manifest_from_row(
            publication_row([member]),
            now_cn=datetime(2026, 8, 29, tzinfo=stream.CHINA_TZ),
        )

        self.assertIsNotNone(manifest)
        self.assertEqual(manifest.assets, ("101",))

    def test_mixed_unknown_and_malformed_v1_never_fall_back_to_legacy(self):
        cases = (
            [legacy_member("100"), v1_member("101", "market-101")],
            [v1_member(schema="unknown.v1")],
            [v1_member("100"), v1_member("101", "market-101", schema="other.v1")],
            [legacy_member(schema="research_market_attribution.v1")],
        )
        for members in cases:
            members.sort(key=lambda item: (item["token_id"], item["market_id"]))
            with self.subTest(members=members):
                self.assertIsNone(self.parse(members))

    def test_publication_envelope_is_strict(self):
        members = [v1_member()]
        valid = publication_row(members)
        names = ("publication_id", "published_at", "token_hash", "token_count", "members_json", "reason")
        cases = (
            {"reason": "test"}, {"reason": ""}, {"published_at": "2026-08-10T00:00:00"},
            {"publication_id": "bad"}, {"token_hash": "A" * 64},
            {"token_count": True}, {"token_count": "1"}, {"token_count": 2},
            {"members_json": "{}"}, {"members_json": 123},
        )
        for changes in cases:
            with self.subTest(changes=changes):
                row = dict(zip(names, valid))
                row.update(changes)
                self.assertIsNone(stream._manifest_from_row(
                    tuple(row[name] for name in names), accepted_legacy_hashes=set()
                ))

    def test_v1_required_fields_types_enums_and_scan_are_strict(self):
        for field in (
            "schema", "token_id", "market_id", "city", "city_scope", "station",
            "target_date", "outcome", "event_id", "source_scan_id", "attribution_status",
        ):
            member = v1_member()
            member.pop(field)
            with self.subTest(missing=field):
                self.assertIsNone(self.parse([member]))
        bad_members = (
            v1_member(token_id=123), v1_member(token_id="１２３"),
            v1_member(target_date="2026-02-30"), v1_member(outcome="yes"),
            v1_member(attribution_status="verified "), v1_member(city_scope="formal "),
            v1_member(city="Wuhan", city_scope="formal", station="ZHHH"),
            v1_member(city="Wuhan", city_scope="research_only", station="ZBAA"),
        )
        for member in bad_members:
            with self.subTest(member=member):
                self.assertIsNone(self.parse([member]))
        different_scans = [v1_member("100"), v1_member("101", "market-101", source_scan_id="scan-2")]
        self.assertIsNone(self.parse(different_scans))

    def test_order_hash_and_global_uniqueness_are_strict(self):
        ordered = [v1_member("100", "market-a"), v1_member("101", "market-b")]
        self.assertIsNone(self.parse(list(reversed(ordered))))
        self.assertIsNone(self.parse([v1_member("100", "market-a"), v1_member("100", "market-b")]))
        self.assertIsNone(self.parse([v1_member("100", "market-a"), v1_member("101", "market-a")]))
        row = publication_row(ordered, token_hash="0" * 64)
        self.assertIsNone(stream._manifest_from_row(row, accepted_legacy_hashes=set()))

    def test_only_previously_accepted_legacy_hash_can_parse(self):
        row = publication_row([legacy_member()])
        token_hash = row[2]
        self.assertIsNone(stream._manifest_from_row(row, accepted_legacy_hashes=set()))
        parsed = stream._manifest_from_row(row, accepted_legacy_hashes={token_hash})
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.format, "legacy")

    def test_schema_less_v1_exclusive_fields_are_rejected_even_if_accepted(self):
        exclusive_values = {
            "city_scope": "formal",
            "station": "ZBAA",
            "outcome": "Yes",
            "event_id": "event-1",
            "source_scan_id": "scan-1",
            "attribution_status": "verified",
        }
        cases = [
            legacy_member(**{field: value})
            for field, value in exclusive_values.items()
        ]
        cases.append(legacy_member(**exclusive_values))
        for member in cases:
            row = publication_row([member])
            with self.subTest(fields=sorted(set(member) - {
                "token_id", "market_id", "city", "target_date",
            })):
                self.assertIsNone(stream._manifest_from_row(
                    row, accepted_legacy_hashes={row[2]},
                ))

        genuine = publication_row([legacy_member()])
        parsed = stream._manifest_from_row(
            genuine, accepted_legacy_hashes={genuine[2]},
        )
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed.format, "legacy")


class TransitionAndRollbackTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.research = Path(self.tmp.name) / "research.sqlite3"
        self.realtime = Path(self.tmp.name) / "realtime.sqlite3"
        self.old_research, self.old_db = stream.RESEARCH_DB, stream.DB
        stream.RESEARCH_DB, stream.DB = self.research, self.realtime
        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute("""CREATE TABLE market_universe_publications (
              publication_id TEXT PRIMARY KEY, published_at TEXT, token_hash TEXT,
              token_count INTEGER, members_json TEXT, reason TEXT)""")
        db = stream.connect()
        db.close()

    def tearDown(self):
        stream.RESEARCH_DB, stream.DB = self.old_research, self.old_db
        self.tmp.cleanup()

    def store(self, members):
        row = publication_row(members)
        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute(
                "INSERT OR IGNORE INTO market_universe_publications VALUES (?,?,?,?,?,?)",
                row,
            )
        return row[2]

    def accepted(self, token_hash, event_at, event_type="universe_changed"):
        with closing(sqlite3.connect(self.realtime)) as db, db:
            db.execute("""INSERT INTO stream_connection_events VALUES
              (?,?,?,?,?,?,?)""", (event_at, event_type, "fixture", token_hash, 1, "[]", "[]"))

    def state_for(self, manifest, *, writer=None):
        hub = stream.LiveStateHub()
        hub.set_universe(manifest.token_market)
        return stream.StreamState(
            None, manifest.token_market, writer or Mock(), hub, manifest.token_hash,
            token_target_date=manifest.token_target_date, manifest=manifest,
        )

    def forward_rollover_pair(self):
        current_hash = self.store([
            v1_member("100", "market-100", target_date="2026-08-11", event_id="event-100"),
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
        ])
        candidate_hash = self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
            v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
        ])
        return (
            stream.published_universe_manifest(current_hash),
            stream.published_universe_manifest(candidate_hash),
        )

    def legacy_forward_rollover_pair(self):
        current_hash = self.store([
            legacy_member("100", "market-100", target_date="2026-08-11"),
            legacy_member("101", "market-101", target_date="2026-08-12"),
        ])
        self.accepted(current_hash, "2026-08-12T00:00:00+00:00", "connected")
        candidate_hash = self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
            v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
        ])
        return (
            stream.published_universe_manifest(current_hash),
            stream.published_universe_manifest(candidate_hash),
        )

    @staticmethod
    def local_universe_snapshot(state):
        return {
            "hash": state.universe_hash,
            "token_market": dict(state.token_market),
            "target_date": dict(state.token_target_date),
            "manifest": state.manifest,
            "hub_token_market": dict(state.hub.token_market),
            "hub_quotes": dict(state.hub.quotes),
        }

    def test_startup_and_dynamic_share_remap_mixed_and_date_gates(self):
        current_members = [v1_member("100", "market-a")]
        current_hash = self.store(current_members)
        self.accepted(current_hash, "2026-08-10T00:00:00+00:00", "connected")
        current = stream.published_universe_manifest(current_hash)
        candidates = (
            [v1_member("100", "market-remap")],
            [v1_member("100", "market-a", target_date="2026-08-11")],
            [v1_member("101", "market-new")],
        )
        now = datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ)
        for members in candidates:
            candidate_hash = self.store(members)
            candidate = stream.published_universe_manifest(candidate_hash)
            dynamic = stream.validate_universe_transition(current, candidate, now_cn=now)
            startup = stream.select_startup_universe(current, candidate, now_cn=now)
            with self.subTest(members=members):
                self.assertIsNone(dynamic)
                self.assertIs(startup, current)

    def test_forward_mixed_rollover_has_independent_classification_and_time_boundaries(self):
        current, candidate = self.forward_rollover_pair()
        at_open = datetime(2026, 8, 12, 0, tzinfo=stream.CHINA_TZ)
        self.assertIsNone(stream.validate_universe_transition(
            current, candidate, now_cn=at_open,
        ))
        change = stream.validate_universe_transition(
            current, candidate, now_cn=at_open, forward_mixed_confirmed=True,
        )
        self.assertIsNotNone(change)
        self.assertEqual(change.added, ("102",))
        self.assertEqual(change.removed, ("100",))
        self.assertEqual(change.format_transition, "forward_mixed_rollover")

        for allowed in (
            datetime(2026, 8, 12, 3, tzinfo=stream.CHINA_TZ),
            datetime(2026, 8, 12, 5, 59, 59, tzinfo=stream.CHINA_TZ),
        ):
            with self.subTest(allowed=allowed):
                self.assertIsNotNone(stream.validate_universe_transition(
                    current, candidate, now_cn=allowed,
                    forward_mixed_confirmed=True,
                ))

        for now_cn in (
            datetime(2026, 8, 11, 23, 59, 59, tzinfo=stream.CHINA_TZ),
            datetime(2026, 8, 12, 6, tzinfo=stream.CHINA_TZ),
            datetime(2026, 8, 12, 12, tzinfo=stream.CHINA_TZ),
        ):
            with self.subTest(now_cn=now_cn):
                self.assertIsNone(stream.validate_universe_transition(
                    current, candidate, now_cn=now_cn,
                    forward_mixed_confirmed=True,
                ))

    def test_legacy_to_v1_forward_mixed_has_independent_classification_and_boundaries(self):
        current, candidate = self.legacy_forward_rollover_pair()
        at_open = datetime(2026, 8, 12, 0, tzinfo=stream.CHINA_TZ)
        self.assertEqual(current.format, "legacy")
        self.assertEqual(candidate.format, stream.V1_SCHEMA)
        self.assertIsNone(stream.validate_universe_transition(
            current, candidate, now_cn=at_open,
        ))
        change = stream.validate_universe_transition(
            current, candidate, now_cn=at_open,
            forward_mixed_confirmed=True,
        )
        self.assertIsNotNone(change)
        self.assertEqual(change.added, ("102",))
        self.assertEqual(change.removed, ("100",))
        self.assertEqual(change.format_transition, "legacy_to_v1_forward_mixed")

        for allowed in (
            datetime(2026, 8, 12, 3, tzinfo=stream.CHINA_TZ),
            datetime(2026, 8, 12, 5, 59, 59, tzinfo=stream.CHINA_TZ),
        ):
            with self.subTest(allowed=allowed):
                self.assertIsNotNone(stream.validate_universe_transition(
                    current, candidate, now_cn=allowed,
                    forward_mixed_confirmed=True,
                ))
        for now_cn in (
            datetime(2026, 8, 11, 23, 59, 59, tzinfo=stream.CHINA_TZ),
            datetime(2026, 8, 12, 6, tzinfo=stream.CHINA_TZ),
            datetime(2026, 8, 12, 12, tzinfo=stream.CHINA_TZ),
        ):
            with self.subTest(now_cn=now_cn):
                self.assertIsNone(stream.validate_universe_transition(
                    current, candidate, now_cn=now_cn,
                    forward_mixed_confirmed=True,
                ))

    def test_legacy_forward_requires_accepted_publication_not_literal_or_forged(self):
        current, candidate = self.legacy_forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        self.assertTrue(current.accepted_legacy)

        new_row = publication_row([
            legacy_member("200", "market-200", target_date="2026-08-11"),
            legacy_member("201", "market-201", target_date="2026-08-12"),
        ])
        self.assertIsNone(stream._manifest_from_row(
            new_row, accepted_legacy_hashes=set(),
        ))

        literal = stream.UniverseManifest(
            current.assets, current.token_market, current.token_hash,
            current.token_target_date, format="legacy_literal",
        )
        self.assertIsNone(stream.validate_universe_transition(
            literal, candidate, now_cn=now_cn,
            forward_mixed_confirmed=True,
        ))

        forged = stream.UniverseManifest(
            current.assets, current.token_market, current.token_hash,
            current.token_target_date, current.publication_id,
            current.published_at, current.reason, current.format, current.members,
            accepted_legacy=False,
        )
        self.assertIsNone(stream.validate_universe_transition(
            forged, candidate, now_cn=now_cn,
            forward_mixed_confirmed=True,
        ))

    def test_legacy_forward_compares_only_owned_shared_facts_and_rejects_remap(self):
        current, _candidate = self.legacy_forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        valid = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="candidate-only-event"),
            v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
        ]))
        change = stream.validate_universe_transition(
            current, valid, now_cn=now_cn, forward_mixed_confirmed=True,
        )
        self.assertEqual(change.format_transition, "legacy_to_v1_forward_mixed")
        self.assertNotIn("schema", current.member_by_token["101"])
        self.assertNotIn("station", current.member_by_token["101"])
        self.assertEqual(valid.member_by_token["101"]["event_id"], "candidate-only-event")

        rewrites = (
            v1_member("101", "market-changed", target_date="2026-08-12", event_id="event-101"),
            v1_member("101", "market-101", city="Shanghai", target_date="2026-08-12", event_id="event-101"),
            v1_member("101", "market-101", target_date="2026-08-13", event_id="event-101"),
        )
        for shared in rewrites:
            members = [
                shared,
                v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
            ]
            members.sort(key=lambda item: (item["token_id"], item["market_id"]))
            candidate = stream.published_universe_manifest(self.store(members))
            with self.subTest(shared=shared):
                self.assertIsNone(stream.validate_universe_transition(
                    current, candidate, now_cn=now_cn,
                    forward_mixed_confirmed=True,
                ))

        remapped = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
            v1_member("102", "market-100", target_date="2026-08-13", event_id="event-102"),
        ]))
        self.assertIsNone(stream.validate_universe_transition(
            current, remapped, now_cn=now_cn,
            forward_mixed_confirmed=True,
        ))

    def test_legacy_forward_date_sides_and_candidate_structure_are_strict(self):
        current, candidate = self.legacy_forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        nonpast_current_hash = self.store([
            legacy_member("100", "market-100", target_date="2026-08-12"),
            legacy_member("101", "market-101", target_date="2026-08-12"),
        ])
        self.accepted(nonpast_current_hash, "2026-08-12T00:01:00+00:00")
        nonpast_current = stream.published_universe_manifest(nonpast_current_hash)
        self.assertIsNone(stream.validate_universe_transition(
            nonpast_current, candidate, now_cn=now_cn,
            forward_mixed_confirmed=True,
        ))

        past_candidate = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
            v1_member("102", "market-102", target_date="2026-08-11", event_id="event-102"),
        ]))
        self.assertIsNone(stream.validate_universe_transition(
            current, past_candidate, now_cn=now_cn,
            forward_mixed_confirmed=True,
        ))

        pure_add = stream.published_universe_manifest(self.store([
            v1_member("100", "market-100", target_date="2026-08-11", event_id="event-100"),
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
            v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
        ]))
        pure_add_change = stream.validate_universe_transition(
            current, pure_add, now_cn=now_cn,
            forward_mixed_confirmed=True,
        )
        if pure_add_change is not None:
            self.assertNotEqual(
                pure_add_change.format_transition,
                "legacy_to_v1_forward_mixed",
            )

        shrink = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
        ]))
        shrink_change = stream.validate_universe_transition(
            current, shrink, now_cn=now_cn, shrink_confirmed=True,
            forward_mixed_confirmed=True,
        )
        if shrink_change is not None:
            self.assertNotEqual(
                shrink_change.format_transition,
                "legacy_to_v1_forward_mixed",
            )

    def test_legacy_forward_two_observations_are_transition_isolated(self):
        current, candidate = self.legacy_forward_rollover_pair()
        state = self.state_for(current)
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        self.assertEqual(state.pending_forward_rollover_hash, candidate.token_hash)
        self.assertEqual(state.pending_forward_rollover_current_hash, current.token_hash)
        self.assertEqual(
            state.pending_forward_rollover_transition,
            "legacy_to_v1_forward_mixed",
        )
        self.assertEqual(state.pending_forward_rollover_count, 1)

        state.pending_forward_rollover_transition = "forward_mixed_rollover"
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        self.assertEqual(state.pending_forward_rollover_count, 1)
        self.assertEqual(
            state.pending_forward_rollover_transition,
            "legacy_to_v1_forward_mixed",
        )
        change = state.plan_subscription_update(candidate, now_cn=now_cn)
        self.assertEqual(change.format_transition, "legacy_to_v1_forward_mixed")

    def test_legacy_forward_startup_cannot_use_database_repetition(self):
        current, candidate = self.legacy_forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        with patch.object(stream, "latest_manifest_repeated", return_value=True):
            self.assertIs(stream.select_startup_universe(
                current, candidate, now_cn=now_cn,
            ), current)

    async def test_legacy_forward_success_order_audit_and_downgrade_boundary(self):
        current, candidate = self.legacy_forward_rollover_pair()
        writer = Mock()
        writer.submit_connection_event.return_value = True
        state = self.state_for(current, writer=writer)
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        order = []
        socket = _OrderedSocket(order)
        original_apply = state.apply_universe

        def tracked_apply(manifest):
            order.append("apply")
            original_apply(manifest)

        writer.submit_connection_event.side_effect = (
            lambda *args, **kwargs: order.append("audit") or True
        )
        with patch.object(state, "apply_universe", side_effect=tracked_apply):
            change = await stream.apply_manifest_candidate(
                socket, state, candidate, now_cn=now_cn,
            )
        self.assertEqual(order, ["subscribe", "unsubscribe", "audit", "apply"])
        self.assertEqual(change.format_transition, "legacy_to_v1_forward_mixed")
        self.assertEqual(state.manifest, candidate)
        self.assertEqual(state.universe_hash, candidate.token_hash)
        self.assertEqual(state.token_market, candidate.token_market)
        self.assertEqual(state.token_target_date, candidate.token_target_date)
        self.assertEqual(state.hub.token_market, candidate.token_market)
        args, _kwargs = writer.submit_connection_event.call_args
        detail = json.loads(args[1])
        self.assertEqual(detail["transition"], "legacy_to_v1_forward_mixed")
        self.assertEqual(detail["from_hash"], current.token_hash)
        self.assertEqual(detail["to_hash"], candidate.token_hash)
        self.assertEqual(detail["remapped"], [])
        self.assertIsNone(stream.validate_universe_transition(
            candidate, current, now_cn=now_cn, shrink_confirmed=True,
            forward_mixed_confirmed=True,
        ))

    async def test_legacy_forward_failures_pin_prechange_legacy_current(self):
        current, candidate = self.legacy_forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)

        writer = Mock()
        state = self.state_for(current, writer=writer)
        before = self.local_universe_snapshot(state)
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        with self.assertRaises(ConnectionError):
            await stream.apply_manifest_candidate(
                _FailingSocket(), state, candidate, now_cn=now_cn,
            )
        writer.submit_connection_event.assert_not_called()
        self.assertEqual(self.local_universe_snapshot(state), before)

        for failure in ("unsubscribe", "writer_false", "writer_error", "apply"):
            with self.subTest(failure=failure):
                writer = Mock()
                writer.submit_connection_event.return_value = failure != "writer_false"
                if failure == "writer_error":
                    writer.submit_connection_event.side_effect = RuntimeError("fixture")
                state = self.state_for(current, writer=writer)
                before = self.local_universe_snapshot(state)
                self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
                socket = _NthFailSocket(2) if failure == "unsubscribe" else _Socket()
                apply_context = (
                    patch.object(state, "apply_universe", side_effect=RuntimeError("fixture"))
                    if failure == "apply" else patch.object(state, "apply_universe", wraps=state.apply_universe)
                )
                with apply_context:
                    with self.assertRaises(stream.UniverseReconnectRequired) as raised:
                        await stream.apply_manifest_candidate(
                            socket, state, candidate, now_cn=now_cn,
                        )
                self.assertEqual(raised.exception.recovery_hash, current.token_hash)
                self.assertEqual(raised.exception.recovery_manifest.format, "legacy")
                self.assertEqual(self.local_universe_snapshot(state), before)

                latest = stream.published_universe_manifest(self.store([
                    v1_member("200", "market-200", target_date="2026-08-13", event_id="event-200"),
                ]))
                pin = stream.ReconnectRecoveryPin()
                pin.capture(raised.exception)
                with patch.object(stream, "read_reconnect_manifest", return_value=latest) as normal_read:
                    selected = await pin.select(stream.LiveStateHub(), Mock())
                self.assertEqual(selected.token_hash, current.token_hash)
                normal_read.assert_not_called()

    def test_forward_mixed_rollover_date_and_nonempty_sides_are_strict(self):
        current, candidate = self.forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        cases = (
            [
                v1_member("100", "market-100", target_date="2026-08-12", event_id="event-100"),
                v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
                v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
            ],
            [
                v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
                v1_member("102", "market-102", target_date="2026-08-11", event_id="event-102"),
            ],
            [
                v1_member("101", "market-101", target_date="2026-08-11", event_id="event-101"),
                v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
            ],
        )
        for members in cases:
            members.sort(key=lambda item: (item["token_id"], item["market_id"]))
            with self.subTest(members=members):
                rejected = stream.published_universe_manifest(self.store(members))
                self.assertIsNone(stream.validate_universe_transition(
                    current, rejected, now_cn=now_cn,
                    forward_mixed_confirmed=True,
                ))

        pure_add = stream.published_universe_manifest(self.store([
            *candidate.members,
            v1_member("103", "market-103", target_date="2026-08-13", event_id="event-103"),
        ]))
        ordinary = stream.validate_universe_transition(
            candidate, pure_add, now_cn=now_cn, forward_mixed_confirmed=True,
        )
        self.assertEqual(ordinary.added, ("103",))
        self.assertIsNone(ordinary.format_transition)

        shrink = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
        ]))
        shrink_change = stream.validate_universe_transition(
            current, shrink, now_cn=now_cn, shrink_confirmed=True,
            forward_mixed_confirmed=True,
        )
        self.assertEqual(shrink_change.removed, ("100",))
        self.assertIsNone(shrink_change.format_transition)

        nonpast_current = stream.published_universe_manifest(self.store([
            v1_member("100", "market-100", target_date="2026-08-12", event_id="event-100"),
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
        ]))
        self.assertIsNone(stream.validate_universe_transition(
            nonpast_current, candidate, now_cn=now_cn,
            forward_mixed_confirmed=True,
        ))

    def test_forward_mixed_rollover_rejects_identity_changes_and_market_remap(self):
        current, _candidate = self.forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        shared_changes = (
            {"market": "market-changed"},
            {"city": "Shanghai"},
            {"target_date": "2026-08-13"},
            {"event_id": "event-changed"},
        )
        for changes in shared_changes:
            shared = v1_member(
                "101", changes.get("market", "market-101"),
                changes.get("city", "Beijing"),
                target_date=changes.get("target_date", "2026-08-12"),
                event_id=changes.get("event_id", "event-101"),
            )
            members = [
                shared,
                v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
            ]
            members.sort(key=lambda item: (item["token_id"], item["market_id"]))
            with self.subTest(shared=shared):
                candidate = stream.published_universe_manifest(self.store(members))
                self.assertIsNone(stream.validate_universe_transition(
                    current, candidate, now_cn=now_cn,
                    forward_mixed_confirmed=True,
                ))

        for field, value in (
            ("city_scope", "research_only"), ("station", "ZSPD"),
            ("outcome", "No"),
        ):
            members = [
                v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101", **{field: value}),
                v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
            ]
            row = publication_row(members)
            with self.subTest(field=field):
                self.assertIsNone(stream._manifest_from_row(
                    row, accepted_legacy_hashes=set(),
                ))

        remapped = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
            v1_member("102", "market-100", target_date="2026-08-13", event_id="event-102"),
        ]))
        self.assertIsNone(stream.validate_universe_transition(
            current, remapped, now_cn=now_cn, forward_mixed_confirmed=True,
        ))

    def test_forward_mixed_rollover_requires_two_runtime_observations_bound_to_current(self):
        current, candidate = self.forward_rollover_pair()
        state = self.state_for(current)
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        self.assertEqual(state.pending_forward_rollover_hash, candidate.token_hash)
        self.assertEqual(state.pending_forward_rollover_current_hash, current.token_hash)
        self.assertEqual(state.pending_forward_rollover_count, 1)

        invalid = stream.published_universe_manifest(self.store([
            v1_member("101", "market-changed", target_date="2026-08-12", event_id="event-101"),
            v1_member("102", "market-102", target_date="2026-08-13", event_id="event-102"),
        ]))
        self.assertIsNone(state.plan_subscription_update(invalid, now_cn=now_cn))
        self.assertIsNone(state.pending_forward_rollover_hash)
        self.assertEqual(state.pending_forward_rollover_count, 0)

        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        change = state.plan_subscription_update(candidate, now_cn=now_cn)
        self.assertEqual(change.format_transition, "forward_mixed_rollover")

        state = self.state_for(current)
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        other = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", target_date="2026-08-12", event_id="event-101"),
            v1_member("103", "market-103", target_date="2026-08-13", event_id="event-103"),
        ]))
        self.assertIsNone(state.plan_subscription_update(other, now_cn=now_cn))
        self.assertEqual(state.pending_forward_rollover_hash, other.token_hash)
        self.assertEqual(state.pending_forward_rollover_count, 1)

        state.universe_hash = "f" * 64
        self.assertIsNone(state.plan_subscription_update(other, now_cn=now_cn))
        self.assertIsNone(state.pending_forward_rollover_current_hash)
        self.assertIsNone(state.pending_forward_rollover_hash)
        self.assertEqual(state.pending_forward_rollover_count, 0)

    def test_startup_cannot_bypass_forward_mixed_runtime_confirmation(self):
        current, candidate = self.forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        with patch.object(stream, "latest_manifest_repeated", return_value=True):
            selected = stream.select_startup_universe(
                current, candidate, now_cn=now_cn,
            )
        self.assertIs(selected, current)

    async def test_forward_mixed_pending_is_cleared_when_dynamic_read_fails(self):
        current, candidate = self.forward_rollover_pair()
        state = self.state_for(current)
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        self.assertEqual(state.pending_forward_rollover_count, 1)

        with patch.object(
            stream, "published_universe_manifest", side_effect=RuntimeError("fixture"),
        ):
            self.assertIsNone(await stream.apply_subscription_update(
                _Socket(), state, now_cn=now_cn, monotonic_now=20,
            ))
        self.assertIsNone(state.pending_forward_rollover_hash)
        self.assertIsNone(state.pending_forward_rollover_current_hash)
        self.assertEqual(state.pending_forward_rollover_count, 0)

    async def test_forward_mixed_success_is_subscribe_unsubscribe_audit_apply(self):
        current, candidate = self.forward_rollover_pair()
        writer = Mock()
        writer.submit_connection_event.return_value = True
        state = self.state_for(current, writer=writer)
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        order = []
        socket = _OrderedSocket(order)
        original_apply = state.apply_universe

        def tracked_apply(manifest):
            order.append("apply")
            original_apply(manifest)

        writer.submit_connection_event.side_effect = (
            lambda *args, **kwargs: order.append("audit") or True
        )
        with patch.object(state, "apply_universe", side_effect=tracked_apply):
            change = await stream.apply_manifest_candidate(
                socket, state, candidate, now_cn=now_cn,
            )

        self.assertEqual(order, ["subscribe", "unsubscribe", "audit", "apply"])
        self.assertEqual(change.format_transition, "forward_mixed_rollover")
        self.assertEqual(state.universe_hash, candidate.token_hash)
        self.assertEqual(state.token_market, candidate.token_market)
        self.assertEqual(state.token_target_date, candidate.token_target_date)
        self.assertEqual(state.hub.token_market, candidate.token_market)
        args, kwargs = writer.submit_connection_event.call_args
        detail = json.loads(args[1])
        self.assertEqual(detail["transition"], "forward_mixed_rollover")
        self.assertEqual(detail["from_hash"], current.token_hash)
        self.assertEqual(detail["to_hash"], candidate.token_hash)
        self.assertEqual(detail["added"], ["102"])
        self.assertEqual(detail["removed"], ["100"])
        self.assertEqual(detail["remapped"], [])
        self.assertEqual(kwargs["universe_hash"], candidate.token_hash)

    async def test_forward_mixed_failures_preserve_current_and_pin_after_partial_change(self):
        current, candidate = self.forward_rollover_pair()
        now_cn = datetime(2026, 8, 12, 1, tzinfo=stream.CHINA_TZ)

        writer = Mock()
        state = self.state_for(current, writer=writer)
        before = self.local_universe_snapshot(state)
        self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
        with self.assertRaises(ConnectionError):
            await stream.apply_manifest_candidate(
                _FailingSocket(), state, candidate, now_cn=now_cn,
            )
        writer.submit_connection_event.assert_not_called()
        self.assertEqual(self.local_universe_snapshot(state), before)

        for failure in ("unsubscribe", "writer_false", "writer_error", "apply"):
            with self.subTest(failure=failure):
                writer = Mock()
                writer.submit_connection_event.return_value = failure != "writer_false"
                if failure == "writer_error":
                    writer.submit_connection_event.side_effect = RuntimeError("fixture")
                state = self.state_for(current, writer=writer)
                before = self.local_universe_snapshot(state)
                self.assertIsNone(state.plan_subscription_update(candidate, now_cn=now_cn))
                socket = _NthFailSocket(2) if failure == "unsubscribe" else _Socket()
                apply_context = (
                    patch.object(state, "apply_universe", side_effect=RuntimeError("fixture"))
                    if failure == "apply" else patch.object(state, "apply_universe", wraps=state.apply_universe)
                )
                with apply_context:
                    with self.assertRaises(stream.UniverseReconnectRequired) as raised:
                        await stream.apply_manifest_candidate(
                            socket, state, candidate, now_cn=now_cn,
                        )
                self.assertEqual(raised.exception.recovery_hash, current.token_hash)
                self.assertEqual(self.local_universe_snapshot(state), before)

                latest = stream.published_universe_manifest(self.store([
                    v1_member("200", "market-200", target_date="2026-08-13", event_id="event-200"),
                ]))
                pin = stream.ReconnectRecoveryPin()
                pin.capture(raised.exception)
                with patch.object(stream, "read_reconnect_manifest", return_value=latest) as normal_read:
                    selected = await pin.select(stream.LiveStateHub(), Mock())
                self.assertEqual(selected.token_hash, current.token_hash)
                normal_read.assert_not_called()

    def test_v1_current_rejects_normal_legacy_downgrade_even_in_rollover_window(self):
        legacy_hash = self.store([legacy_member("100", "market-a")])
        current_hash = self.store([v1_member("100", "market-a")])
        self.accepted(legacy_hash, "2026-08-10T00:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T00:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        legacy = stream.published_universe_manifest(legacy_hash)
        for hour in (0, 12):
            now = datetime(2026, 8, 10, hour, tzinfo=stream.CHINA_TZ)
            with self.subTest(hour=hour):
                self.assertIsNone(stream.validate_universe_transition(
                    current, legacy, now_cn=now, shrink_confirmed=True,
                ))
                self.assertIs(stream.select_startup_universe(
                    current, legacy, now_cn=now,
                ), current)

    def test_legacy_to_v1_same_assets_is_explicit_zero_asset_format_upgrade(self):
        legacy_members = [
            legacy_member("100", "market-100", "Beijing"),
            legacy_member("101", "market-101", "Wuhan"),
        ]
        legacy_hash = self.store(legacy_members)
        self.accepted(legacy_hash, "2026-08-10T00:00:00+00:00", "connected")
        current = stream.published_universe_manifest(legacy_hash)
        candidate_hash = self.store([
            v1_member("100", "market-100", "Beijing", event_id="event-100"),
            v1_member("101", "market-101", "Wuhan", event_id="event-101"),
        ])
        candidate = stream.published_universe_manifest(candidate_hash)
        now = datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ)

        change = stream.validate_universe_transition(current, candidate, now_cn=now)
        state = self.state_for(current)
        dynamic = state.plan_subscription_update(candidate, now_cn=now)

        self.assertIsNotNone(change)
        self.assertEqual(change.added, ())
        self.assertEqual(change.removed, ())
        self.assertEqual(change.format_transition, "legacy_to_v1")
        self.assertEqual(dynamic, change)
        self.assertIs(stream.select_startup_universe(
            current, candidate, now_cn=now,
        ), candidate)

    def test_format_upgrade_rejects_fact_rewrites_and_never_masks_asset_changes(self):
        legacy_hash = self.store([legacy_member("100", "market-100", "Beijing")])
        self.accepted(legacy_hash, "2026-08-10T00:00:00+00:00", "connected")
        current = stream.published_universe_manifest(legacy_hash)
        now = datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ)

        rejected = (
            [v1_member("100", "market-remap", "Beijing")],
            [v1_member("100", "market-100", "Shanghai")],
            [v1_member("100", "market-100", "Beijing", target_date="2026-08-11")],
        )
        for members in rejected:
            with self.subTest(rejected=members):
                candidate = stream.published_universe_manifest(self.store(members))
                self.assertIsNone(stream.validate_universe_transition(
                    current, candidate, now_cn=now,
                ))

        added = stream.published_universe_manifest(self.store([
            v1_member("100", "market-100", "Beijing"),
            v1_member("101", "market-101", "Wuhan", event_id="event-101"),
        ]))
        added_change = stream.validate_universe_transition(current, added, now_cn=now)
        self.assertEqual(added_change.added, ("101",))
        self.assertIsNone(added_change.format_transition)

        removed = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", "Wuhan"),
        ]))
        self.assertIsNone(stream.validate_universe_transition(
            current, removed, now_cn=now,
        ))

        mixed = stream.published_universe_manifest(self.store([
            v1_member("101", "market-101", "Wuhan"),
        ]))
        two_legacy_hash = self.store([
            legacy_member("100", "market-100", "Beijing"),
            legacy_member("102", "market-102", "Shanghai"),
        ])
        self.accepted(two_legacy_hash, "2026-08-10T00:01:00+00:00")
        two_current = stream.published_universe_manifest(two_legacy_hash)
        self.assertIsNone(stream.validate_universe_transition(
            two_current, mixed, now_cn=now,
        ))

    async def test_format_upgrade_audits_before_apply_without_websocket_operations(self):
        legacy_hash = self.store([legacy_member("100", "market-100", "Beijing")])
        self.accepted(legacy_hash, "2026-08-10T00:00:00+00:00", "connected")
        current = stream.published_universe_manifest(legacy_hash)
        candidate_hash = self.store([v1_member("100", "market-100", "Beijing")])
        candidate = stream.published_universe_manifest(candidate_hash)
        order = []
        writer = Mock()
        writer.submit_connection_event.side_effect = (
            lambda *args, **kwargs: order.append("audit") or True
        )
        state = self.state_for(current, writer=writer)
        state.hub.quotes["100"] = {"token_id": "100", "best_bid": 0.4}
        original_apply = state.apply_universe

        def tracked_apply(manifest):
            order.append("apply")
            original_apply(manifest)

        socket = _Socket()
        with patch.object(state, "apply_universe", side_effect=tracked_apply):
            change = await stream.apply_manifest_candidate(
                socket, state, candidate,
                now_cn=datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ),
            )

        self.assertEqual(order, ["audit", "apply"])
        self.assertEqual(socket.sent, [])
        self.assertEqual(change.format_transition, "legacy_to_v1")
        self.assertEqual(state.universe_hash, candidate_hash)
        self.assertEqual(state.hub.quotes["100"]["best_bid"], 0.4)
        args, kwargs = writer.submit_connection_event.call_args
        self.assertEqual(args[0], "universe_changed")
        self.assertIn("legacy_to_v1", args[1])
        self.assertEqual(kwargs["universe_hash"], candidate_hash)
        self.assertEqual(kwargs["token_count"], 1)
        self.assertEqual(kwargs["added"], [])
        self.assertEqual(kwargs["removed"], [])

    async def test_format_upgrade_audit_failure_keeps_legacy_without_reconnect(self):
        legacy_hash = self.store([legacy_member("100", "market-100", "Beijing")])
        self.accepted(legacy_hash, "2026-08-10T00:00:00+00:00", "connected")
        current = stream.published_universe_manifest(legacy_hash)
        candidate = stream.published_universe_manifest(
            self.store([v1_member("100", "market-100", "Beijing")])
        )
        for outcome in (False, RuntimeError("audit unavailable")):
            with self.subTest(outcome=type(outcome).__name__):
                writer = Mock()
                if isinstance(outcome, Exception):
                    writer.submit_connection_event.side_effect = outcome
                else:
                    writer.submit_connection_event.return_value = outcome
                state = self.state_for(current, writer=writer)
                state.hub.quotes["100"] = {"token_id": "100", "best_bid": 0.4}
                before = self.local_universe_snapshot(state)
                socket = _Socket()

                result = await stream.apply_manifest_candidate(
                    socket, state, candidate,
                    now_cn=datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ),
                )

                self.assertIsNone(result)
                self.assertEqual(socket.sent, [])
                self.assertEqual(self.local_universe_snapshot(state), before)
                writer.submit_connection_event.assert_called_once()

    async def test_same_asset_v1_to_adjacent_legacy_rollback_is_audited_then_idempotent(self):
        legacy_hash = self.store([legacy_member("100", "market-100", "Beijing")])
        current_hash = self.store([v1_member("100", "market-100", "Beijing")])
        self.accepted(legacy_hash, "2026-08-10T01:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T01:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        order = []
        writer = Mock()

        def accept_rollback(*args, **kwargs):
            order.append("audit")
            self.accepted(
                kwargs["universe_hash"], "2026-08-10T01:02:00+00:00",
                "universe_rollback",
            )
            return True

        writer.submit_connection_event.side_effect = accept_rollback
        original_apply = state.apply_universe

        def tracked_apply(manifest):
            order.append("apply")
            original_apply(manifest)

        socket = _Socket()
        with patch.object(state, "apply_universe", side_effect=tracked_apply):
            change = await stream.apply_explicit_rollback(
                socket, state, writer,
                expected_current_hash=current_hash,
                target_previous_hash=legacy_hash,
            )

        self.assertEqual(order, ["audit", "apply"])
        self.assertEqual(socket.sent, [])
        self.assertEqual(change.format_transition, "v1_to_legacy_rollback")
        self.assertEqual(state.universe_hash, legacy_hash)
        args, kwargs = writer.submit_connection_event.call_args
        self.assertEqual(args[0], "universe_rollback")
        self.assertIn("v1_to_legacy_rollback", args[1])
        self.assertEqual(kwargs["added"], [])
        self.assertEqual(kwargs["removed"], [])

        repeated = await stream.apply_explicit_rollback(
            socket, state, writer,
            expected_current_hash=current_hash,
            target_previous_hash=legacy_hash,
        )
        self.assertIsNotNone(repeated)
        self.assertEqual(socket.sent, [])
        self.assertEqual(writer.submit_connection_event.call_count, 1)

    async def test_same_asset_rollback_audit_failure_keeps_v1_without_reconnect(self):
        legacy_hash = self.store([legacy_member("100", "market-100", "Beijing")])
        current_hash = self.store([v1_member("100", "market-100", "Beijing")])
        self.accepted(legacy_hash, "2026-08-10T02:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T02:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        for outcome in (False, RuntimeError("audit unavailable")):
            with self.subTest(outcome=type(outcome).__name__):
                writer = Mock()
                if isinstance(outcome, Exception):
                    writer.submit_connection_event.side_effect = outcome
                else:
                    writer.submit_connection_event.return_value = outcome
                state = self.state_for(current)
                before = self.local_universe_snapshot(state)
                socket = _Socket()

                result = await stream.apply_explicit_rollback(
                    socket, state, writer,
                    expected_current_hash=current_hash,
                    target_previous_hash=legacy_hash,
                )

                self.assertIsNone(result)
                self.assertEqual(socket.sent, [])
                self.assertEqual(self.local_universe_snapshot(state), before)
                writer.submit_connection_event.assert_called_once()

    def test_same_asset_rollback_rejects_changed_legacy_fact(self):
        current_hash = self.store([v1_member("100", "market-100", "Beijing")])
        self.accepted(current_hash, "2026-08-10T03:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        cases = (
            [legacy_member("100", "market-remap", "Beijing")],
            [legacy_member("100", "market-100", "Shanghai")],
            [legacy_member("100", "market-100", "Beijing", target_date="2026-08-11")],
        )
        for index, members in enumerate(cases):
            with self.subTest(members=members):
                legacy_hash = self.store(members)
                self.accepted(
                    legacy_hash, f"2026-08-10T03:0{index + 2}:00+00:00",
                    "universe_rollback",
                )
                self.accepted(current_hash, f"2026-08-10T03:1{index}:00+00:00")
                self.assertIsNone(stream.plan_explicit_rollback(
                    state,
                    expected_current_hash=current_hash,
                    target_previous_hash=legacy_hash,
                ))

    async def test_metadata_only_v1_update_sends_no_asset_operation(self):
        current_hash = self.store([v1_member(source_scan_id="scan-1")])
        self.accepted(current_hash, "2026-08-10T00:00:00+00:00", "connected")
        current = stream.published_universe_manifest(current_hash)
        next_hash = self.store([v1_member(source_scan_id="scan-2")])
        candidate = stream.published_universe_manifest(next_hash)
        state = self.state_for(current)
        socket = _Socket()
        change = await stream.apply_manifest_candidate(
            socket, state, candidate,
            now_cn=datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ),
        )
        self.assertTrue(change.metadata_only)
        self.assertEqual(socket.sent, [])
        self.assertEqual(state.universe_hash, next_hash)

    async def test_explicit_rollback_requires_adjacent_hashes_and_is_pinned(self):
        historical_hash = self.store([v1_member("099", "market-099")])
        old_hash = self.store([legacy_member()])
        current_hash = self.store([v1_member("100", "market-100"), v1_member("101", "market-101")])
        unrelated_hash = self.store([v1_member("200", "market-200")])
        self.accepted(historical_hash, "2026-08-09T23:59:00+00:00", "connected")
        self.accepted(old_hash, "2026-08-10T00:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T00:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        plan = stream.plan_explicit_rollback(
            state, expected_current_hash=current_hash, target_previous_hash=old_hash,
        )
        self.assertEqual(plan.target.token_hash, old_hash)
        self.assertEqual(plan.pinned_hash, old_hash)
        self.assertNotEqual(plan.target.token_hash, unrelated_hash)
        for expected, target in (
            ("0" * 64, old_hash), (current_hash, unrelated_hash),
            (current_hash, historical_hash),
        ):
            with self.subTest(expected=expected, target=target):
                self.assertIsNone(stream.plan_explicit_rollback(
                    state, expected_current_hash=expected, target_previous_hash=target,
                ))

    async def test_rollback_send_failure_does_not_apply_or_record(self):
        previous_hash = self.store([v1_member("100", "market-100")])
        current_hash = self.store([v1_member("100", "market-100"), v1_member("101", "market-101")])
        self.accepted(previous_hash, "2026-08-10T00:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T00:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        writer = Mock()
        with self.assertRaises(ConnectionError):
            await stream.apply_explicit_rollback(
                _FailingSocket(), state, writer,
                expected_current_hash=current_hash,
                target_previous_hash=previous_hash,
            )
        self.assertEqual(state.universe_hash, current_hash)
        writer.submit_connection_event.assert_not_called()

    async def test_rollback_records_after_sends_then_applies(self):
        previous_hash = self.store([v1_member("100", "market-100")])
        current_hash = self.store([v1_member("100", "market-100"), v1_member("101", "market-101")])
        self.accepted(previous_hash, "2026-08-10T00:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T00:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        writer = Mock()
        writer.submit_connection_event.return_value = True
        socket = _Socket()
        change = await stream.apply_explicit_rollback(
            socket, state, writer,
            expected_current_hash=current_hash,
            target_previous_hash=previous_hash,
        )
        self.assertEqual(change.removed, ("101",))
        self.assertEqual(json.loads(socket.sent[0])["operation"], "unsubscribe")
        self.assertEqual(state.universe_hash, previous_hash)
        writer.submit_connection_event.assert_called_once()
        args, kwargs = writer.submit_connection_event.call_args
        self.assertEqual(args[0], "universe_rollback")
        self.assertIn(current_hash, args[1])
        self.assertIn(previous_hash, args[1])

    async def test_rollback_mixed_second_send_failure_requires_reconnect(self):
        previous_hash = self.store([
            v1_member("100", "market-100"),
            v1_member("102", "market-102"),
        ])
        current_hash = self.store([
            v1_member("100", "market-100"),
            v1_member("101", "market-101"),
        ])
        self.accepted(previous_hash, "2026-08-10T00:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T00:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        before = self.local_universe_snapshot(state)
        writer = Mock()
        writer.submit_connection_event.return_value = True
        socket = _NthFailSocket(2)

        with self.assertRaises(stream.UniverseReconnectRequired) as raised:
            await stream.apply_explicit_rollback(
                socket, state, writer,
                expected_current_hash=current_hash,
                target_previous_hash=previous_hash,
            )

        self.assertEqual(len(socket.sent), 1)
        self.assertEqual(raised.exception.recovery_hash, current_hash)
        self.assertEqual(
            raised.exception.recovery_manifest.token_hash, current_hash,
        )
        self.assertEqual(self.local_universe_snapshot(state), before)
        writer.submit_connection_event.assert_not_called()
        self.assertEqual(stream.accepted_universe_hash_chain()[:2], [current_hash, previous_hash])

    async def test_rollback_audit_rejection_after_remote_change_requires_reconnect(self):
        cases = (
            (
                [v1_member("100", "market-100"), v1_member("102", "market-102")],
                [v1_member("100", "market-100")],
                ["subscribe"],
            ),
            (
                [v1_member("100", "market-100")],
                [v1_member("100", "market-100"), v1_member("101", "market-101")],
                ["unsubscribe"],
            ),
            (
                [v1_member("100", "market-100"), v1_member("102", "market-102")],
                [v1_member("100", "market-100"), v1_member("101", "market-101")],
                ["subscribe", "unsubscribe"],
            ),
        )
        for index, (previous_members, current_members, operations) in enumerate(cases):
            with self.subTest(operations=operations):
                previous_hash = self.store(previous_members)
                current_hash = self.store(current_members)
                self.accepted(
                    previous_hash, f"2026-08-10T01:{index}0:00+00:00", "connected",
                )
                self.accepted(
                    current_hash, f"2026-08-10T01:{index}1:00+00:00",
                )
                current = stream.published_universe_manifest(current_hash)
                state = self.state_for(current)
                before = self.local_universe_snapshot(state)
                writer = Mock()
                writer.submit_connection_event.return_value = False
                socket = _Socket()

                with self.assertRaises(stream.UniverseReconnectRequired) as raised:
                    await stream.apply_explicit_rollback(
                        socket, state, writer,
                        expected_current_hash=current_hash,
                        target_previous_hash=previous_hash,
                    )

                self.assertEqual(raised.exception.recovery_hash, current_hash)
                self.assertEqual(
                    [json.loads(value)["operation"] for value in socket.sent],
                    operations,
                )
                self.assertEqual(self.local_universe_snapshot(state), before)
                writer.submit_connection_event.assert_called_once()
                self.assertEqual(stream.accepted_universe_hash_chain()[0], current_hash)

    async def test_rollback_success_order_remains_send_then_audit_then_apply(self):
        previous_hash = self.store([v1_member("100", "market-100")])
        current_hash = self.store([
            v1_member("100", "market-100"), v1_member("101", "market-101"),
        ])
        self.accepted(previous_hash, "2026-08-10T02:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T02:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        order = []
        socket = _OrderedSocket(order)
        writer = Mock()
        writer.submit_connection_event.side_effect = lambda *args, **kwargs: order.append("audit") or True
        original_apply = state.apply_universe

        def tracked_apply(manifest):
            order.append("apply")
            original_apply(manifest)

        with patch.object(state, "apply_universe", side_effect=tracked_apply):
            change = await stream.apply_explicit_rollback(
                socket, state, writer,
                expected_current_hash=current_hash,
                target_previous_hash=previous_hash,
            )

        self.assertEqual(order, ["unsubscribe", "audit", "apply"])
        self.assertEqual(change.manifest.token_hash, previous_hash)
        self.assertEqual(state.universe_hash, previous_hash)

    async def test_dynamic_audit_rejection_never_applies_metadata_only(self):
        current_hash = self.store([v1_member(source_scan_id="scan-1")])
        current = stream.published_universe_manifest(current_hash)
        candidate_hash = self.store([v1_member(source_scan_id="scan-2")])
        candidate = stream.published_universe_manifest(candidate_hash)
        writer = Mock()
        writer.submit_connection_event.return_value = False
        state = self.state_for(current, writer=writer)
        before = self.local_universe_snapshot(state)
        socket = _Socket()

        with patch.object(stream, "published_universe_manifest", return_value=candidate):
            change = await stream.apply_subscription_update(
                socket, state,
                now_cn=datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ),
                monotonic_now=20,
            )

        self.assertIsNone(change)
        self.assertEqual(socket.sent, [])
        self.assertEqual(self.local_universe_snapshot(state), before)
        writer.submit_connection_event.assert_called_once()

    async def test_dynamic_audit_rejection_after_asset_send_requires_reconnect(self):
        cases = (
            (
                [v1_member("100", "market-100")],
                [v1_member("100", "market-100"), v1_member("101", "market-101")],
                datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ),
                "subscribe",
            ),
            (
                [
                    v1_member("100", "market-100", target_date="2026-08-09"),
                    v1_member("101", "market-101", target_date="2026-08-10"),
                ],
                [v1_member("101", "market-101", target_date="2026-08-10")],
                datetime(2026, 8, 10, 1, tzinfo=stream.CHINA_TZ),
                "unsubscribe",
            ),
        )
        for current_members, candidate_members, now_cn, operation in cases:
            with self.subTest(operation=operation):
                current_hash = self.store(current_members)
                current = stream.published_universe_manifest(current_hash)
                candidate_hash = self.store(candidate_members)
                candidate = stream.published_universe_manifest(candidate_hash)
                writer = Mock()
                writer.submit_connection_event.return_value = False
                state = self.state_for(current, writer=writer)
                if operation == "unsubscribe":
                    state.pending_shrink_hash = candidate_hash
                    state.pending_shrink_count = 1
                before = self.local_universe_snapshot(state)
                socket = _Socket()

                with patch.object(stream, "published_universe_manifest", return_value=candidate):
                    with self.assertRaises(stream.UniverseReconnectRequired) as raised:
                        await stream.apply_subscription_update(
                            socket, state, now_cn=now_cn, monotonic_now=20,
                        )

                self.assertEqual(raised.exception.recovery_hash, current_hash)
                self.assertEqual(json.loads(socket.sent[0])["operation"], operation)
                self.assertEqual(self.local_universe_snapshot(state), before)
                writer.submit_connection_event.assert_called_once()

    async def test_dynamic_audit_acceptance_applies_and_records_exact_change(self):
        current_hash = self.store([v1_member(source_scan_id="scan-1")])
        current = stream.published_universe_manifest(current_hash)
        candidate_hash = self.store([v1_member(source_scan_id="scan-2")])
        candidate = stream.published_universe_manifest(candidate_hash)
        writer = Mock()
        writer.submit_connection_event.return_value = True
        state = self.state_for(current, writer=writer)
        socket = _Socket()

        with patch.object(stream, "published_universe_manifest", return_value=candidate):
            change = await stream.apply_subscription_update(
                socket, state,
                now_cn=datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ),
                monotonic_now=20,
            )

        self.assertTrue(change.metadata_only)
        self.assertEqual(socket.sent, [])
        self.assertEqual(state.universe_hash, candidate_hash)
        args, kwargs = writer.submit_connection_event.call_args
        self.assertEqual(args[:2], (
            "universe_changed", "dynamic websocket subscription updated",
        ))
        self.assertEqual(kwargs["universe_hash"], candidate_hash)
        self.assertEqual(kwargs["token_count"], 1)
        self.assertEqual(kwargs["added"], [])
        self.assertEqual(kwargs["removed"], [])

    async def test_idempotent_rollback_requires_proven_adjacent_reverse_edge(self):
        previous_hash = self.store([v1_member("100", "market-100")])
        current_hash = self.store([
            v1_member("100", "market-100"), v1_member("101", "market-101"),
        ])
        historical_hash = self.store([v1_member("099", "market-099")])
        self.accepted(historical_hash, "2026-08-10T02:59:00+00:00", "connected")
        self.accepted(previous_hash, "2026-08-10T03:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T03:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        writer = Mock()

        def accept_rollback(*args, **kwargs):
            self.accepted(
                kwargs["universe_hash"], "2026-08-10T03:02:00+00:00",
                "universe_rollback",
            )
            return True

        writer.submit_connection_event.side_effect = accept_rollback
        socket = _Socket()
        await stream.apply_explicit_rollback(
            socket, state, writer,
            expected_current_hash=current_hash,
            target_previous_hash=previous_hash,
        )
        sent_count = len(socket.sent)
        audit_count = writer.submit_connection_event.call_count

        repeated = await stream.apply_explicit_rollback(
            socket, state, writer,
            expected_current_hash=current_hash,
            target_previous_hash=previous_hash,
        )

        self.assertIsNotNone(repeated)
        self.assertEqual(len(socket.sent), sent_count)
        self.assertEqual(writer.submit_connection_event.call_count, audit_count)
        self.assertIsNone(stream.plan_explicit_rollback(
            state,
            expected_current_hash="f" * 64,
            target_previous_hash=previous_hash,
        ))
        self.assertIsNone(stream.plan_explicit_rollback(
            state,
            expected_current_hash=historical_hash,
            target_previous_hash=previous_hash,
        ))

    async def test_idempotent_rollback_rejects_missing_chain_and_unparseable_target(self):
        target_hash = self.store([v1_member("100", "market-100")])
        target = stream.published_universe_manifest(target_hash)
        state = self.state_for(target)
        expected_hash = "a" * 64

        self.assertIsNone(stream.plan_explicit_rollback(
            state,
            expected_current_hash=expected_hash,
            target_previous_hash=target_hash,
        ))

        self.accepted(expected_hash, "2026-08-10T04:00:00+00:00", "connected")
        self.accepted(target_hash, "2026-08-10T04:01:00+00:00", "universe_rollback")
        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute(
                "DELETE FROM market_universe_publications WHERE token_hash=?",
                (target_hash,),
            )
        self.assertIsNone(stream.plan_explicit_rollback(
            state,
            expected_current_hash=expected_hash,
            target_previous_hash=target_hash,
        ))

    async def test_pure_add_audit_rejection_pins_prechange_manifest_not_latest(self):
        accepted_hash = self.store([v1_member("100", "market-100")])
        accepted = stream.published_universe_manifest(accepted_hash)
        latest_hash = self.store([
            v1_member("100", "market-100"), v1_member("101", "market-101"),
        ])
        latest = stream.published_universe_manifest(latest_hash)
        writer = Mock()
        writer.submit_connection_event.return_value = False
        state = self.state_for(accepted, writer=writer)
        before = self.local_universe_snapshot(state)

        with patch.object(stream, "published_universe_manifest", return_value=latest):
            with self.assertRaises(stream.UniverseReconnectRequired) as raised:
                await stream.apply_subscription_update(
                    _Socket(), state,
                    now_cn=datetime(2026, 8, 10, 12, tzinfo=stream.CHINA_TZ),
                    monotonic_now=20,
                )

        self.assertEqual(raised.exception.recovery_hash, accepted_hash)
        self.assertEqual(self.local_universe_snapshot(state), before)
        pin = stream.ReconnectRecoveryPin()
        pin.capture(raised.exception)
        progress = Mock()
        with patch.object(
            stream, "read_reconnect_manifest", return_value=latest,
        ) as normal_read:
            selected = await pin.select(stream.LiveStateHub(), progress)
        self.assertEqual(selected.token_hash, accepted_hash)
        normal_read.assert_not_called()

    async def test_mixed_rollback_partial_failure_pins_current_not_target_or_latest(self):
        target_hash = self.store([
            v1_member("100", "market-100"), v1_member("102", "market-102"),
        ])
        current_hash = self.store([
            v1_member("100", "market-100"), v1_member("101", "market-101"),
        ])
        latest_hash = self.store([v1_member("200", "market-200")])
        self.accepted(target_hash, "2026-08-10T05:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T05:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        latest = stream.published_universe_manifest(latest_hash)
        state = self.state_for(current)

        with self.assertRaises(stream.UniverseReconnectRequired) as raised:
            await stream.apply_explicit_rollback(
                _NthFailSocket(2), state, Mock(),
                expected_current_hash=current_hash,
                target_previous_hash=target_hash,
            )

        self.assertEqual(raised.exception.recovery_hash, current_hash)
        self.assertNotEqual(raised.exception.recovery_hash, target_hash)
        self.assertNotEqual(raised.exception.recovery_hash, latest_hash)
        pin = stream.ReconnectRecoveryPin()
        pin.capture(raised.exception)
        with patch.object(
            stream, "read_reconnect_manifest", return_value=latest,
        ) as normal_read:
            selected = await pin.select(stream.LiveStateHub(), Mock())
        self.assertEqual(selected.token_hash, current_hash)
        normal_read.assert_not_called()

    async def test_rollback_audit_rejection_pins_current_not_rollback_target(self):
        target_hash = self.store([v1_member("100", "market-100")])
        current_hash = self.store([
            v1_member("100", "market-100"), v1_member("101", "market-101"),
        ])
        self.accepted(target_hash, "2026-08-10T06:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T06:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        writer = Mock()
        writer.submit_connection_event.return_value = False

        with self.assertRaises(stream.UniverseReconnectRequired) as raised:
            await stream.apply_explicit_rollback(
                _Socket(), state, writer,
                expected_current_hash=current_hash,
                target_previous_hash=target_hash,
            )

        self.assertEqual(raised.exception.recovery_hash, current_hash)
        self.assertEqual(state.universe_hash, current_hash)
        self.assertNotEqual(raised.exception.recovery_hash, target_hash)

    async def test_pinned_connected_audit_rejection_retries_same_manifest(self):
        accepted_hash = self.store([v1_member("100", "market-100")])
        accepted = stream.published_universe_manifest(accepted_hash)
        latest_hash = self.store([
            v1_member("100", "market-100"), v1_member("101", "market-101"),
        ])
        latest = stream.published_universe_manifest(latest_hash)
        pin = stream.ReconnectRecoveryPin()
        pin.capture(stream.UniverseReconnectRequired(
            "fixture", recovery_manifest=accepted,
        ))
        writer = Mock()
        writer.submit_connection_event.return_value = False

        with self.assertRaises(stream.UniverseReconnectRequired) as raised:
            pin.confirm_connected(writer, accepted)

        self.assertTrue(pin.active)
        self.assertEqual(raised.exception.recovery_hash, accepted_hash)
        with patch.object(
            stream, "read_reconnect_manifest", return_value=latest,
        ) as normal_read:
            selected = await pin.select(stream.LiveStateHub(), Mock())
        self.assertEqual(selected.token_hash, accepted_hash)
        normal_read.assert_not_called()

    async def test_pinned_connected_success_clears_pin_before_dynamic_recheck(self):
        accepted_hash = self.store([v1_member("100", "market-100")])
        accepted = stream.published_universe_manifest(accepted_hash)
        latest_hash = self.store([
            v1_member("100", "market-100"), v1_member("101", "market-101"),
        ])
        latest = stream.published_universe_manifest(latest_hash)
        pin = stream.ReconnectRecoveryPin()
        pin.capture(stream.UniverseReconnectRequired(
            "fixture", recovery_manifest=accepted,
        ))
        writer = Mock()
        writer.submit_connection_event.return_value = True

        self.assertTrue(pin.confirm_connected(writer, accepted))
        self.assertFalse(pin.active)
        with patch.object(
            stream, "read_reconnect_manifest", return_value=latest,
        ) as normal_read:
            selected = await pin.select(stream.LiveStateHub(), Mock())
        self.assertEqual(selected.token_hash, latest_hash)
        normal_read.assert_awaited_once()

    async def test_metadata_only_rollback_audit_rejection_does_not_reconnect(self):
        previous_hash = self.store([v1_member(source_scan_id="scan-1")])
        current_hash = self.store([v1_member(source_scan_id="scan-2")])
        self.accepted(previous_hash, "2026-08-10T07:00:00+00:00", "connected")
        self.accepted(current_hash, "2026-08-10T07:01:00+00:00")
        current = stream.published_universe_manifest(current_hash)
        state = self.state_for(current)
        before = self.local_universe_snapshot(state)
        writer = Mock()
        writer.submit_connection_event.return_value = False
        socket = _Socket()

        result = await stream.apply_explicit_rollback(
            socket, state, writer,
            expected_current_hash=current_hash,
            target_previous_hash=previous_hash,
        )

        self.assertIsNone(result)
        self.assertEqual(socket.sent, [])
        self.assertEqual(self.local_universe_snapshot(state), before)

    def test_reconnect_exception_requires_revalidated_prechange_evidence(self):
        accepted_hash = self.store([v1_member("100", "market-100")])
        accepted = stream.published_universe_manifest(accepted_hash)
        error = stream.UniverseReconnectRequired(
            "fixture", recovery_manifest=accepted,
        )
        self.assertEqual(error.recovery_hash, accepted_hash)
        self.assertEqual(error.recovery_manifest.token_hash, accepted_hash)

        malformed = stream.UniverseManifest(
            ("100",), {"100": "market-100"}, "bad-hash",
            {"100": "2026-08-10"}, format=stream.V1_SCHEMA,
        )
        with self.assertRaises(ValueError):
            stream.UniverseReconnectRequired(
                "fixture", recovery_manifest=malformed,
            )


class _Socket:
    def __init__(self):
        self.sent = []

    async def send(self, value):
        self.sent.append(value)


class _OrderedSocket(_Socket):
    def __init__(self, order):
        super().__init__()
        self.order = order

    async def send(self, value):
        await super().send(value)
        self.order.append(json.loads(value)["operation"])


class _NthFailSocket(_Socket):
    def __init__(self, fail_at):
        super().__init__()
        self.fail_at = fail_at

    async def send(self, value):
        if len(self.sent) + 1 == self.fail_at:
            raise ConnectionError("fixture send failed")
        await super().send(value)


class _FailingSocket(_Socket):
    async def send(self, value):
        raise ConnectionError("fixture send failed")


if __name__ == "__main__":
    unittest.main()
