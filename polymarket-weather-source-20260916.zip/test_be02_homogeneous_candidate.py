from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

import collector


SCANNED_AT = "2026-08-09T15:00:00+00:00"
SCAN_ID = "offline-scan-20260809-150000"
CITY_MATRIX = {
    "Beijing": ("formal", "ZBAA"),
    "Shanghai": ("formal", "ZSPD"),
    "Chengdu": ("formal", "ZUUU"),
    "Guangzhou": ("formal", "ZGGG"),
    "Shenzhen": ("research_only", "ZGSZ"),
    "Wuhan": ("research_only", "ZHHH"),
    "Chongqing": ("research_only", "ZUCK"),
    "Zhengzhou": ("research_only", "ZHCC"),
}


def _source(city: str, station: str) -> str:
    return f"https://www.wunderground.com/weather/cn/{city.lower()}/{station}"


def _record(city: str = "Wuhan", *, market_id: str = "market-1",
            tokens: list[str] | None = None) -> dict:
    scope, station = CITY_MATRIX[city]
    raw_tokens = tokens or ["1001", "1002"]
    event = {
        "id": f"event-{city.lower()}",
        "title": f"Highest temperature in {city} on August 9",
        "resolutionSource": _source(city, station),
        "active": True,
        "closed": False,
        "_query_city": city,
        "_query_target_date": "2026-08-09",
    }
    market = {
        "id": market_id,
        "question": f"Will the highest temperature in {city} be 30 C on August 9?",
        "resolutionSource": _source(city, station),
        "outcomes": json.dumps(["Yes", "No"]),
        "clobTokenIds": json.dumps(raw_tokens),
        "groupItemTitle": "30 C",
        "active": True,
        "closed": False,
    }
    result = collector.attribute_research_market(event, market, scan_id=SCAN_ID, scanned_at=SCANNED_AT)
    assert result["attribution_status"] == "verified"
    return result


class HomogeneousV1CandidateTests(unittest.TestCase):
    def test_legacy_accepted_loads_without_v1_synthesis_and_diffs_pure_add(self) -> None:
        legacy = [{"token_id": "1001", "market_id": "old", "city": "Wuhan", "target_date": "2026-08-09"}]
        raw = json.dumps(legacy, separators=(",", ":"), sort_keys=True)
        token_hash = hashlib.sha256(raw.encode()).hexdigest()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "legacy.sqlite3"
            db = sqlite3.connect(path)
            try:
                db.execute("CREATE TABLE market_universe_publications (publication_id TEXT, published_at TEXT, token_hash TEXT, token_count INTEGER, members_json TEXT)")
                db.execute("INSERT INTO market_universe_publications VALUES (?,?,?,?,?)", ("legacy", SCANNED_AT, token_hash, 1, raw))
                db.commit()
            finally:
                db.close()
            accepted = collector.load_accepted_research_universe_members_read_only(path, expected_accepted_hash=token_hash)
        self.assertEqual(getattr(accepted, "accepted_format", None), "legacy")
        self.assertEqual(accepted[0], legacy[0])
        candidate = collector.build_research_universe_candidate([
            _record(market_id="old", tokens=["1001", "1002"]),
            _record(market_id="new", tokens=["5001", "5002"]),
        ], accepted_members=accepted)
        self.assertTrue(candidate["diff"]["pure_add"])

    def test_rejects_legacy_partial_and_unknown_schema_members(self) -> None:
        record = _record()
        cases = (
            {"token_id": "1001", "market_id": "m", "city": "Wuhan", "target_date": "2026-08-09"},
            {key: value for key, value in record.items() if key != "schema"},
            {**record, "schema": "research_market_attribution.v2"},
        )
        for invalid in cases:
            with self.subTest(invalid=invalid.get("schema", "legacy")):
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.build_research_universe_candidate([record, invalid])

    def test_rejects_every_city_scope_station_mismatch(self) -> None:
        for city, (scope, station) in CITY_MATRIX.items():
            record = _record(city, market_id=f"market-{city}", tokens=[str(10000 + len(city)), str(20000 + len(city))])
            for field, bad_value in (("city", "Wuhan" if city != "Wuhan" else "Beijing"),
                                     ("city_scope", "formal" if scope != "formal" else "research_only"),
                                     ("station", "ZBAA" if station != "ZBAA" else "ZHHH")):
                with self.subTest(city=city, field=field):
                    with self.assertRaises(collector.MarketScanIncomplete):
                        collector.build_research_universe_candidate([{**record, field: bad_value}])

    def test_rejects_scan_timestamp_and_query_binding_mismatch(self) -> None:
        first = _record(market_id="market-1", tokens=["1001", "1002"])
        second = _record(market_id="market-2", tokens=["1003", "1004"])
        for field, value in (("scan_id", "other-scan"), ("scanned_at", "2026-08-09T15:01:00+00:00"),
                             ("scanned_at", "2026-08-09T15:00:00"), ("_query_city", "Beijing"),
                             ("_query_target_date", "2026-08-10")):
            with self.subTest(field=field):
                records = [first, {**second, field: value}]
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.build_research_universe_candidate(records)

    def test_rejects_outcome_binding_remaps_and_all_cross_outcome_conflicts(self) -> None:
        first = _record(market_id="market-1", tokens=["1001", "1002"])
        for name, tokens in (("yes_yes", ["1001", "1003"]), ("yes_no", ["1002", "1003"]),
                             ("no_yes", ["1003", "1001"]), ("no_no", ["1003", "1002"])):
            with self.subTest(name=name):
                with self.assertRaises(collector.MarketScanIncomplete):
                    collector.build_research_universe_candidate([
                        first, _record(market_id=f"market-{name}", tokens=tokens),
                    ])
        changed = {**_record(market_id="market-3", tokens=["1003", "1004"]), "token_id": "1004"}
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.build_research_universe_candidate([first, changed])
        remapped = {**first, "market_id": "market-4"}
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.build_research_universe_candidate([first, remapped])

    def test_preserves_unknown_facts_in_members_and_hash(self) -> None:
        second = _record(market_id="market-2", tokens=["1003", "1004"])
        first = {**_record(market_id="market-1", tokens=["1001", "1002"]), "future_fact": {"version": 1}}
        candidate = collector.build_research_universe_candidate([second, first])
        self.assertEqual([member["token_id"] for member in candidate["members"]], ["1001", "1003"])
        self.assertEqual(candidate["members"][0]["future_fact"], {"version": 1})
        canonical = json.dumps(candidate["members"], ensure_ascii=False, separators=(",", ":"), sort_keys=True)
        self.assertEqual(candidate["token_hash"], hashlib.sha256(canonical.encode()).hexdigest())
        self.assertEqual(candidate["token_count"], len(candidate["members"]))

    def test_distributions_and_diff_are_deterministic(self) -> None:
        old = collector.build_research_universe_candidate([_record("Beijing", market_id="old-market", tokens=["9001", "9002"])])
        current = collector.build_research_universe_candidate([
            _record("Wuhan", market_id="new-market", tokens=["1001", "1002"]),
            _record("Beijing", market_id="new-market-for-old-token", tokens=["9001", "9003"]),
        ], accepted_members=old["members"])
        self.assertEqual(current["distributions"], {
            "cities": {"Beijing": 1, "Wuhan": 1},
            "target_dates": {"2026-08-09": 2},
            "city_scopes": {"formal": 1, "research_only": 1},
            "stations": {"ZBAA": 1, "ZHHH": 1},
        })
        self.assertEqual(current["diff"]["added"], ("1001",))
        self.assertEqual(current["diff"]["removed"], ())
        self.assertEqual(current["diff"]["remapped"], ("9001",))
        self.assertFalse(current["diff"]["pure_add"])

    def test_pure_add_and_empty_complete_scan_fail_closed(self) -> None:
        old = collector.build_research_universe_candidate([_record(market_id="old", tokens=["1001", "1002"])])
        pure_add = collector.build_research_universe_candidate([
            _record(market_id="old", tokens=["1001", "1002"]),
            _record(market_id="new", tokens=["1003", "1004"]),
        ], accepted_members=old["members"])
        self.assertTrue(pure_add["diff"]["pure_add"])
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "candidate_empty"):
            collector.build_research_universe_candidate([])

    def test_removed_diff_and_read_only_accepted_manifest_loader(self) -> None:
        accepted = collector.build_research_universe_candidate([
            _record(market_id="old", tokens=["1001", "1002"]),
            _record(market_id="removed", tokens=["1003", "1004"]),
        ])
        candidate = collector.build_research_universe_candidate([
            _record(market_id="old", tokens=["1001", "1002"]),
        ], accepted_members=accepted["members"])
        self.assertEqual(candidate["diff"], {
            "added": (), "removed": ("1003",), "remapped": (), "pure_add": False,
        })
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "accepted.sqlite3"
            db = sqlite3.connect(path)
            try:
                db.execute(
                    """CREATE TABLE market_universe_publications (
                    publication_id TEXT, published_at TEXT, token_hash TEXT,
                    token_count INTEGER, members_json TEXT)"""
                )
                db.execute(
                    "INSERT INTO market_universe_publications VALUES (?,?,?,?,?)",
                    ("fixture", SCANNED_AT, accepted["token_hash"], accepted["token_count"],
                     json.dumps(accepted["members"])),
                )
                db.commit()
            finally:
                db.close()
            loaded = collector.load_accepted_research_universe_members_read_only(
                path, expected_accepted_hash=accepted["token_hash"]
            )
            self.assertEqual(loaded, accepted["members"])

    def test_accepted_loader_binds_exact_hash_and_rejects_latest_or_noncanonical(self) -> None:
        first = collector.build_research_universe_candidate([_record(market_id="old", tokens=["1001", "1002"])])
        latest = collector.build_research_universe_candidate([_record(market_id="new", tokens=["2001", "2002"])])
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "accepted.sqlite3"
            db = sqlite3.connect(path)
            try:
                db.execute("CREATE TABLE market_universe_publications (publication_id TEXT, published_at TEXT, token_hash TEXT, token_count INTEGER, members_json TEXT)")
                for publication, candidate in (("old", first), ("latest", latest)):
                    db.execute("INSERT INTO market_universe_publications VALUES (?,?,?,?,?)", (publication, publication, candidate["token_hash"], candidate["token_count"], json.dumps(candidate["members"])))
                db.commit()
            finally:
                db.close()
            with self.assertRaises(collector.MarketScanIncomplete):
                collector.load_accepted_research_universe_members_read_only(path)
            self.assertEqual(collector.load_accepted_research_universe_members_read_only(path, expected_accepted_hash=first["token_hash"]), first["members"])
            with self.assertRaisesRegex(collector.MarketScanIncomplete, "accepted_manifest_missing"):
                collector.load_accepted_research_universe_members_read_only(path, expected_accepted_hash="0" * 64)

    def test_diff_immutable_changes_and_v1_whitespace_fail_closed(self) -> None:
        accepted = collector.build_research_universe_candidate([_record(market_id="m", tokens=["1001", "1002"])])
        cases = (
            ("market_id", {"market_id": "other"}),
            ("city", {"city": "Beijing", "city_scope": "formal", "station": "ZBAA"}),
            ("city_scope", {"city": "Beijing", "city_scope": "formal", "station": "ZBAA"}),
            ("station", {"city": "Beijing", "city_scope": "formal", "station": "ZBAA"}),
            ("target_date", {"target_date": "2026-08-10"}),
            ("event_id", {"event_id": "other-event"}),
        )
        for field, changes in cases:
            current = {**accepted["members"][0], **changes}
            current["source_scan_id"] = "new-scan"
            extra = {**accepted["members"][0], "token_id": "5001", "market_id": "extra", "source_scan_id": "new-scan"}
            with self.subTest(field=field):
                diff = collector.research_universe_diff([current, extra], accepted["members"])
                self.assertIn("1001", diff["remapped"])
                self.assertFalse(diff["pure_add"])
        with self.assertRaises(collector.MarketScanIncomplete):
            collector.research_universe_diff([{**accepted["members"][0], "outcome": "No"}], accepted["members"])
        record = _record()
        for field in ("schema", "market_id", "event_id", "city", "station", "outcome"):
            with self.subTest(space=field), self.assertRaises(collector.MarketScanIncomplete):
                collector.build_research_universe_candidate([{**record, field: f" {record[field]} "}])
        for bad_scan in (True, 1, [], {}):
            with self.subTest(scan=type(bad_scan).__name__), self.assertRaises(collector.MarketScanIncomplete):
                collector.build_research_universe_candidate([{**record, "scan_id": bad_scan}])
