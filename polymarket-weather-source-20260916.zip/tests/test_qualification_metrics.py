import unittest
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, ROUND_DOWN, getcontext
from zoneinfo import ZoneInfo

from strategy_engine.data.labels import WEATHER_LABEL_POLICY_HASH, WeatherLabel
from strategy_engine.data.records import OBSERVATION_STATION
from strategy_engine.reports.qualification_metrics import m008_weather_mae
from strategy_v8.canonical import hash_v1
from strategy_v8.contracts import City


class M008Tests(unittest.TestCase):
    city = City.SHANGHAI
    city_text = City.SHANGHAI.value

    @staticmethod
    def _hash(value: str) -> str:
        return hash_v1("PWM.M008.TEST.V1", {"value": value})

    def label(self, day: str, final_milli: int, *, first_minutes: int = 0, first_seconds: int = 0, last_minutes: int = 30, last_seconds: int = 0, gap: object = 3600) -> WeatherLabel:
        target = date.fromisoformat(day)
        local_start = datetime.combine(target, time.min, ZoneInfo("Asia/Shanghai"))
        start = local_start.astimezone(timezone.utc)
        end = (local_start + timedelta(days=1)).astimezone(timezone.utc)
        frozen = (local_start + timedelta(days=2)).astimezone(timezone.utc)
        first = start + timedelta(minutes=first_minutes, seconds=first_seconds)
        last = end - timedelta(minutes=last_minutes, seconds=last_seconds)
        observation_ids = (self._hash(f"observation:{day}"),)
        timestamp = lambda value: value.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        payload = {
            "schema_version": "WeatherLabelV1", "city": self.city_text, "target_date": day,
            "station": OBSERVATION_STATION[self.city], "weather_label_policy_hash": WEATHER_LABEL_POLICY_HASH,
            "ordered_observation_normalized_fact_ids": list(observation_ids),
            "first_report_time_utc": timestamp(first), "last_report_time_utc": timestamp(last),
            "maximum_observed_gap_seconds": gap, "gap_reason": None, "coverage_complete": True,
            "final_max_c_milli": final_milli, "freeze_cutoff_utc": timestamp(frozen),
            "committed_at_utc": timestamp(frozen), "label_status": "FROZEN",
        }
        return WeatherLabel(
            city=self.city, target_date=target, station=OBSERVATION_STATION[self.city],
            observation_window_start_utc=timestamp(start), observation_window_end_utc=timestamp(end),
            label_timestamp_utc=timestamp(frozen), final_max_c=Decimal(final_milli) / Decimal(1000),
            first_report_time_utc=payload["first_report_time_utc"], last_report_time_utc=payload["last_report_time_utc"],
            maximum_gap_seconds=gap, observation_fact_ids=observation_ids,
            label_hash=hash_v1("PWM.IIC2.WEATHER_LABEL.V1", payload),
        )

    def sample_payload(self, day: str, values: list[int]) -> dict:
        samples = [
            {
                "sample_ordinal": ordinal, "training_target_date": f"2025-08-{ordinal + 1:02d}",
                "training_day_ref": self._hash(f"training:{ordinal}"), "residual_c_milli": value - 2000,
                "x_c_milli": value, "bucket_id": "B0",
            }
            for ordinal, value in enumerate(values)
        ]
        payload = {
            "schema_version": "RawTemperatureSampleSetV1", "city": self.city_text, "target_date": day,
            "evaluation_event_id": "event-1", "local_second": 8 * 3600,
            "residual_population_hash": self._hash("population"),
            "current_forecast_normalized_fact_id": self._hash("forecast"),
            "current_forecast_high_c_milli": 2000, "current_observation_set_hash": self._hash("observations"),
            "current_observed_max_c_milli": 2000, "bucket_partition_hash": self._hash("partition"), "samples": samples,
        }
        payload["raw_temperature_sample_hash"] = hash_v1("PWM.IIC2.RAW_TEMPERATURE_SAMPLE_SET.V1", payload)
        return payload

    def row(self, day: str, values: list[int], final_milli: int) -> dict:
        sample = self.sample_payload(day, values)
        label = self.label(day, final_milli)
        return {
            "city": self.city_text, "target_date": day, "sample_payload": sample,
            "sample_identity": sample["raw_temperature_sample_hash"], "label": label,
            "label_identity": label.label_hash, "raw_c_milli": list(values),
        }

    def test_exact_milli_and_partial(self):
        rows = [
            self.row("2026-09-01", [1000, 3000], 3000),
            self.row("2026-09-02", [], 1),
            {"city": self.city_text, "target_date": "2026-09-03", "sample_payload": None, "label": None},
        ]
        self.assertEqual(
            m008_weather_mae(self.city_text, rows),
            (Decimal("1.000000000000"), Decimal(1), Decimal("1.000000000000"), 2, "PARTIAL"),
        )

    def test_duplicate_city_date_rejected(self):
        row = self.row("2026-09-01", [1], 1)
        with self.assertRaisesRegex(ValueError, "M008_DUPLICATE_TARGET_DATE"):
            m008_weather_mae(self.city_text, [row, row])

    def test_forged_sample_label_and_raw_mismatch_rejected(self):
        row = self.row("2026-09-01", [1000], 1000)
        row["sample_payload"]["samples"][0]["x_c_milli"] = 1001
        with self.assertRaisesRegex(ValueError, "M008_IDENTITY_INVALID"):
            m008_weather_mae(self.city_text, [row])
        row = self.row("2026-09-01", [1000], 1000)
        row["label_identity"] = self._hash("forged")
        with self.assertRaisesRegex(ValueError, "M008_IDENTITY_INVALID"):
            m008_weather_mae(self.city_text, [row])
        row = self.row("2026-09-01", [1000], 1000)
        row["raw_c_milli"] = [999]
        with self.assertRaisesRegex(ValueError, "M008_IDENTITY_INVALID"):
            m008_weather_mae(self.city_text, [row])

    def test_noncanonical_date_and_illegal_sample_types_rejected(self):
        row = self.row("2026-09-01", [1000], 1000)
        row["target_date"] = "20260901"
        with self.assertRaisesRegex(ValueError, "M008_TARGET_DATE_INVALID"):
            m008_weather_mae(self.city_text, [row])
        row = self.row("2026-09-01", [1000], 1000)
        row["sample_payload"]["samples"][0]["x_c_milli"] = float("nan")
        with self.assertRaisesRegex(ValueError, "M008_IDENTITY_INVALID"):
            m008_weather_mae(self.city_text, [row])
        row = self.row("2026-09-01", [1000], 1000)
        row["sample_payload"]["samples"][0]["x_c_milli"] = True
        with self.assertRaisesRegex(ValueError, "M008_IDENTITY_INVALID"):
            m008_weather_mae(self.city_text, [row])

    def test_decimal_context_does_not_change_q12(self):
        row = self.row("2026-09-01", [1000, 1001, 1002], 1000)
        prior = getcontext().copy()
        try:
            getcontext().prec = 6
            getcontext().rounding = ROUND_DOWN
            self.assertEqual(
                m008_weather_mae(self.city_text, [row]),
                (Decimal("0.001000000000"), Decimal(1), Decimal("0.001000000000"), 0, "OK"),
            )
        finally:
            getcontext().prec = prior.prec
            getcontext().rounding = prior.rounding

    def test_complete_local_day_boundaries_and_invalid_coverage_rejected(self):
        self.assertEqual(m008_weather_mae(self.city_text, [self.row("2026-09-01", [1000], 1000)] )[-1], "OK")
        for first_minutes, first_seconds, last_minutes, last_seconds in ((30, 1, 30, 0), (30, 0, 30, 1)):
            row = self.row("2026-09-01", [1000], 1000)
            label = self.label("2026-09-01", 1000, first_minutes=first_minutes, first_seconds=first_seconds, last_minutes=last_minutes, last_seconds=last_seconds)
            row["label"] = label
            row["label_identity"] = label.label_hash
            with self.assertRaisesRegex(ValueError, "M008_IDENTITY_INVALID"):
                m008_weather_mae(self.city_text, [row])
        row = self.row("2026-09-01", [1000], 1000)
        label = self.label("2026-09-01", 1000, gap=True)
        row["label"] = label
        row["label_identity"] = label.label_hash
        with self.assertRaisesRegex(ValueError, "M008_IDENTITY_INVALID"):
            m008_weather_mae(self.city_text, [row])
