import unittest
from datetime import date

from strategy_engine.data.evidence import FormalSettlementV1
from strategy_engine.data.records import Visibility
from strategy_engine.reports.population_metrics import (
    EligibleEventV1, FailureDayV1, MarketPartitionV1, PreregisteredPopulationV1,
    m009_settlement_identity_rate, m010_eligible_day_rate, m017_source_failure_rate,
)
from strategy_v8.canonical import hash_v1
from strategy_v8.contracts import City
from strategy_v8.errors import ErrorCode


class PopulationMetricsTests(unittest.TestCase):
    city = City.SHANGHAI
    days = (date(2026, 9, 1), date(2026, 9, 2))

    def population(self):
        return PreregisteredPopulationV1.create(self.city, self.days)

    def settlement(self, day, token="yes", outcome=True):
        visibility = Visibility("2026-09-03T00:00:00.000000Z", "2026-09-03T00:00:00.000000Z", "2026-09-03T00:00:00.000000Z")
        return FormalSettlementV1.create(self.city, day, "market", token, "bucket", outcome, visibility.effective_at_utc, "publication", hash_v1("test", {"d": day.isoformat(), "t": token}), visibility)

    def test_m009_keeps_missing_and_conflicting_days_in_denominator(self):
        pop = self.population()
        partitions = tuple(MarketPartitionV1(self.city, day, (("market", "yes", "bucket"),)) for day in self.days)
        result = m009_settlement_identity_rate(pop, partitions, (self.settlement(self.days[0]), self.settlement(self.days[1], "other")))
        self.assertEqual((result["numerator"], result["denominator"], result["missing_count"], result["value"]), (1, 2, 1, result["value"]))
        self.assertEqual(str(result["value"]), "0.500000000000")
        zero_yes = m009_settlement_identity_rate(pop, partitions, (self.settlement(self.days[0]), self.settlement(self.days[1], outcome=False)))
        self.assertEqual((zero_yes["numerator"], str(zero_yes["value"])), (1, "0.500000000000"))
        foreign = MarketPartitionV1(City.BEIJING, self.days[0], (("market", "yes", "bucket"),))
        self.assertEqual(m009_settlement_identity_rate(pop, partitions + (foreign,), (self.settlement(self.days[0]),))["status"], "NOT_COMPUTABLE")

    def test_m010_first_event_is_per_day_and_no_event_is_zero(self):
        pop = self.population()
        first = EligibleEventV1.create(self.city, self.days[0], 1, "event-a", hash_v1("test", {"x": 1}))
        later = EligibleEventV1.create(self.city, self.days[0], 2, "event-b", hash_v1("test", {"x": 2}))
        result = m010_eligible_day_rate(pop, (first, later))
        self.assertEqual((result["numerator"], result["denominator"], str(result["value"])), (1, 2, "0.500000000000"))
        bad = m010_eligible_day_rate(pop, (later, first))
        self.assertEqual(bad["status"], "NOT_COMPUTABLE")

    def test_m017_uses_fixed_reason_priority_and_unclassified_is_not_computable(self):
        pop = self.population()
        days = (
            FailureDayV1(self.city, self.days[0], ErrorCode.E_SOURCE_FACT_ID_CONFLICT, ("PUBLICATION_MISSING", "SOURCE_FACT_CONFLICT")),
            FailureDayV1(self.city, self.days[1], None, ()),
        )
        result = m017_source_failure_rate(pop, days)
        self.assertEqual(result["reason_counts"], (("SOURCE_FACT_CONFLICT", 1), ("SOURCE_IDENTITY_INVALID", 0), ("RETENTION_GAP", 0), ("PUBLICATION_MISSING", 0)))
        self.assertEqual(str(result["value"]), "0.500000000000")
        self.assertEqual(m017_source_failure_rate(pop, days[:1])["status"], "NOT_COMPUTABLE")

    def test_empty_population_is_not_computable(self):
        pop = PreregisteredPopulationV1.create(self.city, ())
        self.assertEqual(m009_settlement_identity_rate(pop, (), ())["status"], "NOT_COMPUTABLE")
        self.assertEqual(m010_eligible_day_rate(pop, ())["status"], "NOT_COMPUTABLE")
        self.assertEqual(m017_source_failure_rate(pop, ())["status"], "NOT_COMPUTABLE")
