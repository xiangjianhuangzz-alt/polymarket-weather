from __future__ import annotations

from copy import deepcopy
from dataclasses import fields, FrozenInstanceError
from hashlib import sha256
import json
from pathlib import Path
import unittest

from tools.research_weather_v1.adapter import (
    EXPECTED_DATES,
    INSUFFICIENT_MATURE_TRAINING_DATA,
    ResearchWeatherModelInputV1,
    load_research_dataset,
    parse_research_dataset,
)


DATASET = Path("data/strategy_analysis/wp03_stage0_5_research_dataset_v1/research_dataset_v1.json")
MANIFEST = DATASET.with_name("DATASET_MANIFEST_V1.json")
VALIDATION_AS_OF = "2026-09-05T00:00:00Z"


class ResearchWeatherAdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.payload = json.loads(DATASET.read_text(encoding="utf-8"))

    def test_dataset_types_identity_anchor_and_all_dates(self) -> None:
        dataset = load_research_dataset(DATASET, validation_as_of_utc=VALIDATION_AS_OF)
        self.assertEqual(tuple(day.target_date for day in dataset.days), EXPECTED_DATES)
        self.assertEqual(len(dataset.days), 12)
        self.assertEqual(len(dataset.weather_model_inputs()), 12)
        self.assertTrue(all(item.city == "Shanghai" and item.local_second == 28800 for item in dataset.weather_model_inputs()))

    def test_manifest_and_canonical_payload_hashes(self) -> None:
        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        canonical = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        self.assertEqual(sha256(canonical(self.payload)).hexdigest(), manifest["dataset_payload_sha256"])
        manifest_payload = dict(manifest)
        expected_manifest_hash = manifest_payload.pop("dataset_manifest_hash")
        self.assertEqual(sha256(canonical(manifest_payload)).hexdigest(), expected_manifest_hash)
        for day in self.payload["days"]:
            day_payload = dict(day)
            expected_day_hash = day_payload.pop("day_record_hash")
            self.assertEqual(sha256(canonical(day_payload)).hexdigest(), expected_day_hash)

    def test_wrong_json_types_fail_closed(self) -> None:
        changed = deepcopy(self.payload)
        changed["days"][0]["weather_prediction_track"]["observation_count_at_anchor"] = True
        with self.assertRaisesRegex(ValueError, "must be an integer"):
            parse_research_dataset(changed, validation_as_of_utc=VALIDATION_AS_OF)

    def test_forecast_revision_observed_by_anchor_and_zspd(self) -> None:
        dataset = parse_research_dataset(self.payload, validation_as_of_utc=VALIDATION_AS_OF)
        self.assertTrue(all(item.weather_label.station == "ZSPD" for item in dataset.weather_model_inputs()))
        bad = deepcopy(self.payload)
        bad["days"][0]["weather_prediction_track"]["forecast"]["observed_at_utc"] = "2026-08-22T00:00:01Z"
        with self.assertRaisesRegex(ValueError, "not observed"):
            parse_research_dataset(bad, validation_as_of_utc=VALIDATION_AS_OF)

    def test_d_plus_two_maturity_is_enforced(self) -> None:
        with self.assertRaisesRegex(ValueError, "not mature"):
            parse_research_dataset(self.payload, validation_as_of_utc="2026-09-03T15:59:59Z")
        parse_research_dataset(self.payload, validation_as_of_utc="2026-09-03T16:00:00Z")

    def test_missing_conflict_and_unprovable_days_are_retained(self) -> None:
        for index, status in enumerate(("MISSING", "CONFLICT", "UNPROVABLE")):
            changed = deepcopy(self.payload)
            day = changed["days"][index]
            day["overall_status"] = status
            day["weather_prediction_track"]["status"] = status
            day["weather_prediction_track"]["forecast_reason"] = f"TEST_{status}"
            parsed = parse_research_dataset(changed, validation_as_of_utc=VALIDATION_AS_OF)
            self.assertEqual(len(parsed.days), 12)
            self.assertEqual(parsed.days[index].status, status)
            self.assertIsNone(parsed.days[index].weather_input)

    def test_weather_model_boundary_excludes_market_fields_and_is_frozen(self) -> None:
        names = {field.name for field in fields(ResearchWeatherModelInputV1)}
        forbidden = {"market", "market_id", "orderbook", "price", "fee", "cost", "settlement"}
        self.assertTrue(names.isdisjoint(forbidden))
        item = parse_research_dataset(self.payload, validation_as_of_utc=VALIDATION_AS_OF).weather_model_inputs()[0]
        with self.assertRaises(FrozenInstanceError):
            item.city = "Other"

    def test_fixed_input_is_deterministic(self) -> None:
        first = parse_research_dataset(deepcopy(self.payload), validation_as_of_utc=VALIDATION_AS_OF)
        second = parse_research_dataset(deepcopy(self.payload), validation_as_of_utc=VALIDATION_AS_OF)
        self.assertEqual(first, second)
        self.assertEqual(first.deterministic_hash(), second.deterministic_hash())

    def test_insufficient_mature_training_data_status_is_explicit(self) -> None:
        dataset = parse_research_dataset(self.payload, validation_as_of_utc=VALIDATION_AS_OF)
        self.assertEqual(dataset.training_readiness(13), INSUFFICIENT_MATURE_TRAINING_DATA)


if __name__ == "__main__":
    unittest.main()
