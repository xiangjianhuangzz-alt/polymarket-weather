import os
import tempfile
import unittest
from datetime import date
from decimal import Decimal, ROUND_DOWN, getcontext

from strategy_engine.data.evidence import FormalSettlementV1
from strategy_engine.data.records import Visibility
from strategy_engine.simulation.ledger import SimulationLedger
from strategy_v8.canonical import hash_v1
from strategy_v8.contracts import City


DAY = date(2026, 9, 1)


def settlement(*, city=City.SHANGHAI, target_date=DAY, market="m", token="t", outcome=True, source="source"):
    timestamp = "2026-09-02T00:00:00.000000Z"
    visibility = Visibility(timestamp, timestamp, timestamp)
    return FormalSettlementV1.create(
        city, target_date, market, token, "bucket", outcome, timestamp, source,
        hash_v1("PWM.TEST.SETTLEMENT.SOURCE", {"source": source}), visibility,
    )


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.file = tempfile.mktemp(suffix=".sqlite")
        self.ledger = SimulationLedger(self.file)

    def tearDown(self):
        self.ledger.close()
        if os.path.exists(self.file):
            os.remove(self.file)

    def test_yes_settlement_restart_and_hash_idempotence(self):
        self.assertEqual(self.ledger.reserve("a", "SHANGHAI", DAY, "m", "t", 5, "10"), "PENDING")
        self.assertEqual(self.ledger.fill("a", 5, "9", "7"), "FILLED")
        self.ledger.close()
        self.ledger = SimulationLedger(self.file)
        approved = settlement()
        self.assertEqual(self.ledger.settle("a", approved), "SETTLED")
        self.assertEqual(self.ledger.settle("a", approved), "SETTLED")
        self.assertEqual(self.ledger.balances()["cash"], Decimal("998"))
        with self.assertRaisesRegex(ValueError, "SIMULATION_IDENTITY_CONFLICT"):
            self.ledger.settle("a", settlement(source="different"))

    def test_no_settlement_and_binding_rejections(self):
        self.ledger.reserve("a", "SHANGHAI", DAY, "m", "t", 5, "10")
        self.ledger.fill("a", 5, "9", "7")
        self.assertEqual(self.ledger.settle("a", settlement(outcome=False)), "SETTLED")
        self.assertEqual(self.ledger.balances()["cash"], Decimal("993"))
        for invalid in (
            settlement(city=City.BEIJING), settlement(target_date=date(2026, 9, 2)),
            settlement(market="other"), settlement(token="other"),
        ):
            with self.assertRaisesRegex(ValueError, "SETTLEMENT_PENDING_OR_INVALID"):
                self.ledger.settle("a", invalid)
        tampered = settlement()
        object.__setattr__(tampered, "market_id", "tampered")
        with self.assertRaisesRegex(ValueError, "SETTLEMENT_PENDING_OR_INVALID"):
            self.ledger.settle("a", tampered)
        non_boolean = settlement()
        object.__setattr__(non_boolean, "outcome_yes", 1)
        with self.assertRaisesRegex(ValueError, "SETTLEMENT_PENDING_OR_INVALID"):
            self.ledger.settle("a", non_boolean)
        with self.assertRaises(TypeError):
            self.ledger.settle("a", "legacy", True)

    def test_quantity_city_initial_cash_and_rollback_rejections(self):
        with self.assertRaisesRegex(ValueError, "SIMULATION_INITIAL_CASH_INVALID"):
            SimulationLedger(tempfile.mktemp(suffix=".sqlite"), initial_cash="999")
        with self.assertRaisesRegex(ValueError, "SIMULATION_INTENT_INVALID"):
            self.ledger.reserve("a", "SHANGHAI ", DAY, "m", "t", 5, "1")
        with self.assertRaisesRegex(ValueError, "SIMULATION_INTENT_INVALID"):
            self.ledger.reserve("a", "SHANGHAI", DAY, "m", "t", 5.0, "1")
        self.ledger.reserve("a", "SHANGHAI", DAY, "m", "t", 5, "10")
        with self.assertRaisesRegex(ValueError, "ACTUAL_DEBIT"):
            self.ledger.fill("a", 5, "9", "10")
        self.assertEqual(self.ledger.balances()["pending_reservation"], Decimal("10"))

    def test_fixed_decimal_context_and_precision_rejection(self):
        original = getcontext().copy()
        try:
            getcontext().prec = 2
            getcontext().rounding = ROUND_DOWN
            self.ledger.reserve("a", "SHANGHAI", DAY, "m", "t", 5, "10.01")
            self.assertEqual(self.ledger.fill("a", 5, "10.01", "9.99"), "FILLED")
            self.assertEqual(self.ledger.balances()["cash"], Decimal("990.01"))
            self.assertEqual(self.ledger.balances()["unspent_filled_reserve"], Decimal("0.02"))
            with self.assertRaisesRegex(ValueError, "SIMULATION_AMOUNT_INVALID"):
                self.ledger.reserve("b", "SHANGHAI", DAY, "m2", "t2", 5, "0.0000000000001")
        finally:
            getcontext().prec = original.prec
            getcontext().rounding = original.rounding
            getcontext().Emin = original.Emin
            getcontext().Emax = original.Emax
            getcontext().capitals = original.capitals
            getcontext().clamp = original.clamp
