"""Exercise actual saved-record lifecycle, not a hard-coded summary flag."""
from copy import deepcopy
import unittest
from unittest.mock import patch

from tools.research_weather_validation_v1 import runner
from tests.research_weather_validation_v1.test_runner import population, row

def prediction(day, **changes):
    value={'target_date':f'2026-01-{day:02d}','status':'PREDICTION_SAVED_AWAITING_LABEL','source_status':'AVAILABLE','training_dates':['2025-12-28','2025-12-29'],'training_count':2,'model_probabilities':['0','1']+['0']*50,'baseline_probabilities':['0','0','1']+['0']*49,'bucket_ids':[b.bucket_id for b in runner.research_weather_buckets()],'model_temperature_mean_c':'0','baseline_temperature_mean_c':'1','prediction_evidence':{'immutable':'retain'}}
    value.update(changes)
    return value

def score(records):
    labels={'candidate_days':[{'target_date':p['target_date'],'label_final_max_c':'0','status':'AVAILABLE'} for p in records]}
    return runner.score_saved_predictions({'rows':records},labels)

class FailureLifecycleTests(unittest.TestCase):
    def assert_failure_dates(self,result,dates):
        self.assertEqual(result['summary']['computation_failure_days'],dates)
        self.assertEqual(result['summary']['computation_failure_day_count'],len(dates))
        self.assertNotEqual(result['summary']['early_signal'],'POSITIVE_EARLY_SIGNAL')

    def test_a_three_successes_plus_original_prediction_failure_blocks_positive(self):
        records=[prediction(i) for i in range(3,6)]+[prediction(6,status='INPUT_OR_COMPUTATION_FAILURE',reason='prediction failed')]
        result=score(records)
        self.assertEqual(result['summary']['scored_count'],3)
        self.assert_failure_dates(result,['2026-01-06'])

    def test_b_successful_prediction_then_scoring_failure_preserves_every_field(self):
        original=prediction(3,baseline_probabilities=['-0.1','1.1']+['0']*50)
        before=deepcopy(original)
        result=score([original])
        failed=result['rows'][0]
        for key,value in before.items():
            self.assertEqual(failed[key],value)
        self.assertEqual(original,before)
        self.assertEqual(failed['evaluation_status'],'INPUT_OR_COMPUTATION_FAILURE')
        self.assertTrue(failed['evaluation_error'])
        self.assert_failure_dates(result,['2026-01-03'])

    def test_c_successful_prediction_and_evaluation_enter_metrics(self):
        result=score([prediction(i) for i in range(3,6)])
        self.assertEqual(result['summary']['scored_count'],3)
        self.assertEqual(result['summary']['computation_failure_day_count'],0)
        self.assertEqual(result['summary']['brier_mean_model'],'0')
        self.assertEqual(result['summary']['brier_mean_baseline'],'2')
        self.assertEqual(result['summary']['early_signal'],'POSITIVE_EARLY_SIGNAL')

    def test_d_original_failure_keeps_training_vectors_buckets_means_and_reason(self):
        original=prediction(3,status='INPUT_OR_COMPUTATION_FAILURE',reason='original cause',evaluation_status='INPUT_OR_COMPUTATION_FAILURE',evaluation_error='later cause')
        before=deepcopy(original)
        result=score([original])
        self.assertEqual(result['rows'][0],before)
        self.assertEqual(original,before)
        self.assert_failure_dates(result,['2026-01-03'])

    def test_e_prediction_and_evaluation_failures_form_date_union(self):
        result=score([prediction(3,status='INPUT_OR_COMPUTATION_FAILURE'),prediction(4,evaluation_status='INPUT_OR_COMPUTATION_FAILURE',evaluation_error='retained'),prediction(5,status='INPUT_OR_COMPUTATION_FAILURE',evaluation_status='INPUT_OR_COMPUTATION_FAILURE')])
        self.assert_failure_dates(result,['2026-01-03','2026-01-04','2026-01-05'])
        self.assertEqual(result['summary']['scored_count'],0)
        self.assertEqual(result['rows'][1]['evaluation_error'],'retained')

    def test_missing_required_fields_and_unknown_status_are_fail_closed(self):
        for field in ('model_probabilities','baseline_probabilities','model_temperature_mean_c','baseline_temperature_mean_c','status'):
            with self.subTest(field=field):
                original=prediction(3)
                del original[field]
                result=score([original])
                self.assert_failure_dates(result,['2026-01-03'])
                self.assertEqual(result['rows'][0]['training_count'],2)

    def test_early_prediction_error_keeps_computed_training_dates(self):
        result=runner.run_population(population(row('2026-01-01'),row('2026-01-03',forecast_high_c=None)),connect_labels=False)
        failed=result['rows'][1]
        self.assertEqual(failed['training_dates'],['2026-01-01'])
        self.assertEqual(failed['training_count'],1)
        self.assertEqual(failed['status'],'INPUT_OR_COMPUTATION_FAILURE')
        self.assertTrue(failed['reason'])
        self.assert_failure_dates(result,['2026-01-03'])

    def test_baseline_generation_failure_does_not_drop_candidate_evidence(self):
        original_function=runner.research_probability_from_samples
        calls=[]
        def second_call_fails(samples,buckets):
            calls.append(1)
            if len(calls)==2:
                raise ValueError('synthetic baseline generation failure')
            return original_function(samples,buckets)
        with patch.object(runner,'research_probability_from_samples',side_effect=second_call_fails):
            result=runner.run_population(population(row('2026-01-01'),row('2026-01-03')),connect_labels=False)
        failed=result['rows'][1]
        for field in ('model_probabilities','model_temperature_mean_c','model_quantization','bucket_ids'):
            self.assertIn(field,failed)
        self.assertEqual(failed['training_dates'],['2026-01-01'])
        self.assertEqual(failed['training_count'],1)
        self.assert_failure_dates(result,['2026-01-03'])


if __name__ == "__main__":
    unittest.main()
