from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tools.research_weather_validation_v1 import runner


QA_ROOT = Path("data/strategy_analysis/wp03_stage1a_probability_fix_and_rerun_v1/20260905T173944+0800/qa_runtime/implementation")


def population(label: str = "0") -> dict[str, object]:
    return {
        "candidate_days": [
            {
                "target_date": "2026-01-03",
                "label_final_max_c": label,
            }
        ]
    }


def saved_prediction(*, invalid: bool = False) -> dict[str, object]:
    values = ["0"] * 52
    values[1] = "1"
    baseline = ["0"] * 52
    baseline[1] = "1"
    if invalid:
        baseline[0] = "-0.1"
        baseline[1] = "1.1"
    return {
        "research_semantics": "RESEARCH_ONLY_NOT_IIC2",
        "bucket_ids": [f"B_{index}" for index in range(52)],
        "rows": [
            {
                "target_date": "2026-01-03",
                "status": "PREDICTION_SAVED_AWAITING_LABEL",
                "training_dates": ["2026-01-01", "2026-01-02"],
                "training_count": 2,
                "model_probabilities": values,
                "baseline_probabilities": baseline,
                "model_temperature_mean_c": "1",
                "baseline_temperature_mean_c": "1",
                "prediction_identity": {"must": "survive"},
            }
        ],
    }


class SavedScoringTests(unittest.TestCase):
    def setUp(self) -> None:
        QA_ROOT.mkdir(parents=True, exist_ok=True)
        self.root = Path(tempfile.mkdtemp(prefix="saved_scoring_", dir=QA_ROOT))

    def tearDown(self) -> None:
        shutil.rmtree(self.root)

    def test_scoring_reads_persisted_prediction_and_only_appends_evaluation(self) -> None:
        path = self.root / "predictions.json"
        original = saved_prediction()
        path.write_text(json.dumps(original), encoding="utf-8")
        with patch.object(runner, "predict_research_weather", side_effect=AssertionError("must not predict")):
            result = runner.score_saved_prediction_file(path, population())
        saved = original["rows"][0]
        scored = result["rows"][0]
        for key, value in saved.items():
            self.assertEqual(scored[key], value)
        self.assertEqual(scored["evaluation_status"], "SCORED")
        self.assertEqual(scored["candidate_loss_brier"], "0")
        self.assertEqual(scored["baseline_loss_brier"], "0")
        self.assertEqual(result["summary"]["candidate_count"], 1)
        self.assertEqual(result["summary"]["scored_count"], 1)
        self.assertNotIn("evaluation_status", saved)

    def test_scoring_accepts_finite_non_milli_prediction_mean(self) -> None:
        path = self.root / "predictions.json"
        original = saved_prediction()
        original["rows"][0]["model_temperature_mean_c"] = "31.428571428571428571"
        path.write_text(json.dumps(original), encoding="utf-8")
        result = runner.score_saved_prediction_file(path, population())
        self.assertEqual(result["rows"][0]["evaluation_status"], "SCORED")

    def test_scoring_failure_preserves_saved_prediction_fields(self) -> None:
        path = self.root / "predictions.json"
        original = saved_prediction(invalid=True)
        path.write_text(json.dumps(original), encoding="utf-8")
        result = runner.score_saved_prediction_file(path, population())
        saved = original["rows"][0]
        failed = result["rows"][0]
        for key, value in saved.items():
            self.assertEqual(failed[key], value)
        self.assertEqual(failed["evaluation_status"], "INPUT_OR_COMPUTATION_FAILURE")
        self.assertTrue(failed["evaluation_error"])

    def test_legacy_connected_scoring_failure_preserves_prediction(self) -> None:
        payload = {
            "candidate_days": [
                {
                    "target_date": "2026-01-01", "status": "AVAILABLE", "decision_as_of_utc": "2026-01-01T00:00:00Z",
                    "forecast_high_c": "20", "current_observed_max_c": "19", "label_final_max_c": "21", "label_available_at_utc": "2026-01-03T00:00:00+08:00",
                },
                {
                    "target_date": "2026-01-03", "status": "AVAILABLE", "decision_as_of_utc": "2026-01-03T00:00:00Z",
                    "forecast_high_c": "20", "current_observed_max_c": "19", "label_final_max_c": "not-a-decimal", "label_available_at_utc": "2026-01-05T00:00:00+08:00",
                },
            ]
        }
        result = runner.run_population(payload)
        failed = result["rows"][1]
        self.assertEqual(failed["status"], "PREDICTION_SAVED_AWAITING_LABEL")
        self.assertIn("model_probabilities", failed)
        self.assertEqual(failed["evaluation_status"], "INPUT_OR_COMPUTATION_FAILURE")


if __name__ == "__main__":
    unittest.main()
