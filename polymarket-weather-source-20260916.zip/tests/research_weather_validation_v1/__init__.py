"""Tests for the research-only Stage1A weather validation runner."""
