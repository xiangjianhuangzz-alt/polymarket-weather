from __future__ import annotations

import inspect
import json
import shutil
import tempfile
import unittest
from datetime import date
from decimal import Decimal
from pathlib import Path

from tools.research_weather_validation_v1.metrics import brier_score, mean
from tools.research_weather_validation_v1.runner import RUN_ROOT, predict_research_weather, run_population, write_run


QA_ROOT = RUN_ROOT.parent / "qa_runtime" / "implementation"


def row(
    target_date: str,
    *,
    status: str = "AVAILABLE",
    label_available_at_utc: str | None = None,
    label_final_max_c: str | None = "21",
    **changes: object,
) -> dict[str, object]:
    value: dict[str, object] = {
        "target_date": target_date,
        "status": status,
        "reason": None,
        "decision_as_of_utc": f"{target_date}T00:00:00Z",
        "forecast_high_c": "20",
        "current_observed_max_c": "19",
        "label_final_max_c": label_final_max_c,
        "label_available_at_utc": label_available_at_utc or f"{target_date}T00:00:00Z",
        "source_refs": [],
        "asof_checks": {},
    }
    value.update(changes)
    return value


def population(*rows: dict[str, object]) -> dict[str, object]:
    return {"as_of_utc": "2026-01-10T00:00:00Z", "candidate_days": list(rows), "counts": {}}


class Stage1ARunnerTests(unittest.TestCase):
    def setUp(self) -> None:
        QA_ROOT.mkdir(parents=True, exist_ok=True)
        self.output_dir = Path(tempfile.mkdtemp(prefix="stage1a_", dir=QA_ROOT))

    def tearDown(self) -> None:
        shutil.rmtree(self.output_dir)

    def test_d_plus_2_boundary_and_current_label_is_scored_after_prediction(self) -> None:
        result = run_population(
            population(
                row("2026-01-01", label_available_at_utc="2026-01-03T00:00:00+08:00"),
                row("2026-01-02", label_available_at_utc="2026-01-04T00:00:01+08:00"),
                row("2026-01-03", decision_as_of_utc="2026-01-03T00:00:00Z", label_final_max_c="22"),
            )
        )
        target = result["rows"][2]
        self.assertEqual(target["status"], "SCORED")
        self.assertEqual(target["training_dates"], ["2026-01-01"])
        self.assertEqual(len(target["model_probabilities"]), 52)
        self.assertNotIn("label_final_max_c", inspect.signature(predict_research_weather).parameters)

    def test_market_fields_do_not_enter_research_prediction_interface(self) -> None:
        first = row("2026-01-01", label_available_at_utc="2026-01-03T00:00:00+08:00")
        target = row(
            "2026-01-03",
            decision_as_of_utc="2026-01-03T00:00:00Z",
            market_id="forbidden-market-input",
            yes_token_id="forbidden-token-input",
            yes_price="0.99",
            fees="forbidden",
        )
        result = run_population(population(first, target))
        saved = result["rows"][1]
        self.assertEqual(saved["status"], "SCORED")
        self.assertNotIn("market_id", saved)
        self.assertNotIn("yes_token_id", saved)
        self.assertNotIn("fees", saved)

    def test_duplicate_target_date_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "unique target_date"):
            run_population(population(row("2026-01-01"), row("2026-01-01")))

    def test_unavailable_and_insufficient_rows_are_all_preserved(self) -> None:
        result = run_population(
            population(
                row("2026-01-01"),
                row("2026-01-02", status="MISSING", reason="missing source"),
                row("2026-01-03", status="CONFLICT", reason="conflicting source"),
                row("2026-01-04", status="UNPROVABLE", reason="as-of unknown"),
            )
        )
        self.assertEqual(len(result["rows"]), 4)
        self.assertEqual(result["rows"][0]["status"], "INSUFFICIENT_PRIOR_TRAINING_DATA")
        self.assertEqual([item["status"] for item in result["rows"][1:]], ["MISSING", "CONFLICT", "UNPROVABLE"])

    def test_known_brier_and_mae(self) -> None:
        self.assertEqual(brier_score((Decimal("1"), Decimal("0")), 1), Decimal("2"))
        self.assertEqual(mean((Decimal("20"), Decimal("22"))), Decimal("21"))

    def test_write_is_limited_to_the_authorized_run_root(self) -> None:
        result = write_run(population(row("2026-01-01")), self.output_dir)
        self.assertEqual(result["summary"]["candidate_count"], 1)
        saved = self.output_dir / "stage1a_results.json"
        predictions = self.output_dir / "predictions.json"
        self.assertTrue(saved.is_file())
        self.assertTrue(predictions.is_file())
        self.assertEqual(json.loads(predictions.read_text(encoding="utf-8"))["rows"][0]["status"], "INSUFFICIENT_PRIOR_TRAINING_DATA")
        self.assertEqual(json.loads(saved.read_text(encoding="utf-8"))["rows"][0]["status"], "INSUFFICIENT_PRIOR_TRAINING_DATA")
        with self.assertRaisesRegex(ValueError, "authorized run scope"):
            write_run(population(row("2026-01-01")), Path.cwd())


if __name__ == "__main__":
    unittest.main()
