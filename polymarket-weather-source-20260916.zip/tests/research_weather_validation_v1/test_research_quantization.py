"""Research exception tests; production IIC2 tests are untouched."""
from decimal import Decimal, ROUND_HALF_EVEN
from fractions import Fraction
import json
import unittest

from tools.research_weather_validation_v1.metrics import TOTAL_TICKS, largest_remainder_e12
from tools.research_weather_validation_v1.runner import research_probability_from_samples, research_weather_buckets

# Fixed counts mechanically extracted only from the six original failing days,
# frozen population SHA256 31066d7ef7eb2b4f7368df3fd2e1e3fc4b2d5559159c816d6e7a0e56afdfe483.
FAILURE_STRUCTURES = {
    '2026-08-25_baseline': {28:1,29:2,30:2,32:2,34:3,35:2,37:1,38:1},
    '2026-08-26_candidate': {32:4,33:3,34:4,35:4},
    '2026-08-28_baseline': {28:1,29:2,30:2,32:3,33:2,34:3,35:2,37:1,38:1},
    '2026-08-29_baseline': {28:1,29:2,30:2,32:3,33:3,34:3,35:2,37:1,38:1},
    '2026-09-02_baseline': {28:1,29:2,30:2,31:1,32:5,33:3,34:4,35:2,37:1,38:1},
    '2026-09-03_baseline': {28:1,29:2,30:2,31:2,32:5,33:3,34:4,35:2,37:1,38:1},
}

def raw_counts(counts):
    total = sum(counts.values())
    return tuple(Fraction(counts.get(i,0),total) for i in range(52))

class ResearchQuantizationTests(unittest.TestCase):
    def assert_valid(self, raw):
        values, meta = largest_remainder_e12(raw)
        self.assertEqual(len(values),52)
        self.assertTrue(all(Decimal(0)<=v<=Decimal(1) for v in values))
        self.assertEqual(sum(values,Decimal(0)),Decimal(1))
        self.assertEqual(sum(meta['per_bucket_ticks']),TOTAL_TICKS)
        self.assertEqual(meta['total_ticks'],10**12)
        self.assertEqual(meta['research_quantization_policy_id'],'STAGE1A_LARGEST_REMAINDER_E12_V1')
        self.assertEqual(tuple(map(Decimal,meta['research_quantized_probability_vector'])),values)
        self.assertEqual(tuple(Fraction(x['numerator'],x['denominator']) for x in meta['raw_probability_vector']),raw)
        for i, delta in enumerate(meta['quantization_delta_per_bucket']):
            self.assertEqual(Fraction(delta['numerator'],delta['denominator']),Fraction(meta['per_bucket_ticks'][i],TOTAL_TICKS)-raw[i])
        self.assertEqual(json.dumps(meta,sort_keys=True).encode(),json.dumps(largest_remainder_e12(raw)[1],sort_keys=True).encode())
        return values,meta

    def test_original_six_failure_structures(self):
        for name,counts in FAILURE_STRUCTURES.items():
            with self.subTest(original_failure=name):
                raw=raw_counts(counts)
                first51=[(Decimal(p.numerator)/Decimal(p.denominator)).quantize(Decimal('1e-12'),rounding=ROUND_HALF_EVEN) for p in raw[:-1]]
                self.assertLess(Decimal(1)-sum(first51,Decimal(0)),Decimal(0))
                self.assert_valid(raw)

    def test_thirds_counterexample_and_ordinal_tie(self):
        _,meta=self.assert_valid(raw_counts({0:1,1:1,2:1}))
        self.assertEqual(meta['per_bucket_ticks'],[333333333334,333333333333,333333333333]+[0]*49)

    def test_single_bucket_and_sparse_vectors(self):
        for counts in ({0:1},{51:1},{5:1,20:3,50:3}):
            with self.subTest(counts=counts):
                _,meta=self.assert_valid(raw_counts(counts))
                self.assertTrue(all(meta['per_bucket_ticks'][i]==0 for i in range(52) if i not in counts))

    def test_uniform_and_near_uniform(self):
        _,meta=self.assert_valid(tuple(Fraction(1,52) for _ in range(52)))
        base,remainder=divmod(TOTAL_TICKS,52)
        self.assertEqual(meta['per_bucket_ticks'],[base+1]*remainder+[base]*(52-remainder))
        self.assert_valid(raw_counts({i:100+(i%2) for i in range(52)}))

    def test_identical_sample_inputs_use_identical_policy_and_bytes(self):
        samples=(Decimal('31'),Decimal('31'),Decimal('32'))
        buckets=research_weather_buckets()
        candidate=research_probability_from_samples(samples,buckets)
        baseline=research_probability_from_samples(samples,buckets)
        self.assertEqual(candidate,baseline)
        self.assertEqual(json.dumps(candidate[1]).encode(),json.dumps(baseline[1]).encode())

    def test_invalid_raw_is_not_repaired(self):
        illegal=[(),(Fraction(1,3),)*3,(Fraction(-1),Fraction(2))+tuple(Fraction(0) for _ in range(50)),tuple(Fraction(1,53) for _ in range(52)),tuple(Fraction(1,51) for _ in range(52))]
        illegal.extend((bad,)+tuple(Fraction(0) for _ in range(51)) for bad in (Decimal('NaN'),Decimal('Infinity'),float('nan'),float('inf'),'NaN',None,True))
        for raw in illegal:
            with self.subTest(raw=repr(raw)):
                with self.assertRaises(ValueError):
                    largest_remainder_e12(raw)


if __name__ == "__main__":
    unittest.main()
