"""M1-only regression: synthetic facts, explicit isolated QA_ROOT, no acquisition."""
import copy
import importlib.util
import json
import os
import tempfile
import unittest
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch
from tools.research_multi_city_v1 import dynamic_forward as forward
from tools.research_multi_city_v1.asof_input import visible, seal_fact, bind_source_event
from tools.research_multi_city_v1.dynamic_evaluator import FrozenEvaluator, load_bindings
from tools.research_multi_city_v1.dynamic_event_router import DynamicEvent, CITIES
from tools.research_multi_city_v1.dynamic_replay import classify_failure, replay_verdict
from tools.research_multi_city_v1.dynamic_source_adapter import source_times

spec=importlib.util.spec_from_file_location('_m1_fixture_material',Path(__file__).with_name('test_dynamic_integration.py'))
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
T=fixture.T

class M1RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=os.environ['QA_ROOT']);self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.facts={};self.labels={};self.dates={}
        for city in CITIES:self.facts[city],self.labels[city],self.dates[city]=fixture.material(city)
        self.evaluator=FrozenEvaluator(fixture.REFS,self.facts,self.labels,self.dates)
        self.bindings={c:r['candidate_freeze_identity'] for c,r in load_bindings(fixture.REFS).items()}
        self.store=forward.DynamicForward(self.root,self.bindings)

    def event(self,identity='o1',kind='LEGAL_METAR_OR_SPECI'):
        return DynamicEvent('Shanghai','SourceFactV1',identity,kind,T-timedelta(minutes=1))

    def open(self,store=None):
        event=DynamicEvent('Shanghai','WindowBoundaryV1','OPEN','OPEN',T)
        result=(store or self.store).inject(event,T,self.evaluator)
        self.assertEqual(result['status'],'OK',result)
        return event,result

    def test_three_required_times_conditional_times_and_label_contract(self):
        fact=dict(self.facts['Shanghai'][0]);fact['received']=fact['available']=None
        self.assertTrue(visible(seal_fact(fact),T))
        fact['received']=(T+timedelta(seconds=1)).isoformat()
        self.assertFalse(visible(seal_fact(fact),T))
        fact['committed']=None
        with self.assertRaisesRegex(ValueError,'committed'):visible(seal_fact(fact),T)
        label=dict(self.labels['Shanghai'][0]);label['effective']=label['observed']=label['received']=label['available']=None
        self.labels['Shanghai'][0]=seal_fact(label)
        _,record=self.open()
        self.assertEqual(forward.verified(Path(record['snapshot_path']))['training_dates'],['2026-09-03'])

    def test_source_mapping_never_fabricates_observed_or_commit(self):
        row={'report_time':T.isoformat(),'received_at':T.isoformat(),'first_seen_at':T.isoformat(),'frozen_at':T.isoformat()}
        mapped=source_times(row,'METAR')
        self.assertEqual(mapped['received'],row['received_at'])
        self.assertIsNone(mapped['observed']);self.assertIsNone(mapped['committed']);self.assertIsNone(mapped['effective'])
        row.update(effective_at_utc=T.isoformat(),observed_at_utc=T.isoformat(),committed_at_utc=T.isoformat())
        mapped=source_times(row,'METAR')
        self.assertTrue(all(mapped[k]==T.isoformat() for k in ('effective','observed','committed')))

    def test_trigger_source_binding_failures_precede_model(self):
        original=self.facts['Shanghai'][1]
        for mutation in ('missing','city','hash','future','type','source','date'):
            with self.subTest(mutation=mutation):
                facts=copy.deepcopy(self.facts['Shanghai']);row=dict(original)
                if mutation=='missing':event=self.event('missing')
                else:
                    event=self.event()
                    if mutation=='city':row['city']='Beijing'
                    if mutation=='hash':row['value_c']='999'
                    if mutation=='future':row['committed']=(T+timedelta(seconds=1)).isoformat()
                    if mutation=='type':row['fact_type']='FORECAST'
                    if mutation=='source':row['source_identity']='other'
                    if mutation=='date':row['target_date']='2026-09-05'
                    facts[1]=row if mutation=='hash' else seal_fact(row)
                self.evaluator.facts['Shanghai']=facts
                before=self.evaluator.call_count
                with self.assertRaises(ValueError):self.evaluator(event,T)
                self.assertEqual(self.evaluator.call_count,before)
        self.evaluator.facts['Shanghai']=self.facts['Shanghai']

    def test_trigger_can_be_legal_nonwinning_revision(self):
        facts=copy.deepcopy(self.facts['Shanghai'])
        newer=dict(facts[0]);newer.update(identity='winner',revision='winner',revision_rank=2);facts.append(seal_fact(newer))
        bound=bind_source_event(self.event('f1','LEGAL_FORECAST_REVISION'),T,facts)
        self.assertEqual(bound['identity'],'f1')

    def test_corrupt_latest_blocks_new_forecast_metar_speci_before_model(self):
        for kind in ('LEGAL_FORECAST_REVISION','LEGAL_METAR_OR_SPECI','MARKET_SOURCE_FACT'):
            with self.subTest(kind=kind):
                store=forward.DynamicForward(self.root/kind,self.bindings)
                _,record=self.open(store)
                Path(record['snapshot_path']).write_text('{broken',encoding='utf-8')
                before=self.evaluator.call_count
                result=store.inject(self.event('f1' if kind=='LEGAL_FORECAST_REVISION' else 'o1',kind),T,self.evaluator)
                self.assertEqual(result['status'],'FAILURE');self.assertFalse(result['model_call'])
                self.assertEqual(self.evaluator.call_count,before)
                self.assertEqual(result['failure_class'],'STATE_INTEGRITY_FAILURE')

    def test_claim_interruptions_are_not_completed_duplicates(self):
        real=forward.write_once
        for point in ('event_keys','claims','lifecycle','events'):
            with self.subTest(point=point):
                store=forward.DynamicForward(self.root/point,self.bindings)
                event=DynamicEvent('Shanghai','WindowBoundaryV1','OPEN','OPEN',T)
                def interrupted(path,value):
                    real(path,value)
                    if path.parent.name==point:raise KeyboardInterrupt('SYNTHETIC_INTERRUPTION')
                with patch.object(forward,'write_once',interrupted):
                    with self.assertRaises(KeyboardInterrupt):store.inject(event,T,self.evaluator)
                count=self.evaluator.call_count
                result=forward.DynamicForward(store.root,self.bindings).inject(event,T,self.evaluator)
                self.assertEqual(result['status'],'FAILURE');self.assertFalse(result.get('duplicate',False))
                self.assertFalse(result['model_call']);self.assertEqual(self.evaluator.call_count,count)

    def test_completed_event_is_idempotent_and_snapshot_immutable(self):
        event,result=self.open();path=Path(result['snapshot_path']);raw=path.read_bytes();count=self.evaluator.call_count
        repeated=forward.DynamicForward(self.root,self.bindings).inject(event,T,self.evaluator)
        self.assertEqual(repeated['claim_status'],'ALREADY_COMPLETED');self.assertEqual(count,self.evaluator.call_count)
        self.assertEqual(raw,path.read_bytes())
        with self.assertRaises(FileExistsError):forward.write_once(path,{'replacement':True})

    def test_replay_classification_and_actual_snapshot_gate(self):
        pairs={'STRICT_ASOF_TIME_UNPROVABLE:committed':'DATA_EVIDENCE_INSUFFICIENT','SOURCE_FACT_HASH_MISMATCH':'SOURCE_IDENTITY_FAILURE',
               'EVENT_SOURCEFACT_FUTURE':'ASOF_CONTRACT_FAILURE','unexpected division':'IMPLEMENTATION_FAILURE',
               'CANDIDATE_FREEZE_HASH_MISMATCH':'FREEZE_IDENTITY_FAILURE','INCOMPLETE_PRIOR_ATTEMPT':'STATE_INTEGRITY_FAILURE',
               PermissionError('denied'):'ENVIRONMENT_FAILURE','NO_LEGAL_SNAPSHOT':'COVERAGE_INSUFFICIENT'}
        for error,expected in pairs.items():self.assertEqual(classify_failure(error),expected)
        self.assertEqual(replay_verdict([],[])['status'],'BLOCKED')
        row={'status':'OK','legal_dynamic_snapshot':True}
        self.assertEqual(replay_verdict([row],[])['status'],'PASS')
        failed={'error_reason':'SOURCE_FACT_HASH_MISMATCH','error_type':'ValueError'}
        self.assertEqual(replay_verdict([row],[failed])['status'],'BLOCKED')

if __name__=='__main__':unittest.main()
