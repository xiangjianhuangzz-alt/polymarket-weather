import tempfile
import unittest
import json
import hashlib
import os
from pathlib import Path

from tools.research_multi_city_v1 import run_three_city_forward_v1 as runner

RUNTIME = Path(os.environ['QA_ROOT'])


def bound_fixture(root, city):
    output = root / city.lower() / 'forward'
    output.mkdir(parents=True)
    freeze = root / (city + '.json')
    fields = {'city': city, 'station': runner.STATIONS[city]}
    if city == 'Shanghai':
        alias = output / 'WEATHER_CANDIDATE_FREEZE_V1.json'
        alias.write_text(json.dumps({'freeze_id': 'daily-freeze'}), encoding='utf-8')
        fields['existing_freeze'] = {'path': str(alias), 'sha256': runner.sha(alias)}
    freeze.write_text(json.dumps(fields), encoding='utf-8')
    source = alias if city == 'Shanghai' else freeze
    config = root / (city + '-config.json')
    config.write_text(json.dumps({'city': city, 'station': runner.STATIONS[city], 'output_root': str(output),
        'freeze_path': str(source), 'freeze_sha256': runner.sha(source)}), encoding='utf-8')
    item = {'config_path': str(config), 'config_sha256': runner.sha(config), 'freeze_path': str(freeze), 'freeze_sha256': runner.sha(freeze)}
    return output, item, runner.sha(source)


class ThreeCityRunnerTests(unittest.TestCase):
    def _save(self, path, value):
        raw = json.dumps(value).encode(); path.write_bytes(raw); path.with_suffix(".json.sha256").write_text(hashlib.sha256(raw).hexdigest(), encoding="ascii")
    def test_all_fake_processes_start_before_wait_and_failures_are_independent(self):
        with tempfile.TemporaryDirectory(dir=RUNTIME) as temporary:
            root, events = Path(temporary), []
            manifest = {"candidates": {city: {"entrypoint": module, "config_path": str(root / f"{city}.json")} for city, module in runner.CANDIDATES.items()}}
            for city, item in manifest["candidates"].items():
                Path(item["config_path"]).write_text(json.dumps({"output_root": str(root / city)}), encoding="utf-8")
            class Process:
                def __init__(self, city): self.pid, self.city = len(events), city
                def wait(self): events.append(("wait", self.city)); return 1 if self.city == "Beijing" else 0
            def popen(command, **kwargs):
                city = next(city for city, module in runner.CANDIDATES.items() if module == command[5] and city not in [event[1] for event in events if event[0] == "start"])
                events.append(("start", city)); return Process(city)
            result = runner.launch(manifest, popen, root / "attempts")
            self.assertEqual([event[0] for event in events[:3]], ["start"] * 3)
            self.assertEqual([event[0] for event in events[3:]], ["wait"] * 3)
            self.assertEqual(result["cities"]["Beijing"]["status"], "CHECK_FAIL")
            self.assertTrue(all("--check-only" in item["command"] for item in result["cities"].values()))

    def test_counters_deduplicate_days_and_retain_failed_prediction(self):
        with tempfile.TemporaryDirectory(dir=RUNTIME) as temporary:
            root = Path(temporary); config = root / "config.json"; day = root / "city" / "days" / "2026-09-06"; day.mkdir(parents=True)
            (day / "claim.json").write_text("{}", encoding="utf-8")
            (day / "prediction.json").write_text(json.dumps({"status": "INPUT_OR_COMPUTATION_FAILURE"}), encoding="utf-8")
            config.write_text(json.dumps({"output_root": str(root / "city")}), encoding="utf-8")
            manifest = {"candidates": {city: {"config_path": str(config)} for city in runner.CANDIDATES}}
            values = runner.counters(manifest)
            self.assertEqual(values["Beijing"]["attempted_days"], 1)
            self.assertEqual(values["Beijing"]["prediction_days"], 0)
            self.assertEqual(values["Beijing"]["failure_days"], 1)

    def test_counter_requires_prediction_and_score_hash_binding(self):
        with tempfile.TemporaryDirectory(dir=RUNTIME) as temporary:
            root = Path(temporary); output, item, freeze_hash = bound_fixture(root, 'Beijing')
            day = output / 'days' / '2026-09-06'; day.mkdir(parents=True)
            prediction = {"city":"Beijing","station":"ZBAA","target_date":"2026-09-06","execution_mode":"FORWARD_BLIND","status":"PREDICTION_SAVED_AWAITING_LABEL","prediction_created_at_utc":"2026-09-06T00:00:00Z","training_dates":[],"training_count":0,"model_probabilities":[0]*52,"baseline_probabilities":[0]*52,"model_temperature_mean_c":"1","baseline_temperature_mean_c":"1"}
            prediction['freeze_sha256'] = freeze_hash
            self._save(day / "prediction.json", prediction)
            self._save(day / "score.json", {"evaluation_status":"SCORED","prediction_sha256":hashlib.sha256((day / "prediction.json").read_bytes()).hexdigest()})
            manifest={"candidates":{'Beijing':item}}
            self.assertEqual(runner.counters(manifest)["Beijing"]["scored_days"],1)
            (day / "score.json.sha256").write_text("bad",encoding="ascii")
            values=runner.counters(manifest)["Beijing"]
            self.assertEqual(values["scored_days"],0); self.assertEqual(values["failure_days"],1)

    def test_claim_missing_or_bad_score_is_retained_as_failure(self):
        with tempfile.TemporaryDirectory(dir=RUNTIME) as temporary:
            root=Path(temporary); config=root/"config.json"; config.write_text(json.dumps({"output_root":str(root/"city")}),encoding="utf-8")
            claim=root/"city"/"days"/"2026-09-07"; claim.mkdir(parents=True); (claim/"claim.json").write_text("{}",encoding="utf-8")
            corrupt=root/"city"/"days"/"2026-09-08"; corrupt.mkdir(); (corrupt/"prediction.json").write_text("{",encoding="utf-8")
            manifest={"candidates":{city:{"config_path":str(config)} for city in runner.CANDIDATES}}
            values=runner.counters(manifest)["Beijing"]
            self.assertEqual(values["attempted_days"],2); self.assertEqual(values["failure_days"],2)

    def test_shanghai_real_daily_shape_uses_frozen_binding_not_unified_fields(self):
        with tempfile.TemporaryDirectory(dir=RUNTIME) as temporary:
            root = Path(temporary); output, item, freeze_hash = bound_fixture(root, 'Shanghai')
            day = output / 'days' / '2026-09-06'; day.mkdir(parents=True)
            prediction = {"target_date":"2026-09-06","prediction_created_at":"2026-09-06T00:00:00Z","training_dates":[],"training_count":0,"status":"PREDICTION_SAVED_AWAITING_LABEL","freeze_id":"daily-freeze","model_probabilities":[0]*52,"baseline_probabilities":[0]*52,"model_temperature_mean_c":"1","baseline_temperature_mean_c":"1"}
            prediction['freeze_sha256'] = freeze_hash
            self._save(day / "prediction.json", prediction)
            manifest = {"candidates": {'Shanghai': item}}
            values = runner.counters(manifest)["Shanghai"]
            self.assertEqual((values["prediction_days"], values["failure_days"]), (1, 0))


if __name__ == "__main__":
    unittest.main()
