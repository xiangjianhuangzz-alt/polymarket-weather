import copy
import hashlib
import json
import os
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timedelta
from pathlib import Path
from tools.research_multi_city_v1.asof_input import seal_fact, build_input
from tools.research_multi_city_v1.dynamic_evaluator import FrozenEvaluator, load_bindings
from tools.research_multi_city_v1.dynamic_event_router import CITIES, LOCAL, DynamicEvent
from tools.research_multi_city_v1.dynamic_forward import DynamicForward, verified
from tools.research_multi_city_v1.dynamic_source_adapter import load_saved_city

REFS=Path('D:/polymarket天气/data/strategy_analysis/wp03_dynamic_event_action_schema_closeout_v1/20260906T001025+0800/candidate_model_references.json')
T=datetime(2026,9,6,7,0,tzinfo=LOCAL)

def material(city):
    def fact(day,kind,identity,value,stamp,rank=1):
        return seal_fact({'city':city,'station':CITIES[city],'target_date':day,'fact_type':kind,
            'identity':identity,'source_identity':('weatherol_shanghai' if city=='Shanghai' else 'aviationweather_taf') if kind=='FORECAST' else 'aviationweather_metar',
            'revision':identity,'revision_rank':rank,'value_c':str(value),
            **{key:stamp.isoformat() for key in ('effective','observed','received','available','committed')}})
    historical=T-timedelta(days=3)
    f=fact('2026-09-06','FORECAST','f1',30,T-timedelta(minutes=1))
    obs=fact('2026-09-06','METAR','o1',25,T-timedelta(minutes=1))
    old=fact('2026-09-03','FORECAST','old',28,historical-timedelta(minutes=1))
    mature=(T-timedelta(days=1)).replace(hour=0)
    label=fact('2026-09-03','LABEL','label',29,mature)
    label['label_available_at']=mature.isoformat(); label=seal_fact(label)
    return [f,obs,old],[label],['2026-09-03']

class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=os.environ['QA_ROOT']); self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.bindings=load_bindings(REFS)
        self.facts={};self.labels={};self.dates={}
        for city in CITIES:self.facts[city],self.labels[city],self.dates[city]=material(city)
        self.evaluator=FrozenEvaluator(REFS,self.facts,self.labels,self.dates)
        self.store=DynamicForward(self.root,{c:x['candidate_freeze_identity'] for c,x in self.bindings.items()})
    def event(self,ident,transition='LEGAL_METAR_OR_SPECI',cause='SourceFactV1',at=T,city='Shanghai'):
        matching = [f for f in self.facts[city] if f['identity']==ident] if cause=='SourceFactV1' else []
        effective = datetime.fromisoformat(matching[0]['effective']) if matching else at
        return DynamicEvent(city,cause,ident,transition,effective)
    def test_three_city_frozen_kernel_real_time_and_independent_snapshot(self):
        for city in CITIES:
            e=self.event('open','OPEN','WindowBoundaryV1',city=city)
            record=self.store.inject(e,T,self.evaluator)
            self.assertEqual(record['status'],'OK',record)
            snapshot=verified(Path(record['snapshot_path']))
            self.assertEqual(snapshot['city'],city)
            self.assertEqual(snapshot['local_second'],'07:00:00')
            self.assertEqual(snapshot['candidate_mean'],'31')
            self.assertEqual(snapshot['baseline_output']['mean'],'29')
            self.assertEqual(sum(snapshot['quantized_candidate_probabilities_e12']),10**12)
            self.assertEqual(snapshot['training_dates'],['2026-09-03'])
            self.assertEqual(snapshot['execution_mode'],'OFFLINE_DYNAMIC_REPLAY')
        self.assertEqual(self.evaluator.model_count,3)
    def test_new_weather_revision_metar_speci_and_market_isolation(self):
        initial=self.store.inject(self.event('open','OPEN','WindowBoundaryV1'),T,self.evaluator)
        before=Path(initial['snapshot_path']).read_bytes()
        for i,kind in enumerate(('FORECAST','METAR','SPECI'),1):
            at=T+timedelta(minutes=i*30)
            row=copy.deepcopy(self.facts['Shanghai'][0 if kind=='FORECAST' else 1])
            row.update(identity='new'+str(i),revision='rev'+str(i),revision_rank=i+1,fact_type=kind,value_c='35')
            row.update({k:at.isoformat() for k in ('effective','observed','received','available','committed')})
            self.facts['Shanghai'].append(seal_fact(row))
            transition='LEGAL_FORECAST_REVISION' if kind=='FORECAST' else 'LEGAL_METAR_OR_SPECI'
            result=self.store.inject(self.event('new'+str(i),transition,at=at),at,self.evaluator)
            self.assertEqual(result['status'],'OK',result)
            snap=verified(Path(result['snapshot_path']))
            self.assertEqual(snap['local_second'],at.strftime('%H:%M:%S'))
        count=self.evaluator.model_count
        market=self.store.inject(self.event('book','MARKET_SOURCE_FACT',at=at),at,self.evaluator)
        self.assertEqual(self.evaluator.model_count,count)
        self.assertEqual(market['weather_snapshot_hash'],result['snapshot_hash'])
        self.assertEqual(Path(initial['snapshot_path']).read_bytes(),before)
    def test_stale_recovery_checkpoint_close_duplicate_and_restart(self):
        e=self.event('start','OPEN','WindowBoundaryV1')
        self.assertEqual(self.store.inject(e,T,self.evaluator)['status'],'OK')
        stale=self.event('stale','WEATHER_FRESH_TO_STALE','FreshnessBoundaryV1',T+timedelta(minutes=2))
        self.store.inject(stale,T+timedelta(minutes=2),self.evaluator)
        before=self.evaluator.model_count
        checkpoint=T.replace(hour=8)
        self.store.inject(self.event('checkpoint','UNCHANGED','NO_NEW_CAUSE_OR_STATE',checkpoint),checkpoint,self.evaluator)
        self.assertEqual(self.evaluator.model_count,before)
        recovery_fact=copy.deepcopy(self.facts['Shanghai'][1]); recovery_fact.update(identity='new',revision='new')
        recovery_fact.update({k:checkpoint.isoformat() for k in ('effective','observed','received','available','committed')})
        self.facts['Shanghai'].append(seal_fact(recovery_fact))
        recovered=self.store.inject(self.event('new',at=checkpoint),checkpoint,self.evaluator)
        self.assertEqual(recovered['status'],'OK',recovered)
        count=self.evaluator.model_count
        reopened=DynamicForward(self.root,self.store.bindings)
        self.assertTrue(reopened.inject(e,T,self.evaluator)['duplicate'])
        self.assertEqual(self.evaluator.model_count,count)
        close=T.replace(hour=16)
        self.assertFalse(self.store.inject(self.event('close','CLOSE','WindowBoundaryV1',close),close,self.evaluator)['model_call'])
        self.assertFalse(self.store.inject(self.event('late',at=close+timedelta(seconds=1)),close+timedelta(seconds=1),self.evaluator)['model_call'])
        self.assertEqual(self.evaluator.model_count,count)
    def test_freeze_and_snapshot_corruption_fail_closed(self):
        refs=json.loads(REFS.read_text(encoding='utf-8'))
        refs['candidates']['Shanghai']['identity_payload']['referenced_candidate_freeze_sha256']='0'*64
        bad=self.root/'bad.json';bad.write_text(json.dumps(refs),encoding='utf-8')
        with self.assertRaises(ValueError):load_bindings(bad)
        result=self.store.inject(self.event('o1'),T,self.evaluator)
        Path(result['snapshot_path']).write_text('{bad',encoding='utf-8')
        count=self.evaluator.model_count
        market=self.store.inject(self.event('book','MARKET_SOURCE_FACT'),T,self.evaluator)
        self.assertEqual(market['status'],'FAILURE')
        self.assertEqual(self.evaluator.model_count,count)
    def test_unknown_label_and_future_observation_cannot_create_prediction(self):
        label=dict(self.labels['Shanghai'][0]);label['committed']=None;self.labels['Shanghai']=[seal_fact(label)]
        result=self.store.inject(self.event('o1'),T,self.evaluator)
        self.assertEqual(result['status'],'FAILURE')
        self.assertEqual(self.evaluator.model_count,0)
        self.facts['Beijing'][1]=dict(self.facts['Beijing'][1])
        self.facts['Beijing'][1]['received']=(T+timedelta(minutes=5)).isoformat()
        self.facts['Beijing'][1]=seal_fact(self.facts['Beijing'][1])
        result=self.store.inject(self.event('o1',city='Beijing'),T,self.evaluator)
        self.assertEqual(result['status'],'FAILURE')
        self.assertEqual(self.evaluator.model_count,0)
    def test_actual_sqlite_reader_shape_preserves_unknown_and_source_bytes(self):
        r=self.root/'research.sqlite3';o=self.root/'observations.sqlite3'
        with closing(sqlite3.connect(r)) as c:
            c.execute('CREATE TABLE forecast_versions(version_id,city,station,source,target_date,first_seen_at,forecast_high_c,content_hash)')
            c.execute('INSERT INTO forecast_versions VALUES(?,?,?,?,?,?,?,?)',(1,'Shanghai','ZSPD','weatherol_shanghai','2026-09-06',T.isoformat(),30,'source-advertised'))
            c.commit()
        raw='METAR ZSPD synthetic'
        with closing(sqlite3.connect(o)) as c:
            c.execute('CREATE TABLE metar_observations(observation_id,city,station,report_time,received_at,report_type,temperature_c,raw_observation,raw_hash,source)')
            c.execute('INSERT INTO metar_observations VALUES(?,?,?,?,?,?,?,?,?,?)',(1,'Shanghai','ZSPD',T.isoformat(),T.isoformat(),'METAR',25,raw,hashlib.sha256(raw.encode()).hexdigest(),'aviationweather_metar'))
            c.commit()
        before=(r.read_bytes(),o.read_bytes())
        data=load_saved_city('Shanghai','2026-09-06',r,o,[])
        self.assertEqual(data['failures'],[])
        self.assertEqual(len(data['facts']),2)
        self.assertTrue(all(x['committed'] is None for x in data['facts']))
        self.assertEqual(before,(r.read_bytes(),o.read_bytes()))

if __name__=='__main__':unittest.main()
