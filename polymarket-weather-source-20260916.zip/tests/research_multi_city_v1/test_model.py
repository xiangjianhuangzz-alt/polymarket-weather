from __future__ import annotations

import unittest
from unittest.mock import patch

from tools.research_multi_city_v1.model import evaluate_population, predict, score_prediction
from tools.research_multi_city_v1 import model as model_module


def row(day: str, *, city: str = "Beijing", station: str = "ZBAA", status: str = "AVAILABLE", label: str | None = "22", available: str | None = None, **changes: object) -> dict[str, object]:
    result: dict[str, object] = {
        "city": city,
        "station": station,
        "target_date": day,
        "status": status,
        "reason": None,
        "decision_as_of_utc": f"{day}T00:00:00Z",
        "forecast_high_c": "20",
        "current_observed_max_c": "19",
        "label_final_max_c": label,
        "label_available_at_utc": available or f"{day}T16:00:00Z",
        "source_refs": [],
        "asof_checks": {},
    }
    result.update(changes)
    return result


def payload(*rows: dict[str, object], city: str = "Beijing", station: str = "ZBAA") -> dict[str, object]:
    return {"city": city, "station": station, "source": "aviationweather_taf", "candidate_days": list(rows)}


def positive_rows(*, failure: str | None = None) -> list[dict[str, object]]:
    rows = [
        row("2026-01-01", label="20", available="2026-01-02T16:00:00Z"),
        row("2026-01-03", forecast_high_c="30", current_observed_max_c="29", label="30", available="2026-01-04T16:00:00Z"),
        row("2026-01-05", forecast_high_c="31", current_observed_max_c="30", label="31", available="2026-01-06T16:00:00Z"),
        row("2026-01-07", forecast_high_c="32", current_observed_max_c="31", label="32", available="2026-01-08T16:00:00Z"),
        row("2026-01-09", forecast_high_c="33", current_observed_max_c="32", label="33", available="2026-01-10T16:00:00Z"),
    ]
    if failure == "prediction":
        rows[-1]["current_observed_max_c"] = None
    if failure == "label":
        rows[-1]["label_final_max_c"] = None
    return rows


class MultiCityResearchModelTests(unittest.TestCase):
    def test_beijing_uses_only_city_local_prior_and_preserves_quantization(self) -> None:
        result = evaluate_population(
            payload(
                row("2026-01-01", label="21", available="2026-01-02T16:00:00Z"),
                row("2026-01-03", label="22", available="2026-01-04T16:00:00Z"),
                row("2026-01-05", label="23", available="2026-01-06T16:00:00Z"),
            )
        )
        scored = result["rows"][1]
        self.assertEqual(scored["evaluation_status"], "SCORED")
        self.assertEqual(scored["training_dates"], ["2026-01-01"])
        self.assertEqual(scored["candidate_raw_count_total"], 1)
        self.assertEqual(sum(scored["candidate_quantization"]["per_bucket_ticks"]), 10**12)
        self.assertEqual(scored["evaluation_mode"], "EXPLORATORY_RETROSPECTIVE")
        self.assertNotIn("prediction_created_at_utc", scored)
        self.assertEqual(result["metrics"]["early_signal"], "INCONCLUSIVE")

    def test_guangzhou_has_its_own_station_and_model_path(self) -> None:
        first = row("2026-02-01", city="Guangzhou", station="ZGGG", label="25", available="2026-02-02T16:00:00Z")
        target = row("2026-02-03", city="Guangzhou", station="ZGGG", label="26", available="2026-02-04T16:00:00Z")
        result = evaluate_population(payload(first, target, city="Guangzhou", station="ZGGG"))
        self.assertEqual(result["city"], "Guangzhou")
        self.assertEqual(result["rows"][1]["station"], "ZGGG")
        self.assertEqual(result["rows"][1]["training_dates"], ["2026-02-01"])

    def test_cross_city_row_is_rejected_not_silently_filtered(self) -> None:
        with self.assertRaisesRegex(ValueError, "cross-city"):
            evaluate_population(payload(row("2026-01-01"), row("2026-01-03", city="Guangzhou", station="ZGGG")))

    def test_score_appends_without_repredicting_or_overwriting_status(self) -> None:
        training = row("2026-01-01", label="21", available="2026-01-02T16:00:00Z")
        target = row("2026-01-03", label="22", available="2026-01-04T16:00:00Z")
        saved = predict("Beijing", "ZBAA", target, [training])
        saved["prediction_created_at_utc"] = "2026-01-03T00:00:00Z"
        scored = score_prediction(saved, target)
        self.assertEqual(scored["status"], "PREDICTION_SAVED_AWAITING_LABEL")
        self.assertEqual(scored["evaluation_status"], "SCORED")
        self.assertEqual(scored["evaluation_mode"], "FORWARD_BLIND")
        self.assertEqual(scored["model_probabilities"], saved["model_probabilities"])

    def test_direct_predict_rejects_unmature_training_and_market_input(self) -> None:
        target = row("2026-01-03", label="22", available="2026-01-04T16:00:00Z")
        late = row("2026-01-01", label="21", available="2026-01-04T00:00:00Z")
        with self.assertRaisesRegex(ValueError, "not mature"):
            predict("Beijing", "ZBAA", target, [late])
        with self.assertRaisesRegex(ValueError, "market input"):
            predict("Beijing", "ZBAA", {**target, "yes_price": "0.9"}, [row("2026-01-01", label="21", available="2026-01-02T16:00:00Z")])

    def test_scoring_failure_preserves_saved_prediction_and_fractional_mean_is_valid(self) -> None:
        training = row("2026-01-01", label="21", available="2026-01-02T16:00:00Z")
        target = row("2026-01-03", label="22", available="2026-01-04T16:00:00Z")
        saved = predict("Beijing", "ZBAA", target, [training])
        saved.update({"prediction_created_at_utc": "2026-01-03T00:00:00Z", "model_temperature_mean_c": "20.5", "baseline_temperature_mean_c": "21.5"})
        self.assertEqual(score_prediction(saved, target)["evaluation_status"], "SCORED")
        malformed = dict(saved)
        malformed.pop("model_probabilities")
        failed = score_prediction(malformed, target)
        self.assertEqual(failed["evaluation_status"], "INPUT_OR_COMPUTATION_FAILURE")
        self.assertEqual(failed["training_count"], saved["training_count"])
        self.assertEqual(failed["status"], "PREDICTION_SAVED_AWAITING_LABEL")

    def test_unavailable_and_warmup_rows_are_preserved(self) -> None:
        result = evaluate_population(
            payload(
                row("2026-01-01", label="21", available="2026-01-03T16:00:00Z"),
                row("2026-01-02", status="MISSING", label=None, reason="missing"),
            )
        )
        self.assertEqual([item["status"] for item in result["rows"]], ["INSUFFICIENT_PRIOR_TRAINING_DATA", "MISSING"])

    def test_three_successes_are_positive_without_failure(self) -> None:
        result = evaluate_population(payload(*positive_rows()))
        self.assertEqual(result["metrics"]["scored_count"], 4)
        self.assertEqual(result["metrics"]["early_signal"], "POSITIVE")

    def test_three_successes_plus_prediction_failure_cannot_be_positive(self) -> None:
        result = evaluate_population(payload(*positive_rows(failure="prediction")))
        failed = result["rows"][-1]
        self.assertEqual(failed["evaluation_status"], "INPUT_OR_COMPUTATION_FAILURE")
        self.assertEqual(failed["training_dates"], ["2026-01-01", "2026-01-03", "2026-01-05", "2026-01-07"])
        self.assertEqual(result["metrics"]["early_signal"], "INCONCLUSIVE")
        self.assertEqual(result["metrics"]["computation_failure_days"], ["2026-01-09"])

    def test_three_successes_plus_missing_label_cannot_be_positive(self) -> None:
        result = evaluate_population(payload(*positive_rows(failure="label")))
        failed = result["rows"][-1]
        self.assertEqual(failed["status"], "INPUT_OR_COMPUTATION_FAILURE")
        self.assertIsNone(failed["training_count"])
        self.assertEqual(result["metrics"]["early_signal"], "INCONCLUSIVE")
        self.assertEqual(result["metrics"]["computation_failure_days"], ["2026-01-09"])

    def test_score_failure_preserves_prediction_and_blocks_positive_summary(self) -> None:
        training = row("2026-01-01", label="21", available="2026-01-02T16:00:00Z")
        target = row("2026-01-03", label="22", available="2026-01-04T16:00:00Z")
        saved = predict("Beijing", "ZBAA", target, [training])
        saved["prediction_created_at_utc"] = "2026-01-03T00:00:00Z"
        saved.pop("baseline_probabilities")
        failed = score_prediction(saved, target)
        self.assertEqual(failed["status"], "PREDICTION_SAVED_AWAITING_LABEL")
        self.assertEqual(failed["training_dates"], ["2026-01-01"])
        self.assertEqual(failed["evaluation_status"], "INPUT_OR_COMPUTATION_FAILURE")

    def test_score_raise_retains_current_saved_prediction_once(self) -> None:
        rows = payload(
            row("2026-01-01", label="21", available="2026-01-02T16:00:00Z"),
            row("2026-01-03", label="22", available="2026-01-04T16:00:00Z"),
        )
        with patch("tools.research_multi_city_v1.model._score_retrospective_prediction", side_effect=ValueError("score raised")):
            result = evaluate_population(rows)
        failed = result["rows"][1]
        self.assertEqual(len(result["rows"]), 2)
        self.assertEqual(failed["status"], "PREDICTION_SAVED_AWAITING_LABEL")
        self.assertEqual(failed["training_dates"], ["2026-01-01"])
        self.assertEqual(failed["evaluation_status"], "INPUT_OR_COMPUTATION_FAILURE")
        self.assertEqual(result["metrics"]["computation_failure_days"], ["2026-01-03"])

    def test_scored_result_missing_loss_retains_current_saved_prediction_once(self) -> None:
        rows = payload(
            row("2026-01-01", label="21", available="2026-01-02T16:00:00Z"),
            row("2026-01-03", label="22", available="2026-01-04T16:00:00Z"),
        )

        def incomplete(saved: dict[str, object], _: dict[str, object]) -> dict[str, object]:
            return {**saved, "evaluation_status": "SCORED"}

        with patch("tools.research_multi_city_v1.model._score_retrospective_prediction", side_effect=incomplete):
            result = evaluate_population(rows)
        failed = result["rows"][1]
        self.assertEqual(len(result["rows"]), 2)
        self.assertEqual(failed["status"], "PREDICTION_SAVED_AWAITING_LABEL")
        self.assertEqual(failed["training_count"], 1)
        self.assertEqual(failed["evaluation_status"], "INPUT_OR_COMPUTATION_FAILURE")

    def test_three_successes_plus_score_failure_cannot_be_positive(self) -> None:
        original = model_module._score_retrospective_prediction

        def score_with_last_failure(saved: dict[str, object], label_row: dict[str, object]) -> dict[str, object]:
            if saved["target_date"] == "2026-01-09":
                raise ValueError("score raised")
            return original(saved, label_row)

        with patch("tools.research_multi_city_v1.model._score_retrospective_prediction", side_effect=score_with_last_failure):
            result = evaluate_population(payload(*positive_rows()))
        failed = result["rows"][-1]
        self.assertEqual(failed["status"], "PREDICTION_SAVED_AWAITING_LABEL")
        self.assertEqual(failed["training_dates"], ["2026-01-01", "2026-01-03", "2026-01-05", "2026-01-07"])
        self.assertEqual(failed["evaluation_status"], "INPUT_OR_COMPUTATION_FAILURE")
        self.assertEqual(result["metrics"]["early_signal"], "INCONCLUSIVE")
        self.assertEqual(result["metrics"]["computation_failure_days"], ["2026-01-09"])


if __name__ == "__main__":
    unittest.main()
