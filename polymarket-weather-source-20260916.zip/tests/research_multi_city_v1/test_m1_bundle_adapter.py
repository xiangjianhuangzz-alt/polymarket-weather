from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import getcontext
from pathlib import Path

from strategy_v8.canonical import hash_v1
from tools.research_multi_city_v1.asof_input import validate_fact
from tools.research_multi_city_v1.m1_bundle_adapter import _milli, load_city_day


PROJECT = Path("D:/polymarket天气")
PROBE = PROJECT / "data/strategy_analysis/goal_formal_simulation_20260912/forward_probe_v1"
TARGET = "2026-09-12"
TEST_ROOT = Path(os.environ["QA_RUNTIME_ROOT"])


class M1BundleAdapterTests(unittest.TestCase):
    def test_real_probe_maps_all_three_cities_and_seals_facts(self):
        expected = {"Shanghai": "ZSPD", "Beijing": "ZBAA", "Guangzhou": "ZGGG"}
        for city, station in expected.items():
            result = load_city_day(PROBE, city, TARGET)
            self.assertEqual(result["station"], station)
            self.assertEqual(len(result["facts"]), 2)
            self.assertEqual([item["sequence"] for item in result["selected_bundles"]], [1, 2])
            self.assertIsNone(result["decision_as_of_utc"])
            self.assertTrue(result["read_completed_at_utc"].endswith("Z"))
            for fact in result["facts"]:
                self.assertEqual(fact["city"], city)
                self.assertEqual(fact["station"], station)
                self.assertIsNone(fact["received"])
                self.assertIsNone(fact["available"])
                validate_fact(fact, city, station)

    def test_rejects_raw_corruption_and_path_escape(self):
        with tempfile.TemporaryDirectory(dir=TEST_ROOT) as directory:
            root = Path(directory) / "probe"
            shutil.copytree(PROBE, root)
            bundle_path = root / "Shanghai" / TARGET / "commits" / "00000000000000000001.json"
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            raw_path = root / bundle["raw_blob_relative_path"]
            raw_path.write_bytes(raw_path.read_bytes() + b"x")
            with self.assertRaisesRegex(ValueError, "RAW_PAYLOAD_HASH_INVALID"):
                load_city_day(root, "Shanghai", TARGET)
            raw_path.write_bytes(raw_path.read_bytes()[:-1])
            bundle["raw_blob_relative_path"] = "../escape.bin"
            body = dict(bundle)
            body.pop("bundle_hash")
            bundle["bundle_hash"] = hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", body)
            bundle_path.write_text(json.dumps(bundle, sort_keys=True, separators=(",", ":")), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "RAW_BLOB_PATH_INVALID"):
                load_city_day(root, "Shanghai", TARGET)

    def test_rejects_bad_partition_and_future_decision_boundary(self):
        with tempfile.TemporaryDirectory(dir=TEST_ROOT) as directory:
            root = Path(directory) / "probe"
            shutil.copytree(PROBE, root)
            bundle_path = root / "Beijing" / TARGET / "commits" / "00000000000000000001.json"
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            bundle["normalized_source_fact"]["canonical_projection"]["target_date"] = "2026-09-13"
            body = dict(bundle)
            body.pop("bundle_hash")
            bundle["bundle_hash"] = hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", body)
            bundle_path.write_text(json.dumps(bundle, sort_keys=True, separators=(",", ":")), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "NORMALIZED_PROJECTION_HASH_INVALID"):
                load_city_day(root, "Beijing", TARGET)
        with self.assertRaisesRegex(ValueError, "READ_BOUNDARY_AFTER_DECISION_ASOF"):
            load_city_day(PROBE, "Shanghai", TARGET, datetime.now(timezone.utc) - timedelta(seconds=1))

    def test_recomputes_writer_contract_and_raw_projection_with_context_safe_milli(self):
        prior = getcontext().prec
        getcontext().prec = 1
        try:
            self.assertEqual(_milli(12345), "12.345")
        finally:
            getcontext().prec = prior
        with tempfile.TemporaryDirectory(dir=TEST_ROOT) as directory:
            root = Path(directory) / "probe"
            shutil.copytree(PROBE, root)
            bundle_path = root / "Guangzhou" / TARGET / "commits" / "00000000000000000001.json"
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            bundle["normalized_source_fact"]["normalization_contract_hash"] = "0" * 64
            normalized = bundle["normalized_source_fact"]
            normalized["normalized_fact_id"] = hash_v1("PWM.IIC2.NORMALIZED_SOURCE_FACT.V1", {key: normalized[key] for key in ("source_fact_id", "normalization_contract_hash", "projection_kind", "canonical_projection_hash")})
            body = dict(bundle); body.pop("bundle_hash")
            bundle["bundle_hash"] = hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", body)
            bundle_path.write_text(json.dumps(bundle, sort_keys=True, separators=(",", ":")), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "NORMALIZATION_CONTRACT_HASH_INVALID"):
                load_city_day(root, "Guangzhou", TARGET)
