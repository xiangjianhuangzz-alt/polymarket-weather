"""Synthetic-only forward checks; every case owns a fresh explicit fixture root."""
from datetime import date, datetime, timedelta, timezone
from contextlib import closing
import importlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from tools.research_multi_city_v1 import forward, inputs, market, model
from tools.research_forward_collection_v1.daily import PublicResponse, anchor, save, sha, verified_load

RUN = Path(os.environ.get("RUN_SCOPE", "D:/polymarket天气/data/strategy_analysis/wp03_multi_city_p1_closeout_fast_signal_v1/20260905T203601+0800")).resolve()
UTC = timezone.utc
TARGET = date(2026, 9, 6)


def row(city, station, day):
    return {"city": city, "station": station, "source": "aviationweather_taf", "target_date": day.isoformat(), "status": "AVAILABLE",
            "decision_as_of_utc": anchor(day).isoformat(), "forecast_high_c": "30", "current_observed_max_c": "28",
            "label_final_max_c": "31", "label_available_at_utc": inputs.window(day)[3].isoformat()}


class ForwardTests(unittest.TestCase):
    def setUp(self):
        runtime = Path(os.environ.get("QA_ROOT", str(RUN / "implementation_runtime"))).resolve()
        if RUN not in runtime.parents:
            raise ValueError("QA_ROOT_OUTSIDE_AUTHORIZED_RUN")
        runtime.mkdir(parents=True, exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="forward_", dir=runtime)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def test_authoritative_station_mapping_and_wrong_station_rejected(self):
        inputs.identity("Beijing", "ZBAA")
        inputs.identity("Guangzhou", "ZGGG")
        with self.assertRaises(ValueError):
            inputs.identity("Beijing", "ZGGG")

    def databases(self, city="Beijing", station="ZBAA"):
        research, observations = self.root / "research.sqlite3", self.root / "observations.sqlite3"
        with closing(sqlite3.connect(research)) as db, db:
            db.execute("CREATE TABLE forecast_d0_registry(source,city,station,target_date,grid_version,forecast_high_c,source_reported_at,first_captured_at,content_hash,status)")
            db.execute("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?)", ("aviationweather_taf",city,station,str(TARGET),"grid","30","2026-09-05T21:00:00Z","2026-09-05T22:00:00Z","synthetic-forecast","valid_d0"))
        with closing(sqlite3.connect(observations)) as db, db:
            db.execute("CREATE TABLE metar_observations(observation_id,station,city,report_time,received_at,report_type,temperature_c,raw_observation,raw_hash,source)")
            start = inputs.window(TARGET)[0]
            for i in range(48):
                report = start + timedelta(minutes=30*i)
                db.execute("INSERT INTO metar_observations VALUES (?,?,?,?,?,?,?,?,?,?)", (i,station,city,report.isoformat(),(report+timedelta(seconds=2)).isoformat(),"METAR",28+i%4,"synthetic","synthetic-"+str(i),"aviationweather_metar"))
        return research, observations

    def test_city_snapshot_read_only_asof_and_label_maturity(self):
        research, observations = self.databases()
        before = [sha(research), sha(observations)]
        weather = inputs.snapshot("Beijing", "ZBAA", TARGET, research, observations)
        self.assertEqual(len(weather["observations"]), 16)
        self.assertNotIn("label_final_max_c", weather)
        self.assertFalse(set(model.MARKET_FIELDS).intersection(weather))
        with self.assertRaisesRegex(ValueError, "NOT_MATURE"):
            inputs.label("Beijing", "ZBAA", TARGET, observations, anchor(TARGET))
        label = inputs.label("Beijing", "ZBAA", TARGET, observations, inputs.window(TARGET)[3])
        self.assertEqual(label["label_final_max_c"], "31")
        self.assertEqual(before, [sha(research), sha(observations)])

    def test_forecast_future_issue_rejected(self):
        research, observations = self.databases()
        with closing(sqlite3.connect(research)) as db, db:
            db.execute("UPDATE forecast_d0_registry SET source_reported_at='2026-09-06T00:01:00Z'")
        with self.assertRaisesRegex(ValueError, "ASOF"):
            inputs.snapshot("Beijing", "ZBAA", TARGET, research, observations)

    def response(self, seconds=60, quantity="1"):
        when = anchor(TARGET)-timedelta(seconds=seconds)
        raw = {"market":"condition", "asset_id":"123", "timestamp":str(int(when.timestamp()*1000)),
               "asks":[{"price":str((i+1)/10),"size":quantity} for i in range(7)]}
        return PublicResponse("https://clob.polymarket.com/book?token_id=123",when.isoformat(),when.isoformat(),200,json.dumps(raw).encode())

    def member(self, city):
        return {"city":city,"market_id":"1","condition_id":"condition","yes_token_id":"123","rule":"synthetic","ordinal":0}

    def test_each_city_full_ladder_five_shares_and_hash(self):
        for city in ("Beijing", "Guangzhou"):
            response = self.response()
            record = market.book_record(self.root/city, self.member(city), response, TARGET, "partition")
            self.assertEqual(record["status"], "AVAILABLE")
            self.assertEqual(record["ladder_levels"], 7)
            self.assertEqual(record["execution_feasibility"]["vwap"], "0.3")
            metadata = json.loads(Path(record["frame"]["record_path"]).read_text())
            self.assertEqual(metadata["city"], city)
            self.assertEqual(Path(record["frame"]["record_path"]).with_suffix(".raw").read_bytes(), response.body)
            self.assertEqual(len(metadata["yes_asks"]),7)

    def test_freshness_sixty_inclusive_late_and_unfillable_kept(self):
        for index, (seconds,quantity,expected) in enumerate([(60,"1","AVAILABLE"),(61,"1","STALE"),(-1,"1","STALE"),(10,"0.1","UNFILLABLE")]):
            record = market.book_record(self.root/str(index),self.member("Beijing"),self.response(seconds,quantity),TARGET,"partition")
            self.assertEqual(record["status"],expected)
            self.assertTrue((self.root/str(index)/"record.json").is_file())

    def test_wrong_city_event_or_book_identity_not_accepted(self):
        with self.assertRaises(ValueError):
            market.members({"id":"1","slug":market.slug("Guangzhou",TARGET),"markets":[{}]},"Beijing",TARGET)
        member=self.member("Beijing"); member["yes_token_id"]="999"
        record=market.book_record(self.root/"wrong",member,self.response(),TARGET,"partition")
        self.assertEqual(record["status"],"ERROR")
        self.assertTrue((self.root/"wrong/http/response.raw").exists())

    def test_immutable_prediction_and_d2_score_append_without_reprediction(self):
        config={"city":"Beijing","station":"ZBAA","observation_db_path":"unused"}
        day=self.root/"days"/str(TARGET)
        weather=row("Beijing","ZBAA",TARGET)
        for name in ("label_final_max_c","label_available_at_utc"):
            weather.pop(name)
        save(day/"weather_input.json",weather)
        prediction=model.predict("Beijing","ZBAA",weather,[row("Beijing","ZBAA",date(2026,9,3))])
        prediction.update(execution_mode="FORWARD_BLIND",prediction_created_at_utc=anchor(TARGET).isoformat())
        save(day/"prediction.json",prediction)
        before=sha(day/"prediction.json")
        with self.assertRaises(FileExistsError):
            save(day/"prediction.json",{"different":True})
        actual=row("Beijing","ZBAA",TARGET)
        with patch.object(model,"predict",side_effect=AssertionError("must never repredict")):
            early=forward.append_scores(self.root,config,anchor(TARGET),self.root/"early",lambda *a: actual)
            self.assertEqual(early,[])
            self.assertFalse((day/"score.json").exists())
            forward.append_scores(self.root,config,inputs.window(TARGET)[3],self.root/"mature",lambda *a: actual)
            score_hash=sha(day/"score.json")
            forward.append_scores(self.root,config,inputs.window(TARGET)[3],self.root/"repeat",lambda *a: actual)
        self.assertEqual(verified_load(day/"score.json")["evaluation_status"],"SCORED")
        self.assertEqual(before,sha(day/"prediction.json"))
        self.assertEqual(score_hash,sha(day/"score.json"))

    def test_imports_are_offline_and_paths_are_separate(self):
        with patch("urllib.request.OpenerDirector.open",side_effect=AssertionError("network forbidden")), patch("subprocess.Popen",side_effect=AssertionError("process forbidden")):
            importlib.reload(inputs)
            importlib.reload(market)
            importlib.reload(forward)
        roots=[self.root/city/"forward" for city in ("beijing","guangzhou")]
        save(roots[0]/"prediction.json",{"failure":"retained"})
        save(roots[1]/"prediction.json",{"success":"retained"})
        self.assertNotEqual(sha(roots[0]/"prediction.json"),sha(roots[1]/"prediction.json"))


if __name__ == "__main__":
    unittest.main()
