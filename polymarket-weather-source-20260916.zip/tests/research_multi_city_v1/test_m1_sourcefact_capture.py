import json
import os
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from tools.research_multi_city_v1 import m1_sourcefact_capture as capture


TAF = [{"icaoId":"ZBAA","issueTime":"2026-09-05T21:01:00.000Z",
        "validTimeFrom":1788652800,
        "rawTAF":"TAF ZBAA 052101Z 0600/0706 CAVOK TX32/0606Z TX29/0706Z"}]
METAR = [{"icaoId":"ZBAA","reportTime":"2026-09-05T22:30:00.000Z",
          "metarType":"METAR","temp":21,"rawOb":"METAR ZBAA 052230Z CAVOK 21/19 Q1015"}]
STAMP = datetime(2026, 9, 5, 22, 40, tzinfo=timezone.utc)
WEATHEROL = {"code":200,"data":{"current":{"current":{"jcid":"JCCN100117",
             "airportname":"上海浦东国际机场","reporttime":"06:15"}},
             "forecast15d":[{"forecasttime":"09/06","temperature_am":"30"}]}}


class SourceFactCaptureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=os.environ["QA_ROOT"])
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_taf_commit_is_exact_immutable_and_idempotent(self):
        raw = json.dumps(TAF, separators=(",", ":")).encode()
        with patch.object(capture, "_get", return_value=(raw, STAMP)), patch.object(capture, "_now", return_value=STAMP):
            first = capture.capture_taf(self.root, "Beijing", "ZBAA", "2026-09-06")
            second = capture.capture_taf(self.root, "Beijing", "ZBAA", "2026-09-06")
        self.assertEqual(first, second)
        fact = first["raw_source_fact"]
        self.assertEqual(fact["effective_at_utc"], "2026-09-05T21:01:00.000000Z")
        self.assertEqual(first["normalized_source_fact"]["canonical_projection"]["forecast_high_c_milli"], 32000)
        self.assertEqual((self.root / first["raw_blob_relative_path"]).read_bytes(), raw)
        self.assertEqual(len(list((self.root / "Beijing/2026-09-06/commits").glob("*.json"))), 1)

    def test_same_natural_key_changed_payload_fails_closed(self):
        raw = json.dumps(TAF, separators=(",", ":")).encode()
        changed = json.dumps([{**TAF[0], "rawTAF": TAF[0]["rawTAF"] + " AMD"}], separators=(",", ":")).encode()
        with patch.object(capture, "_get", return_value=(raw, STAMP)), patch.object(capture, "_now", return_value=STAMP):
            capture.capture_taf(self.root, "Beijing", "ZBAA", "2026-09-06")
        with patch.object(capture, "_get", return_value=(changed, STAMP)), patch.object(capture, "_now", return_value=STAMP):
            with self.assertRaisesRegex(ValueError, "E_SOURCE_FACT_ID_CONFLICT"):
                capture.capture_taf(self.root, "Beijing", "ZBAA", "2026-09-06")

    def test_metar_exact_time_query_and_projection(self):
        discovery = json.dumps(METAR).encode()
        exact = json.dumps(METAR, separators=(",", ":")).encode()
        calls = []
        def fetch(path, params):
            calls.append((path, params))
            return (discovery if "hours" in params else exact), STAMP
        with patch.object(capture, "_get", side_effect=fetch), patch.object(capture, "_now", return_value=STAMP):
            bundle = capture.capture_latest_metar(self.root, "Beijing", "ZBAA", "2026-09-06")
        self.assertEqual(calls[1][1]["date"], METAR[0]["reportTime"])
        fact = bundle["raw_source_fact"]
        self.assertEqual(fact["effective_at_utc"], "2026-09-05T22:30:00.000000Z")
        self.assertEqual(bundle["normalized_source_fact"]["canonical_projection"]["temperature_c_milli"], 21000)

    def test_response_cardinality_and_station_fail_closed(self):
        with self.assertRaisesRegex(ValueError, "CARDINALITY"):
            capture._one_json(b"[]", "ZBAA")
        with self.assertRaisesRegex(ValueError, "STATION"):
            capture._one_json(b'[{"icaoId":"ZGGG"}]', "ZBAA")

    def test_store_verifier_checks_waterline_and_raw_bytes(self):
        raw = json.dumps(TAF, separators=(",", ":")).encode()
        with patch.object(capture, "_get", return_value=(raw, STAMP)), patch.object(capture, "_now", return_value=STAMP):
            capture.capture_taf(self.root, "Beijing", "ZBAA", "2026-09-06")
        self.assertEqual(capture.verify_store(self.root)["bundle_count"], 1)
        blob = next((self.root / "raw_blobs").glob("*.bin"))
        blob.write_bytes(b"corrupt")
        with self.assertRaisesRegex(ValueError, "RAW_PAYLOAD_HASH_INVALID"):
            capture.verify_store(self.root)

    def test_weatherol_frozen_minute_identity_and_d0_projection(self):
        raw = json.dumps(WEATHEROL, ensure_ascii=False, separators=(",", ":")).encode()
        with patch.object(capture, "_get_url", return_value=(raw, STAMP)), patch.object(capture, "_now", return_value=STAMP):
            bundle = capture.capture_weatherol_shanghai(self.root, "2026-09-06")
        fact = bundle["raw_source_fact"]
        self.assertEqual(fact["source_revision_rank"], 375)
        self.assertEqual(fact["effective_at_utc"], "2026-09-05T22:15:00.000000Z")
        self.assertEqual(bundle["normalized_source_fact"]["canonical_projection"]["forecast_high_c_milli"], 30000)


if __name__ == "__main__":
    unittest.main()
