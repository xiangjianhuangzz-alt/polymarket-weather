from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
from datetime import date
from decimal import localcontext
from pathlib import Path

from strategy_v8.contracts import City
from tools.research_multi_city_v1.formal_weather_bridge import (
    _capture_revision,
    _observation_milli,
    bridge_city_day,
    receipt_hash,
    receipt_payload,
)


PROJECT = Path("D:/polymarket天气")
PROBE = PROJECT / "data/strategy_analysis/goal_formal_simulation_20260912/forward_probe_v1"
TARGET = date(2026, 9, 12)
RUNTIME = Path(os.environ["QA_RUNTIME_ROOT"])


def receipt_for(root: Path, city: str, decision: str) -> dict[str, object]:
    entries = []
    for sequence, path in enumerate(sorted((root / city / TARGET.isoformat() / "commits").glob("*.json")), 1):
        bundle = json.loads(path.read_text(encoding="utf-8"))
        raw = bundle["raw_source_fact"]
        entries.append({"sequence": sequence, "bundle_hash": bundle["bundle_hash"], "raw_payload_hash": raw["raw_payload_hash"], "canonical_payload_hash": raw["canonical_payload_hash"]})
    payload = receipt_payload(city, TARGET.isoformat(), "2026-09-11T23:00:00.000000Z", tuple(entries))
    return {**payload, "receipt_hash": receipt_hash(payload)}


class FormalWeatherBridgeTests(unittest.TestCase):
    def test_all_cities_create_formal_inputs_with_capture_provenance(self):
        for city, capture_city, station in ((City.SHANGHAI, "Shanghai", "ZSPD"), (City.BEIJING, "Beijing", "ZBAA"), (City.GUANGZHOU, "Guangzhou", "ZGGG")):
            result = bridge_city_day(PROBE, city, TARGET, "2026-09-11T23:00:00.000000Z", receipt_for(PROBE, capture_city, ""))
            self.assertEqual(len(result.forecasts), 1)
            self.assertEqual(len(result.observations), 1)
            self.assertEqual(result.observations[0].station, station)
            self.assertEqual(result.forecasts[0].local_second, 7 * 3600)
            self.assertEqual(result.forecasts[0].source_publication_id, result.provenance[0]["formal_source_publication_id"])
            self.assertNotEqual(result.provenance[0]["capture_source_fact_id"], result.provenance[0]["formal_source_fact_id"])

    def test_rejects_missing_or_tampered_receipt_and_window(self):
        receipt = receipt_for(PROBE, "Shanghai", "")
        missing = dict(receipt); missing["entries"] = []
        with self.assertRaisesRegex(ValueError, "BRIDGE_RECEIPT_HASH_INVALID"):
            bridge_city_day(PROBE, City.SHANGHAI, TARGET, "2026-09-11T23:00:00.000000Z", missing)
        late_source = receipt_for(PROBE, "Shanghai", "")
        payload = receipt_payload("Shanghai", TARGET.isoformat(), "2026-09-12T00:00:00.000000Z", tuple(late_source["entries"]))
        late = {**payload, "receipt_hash": receipt_hash(payload)}
        with self.assertRaisesRegex(ValueError, "BRIDGE_RECEIPT_AFTER_DECISION"):
            bridge_city_day(PROBE, City.SHANGHAI, TARGET, "2026-09-11T23:00:00.000000Z", late)
        with self.assertRaisesRegex(ValueError, "BRIDGE_DECISION_WINDOW_INVALID"):
            bridge_city_day(PROBE, City.SHANGHAI, TARGET, "2026-09-11T22:59:59.000000Z", receipt)

    def test_receipt_must_follow_each_capture_observation_and_commit(self):
        valid = receipt_for(PROBE, "Shanghai", "")
        payload = receipt_payload("Shanghai", TARGET.isoformat(), "2026-09-10T00:00:00.000000Z", tuple(valid["entries"]))
        early = {**payload, "receipt_hash": receipt_hash(payload)}
        with self.assertRaisesRegex(ValueError, "BRIDGE_RECEIPT_PRECEDES_CAPTURE"):
            bridge_city_day(PROBE, City.SHANGHAI, TARGET, "2026-09-11T23:00:00.000000Z", early)

    def test_rejects_capture_publication_and_cross_city_tamper(self):
        with tempfile.TemporaryDirectory(dir=RUNTIME) as directory:
            root = Path(directory) / "probe"; shutil.copytree(PROBE, root)
            path = root / "Shanghai" / TARGET.isoformat() / "commits" / "00000000000000000001.json"
            bundle = json.loads(path.read_text(encoding="utf-8")); bundle["raw_source_fact"]["source_publication_id"] = "0" * 64
            body = dict(bundle); body.pop("bundle_hash"); from strategy_v8.canonical import hash_v1
            bundle["bundle_hash"] = hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", body)
            path.write_text(json.dumps(bundle, separators=(",", ":")), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "BRIDGE_CAPTURE_SOURCE_FACT_INVALID"):
                bridge_city_day(root, City.SHANGHAI, TARGET, "2026-09-11T23:00:00.000000Z", receipt_for(root, "Shanghai", ""))
        with self.assertRaisesRegex(ValueError, "BRIDGE_RECEIPT_SCOPE_INVALID"):
            bridge_city_day(PROBE, City.BEIJING, TARGET, "2026-09-11T23:00:00.000000Z", receipt_for(PROBE, "Shanghai", ""))

    def test_same_input_is_stable_and_formal_projection_is_decision_local(self):
        receipt = receipt_for(PROBE, "Beijing", "")
        first = bridge_city_day(PROBE, City.BEIJING, TARGET, "2026-09-12T00:30:00.000000Z", receipt)
        second = bridge_city_day(PROBE, City.BEIJING, TARGET, "2026-09-12T00:30:00.000000Z", receipt)
        self.assertEqual(first, second)
        self.assertEqual(first.forecasts[0].local_second, 8 * 3600 + 30 * 60)
        self.assertNotEqual(first.provenance[0]["capture_normalized_fact_id"], first.provenance[0]["formal_normalized_fact_id"])

    def test_rejects_raw_hash_and_capture_projection_tamper(self):
        with tempfile.TemporaryDirectory(dir=RUNTIME) as directory:
            root = Path(directory) / "probe"; shutil.copytree(PROBE, root)
            bundle_path = root / "Beijing" / TARGET.isoformat() / "commits" / "00000000000000000001.json"
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            raw_path = root / bundle["raw_blob_relative_path"]
            raw_path.write_bytes(raw_path.read_bytes() + b"x")
            with self.assertRaisesRegex(ValueError, "BRIDGE_RAW_HASH_INVALID"):
                bridge_city_day(root, City.BEIJING, TARGET, "2026-09-11T23:00:00.000000Z", receipt_for(root, "Beijing", ""))
        with tempfile.TemporaryDirectory(dir=RUNTIME) as directory:
            root = Path(directory) / "probe"; shutil.copytree(PROBE, root)
            bundle_path = root / "Guangzhou" / TARGET.isoformat() / "commits" / "00000000000000000001.json"
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            bundle["normalized_source_fact"]["canonical_projection"]["forecast_high_c_milli"] = 1
            body = dict(bundle); body.pop("bundle_hash"); from strategy_v8.canonical import hash_v1
            bundle["bundle_hash"] = hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", body)
            bundle_path.write_text(json.dumps(bundle, separators=(",", ":")), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "BRIDGE_CAPTURE_PROJECTION_INVALID"):
                bridge_city_day(root, City.GUANGZHOU, TARGET, "2026-09-11T23:00:00.000000Z", receipt_for(root, "Guangzhou", ""))

    def test_rejects_unknown_nested_schema_before_projection(self):
        with tempfile.TemporaryDirectory(dir=RUNTIME) as directory:
            root = Path(directory) / "probe"; shutil.copytree(PROBE, root)
            path = root / "Shanghai" / TARGET.isoformat() / "commits" / "00000000000000000001.json"
            bundle = json.loads(path.read_text(encoding="utf-8"))
            bundle["raw_source_fact"]["raw_payload_encoding"] = "UNKNOWN"
            body = dict(bundle); body.pop("bundle_hash")
            from strategy_v8.canonical import hash_v1
            bundle["bundle_hash"] = hash_v1("PWM.M1.SOURCEFACT.COMMIT.BUNDLE.V1", body)
            path.write_text(json.dumps(bundle, separators=(",", ":")), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "BRIDGE_CAPTURE_SCHEMA_INVALID"):
                bridge_city_day(root, City.SHANGHAI, TARGET, "2026-09-11T23:00:00.000000Z", receipt_for(root, "Shanghai", ""))

    def test_observation_number_and_capture_revision_are_exact_before_adapter(self):
        with localcontext() as context:
            context.prec = 2
            self.assertEqual(_observation_milli(25.345), 25345)
            self.assertEqual(_observation_milli(0), 0)
            self.assertEqual(_observation_milli(-1.25), -1250)
        with self.assertRaisesRegex(ValueError, "BRIDGE_OBSERVATION_TEMPERATURE_INVALID"):
            _observation_milli(True)
        bundle_path = PROBE / "Beijing" / TARGET.isoformat() / "commits" / "00000000000000000001.json"
        bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
        raw = json.loads((PROBE / bundle["raw_blob_relative_path"]).read_text(encoding="utf-8"))
        invalid = dict(bundle["raw_source_fact"])
        invalid["source_revision_rank"] += 1
        with self.assertRaisesRegex(ValueError, "BRIDGE_CAPTURE_REVISION_INVALID"):
            _capture_revision(invalid, "Beijing", "FORECAST", raw, TARGET.isoformat())
