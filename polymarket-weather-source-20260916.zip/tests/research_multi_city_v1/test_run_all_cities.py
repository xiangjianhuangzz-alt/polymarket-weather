import json
import os
import shutil
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from tools.research_multi_city_v1.run_all_cities import CITIES, PYTHON_EXECUTABLE, RUN_SCOPE, SHANGHAI_CONFIG, run_all

ROOT = Path(os.environ.get("QA_ROOT", str(RUN_SCOPE / "runtime"))).resolve()


class FakeProcess:
    def __init__(self, pid, exit_code, events):
        self.pid, self.exit_code, self.events = pid, exit_code, events

    def wait(self):
        self.events.append(("wait", self.pid))
        return self.exit_code


class Ticks:
    def __init__(self):
        self.value = 0

    def __call__(self):
        self.value += 1
        return datetime(2026, 1, 1, 0, 0, self.value, tzinfo=timezone.utc)


class MultiCityTests(unittest.TestCase):
    def setUp(self):
        if RUN_SCOPE not in ROOT.parents and ROOT != RUN_SCOPE:
            raise ValueError("QA_ROOT_OUTSIDE_RUN_SCOPE")
        ROOT.mkdir(parents=True, exist_ok=True)
        self.root, self.configs = Path(tempfile.mkdtemp(dir=ROOT)), None
        self.configs = self.root / "configs"
        self.configs.mkdir()
        for city, entry in (("Shanghai", "tools.research_forward_collection_v1.daily"), ("Beijing", "tools.research_multi_city_v1.forward"), ("Guangzhou", "tools.research_multi_city_v1.forward")):
            target = SHANGHAI_CONFIG if city == "Shanghai" else self.root / f"{city.lower()}_config.json"
            if city != "Shanghai":
                target.write_text(json.dumps({"city": city, "output_root": str(self.root / city)}))
            (self.configs / f"{city.lower()}.json").write_text(json.dumps({"city": city, "entrypoint": entry, "config_path": str(target)}))

    def tearDown(self):
        shutil.rmtree(self.root)

    def test_all_launches_precede_wait_and_logs_are_unique_closed(self):
        events, streams = [], []
        def popen(command, **kwargs):
            events.append(("launch", command[-2]))
            streams.extend((kwargs["stdout"], kwargs["stderr"]))
            return FakeProcess(len(events), 1 if "beijing" in command[-2] else 0, events)
        result = run_all(self.configs, self.root / "out", datetime(2025, 12, 31, 23, 59, tzinfo=timezone.utc), popen, Ticks())
        self.assertEqual([item[0] for item in events[:3]], ["launch"] * 3)
        self.assertEqual([item[0] for item in events[3:]], ["wait"] * 3)
        self.assertEqual(result["cities"]["Beijing"]["status"], "EXIT_NONZERO")
        self.assertEqual([record["command"][0] for record in result["cities"].values()], [str(PYTHON_EXECUTABLE)] * 3)
        self.assertTrue(all(stream.closed for stream in streams))
        self.assertEqual(len({record["started_at"] for record in result["cities"].values()}), 3)
        self.assertTrue(all(record["ended_at"] >= record["started_at"] for record in result["cities"].values()))
        paths = [record[stream] for record in result["cities"].values() for stream in ("stdout", "stderr")]
        self.assertEqual(len(paths), len(set(paths)))

    def test_config_and_spawn_errors_preserve_all_city_results(self):
        (self.configs / "beijing.json").unlink()
        def popen(command, **kwargs):
            if "guangzhou" in command[-2]:
                raise OSError("guangzhou_start_failed")
            return FakeProcess(7, 0, [])
        result = run_all(self.configs, self.root / "out", datetime(2025, 12, 31, 23, 59, tzinfo=timezone.utc), popen, Ticks())
        self.assertEqual(set(result["cities"]), set(CITIES))
        self.assertEqual(result["cities"]["Shanghai"]["status"], "EXIT_0")
        self.assertEqual(result["cities"]["Beijing"]["status"], "START_ERROR")
        self.assertEqual(result["cities"]["Guangzhou"]["status"], "START_ERROR")
        self.assertTrue(all(Path(result["cities"][city][stream]).is_file() for city in ("Beijing", "Guangzhou") for stream in ("stdout", "stderr")))

    def test_window_and_naive_time_rejected_without_launch(self):
        for value in (datetime(2025, 12, 31, 23, 57, tzinfo=timezone.utc), datetime(2026, 1, 1, 0, 0, tzinfo=timezone.utc), datetime(2026, 1, 1, 7, 59)):
            with self.assertRaises(ValueError):
                run_all(self.configs, self.root / "out", value, lambda *args, **kwargs: self.fail("must_not_launch"))


if __name__ == "__main__":
    unittest.main()
