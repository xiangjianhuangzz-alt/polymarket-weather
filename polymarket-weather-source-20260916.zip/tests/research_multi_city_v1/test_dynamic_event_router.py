"""Synthetic contracts; all filesystem fixtures stay in explicit QA_ROOT."""
import copy
import os
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from tools.research_multi_city_v1.dynamic_event_router import DynamicEvent, LOCAL, ROUTES, route
from tools.research_multi_city_v1.dynamic_forward import DynamicForward, decision_window_id, verified, TIMES

BINDINGS = {'Shanghai':'a'*64,'Beijing':'b'*64,'Guangzhou':'c'*64}
T = datetime(2026,9,6,7,0,12,tzinfo=LOCAL)

def draft(event, t):
    def fact(identity, moment):
        return {'city':event.city,'identity':identity,'hash':'d'*64,**{k:moment for k in TIMES}}
    forecast=fact('forecast',t);forecast['revision']='revision1'
    training=fact('train',t-timedelta(days=3))
    training.update(target_date='2026-09-03',local_second=t.strftime('%H:%M:%S'),label_available_at=t-timedelta(days=1))
    return {'target_date':'2026-09-06','candidate_freeze_identity':BINDINGS[event.city],
        'runtime_event_id':'e'*64,'forecast':forecast,'observations':[fact('metar',t)],'training':[training],
        'raw_candidate_probabilities':['1']+['0']*51,'quantized_candidate_probabilities_e12':[10**12]+[0]*51,
        'candidate_mean':'30','baseline_output':{'raw_probabilities':['1']+['0']*51,'ticks':[10**12]+[0]*51,'mean':'30'}}

class DynamicTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=Path(os.environ['QA_ROOT']))
        self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.forward=DynamicForward(self.root,BINDINGS)
    def event(self, cause='SourceFactV1', transition='LEGAL_FORECAST_REVISION', ident='r1', city='Shanghai', t=T):
        return DynamicEvent(city,cause,ident,transition,t)
    def test_frozen_actions_and_boundaries(self):
        for i, ((cause,transition),expected) in enumerate(ROUTES.items()):
            effective=T.replace(hour=7,minute=0,second=0) if transition=='OPEN' else T.replace(hour=16,minute=0,second=0) if transition=='CLOSE' else T
            with self.subTest(transition=transition):
                self.assertEqual(route(self.event(cause,transition,str(i),t=effective),max(effective,T)),expected)
        self.assertEqual(route(self.event(t=T.replace(hour=16)),T.replace(hour=16)),'FAIL_CLOSED')
        self.assertEqual(route(self.event(t=T.replace(hour=6)),T.replace(hour=6)),'FAIL_CLOSED')
        self.assertIsNone(route(self.event('NO_NEW_CAUSE_OR_STATE','SAFETY'),T))
    def test_actual_open_duplicate_restart_and_immutable_snapshot(self):
        e=self.event('WindowBoundaryV1','OPEN',t=T.replace(second=0))
        first=self.forward.inject(e,T,draft);self.assertEqual(first['action'],'INITIAL_WEATHER_EVALUATION')
        self.assertEqual(first['status'],'OK')
        saved=Path(first['snapshot_path']);before=saved.read_bytes()
        self.assertIn('23:00:12',verified(saved)['evaluation_asof_utc'])
        self.assertFalse(DynamicForward(self.root,BINDINGS).inject(e,T,draft)['model_call'])
        second=self.forward.inject(self.event(ident='r2'),T+timedelta(minutes=1),draft)
        self.assertEqual(second['status'],'OK');self.assertEqual(saved.read_bytes(),before)
        self.assertNotEqual(first['snapshot_path'],second['snapshot_path'])
    def test_market_reference_stale_and_city_isolation(self):
        first=self.forward.inject(self.event(),T,draft)
        market=self.forward.inject(self.event(transition='MARKET_SOURCE_FACT',ident='book'),T)
        self.assertFalse(market['model_call']);self.assertEqual(market['weather_snapshot_hash'],first['snapshot_hash'])
        self.forward.inject(self.event('FreshnessBoundaryV1','WEATHER_FRESH_TO_STALE','stale'),T)
        market=self.forward.inject(self.event(transition='MARKET_SOURCE_FACT',ident='book2'),T)
        self.assertIsNone(market['weather_snapshot_hash'])
        other=self.forward.inject(self.event(city='Beijing'),T,draft)
        self.assertEqual(verified(Path(other['snapshot_path']))['city'],'Beijing')
        self.assertNotEqual(other['decision_window_id'],first['decision_window_id'])
    def test_failure_recovery_and_version_lock(self):
        self.forward.inject(self.event('SystemFailureTransitionV1','SYSTEM_FAILURE','fail'),T)
        self.assertFalse(self.forward.inject(self.event(),T,draft)['model_call'])
        recovered=self.forward.inject(self.event('SystemFailureTransitionV1','RECOVERY','recover'),T)
        self.assertFalse(recovered['model_call'])
        self.assertEqual(self.forward.inject(self.event(ident='new'),T,draft)['status'],'OK')
        self.forward.inject(self.event('ConfigIdentityChangeV1','CONFIG_CHANGE','config'),T)
        self.forward.inject(self.event('SystemFailureTransitionV1','RECOVERY','recover2'),T)
        self.assertEqual(self.forward.inject(self.event(ident='new2'),T,draft)['action'],'FAIL_CLOSED_VERSION_MISMATCH')
    def test_bad_inputs_are_retained_not_snapshots(self):
        mutations=[
            lambda d:d['forecast'].update(received=T+timedelta(seconds=1)),
            lambda d:d['forecast'].pop('committed'),
            lambda d:d['training'][0].update(city='Beijing'),
            lambda d:d['training'][0].update(local_second='08:00:00'),
            lambda d:d['training'][0].update(label_available_at=T+timedelta(days=1)),
            lambda d:d.update(raw_candidate_probabilities=[]),
        ]
        for i, mutate in enumerate(mutations):
            def evaluator(e,t):
                result=draft(e,t);mutate(result);return result
            result=self.forward.inject(self.event(ident=str(i)),T,evaluator)
            self.assertEqual(result['status'],'FAILURE');self.assertNotIn('snapshot_path',result)
        self.assertEqual(len(list(self.root.glob('Shanghai/*/events/*.json'))),len(mutations))
    def test_checkpoint_is_not_window_open_or_model_call(self):
        t=T.replace(hour=8)
        result=self.forward.inject(self.event(transition='MARKET_SOURCE_FACT',ident='book',t=t),t)
        self.assertFalse(result['model_call'])
        checkpoint=self.root/'Shanghai'/'2026-09-06'/'BENCHMARK_CHECKPOINT_0800.json'
        self.assertFalse(verified(checkpoint)['fixed_0800_prediction_generated'])
        self.assertEqual(decision_window_id('Shanghai','2026-09-06','a'*64),decision_window_id('Shanghai','2026-09-06','a'*64))

if __name__=='__main__': unittest.main()
