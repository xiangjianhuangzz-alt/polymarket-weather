"""Offline contract tests; fixtures may only be rooted under QA_ROOT/RUN_SCOPE."""
import os
import unittest
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from tools.research_multi_city_v1.population import (
    CITIES, candidate, coverage, date_set_payload, parse, window,
)


class PopulationContractTests(unittest.TestCase):
    def setUp(self):
        self.qa_root = Path(os.environ["QA_ROOT"])
        self.run_scope = os.environ["RUN_SCOPE"]
        self.fixture_root = self.qa_root / self.run_scope

    def test_authoritative_city_station_map_and_china_window(self):
        self.assertEqual(CITIES, {"Beijing": "ZBAA", "Guangzhou": "ZGGG"})
        start, anchor, end, freeze = window(date(2026, 9, 6))
        self.assertEqual((anchor - start).total_seconds(), 28800)
        self.assertEqual((freeze - end).total_seconds(), 86400)

    def test_parse_accepts_utc_and_china_offset_as_same_instant(self):
        self.assertEqual(parse("2026-09-05T00:00:00Z"), parse("2026-09-05T08:00:00+08:00"))

    def test_parse_rejects_naive_malformed_and_invalid_offset(self):
        for value in ("2026-09-05T08:00:00", "not-a-time", "2026-09-05T08:00:00+99:00", "2026-09-05T08:00:00+08:60", "2026-09-05T08:00:00-00:60", "2026-09-05T08:00:00+24:00"):
            with self.subTest(value=value):
                with self.assertRaises(ValueError): parse(value)

    def test_coverage_requires_30_minute_edges_and_5400_gap(self):
        start = datetime(2026, 9, 5, 16, tzinfo=timezone.utc)
        end = datetime(2026, 9, 6, 16, tzinfo=timezone.utc)
        rows = [{"report_time_utc": "2026-09-05T16:30:00Z"}, {"report_time_utc": "2026-09-06T15:30:00Z"}]
        self.assertEqual(coverage(rows, start, end), (False, 82800))

    def test_date_sets_preserve_observation_only_date_and_differences(self):
        payload = date_set_payload({"forecast": {date(2026, 9, 1)}, "observation": {date(2026, 9, 2)}, "label": set(), "evidence": {date(2026, 9, 3)}})
        self.assertEqual(payload["union"], ["2026-09-01", "2026-09-02", "2026-09-03"])
        self.assertEqual(payload["differences_from_union"]["forecast"], ["2026-09-02", "2026-09-03"])

    def test_related_invalid_time_fails_closed_even_with_normal_observation(self):
        start = datetime(2026, 9, 5, 16, tzinfo=timezone.utc)
        normal = {"source_fact_id": "normal", "temperature_c": "30", "time_parse_records": [{"field": "report_time", "original_value": "2026-09-05T16:00:00Z", "parse_status": "OK", "parse_reason": None}]}
        invalid = {"source_fact_id": "bad", "time_parse_records": [{"field": "received_at", "original_value": "naive", "parse_status": "INVALID", "parse_reason": "TIME_NAIVE"}]}
        result = candidate("fixture", ({"forecast": "30"}, None, None), [normal, invalid], [], start, start + timedelta(days=1), start + timedelta(days=3))
        self.assertEqual(result["status"], "UNPROVABLE")
        self.assertEqual(result["reason"], "RELEVANT_OBSERVATION_TIME_PARSE_INVALID")
        self.assertEqual(result["asof_checks"]["time_parse_records"][0]["original_value"], "naive")


if __name__ == "__main__":
    unittest.main()
