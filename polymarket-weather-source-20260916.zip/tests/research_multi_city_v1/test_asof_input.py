import unittest
from datetime import datetime, timezone
from tools.research_multi_city_v1.asof_input import WeatherFact, strict_asof
class StrictAsofTests(unittest.TestCase):
 def test_unknown_and_future_fail_closed(self):
  t=datetime(2026,8,30,tzinfo=timezone.utc); f=WeatherFact('Shanghai','07:00:00',t,t,t,t,None)
  with self.assertRaises(ValueError): strict_asof(f,'Shanghai','07:00:00',t)
