"""Synthetic-only focused tests. QA_ROOT is explicitly assigned by the run harness."""
from dataclasses import asdict
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from tools.research_forward_collection_v1 import daily
from tools.research_forward_collection_v1.weather_inputs import ForecastInput, WeatherSnapshot, MatureWeatherLabel

QA_ROOT = None
TARGET = date(2026, 9, 6)
ANCHOR = daily.anchor(TARGET)


def synthetic_weather():
    forecast = ForecastInput("Shanghai", "ZSPD", "weatherol_shanghai", str(TARGET), "grid", 30,
                             None, None, daily.stamp(ANCHOR - timedelta(hours=1)),
                             daily.stamp(ANCHOR - timedelta(hours=1)), "f" * 64, "forecast-id")
    return WeatherSnapshot(str(TARGET), daily.stamp(ANCHOR), forecast, 25, (), "a" * 64, None, False, False, False)


def synthetic_training():
    return [{"target_date": f"2026-09-0{i}", "status": "AVAILABLE", "forecast_high_c": "30",
             "label_final_max_c": str(30 + i), "label_available_at_utc": daily.stamp(daily.runner._d_plus_2_freeze(date(2026, 9, i)))} for i in (1, 2, 3)]


def synthetic_event(count=2):
    return {"id": "event", "slug": daily.event_slug(TARGET), "markets": [
        {"id": str(i), "conditionId": f"condition{i}", "groupItemTitle": str(i),
         "description": "synthetic rule", "question": "synthetic Shanghai temperature",
         "outcomes": '["No","Yes"]', "clobTokenIds": json.dumps([str(100 + i), str(200 + i)])} for i in range(1, count + 1)]}


class Clock:
    def __init__(self):
        self.value = ANCHOR - timedelta(minutes=2)

    def now(self):
        return self.value

    def sleep(self, seconds):
        self.value += timedelta(seconds=seconds)


class DailyTests(unittest.TestCase):
    def setUp(self):
        if QA_ROOT is None:
            raise RuntimeError("QA_ROOT must be explicitly supplied by the run harness")
        self.fixture = tempfile.TemporaryDirectory(dir=QA_ROOT, prefix="daily_")
        self.root = Path(self.fixture.name)
        self.addCleanup(self.fixture.cleanup)
        self.freeze = {"freeze_id": "SYNTHETIC_ONLY", "model_source_hashes": {},
                       "population_path": str(self.root / "population.json")}
        daily.save(self.freeze["population_path"], {"candidate_days": synthetic_training()})
        self.config = {"output_root": str(self.root), "research_db_path": str(self.root / "unused.sqlite"),
                       "observation_db_path": str(self.root / "unused2.sqlite"), "freeze_sha256": "synthetic"}

    def response(self, book=None, age=30, received_offset=-20):
        when = ANCHOR - timedelta(seconds=age)
        if book is None:
            book = {"market": "condition1", "asset_id": "201", "timestamp": str(int(when.timestamp() * 1000)),
                    "asks": [{"price": str(Decimal(i) / 100), "size": "1"} for i in range(10, 17)]}
        return daily.PublicResponse("https://clob.polymarket.com/book?token_id=201", daily.stamp(ANCHOR - timedelta(seconds=25)),
                                    daily.stamp(ANCHOR + timedelta(seconds=received_offset)), 200, json.dumps(book).encode())

    def test_market_population_keeps_actual_members_and_rejects_duplicates(self):
        event = synthetic_event(13)
        rows = daily.discover_markets(event, TARGET)
        self.assertEqual(len(rows), 13)
        self.assertEqual([r["ordinal"] for r in rows], list(range(13)))
        event["markets"][1]["clobTokenIds"] = event["markets"][0]["clobTokenIds"]
        self.assertTrue(all(r["identity_error"] == "POPULATION_DUPLICATE_IDENTITY" for r in daily.discover_markets(event, TARGET)))
        with self.assertRaisesRegex(ValueError, "EVENT_TARGET"):
            daily.discover_markets(event, TARGET + timedelta(days=1))

    def test_full_ladder_raw_hash_and_five_share_fill(self):
        member = daily.discover_markets(synthetic_event(), TARGET)[0]
        response = self.response()
        result = daily.save_book(self.root / "market", member, response, TARGET, "partition")
        self.assertEqual(result["status"], "AVAILABLE")
        self.assertEqual(result["ladder_levels"], 7)
        self.assertEqual(result["execution_feasibility"]["vwap"], "0.12")
        self.assertEqual((self.root / "market/http/response.raw").read_bytes(), response.body)
        self.assertEqual(result["snapshot_sha256"], daily.sha(self.root / "market/http/response.raw"))

    def test_source_and_receive_freshness_and_exact_sixty_boundary(self):
        member = daily.discover_markets(synthetic_event(), TARGET)[0]
        for name, age, offset, expected in [("boundary", 60, -20, "AVAILABLE"), ("old", 61, -20, "STALE"),
                                             ("future", -1, -20, "STALE"), ("late", 30, 1, "STALE")]:
            with self.subTest(name=name):
                result = daily.save_book(self.root / name, member, self.response(age=age, received_offset=offset), TARGET, "partition")
                self.assertEqual(result["status"], expected)

    def test_invalid_identity_and_missing_depth_keep_raw_failure(self):
        member = daily.discover_markets(synthetic_event(), TARGET)[0]
        for name, update in [("wrong", {"asset_id": "999"}), ("bbo", {"asks": None}), ("missing_time", {"timestamp": None})]:
            with self.subTest(name=name):
                book = json.loads(self.response().body)
                book.update(update)
                response = self.response(book=book)
                result = daily.save_book(self.root / name, member, response, TARGET, "partition")
                self.assertEqual(result["status"], "ERROR")
                self.assertEqual((self.root / name / "http/response.raw").read_bytes(), response.body)

    def test_insufficient_quantity_is_unfillable_not_extrapolated(self):
        book = json.loads(self.response().body)
        book["asks"] = book["asks"][:2]
        member = daily.discover_markets(synthetic_event(), TARGET)[0]
        result = daily.save_book(self.root / "short", member, self.response(book=book), TARGET, "partition")
        self.assertEqual(result["status"], "UNFILLABLE")
        self.assertIsNone(result["execution_feasibility"]["vwap"])

    def test_exclusive_save_and_hash_tampering_fail_closed(self):
        path = self.root / "immutable.json"
        identity = daily.save(path, {"original": 1})
        self.assertEqual(daily.verified_load(path), {"original": 1})
        for value in ({"original": 1}, {"different": 2}):
            with self.assertRaises(FileExistsError):
                daily.save(path, value)
        self.assertEqual(daily.sha(path), identity)
        path.write_text("{}", encoding="utf-8")  # deliberately corrupt only this synthetic fixture
        with self.assertRaisesRegex(ValueError, "HASH_MISMATCH"):
            daily.verified_load(path)

    def test_only_declared_public_get_and_no_redirect(self):
        with patch.object(daily, "build_opener") as network:
            for url in ("https://clob.polymarket.com/order", "https://evil.example/book", "http://clob.polymarket.com/book"):
                with self.assertRaises(ValueError):
                    daily.public_get(url)
            network.assert_not_called()
        with self.assertRaisesRegex(ValueError, "REDIRECT_DISABLED"):
            daily.NoRedirect().redirect_request(None, None, 302, "", {}, "https://evil.example")

    def test_prediction_uses_same_prior_dates_and_symmetric_frozen_quantization(self):
        rows = synthetic_training()
        rows.append(dict(rows[-1], target_date="2026-09-05", label_available_at_utc="2026-09-06T16:00:00Z"))
        prediction = daily.make_prediction(synthetic_weather(), rows, self.freeze, ANCHOR)
        self.assertEqual(prediction["training_dates"], [r["target_date"] for r in rows[:3]])
        self.assertEqual(prediction["training_count"], 3)
        self.assertEqual(prediction["status"], "PREDICTION_SAVED_AWAITING_LABEL")
        for name in ("model_quantization", "baseline_quantization"):
            q = prediction[name]
            self.assertEqual(q["research_quantization_policy_id"], "STAGE1A_LARGEST_REMAINDER_E12_V1")
            self.assertEqual(sum(q["per_bucket_ticks"]), 10**12)
            self.assertEqual(sum(map(Decimal, q["research_quantized_probability_vector"])), Decimal(1))

    def test_d2_score_never_calls_prediction_and_retains_original(self):
        prediction = daily.make_prediction(synthetic_weather(), synthetic_training(), self.freeze, ANCHOR)
        before = json.dumps(prediction, sort_keys=True)
        maturity = daily.runner._d_plus_2_freeze(TARGET).astimezone(timezone.utc)
        label = SimpleNamespace(target_date=str(TARGET), label_available_at_utc=daily.stamp(maturity), final_max_c=32)
        with patch.object(daily, "make_prediction", side_effect=AssertionError("reprediction")), patch.object(daily.runner, "research_probability_from_samples", side_effect=AssertionError("model called during scoring")):
            with self.assertRaises(ValueError):
                daily.score_record(prediction, label, maturity - timedelta(microseconds=1))
            score = daily.score_record(prediction, label, maturity)
        self.assertEqual(score["evaluation_status"], "SCORED")
        self.assertEqual(json.dumps(prediction, sort_keys=True), before)
        for key, value in prediction.items():
            self.assertEqual(score[key], value)

    def test_outside_window_records_failure_without_network_or_weather(self):
        clock = lambda: ANCHOR + timedelta(seconds=1)
        fetch, weather = Mock(side_effect=AssertionError()), Mock(side_effect=AssertionError())
        with patch.object(daily, "validate_config", return_value=(self.root, self.freeze)):
            result = daily.run_daily(self.config, TARGET, clock=clock, fetch=fetch, weather_reader=weather)
        self.assertEqual(result["status"], "CAPTURE_FAILURE")
        self.assertEqual(len(list((self.root / "attempts").glob("*/result.json"))), 1)
        fetch.assert_not_called(); weather.assert_not_called()

    def test_market_failure_does_not_delete_prediction_and_repeat_never_repredicts(self):
        clock = Clock()
        weather = Mock(return_value=synthetic_weather())
        with patch.object(daily, "validate_config", return_value=(self.root, self.freeze)), patch.object(daily, "capture_market", return_value={"status": "MARKET_MISSING"}):
            result = daily.run_daily(self.config, TARGET, clock.now, clock.sleep, weather_reader=weather)
            path = self.root / "days" / str(TARGET) / "prediction.json"
            identity = daily.sha(path)
            self.assertEqual(result["status"], "PREDICTION_COMPLETE")
            self.assertEqual(result["market"]["status"], "MARKET_MISSING")
            self.assertEqual(result["FORWARD_BLIND_SCORING_DAYS"], 0)
            clock.value = ANCHOR - timedelta(minutes=1)
            duplicate = daily.run_daily(self.config, TARGET, clock.now, clock.sleep, weather_reader=weather)
        self.assertEqual(duplicate["reason"], "DAY_ALREADY_RESERVED_NO_REPREDICTION")
        self.assertEqual(daily.sha(path), identity)
        self.assertEqual(weather.call_count, 1)

    def test_mature_label_adds_training_even_when_prediction_failed(self):
        day = self.root / "days" / str(TARGET)
        daily.save(day / "weather_input.json", asdict(synthetic_weather()))
        prediction = daily.make_prediction(synthetic_weather(), synthetic_training(), self.freeze, ANCHOR)
        prediction.update(status="INPUT_OR_COMPUTATION_FAILURE", reason="synthetic failure")
        identity = daily.save(day / "prediction.json", prediction)
        maturity = daily.runner._d_plus_2_freeze(TARGET).astimezone(timezone.utc)
        label = MatureWeatherLabel(str(TARGET), daily.stamp(maturity), 32, (), "l" * 64, "start", "end", 1800)
        rows = daily.append_mature_scores(self.root, self.root / "unused.sqlite", maturity, self.root / "attempt1", lambda *args: label)
        self.assertEqual([r["target_date"] for r in rows], [str(TARGET)])
        self.assertEqual(daily.forward_metrics(self.root)["FORWARD_BLIND_SCORING_DAYS"], 0)
        self.assertEqual(daily.sha(day / "prediction.json"), identity)

    def test_freeze_and_quantity_mismatch_reject(self):
        config = daily.load(daily.RESEARCH / "wp03_forward_blind_accumulation_v1/20260905T184548+0800/forward_config.json")
        config["freeze_sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "FREEZE_IDENTITY"):
            daily.validate_config(config)
        config["market"]["requested_yes_quantity"] = "6"
        with self.assertRaisesRegex(ValueError, "MARKET_CONFIG"):
            daily.validate_config(config)
