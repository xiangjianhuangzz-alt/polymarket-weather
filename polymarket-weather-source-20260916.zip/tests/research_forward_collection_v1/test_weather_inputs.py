from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from pathlib import Path
import sqlite3
import tempfile
import unittest

from tools.research_forward_collection_v1.weather_inputs import mature_label, snapshot_weather


UTC = timezone.utc
QA_RUNTIME_ROOT = Path("data/strategy_analysis/wp03_forward_blind_accumulation_v1/20260905T184548+0800/qa_runtime/data")


def stamp(value: datetime) -> str:
    return value.isoformat(timespec="microseconds").replace("+00:00", "Z")


class WeatherInputsTests(unittest.TestCase):
    def setUp(self) -> None:
        QA_RUNTIME_ROOT.mkdir(parents=True, exist_ok=True)
        self.root = Path(tempfile.mkdtemp(dir=QA_RUNTIME_ROOT))
        self.research = self.root / "research.sqlite3"
        self.observations = self.root / "observations.sqlite3"
        self.target = date(2026, 9, 6)
        self.start = datetime(2026, 9, 5, 16, tzinfo=UTC)
        self.anchor = datetime(2026, 9, 6, 0, tzinfo=UTC)
        self.end = datetime(2026, 9, 6, 16, tzinfo=UTC)
        self.freeze = datetime(2026, 9, 7, 16, tzinfo=UTC)
        self._schema()

    def _schema(self) -> None:
        with sqlite3.connect(self.research) as db:
            db.execute("CREATE TABLE forecast_d0_registry (source TEXT, city TEXT, station TEXT, target_date TEXT, grid_version TEXT, status TEXT, forecast_high_c REAL, source_reported_at TEXT, first_captured_at TEXT, content_hash TEXT, reason TEXT, frozen_at TEXT, latest_checked_at TEXT)")
        with sqlite3.connect(self.observations) as db:
            db.execute("CREATE TABLE metar_observations (observation_id INTEGER PRIMARY KEY, station TEXT, city TEXT, report_time TEXT, received_at TEXT, report_type TEXT, temperature_c REAL, raw_observation TEXT, raw_hash TEXT, source TEXT)")

    def _forecast(self, first: datetime | None = None) -> None:
        with sqlite3.connect(self.research) as db:
            db.execute("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", ("weatherol_shanghai", "Shanghai", "ZSPD", self.target.isoformat(), "weatherol-airport:ZSPD", "valid_d0", 31.5, stamp(self.start), stamp(first or self.start), "f" * 64, None, stamp(self.start), stamp(self.start)))

    def _observation(self, ordinal: int, report: datetime, temperature: float, received: datetime | None = None) -> None:
        with sqlite3.connect(self.observations) as db:
            db.execute("INSERT INTO metar_observations VALUES (?,?,?,?,?,?,?,?,?,?)", (ordinal, "ZSPD", "Shanghai", stamp(report), stamp(received or report + timedelta(minutes=5)), "METAR", temperature, f"METAR-{ordinal}", f"{ordinal:064x}", "aviationweather_metar"))

    def _complete_day(self) -> None:
        for ordinal in range(49):
            self._observation(ordinal + 1, self.start + timedelta(minutes=30 * ordinal), 20 + ordinal / 10)

    def test_snapshot_is_read_only_and_preserves_asof_fact_identity(self) -> None:
        self._forecast()
        self._observation(1, self.start, 28.0)
        self._observation(2, self.start + timedelta(hours=4), 31.0)
        self._observation(3, self.anchor, 99.0)
        snapshot = snapshot_weather(self.target, self.research, self.observations)
        self.assertEqual(snapshot.current_observed_max_c, 31.0)
        self.assertEqual(len(snapshot.observations), 2)
        self.assertEqual(snapshot.forecast.effective_at_utc, None)
        self.assertEqual(snapshot.forecast.observed_at_utc, stamp(self.start))
        self.assertTrue(snapshot.forecast.source_fact_id)
        self.assertTrue(snapshot.observation_set_hash)
        with sqlite3.connect(self.observations) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM metar_observations").fetchone()[0], 3)

    def test_snapshot_does_not_apply_label_coverage_as_an_admission_gate(self) -> None:
        self._forecast()
        self._observation(1, self.start + timedelta(hours=1), 27.0)
        snapshot = snapshot_weather(self.target, self.research, self.observations)
        self.assertEqual(snapshot.current_observed_max_c, 27.0)
        self.assertFalse(snapshot.coverage_first_within_30m)

    def test_snapshot_accepts_existing_plus_zero_zero_storage_timestamps(self) -> None:
        self._forecast()
        with sqlite3.connect(self.observations) as db:
            db.execute("INSERT INTO metar_observations VALUES (?,?,?,?,?,?,?,?,?,?)", (1, "ZSPD", "Shanghai", self.start.isoformat(), (self.start + timedelta(minutes=5)).isoformat(), "METAR", 28.0, "METAR-1", "a" * 64, "aviationweather_metar"))
        snapshot = snapshot_weather(self.target, self.research, self.observations)
        self.assertEqual(snapshot.current_observed_max_c, 28.0)
        self.assertEqual(len(snapshot.observations), 1)

    def test_snapshot_fails_closed_for_missing_or_late_forecast(self) -> None:
        with self.assertRaisesRegex(ValueError, "forecast_d0_missing"):
            snapshot_weather(self.target, self.research, self.observations)
        self._forecast(self.anchor + timedelta(microseconds=1))
        with self.assertRaisesRegex(ValueError, "forecast_not_visible_by_decision_asof"):
            snapshot_weather(self.target, self.research, self.observations)

    def test_snapshot_fails_closed_when_current_observation_is_missing(self) -> None:
        self._forecast()
        with self.assertRaisesRegex(ValueError, "current_observation_at_anchor_missing"):
            snapshot_weather(self.target, self.research, self.observations)

    def test_mature_label_requires_freeze_and_complete_raw_coverage(self) -> None:
        self._complete_day()
        with self.assertRaisesRegex(ValueError, "label_not_mature"):
            mature_label(self.target, self.observations, self.freeze - timedelta(microseconds=1))
        label = mature_label(self.target, self.observations, self.freeze)
        self.assertEqual(label.final_max_c, 24.7)
        self.assertEqual(label.maximum_gap_seconds, 1800)
        self.assertEqual(len(label.observations), 48)
        self.assertEqual(label.label_available_at_utc, stamp(self.freeze))

    def test_mature_label_excludes_late_received_rows_and_fails_closed(self) -> None:
        self._observation(1, self.start, 25.0, self.freeze + timedelta(microseconds=1))
        with self.assertRaisesRegex(ValueError, "label_observation_missing"):
            mature_label(self.target, self.observations, self.freeze)


if __name__ == "__main__":
    unittest.main()
