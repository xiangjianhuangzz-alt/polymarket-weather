from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import json
import tempfile
import unittest

from tools.research_forward_collection_v1.collector import CaptureMode, CaptureStatus, CaptureStore, FrameInput, YesAsk, capture_once


ASKS = tuple(YesAsk(f"0.{value}", "10") for value in (10, 20, 30, 40, 50))
TEST_STORAGE_ROOT = Path("data/strategy_analysis/wp03_forward_collection_v1/20260905T143455+0800/test_fixture_storage")


def valid_frame(**changes: object) -> FrameInput:
    frame = FrameInput(
        source_frame_id="source-frame-001",
        raw_frame_bytes=b'{"complete":true,"yes_asks":5}',
        city="Shanghai",
        target_date="2026-09-06",
        market_family="POLYMARKET_TEMPERATURE",
        partition_source="PUBLISHED_UNIVERSE_V1",
        market_id="market-001",
        yes_token_id="yes-001",
        rule_hash="a" * 64,
        captured_at_utc="2026-09-06T00:00:00Z",
        received_at_utc="2026-09-06T00:00:01Z",
        source_timestamp_utc=None,
        first_visible_at_utc=None,
        frame_kind="FULL_DEPTH",
        complete=True,
        upstream_truncated=False,
        yes_asks=ASKS,
        requested_yes_quantity="5",
    )
    return replace(frame, **changes)


class ForwardResearchCollectorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.capture_ordinal = 0
        TEST_STORAGE_ROOT.mkdir(parents=True, exist_ok=True)
        self.test_root = Path(tempfile.mkdtemp(prefix=f"{self._testMethodName}_", dir=TEST_STORAGE_ROOT))

    def new_capture_root(self) -> Path:
        self.capture_ordinal += 1
        return Path(tempfile.mkdtemp(prefix=f"capture_{self.capture_ordinal}_", dir=self.test_root))

    def run_capture(self, *frames: FrameInput):
        root = self.new_capture_root()
        results = capture_once(CaptureMode.OFFLINE_TEST, CaptureStore(root), frames)
        records = [json.loads(path.read_text(encoding="utf-8")) for path in sorted((root / "frames").glob("*.json"))]
        return results, records, (root / "manifest.jsonl").read_text(encoding="utf-8"), root

    def test_complete_raw_frame_and_atomic_identity_are_saved(self) -> None:
        results, records, manifest, root = self.run_capture(valid_frame())
        self.assertEqual(results[0]["capture_status"], CaptureStatus.ACCEPTED.value)
        self.assertEqual(len(records), 1)
        record = records[0]
        self.assertEqual(record["city"], "Shanghai")
        self.assertEqual(record["market_id"], "market-001")
        self.assertEqual(record["yes_token_id"], "yes-001")
        self.assertEqual(record["capture_status"], CaptureStatus.ACCEPTED.value)
        self.assertEqual(len(record["yes_asks"]), 5)
        self.assertTrue(record["raw_payload_sha256"])
        self.assertEqual((root / "frames" / f"{record['frame_id']}.raw").read_bytes(), valid_frame().raw_frame_bytes)
        self.assertTrue(record["frame_id"] in manifest)
        self.assertFalse(record["automatic_deletion"])

    def test_mode_is_explicit_and_only_offline_executes(self) -> None:
        store = CaptureStore(self.new_capture_root())
        for mode in (CaptureMode.CAPTURE_ONCE, CaptureMode.CONTINUOUS_COLLECTION):
            with self.assertRaisesRegex(RuntimeError, "OFFLINE_TEST"):
                capture_once(mode, store, (valid_frame(),))

    def test_qualification_and_save_are_separate_for_rejections(self) -> None:
        rejected = valid_frame(frame_kind="BBO")
        results, records, _, _ = self.run_capture(rejected)
        self.assertEqual(results[0]["capture_status"], CaptureStatus.REJECTED_BBO.value)
        self.assertEqual(records[0]["capture_status"], CaptureStatus.REJECTED_BBO.value)

    def test_bbo_heartbeat_partial_and_inconsistent_are_rejected(self) -> None:
        cases = (
            (valid_frame(frame_kind="BBO"), CaptureStatus.REJECTED_BBO),
            (valid_frame(frame_kind="HEARTBEAT"), CaptureStatus.REJECTED_HEARTBEAT),
            (valid_frame(upstream_truncated=True), CaptureStatus.REJECTED_PARTIAL),
            (valid_frame(city="Other"), CaptureStatus.REJECTED_INCONSISTENT),
        )
        for frame, expected in cases:
            results, _, _, _ = self.run_capture(frame)
            self.assertEqual(results[0]["capture_status"], expected.value)

    def test_missing_future_and_stale_are_rejected(self) -> None:
        cases = (
            (valid_frame(yes_token_id=None), CaptureStatus.REJECTED_MISSING),
            (valid_frame(captured_at_utc="2026-09-06T00:00:01Z"), CaptureStatus.REJECTED_FUTURE),
            (valid_frame(captured_at_utc="2026-09-05T23:58:59Z"), CaptureStatus.REJECTED_STALE),
        )
        for frame, expected in cases:
            results, _, _, _ = self.run_capture(frame)
            self.assertEqual(results[0]["capture_status"], expected.value)

    def test_full_ladder_preserves_more_than_five_levels_and_five_share_vwap(self) -> None:
        full_ladder = tuple(YesAsk(f"0.{value}", "1") for value in (10, 20, 30, 40, 50, 60))
        accepted = valid_frame(captured_at_utc="2026-09-05T23:59:00Z", yes_asks=full_ladder, requested_yes_quantity="5")
        partial = valid_frame(source_frame_id="source-frame-002", complete=False, yes_asks=())
        results, records, _, _ = self.run_capture(accepted, partial)
        self.assertEqual(results[0]["capture_status"], CaptureStatus.ACCEPTED.value)
        self.assertEqual(results[1]["capture_status"], CaptureStatus.REJECTED_PARTIAL.value)
        full_record = next(record for record in records if record["source_frame_id"] == accepted.source_frame_id)
        self.assertEqual(full_record["yes_asks"], [{"price": item.price, "size": item.size} for item in full_ladder])
        self.assertEqual(full_record["execution_feasibility"], {"requested_yes_quantity": "5", "fillable": True, "vwap": "0.30"})

    def test_optional_source_and_first_visible_are_not_fabricated(self) -> None:
        first_results, records, _, first_root = self.run_capture(valid_frame())
        second_results, _, _, second_root = self.run_capture(valid_frame())
        self.assertNotEqual(first_root, second_root)
        self.assertEqual(first_results[0]["capture_status"], CaptureStatus.ACCEPTED.value)
        self.assertEqual(second_results[0]["capture_status"], CaptureStatus.ACCEPTED.value)
        self.assertIsNone(records[0]["source_timestamp_utc"])
        self.assertIsNone(records[0]["first_visible_at_utc"])

    def test_duplicate_different_payload_is_retained_without_overwrite(self) -> None:
        first = valid_frame()
        second = valid_frame(raw_frame_bytes=b'{"complete":true,"yes_asks":5,"revision":2}')
        results, records, manifest, root = self.run_capture(first, second)
        self.assertEqual(results[0]["capture_status"], CaptureStatus.ACCEPTED.value)
        self.assertEqual(results[1]["capture_status"], CaptureStatus.DUPLICATE_DIFFERENT_PAYLOAD.value)
        self.assertEqual(len(records), 2)
        self.assertEqual(len(manifest.strip().splitlines()), 2)
        for record in records:
            raw = (root / "frames" / f"{record['frame_id']}.raw").read_bytes()
            self.assertEqual(__import__("hashlib").sha256(raw).hexdigest(), record["raw_payload_sha256"])

    def test_duplicate_same_payload_does_not_overwrite(self) -> None:
        frame = valid_frame()
        results, records, manifest, _ = self.run_capture(frame, frame)
        self.assertEqual(results[1]["capture_status"], CaptureStatus.DUPLICATE_SAME_PAYLOAD.value)
        self.assertEqual(len(records), 1)
        self.assertEqual(len(manifest.strip().splitlines()), 1)


if __name__ == "__main__":
    unittest.main()
