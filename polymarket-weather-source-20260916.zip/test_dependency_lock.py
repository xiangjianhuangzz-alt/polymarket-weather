from __future__ import annotations

from importlib import metadata
from pathlib import Path
import re
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parent
PIN = re.compile(r"([A-Za-z0-9_.-]+)==([^\s]+)")


class DependencyLockTests(unittest.TestCase):
    def test_runtime_requirements_use_only_the_reviewed_lock(self) -> None:
        self.assertEqual((ROOT / "requirements.txt").read_text(encoding="utf-8").strip(),
                         "-r requirements.lock")
        lines = [line.strip() for line in (ROOT / "requirements.lock").read_text(encoding="utf-8").splitlines()
                 if line.strip() and not line.lstrip().startswith("#")]
        self.assertTrue(lines)
        self.assertTrue(all(PIN.fullmatch(line) for line in lines))
        names = [PIN.fullmatch(line).group(1).lower().replace("_", "-") for line in lines]
        self.assertEqual(len(names), len(set(names)))

    def test_installed_runtime_matches_lock_and_dependency_graph_is_consistent(self) -> None:
        for line in (ROOT / "requirements.lock").read_text(encoding="utf-8").splitlines():
            match = PIN.fullmatch(line.strip())
            if match:
                self.assertEqual(metadata.version(match.group(1)), match.group(2), match.group(1))
        result = subprocess.run(
            [sys.executable, "-m", "pip", "check"], text=True, encoding="utf-8",
            capture_output=True, timeout=60, check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
