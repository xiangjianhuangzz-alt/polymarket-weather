"""Crash-safe, process-scoped instance locks for runtime writers.

The lock is held by an operating-system file lock for the lifetime of the
process.  The small lock file deliberately remains on disk after release; the
kernel lock, not file existence or a PID stored in the file, is authoritative.
This avoids stale-PID and PID-reuse failures after a hard process termination.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import BinaryIO


BASE = Path(__file__).resolve().parent
LOCK_DIR = BASE / "data" / "runtime" / "locks"
DUPLICATE_INSTANCE_EXIT = 73


class AlreadyRunningError(RuntimeError):
    """Raised when another process already owns a runtime instance lock."""


class InstanceLock:
    """Hold a non-blocking exclusive OS lock until ``release`` is called."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._handle: BinaryIO | None = None

    @property
    def acquired(self) -> bool:
        return self._handle is not None

    def acquire(self) -> "InstanceLock":
        if self._handle is not None:
            return self
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.path.open("a+b")
        try:
            if handle.seek(0, os.SEEK_END) == 0:
                handle.write(b"\0")
                handle.flush()
                os.fsync(handle.fileno())
            handle.seek(0)
            if os.name == "nt":
                import msvcrt

                try:
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                except OSError as exc:
                    raise AlreadyRunningError(f"instance lock already held: {self.path.name}") from exc
            else:  # pragma: no cover - Windows is the production platform.
                import fcntl

                try:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                except OSError as exc:
                    raise AlreadyRunningError(f"instance lock already held: {self.path.name}") from exc
        except BaseException:
            handle.close()
            raise
        self._handle = handle
        return self

    def release(self) -> None:
        handle, self._handle = self._handle, None
        if handle is None:
            return
        try:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:  # pragma: no cover - Windows is the production platform.
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()

    def __enter__(self) -> "InstanceLock":
        return self.acquire()

    def __exit__(self, _exc_type, _exc, _traceback) -> None:
        self.release()


def writer_lock(service: str, *, lock_dir: Path | None = None) -> InstanceLock:
    """Return the authoritative writer lock for one approved service name."""
    if not service or any(part in service for part in ("/", "\\", "..")):
        raise ValueError("service must be a simple service name")
    directory = Path(lock_dir) if lock_dir is not None else LOCK_DIR
    return InstanceLock(directory / f"{service}.writer.lock")


def guardian_lock(service: str, *, lock_dir: Path | None = None) -> InstanceLock:
    """Return the independent guardian lock for one approved service name."""
    if not service or any(part in service for part in ("/", "\\", "..")):
        raise ValueError("service must be a simple service name")
    directory = Path(lock_dir) if lock_dir is not None else LOCK_DIR
    return InstanceLock(directory / f"{service}.guardian.lock")
