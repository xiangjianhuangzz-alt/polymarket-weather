import asyncio
import json
import sqlite3
import tempfile
import threading
import time
import unittest
from contextlib import closing
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

import collector
import realtime_stream as stream


class _FakeWebSocket:
    def __init__(self):
        self.sent = []

    async def send(self, value):
        self.sent.append(value)


class _FailingWebSocket(_FakeWebSocket):
    async def send(self, value):
        raise ConnectionError("send failed")


class _BlockedWebSocket(_FakeWebSocket):
    async def send(self, value):
        self.sent.append(value)
        await asyncio.Event().wait()


class MarketProtocolShadowTests(unittest.IsolatedAsyncioTestCase):
    async def test_market_rules_are_fetched_once_in_one_batch(self):
        response = Mock()
        response.raise_for_status.return_value = None
        response.json.return_value = [{
            "asset_id": "token", "market": "condition",
            "tick_size": "0.01", "min_order_size": "5",
            "neg_risk": False, "hash": "book-hash",
        }]
        client = Mock()
        client.post = AsyncMock(return_value=response)
        writer = Mock()
        writer.submit_market_rules.return_value = True

        result = await stream.fetch_market_rules(
            writer, {"token": "local-market"}, client=client
        )

        self.assertEqual(result["token"]["min_order_size"], "5")
        client.post.assert_awaited_once()
        writer.submit_market_rules.assert_called_once()
        self.assertEqual(
            writer.submit_market_rules.call_args.kwargs["market_id"],
            "local-market",
        )

    async def test_official_text_heartbeat_is_bounded_and_observational(self):
        protocol = stream.MarketProtocolShadow(ping_interval=10, pong_stale_seconds=30)
        socket = _FakeWebSocket()
        protocol.on_connect()

        self.assertTrue(await protocol.maybe_send_ping(
            socket, force=True, monotonic_now=100.0
        ))
        self.assertFalse(await protocol.maybe_send_ping(
            socket, monotonic_now=109.9
        ))
        self.assertTrue(await protocol.maybe_send_ping(
            socket, monotonic_now=110.0
        ))
        self.assertEqual(socket.sent, ["PING", "PING"])
        self.assertTrue(protocol.observe_text("PONG", monotonic_now=110.25))
        self.assertFalse(protocol.observe_text('{"event_type":"book"}'))
        metrics = protocol.snapshot(monotonic_now=110.25)
        self.assertEqual(metrics["ping_state"], "ok")
        self.assertEqual(metrics["pings_sent"], 2)
        self.assertEqual(metrics["pongs_received"], 1)
        self.assertEqual(metrics["pending_pings"], 1)

    async def test_official_ping_send_has_a_hard_deadline(self):
        protocol = stream.MarketProtocolShadow()
        protocol.on_connect()
        with self.assertRaisesRegex(TimeoutError, "market_ping_timeout"):
            await protocol.maybe_send_ping(
                _BlockedWebSocket(), force=True, timeout=0.01
            )
        self.assertEqual(protocol.pings_sent, 0)
        self.assertEqual(protocol.pending_pings, __import__("collections").deque())

    async def test_universe_subscription_send_has_a_hard_deadline(self):
        manifest = stream.UniverseManifest(
            ("token",), {"token": "market"}, "hash", {"token": "2026-08-16"}
        )
        change = stream.UniverseChange(
            manifest=manifest,
            added=("token",),
            removed=(),
        )
        with self.assertRaisesRegex(TimeoutError, "universe_subscribe_timeout"):
            await stream._send_universe_change(
                _BlockedWebSocket(), change, timeout=0.01
            )

    async def test_exchange_clock_is_measured_but_never_replaces_capture_clock(self):
        protocol = stream.MarketProtocolShadow()
        received_at = datetime(2026, 7, 26, 6, 0, 0, 250000, tzinfo=UTC)
        exchange_at = received_at - timedelta(milliseconds=250)
        payload = {
            "event_type": "best_bid_ask",
            "asset_id": "token",
            "best_bid": "0.30",
            "best_ask": "0.31",
            "timestamp": str(int(exchange_at.timestamp() * 1000)),
        }
        writer = Mock()
        writer.submit.return_value = True
        state = stream.StreamState(
            Mock(), {"token": "market"}, writer, stream.LiveStateHub(),
            "hash", protocol
        )

        state.handle(payload, received_at=received_at)

        event = writer.submit.call_args.args[0]
        self.assertNotEqual(event["captured_at"], exchange_at.isoformat())
        metrics = protocol.snapshot()
        self.assertEqual(metrics["timestamp_valid"], 1)
        self.assertEqual(metrics["timestamp_missing"], 0)
        self.assertEqual(metrics["last_event_age_ms"], 250.0)

    async def test_wrong_timestamp_units_are_rejected_without_affecting_feed(self):
        protocol = stream.MarketProtocolShadow()
        protocol.observe_event({"event_type": "book", "timestamp": "1757908892"})
        protocol.observe_event({"event_type": "book"})
        metrics = protocol.snapshot()
        self.assertEqual(metrics["events"], 2)
        self.assertEqual(metrics["timestamp_invalid"], 1)
        self.assertEqual(metrics["timestamp_missing"], 1)
        self.assertEqual(metrics["timestamp_valid"], 0)


class IngressCommitShadowTests(unittest.TestCase):
    @staticmethod
    def event(token="token"):
        return {
            "captured_at": "2026-07-26T06:00:00+00:00",
            "market": "market",
            "token": token,
            "bid": 0.30,
            "ask": 0.31,
            "bid_size": 5.0,
            "ask_size": 6.0,
            "reason": "price_change",
            "depth_fresh": True,
            "levels": [],
            "latest_levels": [],
            "market_rules": {
                "tick_size": "0.01",
                "min_order_size": "5",
                "neg_risk": True,
                "book_hash": "book-hash",
            },
        }

    def test_full_book_rules_are_strictly_validated(self):
        self.assertEqual(
            stream.validated_book_rules({
                "tick_size": "0.010", "min_order_size": "5.0",
                "neg_risk": True, "hash": "hash-1",
            }),
            {
                "tick_size": "0.01", "min_order_size": "5",
                "neg_risk": True, "book_hash": "hash-1",
            },
        )
        for bad in (
            {"tick_size": "NaN", "min_order_size": "5", "neg_risk": True, "hash": "h"},
            {"tick_size": "0.01", "min_order_size": "0", "neg_risk": True, "hash": "h"},
            {"tick_size": "0.01", "min_order_size": "5", "neg_risk": 1, "hash": "h"},
            {"tick_size": "0.01", "min_order_size": "5", "neg_risk": True},
        ):
            self.assertIsNone(stream.validated_book_rules(bad))

    def test_tick_size_change_updates_only_an_existing_verified_rule(self):
        writer = Mock()
        writer.submit_market_rules.return_value = True
        state = stream.StreamState(
            Mock(), {"token": "market"}, writer, stream.LiveStateHub(), "hash"
        )
        state.market_rules["token"] = {
            "tick_size": "0.01", "min_order_size": "5",
            "neg_risk": False, "book_hash": "book-hash",
        }
        state.handle({
            "event_type": "tick_size_change", "asset_id": "token",
            "old_tick_size": "0.01", "new_tick_size": "0.001",
            "timestamp": "1757908892351",
        }, received_at=datetime.now(UTC))
        self.assertEqual(state.market_rules["token"]["tick_size"], "0.001")
        writer.submit_market_rules.assert_called_once()

    def test_ingress_audit_tracks_pending_until_durable_commit(self):
        shadow = stream.IngressCommitShadow(pending_stale_seconds=5)
        shadow.set_universe({"token": "market"})
        event = self.event()
        shadow.record_ingress(event, monotonic_now=100.0)

        pending = shadow.snapshot(monotonic_now=100.2)
        self.assertEqual(pending["state"], "shadow")
        self.assertEqual(pending["pending_tokens"], 1)
        self.assertEqual(pending["committed"], 0)

        shadow.record_commit(event, monotonic_now=100.25)
        committed = shadow.snapshot(monotonic_now=100.25)
        self.assertEqual(committed["state"], "shadow")
        self.assertEqual(committed["pending_tokens"], 0)
        self.assertEqual(committed["committed"], 1)
        self.assertEqual(committed["last_commit_lag_ms"], 250.0)

    def test_stale_pending_rejection_and_out_of_order_commit_fail_closed(self):
        stale = stream.IngressCommitShadow(pending_stale_seconds=5)
        stale.set_universe({"token": "market"})
        pending = self.event()
        stale.record_ingress(pending, monotonic_now=100.0)
        self.assertEqual(stale.snapshot(monotonic_now=106.0)["state"], "mismatch")

        rejected = stream.IngressCommitShadow()
        event = self.event()
        rejected.record_ingress(event, monotonic_now=100.0)
        rejected.record_rejection(event)
        self.assertEqual(rejected.snapshot(monotonic_now=100.0)["state"], "mismatch")

        ordered = stream.IngressCommitShadow()
        first, second = self.event(), self.event()
        ordered.record_ingress(first, monotonic_now=100.0)
        ordered.record_commit(first, monotonic_now=100.1)
        ordered.record_ingress(second, monotonic_now=101.0)
        ordered.record_commit(second, monotonic_now=101.1)
        ordered.record_commit(first, monotonic_now=101.2)
        metrics = ordered.snapshot(monotonic_now=101.2)
        self.assertEqual(metrics["state"], "mismatch")
        self.assertEqual(metrics["out_of_order_commits"], 1)

    def test_late_commit_for_retired_token_is_audited_without_false_mismatch(self):
        shadow = stream.IngressCommitShadow()
        shadow.set_universe({"retired": "market"})
        event = self.event("retired")
        shadow.record_ingress(event, monotonic_now=100.0)
        shadow.set_universe({})

        shadow.record_commit(event, monotonic_now=100.2)

        metrics = shadow.snapshot(monotonic_now=100.2)
        self.assertEqual(metrics["state"], "shadow")
        self.assertEqual(metrics["retired_commits"], 1)
        self.assertEqual(metrics["unknown_commits"], 0)


class EventLoopResilienceTests(unittest.IsolatedAsyncioTestCase):
    async def test_blocked_reconcile_cannot_delay_heartbeat_or_progress(self):
        hub = stream.LiveStateHub()
        blocker = threading.Event()

        def blocked_read(_path_shadow):
            blocker.wait(timeout=1)
            return {"state": "shadow", "memory_tokens": 0}

        writer = Mock()
        writer.events.qsize.return_value = 0
        writer.dropped_critical = 0
        writer.health.return_value = "ok"
        writer.maintenance_status_fragment.return_value = "maint=none:never:0ms"
        writer.submit_diagnostic.return_value = True
        progress = Mock()
        state = stream.StreamState(
            None, {}, writer, hub, "hash", stream.MarketProtocolShadow(),
            progress=progress,
        )

        with patch.object(hub, "_reconcile_snapshot", side_effect=blocked_read):
            stream.publish_stream_health(state, writer, hub, stream.IngressCommitShadow())
            await asyncio.sleep(0.02)

        self.assertTrue(writer.submit_diagnostic.called)
        progress.publish.assert_called_once()
        self.assertIsNotNone(hub.reconcile_task)
        blocker.set()
        await asyncio.sleep(0.02)

    async def test_startup_reads_finish_before_writer_bootstrap(self):
        order = []
        hub = stream.LiveStateHub()
        manifest = Mock()
        manifest.legacy_tuple.return_value = (["token"], {"token": "market"}, "hash")
        writer = Mock()
        writer.start.side_effect = lambda: order.append("writer")

        def recover():
            order.append("recovery")
            return manifest

        def warmup(_tokens):
            order.append("warmup")
            return ()

        with patch.object(stream, "subscription_manifest", side_effect=recover), \
             patch.object(hub, "read_persisted_rows", side_effect=warmup):
            result, warmed = await stream.prepare_startup(hub, writer, timeout=0.5)

        self.assertIs(result, manifest)
        self.assertEqual(warmed, 0)
        self.assertEqual(order, ["recovery", "warmup", "writer"])

    async def test_startup_timeout_reuses_inflight_read_until_it_exits(self):
        hub = stream.LiveStateHub()
        writer = Mock()
        blocker = threading.Event()
        calls = 0
        manifest = Mock()
        manifest.legacy_tuple.return_value = ([], {}, "hash")

        def blocked_recovery():
            nonlocal calls
            calls += 1
            blocker.wait(timeout=1)
            return manifest

        try:
            with patch.object(stream, "subscription_manifest", side_effect=blocked_recovery), \
                 patch.object(hub, "read_persisted_rows", return_value=(), create=True):
                with self.assertRaises(TimeoutError):
                    await stream.prepare_startup(hub, writer, timeout=0.01)
                with self.assertRaises(TimeoutError):
                    await stream.prepare_startup(hub, writer, timeout=0.01)
                self.assertEqual(calls, 1)
                self.assertFalse(writer.start.called)
                blocker.set()
                _manifest, warmed = await stream.prepare_startup(hub, writer, timeout=0.5)
        finally:
            blocker.set()

        self.assertEqual(calls, 1)
        self.assertEqual(warmed, 0)
        writer.start.assert_called_once()

    async def test_warmup_timeout_is_single_flight_and_blocks_writer_start(self):
        hub = stream.LiveStateHub()
        writer = Mock()
        blocker = threading.Event()
        calls = 0
        manifest = Mock()
        manifest.legacy_tuple.return_value = (["token"], {"token": "market"}, "hash")
        hub.startup_manifest = manifest

        def blocked_warmup(_tokens):
            nonlocal calls
            calls += 1
            blocker.wait(timeout=1)
            return ()

        try:
            with patch.object(hub, "read_persisted_rows", side_effect=blocked_warmup, create=True):
                with self.assertRaises(TimeoutError):
                    await stream.prepare_startup(hub, writer, timeout=0.01)
                with self.assertRaises(TimeoutError):
                    await stream.prepare_startup(hub, writer, timeout=0.01)
                self.assertEqual(calls, 1)
                self.assertFalse(writer.start.called)
                blocker.set()
                await stream.prepare_startup(hub, writer, timeout=0.5)
        finally:
            blocker.set()

        self.assertEqual(calls, 1)
        writer.start.assert_called_once()

    async def test_dynamic_manifest_timeout_never_overlaps_and_recovers(self):
        hub = stream.LiveStateHub()
        writer = Mock()
        state = stream.StreamState(
            None, {}, writer, hub, "hash", stream.MarketProtocolShadow()
        )
        socket = _FakeWebSocket()
        blocker = threading.Event()
        calls = 0

        def blocked_manifest():
            nonlocal calls
            calls += 1
            blocker.wait(timeout=1)
            return None

        try:
            with patch.object(stream, "published_universe_manifest", side_effect=blocked_manifest), \
                 patch.object(stream, "STATE_HUB_READ_DEADLINE_SECONDS", 0.01):
                await stream.apply_subscription_update(socket, state, monotonic_now=100.0)
                state.last_subscription_check = 0.0
                await stream.apply_subscription_update(socket, state, monotonic_now=200.0)
                self.assertEqual(calls, 1)
                blocker.set()
                for _ in range(20):
                    await stream.apply_subscription_update(socket, state, monotonic_now=300.0)
                    if not state.dynamic_manifest_read.in_flight:
                        break
                    await asyncio.sleep(0.01)
                state.last_subscription_check = 0.0
                await stream.apply_subscription_update(socket, state, monotonic_now=400.0)
                for _ in range(20):
                    if not state.dynamic_manifest_read.in_flight:
                        break
                    await asyncio.sleep(0.01)
                    await stream.apply_subscription_update(socket, state, monotonic_now=400.0)
        finally:
            blocker.set()

        self.assertEqual(calls, 2)
        self.assertFalse(state.dynamic_manifest_read.in_flight)

    async def test_single_flight_wait_keeps_event_loop_probe_live(self):
        read = stream.AsyncSingleFlightRead("probe")
        blocker = threading.Event()

        try:
            with self.assertRaises(TimeoutError):
                await read.get(lambda: blocker.wait(timeout=1), timeout=0.01)
            ticks = 0
            deadline = asyncio.get_running_loop().time() + 0.03
            while asyncio.get_running_loop().time() < deadline:
                ticks += 1
                await asyncio.sleep(0)
        finally:
            blocker.set()

        self.assertGreater(ticks, 10)

    async def test_reconnect_manifest_read_is_single_flight_across_deadlines(self):
        hub = stream.LiveStateHub()
        progress = Mock()
        blocker = threading.Event()
        calls = 0
        query_threads = []
        manifest = Mock()
        manifest.legacy_tuple.return_value = (["token"], {"token": "market"}, "hash")
        loop_thread = threading.get_ident()

        def blocked_manifest():
            nonlocal calls
            calls += 1
            query_threads.append(threading.get_ident())
            blocker.wait(timeout=1)
            return manifest

        try:
            with patch.object(stream, "subscription_manifest", side_effect=blocked_manifest):
                first = asyncio.create_task(
                    stream.read_reconnect_manifest(hub, progress, timeout=0.01)
                )
                ticks = 0
                while not first.done():
                    ticks += 1
                    await asyncio.sleep(0)
                with self.assertRaises(TimeoutError):
                    await first
                with self.assertRaises(TimeoutError):
                    await stream.read_reconnect_manifest(hub, progress, timeout=0.01)

                self.assertEqual(calls, 1)
                self.assertTrue(hub.reconnect_manifest_read.in_flight)
                self.assertGreater(ticks, 0)
                self.assertGreaterEqual(progress.publish.call_count, 2)
                self.assertEqual(hub.token_market, {})
                self.assertEqual(hub.sequence, 0)

                blocker.set()
                result = await stream.read_reconnect_manifest(hub, progress, timeout=0.5)
                consumed_thread = threading.get_ident()
                self.assertIs(result, manifest)
                self.assertEqual(consumed_thread, loop_thread)
                self.assertFalse(hub.reconnect_manifest_read.in_flight)
                self.assertEqual(hub.token_market, {})

                again = await stream.read_reconnect_manifest(hub, progress, timeout=0.5)
        finally:
            blocker.set()

        self.assertIs(again, manifest)
        self.assertEqual(calls, 2)
        self.assertNotEqual(query_threads[0], loop_thread)


class RealtimeReliabilityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.research = Path(self.tmp.name) / "research.sqlite3"
        self.realtime = Path(self.tmp.name) / "realtime.sqlite3"
        self.old_research, self.old_db = stream.RESEARCH_DB, stream.DB
        stream.RESEARCH_DB, stream.DB = self.research, self.realtime
        db = sqlite3.connect(self.research)
        try:
            db.execute("""CREATE TABLE market_universe_publications (
              publication_id TEXT PRIMARY KEY, published_at TEXT, token_hash TEXT,
              token_count INTEGER, members_json TEXT, reason TEXT)""")
            db.commit()
        finally:
            db.close()

    def tearDown(self):
        stream.RESEARCH_DB, stream.DB = self.old_research, self.old_db
        self.tmp.cleanup()

    def publish(self, members, *, accepted_legacy=True, v1=False):
        if v1:
            enriched = []
            matrix = stream.CITY_ATTRIBUTION_MATRIX
            for index, item in enumerate(members):
                item = dict(item)
                scope, station = matrix[item["city"]]
                item.update({
                    "schema": stream.V1_SCHEMA,
                    "city_scope": scope,
                    "station": station,
                    "outcome": "Yes",
                    "event_id": f"fixture-event-{index}",
                    "source_scan_id": "fixture-scan",
                    "attribution_status": "verified",
                })
                enriched.append(item)
            members = enriched
        members = sorted(members, key=lambda item: (item["token_id"], item["market_id"]))
        db = sqlite3.connect(self.research)
        try:
            collector.publish_market_universe(
                db, datetime.now(UTC).isoformat(), members, "complete_scan"
            )
            db.commit()
            token_hash = db.execute(
                "SELECT token_hash FROM market_universe_publications ORDER BY published_at DESC LIMIT 1"
            ).fetchone()[0]
        finally:
            db.close()
        if accepted_legacy and not v1:
            accepted_db = stream.connect()
            try:
                accepted_db.execute(
                    "INSERT OR REPLACE INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                    (datetime.now(UTC).isoformat(), "connected", "legacy fixture accepted",
                     token_hash, len(members), "[]", "[]"),
                )
                accepted_db.commit()
            finally:
                accepted_db.close()
        return token_hash

    def test_completed_manifest_is_stable_and_explicit(self):
        members = [
            {"token_id": "b", "market_id": "m2", "city": "Beijing", "target_date": "2026-07-24"},
            {"token_id": "a", "market_id": "m1", "city": "Shanghai", "target_date": "2026-07-24"},
        ]
        self.publish(members)
        assets, mapping, manifest_hash = stream.subscriptions()
        self.assertEqual(assets, ["a", "b"])
        self.assertEqual(mapping["a"], "m1")
        self.assertNotEqual(manifest_hash, "legacy")

    def test_invalid_manifest_fails_closed_for_projection_cleanup(self):
        db = sqlite3.connect(self.research)
        try:
            db.execute("INSERT INTO market_universe_publications VALUES (?,?,?,?,?,?)",
                       ("bad", "2026-07-24T00:00:00+00:00", "not-a-hash", 1,
                        json.dumps([{"token_id": "active", "market_id": "m"}]), "test"))
            db.commit()
        finally:
            db.close()
        db = stream.connect()
        old = (datetime.now(UTC) - timedelta(days=2)).isoformat()
        db.execute("INSERT INTO latest_bbo VALUES (?,?,?,?,?,?,?,?,?)", ("old", "m-old", old, .1, .2, 1, 1, "test", 0))
        stream.prune_old_prices(db)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM latest_bbo").fetchone()[0], 1)
        db.close()

    def test_duplicate_market_mapping_manifest_is_rejected(self):
        self.publish([
            {"token_id": "a", "market_id": "same", "city": "Beijing",
             "target_date": "2026-07-27"},
            {"token_id": "b", "market_id": "same", "city": "Shanghai",
             "target_date": "2026-07-27"},
        ])

        self.assertIsNone(stream.published_universe_manifest())

    def test_projection_prune_keeps_active_and_compact_bars(self):
        self.publish([{"token_id": "active", "market_id": "m", "city": "Beijing", "target_date": "2026-07-24"}])
        db = stream.connect()
        old = (datetime.now(UTC) - timedelta(days=2)).isoformat()
        db.execute("INSERT INTO latest_bbo VALUES (?,?,?,?,?,?,?,?,?)", ("old", "oldm", old, .1, .2, 1, 1, "test", 0))
        db.execute("INSERT INTO latest_bbo VALUES (?,?,?,?,?,?,?,?,?)", ("active", "m", old, .1, .2, 1, 1, "test", 0))
        db.execute("INSERT INTO latest_orderbook_levels VALUES (?,?,?,?,?,?)", ("old", "oldm", old, "bid", .1, 1))
        db.execute("INSERT INTO book_price_bars VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (60, old, "oldm", "old", .1, .1, .1, .1, .1, .2, 1, 1, .1, .1, 1, old))
        stream.prune_old_prices(db)
        self.assertEqual({row[0] for row in db.execute("SELECT token_id FROM latest_bbo")}, {"active"})
        self.assertEqual(db.execute("SELECT COUNT(*) FROM latest_orderbook_levels").fetchone()[0], 0)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM book_price_bars").fetchone()[0], 1)
        db.close()

    def test_protocol_shadow_metrics_are_persisted_with_heartbeat(self):
        db = stream.connect()
        db.close()
        writer = stream.PersistenceWriter()
        writer.start()
        protocol = stream.MarketProtocolShadow()
        protocol.on_connect()
        state = stream.StreamState(
            None, {"token": "market"}, writer, stream.LiveStateHub(),
            "hash", protocol
        )
        state.heartbeat("unit protocol shadow", force=True)
        row = path_row = None
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            with closing(sqlite3.connect(self.realtime)) as check:
                row = check.execute("""SELECT metrics_json FROM stream_protocol_shadow
                                       WHERE service='market_channel'""").fetchone()
                path_row = check.execute("""SELECT metrics_json FROM stream_path_shadow
                                            WHERE service='ingress_commit'""").fetchone()
            if row and path_row:
                break
            time.sleep(0.02)
        writer.close()
        self.assertIsNotNone(row)
        metrics = json.loads(row[0])
        self.assertEqual(metrics["mode"], "shadow")
        self.assertTrue(metrics["connected"])
        self.assertEqual(metrics["ping_state"], "waiting")
        self.assertIsNotNone(path_row)
        self.assertEqual(json.loads(path_row[0])["mode"], "shadow")

    def test_stream_heartbeat_uses_the_single_persistence_writer(self):
        writer = Mock()
        writer.submit_diagnostic.return_value = True
        state = stream.StreamState(
            None, {"token": "market"}, writer, stream.LiveStateHub(), "hash"
        )

        with patch.object(stream.time, "monotonic", return_value=100.0):
            state.heartbeat("healthy", force=True)
            state.heartbeat("throttled")

        writer.submit_diagnostic.assert_called_once()
        self.assertEqual(state.last_heartbeat, 100.0)

    def test_runtime_and_connection_audit_share_the_single_writer(self):
        writer = Mock()
        writer.submit_service_state.return_value = True
        writer.submit_connection_event.return_value = True

        self.assertTrue(stream.runtime_heartbeat(writer, "connecting"))
        self.assertTrue(stream.record_connection_event(
            writer, "connected", "ready", universe_hash="hash", token_count=2
        ))

        writer.submit_service_state.assert_called_once_with("connecting")
        writer.submit_connection_event.assert_called_once()

    def test_writer_persists_quotes_diagnostics_and_connection_audit(self):
        bootstrap = stream.connect()
        bootstrap.close()
        writer = stream.PersistenceWriter()
        writer.start()
        event = IngressCommitShadowTests.event()

        self.assertTrue(writer.submit(event))
        self.assertTrue(writer.submit_diagnostic(
            "live tokens=1 writer=ok", {"events": 1}, {"pending_tokens": 0}
        ))
        self.assertTrue(writer.submit_connection_event(
            "connected", "test", universe_hash="hash", token_count=1
        ))
        deadline = time.monotonic() + 3
        heartbeat = connection = latest = rules = None
        while time.monotonic() < deadline:
            with closing(sqlite3.connect(self.realtime)) as check:
                heartbeat = check.execute(
                    "SELECT detail FROM service_heartbeats WHERE service='realtime_stream'"
                ).fetchone()
                connection = check.execute(
                    "SELECT event_type,detail FROM stream_connection_events ORDER BY rowid DESC LIMIT 1"
                ).fetchone()
                latest = check.execute(
                    "SELECT 1 FROM latest_bbo WHERE token_id=?", (event["token"],)
                ).fetchone()
                rules = check.execute(
                    """SELECT tick_size,min_order_size,neg_risk,book_hash
                         FROM latest_market_rules WHERE token_id=?""",
                    (event["token"],),
                ).fetchone()
            if heartbeat and connection and latest and rules:
                break
            time.sleep(0.02)
        writer.close()
        self.assertEqual(heartbeat[0], "live tokens=1 writer=ok")
        self.assertEqual(connection, ("connected", "test"))
        self.assertIsNotNone(latest)
        self.assertEqual(rules, ("0.01", "5", 1, "book-hash"))

    def test_live_runtime_never_uses_blocking_truncate_checkpoint(self):
        source = Path("realtime_stream.py").read_text(encoding="utf-8")
        self.assertNotIn("wal_checkpoint(TRUNCATE)", source)

    def test_realtime_runtime_has_only_one_writable_database_connection_factory(self):
        source = Path("realtime_stream.py").read_text(encoding="utf-8")
        self.assertEqual(source.count("sqlite3.connect(DB, timeout=30)"), 1)
        self.assertNotIn("sqlite3.connect(DB, timeout=5)", source)

    def test_committed_hub_reconcile_detects_value_divergence(self):
        db = stream.connect()
        now = datetime.now(UTC).isoformat()
        db.execute("INSERT INTO latest_bbo VALUES (?,?,?,?,?,?,?,?,?)",
                   ("token", "market", now, .30, .31, 5, 6, "test", 1))
        db.commit()
        db.close()
        hub = stream.LiveStateHub()
        hub.set_universe({"token": "market"})
        hub.record_quote({
            "token": "token", "market": "market", "captured_at": now,
            "bid": .29, "ask": .31, "bid_size": 5, "ask_size": 6,
            "reason": "test", "depth_fresh": True,
        })

        hub.reconcile()

        self.assertEqual(hub.shadow["state"], "mismatch")
        self.assertEqual(hub.shadow["value_mismatches"], 1)

    def test_reconcile_allows_independent_live_and_durable_clocks(self):
        db = stream.connect()
        durable_at = datetime.now(UTC).isoformat()
        live_at = (datetime.now(UTC) - timedelta(seconds=5)).isoformat()
        db.execute("INSERT INTO latest_bbo VALUES (?,?,?,?,?,?,?,?,?)",
                   ("token", "market", durable_at, .30, .31, 5, 6, "heartbeat", 0))
        db.commit()
        db.close()
        hub = stream.LiveStateHub()
        hub.set_universe({"token": "market"})
        hub.record_quote({
            "token": "token", "market": "market", "captured_at": live_at,
            "bid": .30, "ask": .31, "bid_size": 5, "ask_size": 6,
            "reason": "confirmation", "depth_fresh": False,
        })

        hub.reconcile()

        self.assertEqual(hub.shadow["state"], "shadow")
        self.assertEqual(hub.shadow["value_mismatches"], 0)

    def test_immediate_hub_lead_is_expected_until_matching_commit(self):
        db = stream.connect()
        old = (datetime.now(UTC) - timedelta(seconds=1)).isoformat()
        db.execute("INSERT INTO latest_bbo VALUES (?,?,?,?,?,?,?,?,?)",
                   ("token", "market", old, .20, .21, 5, 6, "test", 1))
        db.commit()
        db.close()
        hub = stream.LiveStateHub()
        hub.set_universe({"token": "market"})
        shadow = stream.IngressCommitShadow()
        shadow.set_universe({"token": "market"})
        event = IngressCommitShadowTests.event()
        event.update(token="token", market="market",
                     captured_at=datetime.now(UTC).isoformat())
        shadow.record_ingress(event, monotonic_now=10.0)
        hub.record_quote(event)

        hub.last_reconcile = -100.0
        with patch.object(stream.time, "monotonic", return_value=10.1):
            hub.reconcile(shadow)

        self.assertEqual(hub.shadow["state"], "ahead")
        self.assertEqual(hub.shadow["expected_ahead_tokens"], 1)
        self.assertEqual(hub.shadow["value_mismatches"], 0)

    def test_stream_state_publishes_after_queue_acceptance_before_commit(self):
        db = stream.connect()
        writer = Mock()
        writer.submit.return_value = True
        hub = stream.LiveStateHub()
        state = stream.StreamState(db, {"token": "market"}, writer, hub, "hash")

        self.assertTrue(state.write_bbo("token", .20, .21, 5, 6))

        self.assertIn("token", hub.quotes)
        writer.submit.assert_called_once()
        self.assertEqual(state.path_shadow.snapshot()["pending_tokens"], 1)
        db.close()

    def test_direct_live_bbo_bypasses_five_second_persistence_gate(self):
        db = stream.connect()
        writer = Mock()
        writer.submit.return_value = True
        hub = stream.LiveStateHub()
        state = stream.StreamState(
            db, {"token": "market"}, writer, hub, "hash"
        )
        received = datetime(2026, 7, 28, 1, 0, 0, tzinfo=UTC)
        exchange = received - timedelta(milliseconds=120)

        with patch.object(stream.time, "monotonic", return_value=100.0):
            self.assertTrue(state.write_bbo(
                "token", .20, .21, 5, 6,
                received_at=received, exchange_at=exchange,
            ))
            self.assertTrue(state.write_bbo(
                "token", .22, .23, 5, 6,
                received_at=received + timedelta(seconds=1),
                exchange_at=exchange + timedelta(seconds=1),
            ))

        self.assertEqual(writer.submit.call_count, 1)
        self.assertEqual(hub.quotes["token"]["bid"], .22)
        self.assertEqual(
            hub.quotes["token"]["exchange_at"],
            (exchange + timedelta(seconds=1)).isoformat(),
        )
        self.assertLess(hub.quotes["token"]["source_to_receive_ms"], 500)
        db.close()

    def test_persistence_rejection_cannot_block_direct_live_projection(self):
        db = stream.connect()
        writer = Mock()
        writer.submit.return_value = False
        hub = stream.LiveStateHub()
        state = stream.StreamState(
            db, {"token": "market"}, writer, hub, "hash"
        )

        published = state.write_bbo("token", .30, .31, 5, 6)

        self.assertTrue(published)
        self.assertEqual(hub.quotes["token"]["bid"], .30)
        self.assertEqual(state.last_persisted_bbo_state, {})
        self.assertEqual(state.path_shadow.snapshot()["rejected"], 1)
        db.close()

    def test_same_bbo_with_new_exchange_clock_refreshes_live_only(self):
        db = stream.connect()
        writer = Mock()
        writer.submit.return_value = True
        hub = stream.LiveStateHub()
        state = stream.StreamState(
            db, {"token": "market"}, writer, hub, "hash"
        )
        received = datetime(2026, 7, 28, 1, 0, 0, tzinfo=UTC)

        with patch.object(stream.time, "monotonic", return_value=100.0):
            self.assertTrue(state.write_bbo(
                "token", .20, .21, 5, 6,
                received_at=received,
                exchange_at=received - timedelta(milliseconds=100),
            ))
            first_sequence = hub.sequence
            self.assertTrue(state.write_bbo(
                "token", .20, .21, 5, 6,
                received_at=received + timedelta(seconds=1),
                exchange_at=received + timedelta(milliseconds=900),
            ))
            confirmed_sequence = hub.sequence
            self.assertFalse(state.write_bbo(
                "token", .20, .21, 5, 6,
                received_at=received + timedelta(seconds=2),
                exchange_at=None,
            ))

        self.assertGreater(confirmed_sequence, first_sequence)
        self.assertEqual(hub.sequence, confirmed_sequence)
        self.assertEqual(hub.quotes["token"]["reason"], "confirmation")
        self.assertEqual(writer.submit.call_count, 1)
        db.close()

    def test_database_lock_keeps_commit_callback_private_until_commit(self):
        bootstrap = stream.connect()
        bootstrap.close()
        durable_callbacks = []
        writer = stream.PersistenceWriter(
            on_committed=lambda event: durable_callbacks.append(event)
        )
        blocker = sqlite3.connect(self.realtime, timeout=1)
        blocker.execute("BEGIN IMMEDIATE")
        writer.start()
        event = IngressCommitShadowTests.event()
        shadow = stream.IngressCommitShadow()
        shadow.record_ingress(event)
        self.assertTrue(writer.submit(event))
        time.sleep(0.15)
        self.assertEqual(durable_callbacks, [])
        self.assertEqual(shadow.snapshot()["pending_tokens"], 1)

        blocker.rollback()
        blocker.close()
        deadline = time.monotonic() + 3
        while not durable_callbacks and time.monotonic() < deadline:
            time.sleep(0.02)
        writer.close()

        self.assertEqual(len(durable_callbacks), 1)
        shadow.record_commit(durable_callbacks[0])
        self.assertEqual(shadow.snapshot()["pending_tokens"], 0)

    def test_commit_callback_precedes_slow_capacity_maintenance(self):
        bootstrap = stream.connect()
        bootstrap.close()
        order = []
        writer = stream.PersistenceWriter(
            on_committed=lambda _event: order.append("commit")
        )
        writer.start()
        event = IngressCommitShadowTests.event()
        with patch.object(stream, "enforce_row_cap_phase",
                          side_effect=lambda _db, _phase, **_kwargs: order.append("maintenance")):
            self.assertTrue(writer.submit(event))
            deadline = time.monotonic() + 3
            while "maintenance" not in order and time.monotonic() < deadline:
                time.sleep(0.02)
        writer.close()

        self.assertIn("commit", order)
        self.assertIn("maintenance", order)
        self.assertLess(order.index("commit"), order.index("maintenance"))

    def test_pending_quote_cooperatively_preempts_capacity_maintenance(self):
        """A quote arriving during housekeeping must not wait behind it."""
        bootstrap = stream.connect()
        bootstrap.close()
        committed = []
        maintenance_started = threading.Event()

        def interruptible_maintenance(_db, _phase, *, should_yield):
            maintenance_started.set()
            deadline = time.monotonic() + 2.0
            while not should_yield() and time.monotonic() < deadline:
                time.sleep(0.005)

        writer = stream.PersistenceWriter(
            on_committed=lambda event: committed.append(event["token"])
        )
        submitted_at = time.monotonic()
        try:
            with patch.object(
                stream,
                "enforce_row_cap_phase",
                side_effect=interruptible_maintenance,
            ):
                writer.start()
                self.assertTrue(writer.submit(IngressCommitShadowTests.event("first")))
                self.assertTrue(maintenance_started.wait(timeout=1.0))
                submitted_at = time.monotonic()
                self.assertTrue(writer.submit(IngressCommitShadowTests.event("second")))
                deadline = submitted_at + 0.5
                while "second" not in committed and time.monotonic() < deadline:
                    time.sleep(0.005)
        finally:
            writer.close()

        self.assertIn("second", committed)
        self.assertLess(time.monotonic() - submitted_at, 0.75)
        self.assertEqual(committed.count("first"), 1)
        self.assertEqual(committed.count("second"), 1)

    def test_capacity_maintenance_hot_path_has_no_full_table_count(self):
        source = Path("realtime_stream.py").read_text(encoding="utf-8")
        start = source.index("def prune_old_prices")
        end = source.index("def upsert_price_bar")
        maintenance_source = source[start:end]

        self.assertNotIn("COUNT(*)", maintenance_source)

    def test_sqlite_progress_handler_preempts_long_maintenance_query(self):
        db = stream.connect()
        writer = stream.PersistenceWriter()

        def slow_sql(connection, *, should_yield):
            connection.execute("""WITH RECURSIVE seq(x) AS (
                SELECT 1 UNION ALL SELECT x + 1 FROM seq WHERE x < 10000000
            ) SELECT SUM(x) FROM seq""").fetchone()
            return 0

        def enqueue_quote():
            time.sleep(0.03)
            writer.events.put(IngressCommitShadowTests.event("waiting"))

        producer = threading.Thread(target=enqueue_quote)
        producer.start()
        started = time.monotonic()
        try:
            completed = writer._run_bounded_maintenance(
                db, "test", slow_sql,
            )
        finally:
            producer.join(timeout=1.0)
            db.close()

        self.assertFalse(completed)
        self.assertLess(time.monotonic() - started, 0.75)
        self.assertEqual(writer.maintenance_snapshot()["preemptions"], 1)

    def test_maintenance_wall_clock_overrun_is_distinct_and_observable(self):
        writer = stream.PersistenceWriter()
        db = sqlite3.connect(":memory:")

        with patch.object(stream, "MAINTENANCE_BUDGET_SECONDS", 0.01):
            completed = writer._run_bounded_maintenance(
                db,
                "test/overrun",
                lambda _db, **_kwargs: (time.sleep(0.03) or 0),
            )

        self.assertFalse(completed)
        metrics = writer.maintenance_snapshot()
        self.assertEqual(metrics["status"], "budget_exceeded")
        self.assertEqual(metrics["overruns"], 1)
        db.close()

    def test_committed_maintenance_slice_survives_later_phase_failure(self):
        db = stream.connect()
        base = datetime(2026, 8, 1, tzinfo=UTC)
        for offset in range(2):
            captured = (base + timedelta(seconds=offset)).isoformat()
            db.execute(
                "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
                (captured, "market", f"token-{offset}", .3, .31, 5, 6,
                 "test", 0),
            )
        db.commit()
        writer = stream.PersistenceWriter()

        def first_slice(connection, *, should_yield):
            return connection.execute(
                "DELETE FROM book_snapshots WHERE token_id='token-0'"
            ).rowcount

        def failed_slice(connection, *, should_yield):
            connection.execute(
                "DELETE FROM book_snapshots WHERE token_id='token-1'"
            )
            raise sqlite3.OperationalError("database or disk is full")

        self.assertTrue(writer._run_bounded_maintenance(
            db, "retention/raw_time", first_slice,
        ))
        self.assertFalse(writer._run_bounded_maintenance(
            db, "retention/depth_time", failed_slice,
        ))
        remaining = [
            row[0] for row in db.execute(
                "SELECT token_id FROM book_snapshots ORDER BY captured_at"
            )
        ]
        metrics = writer.maintenance_snapshot()
        db.close()

        self.assertEqual(remaining, ["token-1"])
        self.assertEqual(metrics["status"], "failed")
        self.assertEqual(metrics["failures"], 1)

    def test_time_retention_deletes_only_rows_with_exact_compact_bucket(self):
        db = stream.connect()
        captured = datetime.now(UTC) - timedelta(hours=2)
        captured_at = captured.isoformat()
        bucket_at = captured.replace(
            minute=(captured.minute // 5) * 5, second=0, microsecond=0,
        ).isoformat()
        db.execute(
            "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
            (captured_at, "market", "compact", .3, .31, 5, 6, "test", 0),
        )
        db.execute(
            "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
            (captured_at, "market", "no-compact", .3, .31, 5, 6, "test", 0),
        )
        db.execute(
            """INSERT INTO book_price_bars VALUES
            (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (300, bucket_at, "market", "compact", .3, .3, .3, .3,
             .3, .31, 5, 6, .01, .01, 1, captured_at),
        )
        with patch.object(stream, "RAW_QUOTE_RETENTION_HOURS", 1):
            deleted = stream.prune_retention_phase(db, "raw_time")
            db.commit()
        remaining = {
            row[0] for row in db.execute("SELECT token_id FROM book_snapshots")
        }
        db.close()

        self.assertEqual(deleted, 1)
        self.assertEqual(remaining, {"no-compact"})

    def test_oldest_capacity_queries_use_existing_indexes_without_temp_sort(self):
        db = stream.connect()
        queries = (
            "SELECT rowid FROM book_snapshots ORDER BY captured_at ASC LIMIT 10",
            "SELECT rowid FROM orderbook_levels ORDER BY captured_at ASC LIMIT 10",
            "SELECT rowid FROM book_price_bars WHERE interval_seconds=60 "
            "ORDER BY bucket_at ASC LIMIT 10",
            "SELECT rowid FROM book_price_bars WHERE interval_seconds=300 "
            "ORDER BY bucket_at ASC LIMIT 10",
        )
        plans = [
            " ".join(str(row[3]) for row in db.execute("EXPLAIN QUERY PLAN " + query))
            for query in queries
        ]
        db.close()

        for plan in plans:
            self.assertNotIn("TEMP B-TREE", plan.upper())

    def test_no_count_capacity_trim_keeps_newest_rows(self):
        db = stream.connect()
        base = datetime(2026, 8, 1, tzinfo=UTC)
        for offset in range(8):
            captured = (base + timedelta(seconds=offset)).isoformat()
            db.execute(
                "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
                (captured, "market", f"token-{offset}", .3, .31, 5, 6,
                 "test", 0),
            )
        with (
            patch.object(stream, "MAX_RAW_QUOTE_ROWS", 5),
            patch.object(stream, "MAX_DEPTH_ROWS", 5),
            patch.object(stream, "ROW_CAP_HEADROOM", 1),
            patch.object(stream, "PRUNE_BATCH_ROWS", 100),
        ):
            deleted = stream.enforce_near_term_row_caps(db)
            db.commit()
        remaining = [
            row[0] for row in db.execute(
                "SELECT token_id FROM book_snapshots ORDER BY captured_at"
            )
        ]
        db.close()

        self.assertEqual(deleted, 4)
        self.assertEqual(
            remaining,
            ["token-4", "token-5", "token-6", "token-7"],
        )

    def test_near_term_capacity_guard_also_closes_compact_bar_caps(self):
        db = stream.connect()
        base = datetime(2026, 8, 1, tzinfo=UTC)
        for interval in (60, 300):
            for offset in range(8):
                captured = (base + timedelta(minutes=offset)).isoformat()
                db.execute(
                    """INSERT INTO book_price_bars VALUES
                    (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (interval, captured, "market", f"{interval}-{offset}",
                     .3, .3, .3, .3, .3, .31, 5, 6, .01, .01, 1, captured),
                )
        with (
            patch.object(stream, "MINUTE_BAR_RETENTION_DAYS", 6),
            patch.object(stream, "FIVE_MINUTE_BAR_RETENTION_DAYS", 7),
            patch.object(stream, "MAX_MINUTE_BAR_ROWS", 5),
            patch.object(stream, "MAX_FIVE_MINUTE_BAR_ROWS", 5),
            patch.object(stream, "ROW_CAP_HEADROOM", 1),
            patch.object(stream, "PRUNE_BATCH_ROWS", 100),
        ):
            deleted = stream.enforce_near_term_row_caps(db)
            db.commit()
        counts = dict(db.execute(
            "SELECT interval_seconds,COUNT(*) FROM book_price_bars "
            "GROUP BY interval_seconds"
        ))
        db.close()

        self.assertEqual(deleted, 8)
        self.assertEqual(counts, {60: 4, 300: 4})

    def test_online_capacity_delete_has_non_configurable_batch_ceiling(self):
        db = stream.connect()
        base = datetime(2026, 8, 1, tzinfo=UTC)
        for offset in range(20):
            captured = (base + timedelta(seconds=offset)).isoformat()
            db.execute(
                "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
                (captured, "market", f"token-{offset}", .3, .31, 5, 6,
                 "test", 0),
            )
        with (
            patch.object(stream, "MAX_RAW_QUOTE_ROWS", 1),
            patch.object(stream, "ROW_CAP_HEADROOM", 0),
            patch.object(stream, "PRUNE_BATCH_ROWS", 100_000),
            patch.object(stream, "MAX_ONLINE_PRUNE_BATCH_ROWS", 3),
        ):
            deleted = stream.enforce_row_cap_phase(db, "raw")
            db.commit()
        remaining = db.execute(
            "SELECT COUNT(*) FROM book_snapshots"
        ).fetchone()[0]
        db.close()

        self.assertEqual(deleted, 3)
        self.assertEqual(remaining, 17)

    def test_capacity_phase_does_not_bundle_unrelated_table_deletes(self):
        db = stream.connect()
        base = datetime(2026, 8, 1, tzinfo=UTC).isoformat()
        db.execute(
            "INSERT INTO book_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
            (base, "market", "raw", .3, .31, 5, 6, "test", 0),
        )
        db.execute(
            """INSERT INTO book_price_bars VALUES
            (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (60, base, "market", "bar", .3, .3, .3, .3, .3, .31,
             5, 6, .01, .01, 1, base),
        )
        with (
            patch.object(stream, "MAX_RAW_QUOTE_ROWS", 0),
            patch.object(stream, "MAX_MINUTE_BAR_ROWS", 0),
            patch.object(stream, "ROW_CAP_HEADROOM", 0),
        ):
            deleted = stream.enforce_row_cap_phase(db, "raw")
            db.commit()
        raw_count = db.execute("SELECT COUNT(*) FROM book_snapshots").fetchone()[0]
        bar_count = db.execute("SELECT COUNT(*) FROM book_price_bars").fetchone()[0]
        db.close()

        self.assertEqual(deleted, 1)
        self.assertEqual(raw_count, 0)
        self.assertEqual(bar_count, 1)

    def test_no_count_bar_trim_does_not_shrink_sla_window(self):
        db = stream.connect()
        base = datetime.now(UTC) - timedelta(hours=1)
        for interval in (60, 300):
            for offset in range(8):
                captured = (base + timedelta(minutes=offset)).isoformat()
                db.execute(
                    """INSERT INTO book_price_bars VALUES
                    (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (interval, captured, "market", f"{interval}-{offset}",
                     .3, .3, .3, .3, .3, .31, 5, 6, .01, .01, 1, captured),
                )
        with (
            patch.object(stream, "MAX_MINUTE_BAR_ROWS", 5),
            patch.object(stream, "MAX_FIVE_MINUTE_BAR_ROWS", 5),
            patch.object(stream, "PRUNE_BATCH_ROWS", 100),
            patch.object(stream, "published_token_ids", return_value=None),
        ):
            stream.prune_old_prices(db)
            db.commit()
        counts = dict(db.execute(
            "SELECT interval_seconds,COUNT(*) FROM book_price_bars GROUP BY interval_seconds"
        ))
        db.close()

        self.assertEqual(counts, {60: 8, 300: 8})

    def test_transactional_row_counters_do_not_drift_on_duplicate_upsert(self):
        db = stream.connect()
        event = IngressCommitShadowTests.event("same-token")
        stream.persist_quote_event(db, event)
        stream.persist_quote_event(db, event)
        db.commit()

        counters = dict(db.execute(
            "SELECT table_key,row_count FROM realtime_row_counts"
        ))
        physical = {
            "book_snapshots": db.execute(
                "SELECT COUNT(*) FROM book_snapshots"
            ).fetchone()[0],
            "orderbook_levels": db.execute(
                "SELECT COUNT(*) FROM orderbook_levels"
            ).fetchone()[0],
            "book_price_bars:60": db.execute(
                "SELECT COUNT(*) FROM book_price_bars WHERE interval_seconds=60"
            ).fetchone()[0],
            "book_price_bars:300": db.execute(
                "SELECT COUNT(*) FROM book_price_bars WHERE interval_seconds=300"
            ).fetchone()[0],
        }
        db.close()

        self.assertEqual(counters, physical)
        self.assertEqual(counters["book_snapshots"], 1)
        self.assertEqual(counters["book_price_bars:60"], 1)
        self.assertEqual(counters["book_price_bars:300"], 1)
        with closing(sqlite3.connect(self.realtime)) as check:
            self.assertEqual(
                check.execute("SELECT COUNT(*) FROM market_rule_snapshots").fetchone(),
                (1,),
            )

    def test_existing_database_bootstraps_row_counters_once(self):
        db = stream.connect()
        for trigger in (
            "trg_book_snapshots_count_insert",
            "trg_book_snapshots_count_delete",
            "trg_orderbook_levels_count_insert",
            "trg_orderbook_levels_count_delete",
            "trg_minute_bars_count_insert",
            "trg_minute_bars_count_delete",
            "trg_five_minute_bars_count_insert",
            "trg_five_minute_bars_count_delete",
        ):
            db.execute(f"DROP TRIGGER {trigger}")
        db.execute("DROP TABLE realtime_row_counts")
        event = IngressCommitShadowTests.event("legacy-token")
        stream.persist_quote_event(db, event)
        db.commit()
        db.close()

        migrated = stream.connect()
        counters = dict(migrated.execute(
            "SELECT table_key,row_count FROM realtime_row_counts"
        ))
        migrated.close()

        self.assertEqual(counters["book_snapshots"], 1)
        self.assertEqual(counters["orderbook_levels"], 0)
        self.assertEqual(counters["book_price_bars:60"], 1)
        self.assertEqual(counters["book_price_bars:300"], 1)

    def test_progressive_universe_addition_is_planned_without_reconnect(self):
        db = stream.connect()
        try:
            writer = Mock()
            hub = stream.LiveStateHub()
            state = stream.StreamState(
                db, {"old": "old-market"}, writer, hub, "old-hash",
                token_target_date={"old": "2026-07-26"},
            )
            self.publish([
                {"token_id": "old", "market_id": "old-market", "city": "Beijing",
                 "target_date": "2026-07-26"},
                {"token_id": "new", "market_id": "new-market", "city": "Shanghai",
                 "target_date": "2026-07-28"},
            ])
            change = state.subscription_update(
                now_cn=datetime(2026, 7, 26, 16, 0, tzinfo=stream.CHINA_TZ),
                monotonic_now=20,
            )
            self.assertEqual(change.added, ("new",))
            self.assertEqual(change.removed, ())
            self.assertEqual(set(state.token_market), {"old"})
        finally:
            db.close()

    def test_dynamic_subscription_kill_switch_leaves_static_universe(self):
        db = stream.connect()
        try:
            state = stream.StreamState(
                db, {"old": "old-market"}, Mock(), stream.LiveStateHub(), "old-hash",
                token_target_date={"old": "2026-07-27"},
            )
            self.publish([
                {"token_id": "old", "market_id": "old-market", "city": "Beijing",
                 "target_date": "2026-07-27"},
                {"token_id": "new", "market_id": "new-market", "city": "Shanghai",
                 "target_date": "2026-07-28"},
            ])
            with patch.object(stream, "DYNAMIC_UNIVERSE_ENABLED", False):
                change = state.subscription_update(
                    now_cn=datetime(2026, 7, 27, 16, 0, tzinfo=stream.CHINA_TZ),
                    monotonic_now=20,
                )
            self.assertIsNone(change)
            self.assertEqual(state.token_market, {"old": "old-market"})
        finally:
            db.close()

    def test_intraday_shrink_cannot_drop_live_subscription(self):
        db = stream.connect()
        try:
            state = stream.StreamState(
                db, {"old": "old-market", "missing": "missing-market"},
                Mock(), stream.LiveStateHub(), "old-hash",
                token_target_date={"old": "2026-07-26", "missing": "2026-07-28"},
            )
            self.publish([
                {"token_id": "old", "market_id": "old-market", "city": "Beijing",
                 "target_date": "2026-07-26"},
            ])
            self.assertIsNone(state.subscription_update(
                now_cn=datetime(2026, 7, 26, 16, 0, tzinfo=stream.CHINA_TZ),
                monotonic_now=20,
            ))
            self.assertEqual(set(state.token_market), {"old", "missing"})
        finally:
            db.close()

    def test_mixed_add_remove_candidate_is_rejected(self):
        db = stream.connect()
        try:
            state = stream.StreamState(
                db, {"keep": "keep-market", "remove": "remove-market"},
                Mock(), stream.LiveStateHub(), "old-hash",
                token_target_date={"keep": "2026-07-27", "remove": "2026-07-27"},
            )
            self.publish([
                {"token_id": "keep", "market_id": "keep-market", "city": "Beijing",
                 "target_date": "2026-07-27"},
                {"token_id": "add", "market_id": "add-market", "city": "Shanghai",
                 "target_date": "2026-07-28"},
            ])

            change = state.subscription_update(
                now_cn=datetime(2026, 7, 27, 16, 0, tzinfo=stream.CHINA_TZ),
                monotonic_now=20,
            )

            self.assertIsNone(change)
            self.assertEqual(set(state.token_market), {"keep", "remove"})
        finally:
            db.close()

    def test_existing_token_cannot_be_remapped_during_addition(self):
        db = stream.connect()
        try:
            state = stream.StreamState(
                db, {"keep": "known-market"}, Mock(), stream.LiveStateHub(), "old-hash",
                token_target_date={"keep": "2026-07-27"},
            )
            self.publish([
                {"token_id": "keep", "market_id": "changed-market", "city": "Beijing",
                 "target_date": "2026-07-27"},
                {"token_id": "add", "market_id": "add-market", "city": "Shanghai",
                 "target_date": "2026-07-28"},
            ])

            change = state.subscription_update(
                now_cn=datetime(2026, 7, 27, 16, 0, tzinfo=stream.CHINA_TZ),
                monotonic_now=20,
            )

            self.assertIsNone(change)
            self.assertEqual(state.token_market, {"keep": "known-market"})
        finally:
            db.close()

    def test_rollover_removes_only_past_tokens_after_identical_manifest_repeats(self):
        db = stream.connect()
        try:
            state = stream.StreamState(
                db, {"past": "past-market", "current": "current-market"},
                Mock(), stream.LiveStateHub(), "old-hash",
                token_target_date={"past": "2026-07-26", "current": "2026-07-27"},
            )
            self.publish([
                {"token_id": "current", "market_id": "current-market", "city": "Beijing",
                 "target_date": "2026-07-27"},
            ])
            now = datetime(2026, 7, 27, 0, 30, tzinfo=stream.CHINA_TZ)
            self.assertIsNone(state.subscription_update(now_cn=now, monotonic_now=20))
            change = state.subscription_update(now_cn=now, monotonic_now=40)
            self.assertEqual(change.added, ())
            self.assertEqual(change.removed, ("past",))
        finally:
            db.close()

    def test_restart_recovery_does_not_regress_to_intraday_smaller_manifest(self):
        accepted_hash = self.publish([
            {"token_id": "a", "market_id": "ma", "city": "Beijing",
             "target_date": datetime.now(stream.CHINA_TZ).date().isoformat()},
            {"token_id": "b", "market_id": "mb", "city": "Shanghai",
             "target_date": datetime.now(stream.CHINA_TZ).date().isoformat()},
        ])
        db = stream.connect()
        db.close()
        writer = stream.PersistenceWriter()
        writer.start()
        stream.record_connection_event(
            writer, "connected", "test", universe_hash=accepted_hash, token_count=2
        )
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            with closing(sqlite3.connect(self.realtime)) as check:
                if check.execute(
                    "SELECT 1 FROM stream_connection_events WHERE universe_hash=?",
                    (accepted_hash,),
                ).fetchone():
                    break
            time.sleep(0.02)
        writer.close()
        self.publish([
            {"token_id": "a", "market_id": "ma", "city": "Beijing",
             "target_date": datetime.now(stream.CHINA_TZ).date().isoformat()},
        ], accepted_legacy=False)

        assets, _mapping, restored_hash = stream.subscriptions()

        self.assertEqual(assets, ["a", "b"])
        self.assertEqual(restored_hash, accepted_hash)

    def test_restart_cannot_use_repetition_to_bypass_mixed_transition_gate(self):
        today = datetime.now(stream.CHINA_TZ).date()
        yesterday = (today - timedelta(days=1)).isoformat()
        current = today.isoformat()
        tomorrow = (today + timedelta(days=1)).isoformat()
        accepted_hash = self.publish([
            {"token_id": "100", "market_id": "past-market", "city": "Beijing",
             "target_date": yesterday},
            {"token_id": "101", "market_id": "current-market", "city": "Beijing",
             "target_date": current},
        ], v1=True)
        db = stream.connect()
        db.close()
        writer = stream.PersistenceWriter()
        writer.start()
        stream.record_connection_event(
            writer, "connected", "test", universe_hash=accepted_hash, token_count=2
        )
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            with closing(sqlite3.connect(self.realtime)) as check:
                if check.execute(
                    "SELECT 1 FROM stream_connection_events WHERE universe_hash=?",
                    (accepted_hash,),
                ).fetchone():
                    break
            time.sleep(0.02)
        writer.close()
        candidate = [
            {"token_id": "101", "market_id": "current-market", "city": "Beijing",
             "target_date": current},
            {"token_id": "102", "market_id": "future-market", "city": "Beijing",
             "target_date": tomorrow},
        ]
        self.publish(candidate, v1=True)

        first_assets, _mapping, first_hash = stream.subscriptions()
        self.publish(candidate, v1=True)
        second_assets, _mapping, second_hash = stream.subscriptions()

        self.assertEqual(set(first_assets), {"100", "101"})
        self.assertEqual(first_hash, accepted_hash)
        self.assertEqual(set(second_assets), {"100", "101"})
        self.assertEqual(second_hash, accepted_hash)


class DynamicSubscriptionTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.research = Path(self.tmp.name) / "research.sqlite3"
        self.realtime = Path(self.tmp.name) / "realtime.sqlite3"
        self.old_research, self.old_db = stream.RESEARCH_DB, stream.DB
        stream.RESEARCH_DB, stream.DB = self.research, self.realtime
        with closing(sqlite3.connect(self.research)) as db, db:
            db.execute("""CREATE TABLE market_universe_publications (
              publication_id TEXT PRIMARY KEY, published_at TEXT, token_hash TEXT,
              token_count INTEGER, members_json TEXT, reason TEXT)""")

    def tearDown(self):
        stream.RESEARCH_DB, stream.DB = self.old_research, self.old_db
        self.tmp.cleanup()

    def publish(self, members):
        members = sorted(members, key=lambda item: (item["token_id"], item["market_id"]))
        with closing(sqlite3.connect(self.research)) as db, db:
            collector.publish_market_universe(
                db, datetime.now(UTC).isoformat(), members, "complete_scan"
            )
            token_hash = db.execute(
                "SELECT token_hash FROM market_universe_publications ORDER BY published_at DESC LIMIT 1"
            ).fetchone()[0]
        accepted_db = stream.connect()
        try:
            accepted_db.execute(
                "INSERT OR REPLACE INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                (datetime.now(UTC).isoformat(), "connected", "legacy fixture accepted",
                 token_hash, len(members), "[]", "[]"),
            )
            accepted_db.commit()
        finally:
            accepted_db.close()

    async def test_addition_uses_dynamic_subscribe_and_waits_for_initial_bbo(self):
        db = stream.connect()
        hub = stream.LiveStateHub()
        state = stream.StreamState(
            db, {"old": "old-market"}, Mock(), hub, "old-hash",
            token_target_date={"old": "2026-07-27"},
        )
        self.publish([
            {"token_id": "old", "market_id": "old-market", "city": "Beijing",
             "target_date": "2026-07-27"},
            {"token_id": "new", "market_id": "new-market", "city": "Shanghai",
             "target_date": "2026-07-28"},
        ])
        socket = _FakeWebSocket()

        change = await stream.apply_subscription_update(
            socket, state,
            now_cn=datetime(2026, 7, 27, 16, 0, tzinfo=stream.CHINA_TZ),
            monotonic_now=20,
        )

        self.assertEqual(json.loads(socket.sent[0]), {
            "assets_ids": ["new"], "operation": "subscribe",
        })
        self.assertEqual(change.added, ("new",))
        self.assertIn("new", state.token_market)
        self.assertNotIn("new", hub.quotes)
        second = await stream.apply_subscription_update(
            socket, state,
            now_cn=datetime(2026, 7, 27, 16, 1, tzinfo=stream.CHINA_TZ),
            monotonic_now=40,
        )
        self.assertIsNone(second)
        self.assertEqual(len(socket.sent), 1)
        db.close()

    async def test_send_failure_leaves_all_local_universe_state_unchanged(self):
        db = stream.connect()
        hub = stream.LiveStateHub()
        state = stream.StreamState(
            db, {"old": "old-market"}, Mock(), hub, "old-hash",
            token_target_date={"old": "2026-07-27"},
        )
        self.publish([
            {"token_id": "old", "market_id": "old-market", "city": "Beijing",
             "target_date": "2026-07-27"},
            {"token_id": "new", "market_id": "new-market", "city": "Shanghai",
             "target_date": "2026-07-28"},
        ])

        with self.assertRaises(ConnectionError):
            await stream.apply_subscription_update(
                _FailingWebSocket(), state,
                now_cn=datetime(2026, 7, 27, 16, 0, tzinfo=stream.CHINA_TZ),
                monotonic_now=20,
            )

        self.assertEqual(state.token_market, {"old": "old-market"})
        self.assertEqual(state.universe_hash, "old-hash")
        db.close()

    async def test_rollover_unsubscribe_prunes_live_state_after_send(self):
        db = stream.connect()
        hub = stream.LiveStateHub()
        hub.set_universe({"past": "past-market", "current": "current-market"})
        state = stream.StreamState(
            db, {"past": "past-market", "current": "current-market"},
            Mock(), hub, "old-hash",
            token_target_date={"past": "2026-07-26", "current": "2026-07-27"},
        )
        state.books["past"] = {"bid": {}, "ask": {}}
        state.latest_bbo["past"] = (0.1, 0.2, 1.0, 1.0)
        self.publish([
            {"token_id": "current", "market_id": "current-market", "city": "Beijing",
             "target_date": "2026-07-27"},
        ])
        socket = _FakeWebSocket()
        now = datetime(2026, 7, 27, 0, 30, tzinfo=stream.CHINA_TZ)

        self.assertIsNone(await stream.apply_subscription_update(
            socket, state, now_cn=now, monotonic_now=20,
        ))
        change = await stream.apply_subscription_update(
            socket, state, now_cn=now, monotonic_now=40,
        )

        self.assertEqual(json.loads(socket.sent[0]), {
            "assets_ids": ["past"], "operation": "unsubscribe",
        })
        self.assertEqual(change.removed, ("past",))
        self.assertNotIn("past", state.token_market)
        self.assertNotIn("past", state.books)
        self.assertNotIn("past", state.latest_bbo)
        self.assertNotIn("past", hub.token_market)
        db.close()


if __name__ == "__main__":
    unittest.main()
