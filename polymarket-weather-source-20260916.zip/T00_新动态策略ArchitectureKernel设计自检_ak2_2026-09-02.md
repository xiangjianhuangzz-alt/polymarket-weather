# T00｜新动态策略Architecture Kernel ak2作者反例自检｜2026-09-02

状态：`AK2_AUTHOR_SELFCHECK_PASS_DESIGN_ONLY_AWAITING_SECOND_INDEPENDENT_AUDIT_AUTHORIZATION`

性质：作者和咨询输入整合后的设计级反例检查；不是独立审查、实现测试、SQLite验证、Windows部署验证或组织接受。

## 1. 自检身份

```text
TASK_ID=PWM-V8-AK-R1-001
CANDIDATE_ID=T00-weather-strategy-architecture-kernel/ak2
BASELINE=codex/handoff-baseline-20260809@13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
AS_OF_DATE=2026-09-02
TIMEZONE=Asia/Shanghai

TASK_CONTRACT_SHA256=a58702dc83fe8878bd893f24e7f373ee2a74bdc174fc04da7b315b4f899c9dc1
CANDIDATE_SHA256=e01d30534b8b1de77ac4c426d925dda222a0c772540fb09b6425d39fab11308d
PARENT_AK1_SHA256=b0ccc9d82e8c8bfec06836abaf6914a4c4c7fbcf932a59fb9ce54140d7485988
FIRST_AUDIT_SHA256=df01190520cf687758b78e1082671d7d2e5eb855e210307b035ecf12963eea45
```

## 2. 岗位输入边界

| 岗位 | 输入范围 | T00处理 |
|---|---|---|
| DATA | R02/R04/R05的AS-OF、事实/事件身份和历史折叠 | 接纳稳定前缀waterline、持久事实ID和append-only折叠；未让DATA裁决PASS |
| STRATEGY | R03 M007 | 接纳反保守校准差的最坏组同时单侧UCB；明确全零LCB可能保守但不证明技能 |
| BE | R02/R05/R06 | 接纳单文件批准、同城事务和Outcome闭合函数；禁止跨库FK/写事务 |
| OPS | R07/R08/R09 | 接纳完整进程身份、10+10路径清单和breaker状态机；具体部署仍阻断 |
| T01 | EXCLUDED | 未参与ak2修订，保留第二次审查独立性 |

咨询岗位均只返回建议，没有修改项目文件、运行测试或作出ak2接受裁决。

## 3. 机械闭合检查

| 检查 | 观察结果 | 作者状态 |
|---|---:|---|
| Registry条目数 | 20 | PASS |
| Registry唯一rule_id数 | 20 | PASS |
| NORMATIVE_PAYLOAD数 | 20 | PASS |
| 唯一Payload ID数 | 20 | PASS |
| 显式owner anchor数 | 20 | PASS |
| Registry与Payload集合 | 完全相等 | PASS |
| Registry owner_anchor与实际anchor集合 | 完全相等 | PASS |
| Registry按rule_id排序 | YES | PASS |
| R01—R09反例矩阵 | 9/9 | PASS |
| Manifest成员 | 尚待本自检完成后形成 | EXPECTED |

以上通过只证明文本和登记结构，不证明未来生成器、Schema、DDL或运行实现。

## 4. R01—R09作者反例

| ID | 反例 | 预期唯一结果 | 作者状态 |
|---|---|---|---|
| R01 | 实现者在Registry外维护第二份CLI规则 | 反向消费检查发现未消费R06或额外规范并拒绝全部生成物 | DESIGN_PASS |
| R02 | 上海/北京使用旧policy，广州使用新policy；或广州在approval AS-OF后提交 | common hash或waterline/commit时限不符，ConfigSet不产生 | DESIGN_PASS |
| R03 | 某组真实频率0.2而LCB长期0.8 | `Delta≈0.6`且同时单侧UCB超过阈值时VIOLATION | DESIGN_PASS |
| R03-A | 所有LCB为0 | M007可显示未反保守，但不得推出技能或Qualification PASS | DESIGN_PASS |
| R03-B | alpha/R/N_min/tau或必需组未冻结 | `M007=null/M007_POLICY_UNFROZEN`并阻断 | DESIGN_PASS |
| R04 | 同一来源revision在重启后再次观察 | natural key和payload相同，命中既有SourceFact/Event，不增加family | DESIGN_PASS |
| R04-A | 同一publication/revision出现不同payload | natural key冲突，单城fail-stop | DESIGN_PASS |
| R05 | D1存在但slot被清空，新事件准备生成D2 | 事务前历史折叠与slot不符，停止且不插入D2 | DESIGN_PASS |
| R05-A | COMMIT响应丢失 | 先按operation receipt及immutable行完整对账；结果不明禁止重试 | DESIGN_PASS |
| R06 | lease冲突被两个实现解释为不同退出码 | 唯一映射为CITY_RETRYABLE/2/同recovery ID重试 | DESIGN_PASS |
| R06-A | 未登记错误、无receipt或退出码7 | 合成为E_UNCLASSIFIED_EXCEPTION/3/系统停止 | DESIGN_PASS |
| R07 | Guardian在child启动后、PID receipt前崩溃 | lease未过期等待；到期仍有/不可识别child则fail-stop，不产生第二Worker | DESIGN_PASS |
| R08 | 漏掉runtime_root后仍声称10目录 | 精确集合/父子比较失败，不生成ACL计划 | DESIGN_PASS |
| R08-A | 上海registry.db挂到release_root | parent_target_id和city role不符，部署前拒绝 | DESIGN_PASS |
| R09 | 两个Guardian同时尝试OPEN→HALF_OPEN | CAS只允许一个probe+lease，另一个冲突 | DESIGN_PASS |
| R09-A | FAIL_STOP后进程自行恢复 | 无自动转换；缺独立恢复授权保持FAIL_STOP | DESIGN_PASS |

## 5. B01—B15回归核对

```text
B01=R01，实际封闭Registry实例、owner anchor和反向消费
B02=R02，单文件唯一批准权威和三城逻辑AS-OF向量
B03=继承，无ATTACH或跨库批准写事务
B04=继承+R05/R09，历史append-only、可变集合封闭
B05=继承，DatabaseIdentity+复合FK+城市trigger
B06=继承，M001—M018固定名称
B07=继承，PF001—PF016/DV001—DV008固定全集
B08=继承任务固定map+R08精确路径全集
B09=R03，非恒真且不冒充技能
B10=R04，持久事实/事件ID和family唯一键
B11=R05，slot唯一谓词和append-only恢复折叠
B12=R06，ErrorCode到Guardian action闭合函数
B13=R07，attempt/lease/child/recovery完整身份
B14=R08，10目录+10 DB实际闭合
B15=R09，HALF_OPEN/health/PathPolicy/recovery状态机
```

作者未发现ak2重新打开B03—B08已收敛问题。该判断必须由第二次独立审查重新反证。

## 6. 第一性原理边界检查

### 6.1 单一真相

Kernel规则只有Registry和其20个唯一Payload。Manifest以候选文件hash绑定整体，避免内部自引用hash。完整设计若在Registry外发明规则，不能通过反向消费检查。

作者状态：`DESIGN_PASS`。

### 6.2 三城独立

批准只聚合三份不可替换引用，不执行跨城写事务；Runtime/Event/Decision/slot/lease/health仍逐城。跨城身份错误是系统性不变量破坏，必须停止，不能把错误写入任一城市。

作者状态：`DESIGN_PASS`。

### 6.3 动态运行与统计样本

30秒只检查，不自动制造事实。来源事实、非来源原因、Event和family均有持久ID；动态评价次数不增加target-day独立样本权重。

作者状态：`DESIGN_PASS`。

### 6.4 资格边界

M007只检查反保守校准偏差。全零LCB可能通过M007但不能因此获得技能、模型、策略或交易资格；完整资格必须等待其余指标和阈值在未来阶段独立冻结。

作者状态：`DESIGN_PASS_WITH_QUALIFICATION_BLOCKED`。

### 6.5 实际部署

路径、进程和恢复身份已经唯一，但文件系统持久性、ACE rights、SID、任务XML、具体阈值、实现和现场验证均未证明。因此Kernel设计完成不等于可部署。

作者状态：`DEPLOYMENT_BLOCKED_BY_SCOPE`。

## 7. 未证明事项

```text
SECOND_INDEPENDENT_AUDIT=NOT_AUTHORIZED/NOT_RUN
COMPLETE_V8_DESIGN=NO
IMPLEMENTATION=NO
IMPLEMENTATION_TESTED=NO
GIT_INTEGRATED=NO
FILESYSTEM_PUBLICATION_PROVEN=NO
ACL_RIGHTS_MATRIX_DESIGNED=NO
DEPLOYMENT=NO
SHADOW=NO
PAPER=NO
LIVE_TRADING=NO
FUNDS=NO
```

## 8. 作者裁决和停止点

```text
AK2_AUTHOR_SELFCHECK=PASS_DESIGN_ONLY
AK2_ARCHITECTURE_VALIDATED=NO
AK2_DESIGN_ACCEPTED=NO
SECOND_INDEPENDENT_AUDIT_AUTHORIZED=NO
READY_FOR_COMPLETE_V8_DESIGN=NO
```

结论：作者级检查认为R01—R09和B01—B15已在Kernel设计层形成唯一规范与失败反例，但作者不能认证自己的关键输出。形成新Manifest后必须停止，等待用户独立授权T01第二次Kernel审查。
