"""Local paper-trading ledger for the weather research dashboard.

This module never imports a wallet or a trading client.  Fills are simulated
only from quotes already captured in the local research database.
"""
from __future__ import annotations

import sqlite3
import uuid
import json
import math
from contextlib import closing
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from pathlib import Path
from execution_evidence import FeeSchedule, LiquidityRole
from polymarket_rules import (
    RuleError,
    fee_for_fill,
    is_marketable,
    normalize_time_in_force,
    rules_for_market,
    validate_order_constraints,
)
from ui_events import ensure_paper_events


ACCOUNT_ID = "research"
STARTING_CASH = 1000.0
MIN_LOT = 5.0
MAX_POSITION = 25.0
MAX_QUOTE_AGE_SECONDS = 20.0
# Displayed top-of-book quantity is shared liquidity, not a guarantee that a
# newly placed paper order receives all of it.  Use at most half of it per
# observed quote; subsequent quote events may complete a partial order.
SIMULATED_BOOK_PARTICIPATION = 0.50
GTD_SECURITY_THRESHOLD_SECONDS = 60


class PaperError(ValueError):
    pass


def _ensure_column(db: sqlite3.Connection, table: str, column: str, definition: str) -> None:
    columns = {str(row[1]) for row in db.execute(f"PRAGMA table_info({table})")}
    if column not in columns:
        db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


class PaperBroker:
    def __init__(self, database: Path) -> None:
        self.database = database
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        db = sqlite3.connect(self.database, timeout=30)
        db.row_factory = sqlite3.Row
        # The research database is bootstrapped in WAL mode.  Changing its
        # journal mode here requires an exclusive lock and can interrupt the
        # collector/quote writer; paper simulation must coexist with them.
        db.execute("PRAGMA busy_timeout=30000")
        # This ledger has an independent writer (the simulator) and several
        # readers (dashboard/supervisor).  DELETE journaling caused routine
        # read/write collisions and simulator restart loops on Windows.
        # WAL permits readers while one short paper-ledger transaction writes.
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=NORMAL")
        return db

    def _init_schema(self) -> None:
        with closing(self._connect()) as db, db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS paper_accounts (
              account_id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
              starting_cash REAL NOT NULL, cash REAL NOT NULL,
              realized_pnl REAL NOT NULL DEFAULT 0,
              fees_paid REAL NOT NULL DEFAULT 0, status TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS paper_orders (
              order_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
              created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
              market_id TEXT NOT NULL, token_id TEXT NOT NULL,
              city TEXT NOT NULL, target_date TEXT NOT NULL, bucket TEXT NOT NULL,
              side TEXT NOT NULL, order_type TEXT NOT NULL, quantity REAL NOT NULL,
              limit_price REAL, status TEXT NOT NULL, filled_quantity REAL NOT NULL DEFAULT 0,
              avg_fill_price REAL, reason TEXT NOT NULL, last_quote_at TEXT,
              submitted_quote_at TEXT, time_in_force TEXT NOT NULL DEFAULT 'GTC',
              post_only INTEGER NOT NULL DEFAULT 0, expires_at TEXT, cancel_reason TEXT,
              rules_version TEXT NOT NULL DEFAULT 'legacy-no-rules',
              rules_source TEXT NOT NULL DEFAULT 'legacy',
              tick_size REAL NOT NULL DEFAULT 0.01,
              min_order_size REAL NOT NULL DEFAULT 5,
              neg_risk INTEGER NOT NULL DEFAULT 1,
              fee_schedule_version TEXT NOT NULL DEFAULT 'legacy-no-fee',
              platform_fee_rate REAL NOT NULL DEFAULT 0,
              platform_taker_only INTEGER NOT NULL DEFAULT 1,
              maker_builder_bps INTEGER NOT NULL DEFAULT 0,
              taker_builder_bps INTEGER NOT NULL DEFAULT 0,
              worst_price REAL);
            CREATE TABLE IF NOT EXISTS paper_positions (
              account_id TEXT NOT NULL, token_id TEXT NOT NULL, market_id TEXT NOT NULL,
              city TEXT NOT NULL, target_date TEXT NOT NULL, bucket TEXT NOT NULL,
              quantity REAL NOT NULL, avg_cost REAL NOT NULL, realized_pnl REAL NOT NULL DEFAULT 0,
              fees_paid REAL NOT NULL DEFAULT 0,
              updated_at TEXT NOT NULL, PRIMARY KEY(account_id,token_id));
            CREATE TABLE IF NOT EXISTS paper_fills (
              fill_id TEXT PRIMARY KEY, order_id TEXT NOT NULL, filled_at TEXT NOT NULL,
              side TEXT NOT NULL, quantity REAL NOT NULL, price REAL NOT NULL,
              notional REAL NOT NULL, quote_at TEXT NOT NULL, reason TEXT NOT NULL,
              liquidity_role TEXT NOT NULL DEFAULT 'legacy_unknown',
              platform_fee REAL NOT NULL DEFAULT 0,
              builder_fee REAL NOT NULL DEFAULT 0,
              total_fee REAL NOT NULL DEFAULT 0,
              fee_schedule_version TEXT NOT NULL DEFAULT 'legacy-no-fee',
              net_cash_flow REAL NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS paper_sessions (
              session_id TEXT PRIMARY KEY, target_date TEXT NOT NULL UNIQUE,
              started_at TEXT NOT NULL, starting_cash REAL NOT NULL,
              rules_json TEXT NOT NULL, status TEXT NOT NULL, note TEXT);
            CREATE TABLE IF NOT EXISTS paper_settlements (
              settlement_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
              token_id TEXT NOT NULL, market_id TEXT NOT NULL,
              city TEXT NOT NULL, target_date TEXT NOT NULL, bucket TEXT NOT NULL,
              settled_at TEXT NOT NULL, resolution_at TEXT NOT NULL,
              payout_per_share REAL NOT NULL, quantity REAL NOT NULL,
              avg_cost REAL NOT NULL, cash_delta REAL NOT NULL,
              realized_pnl REAL NOT NULL, reason TEXT NOT NULL,
              UNIQUE(account_id,token_id,market_id));
            CREATE INDEX IF NOT EXISTS idx_paper_orders_status ON paper_orders(account_id,status,created_at);
            CREATE INDEX IF NOT EXISTS idx_paper_fills_time ON paper_fills(filled_at,order_id);
            CREATE UNIQUE INDEX IF NOT EXISTS idx_paper_fills_order_quote ON paper_fills(order_id,quote_at);
            CREATE TABLE IF NOT EXISTS paper_quote_marks (
              token_id TEXT PRIMARY KEY, best_bid REAL, best_ask REAL,
              bid_size REAL, ask_size REAL,
              captured_at TEXT NOT NULL
            );
            """)
            now = datetime.now(UTC).isoformat()
            db.execute("""INSERT OR IGNORE INTO paper_accounts
              (account_id,created_at,starting_cash,cash,realized_pnl,status)
              VALUES (?,?,?,?,0,'ACTIVE')""", (ACCOUNT_ID, now, STARTING_CASH, STARTING_CASH))
            mark_columns = {row[1] for row in db.execute("PRAGMA table_info(paper_quote_marks)")}
            if "bid_size" not in mark_columns:
                db.execute("ALTER TABLE paper_quote_marks ADD COLUMN bid_size REAL")
            if "ask_size" not in mark_columns:
                db.execute("ALTER TABLE paper_quote_marks ADD COLUMN ask_size REAL")
            migrations = {
                "paper_accounts": {
                    "fees_paid": "REAL NOT NULL DEFAULT 0",
                },
                "paper_orders": {
                    "submitted_quote_at": "TEXT",
                    "time_in_force": "TEXT NOT NULL DEFAULT 'GTC'",
                    "post_only": "INTEGER NOT NULL DEFAULT 0",
                    "expires_at": "TEXT",
                    "cancel_reason": "TEXT",
                    "rules_version": "TEXT NOT NULL DEFAULT 'legacy-no-rules'",
                    "rules_source": "TEXT NOT NULL DEFAULT 'legacy'",
                    "tick_size": "REAL NOT NULL DEFAULT 0.01",
                    "min_order_size": "REAL NOT NULL DEFAULT 5",
                    "neg_risk": "INTEGER NOT NULL DEFAULT 1",
                    "fee_schedule_version": "TEXT NOT NULL DEFAULT 'legacy-no-fee'",
                    "platform_fee_rate": "REAL NOT NULL DEFAULT 0",
                    "platform_taker_only": "INTEGER NOT NULL DEFAULT 1",
                    "maker_builder_bps": "INTEGER NOT NULL DEFAULT 0",
                    "taker_builder_bps": "INTEGER NOT NULL DEFAULT 0",
                    "worst_price": "REAL",
                },
                "paper_positions": {
                    "fees_paid": "REAL NOT NULL DEFAULT 0",
                },
                "paper_fills": {
                    "liquidity_role": "TEXT NOT NULL DEFAULT 'legacy_unknown'",
                    "platform_fee": "REAL NOT NULL DEFAULT 0",
                    "builder_fee": "REAL NOT NULL DEFAULT 0",
                    "total_fee": "REAL NOT NULL DEFAULT 0",
                    "fee_schedule_version": "TEXT NOT NULL DEFAULT 'legacy-no-fee'",
                    "net_cash_flow": "REAL NOT NULL DEFAULT 0",
                },
            }
            for table, columns in migrations.items():
                for column, definition in columns.items():
                    _ensure_column(db, table, column, definition)
            # Ledger mutations and dashboard paper events are one transaction.
            ensure_paper_events(db)

    def begin_session(self, target_date: str, note: str = "") -> dict:
        """Start one auditable local simulation session; never connects a wallet."""
        rules = {"entry_lot": MIN_LOT, "max_position": MAX_POSITION,
                  "sequential_entries": True, "exit_all": True,
                  "quote_max_age_seconds": MAX_QUOTE_AGE_SECONDS,
                  "exchange_constraints": "polymarket_market_metadata_or_weather_v2_fallback",
                  "market_order_time_in_force": "FOK",
                  "fees_net_of_cash_and_pnl": True,
                  "mode": "local_paper_auto_only"}
        with closing(self._connect()) as db, db:
            existing = db.execute("SELECT * FROM paper_sessions WHERE target_date=?", (target_date,)).fetchone()
            if existing:
                return {"ok": True, "created": False, "session": dict(existing)}
            now = datetime.now(UTC).isoformat()
            session = {"session_id": f"paper-session-{uuid.uuid4()}", "target_date": target_date,
                       "started_at": now, "starting_cash": STARTING_CASH,
                       "rules_json": json.dumps(rules, ensure_ascii=False), "status": "ACTIVE", "note": note}
            db.execute("""INSERT INTO paper_sessions
              (session_id,target_date,started_at,starting_cash,rules_json,status,note)
              VALUES (:session_id,:target_date,:started_at,:starting_cash,:rules_json,:status,:note)""", session)
            return {"ok": True, "created": True, "session": session}

    def reset_current_exposure(self, *, cash: float, reason: str) -> dict:
        """Reset only live paper exposure while retaining the audit history.

        Filled orders/fills are historical evidence and are never deleted.
        Open orders are cancelled, current positions are removed, and a reset
        event records exactly what was cleared before the account is funded.
        """
        cash = float(cash)
        if cash < 0:
            raise PaperError("paper reset cash cannot be negative")
        with closing(self._connect()) as db, db:
            db.execute("""CREATE TABLE IF NOT EXISTS paper_reset_events (
              reset_at TEXT NOT NULL, account_id TEXT NOT NULL, reason TEXT NOT NULL,
              prior_cash REAL NOT NULL, cancelled_orders INTEGER NOT NULL,
              cleared_positions INTEGER NOT NULL, new_cash REAL NOT NULL)""")
            account = db.execute("SELECT cash FROM paper_accounts WHERE account_id=?", (ACCOUNT_ID,)).fetchone()
            if not account:
                raise PaperError("paper account is missing")
            now = datetime.now(UTC).isoformat()
            cancelled = db.execute("""UPDATE paper_orders SET status='CANCELLED',updated_at=?
              WHERE account_id=? AND status IN ('OPEN','PARTIAL')""", (now, ACCOUNT_ID)).rowcount
            positions = db.execute("SELECT COUNT(*) FROM paper_positions WHERE account_id=? AND quantity>0.000001",
                                   (ACCOUNT_ID,)).fetchone()[0]
            db.execute("DELETE FROM paper_positions WHERE account_id=?", (ACCOUNT_ID,))
            db.execute("DELETE FROM paper_quote_marks")
            if db.execute("""SELECT 1 FROM sqlite_master
              WHERE type='table' AND name='paper_position_risk_state'""").fetchone():
                db.execute("DELETE FROM paper_position_risk_state")
            if db.execute("""SELECT 1 FROM sqlite_master
              WHERE type='table' AND name='paper_signal_cycles'""").fetchone():
                db.execute("DELETE FROM paper_signal_cycles")
            db.execute("""UPDATE paper_accounts
              SET starting_cash=?,cash=?,realized_pnl=0,fees_paid=0,status='ACTIVE'
              WHERE account_id=?""", (cash, cash, ACCOUNT_ID))
            db.execute("""INSERT INTO paper_reset_events
              (reset_at,account_id,reason,prior_cash,cancelled_orders,cleared_positions,new_cash)
              VALUES (?,?,?,?,?,?,?)""", (now, ACCOUNT_ID, reason, float(account[0]), cancelled, positions, cash))
            return {"ok": True, "cancelled_orders": int(cancelled), "cleared_positions": int(positions),
                    "prior_cash": float(account[0]), "cash": cash}

    @staticmethod
    def _quote(db: sqlite3.Connection, token: str) -> sqlite3.Row | None:
        # The isolated paper ledger retains only one current mark per token.
        return db.execute("""SELECT best_bid,best_ask,bid_size,ask_size,captured_at
          FROM paper_quote_marks WHERE token_id=?""", (token,)).fetchone()

    def sync_quote_marks(self, quotes: dict[str, tuple]) -> None:
        """Copy bounded current BBO marks into the paper ledger in one short write.

        This is intentionally a projection, not a second quote history.  It
        keeps the paper database independent from research.sqlite3 while
        preserving mark-to-market and stale-quote safeguards.
        """
        rows = []
        for token, values in quotes.items():
            if len(values) == 3:
                bid, ask, captured_at = values; bid_size = ask_size = None
            else:
                bid, ask, bid_size, ask_size, captured_at = values
            if captured_at is not None:
                rows.append((token, bid, ask, bid_size, ask_size, captured_at))
        if not rows:
            return
        with closing(self._connect()) as db, db:
            db.executemany("""INSERT INTO paper_quote_marks
              (token_id,best_bid,best_ask,bid_size,ask_size,captured_at)
              VALUES (?,?,?,?,?,?) ON CONFLICT(token_id) DO UPDATE SET
              best_bid=excluded.best_bid,best_ask=excluded.best_ask,
              bid_size=excluded.bid_size,ask_size=excluded.ask_size,captured_at=excluded.captured_at""", rows)

    @staticmethod
    def _quote_age(quote_at: str) -> float:
        stamp = datetime.fromisoformat(quote_at.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=UTC)
        return max(0.0, (datetime.now(UTC) - stamp).total_seconds())

    @staticmethod
    def _fee_schedule_from_order(order: sqlite3.Row) -> FeeSchedule:
        return FeeSchedule(
            version_id=str(order["fee_schedule_version"]),
            platform_rate=Decimal(str(order["platform_fee_rate"])),
            platform_taker_only=bool(order["platform_taker_only"]),
            maker_builder_bps=int(order["maker_builder_bps"]),
            taker_builder_bps=int(order["taker_builder_bps"]),
            rounding_quantum=Decimal("0.00001"),
        )

    @staticmethod
    def _cancel_order(db: sqlite3.Connection, order_id: str, reason: str) -> None:
        db.execute("""UPDATE paper_orders SET status='CANCELLED',cancel_reason=?,updated_at=?
          WHERE order_id=? AND status IN ('OPEN','PARTIAL')""",
          (reason, datetime.now(UTC).isoformat(), order_id))

    @staticmethod
    def _expired(order: sqlite3.Row) -> bool:
        expires_at = order["expires_at"]
        if not expires_at:
            return False
        stamp = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=UTC)
        return datetime.now(UTC) >= stamp

    @staticmethod
    def _liquidity_role(order: sqlite3.Row, quote_at: str) -> LiquidityRole:
        if str(order["order_type"]) == "MARKET":
            return LiquidityRole.TAKER
        if str(order["submitted_quote_at"] or "") == quote_at:
            return LiquidityRole.TAKER
        return LiquidityRole.MAKER

    @classmethod
    def _trade_fee(cls, order: sqlite3.Row, *, quantity: float,
                   price: float, role: LiquidityRole):
        return fee_for_fill(
            shares=quantity,
            price=price,
            role=role,
            schedule=cls._fee_schedule_from_order(order),
        )

    @classmethod
    def _affordable_buy_quantity(cls, order: sqlite3.Row, *, desired: float,
                                 price: float, cash: float,
                                 role: LiquidityRole) -> float:
        def all_in(quantity: float) -> float:
            if quantity <= 1e-12:
                return 0.0
            fee = cls._trade_fee(order, quantity=quantity, price=price, role=role)
            return quantity * price + float(fee.total_fee)

        if all_in(desired) <= cash + 1e-9:
            return desired
        low, high = 0.0, desired
        for _ in range(64):
            middle = (low + high) / 2
            if all_in(middle) <= cash + 1e-9:
                low = middle
            else:
                high = middle
        return low

    def _fill_once(self, db: sqlite3.Connection, order: sqlite3.Row, quote: sqlite3.Row) -> None:
        if self._expired(order):
            self._cancel_order(db, str(order["order_id"]), "gtd_expired")
            return
        quote_at = str(quote["captured_at"])
        if order["last_quote_at"] == quote_at:
            return
        remaining = float(order["quantity"]) - float(order["filled_quantity"])
        if remaining <= 1e-9:
            return
        side, kind = str(order["side"]), str(order["order_type"])
        bid, ask = quote["best_bid"], quote["best_ask"]
        available = quote["ask_size"] if side == "BUY" else quote["bid_size"]
        price = ask if side == "BUY" else bid
        limit_price = order["limit_price"]
        crosses = is_marketable(
            side=side,
            order_type=kind,
            limit_price=float(limit_price) if limit_price is not None else None,
            best_bid=float(bid) if bid is not None else None,
            best_ask=float(ask) if ask is not None else None,
        )
        claimed = db.execute("""UPDATE paper_orders SET last_quote_at=?,updated_at=?
          WHERE order_id=? AND COALESCE(last_quote_at,'')<>?""",
                             (quote_at, datetime.now(UTC).isoformat(), order["order_id"], quote_at)).rowcount
        if not claimed:
            return
        worst_price = order["worst_price"]
        if worst_price is not None and (
            (side == "BUY" and
             (price is None or float(price) > float(worst_price) + 1e-12))
            or (side == "SELL" and
                (price is None or float(price) + 1e-12 < float(worst_price)))
        ):
            self._cancel_order(
                db, str(order["order_id"]), "market_worst_price_exceeded"
            )
            return
        if not crosses:
            if str(order["time_in_force"]) in {"FAK", "FOK"}:
                self._cancel_order(db, str(order["order_id"]), "immediate_order_not_marketable")
            return
        # A missing displayed size is not permission to invent executable
        # depth.  Even a displayed size is shared with orders already queued
        # ahead of us, so the paper ledger takes only a conservative fraction
        # per observed BBO rather than claiming a full immediate fill.
        executable = max(0.0, float(available or 0.0)) * SIMULATED_BOOK_PARTICIPATION
        if str(order["time_in_force"]) == "FOK" and executable + 1e-9 < remaining:
            self._cancel_order(db, str(order["order_id"]), "fok_insufficient_displayed_depth")
            return
        fill_quantity = min(remaining, executable)
        if fill_quantity <= 1e-9:
            if str(order["time_in_force"]) in {"FAK", "FOK"}:
                self._cancel_order(db, str(order["order_id"]), "immediate_order_no_depth")
            return
        account = db.execute("SELECT cash FROM paper_accounts WHERE account_id=?", (ACCOUNT_ID,)).fetchone()
        position = db.execute("SELECT * FROM paper_positions WHERE account_id=? AND token_id=?",
                              (ACCOUNT_ID, order["token_id"])).fetchone()
        role = self._liquidity_role(order, quote_at)
        if side == "BUY":
            fill_quantity = self._affordable_buy_quantity(
                order,
                desired=fill_quantity,
                price=float(price),
                cash=float(account["cash"]),
                role=role,
            )
            if str(order["time_in_force"]) == "FOK" and fill_quantity + 1e-9 < remaining:
                self._cancel_order(db, str(order["order_id"]), "fok_insufficient_cash_including_fee")
                return
            if fill_quantity <= 1e-9:
                return
            fee = self._trade_fee(order, quantity=fill_quantity, price=float(price), role=role)
            total_fee = float(fee.total_fee)
            notional = fill_quantity * float(price)
            cash_delta = -(notional + total_fee)
            old_qty = float(position["quantity"]) if position else 0.0
            old_cost = float(position["avg_cost"]) if position else 0.0
            new_qty = old_qty + fill_quantity
            new_cost = (old_qty * old_cost + fill_quantity * float(price)) / new_qty
            db.execute("""UPDATE paper_accounts
              SET cash=cash+?,realized_pnl=realized_pnl-?,fees_paid=fees_paid+?
              WHERE account_id=?""", (cash_delta, total_fee, total_fee, ACCOUNT_ID))
            if position:
                db.execute("""UPDATE paper_positions SET quantity=?,avg_cost=?,
                  realized_pnl=realized_pnl-?,fees_paid=fees_paid+?,updated_at=?
                  WHERE account_id=? AND token_id=?""",
                  (new_qty, new_cost, total_fee, total_fee, datetime.now(UTC).isoformat(),
                   ACCOUNT_ID, order["token_id"]))
            else:
                db.execute("""INSERT INTO paper_positions
                  (account_id,token_id,market_id,city,target_date,bucket,quantity,avg_cost,
                   realized_pnl,fees_paid,updated_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                  (ACCOUNT_ID, order["token_id"], order["market_id"], order["city"],
                   order["target_date"], order["bucket"], new_qty, new_cost,
                   -total_fee, total_fee, datetime.now(UTC).isoformat()))
        else:
            held = float(position["quantity"]) if position else 0.0
            fill_quantity = min(fill_quantity, held)
            if str(order["time_in_force"]) == "FOK" and fill_quantity + 1e-9 < remaining:
                self._cancel_order(db, str(order["order_id"]), "fok_insufficient_position")
                return
            # A risk exit may use FAK so it can make immediate progress through
            # a thin bid.  Do not let that partial execution strand a positive
            # position below the exchange's minimum order size: such a residual
            # could no longer be submitted on the next quote.  Either finish the
            # whole position, or leave at least one valid minimum-size lot.
            minimum = max(float(order["min_order_size"] or MIN_LOT), MIN_LOT)
            residual = held - fill_quantity
            if (str(order["time_in_force"]) == "FAK"
                    and residual > 1e-9 and residual + 1e-9 < minimum):
                fill_quantity = max(0.0, held - minimum)
            if fill_quantity <= 1e-9:
                if str(order["time_in_force"]) == "FAK":
                    self._cancel_order(db, str(order["order_id"]), "fak_dust_residual_prevented")
                return
            fee = self._trade_fee(order, quantity=fill_quantity, price=float(price), role=role)
            total_fee = float(fee.total_fee)
            notional = fill_quantity * float(price)
            cash_delta = notional - total_fee
            pnl = (float(price) - float(position["avg_cost"])) * fill_quantity - total_fee
            new_qty = held - fill_quantity
            db.execute("""UPDATE paper_accounts SET cash=cash+?,realized_pnl=realized_pnl+?,
              fees_paid=fees_paid+? WHERE account_id=?""",
                       (cash_delta, pnl, total_fee, ACCOUNT_ID))
            db.execute("""UPDATE paper_positions SET quantity=?,realized_pnl=realized_pnl+?,
              fees_paid=fees_paid+?,updated_at=?
              WHERE account_id=? AND token_id=?""",
              (new_qty, pnl, total_fee, datetime.now(UTC).isoformat(), ACCOUNT_ID, order["token_id"]))
        old_filled = float(order["filled_quantity"])
        old_average = float(order["avg_fill_price"] or 0)
        total_filled = old_filled + fill_quantity
        average = (old_filled * old_average + fill_quantity * float(price)) / total_filled
        status = "FILLED" if total_filled + 1e-9 >= float(order["quantity"]) else "PARTIAL"
        now = datetime.now(UTC).isoformat()
        db.execute("""UPDATE paper_orders SET filled_quantity=?,avg_fill_price=?,status=?,updated_at=?
          WHERE order_id=?""", (total_filled, average, status, now, order["order_id"]))
        db.execute("""INSERT INTO paper_fills
          (fill_id,order_id,filled_at,side,quantity,price,notional,quote_at,reason,
           liquidity_role,platform_fee,builder_fee,total_fee,fee_schedule_version,net_cash_flow)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (f"fill-{uuid.uuid4()}", order["order_id"], now, side, fill_quantity, float(price),
           notional, quote_at, "captured_bbo", role.value, float(fee.platform_fee),
           float(fee.builder_fee), total_fee, fee.schedule_version, cash_delta))
        if status != "FILLED" and str(order["time_in_force"]) == "FAK":
            self._cancel_order(db, str(order["order_id"]), "fak_remainder_cancelled")

    def process(self, db: sqlite3.Connection, token: str | None = None) -> None:
        sql = """SELECT * FROM paper_orders WHERE account_id=?
          AND status IN ('OPEN','PARTIAL')"""
        params: list[object] = [ACCOUNT_ID]
        if token is not None:
            sql += " AND token_id=?"
            params.append(token)
        orders = db.execute(sql + " ORDER BY created_at", params).fetchall()
        for order in orders:
            if self._expired(order):
                self._cancel_order(db, str(order["order_id"]), "gtd_expired")
                continue
            quote = self._quote(db, str(order["token_id"]))
            if quote and self._quote_age(str(quote["captured_at"])) <= MAX_QUOTE_AGE_SECONDS:
                self._fill_once(db, order, quote)

    def process_open_orders(self) -> None:
        """Advance only existing orders from fresh captured BBO marks."""
        with closing(self._connect()) as db, db:
            self.process(db)

    def place(self, market: dict, side: str, order_type: str,
              quantity: float, limit_price: float | None, reason: str, *,
              time_in_force: str | None = None, post_only: bool = False,
              expires_at: str | None = None,
              worst_price: float | None = None) -> dict:
        side, order_type = side.upper(), order_type.upper()
        quantity = float(quantity)
        try:
            tif = normalize_time_in_force(order_type, time_in_force)
            rules = rules_for_market(market)
            validate_order_constraints(
                side=side, order_type=order_type, quantity=quantity,
                limit_price=limit_price, time_in_force=tif,
                post_only=post_only, rules=rules,
            )
        except (RuleError, ValueError) as exc:
            raise PaperError(str(exc)) from exc
        if worst_price is not None:
            try:
                worst_price = float(worst_price)
            except (TypeError, ValueError) as exc:
                raise PaperError("worst_price must be a finite price in [0,1]") from exc
            if not math.isfinite(worst_price) or not 0 <= worst_price <= 1:
                raise PaperError("worst_price must be a finite price in [0,1]")
            if order_type != "MARKET":
                raise PaperError("worst_price protection is only valid for MARKET orders")
        if order_type == "MARKET" and tif not in {"FAK", "FOK"}:
            raise PaperError("Polymarket市价单必须使用FAK或FOK")
        if tif == "GTD":
            if not expires_at:
                raise PaperError("GTD订单必须提供expires_at")
            try:
                expiry = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
                if expiry.tzinfo is None:
                    expiry = expiry.replace(tzinfo=UTC)
            except ValueError as exc:
                raise PaperError("expires_at必须是ISO时间") from exc
            if expiry < datetime.now(UTC) + timedelta(seconds=GTD_SECURITY_THRESHOLD_SECONDS):
                raise PaperError("GTD到期时间必须至少晚于当前时间60秒")
            expires_at = expiry.isoformat()
        elif expires_at is not None:
            raise PaperError("只有GTD订单可以提供expires_at")

        token = str(market["token"])
        with closing(self._connect()) as db, db:
            self.process(db)
            quote = self._quote(db, token)
            if not quote or self._quote_age(str(quote["captured_at"])) > MAX_QUOTE_AGE_SECONDS:
                raise PaperError(f"行情超过{MAX_QUOTE_AGE_SECONDS:g}秒未更新，禁止创建模拟订单")
            executable_price = quote["best_ask"] if side == "BUY" else quote["best_bid"]
            if worst_price is not None and (
                executable_price is None
                or (side == "BUY" and float(executable_price) > worst_price + 1e-12)
                or (side == "SELL" and float(executable_price) + 1e-12 < worst_price)
            ):
                raise PaperError("worst_price protection rejected current market price")
            marketable = is_marketable(
                side=side, order_type=order_type,
                limit_price=float(limit_price) if limit_price is not None else None,
                best_bid=float(quote["best_bid"]) if quote["best_bid"] is not None else None,
                best_ask=float(quote["best_ask"]) if quote["best_ask"] is not None else None,
            )
            if post_only and marketable:
                raise PaperError("post-only订单会立即吃单，已按Polymarket规则拒绝")

            position = db.execute("SELECT quantity FROM paper_positions WHERE account_id=? AND token_id=?",
                                  (ACCOUNT_ID, token)).fetchone()
            held = float(position["quantity"]) if position else 0.0
            if side == "BUY":
                open_buys = db.execute("""SELECT COALESCE(SUM(quantity-filled_quantity),0) FROM paper_orders
                  WHERE account_id=? AND token_id=? AND side='BUY' AND status IN ('OPEN','PARTIAL')""",
                  (ACCOUNT_ID, token)).fetchone()[0]
                if float(open_buys) > 1e-9:
                    raise PaperError("上一笔模拟买单尚未完全成交或撤销")
                if held + float(open_buys) + quantity > MAX_POSITION + 1e-9:
                    raise PaperError("单个温度桶最多模拟持有25份（5份×5次）")
                account_cash = float(db.execute("SELECT cash FROM paper_accounts WHERE account_id=?",
                                                (ACCOUNT_ID,)).fetchone()[0])
                reservation_price = float(limit_price if order_type == "LIMIT" else quote["best_ask"] or 1)
                reservation_fee = fee_for_fill(
                    shares=quantity, price=reservation_price,
                    role=LiquidityRole.TAKER, schedule=rules.fee_schedule,
                )
                required_cash = quantity * reservation_price + float(reservation_fee.total_fee)
                if required_cash > account_cash + 1e-9:
                    raise PaperError("模拟账户现金不足（已包含最坏情形手续费）")
            else:
                open_sells = float(db.execute("""SELECT COALESCE(SUM(quantity-filled_quantity),0) FROM paper_orders
                  WHERE account_id=? AND token_id=? AND side='SELL' AND status IN ('OPEN','PARTIAL')""",
                  (ACCOUNT_ID, token)).fetchone()[0])
                if quantity > held - open_sells + 1e-9:
                    raise PaperError("模拟卖出数量超过未冻结持仓")

            now = datetime.now(UTC).isoformat()
            order_id = f"paper-{uuid.uuid4()}"
            db.execute("""INSERT INTO paper_orders
              (order_id,account_id,created_at,updated_at,market_id,token_id,city,target_date,bucket,
               side,order_type,quantity,limit_price,status,filled_quantity,reason,
               submitted_quote_at,time_in_force,post_only,expires_at,rules_version,rules_source,
               tick_size,min_order_size,neg_risk,fee_schedule_version,platform_fee_rate,
               platform_taker_only,maker_builder_bps,taker_builder_bps,worst_price)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'OPEN',0,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (order_id, ACCOUNT_ID, now, now, str(market["id"]), token, str(market["city"]),
               str(market["date"]), str(market["bucket"]), side, order_type, quantity,
               float(limit_price) if limit_price is not None else None, reason or "manual_paper",
               str(quote["captured_at"]), tif, int(bool(post_only)), expires_at,
               rules.version_id, rules.metadata_source, float(rules.tick_size),
               float(rules.min_order_size), int(rules.neg_risk), rules.fee_schedule.version_id,
               float(rules.fee_schedule.platform_rate), int(rules.fee_schedule.platform_taker_only),
               rules.fee_schedule.maker_builder_bps, rules.fee_schedule.taker_builder_bps,
               worst_price))
            order = db.execute("SELECT * FROM paper_orders WHERE order_id=?", (order_id,)).fetchone()
            self._fill_once(db, order, quote)
            state = db.execute("SELECT status,filled_quantity,cancel_reason FROM paper_orders WHERE order_id=?",
                               (order_id,)).fetchone()
            return {"ok": True, "order_id": order_id, "status": state["status"],
                    "filled_quantity": float(state["filled_quantity"]),
                    "cancel_reason": state["cancel_reason"], "time_in_force": tif}

    def exit_all(self, market: dict, reason: str = "manual_exit_all") -> dict:
        with closing(self._connect()) as db, db:
            position = db.execute("SELECT quantity FROM paper_positions WHERE account_id=? AND token_id=?",
                                  (ACCOUNT_ID, str(market["token"]))).fetchone()
            quantity = float(position["quantity"]) if position else 0.0
            quote = self._quote(db, str(market["token"]))
            worst_bid = (
                float(quote["best_bid"])
                if quote is not None and quote["best_bid"] is not None else None
            )
        if quantity <= 1e-9:
            raise PaperError("当前温度桶没有模拟持仓")
        if worst_bid is None:
            raise PaperError("cannot exit without a current executable bid")
        return self.place(
            market, "SELL", "MARKET", quantity, None, reason,
            worst_price=worst_bid,
        )

    def settle_resolved_positions(self, resolutions: list[dict]) -> list[dict]:
        """Settle held YES shares once at the binary market payout."""
        settled: list[dict] = []
        with closing(self._connect()) as db, db:
            for resolution in resolutions:
                market_id = str(resolution.get("market_id") or "")
                yes_resolved = resolution.get("yes_resolved")
                resolution_at = str(resolution.get("resolved_at") or "")
                if not market_id or yes_resolved not in {0, 1} or not resolution_at:
                    continue
                position = db.execute("""SELECT * FROM paper_positions
                  WHERE account_id=? AND market_id=? AND quantity>0.000001""",
                  (ACCOUNT_ID, market_id)).fetchone()
                if not position:
                    continue
                duplicate = db.execute("""SELECT 1 FROM paper_settlements
                  WHERE account_id=? AND token_id=? AND market_id=?""",
                  (ACCOUNT_ID, position["token_id"], market_id)).fetchone()
                if duplicate:
                    continue
                quantity = float(position["quantity"])
                avg_cost = float(position["avg_cost"])
                payout = float(int(yes_resolved))
                cash_delta = quantity * payout
                pnl = (payout - avg_cost) * quantity
                settled_at = datetime.now(UTC).isoformat()
                db.execute("""UPDATE paper_accounts
                  SET cash=cash+?,realized_pnl=realized_pnl+?
                  WHERE account_id=?""", (cash_delta, pnl, ACCOUNT_ID))
                db.execute("""UPDATE paper_positions
                  SET quantity=0,realized_pnl=realized_pnl+?,updated_at=?
                  WHERE account_id=? AND token_id=?""",
                  (pnl, settled_at, ACCOUNT_ID, position["token_id"]))
                db.execute("""UPDATE paper_orders SET status='CANCELLED',
                  cancel_reason='market_resolved',updated_at=?
                  WHERE account_id=? AND token_id=? AND status IN ('OPEN','PARTIAL')""",
                  (settled_at, ACCOUNT_ID, position["token_id"]))
                db.execute("""INSERT INTO paper_settlements
                  (settlement_id,account_id,token_id,market_id,city,target_date,bucket,
                   settled_at,resolution_at,payout_per_share,quantity,avg_cost,
                   cash_delta,realized_pnl,reason)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                  (f"settlement-{uuid.uuid4()}", ACCOUNT_ID, position["token_id"],
                   market_id, position["city"], position["target_date"],
                   position["bucket"], settled_at, resolution_at, payout, quantity,
                   avg_cost, cash_delta, pnl, "market_resolution"))
                if db.execute("""SELECT 1 FROM sqlite_master
                  WHERE type='table' AND name='paper_position_risk_state'""").fetchone():
                    db.execute("""UPDATE paper_position_risk_state
                      SET last_exit_reason=?,last_evaluated_at=? WHERE token_id=?""",
                      ("settled_yes" if yes_resolved else "settled_no",
                       settled_at, position["token_id"]))
                if db.execute("""SELECT 1 FROM sqlite_master
                  WHERE type='table' AND name='paper_signal_cycles'""").fetchone():
                    db.execute("""UPDATE paper_signal_cycles
                      SET state='SEALED',sealed_at=COALESCE(sealed_at,?),
                          seal_reason=COALESCE(seal_reason,?),updated_at=?
                      WHERE market_token=? AND target_date=?""",
                      (settled_at,
                       "settled_yes" if yes_resolved else "settled_no",
                       settled_at, position["token_id"], position["target_date"]))
                settled.append({
                    "token": str(position["token_id"]), "market_id": market_id,
                    "city": str(position["city"]), "bucket": str(position["bucket"]),
                    "quantity": quantity, "payout_per_share": payout,
                    "cash_delta": cash_delta, "realized_pnl": pnl,
                    "resolution_at": resolution_at,
                })
        return settled

    def cancel(self, order_id: str) -> dict:
        with closing(self._connect()) as db, db:
            changed = db.execute("""UPDATE paper_orders SET status='CANCELLED',cancel_reason='manual_cancel',updated_at=?
              WHERE order_id=? AND account_id=? AND status IN ('OPEN','PARTIAL')""",
              (datetime.now(UTC).isoformat(), order_id, ACCOUNT_ID)).rowcount
        return {"ok": bool(changed)}

    def cancel_open_orders(self, token: str, side: str | None = None) -> dict:
        """Cancel outstanding local orders for one token before an exit/cutoff."""
        sql = """UPDATE paper_orders SET status='CANCELLED',cancel_reason='strategy_cancel',updated_at=?
          WHERE account_id=? AND token_id=? AND status IN ('OPEN','PARTIAL')"""
        params: list[object] = [datetime.now(UTC).isoformat(), ACCOUNT_ID, str(token)]
        if side is not None:
            normalized = side.upper()
            if normalized not in {"BUY", "SELL"}:
                raise PaperError("unsupported paper order side")
            sql += " AND side=?"
            params.append(normalized)
        with closing(self._connect()) as db, db:
            changed = db.execute(sql, params).rowcount
        return {"ok": True, "cancelled": int(changed)}

    def open_orders(self) -> list[dict]:
        """Return every live paper order; lifecycle code must not use UI limits."""
        with closing(self._connect()) as db:
            rows = db.execute("""SELECT * FROM paper_orders WHERE account_id=?
              AND status IN ('OPEN','PARTIAL') ORDER BY created_at""",
              (ACCOUNT_ID,)).fetchall()
            return [dict(row) for row in rows]

    def last_buy_quote_at(self, token: str) -> str | None:
        """Return the last quote atomically consumed by a submitted buy order."""
        with closing(self._connect()) as db:
            row = db.execute("""SELECT last_quote_at FROM paper_orders
              WHERE account_id=? AND token_id=? AND side='BUY'
                AND last_quote_at IS NOT NULL
              ORDER BY created_at DESC LIMIT 1""",
              (ACCOUNT_ID, str(token))).fetchone()
            return str(row[0]) if row else None

    def snapshot(self) -> dict:
        with closing(self._connect()) as db, db:
            # Fills are event-driven in realtime_stream.py. A dashboard refresh
            # must remain read-only so merely opening the page cannot alter a run.
            account = db.execute("SELECT * FROM paper_accounts WHERE account_id=?", (ACCOUNT_ID,)).fetchone()
            positions = []
            for row in db.execute("""SELECT * FROM paper_positions WHERE account_id=? AND quantity>0.000001
              ORDER BY updated_at DESC""", (ACCOUNT_ID,)):
                quote = self._quote(db, str(row["token_id"]))
                mark = float(quote["best_bid"]) if quote and quote["best_bid"] is not None else None
                unrealized = ((mark - float(row["avg_cost"])) * float(row["quantity"])) if mark is not None else None
                positions.append({**dict(row), "mark": mark, "unrealized_pnl": unrealized,
                                  "quote_at": str(quote["captured_at"]) if quote else None})
            orders = [dict(row) for row in db.execute("""SELECT * FROM paper_orders WHERE account_id=?
              ORDER BY created_at DESC LIMIT 30""", (ACCOUNT_ID,))]
            fills = [dict(row) for row in db.execute("""SELECT f.* FROM paper_fills f JOIN paper_orders o
              ON o.order_id=f.order_id WHERE o.account_id=? ORDER BY f.filled_at DESC LIMIT 30""", (ACCOUNT_ID,))]
            settlements = [dict(row) for row in db.execute("""SELECT * FROM paper_settlements
              WHERE account_id=? ORDER BY settled_at DESC LIMIT 30""", (ACCOUNT_ID,))]
            unrealized_total = sum(float(row["unrealized_pnl"] or 0) for row in positions)
            market_value = sum(float(row["quantity"]) * float(row["mark"] or 0) for row in positions)
            return {"account": dict(account), "positions": positions, "orders": orders,
                    "fills": fills, "settlements": settlements,
                    "unrealized_pnl": unrealized_total,
                    "equity": float(account["cash"]) + market_value,
                    "rules": {"min_lot": MIN_LOT, "max_position": MAX_POSITION,
                    "max_quote_age_seconds": MAX_QUOTE_AGE_SECONDS,
                    "simulated_book_participation": SIMULATED_BOOK_PARTICIPATION}}
