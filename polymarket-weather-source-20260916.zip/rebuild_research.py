"""Build a compact live research database from a frozen oversized archive.

This tool is intentionally additive: it never modifies the source database.
It excludes raw BBO/depth history and paper-ledger tables, while retaining the
forecast, settlement, market metadata, compact price bars and current book
projection needed by the dashboard and research replay.
"""
from __future__ import annotations

import argparse
import sqlite3
from datetime import UTC, datetime, timedelta
from pathlib import Path


RAW_ONLY = {"book_snapshots", "orderbook_levels", "forecast_raw_payloads"}
PAPER_ONLY = {"paper_accounts", "paper_auto_decisions", "paper_auto_model_signals",
              "paper_auto_state", "paper_signal_cycles", "paper_fills", "paper_orders",
              "paper_positions", "paper_sessions", "auto_quote_path_shadow",
              "auto_quote_path_minutes"}
RUNTIME_ONLY = {"service_heartbeats"}


def condition(table: str, now: datetime) -> tuple[str, tuple]:
    if table == "book_price_bars":
        return " WHERE bucket_at>=?", ((now - timedelta(days=180)).isoformat(),)
    if table in {"market_snapshots", "collector_runs"}:
        return " WHERE captured_at>=?", ((now - timedelta(days=30)).isoformat(),)
    if table == "forecast_fetch_audits":
        return " WHERE requested_at>=?", ((now - timedelta(days=30)).isoformat(),)
    if table == "forecast_snapshots":
        # Needed only for current QXZX/TAF D0 evidence.
        return " WHERE captured_at>=?", ((now - timedelta(days=2)).isoformat(),)
    return "", ()


def copy_table(source: sqlite3.Connection, target: sqlite3.Connection, table: str, now: datetime) -> int:
    columns = [row[1] for row in source.execute(f'PRAGMA table_info("{table}")')]
    if not columns:
        return 0
    marks = ",".join("?" for _ in columns)
    names = ",".join(f'"{name}"' for name in columns)
    suffix, params = condition(table, now)
    cursor = source.execute(f'SELECT {names} FROM "{table}"{suffix}', params)
    copied = 0
    while rows := cursor.fetchmany(1000):
        target.executemany(f'INSERT INTO "{table}" ({names}) VALUES ({marks})', rows)
        copied += len(rows)
    return copied


def rebuild(source_path: Path, target_path: Path) -> dict[str, int]:
    if not source_path.exists():
        raise FileNotFoundError(source_path)
    if target_path.exists():
        raise FileExistsError(f"target already exists: {target_path}")
    source = sqlite3.connect(f"file:{source_path}?mode=ro", uri=True, timeout=30)
    target = sqlite3.connect(target_path, timeout=30)
    target.execute("PRAGMA journal_mode=WAL")
    target.execute("PRAGMA synchronous=FULL")
    now = datetime.now(UTC)
    copied: dict[str, int] = {}
    try:
        schema = list(source.execute("SELECT type,name,sql FROM sqlite_master "
                                     "WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY type='table' DESC"))
        for kind, name, sql in schema:
            if kind == "table":
                target.execute(sql)
        for kind, name, sql in schema:
            if kind == "index":
                # Build indexes after copying data; table primary-key indexes
                # already exist and preserve insert integrity during transfer.
                continue
        excluded = RAW_ONLY | PAPER_ONLY | RUNTIME_ONLY
        for kind, table, sql in schema:
            if kind != "table" or table in excluded:
                continue
            copied[table] = copy_table(source, target, table, now)
            target.commit()
        for kind, name, sql in schema:
            if kind == "index" and name and sql:
                target.execute(sql)
        target.commit()
        target.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        target.commit()
        return copied
    finally:
        source.close()
        target.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    args = parser.parse_args()
    result = rebuild(args.source, args.target)
    print("rebuild complete")
    for name, count in sorted(result.items()):
        print(f"{name}: {count}")
