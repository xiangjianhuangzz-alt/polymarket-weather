# T00｜V8 Architecture Kernel设计任务合同｜2026-09-02

状态：`COMPLETED_CANDIDATE_FROZEN_AWAITING_INDEPENDENT_AUDIT_AUTHORIZATION`  
任务编号：`PWM-V8-AK-001`  
授权来源：用户于2026-09-02明确授权按照正确下一步执行  
性质：最小架构内核设计；不是完整替代设计、实现、实现测试、Git集成、部署、激活、Shadow、Paper或交易授权

## 1. 唯一问题

V8.2-R1身份有效但独立终审发现B01—B15，证明其Canonical、批准、持久化、逐城隔离、Schema、模型资格、事件及部署合同不能由实现者唯一解释。本任务只形成一个最小Architecture Kernel候选，使这15项根因先具有单一规范和可失败反例。

## 2. 权威输入

1. `PROJECT_EXECUTION_PROTOCOL.md`和当前五份控制文档；
2. `T00_新动态策略设计输入基线_2026-08-31.md`；
3. `T00_V3唯一策略保留项_保守净优势公式归档_2026-08-30.md`；
4. `T01_新动态策略端到端研究架构独立终审_v8.2_r1_2026-09-01.md`及其冻结R1身份；
5. `T00_V8.2_R1独立终审FAIL后续路线决策审查_2026-09-02.md`；
6. V8、V8.1、R2、V8.2和R1只读历史设计与失败证据。

优先顺序为：当前用户授权与控制边界→设计输入基线→V3唯一公式/AS-OF原则→R1独立终审反例→本Kernel候选。旧候选不得补齐本Kernel语义。

## 3. 允许范围

- 更新README、TASK_CONTRACT、CURRENT_ISSUES、项目索引和系统架构，登记路线决策及Kernel候选状态；
- 新建本任务合同、一个Kernel候选、作者反例自检和Manifest；
- 只读核对全部V8文件、当前Git身份和R1冻结身份；
- 执行不写项目数据库、不调用外部接口的文本、哈希和设计级机械检查。

## 4. 明确禁止

- 不修改任何冻结V8/V8.1/R2/V8.2/R1候选、Manifest或终审证据；
- 不创建完整替代设计、`strategy_v8/`代码、Schema/DDL实现、实现测试或实际SQLite文件；
- 不修改Collector、Realtime、METAR、Dashboard或运行配置；
- 不暂存、提交、推送、合并或切换Git；
- 不修改数据库、Evidence、checkpoint、Seal、任务、ACL、网络、服务、环境、订单、资格或资金；
- 不读取或处理`backups/`；
- 不进行本Kernel独立审查，作者自检不能代替独立审查。

## 5. 必须保留的不变量

1. 单bucket BUY YES；
2. `E_conservative(B,t)=P_LCB(B|I_t)-C_executable(B,t)`；
3. 市场价格只进入成本；
4. Asia/Shanghai `07:00:00 <= t < 16:00:00`实时动态；
5. Strict AS-OF和后到事实不回写过去；
6. 上海、北京、广州从Evidence、训练、模型、资格、Runtime到恢复完全独立；
7. 上海`weatherol_shanghai/weatherol_d0`与ZSPD，北京/广州TAF与ZBAA/ZGGG；
8. 无订单、钱包、资金、Paper、Shadow或真实交易能力；
9. 当前HP账户/SID，不新增账户；
10. 设计、实现、验证、Git集成、部署、激活和交易资格逐层独立授权。

## 6. Kernel范围

```text
AK-A Canonical、稳定身份和唯一批准提交点：B01—B03
AK-B append-only、逐城数据库身份、Decision失效和恢复：B04、B05、B11、B15
AK-C Schema、资格指标、事件与Bootstrap语义：B06—B10
AK-D CLI、子进程、ACL和部署目标：B12—B15
AK-E CE-K01—CE-K15全量反例和双向关闭矩阵
```

同一B项可被多个域共同覆盖，但只能有一个最终规范来源。

## 7. 交付物

```text
T00_V8_ArchitectureKernel任务合同_2026-09-02.md
T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md
T00_新动态策略ArchitectureKernel设计自检_2026-09-02.md
T00_新动态策略ArchitectureKernel设计Manifest_2026-09-02.md
```

Manifest只绑定前三份成员，不绑定自身。路线决策和五份控制文档是输入/状态记录，不是Kernel规范成员。

## 8. 成功标准

- B01—B15每项均有唯一裁决、规范对象、失败行为和CE反例；
- Canonical引用不依赖连续位置编号；
- 任何跨城、历史改写、空检查、重复任务、恒真指标或双退出码反例都必须失败；
- 单文件批准不存在三Registry写入或跨库提交；
- Kernel不展开完整文件树、类、函数或实现细节，不冒充完整设计；
- 作者自检逐项给出PASS/FAIL与定位；
- 三成员hash与候选身份进入Manifest。

## 9. 停止点

四份交付物完成并冻结后停止。状态只能是：

```text
ARCHITECTURE_KERNEL_CANDIDATE_FROZEN=YES
AUTHOR_SELFCHECK=PASS_OR_FAIL
INDEPENDENT_AUDIT=NOT_AUTHORIZED/NOT_RUN
COMPLETE_REPLACEMENT_DESIGN=NO
IMPLEMENTATION/GIT/DEPLOYMENT=NO
```

只有用户另行授权独立Kernel审查且结果PASS，才可讨论完整替代设计。
