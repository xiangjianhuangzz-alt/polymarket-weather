from __future__ import annotations

import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from datetime import UTC, datetime, timedelta
from pathlib import Path

from stability_audit import (
    CHINA_TZ,
    RuntimeLogTail,
    StabilityAudit,
    actual_source_gate,
    d0_sample_gate,
    forecast_delivery_gate,
    paper_recovery_gate,
    report,
    universe_mismatch_gate,
)
from service_supervisor import latest_quote_age


class StabilityAuditTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.audit_db = self.root / "stability.sqlite3"
        self.quote_db = self.root / "realtime.sqlite3"
        db = sqlite3.connect(self.quote_db)
        try:
            db.execute("CREATE TABLE latest_bbo(token_id TEXT PRIMARY KEY,captured_at TEXT)")
            db.execute("INSERT INTO latest_bbo VALUES (?,?)", ("token", datetime.now(UTC).isoformat()))
            db.execute("CREATE TABLE service_heartbeats(service TEXT PRIMARY KEY,updated_at TEXT,detail TEXT)")
            db.execute("INSERT INTO service_heartbeats VALUES (?,?,?)", ("realtime_stream", datetime.now(UTC).isoformat(), "writer=ok"))
            db.commit()
        finally:
            db.close()

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_missing_audit_never_passes(self) -> None:
        self.assertEqual(report(self.audit_db)["state"], "NOT_STARTED")

    def test_existing_audit_schema_is_upgraded_without_losing_rows(self) -> None:
        db = sqlite3.connect(self.audit_db)
        try:
            db.execute("""CREATE TABLE quote_freshness_samples (
              sampled_at TEXT PRIMARY KEY,window_id TEXT NOT NULL,token_count INTEGER NOT NULL,
              fresh_token_count INTEGER NOT NULL,max_age_seconds REAL,read_error TEXT)""")
            db.execute("INSERT INTO quote_freshness_samples VALUES (?,?,?,?,?,?)",
                       ("2026-01-01T00:00:00+00:00", "old", 1, 1, 0.0, None))
            db.commit()
        finally:
            db.close()
        StabilityAudit(self.audit_db)
        db = sqlite3.connect(self.audit_db)
        try:
            columns = {row[1] for row in db.execute("PRAGMA table_info(quote_freshness_samples)")}
            self.assertIn("executable_fresh_token_count", columns)
            self.assertIn("stream_heartbeat_age_seconds", columns)
            self.assertIn("expected_universe_hash", columns)
            self.assertIn("subscribed_token_count", columns)
            self.assertIn("subscribed_universe_hash", columns)
            self.assertIn("universe_match", columns)
            self.assertEqual(db.execute("SELECT COUNT(*) FROM quote_freshness_samples").fetchone()[0], 1)
            self.assertIsNotNone(db.execute("""SELECT 1 FROM sqlite_master
              WHERE type='table' AND name='stage_e_gate_evidence'""").fetchone())
        finally:
            db.close()

    def test_window_with_short_duration_is_blocked(self) -> None:
        audit = StabilityAudit(self.audit_db)
        audit.begin_window()
        audit.sample_quotes(self.quote_db, {"token"})
        result = report(self.audit_db)
        self.assertEqual(result["state"], "BLOCKED")
        self.assertIn("48h_window_incomplete", result["blockers"])
        self.assertGreater(result["quote_executable_fresh_fraction_lt20"], 0.99)
        self.assertGreater(result["quote_stream_continuity_fraction_lt10"], 0.99)
        self.assertNotIn("quote_sample_read_error", result["blockers"])

    def test_unexpected_event_blocks_window(self) -> None:
        audit = StabilityAudit(self.audit_db)
        audit.begin_window()
        audit.event("collector", "worker_exited", "test")
        self.assertIn("unexpected_runtime_event", report(self.audit_db)["blockers"])

    def test_prior_active_window_is_failed_on_new_start(self) -> None:
        first = StabilityAudit(self.audit_db); first.begin_window()
        second = StabilityAudit(self.audit_db); second.begin_window()
        db = sqlite3.connect(self.audit_db)
        try:
            states = [row[0] for row in db.execute("SELECT state FROM stability_windows ORDER BY started_at")]
        finally:
            db.close()
        self.assertIn("FAILED", states)

    def test_freshness_uses_only_active_strategy_tokens_and_counts_missing(self) -> None:
        db = sqlite3.connect(self.quote_db)
        try:
            db.execute("INSERT INTO latest_bbo VALUES (?,?)", ("historic", "2000-01-01T00:00:00+00:00"))
            db.commit()
        finally:
            db.close()
        audit = StabilityAudit(self.audit_db)
        audit.begin_window()
        audit.sample_quotes(self.quote_db, {"token", "missing"})
        db = sqlite3.connect(self.audit_db)
        try:
            row = db.execute("SELECT token_count,fresh_token_count,executable_fresh_token_count FROM quote_freshness_samples").fetchone()
        finally:
            db.close()
        self.assertEqual(row, (2, 1, 1))

    def test_no_active_tokens_are_excluded_from_bbo_denominator(self) -> None:
        audit = StabilityAudit(self.audit_db)
        audit.begin_window()
        audit.sample_quotes(self.quote_db, set())
        db = sqlite3.connect(self.audit_db)
        try:
            row = db.execute("""SELECT token_count,read_error
              FROM quote_freshness_samples""").fetchone()
        finally:
            db.close()
        self.assertEqual(row, (0, None))
        result = report(self.audit_db)
        self.assertNotIn("quote_executable_freshness_below_99pct", result["blockers"])

    def test_universe_mismatch_is_recorded_separately(self) -> None:
        db = sqlite3.connect(self.quote_db)
        try:
            db.execute("""CREATE TABLE stream_connection_events (
              event_at TEXT,event_type TEXT,detail TEXT,universe_hash TEXT,
              token_count INTEGER,added_tokens_json TEXT,removed_tokens_json TEXT)""")
            db.execute("""INSERT INTO stream_connection_events VALUES
              (?,?,?,?,?,?,?)""", (
                datetime.now(UTC).isoformat(), "connected", "test",
                "subscribed", 1, "[]", "[]",
            ))
            db.commit()
        finally:
            db.close()
        audit = StabilityAudit(self.audit_db)
        audit.begin_window()
        audit.sample_quotes(
            self.quote_db, {"token"}, expected_universe_hash="expected"
        )
        db = sqlite3.connect(self.audit_db)
        try:
            row = db.execute("""SELECT subscribed_token_count,
              subscribed_universe_hash,universe_match
              FROM quote_freshness_samples""").fetchone()
        finally:
            db.close()
        self.assertEqual(row, (1, "subscribed", 0))
        self.assertIn("quote_universe_mismatch", report(self.audit_db)["blockers"])

    def test_transient_universe_expansion_converges_without_blocking(self) -> None:
        start = datetime(2026, 7, 29, 4, 8, 21, tzinfo=UTC)
        gate = universe_mismatch_gate([
            (start.isoformat(), 154, 110, "new", "old", 0, None),
            ((start + timedelta(seconds=10)).isoformat(),
             154, 110, "new", "old", 0, None),
            ((start + timedelta(seconds=20)).isoformat(),
             154, 154, "new", "new", 1, None),
        ])
        self.assertEqual(gate["status"], "pass")
        self.assertEqual(gate["transient_streaks"], 1)
        self.assertEqual(gate["blocking_streaks"], 0)
        self.assertEqual(gate["directions"], {"expected_ahead": 1})

    def test_persistent_or_unresolved_universe_mismatch_blocks(self) -> None:
        start = datetime(2026, 7, 29, 4, 8, 0, tzinfo=UTC)
        persistent = universe_mismatch_gate([
            (start.isoformat(), 154, 110, "new", "old", 0, None),
            ((start + timedelta(seconds=20)).isoformat(),
             154, 110, "new", "old", 0, None),
            ((start + timedelta(seconds=40)).isoformat(),
             154, 154, "new", "new", 1, None),
        ])
        unresolved = universe_mismatch_gate([
            (start.isoformat(), 154, 154, "new", "other", 0, None),
        ])
        self.assertEqual(persistent["status"], "blocked")
        self.assertEqual(unresolved["status"], "blocked")
        self.assertEqual(unresolved["directions"], {"set_mismatch": 1})

    def test_latest_dynamic_universe_event_replaces_connection_baseline(self) -> None:
        db = sqlite3.connect(self.quote_db)
        try:
            db.execute("""CREATE TABLE stream_connection_events (
              event_at TEXT,event_type TEXT,detail TEXT,universe_hash TEXT,
              token_count INTEGER,added_tokens_json TEXT,removed_tokens_json TEXT)""")
            db.execute(
                "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                ("2026-07-27T08:00:00+00:00", "connected", "test",
                 "old", 110, "[]", "[]"),
            )
            db.execute(
                "INSERT INTO stream_connection_events VALUES (?,?,?,?,?,?,?)",
                ("2026-07-27T09:00:00+00:00", "universe_changed", "dynamic",
                 "new", 165, '["added"]', "[]"),
            )
            db.commit()
        finally:
            db.close()
        audit = StabilityAudit(self.audit_db)
        audit.begin_window()

        audit.sample_quotes(
            self.quote_db, {"token"}, expected_universe_hash="new"
        )

        db = sqlite3.connect(self.audit_db)
        try:
            row = db.execute("""SELECT subscribed_token_count,
              subscribed_universe_hash,universe_match
              FROM quote_freshness_samples""").fetchone()
        finally:
            db.close()
        self.assertEqual(row, (165, "new", 1))

    def test_failed_window_can_never_pass(self) -> None:
        audit = StabilityAudit(self.audit_db)
        window = audit.begin_window()
        db = sqlite3.connect(self.audit_db)
        try:
            db.execute("""UPDATE stability_windows
              SET state='FAILED' WHERE window_id=?""", (window,))
            db.commit()
        finally:
            db.close()
        result = report(self.audit_db)
        self.assertEqual(result["state"], "FAILED")
        self.assertIn("window_state_not_eligible", result["blockers"])

    def test_guardian_restart_log_blocks_even_when_event_table_is_empty(self) -> None:
        audit = StabilityAudit(self.audit_db)
        window = audit.begin_window()
        db = sqlite3.connect(self.audit_db)
        try:
            db.execute("""UPDATE stability_windows SET started_at=?
              WHERE window_id=?""", (
                (datetime.now(UTC).replace(microsecond=0)
                 - timedelta(minutes=1)).isoformat(),
                window,
            ))
            db.commit()
        finally:
            db.close()
        logs = self.root / "logs"
        logs.mkdir()
        local = datetime.now(CHINA_TZ)
        line = (
            f"{local.strftime('%Y-%m-%d %H:%M:%S')},000 "
            "WARNING realtime_stream requires restart: worker_exited:1\n"
        )
        (logs / "realtime_stream_guardian.log").write_text(line, encoding="utf-8")
        result = report(self.audit_db, runtime_log_dir=logs)
        self.assertIn("unexpected_runtime_event", result["blockers"])
        self.assertEqual(result["guardian_restart_events"], 1)

    def test_actual_source_and_d0_gates_use_retained_evidence(self) -> None:
        observations = self.root / "observations.sqlite3"
        now = datetime(2026, 7, 29, 8, 0, tzinfo=UTC)
        db = sqlite3.connect(observations)
        try:
            db.execute("""CREATE TABLE metar_live_status (
              station TEXT,city TEXT,decision_scope TEXT,last_attempt_at TEXT,
              last_success_at TEXT,last_report_at TEXT,last_report_temperature_c REAL,
              state TEXT,detail TEXT,updated_at TEXT)""")
            db.execute("""INSERT INTO metar_live_status VALUES
              (?,?,?,?,?,?,?,?,?,?)""", (
                "TEST", "Beijing", "risk_exclusion", now.isoformat(),
                now.isoformat(), (now - timedelta(minutes=30)).isoformat(),
                30.0, "healthy", "ok", now.isoformat(),
            ))
            db.commit()
        finally:
            db.close()
        source = actual_source_gate(observations, now=now)
        self.assertEqual(source["status"], "pass")

        research = self.root / "research.sqlite3"
        db = sqlite3.connect(research)
        try:
            db.execute("""CREATE TABLE forecast_d0_registry (
              source TEXT,city TEXT,station TEXT,target_date TEXT,status TEXT,
              forecast_bucket INTEGER,first_captured_at TEXT)""")
            db.execute("""CREATE TABLE market_resolutions (
              city TEXT,target_date TEXT,bucket_label TEXT,yes_resolved INTEGER)""")
            for day in range(1, 8):
                target = f"2026-07-{day:02d}"
                db.execute("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?)",
                           ("weatherol_beijing", "Beijing", "TEST", target,
                            "valid_d0", 30, f"{target}T00:10:00+08:00"))
                db.execute("INSERT INTO market_resolutions VALUES (?,?,?,1)",
                           ("Beijing", target, "31" + chr(176) + "C"))
            db.commit()
        finally:
            db.close()
        gate = d0_sample_gate(research, source["eligible_cities"])
        self.assertEqual(gate["status"], "pass")
        self.assertEqual(gate["counts"]["Beijing"], 7)

    def test_d0_gate_counts_range_category_but_rejects_malformed_winner(self) -> None:
        research = self.root / "research.sqlite3"
        db = sqlite3.connect(research)
        try:
            db.execute("""CREATE TABLE forecast_d0_registry (
              source TEXT,city TEXT,target_date TEXT,status TEXT,
              forecast_bucket INTEGER,first_captured_at TEXT)""")
            db.execute("""CREATE TABLE market_resolutions (
              city TEXT,target_date TEXT,bucket_label TEXT,yes_resolved INTEGER)""")
            for city in ("Beijing", "Chengdu"):
                for day in range(1, 8):
                    target = f"2026-07-{day:02d}"
                    db.execute(
                        "INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?)",
                        (
                            f"weatherol_{city.lower()}", city, target,
                            "valid_d0", 31, f"{target}T00:10:00+08:00",
                        ),
                    )
                    label = "32" + chr(176) + "C"
                    if day == 7 and city == "Beijing":
                        label = "34" + chr(176) + "C or higher"
                    if day == 7 and city == "Chengdu":
                        label = "unparseable winner"
                    db.execute(
                        "INSERT INTO market_resolutions VALUES (?,?,?,1)",
                        (city, target, label),
                    )
            db.commit()
        finally:
            db.close()

        gate = d0_sample_gate(research, ["Beijing", "Chengdu"])

        self.assertEqual(gate["status"], "blocked")
        self.assertEqual(gate["counts"]["Beijing"], 7)
        self.assertEqual(gate["range_counts"]["Beijing"], 1)
        self.assertEqual(gate["counts"]["Chengdu"], 6)
        self.assertEqual(gate["insufficient"]["Chengdu"], 6)

    def test_actual_source_blocks_delayed_unavailable_or_stale_status(self) -> None:
        observations = self.root / "observations.sqlite3"
        now = datetime(2026, 7, 29, 8, 0, tzinfo=UTC)
        db = sqlite3.connect(observations)
        try:
            db.execute("""CREATE TABLE metar_live_status (
              station TEXT,city TEXT,decision_scope TEXT,last_attempt_at TEXT,
              last_success_at TEXT,last_report_at TEXT,last_report_temperature_c REAL,
              state TEXT,detail TEXT,updated_at TEXT)""")
            rows = [
                ("A", "Beijing", "risk_exclusion", now.isoformat(),
                 now.isoformat(), now.isoformat(), 30.0, "delayed", "late",
                 now.isoformat()),
                ("B", "Chengdu", "risk_exclusion", now.isoformat(),
                 now.isoformat(), now.isoformat(), 31.0, "unavailable", "down",
                 now.isoformat()),
                ("C", "Shanghai", "risk_exclusion",
                 (now - timedelta(minutes=4)).isoformat(),
                 (now - timedelta(minutes=4)).isoformat(), now.isoformat(),
                 29.0, "healthy", "old status",
                 (now - timedelta(minutes=4)).isoformat()),
            ]
            db.executemany("INSERT INTO metar_live_status VALUES (?,?,?,?,?,?,?,?,?,?)",
                           rows)
            db.commit()
        finally:
            db.close()
        gate = actual_source_gate(observations, now=now)
        self.assertEqual(gate["status"], "blocked")
        self.assertEqual(
            set(gate["unhealthy_cities"]),
            {"Beijing", "Chengdu", "Shanghai"},
        )

    def test_forecast_delivery_pairs_precision_and_three_minute_retry(self) -> None:
        research = self.root / "research.sqlite3"
        db = sqlite3.connect(research)
        try:
            db.execute("""CREATE TABLE forecast_delivery_windows (
              scheduled_at TEXT,schedule_kind TEXT,city TEXT,source TEXT,status TEXT,
              requested_at TEXT,received_at TEXT,source_reported_at TEXT,
              detail TEXT,completed_at TEXT)""")
            rows = [
                ("2026-07-29T07:57:00+08:00", "precision", "Beijing",
                 "weatherol_beijing", "ok", None, None, None, None,
                 "2026-07-28T23:57:10+00:00"),
                ("2026-07-29T08:00:00+08:00", "retry", "Beijing",
                 "weatherol_beijing", "fetch_failed", None, None, None, None,
                 "2026-07-29T00:00:10+00:00"),
                ("2026-07-29T08:12:00+08:00", "precision", "Beijing",
                 "weatherol_beijing", "fetch_failed", None, None, None, None,
                 "2026-07-29T00:12:10+00:00"),
                ("2026-07-29T08:15:00+08:00", "retry", "Beijing",
                 "weatherol_beijing", "ok", None, None, None, None,
                 "2026-07-29T00:15:10+00:00"),
            ]
            db.executemany("INSERT INTO forecast_delivery_windows VALUES (?,?,?,?,?,?,?,?,?,?)",
                           rows)
            db.commit()
        finally:
            db.close()
        gate = forecast_delivery_gate(
            research,
            started_at=datetime(2026, 7, 28, 23, 50, tzinfo=UTC),
            ended_at=datetime(2026, 7, 29, 0, 20, tzinfo=UTC),
        )
        self.assertEqual(gate["status"], "pass")
        self.assertEqual(gate["families"], 2)
        self.assertEqual(gate["recovered_failures"], 2)

    def test_forecast_delivery_both_failed_or_orphan_failure_blocks(self) -> None:
        research = self.root / "research.sqlite3"
        db = sqlite3.connect(research)
        try:
            db.execute("""CREATE TABLE forecast_delivery_windows (
              scheduled_at TEXT,schedule_kind TEXT,city TEXT,source TEXT,status TEXT,
              requested_at TEXT,received_at TEXT,source_reported_at TEXT,
              detail TEXT,completed_at TEXT)""")
            rows = [
                ("2026-07-29T07:57:00+08:00", "precision", "Beijing",
                 "weatherol_beijing", "fetch_failed", None, None, None, None,
                 "2026-07-28T23:57:10+00:00"),
                ("2026-07-29T08:00:00+08:00", "retry", "Beijing",
                 "weatherol_beijing", "fetch_failed", None, None, None, None,
                 "2026-07-29T00:00:10+00:00"),
                ("2026-07-29T08:15:00+08:00", "retry", "Chengdu",
                 "weatherol_chengdu", "fetch_failed", None, None, None, None,
                 "2026-07-29T00:15:10+00:00"),
            ]
            db.executemany("INSERT INTO forecast_delivery_windows VALUES (?,?,?,?,?,?,?,?,?,?)",
                           rows)
            db.commit()
        finally:
            db.close()
        gate = forecast_delivery_gate(
            research,
            started_at=datetime(2026, 7, 28, 23, 50, tzinfo=UTC),
            ended_at=datetime(2026, 7, 29, 0, 20, tzinfo=UTC),
        )
        self.assertEqual(gate["status"], "blocked")
        self.assertEqual(gate["unresolved_families"], 2)

    def test_paper_recovery_requires_explicit_pass_evidence(self) -> None:
        self.assertEqual(paper_recovery_gate({})["status"], "blocked")
        passed = paper_recovery_gate({
            "paper_recovery": {
                "status": "pass", "observed_at": "now",
                "detail": "ok", "evidence": {"tracking_high": True},
            }
        })
        self.assertEqual(passed["status"], "pass")

    def test_log_tail_ignores_history_and_finds_new_lock_after_rotation(self) -> None:
        log = self.root / "worker.err.log"
        log.write_text("old database is locked\n", encoding="utf-8")
        tail = RuntimeLogTail()
        tail.prime([log])
        self.assertEqual(tail.lock_messages([log]), [])
        with log.open("a", encoding="utf-8") as handle:
            handle.write("new database is locked\n")
        self.assertEqual(len(tail.lock_messages([log])), 1)
        log.write_text("after rotation database busy\n", encoding="utf-8")
        self.assertEqual(len(tail.lock_messages([log])), 1)

    def test_latest_quote_age_reads_current_projection(self) -> None:
        with patch("service_supervisor.REALTIME_DB", self.quote_db):
            age = latest_quote_age()
        self.assertIsNotNone(age)
        self.assertLess(float(age), 10)
