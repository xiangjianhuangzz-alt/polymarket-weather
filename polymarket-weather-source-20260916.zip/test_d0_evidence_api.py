from __future__ import annotations

import hashlib
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import dashboard_modern


class D0EvidenceApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "research.sqlite3"
        db = sqlite3.connect(self.path)
        db.executescript("""
          CREATE TABLE forecast_d0_registry (
            source TEXT NOT NULL, city TEXT NOT NULL, station TEXT NOT NULL,
            target_date TEXT NOT NULL, grid_version TEXT NOT NULL,
            status TEXT NOT NULL, forecast_high_c REAL, forecast_bucket INTEGER,
            source_reported_at TEXT, first_captured_at TEXT NOT NULL,
            capture_delay_seconds REAL, content_hash TEXT, reason TEXT,
            frozen_at TEXT, latest_checked_at TEXT NOT NULL,
            PRIMARY KEY (source, station, target_date, grid_version));
          CREATE TABLE forecast_versions (
            version_id TEXT PRIMARY KEY, source TEXT NOT NULL, city TEXT NOT NULL,
            station TEXT NOT NULL, target_date TEXT NOT NULL, forecast_high_c REAL,
            content_hash TEXT NOT NULL, first_seen_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL, source_display_time TEXT,
            is_change INTEGER NOT NULL DEFAULT 1);
          CREATE TABLE forecast_update_values (
            source TEXT NOT NULL, city TEXT NOT NULL, station TEXT NOT NULL,
            source_reported_at TEXT NOT NULL, captured_at TEXT NOT NULL,
            target_date TEXT NOT NULL, forecast_high_c REAL,
            PRIMARY KEY (source, station, source_reported_at, target_date));
          CREATE TABLE market_resolutions (
            market_id TEXT PRIMARY KEY, city TEXT NOT NULL, target_date TEXT,
            bucket_label TEXT, yes_resolved INTEGER, resolved_at TEXT NOT NULL,
            outcome_prices_json TEXT, resolution_source TEXT);
        """)
        db.executemany("INSERT INTO forecast_d0_registry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
            ("weatherol_beijing", "Beijing", "ZBAA", "2026-08-09", "g1",
             "valid_d0", 31.0, 31, "2026-08-09T00:10:00+08:00",
             "2026-08-09T00:40:00+08:00", 1800.0, "qx-hash", "frozen",
             "2026-08-09T00:40:00+08:00", "2026-08-09T08:00:00+08:00"),
            ("aviationweather_taf", "Beijing", "ZBAA", "2026-08-09", "g1",
             "valid_d0", 33.0, 33, "2026-08-09T05:00:00+08:00",
             "2026-08-09T05:08:00+08:00", 480.0, "taf-hash", "frozen",
             "2026-08-09T05:08:00+08:00", "2026-08-09T08:00:00+08:00"),
            ("weatherol_shanghai", "Shanghai", "ZSPD", "2026-08-10", "g1",
             "valid_d0", 40.0, 40, "2026-08-10T00:10:00+08:00",
             "2026-08-10T00:40:00+08:00", 1800.0, "future", "frozen",
             "2026-08-10T00:40:00+08:00", "2026-08-10T08:00:00+08:00"),
            ("weatherol_chengdu", "Chengdu", "ZUUU", "2026-08-09", "g1",
             "valid_d0", None, None, "2026-08-09T00:15:00+08:00",
             "2026-08-09T00:40:00+08:00", 1500.0, "missing", "empty high",
             None, "2026-08-09T08:00:00+08:00"),
        ])
        db.execute("""INSERT INTO forecast_versions VALUES
          ('v1','weatherol_beijing','Beijing','ZBAA','2026-08-09',31,'qx-hash',
           '2026-08-09T00:40:00+08:00','2026-08-09T00:45:00+08:00',
           '2026-08-09T00:10:00+08:00',1)""")
        db.execute("""INSERT INTO market_resolutions VALUES
          ('m1','Beijing','2026-08-09','32°C',1,'2026-08-10T12:00:00+08:00',
           '{}','official')""")
        db.commit()
        db.close()
        self.api = dashboard_modern.Api()
        self.db_patch = patch.object(dashboard_modern, "DB", self.path)
        self.db_patch.start()

    def tearDown(self) -> None:
        self.db_patch.stop()
        self.temp.cleanup()

    def _digest(self) -> str:
        return hashlib.sha256(self.path.read_bytes()).hexdigest()

    def test_panel_is_fixed_shape_and_strictly_target_date_bound(self) -> None:
        panel = self.api.d0_evidence_panel("2026-08-09")
        self.assertTrue(panel["ok"])
        self.assertEqual(panel["schema"], "d0_evidence.v1")
        self.assertEqual(panel["timezone"], "Asia/Shanghai")
        self.assertEqual([row["city"] for row in panel["cities"]], dashboard_modern.CITY_ORDER)
        for row in panel["cities"]:
            self.assertEqual([source["source_key"] for source in row["sources"]], ["qxzx", "taf"])
        shanghai = next(row for row in panel["cities"] if row["city"] == "Shanghai")
        self.assertTrue(all(source["temperature_c"] is None for source in shanghai["sources"]))
        self.assertTrue(all(source["status"] == "waiting" for source in shanghai["sources"]))

    def test_qc_ta_policy_is_waiting_with_null_windows_and_overdue_unreachable(self) -> None:
        panel = self.api.d0_evidence_panel("2099-12-31")
        statuses = []
        for city in panel["cities"]:
            qxzx, taf = city["sources"]
            self.assertEqual(qxzx["reason_code"], "qxzx_window_not_enabled_v1")
            self.assertEqual(taf["reason_code"], "taf_schedule_not_frozen")
            for source in (qxzx, taf):
                statuses.append(source["status"])
                self.assertIsNone(source["expected_window_start"])
                self.assertIsNone(source["expected_window_end"])
                self.assertIsNone(source["grace_deadline"])
                self.assertEqual(source["provenance"]["policy_version"], "d0-evidence-facts-v1")
        self.assertEqual(set(statuses), {"waiting"})
        self.assertNotIn("publication_overdue", statuses)

    def test_valid_null_maps_to_missing_and_comparison_never_fuses_sources(self) -> None:
        panel = self.api.d0_evidence_panel("2026-08-09")
        beijing = next(row for row in panel["cities"] if row["city"] == "Beijing")
        self.assertEqual(beijing["comparison"]["status"], "both_valid_delta")
        self.assertEqual(beijing["comparison"]["delta_c"], 2.0)
        self.assertEqual(beijing["comparison"]["valid_sources"], ["qxzx", "taf"])
        self.assertNotIn("temperature_c", beijing["comparison"])
        chengdu = next(row for row in panel["cities"] if row["city"] == "Chengdu")
        qxzx = chengdu["sources"][0]
        self.assertEqual(qxzx["status"], "missing_target_value")
        self.assertEqual(qxzx["provenance"]["registry_status"], "valid_d0")

    def test_detail_keeps_time_fields_distinct_and_filters_versions_by_date(self) -> None:
        detail = self.api.d0_evidence_detail("Beijing", "2026-08-09")
        qxzx = detail["sources"][0]
        self.assertEqual(qxzx["source_reported_at"], "2026-08-09T00:10:00+08:00")
        self.assertEqual(qxzx["first_captured_at"], "2026-08-09T00:40:00+08:00")
        self.assertEqual(qxzx["capture_delay_seconds"], 1800.0)
        self.assertRegex(detail["page_updated_at"], r"\+08:00$")
        self.assertEqual([item["version_id"] for item in detail["versions"]], ["v1"])
        self.assertEqual(detail["resolution"]["market_id"], "m1")
        self.assertEqual(detail["resolution"]["forecast_bucket_delta_c"], 1)

    def test_research_fails_closed_without_supported_point_in_time_artifact(self) -> None:
        detail = self.api.d0_evidence_detail("Beijing", "2026-08-09")
        self.assertIn(detail["research"]["availability"], {"not_yet_known", "partial", "unsupported_version"})
        self.assertIsNone(detail["research"]["model_output"])
        self.assertFalse(detail["research"]["snapshot"]["ready_for_probability"])
        self.assertNotIn("probability", detail["research"])

        db = sqlite3.connect(self.path)
        db.execute("CREATE TABLE wp3_factor_snapshots(schema_version TEXT)")
        db.commit()
        db.close()
        unsupported = self.api.d0_evidence_detail("Beijing", "2026-08-09")
        self.assertEqual(unsupported["research"]["availability"], "unsupported_version")
        self.assertIsNone(unsupported["research"]["model_output"])

    def test_all_comparison_states_are_deterministic(self) -> None:
        def source(key: str, status: str, temperature: float | None = None) -> dict:
            return {"source_key": key, "status": status, "temperature_c": temperature}

        cases = [
            ([source("qxzx", "valid_d0", 30), source("taf", "valid_d0", 30)], "both_valid_equal"),
            ([source("qxzx", "valid_d0", 30), source("taf", "valid_d0", 31)], "both_valid_delta"),
            ([source("qxzx", "valid_d0", 30), source("taf", "waiting")], "qxzx_only_valid"),
            ([source("qxzx", "waiting"), source("taf", "valid_d0", 31)], "taf_only_valid"),
            ([source("qxzx", "waiting"), source("taf", "waiting")], "both_waiting"),
            ([source("qxzx", "fetch_failed"), source("taf", "waiting")], "source_anomaly"),
            ([source("qxzx", "legacy_unverified"), source("taf", "not_retained")], "no_valid_evidence"),
        ]
        for sources, expected in cases:
            with self.subTest(expected=expected):
                self.assertEqual(self.api._d0_comparison(sources)["status"], expected)

    def test_complete_frozen_evidence_is_not_downgraded_by_newer_failure(self) -> None:
        db = sqlite3.connect(self.path)
        db.execute("""INSERT INTO forecast_d0_registry VALUES
          ('weatherol_beijing','Beijing','ZBAA','2026-08-09','g2','fetch_failed',
           NULL,NULL,NULL,'2026-08-09T08:30:00+08:00',NULL,NULL,'later failure',NULL,
           '2026-08-09T08:30:00+08:00')""")
        db.commit()
        db.close()
        panel = self.api.d0_evidence_panel("2026-08-09")
        qxzx = panel["cities"][0]["sources"][0]
        self.assertEqual(qxzx["status"], "valid_d0")
        self.assertEqual(qxzx["temperature_c"], 31.0)
        self.assertTrue(qxzx["provenance"]["immutable_frozen"])

    def _insert_registry(self, *, source: str = "weatherol_shanghai",
                         city: str = "Shanghai", station: str = "ZSPD",
                         grid: str, status: str, high: float | None = None,
                         frozen: str | None = None, checked: str) -> None:
        db = sqlite3.connect(self.path)
        db.execute("""INSERT INTO forecast_d0_registry VALUES
          (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
            source, city, station, "2026-08-09", grid, status, high,
            int(high) if high is not None else None, None,
            "2026-08-09T01:00:00+08:00", None, f"hash-{grid}",
            f"raw free text {status}", frozen, checked,
        ))
        db.commit()
        db.close()

    def test_registry_overdue_is_rejected_by_v1_in_panel_and_detail(self) -> None:
        self._insert_registry(grid="overdue", status="publication_overdue",
                              checked="2026-08-09T09:00:00+08:00")
        panel_source = self.api.d0_evidence_panel("2026-08-09")["cities"][1]["sources"][0]
        detail_source = self.api.d0_evidence_detail("Shanghai", "2026-08-09")["sources"][0]
        for item in (panel_source, detail_source):
            self.assertEqual(item["policy_status"], "waiting")
            self.assertEqual(item["evidence_status"], "policy_undetermined")
            self.assertNotEqual(item["status"], "publication_overdue")
            self.assertEqual(item["provenance"]["registry_status"], "publication_overdue")
            self.assertIn("publication_overdue_ignored_v1", item["limitations"])

    def test_policy_evidence_and_retention_layers_are_independent(self) -> None:
        no_fact = self.api.d0_evidence_detail("Shenzhen", "2026-08-09")
        for item, reason_code in zip(
            no_fact["sources"],
            ("qxzx_window_not_enabled_v1", "taf_schedule_not_frozen"),
        ):
            self.assertEqual(item["policy_status"], "waiting")
            self.assertEqual(item["evidence_status"], "policy_undetermined")
            self.assertEqual(item["retention_state"], "policy_undetermined")
            self.assertEqual(item["reason_code"], reason_code)
            self.assertIn("target_date_attribution_unavailable", item["limitations"])
            self.assertIn("cannot distinguish not_observed from not_retained", item["limitations"])
            self.assertNotEqual(item["policy_status"], "publication_overdue")

        self._insert_registry(grid="old-waiting", status="waiting",
                              checked="2026-08-09T04:00:00+08:00")
        old_waiting = self.api.d0_evidence_detail("Shanghai", "2026-08-09")["sources"][0]
        self.assertEqual(old_waiting["policy_status"], "waiting")
        self.assertEqual(old_waiting["evidence_status"], "policy_undetermined")
        self.assertEqual(old_waiting["provenance"]["registry_status"], "waiting")

        self._insert_registry(source="weatherol_guangzhou", city="Guangzhou", station="ZGGG",
                              grid="real-anomaly", status="source_clock_skew",
                              checked="2026-08-09T04:01:00+08:00")
        anomaly = self.api.d0_evidence_detail("Guangzhou", "2026-08-09")["sources"][0]
        self.assertEqual(anomaly["policy_status"], "source_clock_skew")
        self.assertEqual(anomaly["evidence_status"], "source_clock_skew")

        valid = self.api.d0_evidence_detail("Beijing", "2026-08-09")["sources"][0]
        self.assertEqual(valid["policy_status"], "valid_d0")
        self.assertEqual(valid["evidence_status"], "valid_d0")

    def test_source_status_uses_frozen_priority_not_latest_row(self) -> None:
        cases = [
            (("valid_d0", "delayed_carry"), "missing_target_value"),
            (("source_clock_skew", "fetch_failed"), "source_clock_skew"),
        ]
        for index, ((earlier, later), expected) in enumerate(cases):
            city, station = ("Shanghai", "ZSPD") if index == 0 else ("Guangzhou", "ZGGG")
            source = f"weatherol_{city.lower()}"
            self._insert_registry(source=source, city=city, station=station,
                                  grid=f"early-{index}", status=earlier,
                                  checked="2026-08-09T01:00:00+08:00")
            self._insert_registry(source=source, city=city, station=station,
                                  grid=f"late-{index}", status=later,
                                  checked="2026-08-09T02:00:00+08:00")
            item = self.api.d0_evidence_detail(city, "2026-08-09")["sources"][0]
            self.assertEqual(item["policy_status"], expected)
            self.assertNotEqual(item["reason_code"], f"raw free text {expected}")

    def test_each_adjacent_source_status_priority_is_stable(self) -> None:
        pairs = [
            ("source_clock_skew", "source_time_missing", "source_clock_skew"),
            ("source_time_missing", "valid_d0", "source_time_missing"),
            ("valid_d0", "delayed_carry", "missing_target_value"),
            ("delayed_carry", "midnight_not_after", "delayed_carry"),
            ("midnight_not_after", "fetch_failed", "midnight_not_after"),
        ]
        for index, (higher, lower, expected) in enumerate(pairs):
            with self.subTest(higher=higher, lower=lower):
                db = sqlite3.connect(self.path)
                db.execute("""DELETE FROM forecast_d0_registry
                  WHERE source='weatherol_shanghai' AND target_date='2026-08-09'""")
                db.commit()
                db.close()
                self._insert_registry(grid=f"priority-{index}-a", status=higher,
                                      checked="2026-08-09T01:00:00+08:00")
                self._insert_registry(grid=f"priority-{index}-b", status=lower,
                                      checked="2026-08-09T02:00:00+08:00")
                item = self.api.d0_evidence_detail("Shanghai", "2026-08-09")["sources"][0]
                self.assertEqual(item["policy_status"], expected)

    def test_source_dto_contains_all_frozen_top_level_fields(self) -> None:
        required = {
            "source", "source_role", "city", "station", "target_date",
            "policy_status", "status_label", "reason_code", "reason_text", "severity",
            "evidence_status", "fetch_health", "temperature_c", "forecast_bucket",
            "source_reported_at", "first_captured_at", "capture_delay_seconds",
            "frozen_at", "latest_checked_at", "expected_window_start",
            "expected_window_end", "grace_deadline", "evaluation_at",
            "last_attempt_at", "last_attempt_status", "last_success_at",
            "expected_attempt_seen", "policy_version", "provenance",
            "limitations", "retention_state",
        }
        for city in self.api.d0_evidence_panel("2026-08-09")["cities"]:
            for source in city["sources"]:
                self.assertFalse(required - source.keys())
                self.assertEqual(source["fetch_health"], "not_attributed")
                self.assertIsNone(source["last_attempt_at"])
                self.assertIsNone(source["last_success_at"])
                self.assertEqual(source["expected_attempt_seen"], "unknown")

    def test_retention_fails_closed_without_proof_of_observation_or_cleanup(self) -> None:
        detail = self.api.d0_evidence_detail("Shenzhen", "2026-08-09")
        for source in detail["sources"]:
            self.assertEqual(source["retention_state"], "policy_undetermined")
            self.assertIn("target_date_attribution_unavailable", source["limitations"])
        self.assertEqual(detail["availability"]["detail"], "policy_undetermined")

        self._insert_registry(source="weatherol_shenzhen", city="Shenzhen", station="ZGSZ",
                              grid="retained-summary", status="not_retained",
                              checked="2026-08-09T03:00:00+08:00")
        self._insert_registry(source="aviationweather_taf", city="Shenzhen", station="ZGSZ",
                              grid="observed-none", status="not_observed",
                              checked="2026-08-09T03:01:00+08:00")
        explicit = self.api.d0_evidence_detail("Shenzhen", "2026-08-09")
        self.assertEqual(explicit["sources"][0]["retention_state"], "not_retained")
        self.assertEqual(explicit["sources"][1]["retention_state"], "not_observed")
        self.assertEqual(explicit["availability"]["detail"], "policy_undetermined")

    def test_resolution_selects_unique_yes_and_fails_closed_otherwise(self) -> None:
        db = sqlite3.connect(self.path)
        db.executemany("INSERT INTO market_resolutions VALUES (?,?,?,?,?,?,?,?)", [
            ("no-new", "Beijing", "2026-08-09", "35°C", 0,
             "2026-08-11T14:00:00+08:00", "{}", "official"),
            ("no-old", "Beijing", "2026-08-09", "34°C", 0,
             "2026-08-10T13:00:00+08:00", "{}", "official"),
        ])
        db.commit()
        db.close()
        resolution = self.api.d0_evidence_detail("Beijing", "2026-08-09")["resolution"]
        self.assertEqual(resolution["market_id"], "m1")
        self.assertTrue(resolution["yes_resolved"])

        db = sqlite3.connect(self.path)
        db.execute("UPDATE market_resolutions SET yes_resolved=0 WHERE market_id='m1'")
        db.commit()
        db.close()
        no_yes = self.api.d0_evidence_detail("Beijing", "2026-08-09")["resolution"]
        self.assertEqual(no_yes["status"], "unavailable")
        self.assertEqual(no_yes["quality_code"], "no_yes_resolution")

        db = sqlite3.connect(self.path)
        db.executemany("INSERT INTO market_resolutions VALUES (?,?,?,?,?,?,?,?)", [
            ("yes-a", "Beijing", "2026-08-09", "30°C", 1,
             "2026-08-12T12:00:00+08:00", "{}", "official"),
            ("yes-b", "Beijing", "2026-08-09", "31°C", 1,
             "2026-08-12T12:01:00+08:00", "{}", "official"),
        ])
        db.commit()
        db.close()
        conflicting = self.api.d0_evidence_detail("Beijing", "2026-08-09")["resolution"]
        self.assertEqual(conflicting["status"], "unavailable")
        self.assertEqual(conflicting["quality_code"], "conflicting_yes_resolutions")

    def test_unparseable_yes_bucket_never_produces_delta(self) -> None:
        db = sqlite3.connect(self.path)
        db.execute("UPDATE market_resolutions SET bucket_label='unknown bucket' WHERE market_id='m1'")
        db.commit()
        db.close()
        resolution = self.api.d0_evidence_detail("Beijing", "2026-08-09")["resolution"]
        self.assertIsNone(resolution["forecast_bucket_delta_c"])
        self.assertIn("unparseable_bucket_label", resolution["limitations"])

    def test_connection_closes_when_dto_construction_raises(self) -> None:
        real_connect = sqlite3.connect
        tracked = []

        class ConnectionProxy:
            def __init__(self, connection, uri):
                object.__setattr__(self, "connection", connection)
                object.__setattr__(self, "closed", False)
                object.__setattr__(self, "uri", uri)

            def __getattr__(self, name):
                return getattr(self.connection, name)

            def __setattr__(self, name, value):
                if name in {"connection", "closed", "uri"}:
                    object.__setattr__(self, name, value)
                else:
                    setattr(self.connection, name, value)

            def close(self):
                object.__setattr__(self, "closed", True)
                return self.connection.close()

        def tracking_connect(*args, **kwargs):
            proxy = ConnectionProxy(real_connect(*args, **kwargs), args[0])
            tracked.append(proxy)
            return proxy

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(self.api, "_d0_panel_from_db", side_effect=ValueError("dto failed")):
            response = self.api.d0_evidence_panel("2026-08-09")
        self.assertFalse(response["ok"])
        self.assertTrue(tracked[0].closed)
        self.assertIn("mode=ro", tracked[0].uri)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(self.api, "_d0_versions", side_effect=ValueError("detail dto failed")):
            response = self.api.d0_evidence_detail("Beijing", "2026-08-09")
        self.assertFalse(response["ok"])
        self.assertTrue(tracked[1].closed)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(dashboard_modern, "_d0_has_table",
                          side_effect=sqlite3.OperationalError("database is locked")):
            response = self.api.d0_evidence_panel("2026-08-09")
        self.assertEqual(response["error"]["code"], "data_temporarily_unavailable")
        self.assertTrue(tracked[2].closed)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect), \
             patch.object(dashboard_modern, "_d0_has_table", return_value=False):
            response = self.api.d0_evidence_panel("2026-08-09")
        self.assertEqual(response["error"]["code"], "data_contract_unavailable")
        self.assertTrue(tracked[3].closed)

        with patch.object(dashboard_modern.sqlite3, "connect", side_effect=tracking_connect):
            response = self.api.d0_evidence_detail("Beijing", "2026-08-09")
        self.assertTrue(response["ok"])
        self.assertTrue(tracked[4].closed)

    def test_errors_use_stable_envelope(self) -> None:
        invalid = self.api.d0_evidence_panel("2026-02-30")
        self.assertFalse(invalid["ok"])
        self.assertEqual(invalid["error"]["code"], "invalid_target_date")
        self.assertEqual(invalid["error"]["field"], "target_date")
        unsupported = self.api.d0_evidence_detail("Hong Kong", "2026-08-09")
        self.assertFalse(unsupported["ok"])
        self.assertEqual(unsupported["error"]["code"], "unsupported_city")

    def test_database_is_opened_read_only_and_unchanged(self) -> None:
        before = self._digest()
        panel = self.api.d0_evidence_panel("2026-08-09")
        detail = self.api.d0_evidence_detail("Beijing", "2026-08-09")
        self.assertTrue(panel["provenance"]["read_only"])
        self.assertTrue(detail["provenance"]["read_only"])
        self.assertEqual(before, self._digest())


if __name__ == "__main__":
    unittest.main()
