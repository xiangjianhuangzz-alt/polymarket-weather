from __future__ import annotations

import sqlite3
import tempfile
import unittest
import math
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

from metar_collector import STATIONS, connect, fetch_reports, normalise, run_cycle


EXPECTED_STATIONS = {
    "ZBAA": {"city": "Beijing", "scope": "risk_exclusion"},
    "ZSPD": {"city": "Shanghai", "scope": "risk_exclusion"},
    "ZUUU": {"city": "Chengdu", "scope": "risk_exclusion"},
    "ZGGG": {"city": "Guangzhou", "scope": "risk_exclusion"},
    "ZGSZ": {"city": "Shenzhen", "scope": "research_only"},
    "ZHHH": {"city": "Wuhan", "scope": "research_only"},
    "ZUCK": {"city": "Chongqing", "scope": "research_only"},
}
FORMAL_STATIONS = {"ZBAA", "ZSPD", "ZUUU", "ZGGG"}
RESEARCH_STATIONS = set(EXPECTED_STATIONS) - FORMAL_STATIONS
NEW_RESEARCH_STATIONS = {"ZHHH", "ZUCK"}


def row(station: str, stamp: str, temp: int, raw_suffix: str = "") -> dict:
    return {"icaoId": station, "reportTime": stamp, "temp": temp,
            "rawOb": f"METAR {station} 260330Z 18002MPS 8000 NSC {temp:02d}/20 Q1008{raw_suffix}"}


class MetarCollectorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.folder = tempfile.TemporaryDirectory()
        self.database = Path(self.folder.name) / "observations.sqlite3"
        self.now = datetime(2026, 7, 26, 4, 0, tzinfo=UTC)
        self.payload = [row(station, "2026-07-26T03:30:00.000Z", 20 + index)
                        for index, station in enumerate(STATIONS)]

    def tearDown(self) -> None:
        self.folder.cleanup()

    def test_station_registry_is_exact_and_roles_are_preserved(self) -> None:
        self.assertEqual(STATIONS, EXPECTED_STATIONS)
        self.assertEqual(
            {station for station, meta in STATIONS.items()
             if meta["scope"] == "risk_exclusion"},
            FORMAL_STATIONS,
        )
        self.assertEqual(
            {station for station, meta in STATIONS.items()
             if meta["scope"] == "research_only"},
            RESEARCH_STATIONS,
        )

    def test_fetch_reports_queries_all_active_station_ids_once(self) -> None:
        response = MagicMock()
        response.read.return_value = b"[]"
        response.__enter__.return_value = response
        with patch("metar_collector.urllib.request.urlopen", return_value=response) as open_url:
            self.assertEqual(fetch_reports(), [])
        query = open_url.call_args.args[0].full_url
        self.assertIn("ids=ZBAA%2CZSPD%2CZUUU%2CZGGG%2CZGSZ%2CZHHH%2CZUCK", query)
        self.assertNotIn("ZHCC", query)
        self.assertNotIn("ZSJN", query)
        self.assertNotIn("ZSQD", query)

    def test_new_stations_normalise_from_registry_and_speci_is_preserved(self) -> None:
        for index, station in enumerate(sorted(NEW_RESEARCH_STATIONS)):
            with self.subTest(station=station):
                metar = normalise(row(station, "2026-07-26T03:30:00.000Z", 20 + index), self.now.isoformat())
                speci_source = row(station, "2026-07-26T03:31:00.000Z", 20 + index)
                speci_source["rawOb"] = speci_source["rawOb"].replace("METAR", "SPECI", 1)
                speci = normalise(speci_source, self.now.isoformat())
                self.assertEqual(metar["city"], EXPECTED_STATIONS[station]["city"])
                self.assertEqual(metar["decision_scope"], "research_only")
                self.assertEqual(metar["report_type"], "METAR")
                self.assertEqual(speci["report_type"], "SPECI")

    def test_unknown_or_missing_icao_fails_closed(self) -> None:
        valid = row("ZHHH", "2026-07-26T03:30:00.000Z", 24)
        self.assertIsNone(normalise({**valid, "icaoId": "XXXX"}, self.now.isoformat()))
        self.assertIsNone(normalise({key: value for key, value in valid.items() if key != "icaoId"}, self.now.isoformat()))
        self.assertIsNone(normalise({**valid, "icaoId": ""}, self.now.isoformat()))

    def test_identity_time_and_temperature_are_strictly_validated(self) -> None:
        valid = row("ZHHH", "2026-07-26T03:30:00.000Z", 24)
        invalid = (
            {**valid, "rawOb": valid["rawOb"].replace("ZHHH", "ZBAA")},
            {**valid, "rawOb": valid["rawOb"].replace("METAR", "UNKNOWN", 1)},
            {**valid, "reportTime": "2026-07-26T03:30:00"},
            {**valid, "reportTime": "2500-07-26T03:30:00Z"},
            {**valid, "reportTime": "2026-07-26T04:10:00Z"},
            {**valid, "temp": True},
            {**valid, "temp": "24"},
            {**valid, "temp": math.nan},
            {**valid, "temp": math.inf},
            {**valid, "temp": 71},
        )
        for payload in invalid:
            with self.subTest(payload=payload):
                self.assertIsNone(normalise(payload, self.now.isoformat()))
        self.assertIsNone(normalise(valid, "2026-07-26T04:00:00"))

    def test_invalid_station_is_isolated_and_missing_temperature_is_not_healthy(self) -> None:
        payload = list(self.payload)
        payload[0] = {**payload[0], "temp": "20"}
        payload[1] = {**payload[1], "temp": None}
        result = run_cycle(lambda: payload, self.database, now=self.now)
        self.assertEqual(result["reports"], 6)
        db = sqlite3.connect(self.database)
        try:
            states = dict(db.execute("SELECT station,state FROM metar_live_status"))
            details = dict(db.execute("SELECT station,detail FROM metar_live_status"))
            self.assertEqual(states["ZBAA"], "unavailable")
            self.assertEqual(details["ZBAA"], "provider_missing_station")
            self.assertEqual(states["ZSPD"], "unavailable")
            self.assertEqual(details["ZSPD"], "temperature_unavailable")
            self.assertEqual(
                {station for station, state in states.items() if state == "healthy"},
                set(STATIONS) - {"ZBAA", "ZSPD"},
            )
        finally:
            db.close()

    def test_deduplicates_polls_but_preserves_corrected_report(self) -> None:
        first = run_cycle(lambda: self.payload, self.database, now=self.now)
        second = run_cycle(lambda: self.payload, self.database, now=self.now + timedelta(minutes=1))
        corrected = list(self.payload)
        corrected[0] = row("ZBAA", "2026-07-26T03:30:00.000Z", 26, " RMK COR")
        third = run_cycle(lambda: corrected, self.database, now=self.now + timedelta(minutes=2))
        self.assertEqual((first["new"], second["new"], third["new"]), (7, 0, 1))
        db = sqlite3.connect(self.database)
        try:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM metar_observations").fetchone()[0], 8)
            self.assertEqual(db.execute("SELECT decision_scope FROM metar_observations WHERE station='ZGSZ' LIMIT 1").fetchone()[0],
                             "research_only")
        finally:
            db.close()

    def test_outage_never_relabels_old_temperature_as_healthy(self) -> None:
        run_cycle(lambda: self.payload, self.database, now=self.now)
        failed = run_cycle(lambda: (_ for _ in ()).throw(OSError("offline")), self.database,
                           now=self.now + timedelta(minutes=1))
        self.assertFalse(failed["ok"])
        db = sqlite3.connect(self.database)
        try:
            states = dict(db.execute("SELECT station,state FROM metar_live_status"))
            self.assertEqual(set(states), set(STATIONS))
            self.assertEqual(set(states.values()), {"unavailable"})
            self.assertEqual(db.execute("SELECT COUNT(*) FROM metar_observations").fetchone()[0], 7)
        finally:
            db.close()

    def test_old_report_is_delayed_not_transport_failure(self) -> None:
        old = [row(station, "2026-07-26T00:00:00.000Z", 25) for station in STATIONS]
        result = run_cycle(lambda: old, self.database, now=self.now)
        self.assertTrue(result["ok"])
        db = sqlite3.connect(self.database)
        try:
            states = {state for (state,) in db.execute("SELECT state FROM metar_live_status")}
            self.assertEqual(states, {"delayed"})
        finally:
            db.close()

    def test_each_new_station_writes_metar_and_speci_to_temporary_database(self) -> None:
        payload = []
        for index, station in enumerate(sorted(NEW_RESEARCH_STATIONS)):
            payload.append(row(station, "2026-07-26T03:30:00.000Z", 20 + index))
            speci = row(station, "2026-07-26T03:31:00.000Z", 20 + index)
            speci["rawOb"] = speci["rawOb"].replace("METAR", "SPECI", 1)
            payload.append(speci)
        result = run_cycle(lambda: payload, self.database, now=self.now)
        self.assertEqual(result["new"], len(payload))
        db = sqlite3.connect(self.database)
        try:
            rows = db.execute("SELECT station,city,decision_scope,report_type FROM metar_observations ORDER BY station,report_type").fetchall()
            self.assertEqual(len(rows), 4)
            for station, city, scope, report_type in rows:
                self.assertIn(station, NEW_RESEARCH_STATIONS)
                self.assertEqual(city, EXPECTED_STATIONS[station]["city"])
                self.assertEqual(scope, "research_only")
                self.assertIn(report_type, {"METAR", "SPECI"})
        finally:
            db.close()

    def test_missing_zhhh_is_isolated_from_other_active_stations(self) -> None:
        payload = [item for item in self.payload if item["icaoId"] != "ZHHH"]
        result = run_cycle(lambda: payload, self.database, now=self.now)
        self.assertEqual((result["new"], result["reports"]), (6, 6))
        db = sqlite3.connect(self.database)
        try:
            rows = dict(db.execute("SELECT station,state FROM metar_live_status"))
            details = dict(db.execute("SELECT station,detail FROM metar_live_status"))
            self.assertEqual(rows["ZHHH"], "unavailable")
            self.assertEqual(details["ZHHH"], "provider_missing_station")
            self.assertEqual({station for station, state in rows.items() if state == "healthy"}, set(STATIONS) - {"ZHHH"})
            self.assertEqual(db.execute("SELECT COUNT(*) FROM metar_observations").fetchone()[0], 6)
        finally:
            db.close()

    def test_one_stale_station_does_not_mark_other_stations_stale(self) -> None:
        payload = list(self.payload)
        payload = [
            row(item["icaoId"], "2026-07-26T00:00:00.000Z", item["temp"])
            if item["icaoId"] == "ZHHH" else item
            for item in payload
        ]
        run_cycle(lambda: payload, self.database, now=self.now)
        db = sqlite3.connect(self.database)
        try:
            states = dict(db.execute("SELECT station,state FROM metar_live_status"))
            self.assertEqual(states["ZHHH"], "delayed")
            self.assertEqual({station for station, state in states.items() if state == "healthy"}, set(STATIONS) - {"ZHHH"})
        finally:
            db.close()

    def test_no_foreign_database_is_opened_or_written(self) -> None:
        run_cycle(lambda: self.payload, self.database, now=self.now)
        db = connect(self.database)
        try:
            tables = {name for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            db.close()
        self.assertTrue({"metar_observations", "metar_live_status", "service_heartbeats"}.issubset(tables))


if __name__ == "__main__":
    unittest.main()
