# Polymarket天气研究系统

> 2026-09-16 源码保存与暂停交接：见 [PROJECT_PAUSE_20260916.md](PROJECT_PAUSE_20260916.md)。下方保留既有阶段记录；源码保存不表示当前候选已经验收或部署。

当前状态日期：2026-09-02（Asia/Shanghai）

## 当前状态

- 活动运行域仅为Collector、Realtime、METAR和Runtime Observer。
- V3及其AS-OF、Shadow、Paper、Dashboard连接、Guardian和计划任务已经退役，不得恢复。
- 郑州、济南和青岛已经退出未来活动路径；历史记录保持可读。
- 2026-08-31实现前现场审计发现未纳入当前管理域的`dashboard_live.py`父子进程；该漂移只登记，不代表Dashboard恢复或获得运行资格，未经独立授权不得启停或处置。
- 真实交易、订单、资金和资格保持关闭。
- 运行进程不能完整自证模块SHA时，继续标记`RUNNING_RELEASE_UNVERIFIED`。
- 新动态策略V8、V8.1、R2、V8.2和V8.2-R1均保留为历史设计证据，不得实现。V8.2-R1候选身份PASS，但独立终审最终`FAIL`，确认15项实施阻断。2026-09-02 Architecture Kernel首次独立审查已完成：候选身份PASS、架构内容FAIL；按既定硬止损路线，下一步只能在用户独立授权后进行一次受限Kernel修订，不得进入完整替代设计、实现、Git集成或部署。

## 当前入口

- 执行方法：[`PROJECT_EXECUTION_PROTOCOL.md`](PROJECT_EXECUTION_PROTOCOL.md)
- 业务契约：[`TASK_CONTRACT.md`](TASK_CONTRACT.md)
- 当前问题：[`CURRENT_ISSUES.md`](CURRENT_ISSUES.md)
- 项目导航：[`项目索引.md`](项目索引.md)
- 当前架构：[`系统架构.md`](系统架构.md)
- 新动态策略冻结输入：[`T00_新动态策略设计输入基线_2026-08-31.md`](T00_新动态策略设计输入基线_2026-08-31.md)
- V8完整设计：[`T00_新动态策略端到端研究架构完整设计_v8_2026-08-31.md`](T00_新动态策略端到端研究架构完整设计_v8_2026-08-31.md)
- V8登记附录：[`T00_新动态策略端到端研究架构登记附录_v8_2026-08-31.md`](T00_新动态策略端到端研究架构登记附录_v8_2026-08-31.md)
- V8冻结Manifest：[`T00_新动态策略端到端研究架构设计Manifest_v8_2026-08-31.md`](T00_新动态策略端到端研究架构设计Manifest_v8_2026-08-31.md)
- V8独立终审：[`T00_新动态策略端到端研究架构独立终审_v8_2026-08-31.md`](T00_新动态策略端到端研究架构独立终审_v8_2026-08-31.md)
- R2第二次独立终审：[`T01_新动态策略端到端研究架构第二次独立终审_v8.1_r2_2026-09-01.md`](T01_新动态策略端到端研究架构第二次独立终审_v8.1_r2_2026-09-01.md)
- V8.2路线决策：[`T00_V8.1_R2第二次FAIL后续决策审查_2026-09-01.md`](T00_V8.1_R2第二次FAIL后续决策审查_2026-09-01.md)
- V8.2冻结Manifest：[`T00_新动态策略端到端研究架构设计Manifest_v8.2_2026-09-01.md`](T00_新动态策略端到端研究架构设计Manifest_v8.2_2026-09-01.md)
- V8.2独立终审：[`T01_新动态策略端到端研究架构独立终审_v8.2_2026-09-01.md`](T01_新动态策略端到端研究架构独立终审_v8.2_2026-09-01.md)
- V8.2-R1路线决策：[`T00_V8.2独立终审FAIL后续决策审查_2026-09-01.md`](T00_V8.2独立终审FAIL后续决策审查_2026-09-01.md)
- V8.2-R1任务合同：[`T00_V8.2_R1受限整版替代设计任务合同_2026-09-01.md`](T00_V8.2_R1受限整版替代设计任务合同_2026-09-01.md)
- V8.2-R1 Canonical Contract：[`T00_新动态策略CanonicalContract_v8.2_r1_2026-09-01.md`](T00_新动态策略CanonicalContract_v8.2_r1_2026-09-01.md)
- V8.2-R1完整设计：[`T00_新动态策略端到端研究架构完整设计_v8.2_r1_2026-09-01.md`](T00_新动态策略端到端研究架构完整设计_v8.2_r1_2026-09-01.md)
- V8.2-R1最终登记：[`T00_新动态策略端到端研究架构最终登记_v8.2_r1_2026-09-01.md`](T00_新动态策略端到端研究架构最终登记_v8.2_r1_2026-09-01.md)
- V8.2-R1作者自检：[`T00_新动态策略端到端研究架构设计自检_v8.2_r1_2026-09-01.md`](T00_新动态策略端到端研究架构设计自检_v8.2_r1_2026-09-01.md)
- V8.2-R1 Manifest：[`T00_新动态策略端到端研究架构设计Manifest_v8.2_r1_2026-09-01.md`](T00_新动态策略端到端研究架构设计Manifest_v8.2_r1_2026-09-01.md)
- V8.2-R1独立终审：[`T01_新动态策略端到端研究架构独立终审_v8.2_r1_2026-09-01.md`](T01_新动态策略端到端研究架构独立终审_v8.2_r1_2026-09-01.md)
- R1 FAIL后路线决策：[`T00_V8.2_R1独立终审FAIL后续路线决策审查_2026-09-02.md`](T00_V8.2_R1独立终审FAIL后续路线决策审查_2026-09-02.md)
- Architecture Kernel任务合同：[`T00_V8_ArchitectureKernel任务合同_2026-09-02.md`](T00_V8_ArchitectureKernel任务合同_2026-09-02.md)
- Architecture Kernel候选：[`T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md`](T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md)
- Architecture Kernel作者自检：[`T00_新动态策略ArchitectureKernel设计自检_2026-09-02.md`](T00_新动态策略ArchitectureKernel设计自检_2026-09-02.md)
- Architecture Kernel Manifest：[`T00_新动态策略ArchitectureKernel设计Manifest_2026-09-02.md`](T00_新动态策略ArchitectureKernel设计Manifest_2026-09-02.md)
- Architecture Kernel首次独立审查：[`T01_新动态策略ArchitectureKernel独立审查_2026-09-02.md`](T01_新动态策略ArchitectureKernel独立审查_2026-09-02.md)

## 安全边界

- 任何市场最终结果只以Polymarket正式YES/NO结算为准。
- 不得把预报、METAR、第三方网页或旧研究结果冒充正式结算。
- 不得修改、回填、重算或改判历史数据库、Evidence、checkpoint、manifest或Seal。
- V8、V8.1、R2、V8.2、V8.2-R1及首次Architecture Kernel候选只保留历史设计和缺陷证据；Kernel首次独立审查已FAIL，不代表完整设计完成、Git集成或实现授权，不允许创建策略实现、测试实现、部署、Shadow、Paper或真实交易路径。
