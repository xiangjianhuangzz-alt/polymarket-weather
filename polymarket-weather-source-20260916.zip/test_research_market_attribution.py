from __future__ import annotations

import asyncio
import hashlib
import json
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch

import httpx

import collector


SCANNED_AT = "2026-08-09T15:00:00+00:00"
SCAN_ID = "scan-20260809-150000"


CITY_MATRIX = {
    "Beijing": ("ZBAA", "formal"),
    "Shanghai": ("ZSPD", "formal"),
    "Chengdu": ("ZUUU", "formal"),
    "Guangzhou": ("ZGGG", "formal"),
    "Shenzhen": ("ZGSZ", "research_only"),
    "Wuhan": ("ZHHH", "research_only"),
    "Chongqing": ("ZUCK", "research_only"),
}


def source(city: str, station: str, *, scheme: str = "https", host: str = "www.wunderground.com") -> str:
    return f"{scheme}://{host}/weather/cn/{city.lower()}/{station}"


def noaa_source(station: str) -> str:
    return f"https://www.weather.gov/wrh/timeseries?site={station.lower()}"


def event(
    city: str = "Wuhan",
    station: str = "ZHHH",
    *,
    day: str = "August 9",
    query_city: str | None = None,
    query_target_date: str = "2026-08-09",
) -> dict:
    return {
        "id": f"event-{city.lower()}",
        "title": f"Highest temperature in {city} on {day}",
        "resolutionSource": source(city, station),
        "active": True,
        "closed": False,
        "_query_city": query_city or city,
        "_query_target_date": query_target_date,
    }


def market(
    city: str = "Wuhan",
    station: str = "ZHHH",
    *,
    market_id: str = "market-wuhan-30",
    day: str = "August 9",
    resolution_source: str | None = "default",
    outcomes: list[str] | None = None,
    tokens: list[str] | None = None,
) -> dict:
    if resolution_source == "default":
        resolution_source = source(city, station)
    return {
        "id": market_id,
        "question": f"Will the highest temperature in {city} be 30 C on {day}?",
        "resolutionSource": resolution_source,
        "endDate": "2026-08-09T12:00:00Z",
        "outcomes": json.dumps(outcomes if outcomes is not None else ["Yes", "No"]),
        "clobTokenIds": json.dumps(tokens if tokens is not None else ["1001", "1002"]),
        "groupItemTitle": "30 C",
        "active": True,
        "closed": False,
        "acceptingOrders": True,
        "umaResolutionStatus": "unresolved",
        "liquidityNum": 1,
        "volumeNum": 1,
    }


def _test_authorized_publication(records, _statuses, **_kwargs):
    """Isolate existing attribution tests from the separately tested approval gate."""
    return {
        "candidate": collector.build_research_universe_candidate(records),
        "already_published": False,
    }


class _DetailClient:
    def __init__(self, detail: dict) -> None:
        self.detail = detail

    async def get(self, url: str, *_args, **_kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith(f"/events/{self.detail['id']}"):
            return _Response(self.detail)
        raise AssertionError(url)


class _SearchPayloadClient:
    def __init__(self, payload: object) -> None:
        self.payload = payload

    async def get(self, url: str, *_args, **_kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith("/public-search"):
            return _Response(self.payload)
        raise AssertionError(url)


class _SlugFallbackClient:
    def __init__(self, exact_event: dict) -> None:
        self.exact_event = exact_event
        self.urls: list[str] = []

    async def get(self, url: str, *_args, **_kwargs):
        self.urls.append(url)
        if url.endswith("/public-search"):
            return _Response({"events": []})
        expected_slug = "highest-temperature-in-wuhan-on-august-9-2026"
        if url.endswith(f"/events/slug/{expected_slug}"):
            return _Response(self.exact_event)
        return _Response({}, status_code=404)


class _ResolutionPayloadClient:
    def __init__(self, payloads: dict[str, dict]) -> None:
        self.payloads = payloads

    async def get(self, url: str, *_args, **kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith("/markets"):
            params = list(kwargs.get("params") or [])
            requested = [str(value) for key, value in params if key == "id"]
            closed_filter = next((str(value) for key, value in params if key == "closed"), None)
            values = []
            for market_id in requested:
                payload = self.payloads[market_id]
                closed = payload.get("closed")
                if closed_filter == "true" and closed is False:
                    continue
                if closed_filter == "false" and closed is not False:
                    continue
                values.append(payload)
            return _Response(values)
        return _Response(self.payloads[url.rsplit("/", 1)[-1]])


class _TwoCityMatrixClient:
    async def get(self, url: str, *_args, **kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith("/public-search"):
            query = str(kwargs.get("params", {}).get("q", "")).lower()
            if "in beijing " in query and "august 9" in query:
                summary = event("Beijing", "ZBAA", query_target_date="2026-08-09")
                return _Response({"events": [summary]})
            return _Response({"events": []})
        if url.endswith("/events/event-beijing"):
            detail = event("Beijing", "ZBAA", query_target_date="2026-08-09")
            detail["markets"] = [market(
                "Beijing", "ZBAA", market_id="beijing-market",
                tokens=["7001", "7002"],
            )]
            return _Response(detail)
        raise AssertionError(url)


class _SearchFailureByCityClient:
    async def get(self, url: str, *_args, **kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if not url.endswith("/public-search"):
            raise AssertionError(url)
        query = str(kwargs.get("params", {}).get("q", "")).lower()
        if "in wuhan " in query:
            raise httpx.ConnectError("wuhan search offline")
        return _Response({"events": []})


class _HangingSearchClient:
    async def get(self, url: str, *_args, **_kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if not url.endswith("/public-search"):
            raise AssertionError(url)
        await asyncio.sleep(0.1)
        return _Response({"events": []})


class _MisroutedCityClient:
    async def get(self, url: str, *_args, **kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith("/public-search"):
            query = str(kwargs.get("params", {}).get("q", "")).lower()
            if "august 9" in query:
                return _Response({"events": [event("Beijing", "ZBAA")]})
            return _Response({"events": []})
        if url.endswith("/events/event-beijing"):
            detail = event("Beijing", "ZBAA")
            detail["markets"] = [market(
                "Beijing", "ZBAA", market_id="misrouted-beijing",
                tokens=["8001", "8002"],
            )]
            return _Response(detail)
        raise AssertionError(url)


class _EventOnlyMatrixClient:
    def __init__(self, invalid_case: str) -> None:
        self.invalid_case = invalid_case

    async def get(self, url: str, *_args, **kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith("/public-search"):
            query = str(kwargs.get("params", {}).get("q", "")).lower()
            if "august 9" not in query:
                return _Response({"events": []})
            if "in beijing " in query:
                return _Response({"events": [event("Beijing", "ZBAA")]})
            if "in wuhan " in query:
                return _Response({"events": [event("Wuhan", "ZHHH")]})
            return _Response({"events": []})
        if url.endswith("/events/event-beijing"):
            detail = event("Beijing", "ZBAA")
            detail["markets"] = [market(
                "Beijing", "ZBAA", market_id="beijing-valid",
                tokens=["7001", "7002"],
            )]
            return _Response(detail)
        if url.endswith("/events/event-wuhan"):
            detail = event("Wuhan", "ZHHH")
            if self.invalid_case in {"source_host", "inactive_markets", "closed_markets"}:
                detail["resolutionSource"] = source(
                    "Wuhan", "ZHHH", host="attacker.invalid"
                )
            elif self.invalid_case == "station":
                detail["resolutionSource"] = source("Wuhan", "ZBAA")
            elif self.invalid_case == "query_city":
                detail["title"] = "Highest temperature in Beijing on August 9"
                detail["resolutionSource"] = source("Beijing", "ZBAA")
            elif self.invalid_case == "query_date":
                detail["title"] = "Highest temperature in Wuhan on August 10"
            elif self.invalid_case == "title":
                detail["title"] = "Will it rain in Wuhan on August 9?"
            if self.invalid_case == "inactive_markets":
                detail["markets"] = [{**market(), "active": False, "closed": False}]
            elif self.invalid_case == "closed_markets":
                detail["markets"] = [{**market(), "active": False, "closed": True}]
            else:
                detail["markets"] = []
            return _Response(detail)
        raise AssertionError(url)


class _SearchMisrouteNoDetailClient:
    def __init__(self) -> None:
        self.detail_requested = False

    async def get(self, url: str, *_args, **kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith("/public-search"):
            query = str(kwargs.get("params", {}).get("q", "")).lower()
            if "august 9" in query:
                return _Response({"events": [event("Beijing", "ZBAA")]})
            return _Response({"events": []})
        self.detail_requested = True
        raise AssertionError(url)


def _search_phrase(city: str, target: date) -> str:
    return f"highest temperature in {city} on {target.strftime('%B')} {target.day}".lower()


class _GammaSearchFixtureClient:
    def __init__(self, search_events: dict[str, list[dict]], details: dict[str, dict]) -> None:
        self.search_events = {query.lower(): events for query, events in search_events.items()}
        self.details = details
        self.detail_requests: list[str] = []

    async def get(self, url: str, *_args, **kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith("/public-search"):
            query = str(kwargs.get("params", {}).get("q", "")).lower()
            return _Response({"events": self.search_events.get(query, [])})
        event_id = url.rsplit("/", 1)[-1]
        self.detail_requests.append(event_id)
        if event_id not in self.details:
            raise AssertionError(url)
        return _Response(self.details[event_id])


class _ThirtyPointFuzzyClient(_GammaSearchFixtureClient):
    def __init__(self) -> None:
        search_events: dict[str, list[dict]] = {}
        details: dict[str, dict] = {}
        exact_cities = set(list(CITY_MATRIX)[:6])
        token_seed = 10000
        for city, (station, _scope) in CITY_MATRIX.items():
            city_events: list[dict] = []
            if city in exact_cities:
                for day in (9, 10, 11):
                    event_id = f"event-{city.lower()}-202608{day:02d}"
                    summary = event(
                        city, station, day=f"August {day}",
                        query_target_date=f"2026-08-{day:02d}",
                    )
                    summary["id"] = event_id
                    city_events.append(summary)
                    detail = dict(summary)
                    detail["markets"] = [market(
                        city, station,
                        market_id=f"market-{city.lower()}-202608{day:02d}",
                        day=f"August {day}",
                        tokens=[str(token_seed), str(token_seed + 1)],
                    )]
                    details[event_id] = detail
                    token_seed += 2
            else:
                fuzzy = event(
                    city, station, day="August 8",
                    query_target_date="2026-08-08",
                )
                fuzzy["id"] = f"event-{city.lower()}-20260808"
                city_events.append(fuzzy)
            for day in (9, 10, 11):
                search_events[_search_phrase(city, date(2026, 8, day))] = city_events
        super().__init__(search_events, details)


class _MultipleDetailFailureClient:
    async def get(self, url: str, *_args, **kwargs):
        if "/events/slug/" in url:
            return _Response({}, status_code=404)
        if url.endswith("/public-search"):
            query = str(kwargs.get("params", {}).get("q", "")).lower()
            if "august 9" not in query:
                return _Response({"events": []})
            if "in beijing " in query:
                return _Response({"events": [event("Beijing", "ZBAA")]})
            if "in wuhan " in query:
                return _Response({"events": [event("Wuhan", "ZHHH")]})
            return _Response({"events": []})
        if url.endswith("/events/event-beijing"):
            return _Response(event("Beijing", "ZBAA"))
        if url.endswith("/events/event-wuhan"):
            return _Response({**event("Wuhan", "ZHHH"), "markets": None})
        raise AssertionError(url)


class _Response:
    def __init__(self, payload: object, status_code: int = 200) -> None:
        self.payload = payload
        self.status_code = status_code

    def raise_for_status(self) -> None:
        return None

    def json(self) -> object:
        return self.payload


class ResearchMarketAttributionTests(unittest.TestCase):

    def accepted_member(self) -> dict:
        record = self.attribute(event(), market())
        return collector.build_research_universe_candidate([record])["members"][0]

    def test_prepare_publication_accepts_realtime_count_after_retired_city_filter(self) -> None:
        current = self.accepted_member()
        active = collector.AcceptedManifestMembers([
            {
                **current,
                "token_id": "1003",
                "market_id": "market-zhengzhou-30",
                "city": "Zhengzhou",
                "city_scope": "research_only",
                "station": "ZHCC",
                "event_id": "event-zhengzhou",
            },
            current,
        ], "v1")
        record = self.attribute(event(), market())

        with patch.object(
            collector,
            "load_realtime_accepted_universe_read_only",
            return_value={"token_hash": "a" * 64, "token_count": 1},
        ), patch.object(
            collector,
            "load_accepted_research_universe_members_read_only",
            return_value=active,
        ):
            publication = collector.prepare_research_universe_publication(
                [record], [],
            )

        self.assertEqual(publication["candidate"]["token_count"], 1)
        self.assertFalse(publication["suppress_universe_publication"])

    def test_prepare_publication_rejects_unexplained_realtime_count(self) -> None:
        active = collector.AcceptedManifestMembers([self.accepted_member()], "v1")

        with patch.object(
            collector,
            "load_realtime_accepted_universe_read_only",
            return_value={"token_hash": "a" * 64, "token_count": 2},
        ), patch.object(
            collector,
            "load_accepted_research_universe_members_read_only",
            return_value=active,
        ), self.assertRaisesRegex(
            collector.MarketScanIncomplete,
            "publication_current_count_mismatch",
        ):
            collector.prepare_research_universe_publication([], [])

    def test_prepare_publication_keeps_legacy_count_strict(self) -> None:
        legacy = collector.AcceptedManifestMembers([
            {
                "token_id": "1001", "market_id": "market-beijing",
                "city": "Beijing", "target_date": "2026-08-09",
            },
            {
                "token_id": "1003", "market_id": "market-legacy-city",
                "city": "Legacy City", "target_date": "2026-08-09",
            },
        ], "legacy")

        with patch.object(
            collector,
            "load_realtime_accepted_universe_read_only",
            return_value={"token_hash": "a" * 64, "token_count": 1},
        ), patch.object(
            collector,
            "load_accepted_research_universe_members_read_only",
            return_value=legacy,
        ), self.assertRaisesRegex(
            collector.MarketScanIncomplete,
            "publication_current_count_mismatch",
        ):
            collector.prepare_research_universe_publication([], [])

    def test_exact_noaa_station_source_is_verified_without_broad_host_allowlist(self) -> None:
        event_payload = event("Shanghai", "ZSPD", day="August 24", query_target_date="2026-08-24")
        event_payload["resolutionSource"] = noaa_source("ZSPD")
        market_payload = market(
            "Shanghai", "ZSPD", day="August 24", market_id="shanghai-noaa",
            tokens=["24001", "24002"], resolution_source=noaa_source("ZSPD"),
        )

        accepted = self.attribute(event_payload, market_payload)
        self.assertEqual(accepted["attribution_status"], "verified")
        self.assertEqual(accepted["resolution_source_host"], "www.weather.gov")

        for invalid in (
            "https://www.weather.gov.evil/wrh/timeseries?site=zspd",
            "https://www.weather.gov/wrh/timeseries?site=zbaa",
            "https://www.weather.gov/wrh/timeseries?site=zspd&extra=1",
            "http://www.weather.gov/wrh/timeseries?site=zspd",
        ):
            with self.subTest(invalid=invalid):
                rejected_event = dict(event_payload, resolutionSource=invalid)
                self.assertNotEqual(
                    self.attribute(rejected_event, market_payload)["attribution_status"],
                    "verified",
                )

    def test_exact_slug_recovers_event_omitted_by_public_search(self) -> None:
        exact = event("Wuhan", "ZHHH")
        query_results: list[dict] = []
        client = _SlugFallbackClient(exact)

        with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}):
            events = asyncio.run(collector.active_events(
                client,
                query_date=date(2026, 8, 9),
                query_results=query_results,
            ))

        self.assertEqual([item["id"] for item in events], [exact["id"]])
        self.assertTrue(any("/events/slug/" in url for url in client.urls))

    def attribute(self, event_payload: dict, market_payload: dict) -> dict:
        return collector.attribute_research_market(
            event_payload,
            market_payload,
            scan_id=SCAN_ID,
            scanned_at=SCANNED_AT,
        )

    def assert_rejected(self, event_payload: dict, market_payload: dict, reason: str) -> None:
        result = self.attribute(event_payload, market_payload)
        self.assertEqual(result["attribution_status"], "attribution_rejected")
        self.assertEqual(result["reason_code"], reason)
        for field in (
            "market_id", "market_question", "resolution_source", "resolution_source_host",
            "bucket_label", "outcome", "token_id",
        ):
            self.assertIsNone(result[field], field)

    @staticmethod
    def _seed_previous_manifest(db) -> None:
        previous = market("Beijing", "ZBAA", market_id="old-market", tokens=["9001", "9002"])
        collector.save_market(db, "2026-08-09T14:00:00+00:00", previous, "Beijing")
        collector.publish_market_universe(
            db, "2026-08-09T14:00:00+00:00",
            [{"token_id": "9001", "market_id": "old-market", "city": "Beijing",
              "target_date": "2026-08-09"}],
            "complete_scan",
        )
        db.commit()

    def _temporary_database(self, tmp: str):
        path = Path(tmp) / "research.sqlite3"
        with patch.object(collector, "DB_PATH", path), patch.object(collector, "prune_research_data"):
            db = collector.connect()
        self._seed_previous_manifest(db)
        return db

    def _detail_market_scan(self, tmp: str, raw_markets: list[object]):
        db = self._temporary_database(tmp)
        detail = event()
        detail["markets"] = raw_markets
        summary = {
            key: detail[key]
            for key in (
                "id", "title", "active", "closed", "_query_city", "_query_target_date"
            )
        }
        before = {
            "snapshots": db.execute(
                "SELECT * FROM market_snapshots ORDER BY captured_at,market_id"
            ).fetchall(),
            "rules": db.execute(
                "SELECT * FROM market_rules ORDER BY market_id"
            ).fetchall(),
            "publications": db.execute(
                "SELECT publication_id,published_at,token_hash,token_count,members_json,reason "
                "FROM market_universe_publications ORDER BY published_at"
            ).fetchall(),
        }
        statuses: list[dict] = []
        try:
            with patch.object(collector, "active_events", return_value=[summary]):
                found = asyncio.run(collector.collect_markets(
                    _DetailClient(detail), db, SCANNED_AT,
                    attribution_results=statuses,
                ))
            after = {
                "snapshots": db.execute(
                    "SELECT * FROM market_snapshots ORDER BY captured_at,market_id"
                ).fetchall(),
                "rules": db.execute(
                    "SELECT * FROM market_rules ORDER BY market_id"
                ).fetchall(),
                "publications": db.execute(
                    "SELECT publication_id,published_at,token_hash,token_count,members_json,reason "
                    "FROM market_universe_publications ORDER BY published_at"
                ).fetchall(),
            }
            active = db.execute(
                "SELECT active FROM market_snapshots WHERE market_id='old-market' "
                "ORDER BY captured_at DESC LIMIT 1"
            ).fetchone()
        finally:
            db.close()
        return found, before, after, active, statuses

    def assert_previous_manifest_unchanged(self, db) -> None:
        publications = db.execute(
            "SELECT token_count,reason FROM market_universe_publications ORDER BY published_at"
        ).fetchall()
        active = db.execute(
            "SELECT active FROM market_snapshots WHERE market_id='old-market' ORDER BY captured_at DESC LIMIT 1"
        ).fetchone()
        self.assertEqual(publications, [(1, "complete_scan")])
        self.assertEqual(active, (1,))

    def test_event_and_market_city_station_and_date_are_independently_verified(self) -> None:
        self.assert_rejected(event(), market("Beijing", "ZBAA"), "event_market_city_mismatch")
        self.assert_rejected(event(), market(resolution_source=None), "market_source_missing")
        self.assert_rejected(event(), market(station="ZBAA"), "market_station_mismatch")
        self.assert_rejected(event(), market(day="August 10"), "event_market_date_mismatch")

    def test_source_requires_https_exact_host_city_path_and_station(self) -> None:
        self.assert_rejected(event(), market(resolution_source=source("Wuhan", "ZHHH", scheme="http")),
                             "market_source_scheme")
        self.assert_rejected(event(), market(resolution_source=source("Wuhan", "ZHHH", host="attacker.invalid")),
                             "market_source_host")
        self.assert_rejected(event(), market(resolution_source=source("Wuhan", "ZHHH", host="www.wunderground.com.evil")),
                             "market_source_host")
        self.assert_rejected(event(), market(resolution_source=source("Beijing", "ZHHH")),
                             "market_source_city_path")
        disguised = "https://www.wunderground.com/weather/cn/beijing/ZBAA/wuhan/ZHHH"
        self.assert_rejected(event(), market(resolution_source=disguised), "market_source_path")

    def test_yes_token_quality_gate(self) -> None:
        cases = [
            (market(outcomes=["No", "No"]), "market_yes_missing"),
            (market(outcomes=["Yes", "YES"]), "market_yes_ambiguous"),
            (market(tokens=["1001"]), "market_outcome_token_count"),
            (market(tokens=["1001", "1001"]), "market_token_duplicate"),
            (market(tokens=["", "1002"]), "market_token_empty"),
            (market(tokens=["yes-token", "1002"]), "market_token_not_decimal"),
        ]
        for payload, reason in cases:
            with self.subTest(reason=reason):
                self.assert_rejected(event(), payload, reason)

    def test_tokens_must_be_original_ascii_strings(self) -> None:
        self.assert_rejected(event(), market(tokens=[1001, "1002"]), "market_token_type")
        self.assert_rejected(event(), market(tokens=["١٢٣", "1002"]), "market_token_not_decimal")

    def test_all_outcome_tokens_are_globally_unique(self) -> None:
        first = self.attribute(event(), market(market_id="m1", tokens=["1001", "1002"]))
        no_no = self.attribute(event(), market(market_id="m2", tokens=["1003", "1002"]))
        yes_no = self.attribute(event(), market(market_id="m3", tokens=["1002", "1004"]))
        for conflicting in (no_no, yes_no):
            with self.subTest(market_id=conflicting["market_id"]):
                with self.assertRaisesRegex(collector.MarketScanIncomplete, "outcome_token_conflict"):
                    collector.build_research_universe_candidate([first, conflicting])

    def test_candidate_revalidates_complete_outcome_token_binding(self) -> None:
        record = self.attribute(event(), market())
        self.assertEqual(
            record["_outcome_token_bindings"],
            (("Yes", "1001"), ("No", "1002")),
        )
        collector.build_research_universe_candidate([record])

        yes_changed_to_no = {**record, "token_id": "1002"}
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "candidate_yes_token_mismatch"):
            collector.build_research_universe_candidate([yes_changed_to_no])

        outcomes_reordered = {
            **record,
            "_outcome_token_bindings": (("No", "1001"), ("Yes", "1002")),
        }
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "candidate_yes_token_mismatch"):
            collector.build_research_universe_candidate([outcomes_reordered])

        multiple_yes = {
            **record,
            "_outcome_token_bindings": (("Yes", "1001"), ("YES", "1002")),
        }
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "candidate_yes_ambiguous"):
            collector.build_research_universe_candidate([multiple_yes])

        count_mismatch = {
            **record,
            "_outcome_token_bindings": (("Yes", "1001"), ("No",)),
        }
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "candidate_outcome_token_count"):
            collector.build_research_universe_candidate([count_mismatch])

        for bad_binding in (
            (("Yes", 1001), ("No", "1002")),
            ((1, "1001"), ("No", "1002")),
        ):
            with self.subTest(binding=bad_binding), self.assertRaisesRegex(
                collector.MarketScanIncomplete, "candidate_outcome_token_type"
            ):
                collector.build_research_universe_candidate([
                    {**record, "_outcome_token_bindings": bad_binding}
                ])

    def test_tampered_token_set_cannot_hide_conflict_from_complete_binding(self) -> None:
        first = self.attribute(event(), market(market_id="m1", tokens=["1001", "1002"]))
        conflicting = self.attribute(event(), market(market_id="m2", tokens=["1003", "1002"]))
        conflicting["_outcome_token_ids"] = ("1003", "1004")
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "outcome_token_conflict"):
            collector.build_research_universe_candidate([first, conflicting])

    def test_frozen_gamma_token_evidence_rejects_coordinated_derived_mutation(self) -> None:
        record = self.attribute(event(), market())
        self.assertIn("_gamma_token_evidence", record)
        collector.build_research_universe_candidate([record])

        coordinated = {
            **record,
            "token_id": "1002",
            "_outcome_token_bindings": (("No", "1001"), ("Yes", "1002")),
        }
        forged = {
            **record,
            "token_id": "9999",
            "_outcome_token_bindings": (("Yes", "9999"), ("No", "1002")),
        }
        for name, mutated in (("yes_no_swap", coordinated), ("forged_token", forged)):
            with self.subTest(name=name), self.assertRaisesRegex(
                collector.MarketScanIncomplete, "candidate_token_evidence_mismatch"
            ):
                collector.build_research_universe_candidate([mutated])

    def test_frozen_evidence_prevents_hiding_every_cross_market_token_conflict(self) -> None:
        first = self.attribute(event(), market(market_id="m1", tokens=["1001", "1002"]))
        cases = (
            ("no_no", ["1003", "1002"], "2001", (("Yes", "2001"), ("No", "2002"))),
            ("yes_no", ["1002", "1003"], "2003", (("Yes", "2003"), ("No", "2004"))),
            ("no_yes", ["1003", "1001"], "2005", (("Yes", "2005"), ("No", "2006"))),
            ("yes_yes", ["1001", "1003"], "2007", (("Yes", "2007"), ("No", "2008"))),
        )
        for index, (name, raw_tokens, forged_yes, forged_binding) in enumerate(cases, start=2):
            conflicting = self.attribute(
                event(), market(market_id=f"m{index}", tokens=raw_tokens)
            )
            hidden = {
                **conflicting,
                "token_id": forged_yes,
                "_outcome_token_bindings": forged_binding,
            }
            with self.subTest(name=name), self.assertRaises(collector.MarketScanIncomplete):
                collector.build_research_universe_candidate([first, hidden])

    def test_global_token_and_market_mapping_is_unique(self) -> None:
        first = self.attribute(event(), market(market_id="m1", tokens=["1001", "1002"]))
        second = self.attribute(event(), market(market_id="m2", tokens=["1001", "1003"]))
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "duplicate_mapping"):
            collector.build_research_universe_candidate([first, first])
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "token_remapped"):
            collector.build_research_universe_candidate([first, second])

        remapped_market = dict(
            first,
            token_id="9999",
            _outcome_token_bindings=(("Yes", "9999"), ("No", "1002")),
        )
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "market_remapped"):
            collector.build_research_universe_candidate([first, remapped_market])

    def test_all_ten_city_pairs_are_verified_without_regression(self) -> None:
        for index, (city, (station, scope)) in enumerate(CITY_MATRIX.items(), start=1):
            with self.subTest(city=city):
                result = self.attribute(
                    event(city, station),
                    market(city, station, market_id=f"market-{index}", tokens=[str(index * 10), str(index * 10 + 1)]),
                )
                self.assertEqual(result["attribution_status"], "verified")
                self.assertEqual((result["city"], result["station"], result["city_scope"]),
                                 (city, station, scope))

    def test_non_verified_statuses_never_carry_market_facts(self) -> None:
        for status in ("no_active_market", "scan_not_executed", "search_failed"):
            result = collector.research_attribution_status(
                status, f"unit_{status}", scan_id=SCAN_ID, scanned_at=SCANNED_AT,
                event_payload=event(),
            )
            self.assertEqual(result["attribution_status"], status)
            for field in (
                "market_id", "market_question", "resolution_source", "resolution_source_host",
                "bucket_label", "outcome", "token_id",
            ):
                self.assertIsNone(result[field], field)

    def test_enriched_candidate_is_canonical_hashed_and_requires_every_field(self) -> None:
        records = [
            self.attribute(event("Wuhan", "ZHHH"), market(market_id="m2", tokens=["200", "201"])),
            self.attribute(event("Wuhan", "ZHHH"), market(market_id="m1", tokens=["100", "101"])),
        ]
        candidate = collector.build_research_universe_candidate(records)
        self.assertEqual([item["token_id"] for item in candidate["members"]], ["100", "200"])
        self.assertEqual(candidate["token_count"], 2)
        self.assertEqual(len(candidate["token_hash"]), 64)
        expected = {
            "schema", "token_id", "market_id", "city", "city_scope", "station",
            "target_date", "outcome", "event_id", "source_scan_id", "attribution_status",
        }
        self.assertEqual(set(candidate["members"][0]), expected)

        for field in ("station", "city_scope", "event_id", "scan_id", "outcome"):
            broken = dict(records[0])
            broken[field] = None
            with self.subTest(field=field), self.assertRaises(collector.MarketScanIncomplete):
                collector.build_research_universe_candidate([broken])

    def test_candidate_revalidates_complete_verified_dto_and_single_scan(self) -> None:
        record = self.attribute(event(), market())
        for field in (
            "scanned_at", "event_title", "market_question", "resolution_source",
            "resolution_source_host", "bucket_label", "reason_code",
        ):
            broken = dict(record)
            broken[field] = None
            with self.subTest(field=field), self.assertRaises(collector.MarketScanIncomplete):
                collector.build_research_universe_candidate([broken])

        mutations = {
            "wrong_scope": {"city_scope": "formal"},
            "wrong_station": {"station": "ZBAA"},
            "bad_date": {"target_date": "not-a-date"},
            "inactive": {"active": False},
            "closed": {"closed": True},
            "bad_reason": {"reason_code": "forged"},
        }
        for name, values in mutations.items():
            with self.subTest(name=name), self.assertRaises(collector.MarketScanIncomplete):
                collector.build_research_universe_candidate([{**record, **values}])

        other_scan = {**record, "scan_id": "scan-b"}
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "mixed_scan"):
            collector.build_research_universe_candidate([record, other_scan])

    def test_candidate_target_year_comes_from_frozen_query_not_target_date(self) -> None:
        record = self.attribute(event(), market())
        for wrong_year in ("2025-08-09", "2099-08-09"):
            with self.subTest(target_date=wrong_year), self.assertRaisesRegex(
                collector.MarketScanIncomplete, "candidate_contract_invalid"
            ):
                collector.build_research_universe_candidate([
                    {**record, "target_date": wrong_year}
                ])

    def test_candidate_query_target_is_bound_to_scanned_china_three_day_window(self) -> None:
        record = self.attribute(event(), market())
        for target_date in ("2025-08-09", "2099-08-09", "2026-08-08", "2026-08-12"):
            mutated = {
                **record,
                "target_date": target_date,
                "_query_target_date": target_date,
            }
            with self.subTest(target_date=target_date), self.assertRaisesRegex(
                collector.MarketScanIncomplete, "candidate_query_window_invalid"
            ):
                collector.build_research_universe_candidate([mutated])

        china_next_day = collector.attribute_research_market(
            event(day="August 10", query_target_date="2026-08-10"),
            market(day="August 10"),
            scan_id="china-boundary", scanned_at="2026-08-09T16:01:00+00:00",
        )
        candidate = collector.build_research_universe_candidate([china_next_day])
        self.assertEqual(candidate["members"][0]["target_date"], "2026-08-10")

        utc_day_but_previous_china_day = collector.attribute_research_market(
            event(day="August 9", query_target_date="2026-08-09"),
            market(day="August 9"),
            scan_id="china-boundary-old", scanned_at="2026-08-09T16:01:00+00:00",
        )
        with self.assertRaisesRegex(
            collector.MarketScanIncomplete, "candidate_query_window_invalid"
        ):
            collector.build_research_universe_candidate([utc_day_but_previous_china_day])

        cross_year = collector.attribute_research_market(
            event(day="January 1", query_target_date="2027-01-01"),
            market(day="January 1"),
            scan_id="cross-year-candidate", scanned_at="2026-12-31T15:59:00+00:00",
        )
        self.assertEqual(
            collector.build_research_universe_candidate([cross_year])["members"][0]["target_date"],
            "2027-01-01",
        )

    def test_candidate_requires_one_normalized_scanned_instant_per_scan(self) -> None:
        first = self.attribute(event(), market(market_id="m1", tokens=["1001", "1002"]))
        different_instant = collector.attribute_research_market(
            event(), market(market_id="m2", tokens=["1003", "1004"]),
            scan_id=SCAN_ID, scanned_at="2026-08-09T15:01:00+00:00",
        )
        with self.assertRaisesRegex(collector.MarketScanIncomplete, "candidate_scanned_at_mismatch"):
            collector.build_research_universe_candidate([first, different_instant])

        same_instant = collector.attribute_research_market(
            event(), market(market_id="m3", tokens=["1005", "1006"]),
            scan_id=SCAN_ID, scanned_at="2026-08-09T23:00:00+08:00",
        )
        candidate = collector.build_research_universe_candidate([first, same_instant])
        self.assertEqual(candidate["scanned_at"], "2026-08-09T15:00:00+00:00")

    def test_query_city_and_target_date_are_hard_attribution_bindings(self) -> None:
        wrong_city = event("Beijing", "ZBAA", query_city="Wuhan")
        self.assert_rejected(
            wrong_city,
            market("Beijing", "ZBAA"),
            "event_query_city_mismatch",
        )

        wrong_date = event(
            day="January 1",
            query_city="Wuhan",
            query_target_date="2026-12-31",
        )
        self.assert_rejected(
            wrong_date,
            market(day="January 1"),
            "event_query_date_mismatch",
        )

    def test_contract_templates_bucket_activity_and_cross_year_are_deterministic(self) -> None:
        self.assert_rejected(
            {**event(), "title": "prefix Highest temperature in Wuhan on August 9"},
            market(), "event_contract_invalid",
        )
        self.assert_rejected(
            event(), {**market(), "question": market()["question"] + " unrelated suffix"},
            "market_contract_invalid",
        )
        self.assert_rejected(
            event(), {**market(), "question": "Will it rain and will the highest temperature in Wuhan be 30 C on August 9?"},
            "market_contract_invalid",
        )
        self.assert_rejected(event(), {**market(), "groupItemTitle": "rain"}, "market_bucket_invalid")
        self.assert_rejected({**event(), "active": False}, market(), "event_inactive")
        self.assert_rejected({**event(), "closed": True}, market(), "event_closed")
        self.assert_rejected(event(), {**market(), "active": False}, "market_inactive")
        self.assert_rejected(event(), {**market(), "closed": True}, "market_closed")
        self.assert_rejected(
            event(),
            market(market_id='market-x" onmouseover="window.pwned=1'),
            "market_id_invalid",
        )

        new_year_event = event(day="January 1", query_target_date="2027-01-01")
        new_year_market = market(day="January 1")
        result = collector.attribute_research_market(
            new_year_event, new_year_market,
            scan_id="cross-year", scanned_at="2026-12-31T16:30:00+00:00",
        )
        self.assertEqual(result["target_date"], "2027-01-01")

        explicit = event(day="January 1, 2031", query_target_date="2031-01-01")
        explicit_market = market(day="January 1, 2031")
        replay = collector.attribute_research_market(
            explicit, explicit_market,
            scan_id="replay", scanned_at="2040-06-01T00:00:00+00:00",
        )
        self.assertEqual(replay["target_date"], "2031-01-01")

        self.assertEqual(
            collector._date_near_reference("February", "29", None, collector.date(2024, 2, 28)),
            "2024-02-29",
        )
        self.assertIsNone(
            collector._date_near_reference("February", "30", None, collector.date(2024, 2, 28))
        )

    def test_city_date_status_matrix_is_complete_for_each_query(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "matrix.sqlite3"
            with patch.object(collector, "DB_PATH", path), patch.object(collector, "prune_research_data"):
                db = collector.connect()
            statuses: list[dict] = []
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"beijing", "wuhan"}), \
                     patch.object(collector, "prepare_research_universe_publication",
                                  side_effect=_test_authorized_publication):
                    found = asyncio.run(collector.collect_markets(
                        _TwoCityMatrixClient(), db, SCANNED_AT,
                        attribution_results=statuses,
                    ))
            finally:
                db.close()
        self.assertEqual(found, 1)
        matrix = {(item["city"], item["target_date"]): item["attribution_status"]
                  for item in statuses}
        self.assertEqual(matrix[("Beijing", "2026-08-09")], "verified")
        self.assertEqual(matrix[("Wuhan", "2026-08-09")], "no_active_market")
        self.assertEqual(
            set(matrix),
            {(city, f"2026-08-{day:02d}")
             for city in ("Beijing", "Wuhan") for day in (9, 10, 11)},
        )

    def test_search_failure_and_query_city_misroute_are_query_scoped_and_preserve_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            try:
                statuses: list[dict] = []
                with patch.object(collector, "ALLOWED_CITIES", {"beijing", "wuhan"}):
                    found = asyncio.run(collector.collect_markets(
                        _SearchFailureByCityClient(), db, SCANNED_AT,
                        attribution_results=statuses,
                    ))
                self.assertEqual(found, 0)
                wuhan_failures = [item for item in statuses
                                  if item["city"] == "Wuhan"
                                  and item["attribution_status"] == "search_failed"]
                self.assertEqual({item["target_date"] for item in wuhan_failures}, {
                    "2026-08-09", "2026-08-10", "2026-08-11",
                })
                self.assertNotIn(
                    "no_active_market",
                    {item["attribution_status"] for item in wuhan_failures},
                )
                self.assert_previous_manifest_unchanged(db)

                statuses = []
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}):
                    found = asyncio.run(collector.collect_markets(
                        _MisroutedCityClient(), db, SCANNED_AT,
                        attribution_results=statuses,
                    ))
                self.assertEqual(found, 0)
                rejected = [item for item in statuses
                            if item["city"] == "Wuhan"
                            and item["target_date"] == "2026-08-09"]
                self.assertEqual(rejected[-1]["attribution_status"], "attribution_rejected")
                self.assertEqual(
                    rejected[-1]["reason_code"], "search_event_query_city_mismatch"
                )
                self.assert_previous_manifest_unchanged(db)
            finally:
                db.close()

    def test_event_only_gate_rejects_invalid_empty_or_inactive_market_events_atomically(self) -> None:
        cases = {
            "source_host": "event_source_host",
            "station": "event_station_mismatch",
            "query_city": "event_query_city_mismatch",
            "query_date": "event_query_date_mismatch",
            "title": "event_contract_invalid",
            "inactive_markets": "event_source_host",
            "closed_markets": "event_source_host",
        }
        for invalid_case, reason_code in cases.items():
            with self.subTest(invalid_case=invalid_case), tempfile.TemporaryDirectory() as tmp:
                db = self._temporary_database(tmp)
                before_snapshots = db.execute(
                    "SELECT COUNT(*) FROM market_snapshots"
                ).fetchone()[0]
                statuses: list[dict] = []
                try:
                    with patch.object(collector, "ALLOWED_CITIES", {"beijing", "wuhan"}):
                        found = asyncio.run(collector.collect_markets(
                            _EventOnlyMatrixClient(invalid_case), db, SCANNED_AT,
                            attribution_results=statuses,
                        ))
                    after_snapshots = db.execute(
                        "SELECT COUNT(*) FROM market_snapshots"
                    ).fetchone()[0]
                    rejected = [item for item in statuses
                                if item["city"] == "Wuhan"
                                and item["target_date"] == "2026-08-09"]
                    self.assertEqual(found, 0)
                    self.assertEqual(after_snapshots, before_snapshots)
                    self.assertEqual(rejected[-1]["attribution_status"], "attribution_rejected")
                    self.assertEqual(rejected[-1]["reason_code"], reason_code)
                    self.assert_previous_manifest_unchanged(db)
                finally:
                    db.close()

    def test_public_search_misroute_is_rejected_before_detail_fetch(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            client = _SearchMisrouteNoDetailClient()
            statuses: list[dict] = []
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}):
                    found = asyncio.run(collector.collect_markets(
                        client, db, SCANNED_AT, attribution_results=statuses,
                    ))
                rejected = [item for item in statuses
                            if item["target_date"] == "2026-08-09"]
                self.assertEqual(found, 0)
                self.assertFalse(client.detail_requested)
                self.assertEqual(rejected[-1]["attribution_status"], "attribution_rejected")
                self.assertEqual(
                    rejected[-1]["reason_code"], "search_event_query_city_mismatch"
                )
                self.assert_previous_manifest_unchanged(db)
            finally:
                db.close()

    def test_only_same_city_adjacent_dates_are_no_exact_without_detail_fetch(self) -> None:
        adjacent = []
        for event_day in (11, 15):
            summary = event(
                "Wuhan", "ZHHH", day=f"August {event_day}",
                query_target_date=f"2026-08-{event_day:02d}",
            )
            summary["id"] = f"event-wuhan-202608{event_day:02d}"
            adjacent.append(summary)
        client = _GammaSearchFixtureClient(
            {_search_phrase("Wuhan", date(2026, 8, day)): adjacent
             for day in (12, 13, 14)},
            {},
        )
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            statuses: list[dict] = []
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}):
                    found = asyncio.run(collector.collect_markets(
                        client, db, "2026-08-12T01:00:00+00:00",
                        attribution_results=statuses,
                    ))
                self.assertEqual(found, 0)
                self.assertEqual(client.detail_requests, [])
                self.assertEqual(
                    {(item["target_date"], item["attribution_status"], item["reason_code"])
                     for item in statuses},
                    {(f"2026-08-{day:02d}", "no_active_market", "no_exact_active_event")
                     for day in (12, 13, 14)},
                )
                self.assert_previous_manifest_unchanged(db)
            finally:
                db.close()

    def test_exact_and_fuzzy_results_fetch_only_exact_and_do_not_create_ambiguity(self) -> None:
        exact = event(
            "Wuhan", "ZHHH", day="August 12", query_target_date="2026-08-12"
        )
        exact["id"] = "event-wuhan-20260812"
        older = event(
            "Wuhan", "ZHHH", day="August 11", query_target_date="2026-08-11"
        )
        older["id"] = "event-wuhan-20260811"
        detail = dict(exact)
        detail["markets"] = [market(
            day="August 12", market_id="market-wuhan-20260812",
            tokens=["12001", "12002"],
        )]
        client = _GammaSearchFixtureClient({
            _search_phrase("Wuhan", date(2026, 8, 12)): [older, exact],
            _search_phrase("Wuhan", date(2026, 8, 13)): [exact],
            _search_phrase("Wuhan", date(2026, 8, 14)): [older, exact],
        }, {exact["id"]: detail})
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            statuses: list[dict] = []
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}), \
                     patch.object(collector, "prepare_research_universe_publication",
                                  side_effect=_test_authorized_publication):
                    found = asyncio.run(collector.collect_markets(
                        client, db, "2026-08-12T01:00:00+00:00",
                        attribution_results=statuses,
                    ))
                matrix = {(item["city"], item["target_date"]):
                          (item["attribution_status"], item["reason_code"])
                          for item in statuses}
                self.assertEqual(found, 1)
                self.assertEqual(client.detail_requests, [exact["id"]])
                self.assertEqual(matrix[("Wuhan", "2026-08-12")], ("verified", "verified"))
                self.assertEqual(
                    matrix[("Wuhan", "2026-08-13")],
                    ("no_active_market", "no_exact_active_event"),
                )
                self.assertEqual(
                    matrix[("Wuhan", "2026-08-14")],
                    ("no_active_market", "no_exact_active_event"),
                )
                latest = db.execute(
                    "SELECT token_count,members_json FROM market_universe_publications "
                    "ORDER BY published_at DESC LIMIT 1"
                ).fetchone()
                self.assertEqual(latest[0], 1)
                self.assertEqual(json.loads(latest[1])[0]["token_id"], "12001")
            finally:
                db.close()

    def test_multiple_exact_events_are_a_hard_query_rejection(self) -> None:
        exact_events = []
        for suffix in ("a", "b"):
            summary = event(
                "Wuhan", "ZHHH", day="August 12",
                query_target_date="2026-08-12",
            )
            summary["id"] = f"event-wuhan-20260812-{suffix}"
            exact_events.append(summary)
        client = _GammaSearchFixtureClient({
            _search_phrase("Wuhan", date(2026, 8, 12)): exact_events,
        }, {})
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            statuses: list[dict] = []
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}):
                    found = asyncio.run(collector.collect_markets(
                        client, db, "2026-08-12T01:00:00+00:00",
                        attribution_results=statuses,
                    ))
                rejected = [item for item in statuses
                            if item["target_date"] == "2026-08-12"]
                self.assertEqual(found, 0)
                self.assertEqual(client.detail_requests, [])
                self.assertEqual(rejected[-1]["attribution_status"], "attribution_rejected")
                self.assertEqual(rejected[-1]["reason_code"], "multiple_exact_active_events")
                self.assert_previous_manifest_unchanged(db)
            finally:
                db.close()

    def test_invalid_or_misrouted_search_events_remain_hard_failures(self) -> None:
        wrong_city = event(
            "Beijing", "ZBAA", day="August 12", query_target_date="2026-08-12"
        )
        invalid_title = event(
            "Wuhan", "ZHHH", day="August 12", query_target_date="2026-08-12"
        )
        invalid_title["title"] = "Will it rain in Wuhan on August 12?"
        cases = (
            (wrong_city, "search_event_query_city_mismatch"),
            (invalid_title, "search_event_contract_invalid"),
        )
        for payload, reason in cases:
            with self.subTest(reason=reason):
                query_results: list[dict] = []
                client = _GammaSearchFixtureClient({
                    _search_phrase("Wuhan", date(2026, 8, 12)): [payload],
                }, {})
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}), \
                     self.assertRaises(collector.MarketScanIncomplete) as raised:
                    asyncio.run(collector.active_events(
                        client, query_date=date(2026, 8, 12),
                        query_results=query_results,
                    ))
                self.assertEqual(raised.exception.reason_code, reason)
                by_date = {item["query_target_date"]: item for item in query_results}
                self.assertEqual(by_date["2026-08-12"]["status"], "attribution_rejected")
                self.assertEqual(by_date["2026-08-12"]["reason_code"], reason)
                self.assertEqual(client.detail_requests, [])

    def test_search_summary_activity_requires_present_native_booleans(self) -> None:
        invalid_cases = (
            ("active_missing", "active", False, None),
            ("closed_missing", "closed", False, None),
            ("active_string", "active", True, "true"),
            ("closed_string", "closed", True, "false"),
            ("active_integer", "active", True, 1),
            ("closed_integer", "closed", True, 0),
            ("active_null", "active", True, None),
            ("closed_null", "closed", True, None),
        )
        query = _search_phrase("Wuhan", date(2026, 8, 9))
        for name, field, field_present, value in invalid_cases:
            with self.subTest(name=name):
                summary = event("Wuhan", "ZHHH")
                if field_present:
                    summary[field] = value
                else:
                    summary.pop(field)
                query_results: list[dict] = []
                client = _GammaSearchFixtureClient({query: [summary]}, {})
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}), \
                     self.assertRaises(collector.MarketScanIncomplete) as raised:
                    asyncio.run(collector.active_events(
                        client, query_date=date(2026, 8, 9),
                        query_results=query_results,
                    ))
                point = next(item for item in query_results
                             if item["query_target_date"] == "2026-08-09")
                self.assertEqual(raised.exception.reason_code, "search_event_activity_invalid")
                self.assertEqual(point["status"], "attribution_rejected")
                self.assertEqual(point["reason_code"], "search_event_activity_invalid")
                self.assertEqual(client.detail_requests, [])

    def test_native_boolean_inactive_is_excluded_and_exact_still_reaches_detail(self) -> None:
        query = _search_phrase("Wuhan", date(2026, 8, 9))
        for active, closed in ((False, False), (False, True), (True, True)):
            with self.subTest(active=active, closed=closed):
                query_results: list[dict] = []
                summary = {**event(), "active": active, "closed": closed}
                client = _GammaSearchFixtureClient({query: [summary]}, {})
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}):
                    events = asyncio.run(collector.active_events(
                        client, query_date=date(2026, 8, 9),
                        query_results=query_results,
                    ))
                point = next(item for item in query_results
                             if item["query_target_date"] == "2026-08-09")
                self.assertEqual(events, [])
                self.assertEqual(point["status"], "no_active_market")
                self.assertEqual(point["reason_code"], "no_active_event")

        exact = event()
        detail = dict(exact)
        detail["markets"] = [market(
            market_id="native-bool-exact", tokens=["14001", "14002"]
        )]
        client = _GammaSearchFixtureClient({query: [exact]}, {exact["id"]: detail})
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}), \
                     patch.object(collector, "prepare_research_universe_publication",
                                  side_effect=_test_authorized_publication):
                    found = asyncio.run(collector.collect_markets(client, db, SCANNED_AT))
                self.assertEqual(found, 1)
                self.assertEqual(client.detail_requests, [exact["id"]])
            finally:
                db.close()

    def test_invalid_search_activity_preserves_two_city_manifest_atomically(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "two-city.sqlite3"
            with patch.object(collector, "DB_PATH", path), \
                 patch.object(collector, "prune_research_data"):
                db = collector.connect()
            previous_at = "2026-08-09T14:00:00+00:00"
            previous_markets = (
                ("Beijing", "ZBAA", "old-beijing", ["9101", "9102"]),
                ("Wuhan", "ZHHH", "old-wuhan", ["9201", "9202"]),
            )
            previous_members = []
            for city, station, market_id, tokens in previous_markets:
                collector.save_market(
                    db, previous_at,
                    market(city, station, market_id=market_id, tokens=tokens),
                    city,
                )
                previous_members.append({
                    "token_id": tokens[0], "market_id": market_id,
                    "city": city, "target_date": "2026-08-09",
                })
            collector.publish_market_universe(
                db, previous_at, previous_members, "complete_scan"
            )
            db.commit()

            before = {
                "snapshots": db.execute(
                    "SELECT * FROM market_snapshots ORDER BY captured_at,market_id"
                ).fetchall(),
                "rules": db.execute(
                    "SELECT * FROM market_rules ORDER BY market_id"
                ).fetchall(),
                "publications": db.execute(
                    "SELECT publication_id,published_at,token_hash,token_count,members_json,reason "
                    "FROM market_universe_publications ORDER BY published_at"
                ).fetchall(),
            }

            beijing = event("Beijing", "ZBAA")
            beijing["id"] = "event-beijing-current"
            beijing_detail = dict(beijing)
            beijing_detail["markets"] = [market(
                "Beijing", "ZBAA", market_id="new-beijing",
                tokens=["7101", "7102"],
            )]
            wuhan = {**event("Wuhan", "ZHHH"), "active": "true"}
            wuhan["id"] = "event-wuhan-invalid-activity"
            client = _GammaSearchFixtureClient({
                _search_phrase("Beijing", date(2026, 8, 9)): [beijing],
                _search_phrase("Wuhan", date(2026, 8, 9)): [wuhan],
            }, {beijing["id"]: beijing_detail})
            statuses: list[dict] = []
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"beijing", "wuhan"}):
                    found = asyncio.run(collector.collect_markets(
                        client, db, SCANNED_AT, attribution_results=statuses,
                    ))
                after = {
                    "snapshots": db.execute(
                        "SELECT * FROM market_snapshots ORDER BY captured_at,market_id"
                    ).fetchall(),
                    "rules": db.execute(
                        "SELECT * FROM market_rules ORDER BY market_id"
                    ).fetchall(),
                    "publications": db.execute(
                        "SELECT publication_id,published_at,token_hash,token_count,members_json,reason "
                        "FROM market_universe_publications ORDER BY published_at"
                    ).fetchall(),
                }
                latest = after["publications"][-1]
                active_snapshots = db.execute(
                    "SELECT market_id,active FROM market_snapshots "
                    "WHERE market_id IN ('old-beijing','old-wuhan') ORDER BY market_id"
                ).fetchall()
                wuhan_status = next(
                    item for item in statuses
                    if item["city"] == "Wuhan" and item["target_date"] == "2026-08-09"
                )
                self.assertEqual(found, 0)
                self.assertEqual(client.detail_requests, [])
                self.assertEqual(after, before)
                self.assertEqual(active_snapshots, [("old-beijing", 1), ("old-wuhan", 1)])
                self.assertEqual(latest[3], 2)
                self.assertEqual(json.loads(latest[4]), previous_members)
                self.assertEqual(latest[2], before["publications"][-1][2])
                self.assertEqual(wuhan_status["attribution_status"], "attribution_rejected")
                self.assertEqual(wuhan_status["reason_code"], "search_event_activity_invalid")
            finally:
                db.close()

    def test_seven_city_three_day_fuzzy_matrix_has_18_exact_and_3_no_exact_points(self) -> None:
        client = _ThirtyPointFuzzyClient()
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            statuses: list[dict] = []
            try:
                with patch.object(
                    collector, "ALLOWED_CITIES", {city.lower() for city in CITY_MATRIX}
                ), patch.object(collector, "prepare_research_universe_publication",
                                side_effect=_test_authorized_publication):
                    found = asyncio.run(collector.collect_markets(
                        client, db, SCANNED_AT, attribution_results=statuses,
                    ))
                points = {(item["city"], item["target_date"]): item for item in statuses}
                exact = [item for item in points.values()
                         if item["attribution_status"] == "verified"]
                no_exact = [item for item in points.values()
                            if item["attribution_status"] == "no_active_market"]
                expected_exact_points = {
                    (city, f"2026-08-{day:02d}")
                    for city in list(CITY_MATRIX)[:6] for day in (9, 10, 11)
                }
                self.assertEqual(found, 18)
                self.assertEqual(len(statuses), 21)
                self.assertEqual(len(points), 21)
                self.assertEqual(len(exact), 18)
                self.assertEqual(len(no_exact), 3)
                self.assertEqual(
                    {point for point, item in points.items()
                     if item["attribution_status"] == "verified"},
                    expected_exact_points,
                )
                self.assertEqual(
                    {item["reason_code"] for item in no_exact},
                    {"no_exact_active_event"},
                )
                self.assertEqual(len(client.detail_requests), 18)
                self.assertEqual(len(set(client.detail_requests)), 18)
                latest_count = db.execute(
                    "SELECT token_count FROM market_universe_publications "
                    "ORDER BY published_at DESC LIMIT 1"
                ).fetchone()[0]
                self.assertEqual(latest_count, 18)
            finally:
                db.close()

    def test_fuzzy_no_exact_points_do_not_weaken_atomic_hard_failures(self) -> None:
        exact = event("Beijing", "ZBAA")
        exact["id"] = "event-beijing-exact"
        fuzzy = event(
            "Wuhan", "ZHHH", day="August 8", query_target_date="2026-08-08"
        )
        fuzzy["id"] = "event-wuhan-fuzzy"
        search_events = {
            _search_phrase("Wuhan", date(2026, 8, day)): [fuzzy]
            for day in (9, 10, 11)
        }
        expected_reasons = {
            "multiple_exact": "multiple_exact_active_events",
            "detail": "event_markets_missing",
            "market": "market_token_not_decimal",
        }
        for mode, expected_reason in expected_reasons.items():
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                per_scan_events = dict(search_events)
                details: dict[str, dict] = {}
                if mode == "multiple_exact":
                    duplicate = dict(exact)
                    duplicate["id"] = "event-beijing-exact-duplicate"
                    per_scan_events[_search_phrase("Beijing", date(2026, 8, 9))] = [
                        exact, duplicate,
                    ]
                else:
                    per_scan_events[_search_phrase("Beijing", date(2026, 8, 9))] = [exact]
                    detail = dict(exact)
                    if mode == "detail":
                        details[exact["id"]] = detail
                    else:
                        detail["markets"] = [market(
                            "Beijing", "ZBAA", market_id="bad-market",
                            tokens=["not-decimal", "13002"],
                        )]
                        details[exact["id"]] = detail
                client = _GammaSearchFixtureClient(per_scan_events, details)
                db = self._temporary_database(tmp)
                before = {
                    table: db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                    for table in (
                        "market_snapshots", "market_rules", "market_universe_publications"
                    )
                }
                statuses: list[dict] = []
                try:
                    with patch.object(collector, "ALLOWED_CITIES", {"beijing", "wuhan"}):
                        found = asyncio.run(collector.collect_markets(
                            client, db, SCANNED_AT, attribution_results=statuses,
                        ))
                    after = {
                        table: db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                        for table in before
                    }
                    self.assertEqual(found, 0)
                    self.assertEqual(after, before)
                    self.assertIn(
                        expected_reason,
                        {item["reason_code"] for item in statuses
                         if item["attribution_status"] == "attribution_rejected"},
                    )
                    self.assert_previous_manifest_unchanged(db)
                finally:
                    db.close()

    def test_multiple_detail_failures_keep_each_query_reason_code(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            statuses: list[dict] = []
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"beijing", "wuhan"}):
                    found = asyncio.run(collector.collect_markets(
                        _MultipleDetailFailureClient(), db, SCANNED_AT,
                        attribution_results=statuses,
                    ))
                reasons = {(item["city"], item["target_date"]): item["reason_code"]
                           for item in statuses
                           if item["attribution_status"] == "attribution_rejected"}
                self.assertEqual(found, 0)
                self.assertEqual(reasons[("Beijing", "2026-08-09")], "event_markets_missing")
                self.assertEqual(reasons[("Wuhan", "2026-08-09")], "event_markets_not_list")
                self.assert_previous_manifest_unchanged(db)
            finally:
                db.close()

    def test_search_budget_timeout_marks_every_query_not_executed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            statuses: list[dict] = []
            try:
                with patch.object(collector, "ALLOWED_CITIES", {"beijing", "wuhan"}), \
                     patch.object(collector, "MARKET_SCAN_BUDGET_SECONDS", 0.01):
                    found = asyncio.run(collector.collect_markets(
                        _HangingSearchClient(), db, SCANNED_AT,
                        attribution_results=statuses,
                    ))
                self.assertEqual(found, 0)
                self.assertEqual(
                    {(item["city"], item["target_date"], item["attribution_status"])
                     for item in statuses},
                    {(city, f"2026-08-{day:02d}", "scan_not_executed")
                     for city in ("Beijing", "Wuhan") for day in (9, 10, 11)},
                )
                self.assert_previous_manifest_unchanged(db)
            finally:
                db.close()

    def test_search_and_detail_structure_fail_closed_with_actual_statuses(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            try:
                for payload, reason in (
                    ({}, "search_response_events_missing"),
                    ({"events": {}}, "search_response_events_not_list"),
                ):
                    statuses = []
                    with self.subTest(reason=reason), patch.object(collector, "ALLOWED_CITIES", {"wuhan"}):
                        found = asyncio.run(collector.collect_markets(
                            _SearchPayloadClient(payload), db, SCANNED_AT,
                            attribution_results=statuses,
                        ))
                        self.assertEqual(found, 0)
                        self.assertEqual(statuses[-1]["attribution_status"], "search_failed")
                        self.assertEqual(statuses[-1]["reason_code"], reason)
                        self.assert_previous_manifest_unchanged(db)

                summary = event()
                for markets_value, reason in (
                    ("missing", "event_markets_missing"),
                    (None, "event_markets_not_list"),
                    ({}, "event_markets_not_list"),
                ):
                    detail = dict(summary)
                    if markets_value != "missing":
                        detail["markets"] = markets_value
                    statuses = []
                    with self.subTest(reason=reason), patch.object(collector, "active_events", return_value=[summary]):
                        found = asyncio.run(collector.collect_markets(
                            _DetailClient(detail), db, SCANNED_AT,
                            attribution_results=statuses,
                        ))
                        self.assertEqual(found, 0)
                        self.assertEqual(statuses[-1]["attribution_status"], "attribution_rejected")
                        self.assertEqual(statuses[-1]["reason_code"], reason)
                        self.assert_previous_manifest_unchanged(db)
            finally:
                db.close()

    def test_empty_scan_and_all_four_non_verified_paths_preserve_previous_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            try:
                statuses = []
                with patch.object(collector, "ALLOWED_CITIES", {"wuhan"}):
                    self.assertEqual(asyncio.run(collector.collect_markets(
                        _SearchPayloadClient({"events": []}), db, SCANNED_AT,
                        attribution_results=statuses,
                    )), 0)
                self.assertEqual(statuses[-1]["attribution_status"], "no_active_market")
                self.assert_previous_manifest_unchanged(db)

                statuses = []
                with patch.object(collector, "active_events", side_effect=TimeoutError):
                    self.assertEqual(asyncio.run(collector.collect_markets(
                        _SearchPayloadClient({}), db, SCANNED_AT,
                        attribution_results=statuses,
                    )), 0)
                self.assertEqual(statuses[-1]["attribution_status"], "scan_not_executed")
                self.assert_previous_manifest_unchanged(db)

                bad_detail = event()
                bad_detail["markets"] = [market(resolution_source=None)]
                statuses = []
                with patch.object(collector, "active_events", return_value=[event()]):
                    self.assertEqual(asyncio.run(collector.collect_markets(
                        _DetailClient(bad_detail), db, SCANNED_AT,
                        attribution_results=statuses,
                    )), 0)
                self.assertEqual(statuses[-1]["attribution_status"], "attribution_rejected")
                self.assert_previous_manifest_unchanged(db)
            finally:
                db.close()

    def test_resolution_response_must_preserve_original_attribution(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "resolution.sqlite3"
            with patch.object(collector, "DB_PATH", path), patch.object(collector, "prune_research_data"):
                db = collector.connect()
            original = market("Wuhan", "ZHHH", market_id="wuhan-market", day="August 8")
            collector.save_market(db, "2026-08-08T12:00:00+00:00", original, "Wuhan")
            db.commit()
            wrong = market("Beijing", "ZBAA", market_id="beijing-market", day="August 8")
            wrong.update({"closed": True, "active": False, "outcomePrices": '["1", "0"]',
                          "acceptingOrders": False, "umaResolutionStatus": "resolved",
                          "groupItemTitle": "99 C"})
            before_snapshots = db.execute("SELECT COUNT(*) FROM market_snapshots").fetchone()[0]
            try:
                resolved = asyncio.run(collector.collect_resolutions(
                    _ResolutionPayloadClient({"wuhan-market": wrong}), db,
                    "2026-08-09T16:05:00+00:00",
                ))
                after_snapshots = db.execute("SELECT COUNT(*) FROM market_snapshots").fetchone()[0]
                resolution_count = db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0]
            finally:
                db.close()
            self.assertEqual((resolved, before_snapshots, after_snapshots, resolution_count), (0, 1, 1, 0))

    def _resolution_result(
        self, response: dict, *, original: dict | None = None
    ) -> tuple[int, int, int, int]:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "resolution.sqlite3"
            with patch.object(collector, "DB_PATH", path), patch.object(collector, "prune_research_data"):
                db = collector.connect()
            original = original or market(
                "Wuhan", "ZHHH", market_id="wuhan-market", day="August 8"
            )
            collector.save_market(db, "2026-08-08T12:00:00+00:00", original, "Wuhan")
            db.commit()
            before_snapshots = db.execute("SELECT COUNT(*) FROM market_snapshots").fetchone()[0]
            try:
                resolved = asyncio.run(collector.collect_resolutions(
                    _ResolutionPayloadClient({"wuhan-market": response}), db,
                    "2026-08-09T16:05:00+00:00",
                ))
                after_snapshots = db.execute("SELECT COUNT(*) FROM market_snapshots").fetchone()[0]
                resolution_count = db.execute("SELECT COUNT(*) FROM market_resolutions").fetchone()[0]
            finally:
                db.close()
        return resolved, before_snapshots, after_snapshots, resolution_count

    def test_resolution_question_bucket_must_match_group_item_title(self) -> None:
        response = market("Wuhan", "ZHHH", market_id="wuhan-market", day="August 8")
        response.update({
            "question": "Will the highest temperature in Wuhan be 99 C on August 8?",
            "groupItemTitle": "30 C",
            "active": False,
            "closed": True,
            "acceptingOrders": False,
            "umaResolutionStatus": "resolved",
            "outcomePrices": '["1", "0"]',
        })
        self.assertEqual(self._resolution_result(response), (0, 1, 1, 0))

        stored_mismatch = market("Wuhan", "ZHHH", market_id="wuhan-market", day="August 8")
        stored_mismatch["question"] = "Will the highest temperature in Wuhan be 99 C on August 8?"
        valid_response = market("Wuhan", "ZHHH", market_id="wuhan-market", day="August 8")
        valid_response.update({"active": False, "closed": True,
                               "acceptingOrders": False,
                               "umaResolutionStatus": "resolved",
                               "outcomePrices": '["1", "0"]'})
        self.assertEqual(
            self._resolution_result(valid_response, original=stored_mismatch),
            (0, 1, 1, 0),
        )

    def test_resolution_activity_is_strict_boolean_and_consistent(self) -> None:
        invalid_activity = (
            (True, "false"),
            (False, False),
            (1, 0),
            (True, None),
            (None, None),
        )
        for active, closed in invalid_activity:
            response = market("Wuhan", "ZHHH", market_id="wuhan-market", day="August 8")
            response.update({"active": active, "closed": closed, "outcomePrices": '["1", "0"]'})
            if active is None and closed is None:
                response.pop("active")
                response.pop("closed")
            with self.subTest(active=active, closed=closed):
                self.assertEqual(self._resolution_result(response), (0, 1, 1, 0))

        normally_closed = market("Wuhan", "ZHHH", market_id="wuhan-market", day="August 8")
        normally_closed.update({"active": False, "closed": True,
                                "acceptingOrders": False,
                                "umaResolutionStatus": "resolved",
                                "outcomePrices": '["1", "0"]'})
        self.assertEqual(self._resolution_result(normally_closed), (1, 1, 2, 1))

        live_gamma_closed = market(
            "Wuhan", "ZHHH", market_id="wuhan-market", day="August 8"
        )
        live_gamma_closed.update({"active": True, "closed": True,
                                  "acceptingOrders": False,
                                  "umaResolutionStatus": "resolved",
                                  "outcomePrices": '["1", "0"]'})
        self.assertEqual(self._resolution_result(live_gamma_closed), (1, 1, 2, 1))

        early_winner = market("Wuhan", "ZHHH", market_id="wuhan-market", day="August 8")
        early_winner.update({"active": True, "closed": False, "outcomePrices": '["1", "0"]'})
        # A terminal-looking open price is retained only as provisional
        # evidence.  It must not enter the legacy final-resolution projection.
        self.assertEqual(self._resolution_result(early_winner), (0, 1, 2, 0))

    def test_every_raw_detail_market_requires_native_boolean_activity_before_filtering(self) -> None:
        invalid_cases = (
            ("active_string", {"active": "true"}, None),
            ("active_integer", {"active": 1}, None),
            ("closed_string", {"closed": "false"}, None),
            ("closed_integer", {"closed": 0}, None),
            ("active_null", {"active": None}, None),
            ("closed_null", {"closed": None}, None),
            ("active_missing", {}, "active"),
            ("closed_missing", {}, "closed"),
            ("active_array", {"active": []}, None),
            ("closed_array", {"closed": []}, None),
            ("active_object", {"active": {}}, None),
            ("closed_object", {"closed": {}}, None),
            ("invalid_filtered_inactive", {"active": False, "closed": "false"}, None),
        )
        for index, (name, updates, removed_field) in enumerate(invalid_cases, start=1):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as tmp:
                valid = market(
                    market_id="valid-active", tokens=["15001", "15002"]
                )
                invalid = market(
                    market_id=f"invalid-{index}",
                    tokens=[str(16000 + index * 2), str(16001 + index * 2)],
                )
                invalid.update(updates)
                if removed_field is not None:
                    invalid.pop(removed_field)
                found, before, after, active, statuses = self._detail_market_scan(
                    tmp, [valid, invalid]
                )
                self.assertEqual(found, 0)
                self.assertEqual(after, before)
                self.assertEqual(active, (1,))
                self.assertEqual(statuses[-1]["attribution_status"], "attribution_rejected")
                self.assertEqual(
                    statuses[-1]["reason_code"], "market_activity_contract_invalid"
                )

    def test_non_object_raw_detail_market_remains_a_hard_structure_failure(self) -> None:
        for value in (None, [], "market", 1):
            with self.subTest(value=value), tempfile.TemporaryDirectory() as tmp:
                valid = market(
                    market_id="valid-active", tokens=["15001", "15002"]
                )
                found, before, after, active, statuses = self._detail_market_scan(
                    tmp, [valid, value]
                )
                self.assertEqual(found, 0)
                self.assertEqual(after, before)
                self.assertEqual(active, (1,))
                self.assertEqual(statuses[-1]["attribution_status"], "attribution_rejected")
                self.assertEqual(statuses[-1]["reason_code"], "event_market_not_object")

    def test_valid_active_and_inactive_detail_markets_preserve_candidate_semantics(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db = self._temporary_database(tmp)
            detail = event()
            detail["markets"] = [
                market(market_id="active-later", tokens=["16001", "16002"]),
                {**market(market_id="inactive", tokens=["17001", "17002"]),
                 "active": False, "closed": True},
                market(market_id="active-first", tokens=["15001", "15002"]),
            ]
            summary = {
                key: detail[key]
                for key in (
                    "id", "title", "active", "closed",
                    "_query_city", "_query_target_date",
                )
            }
            try:
                with patch.object(collector, "active_events", return_value=[summary]), \
                     patch.object(collector, "prepare_research_universe_publication",
                                  side_effect=_test_authorized_publication):
                    found = asyncio.run(collector.collect_markets(
                        _DetailClient(detail), db, SCANNED_AT
                    ))
                token_hash, token_count, members_json = db.execute(
                    "SELECT token_hash,token_count,members_json "
                    "FROM market_universe_publications ORDER BY published_at DESC LIMIT 1"
                ).fetchone()
                members = json.loads(members_json)
                canonical = json.dumps(
                    members, ensure_ascii=False, separators=(",", ":"), sort_keys=True
                )
                inactive_rows = db.execute(
                    "SELECT COUNT(*) FROM market_snapshots WHERE market_id='inactive'"
                ).fetchone()[0]
            finally:
                db.close()
        self.assertEqual(found, 1)
        self.assertEqual(token_count, 2)
        self.assertEqual(
            [(item["token_id"], item["market_id"]) for item in members],
            [("15001", "active-first"), ("16001", "active-later")],
        )
        self.assertEqual(
            token_hash, hashlib.sha256(canonical.encode()).hexdigest()
        )
        self.assertEqual(inactive_rows, 0)

    def test_invalid_active_market_preserves_previous_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "research.sqlite3"
            with patch.object(collector, "DB_PATH", path), patch.object(collector, "prune_research_data"):
                db = collector.connect()
            collector.publish_market_universe(
                db, "2026-08-09T14:00:00+00:00",
                [{"token_id": "1", "market_id": "old", "city": "Beijing", "target_date": "2026-08-09"}],
                "complete_scan",
            )
            db.commit()
            detail = event()
            detail["markets"] = [
                market(market_id="good", tokens=["1001", "1002"]),
                market(market_id="bad", resolution_source=None, tokens=["1003", "1004"]),
            ]
            summary = {key: detail[key] for key in ("id", "title", "active", "closed")}
            try:
                with patch.object(collector, "active_events", return_value=[summary]):
                    found = asyncio.run(collector.collect_markets(_DetailClient(detail), db, SCANNED_AT))
                rows = db.execute(
                    "SELECT members_json,reason FROM market_universe_publications ORDER BY published_at"
                ).fetchall()
            finally:
                db.close()
            self.assertEqual(found, 0)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0][1], "complete_scan")


if __name__ == "__main__":
    unittest.main()
