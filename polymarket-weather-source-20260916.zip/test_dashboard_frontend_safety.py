from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import textwrap
import unittest


ROOT = Path(__file__).resolve().parent
HTML = ROOT / "ui" / "live.html"
NODE = Path(os.environ.get(
    "CODEX_NODE",
    r"C:\Users\HP\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe",
))
MODULES = NODE.parent.parent / "node_modules"


def chromium_path() -> str:
    for candidate in (
        os.environ.get("PLAYWRIGHT_CHROMIUM"),
        shutil.which("chrome"),
        shutil.which("msedge"),
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    ):
        if candidate and Path(candidate).is_file():
            return str(candidate)
    raise RuntimeError("required Chromium-family browser is missing")


class DashboardFrontendSafetyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        if not NODE.is_file() or not (MODULES / "playwright").is_dir():
            raise RuntimeError("required Node + Playwright runtime is missing")
        cls.chromium = chromium_path()

    def test_untrusted_identity_is_text_and_detail_requests_are_deduplicated(self) -> None:
        script = textwrap.dedent(r"""
            const {chromium}=require('playwright'),assert=require('node:assert/strict');
            (async()=>{
              const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER});
              const page=await browser.newPage({viewport:{width:900,height:800}}),errors=[];
              page.on('pageerror',error=>errors.push(String(error)));
              await page.addInitScript(()=>{
                window.__calls={history:0,depth:0};
                const wait=value=>new Promise(resolve=>setTimeout(()=>resolve(value),100));
                window.pywebview={api:{
                  snapshot:async()=>({}),
                  history:async()=>{window.__calls.history++;return wait([])},
                  depth:async()=>{window.__calls.depth++;return wait([])},
                  paper_snapshot:async()=>({ok:false}),
                  d0_evidence_panel_v2:async()=>({ok:false,error:{code:'offline',message:'offline'}})
                }};
              });
              await page.goto(process.env.HTML);
              const malicious='market-x" autofocus onfocus="window.pwned=1';
              const frame={now:'2026-08-16 06:00:00',services:{},markets:[{
                id:malicious,token:'123',city:'Shanghai',city_cn:'上海',date:'2026-08-16',
                bucket:'29°C',question:'question',liquidity:1,bid:.40,ask:.42,levels:[]
              }],actuals:[],forecasts:[],validations:[]};
              await page.evaluate(value=>window.dashboardInit(value),frame);
              await page.evaluate(value=>{for(let i=0;i<20;i++)window.dashboardPatch({quotes:[{id:value,bid:.41,ask:.43}]})},malicious);
              await page.waitForTimeout(25);
              assert.deepEqual(await page.evaluate(()=>window.__calls),{history:1,depth:1});
              await page.waitForTimeout(125);
              await page.evaluate(value=>{for(let i=0;i<20;i++)window.dashboardPatch({quotes:[{id:value,bid:.42,ask:.44}]})},malicious);
              await page.waitForTimeout(25);
              assert.deepEqual(await page.evaluate(()=>window.__calls),{history:1,depth:1});
              const result=await page.evaluate(()=>({
                pwned:window.pwned,
                bucketId:document.querySelector('#buckets button')?.dataset.id,
                autofocus:document.querySelector('#buckets button')?.hasAttribute('autofocus'),
                cityOptions:[...document.querySelectorAll('#city option')].map(x=>x.value),
              }));
              assert.equal(result.pwned,undefined);
              assert.equal(result.bucketId,malicious);
              assert.equal(result.autofocus,false);
              assert.deepEqual(result.cityOptions,['Shanghai']);
              assert.deepEqual(errors,[]);
              await browser.close();
            })().catch(error=>{console.error(error.stack||error);process.exit(1)});
        """)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.js"
            path.write_text(script, encoding="utf-8")
            run = subprocess.run(
                [str(NODE), str(path)],
                cwd=ROOT,
                env=os.environ | {
                    "NODE_PATH": str(MODULES),
                    "BROWSER": self.chromium,
                    "HTML": HTML.as_uri(),
                },
                text=True,
                encoding="utf-8",
                capture_output=True,
                timeout=120,
                check=False,
            )
        self.assertEqual(run.returncode, 0, run.stderr)

    def test_legacy_v2_paper_is_not_requested_or_rendered(self) -> None:
        script = textwrap.dedent(r"""
            const {chromium}=require('playwright'),assert=require('node:assert/strict');
            (async()=>{
              const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER});
              const page=await browser.newPage({viewport:{width:1200,height:900}}),errors=[];
              page.on('pageerror',error=>errors.push(String(error)));
              await page.addInitScript(()=>{
                window.__paperCalls=0;
                window.pywebview={api:{
                  snapshot:async()=>({
                    now:'2026-08-16 06:00:00',services:{},markets:[],actuals:[],forecasts:[],validations:[]
                  }),
                  history:async()=>[],
                  depth:async()=>[],
                  paper_snapshot:async()=>{
                    window.__paperCalls++;
                    return {
                      ok:true,account:{cash:885.22,equity:885.22},positions:[],open_orders:[],fills:[]
                    };
                  },
                  d0_evidence_panel_v2:async()=>({ok:false,error:{code:'offline',message:'offline'}})
                }};
              });
              await page.goto(process.env.HTML);
              await page.evaluate(()=>window.dashboardInit({
                now:'2026-08-16 06:00:00',services:{},markets:[],actuals:[],forecasts:[],validations:[]
              }));
              await page.waitForTimeout(150);
              const result=await page.evaluate(()=>(
                {
                  paperCalls:window.__paperCalls,
                  paperPanel:document.querySelector('.panel.paper')!==null,
                  paperSummary:document.querySelector('#paper')!==null,
                  paperDetails:document.querySelector('#paperDetails')!==null,
                  bodyText:document.body.innerText,
                }
              ));
              assert.equal(result.paperCalls,0);
              assert.equal(result.paperPanel,false);
              assert.equal(result.paperSummary,false);
              assert.equal(result.paperDetails,false);
              assert.equal(result.bodyText.includes('自动模拟交易（本地纸面）'),false);
              assert.equal(result.bodyText.includes('本轮账户起点'),false);
              assert.equal(result.bodyText.includes('$885.22'),false);
              assert.deepEqual(errors,[]);
              await browser.close();
            })().catch(error=>{console.error(error.stack||error);process.exit(1)});
        """)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.js"
            path.write_text(script, encoding="utf-8")
            run = subprocess.run(
                [str(NODE), str(path)],
                cwd=ROOT,
                env=os.environ | {
                    "NODE_PATH": str(MODULES),
                    "BROWSER": self.chromium,
                    "HTML": HTML.as_uri(),
                },
                text=True,
                encoding="utf-8",
                capture_output=True,
                timeout=120,
                check=False,
            )
        self.assertEqual(run.returncode, 0, run.stderr)


if __name__ == "__main__":
    unittest.main()
