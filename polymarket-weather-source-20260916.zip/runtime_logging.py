"""Bounded, service-owned runtime logging.

Workers own their log files so Windows never has to rename a file held open by
the supervisor.  This keeps log retention independent from process lifetime.
"""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import re


DEFAULT_MAX_BYTES = 2 * 1024 * 1024
DEFAULT_BACKUP_COUNT = 5

SENSITIVE_ASSIGNMENT = re.compile(
    r"(?i)\b(private[_-]?key|funder[_-]?address|api[_-]?key|access[_-]?token|"
    r"refresh[_-]?token|authorization|password|secret)\b(\s*[:=]\s*)([^\s,;]+)"
)
BEARER_TOKEN = re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+")


def redact_sensitive_text(value: object) -> str:
    text = str(value)
    text = BEARER_TOKEN.sub("Bearer [REDACTED]", text)
    text = SENSITIVE_ASSIGNMENT.sub(lambda match: f"{match.group(1)}{match.group(2)}[REDACTED]", text)
    return text


class SensitiveDataFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            rendered = record.getMessage()
        except Exception:
            rendered = "log_format_error"
        record.msg = redact_sensitive_text(rendered)
        record.args = ()
        return True


def configure_runtime_logging(service: str, *, log_dir: Path | None = None,
                              max_bytes: int = DEFAULT_MAX_BYTES,
                              backup_count: int = DEFAULT_BACKUP_COUNT) -> Path:
    """Configure the root logger to a bounded file owned by ``service``.

    Deliberately no stderr handler is installed.  The supervisor sends worker
    stdio to ``DEVNULL`` after each worker has an explicit fatal-exception
    boundary, preventing a second unbounded copy of every log line.
    """
    if not service or any(part in service for part in ("/", "\\", "..")):
        raise ValueError("service must be a simple service name")
    if max_bytes <= 0 or backup_count < 1:
        raise ValueError("invalid log retention limits")

    root_dir = log_dir or (Path(__file__).resolve().parent / "data" / "runtime" / "logs")
    root_dir.mkdir(parents=True, exist_ok=True)
    path = root_dir / f"{service}.log"
    root = logging.getLogger()
    for handler in root.handlers[:]:
        root.removeHandler(handler)
        handler.close()
    handler = RotatingFileHandler(path, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8")
    handler.addFilter(SensitiveDataFilter())
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    root.addHandler(handler)
    root.setLevel(logging.INFO)
    logging.captureWarnings(True)
    return path
