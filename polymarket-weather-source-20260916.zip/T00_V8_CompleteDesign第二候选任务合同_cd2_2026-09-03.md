# V8 Complete Design第二候选任务合同｜cd2｜2026-09-03

## 1. 身份与边界

```text
TASK_ID=PWM-V8-CD2-001
CURRENT_STAGE=COMPLETE_DESIGN
BASELINE_BRANCH=codex/handoff-baseline-20260809
BASELINE_HEAD=13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
SOURCE_KERNEL=ak2
SOURCE_KERNEL_SHA256=e01d30534b8b1de77ac4c426d925dda222a0c772540fb09b6425d39fab11308d
SOURCE_CD1_SHA256=96f01d9f9639fb6f8fca5ada9188cdcd21aa29e68023f40e93a0c7aa06cce89a
CD1_FROZEN_UNCHANGED=YES
COMPLETE_DESIGN_CD2_AUTHORIZED=YES
IMPLEMENTATION_AUTHORIZED=NO
TEST_EXECUTION_AUTHORIZED=NO
GIT_WRITE_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
```

本候选只关闭cd1独立QA发现的6个去重根阻断。13个原Finding仅作为覆盖映射，不分别复制设计。

## 2. CD-01｜Canonical Hash Contract

```text
OBJECT=cd2 Candidate、Section与Derived Artifact的Canonical identity
CURRENT_AMBIGUITY=cd1缺少candidate hash唯一字节公式、section registry/hash和derived artifact registry
NORMATIVE_DECISION_REQUIRED=冻结单一HashV1 framing、CandidateCore、SectionCore、ArtifactCore、唯一Registry和反向消费字段
CLOSURE_CRITERIA=相同输入在两个合规实现中产生完全相同candidate/section/artifact hash；每个派生字段可定位到唯一Section
OUT_OF_SCOPE=生成器代码、实现测试、文件系统或部署验证
```

## 3. CD-02｜M001—M018 Metric Semantics

```text
OBJECT=逐城MetricRegistryV2及M001—M018
CURRENT_AMBIGUITY=M009/M010/M017范围、M005分箱、M017原因优先级、M018比较对象/hash仍有多种解释
NORMATIVE_DECISION_REQUIRED=冻结逐城分母、M005端点及聚合顺序、M017封闭原因优先级、M018基准与比较Payload
CLOSURE_CRITERIA=同一输入对每个指标只产生一个numerator/denominator/value/status；禁止跨城池化；M007完全继承ak2
OUT_OF_SCOPE=阈值选择、Backtest、盈利验证、实现测试或部署
```

## 4. CD-03｜Candidate Receipt / Slot / Effect Identity

```text
OBJECT=Decision、Invalidation、CurrentCandidateSlot、EffectManifest和OperationReceipt
CURRENT_AMBIGUITY=slot/pre/post/effect hash没有唯一编码/domain/公式；Decision和Invalidation唯一键未冻结
NORMATIVE_DECISION_REQUIRED=冻结对象Schema、唯一键、null语义、HashV1 domain、无自引用EffectManifest以及四分支恢复oracle
CLOSURE_CRITERIA=同一单城事务效果产生相同对象hash；每个恢复观察只进入一个分支；必要Invalidation唯一
OUT_OF_SCOPE=DDL/Trigger执行、SQLite实测、故障注入或部署
```

## 5. CD-04｜Error Model Conflict

```text
OBJECT=ak2冻结ErrorCode全集与Candidate恢复状态
CURRENT_AMBIGUITY=cd1新增E_OPERATION_OUTCOME_UNKNOWN同时声明不覆盖ak2全集
NORMATIVE_DECISION_REQUIRED=OUTCOME_UNKNOWN仅作为恢复状态；只能映射ak2现有ErrorCode和OutcomeClass
CLOSURE_CRITERIA=不新增、不删除、不改名任何ak2 ErrorCode，且四个恢复状态都有唯一处置
OUT_OF_SCOPE=Kernel修订；如果现有集合无法表达则UPSTREAM_DESIGN_CONFLICT=YES并停止该项
```

## 6. CD-05｜Lease / CAS State Contract

```text
OBJECT=LeaseState、CAS、fencing和Guardian/Worker恢复矩阵
CURRENT_AMBIGUITY=字段类型、identity绑定、EXPIRED语义及过期但child存在分支不唯一
NORMATIVE_DECISION_REQUIRED=冻结封闭Schema、null规则、HashV1 fence、持久状态、派生过期、CAS总规则和恢复结果
CLOSURE_CRITERIA=每个Lease状态与观察组合只有一个合法转换、等待或fail-closed结果
OUT_OF_SCOPE=进程API、故障注入、任务配置或部署
```

## 7. CD-06｜Breaker / PathPolicy Total Contract

```text
OBJECT=OperationalHealth、Breaker总函数与PathPolicy逻辑身份
CURRENT_AMBIGUITY=CAS loser、HALF_OPEN非retry结果和Guard优先级不唯一；PathPolicy枚举及hash不闭合
NORMATIVE_DECISION_REQUIRED=冻结Guard优先级和所有输入分支；冻结逻辑枚举、角色、target排序以及targets/policy hash
CLOSURE_CRITERIA=每个登记状态+输入只产生一个结果；相同PathPolicy产生同一hash
OUT_OF_SCOPE=精确物理URI、ACL现场验证、部署或实现测试
```

## 8. 路由与整合

```text
T01=CD-01和单一规范源整合约束
STRATEGY=CD-02
DATA=CD-01 identity与CD-03
BE=CD-04、CD-05、CD-06
QA=仅在cd2冻结后独立审查
```

任何岗位的输入如果新增ak2 ErrorCode、修改M007、定义物理部署URI或引入第二规范源，T00必须拒绝该部分而非合并。

## 9. 后续阶段保留

实际DDL、Trigger测试、故障注入、SQLite/文件系统实测、Backtest、盈利验证、部署URI、ACL现场验证和Runtime部署继续延期，不得用于使cd2通过或失败。

## 10. 停止点

形成单一机器可读cd2并冻结Manifest后，才调度QA。QA返回后停止；FAIL时不得自动创建cd3。
