# Polymarket天气项目当前问题台账

当前状态统一入口：`TASK_CONTRACT.md#current-execution-state`，须与用户当前明确指令一同读取。本台账按对象保存问题及历史处理事实，不是独立的运行授权源。下方带日期批次中的“当前”“停止”“授权”等文字属于对应批次时点；已完成批次不自动恢复执行，历史已关闭问题不因旧措辞重新开启。此次指令修订不改变任何策略阶段或实验结论。

版本：v1.9
建立日期：2026-08-27（中国时间）  
最近更新：2026-09-03（中国时间）
状态：ACTIVE（当前有效）  
维护者：T00  

## 1. 用途与边界

本文件只登记V3系统退役后仍然有效的问题、历史资产保护要求及后续处理顺序。

V3已于2026-08-30完成系统级退役。原V3第21—45步、AS-OF、动态Shadow、Paper、概率与研究、流动性与仓位、V3 Dashboard/API/前端、Guardian、计划任务以及PWM-CUR-001、002、004—008、020—028均不再属于当前问题台账，不得据其恢复旧V3。相关事故、测试、部署和验收事实由Git历史、日志、数据库、Evidence、checkpoint、manifest、Seal、journal和任务历史XML继续保存；从当前台账和工作树删除历史文档不等于改写Git历史或运行证据。

本文件不替代：

- `PROJECT_EXECUTION_PROTOCOL.md`中的执行方法；
- 当前进程、Git、状态文件、数据库和已封印证据；
- 用户对修改、清理、部署和外部操作的独立授权。

问题状态：

- `NOW`：当前运行事实已经触发，值得作为下一项独立处理；仍不代表已授权修改；
- `NEXT`：尚待处理；
- `WAITING_EXTERNAL`：等待正式外部接口；
- `WAITING_STAGE`：尚未到达需要处理的业务阶段；保持硬门禁，只有冻结的触发条件出现后才可重新授权处理；
- `MAINTENANCE_BACKLOG`：已证明存在维护价值或风险，但当前不阻断运行、未证明持续损失，可以延后；
- `PRESERVE`：历史资产，保留但不继续使用；
- `CLEANUP_CANDIDATE`：只有证明依赖和证据价值后才可申请清理；
- `RESOLVED`：已经结案，仅保留控制记录；
- `DO_NOT_TOUCH`：禁止修改、迁移、回填或删除。

任何条目开始处理前，必须读取`PROJECT_EXECUTION_PROTOCOL.md`、建立单问题任务卡并取得用户独立授权。登记问题不代表授权修复或清理。

## 2. 当前控制快照

- 正式分支：`codex/handoff-baseline-20260809`。
- 当前Git HEAD必须通过`git rev-parse HEAD`现场核对，不在台账中冻结易陈旧SHA。
- V3与郑州系统级退役已进入正式Git历史；V3不得恢复，郑州自2026-08-30起不得进入未来活动采集或Realtime订阅。
- 当前正式活动管理域为Collector、Realtime、METAR和Runtime Observer；2026-08-31实现前现场审计发现未纳管的`dashboard_live.py`父子进程，该漂移不代表Dashboard恢复，未经独立授权不得启停或处置。运行进程未完整自报模块SHA时继续标记`RUNNING_RELEASE_UNVERIFIED`。
- 真实交易、订单、资金和资格保持关闭。
- V8.1、R2、V8.2和V8.2-R1独立终审均为`FAIL`。2026-09-02 Architecture Kernel `ak2`身份保持冻结；独立QA最终裁决`K1—K6=PASS`、`TRUE_KERNEL_BLOCKERS=0`、`KERNEL_FINAL_VERDICT=PASS`。Complete Design `cd4`已冻结且独立QA最终裁决`COMPLETE_DESIGN_QA_VERDICT=PASS`、`COMPLETE_DESIGN_ACCEPTED=YES`、`TRUE_COMPLETE_DESIGN_BLOCKERS=0`。设计血缘审计确认的7组实现规划输入已由冻结`iic2`闭合并通过最终独立QA：`IMPLEMENTATION_INPUT_CLOSURE_COMPLETE=YES`、`TRUE_IMPLEMENTATION_INPUT_BLOCKERS=0`、`IMPLEMENTATION_PLANNING_READINESS=READY`；实现、测试、Git、部署、Shadow、Paper和Live权限仍全部关闭。
- 工作树除明确禁止处理的`backups/`外，应保持当前项目资产清晰；实际状态必须现场核对。

## 3. NOW｜当前最小处理候选

### PWM-V8.1-DESIGN-001｜V8.1设计完整性修复

- 状态：`RESOLVED`；V8.1候选正文、登记附录、候选Manifest和设计自检已完成，状态仅为`MODIFIED`，尚未独立终审或Git集成。
- 唯一目标：在不回写四份冻结V8文件的前提下，形成可机械闭环、可直接指导未来编码、离线验证、实际部署和现场执行的V8.1候选设计。
- 允许范围：新建V8.1正文、登记附录、候选Manifest和设计自检报告，并更新本轮五份控制文档；不得创建`strategy_v8/`实现。
- 强制不变量：上海、北京、广州从训练到恢复端到端独立；Strict AS-OF；只评价BUY YES；唯一策略公式为`E_conservative=P_LCB-C_executable`；07:00至16:00实时事件驱动；Shadow、Paper和真实交易保持关闭。
- 部署与执行要求：必须设计到正式路径、当前HP账户/SID发现、进程能力、ACL、网络、任务XML、启动顺序、预检、恢复、回滚、Observer和现场验收；只允许设计，不得现场执行。
- 当前停止点：已到达。独立终审、Git集成、实现、测试、部署或激活前必须重新取得用户独立授权。

### PWM-V8.1-AUDIT-001｜V8.1设计完整性独立终审

- 状态：`RESOLVED`；用户已授权并完成独立终审，最终裁决为`FAIL`。
- 唯一目标：独立复算V8.1候选身份，并逐项反证文件、API、对象、Schema、DDL、事务、错误、测试、逐城隔离、Strict AS-OF及实际部署执行合同。
- 关键结论：候选身份和机械计数PASS，但实际上游城市值、fee evidence、逐源AS-OF锚、概率算法、market/bucket/token身份、SYSTEM唯一writer、SYSTEM事件消费、Evidence运行状态、Schema/DDL、任务停止和资格配置生成链存在阻断。
- 审查证据：`T01_新动态策略端到端研究架构独立终审_v8.1_2026-09-01.md`。

### PWM-V8.1-REPAIR-002｜V8.1独立终审FAIL最小修复

- 状态：`RESOLVED`；用户已授权，R2任务合同、完整正文、最终登记附录、候选Manifest和作者16项关闭矩阵已完成；状态仅为设计候选`MODIFIED`。
- 唯一目标：按独立终审确定的顺序修复16项发现，形成新候选身份；不得改变已通过的核心业务不变量。
- 关键处置：显式城市映射；Collector未来condition/fee evidence；逐源AS-OF anchor/cursor；确定性逐城模型；正式market/bucket/YES token；Runtime Guardian唯一SYSTEM writer；SYSTEM逐城扇出；Evidence健康；writer lease；Schema/DDL/API/原因/测试；精确停止；双Manifest；资格配置批准链。
- 第二次终审：已完成，最终`FAIL`；审查证据为`T01_新动态策略端到端研究架构第二次独立终审_v8.1_r2_2026-09-01.md`。R2路径在此终止，不得继续R3局部补丁或进入实现。

### PWM-V8.2-DESIGN-001｜V8.2整版合并替代设计

- 状态：`COMPLETED/CANDIDATE_FROZEN_AWAITING_INDEPENDENT_AUDIT_AUTHORIZATION`；候选、作者自检和Manifest已完成。
- 唯一目标：在不继承V8.1/R2补丁语义的前提下，形成自包含、可唯一实现的V8.2完整设计候选。
- 允许范围：先更新五份控制文档；随后形成任务合同、真实上游Truth Table与Canonical Contract、完整架构、最终登记附录、Manifest和作者自检。
- 强制保留：单bucket BUY YES、V3保守净优势公式、07:00—16:00实时动态、Strict AS-OF、三城端到端独立、市场价格仅入成本、SYSTEM单writer、零网络和逐阶段授权。
- 唯一允许重构：Schema/DDL等价、模型时间与校准、单文件批准、完整book snapshot、单调游标、原因码和三个入口绝对停止。
- 明确禁止：创建实现、修改活动上游代码或数据库、运行候选测试、Git集成、部署、激活、Shadow、Paper或真实交易。
- 当前停止点：等待用户独立授权V8.2设计完整性终审；不得在该授权中夹带Git集成或实现。

### PWM-V8.2-AUDIT-001｜V8.2独立设计完整性终审

- 状态：`RESOLVED/FAIL`；候选身份和机械登记PASS，实施唯一性与部署完整性FAIL。
- 审查证据：`T01_新动态策略端到端研究架构独立终审_v8.2_2026-09-01.md`。
- 七个阻断：Schema范围冲突、字段/数值域不闭合、模型population与seed不唯一、Forecast A→B→A丢失、Book levels可变、Evidence同seq双payload、部署对象不逐字。

### PWM-V8.2-R1-DESIGN-001｜V8.2-R1受限整版替代设计

- 状态：`COMPLETED/CANDIDATE_FROZEN`；R1六份设计交付物和作者CE01-CE06自检已完成，后续独立终审已裁决FAIL。
- 唯一目标：只闭合V8.2终审七个阻断，形成完整自包含、无需回查V8.2的R1候选。
- 强制反例：A→B→A均有seq；同seq不同payload零写；同captured两盘口均可重放；负edge round-trip；模型黄金向量唯一；Config/Manifest/XML/ACL hash稳定。
- 禁止扩张：不新增城市、来源、模型家族、交易侧、账户、Shadow、Paper、真实交易或无关上游重构。
- 当前停止点：已到达；候选保持冻结，由下方独立终审FAIL裁决控制后续生命周期。

### PWM-V8.2-R1-AUDIT-001｜V8.2-R1设计完整性独立终审

- 状态：`RESOLVED/FAIL`；用户已授权并完成终审。
- 候选身份：五成员hash与设计集身份全部PASS。
- 内容裁决：15项实施级阻断，禁止设计Git集成、实现、部署或激活。
- 审查证据：`T01_新动态策略端到端研究架构独立终审_v8.2_r1_2026-09-01.md`，SHA256=`ee2b599d58b1b321197bb9e87b372992955264894ab244325c1b6bb55cfa5add`。
- 后续处置：R1 FAIL路线决策已于2026-09-02完成；R1继续冻结，不得创建R2或补丁。

### PWM-V8-R1-ROUTE-001｜R1 FAIL后路线决策

- 状态：`RESOLVED`；用户已授权并完成路线决策。
- 唯一裁决：禁止修改R1、追加补丁、立即完整R2或形成五套K1—K5候选；采用一个Architecture Kernel候选先审，PASS后再形成一个完整替代候选。
- 决策证据：`T00_V8.2_R1独立终审FAIL后续路线决策审查_2026-09-02.md`。

### PWM-V8-AK-001｜Architecture Kernel设计与首次独立审查

- 状态：`RESOLVED/FIRST_INDEPENDENT_AUDIT_FAIL`；候选身份PASS，架构内容FAIL。
- 唯一目标：以一个内核候选关闭R1终审B01—B15的规范根因，不展开完整未来代码设计。
- 交付物：任务合同、Kernel候选、作者CE-K01—CE-K15反例自检和Manifest。
- 独立审查：`T01_新动态策略ArchitectureKernel独立审查_2026-09-02.md`，SHA256=`df01190520cf687758b78e1082671d7d2e5eb855e210307b035ecf12963eea45`。
- 审查裁决：B03—B08中除B02外的六项收敛；B01、B02、B09—B15及新增N01—N06仍存在实施级歧义或直接矛盾。
- 当时停止点（历史）：等待用户独立授权唯一一次受限Kernel修订；该停止点已由下方`PWM-V8-AK-CLOSEOUT-001`的最终PASS推进，不再代表当前阶段。

### PWM-V8-AK-CLOSEOUT-001｜Architecture Kernel阶段关闭

- 状态：`RESOLVED/KERNEL_FINAL_PASS`；`ARCHITECTURE_KERNEL_STAGE_COMPLETE=YES`。
- 当前对象：冻结的`ak2`、ak2第二次独立审查、Kernel阶段重新分类、KG-01架构裁决及独立QA最终审查；本关闭记录不修改`ak2`或创建`ak3`。
- 最终裁决：`K1=PASS`、`K2=PASS`、`K3=PASS`、`K4=PASS`、`K5=PASS`、`K6=PASS`、`TRUE_KERNEL_BLOCKERS=0`、`KERNEL_FINAL_VERDICT=PASS`。
- KG-01：`ApprovedConfigSet`是按`config_set_hash`寻址的不可变历史对象；唯一可变权威`ActiveConfigPointer`指出`active_config_set_hash`；Runtime只能按`Pointer→hash→ApprovedConfigSet`选择当前配置。禁止目录顺序、mtime、最新文件或调用者任意hash；Pointer异常或身份无法确认时`FAIL_CLOSED`。具体Schema、格式、原子实现和恢复实现后移。
- Finding归属：`TOTAL_FINDINGS=31`；`DEFERRED_COMPLETE_DESIGN=13`；`DEFERRED_IMPLEMENTATION_TEST=4`；`DEFERRED_DEPLOYMENT_ACCEPTANCE=6`；`INVALID_FINDINGS=5`。后续阶段Finding不得继续作为Architecture Kernel blocker。
- 阶段门：只有`FINDING_VALID=YES`、`CURRENT_STAGE_REQUIRED=YES`且`CURRENT_STAGE_BLOCKER=YES`的Finding可以阻断当前阶段；旧“第二次Kernel审查存在实施级架构阻断→STOP_REDESIGN”规则不再具有当前效力。
- 权限状态：`COMPLETE_DESIGN_MAY_START=YES`，但`IMPLEMENTATION_AUTHORIZED=NO`、`TEST_EXECUTION_AUTHORIZED=NO`、`GIT_WRITE_AUTHORIZED=NO`、`DEPLOYMENT_AUTHORIZED=NO`、`SHADOW_AUTHORIZED=NO`、`PAPER_AUTHORIZED=NO`、`LIVE_TRADING_AUTHORIZED=NO`。
- 当前停止点：等待用户对Complete Design的下一次独立授权；不得自动开始设计、实现、测试、Git或部署。

### PWM-V8-CD4-CLOSEOUT-001｜Complete Design与Implementation Input Closure阶段关闭

- 状态：`RESOLVED/IIC2_FINAL_QA_PASS`；Complete Design `cd4`和Implementation Input Closure `iic2`均保持冻结，独立QA均已裁决`PASS`。
- 已证明：`COMPLETE_DESIGN_QA_VERDICT=PASS`、`COMPLETE_DESIGN_ACCEPTED=YES`、`TRUE_COMPLETE_DESIGN_BLOCKERS=0`。
- IIC2冻结身份：Candidate Hash=`fde2c34c6f8c01e68a176b6c577eead4d931c81ab4f4ea64b41875d4c9629c03`；唯一规范源SHA256=`22958942034314447067b0d01b124cc855b0207bf862f192ece48d6cfb4b3ff4`；Manifest SHA256=`0b2fc5d318ff05e3f5f83965cc0135ded84d79722fa6b66e42b0b0a46cb969c3`。
- IIC2最终QA：`IMPLEMENTATION_INPUT_CLOSURE_QA_VERDICT=PASS`、`TRUE_IMPLEMENTATION_INPUT_BLOCKERS=0`、`CAN_TWO_IMPLEMENTERS_STILL_DIVERGE=NO`；MISSING-01至MISSING-07均已有当前唯一规范归属。
- 当前门禁：`IMPLEMENTATION_INPUT_CLOSURE_COMPLETE=YES`、`IMPLEMENTATION_PLANNING_READINESS=READY`、`IMPLEMENTATION_AUTHORIZED=NO`、`TEST_EXECUTION_AUTHORIZED=NO`、`GIT_WRITE_AUTHORIZED=NO`、`DEPLOYMENT_AUTHORIZED=NO`、`SHADOW_AUTHORIZED=NO`、`PAPER_AUTHORIZED=NO`、`LIVE_TRADING_AUTHORIZED=NO`。
- 停止点：Implementation Input Closure控制面同步已完成；后续阶段状态由下方Implementation Planning台账继续记录。

### PWM-V8-IMPLEMENTATION-PLANNING-001｜Implementation Planning与首次授权范围

- 状态：`CURRENT_STAGE=IMPLEMENTATION_PLANNING`；`IMPLEMENTATION_PLAN_STATUS=READY`；`IMPLEMENTATION_PLAN_REFERENCE=IMPLEMENTATION_PLAN_V1`；`ACCEPTED_FOR_PLANNING=YES`；`IMPLEMENTATION_AUTHORIZATION_REQUEST_STATUS=READY`。
- 规划身份：`IMPLEMENTATION_PLAN_V1`是本控制面内嵌施工摘要对应的规划标识，不是仓库中的独立文件；规划READY不代表Implementation开始或完成。
- 首次候选范围：`WP-01`仅包含Canonical、Hash、Decimal、Time、Enum、ErrorCode/OutcomeClass；`WP-02-FOUNDATION`仅包含`schema_metadata`、`database_identity`、city/role隔离基础及repository identity validation；`VS-01-SKELETON`仅包含Request、Result、DependencySet及输入输出边界，且`VS01_SKELETON_ONLY=YES`、`VS01_EXECUTABLE=NO`。
- 首次候选范围不包括：业务表、Decision、ActiveConfig、Runtime状态、WP-03及以后策略实现、Probability Model、PAV、P_LCB、C_executable、delta Gate、ActiveConfig实现、Decision流程、Guardian/Worker、Deployment、Shadow、Paper、Live、Funds或Order execution。
- Baseline门：Implementation开始前必须现场只读复算并绑定Branch、HEAD、AGENTS hash、TASK_CONTRACT hash、CURRENT_ISSUES hash、ak2 hash、cd4规范源hash/Candidate Hash及IIC2规范源hash/Candidate Hash；任一必需身份不匹配即`IMPLEMENTATION_GATE=BLOCKED`。TASK_CONTRACT和CURRENT_ISSUES必须采用本次同步后的未来授权时现场hash，不得沿用同步前hash。
- 权限状态：`IMPLEMENTATION_AUTHORIZED=NO`、`TEST_EXECUTION_AUTHORIZED=NO`、`GIT_WRITE_AUTHORIZED=NO`、`DEPLOYMENT_AUTHORIZED=NO`、`SHADOW_AUTHORIZED=NO`、`PAPER_AUTHORIZED=NO`、`LIVE_TRADING_AUTHORIZED=NO`。
- 当前停止点：等待用户对上述精确首次范围签发独立Implementation授权；此前不得创建Implementation Thread、创建`strategy_v8/`、写代码、修改设计规范或ak2/cd4/IIC2、执行测试、Git写入、数据库操作或部署。

## 4. WAITING_EXTERNAL｜正式外部接口

### PWM-CUR-012｜source_scan_id

- 状态：`WAITING_EXTERNAL`。
- 目标：证明历史行情快照与正式market scan的精确绑定。
- 禁止替代：latest行情、人工说明或仅publication hash不得冒充缺失接口。

## 5. 未来真实资金阶段门

### PWM-CUR-017｜仓库遗留真实下单能力

- 状态：`WAITING_STAGE`；当前未进入真实资金或真实执行阶段，在任何未来真实资金讨论前必须处理。
- 最近已知事实：Git仍跟踪`bot.py`、`paper_trading.py`和`service_supervisor.py`；`bot.py`保留历史CLOB下单和密钥读取能力。实际依赖与可达性必须在任务开始时重新核对。
- 当前边界：没有证据证明真实下单路径正在运行或已经发生真实订单事故；真实交易、订单、资金和资格继续关闭。不能因文件存在推断已启用，也不能因当前未运行推断风险已经消失。
- 当前处理规则：现阶段不审查、不测试、不删除真实下单代码，不读取密钥，不连接交易接口，不发送订单，也不建设真实交易能力。
- 重新激活条件：讨论真实资金；配置钱包、私钥、API密钥或签名账户；将Paper、Shadow或研究信号接入真实执行；启停、恢复或部署`bot.py`、`paper_trading.py`或`service_supervisor.py`；新增或恢复CLOB下单依赖；启用订单、资格或真实交易开关；或者当前运行证据发现真实下单代码被计划任务、服务或进程加载。任一条件出现时，必须先建立独立只读可达性审查任务并取得用户授权。
- 未来完成目标：经独立授权实现物理隔离、构建级不可达或正式退役；本状态不预先选择方案。

## 6. DO_NOT_TOUCH｜禁止清理或回写

以下对象无论是否退役或失败，未经专门证据治理授权均不得修改、迁移、回填或删除：

- 正式历史Evidence日库；
- checkpoint、manifest、Seal、recorder_meta；
- 不完整日、冲突日、事故日和失败证据；
- Evidence archive；
- 历史V2 Paper账本；
- V3历史数据库、日志、journal和任务历史XML；
- 事故日志；
- 已退役城市的历史证据和Settlement身份；
- 未证明可替代的分支、工作树和未提交资产；
- `backups/`；
- 用户未跟踪研究文档。

“已退役”只表示不再进入当前运行和决策链，不表示可以销毁历史证据。

## 7. 固定处理顺序

1. Architecture Kernel阶段已经结束；不得修改`ak2`、创建`ak3`或继续以后续阶段Finding返修Kernel。
2. Complete Design `cd4`已经独立QA PASS并关闭；不得修改`cd1`—`cd4`或创建`cd5`。
3. MISSING-01至MISSING-07已经由`iic2`闭合并通过独立QA；Implementation Planning已获得用户授权并完成规划及首次候选范围登记，但`IMPLEMENTATION_AUTHORIZED=NO`。
4. 下一步唯一允许动作是用户对`WP-01 + WP-02-FOUNDATION + VS-01-SKELETON`精确范围签发独立Implementation授权；不得把授权请求或范围READY当成已授权。
5. Implementation Test、Git集成、部署、激活、Shadow、Paper和真实交易均保持各自独立授权门，不得由Kernel、Complete Design、Implementation Input Closure或Implementation Planning自动推出。
6. PWM-CUR-012继续等待正式外部接口，不以内部推断替代。
7. PWM-CUR-017保持`WAITING_STAGE`并移出当前执行顺序；它仍是任何未来真实资金讨论前的强制前置门。
8. 第6节对象持续保留，不进入常规清理；任何prune、删除、移动、恢复、合并或提交均须独立授权。

上述顺序如需改变，T00必须先报告事实、影响和建议，并取得用户明确授权。

## 8. 更新规则

- 新问题必须有新证据，不得仅凭对话猜测登记为故障。
- 问题解决后可以保留简短结案记录；已退役系统的专属待办不留在当前问题台账中。
- 删除当前台账条目不得删除Git历史、专项归档、日志、数据库或Evidence。
- 每次T00接管、部署、重大事故或系统退役后，应先核对本台账，再决定下一项。

## 9. RESOLVED｜2026-09-01 Collector跨日市场Universe阻断

- 现场现象：Asia/Shanghai跨入2026-09-01后，看板市场列表为空；实况数据实际有效，但前端因没有当前市场显示“实况接口契约异常”。
- 根因：Research最新已接纳Manifest保留165个成员，其中包含已退役郑州的11个市场；Realtime对同一Manifest生成154个有效订阅，但Collector仍将原始165成员与Realtime有效154订阅直接比较，触发`publication_current_count_mismatch`并拒绝后续市场发布。
- 修复：提交`a1f4b564de8faaf3812f7126d373280673ae21d3`仅修改`collector.py`和`test_research_market_attribution.py`；原始成员数相等时保持原门，只有v1允许使用活动城市视图计数，legacy继续严格要求原始数量一致。
- 离线证据：Collector、Manifest和Realtime相关回归合计`163/163 PASS`；独立QA最终`PASS`，未放宽Manifest哈希、城市身份、candidate或approval门。
- 部署事实：仅重启正式任务`\PolymarketWeather\PW-CollectorGuardian`；新进程链为Guardian PID `9460`至Worker PID `14484`。Realtime、METAR和Runtime Observer未重启。
- 数据验收：Collector启动全量刷新14个事件并发布154个YES市场；新Universe哈希为`6e022f3393609f95083bff4b7736276ccab7c07b194d99200cd64fbf84055eb4`，覆盖7城，2026-09-01和2026-09-02各77个市场；Realtime记录`universe_changed`并接纳154个token。
- 现场验收：只读看板快照返回`error=null`、`markets=154`、`actuals=7`；用户于2026-09-01 01:39（Asia/Shanghai）提供页面截图确认市场、METAR、温度曲线、订单簿、行情流和采集器恢复正常。本事故状态为`RESOLVED`。
- 安全边界：真实交易、订单、资金和资格始终保持关闭；未手工修改数据库、Evidence、checkpoint、Seal或历史Manifest。运行进程未自报完整Release、Manifest及依赖哈希，继续标记`RUNNING_RELEASE_UNVERIFIED`。
- 未并入本次修复：`ui/live.html`在未来再次出现零市场时仍可能把“没有当前市场”误报为“实况接口契约异常”；该前端语义缺陷需另建单问题任务并取得独立授权。

## 10. WP03研究验证当前批次（2026-09-05）

本节是当前问题队列；上方Implementation Planning等待项是历史阶段记录，不再反向禁止本次已经由用户明确授权并完成的限定Research Pilot。未在本批授权中的模型、回测、采集启用及生产操作仍保持关闭。

### WP03-RESEARCH-WEATHER-PILOT-001｜上海天气轨工程Pilot

- 状态：`RESOLVED/PASS_RESEARCH_LEVEL`。
- 结果：Research Dataset V1的12/12日期进入研究天气输入链；长期QA独立复算身份并重跑11/11限定测试通过。
- 范围：只证明数据解析、08:00研究AS-OF、ZSPD、D+2标签、失败状态保留、无市场污染、确定性和样本不足拒绝路径。
- 未证明：严格IIC2 revision/committed_at身份、模型预测能力、PAV/P_LCB、Decision、Edge、盈利或生产集成。
- 证据：`data/strategy_analysis/wp03_weather_pipeline_validation_v1/20260905T043612+0800/WEATHER_PIPELINE_ENGINEERING_PILOT_REPORT.md`。

### WP03-HISTORICAL-EDGE-001｜34日历史Edge可行性

- 状态：`RESOLVED/UNUSABLE_HISTORICAL_SAMPLE`。
- 结论：冻结参数和34日母集保持不变，`EDGE_ELIGIBLE_DAY_COUNT=0`。2026-08-24的11条历史深度引用均不满足08:00前60秒完整frame规则；Stage0.5的11/11与Stage0.6B的0/0属于不同筛选口径。
- 证据限制：Stage0.6B完整Manifest载荷在非备份仓库中未定位；`WEATHER_MISSING=14`、`WEATHER_UNPROVABLE=8`保留为冻结报告计数，不声明本轮独立复算。
- 证据：`data/strategy_analysis/wp03_weather_pipeline_validation_v1/20260905T043612+0800/HISTORICAL_EDGE_DATA_CLOSURE_NOTE.md`。

### WP03-FORWARD-EDGE-COLLECTION-001｜前瞻Edge采集

- 状态：`NEXT/AUTHORIZATION_REQUIRED`。
- 当前阻断：采集器最多保存每侧前5档，缺不可变完整frame身份和原始payload绑定，BBO/深度最低保留仅6小时，实际运行Release、权限及08:00前60秒完整率未验证。
- 当前动作：仅形成启用清单；未改采集器、配置、保留策略、服务或计划任务。
- 证据：`data/strategy_analysis/wp03_weather_pipeline_validation_v1/20260905T043612+0800/FORWARD_EDGE_COLLECTION_ACTIVATION_CHECKLIST.md`。

### 延期项

- `P1`：Research Dataset未证明IIC2最高forecast revision与完整`committed_at`链；进入确认性研究或生产数据链前处理。
- `P2`：完整E3、历史Harness、Evidence transport、payload recovery和机构级审计基础设施继续延期。
- 前瞻Edge采集、模型/PAV/P_LCB/Decision/Backtest均未自动开始。

---

## 11. WP03 Stage1 weather-model validation transition (2026-09-05)

This is the current authoritative WP03 entry. Older Implementation Planning text above is retained historical control context and does not supersede this user-authorized research-stage transition.

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_PHASE=WP03_STAGE1_WEATHER_MODEL_VALIDATION
FORWARD_COLLECTOR_OFFLINE_STATUS=COMPLETE_FOR_RESEARCH_CANDIDATE
LIVE_CAPTURE_EXECUTED=NO
FORWARD_COLLECTION_RUNNING=NO
MODEL_EXECUTION_AUTHORIZED=NO
BACKTEST_AUTHORIZED=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
IMPLEMENTATION_ACCEPTED=NO
```

### WP03-TEST-ENVIRONMENT-001 — standard test environment governance

- Status: `RESOLVED/CONTROL_SYNCHRONIZED`.
- Standard: every writing test declares its runtime root, virtual/test environment, Python executable and version, and Codex workspace permission mode; it verifies `CREATE/WRITE/READ/DELETE` before fixture execution and retains environment/dependency identity, command, output, and exit code.
- Boundary: `WORKSPACE_WRITE` is the normal project test permission. `READ_ONLY` blocks writing tests. `FULL_ACCESS` is not implied and needs separate current user authorization.

### WP03-FORWARD-COLLECTOR-OFFLINE-001 — limited research-candidate closeout

- Status: `COMPLETE_FOR_RESEARCH_CANDIDATE` only.
- Completed scope: offline frame save/reload, raw hash, market/token identity handling, fail-close handling, FEC-02 full YES ask-ladder semantics, and current-workspace fixture-isolation regression (`9/9 PASS`).
- Evidence limitation: `QA_INDEPENDENT_EXECUTION=BLOCKED_BY_QA_SANDBOX_FILESYSTEM_PERMISSION`; `QA_INDEPENDENT_REPRODUCTION=NOT_ESTABLISHED`; `UNCONDITIONAL_QA_ACCEPTANCE=NO`.
- Not completed: live API compatibility, real capture, continuous collection, service deployment, long-term storage, production ACL, online runtime, and FEC-01..08 productionization. They remain outside this batch.

### WP03-STAGE1-WEATHER-MODEL-001 — protocol preparation

- Status: `CURRENT/PROTOCOL_ONLY`.
- Purpose: prepare the research-only Shanghai weather-model validation protocol using Shanghai Research Dataset V1. The protocol may define input validation, feature construction, chronological train/validation treatment, baseline comparison, and prediction metrics; it does not authorize execution.
- Boundary: Edge, return/profit analysis, real trading, Decision execution, final PAV effectiveness, P_LCB coverage, model execution, tuning, and backtesting remain prohibited until separately authorized.

---

## 12. Current forward blind accumulation V1 — 2026-09-05

Authority: `T00_FREEZE_WEATHER_CANDIDATE_AND_START_FORWARD_BLIND_ACCUMULATION_V1`. This is the current narrowly scoped research entry. Older Implementation Planning and protocol-only/no-capture statements above are historical and do not override this new instruction.

- `EARLY_SIGNAL=POSITIVE` is the existing 25-mature-day/23-score/zero-computation-failure exploratory result, not confirmatory proof.
- `WEATHER_CANDIDATE_FREEZE_V1` freezes current model/feature/residual/baseline/08:00/52-bucket/training/D+2/Brier/MAE identities. Research quantization remains `STAGE1A_LARGEST_REMAINDER_E12_V1`; explicit forward research scope does not change the original IIC2 or production policy.
- `FORWARD_BLIND_ACCUMULATION`: new immutable pre-label predictions and separate mature labels/scores; `FORWARD_BLIND_SCORING_DAYS_AT_ACTIVATION=0`, `EXPLORATORY_SCORING_DAYS=23`. Preserve failures and never tune from checkpoint results.
- `RESEARCH_FORWARD_MARKET_COLLECTION`: public raw-data reads authorized, full actual event membership and full YES asks, five-share quantity/60-second freshness unchanged. No Edge verdict, Decision or trading.
- `FORWARD_COLLECTION_RUNNING=NO`; `PERSISTENT_EXECUTION_AVAILABLE=NO`. No daily trigger was established. A timely manual/external invocation and available weather-source records are operational prerequisites; no task scheduler, service or startup changes were made. First conditional eligible target is 2026-09-06.
- `CURRENT_PHASE=WP03_FORWARD_WEATHER_BLIND_ACCUMULATION_V1`; `PREDICTIVE_SKILL_PROVEN=NO`; `POSITIVE_EDGE_PROVEN=NO`; `PROFITABILITY_PROVEN=NO`; `IMPLEMENTATION_ACCEPTED=NO`; `PRODUCTION_READY=NO`.

Evidence and exact operational status: `data/strategy_analysis/wp03_forward_blind_accumulation_v1/20260905T184548+0800/WP03_FORWARD_BLIND_ACCUMULATION_ACTIVATION_REPORT_V1.md`. Do not infer a live capture or independent test pass from source-file existence.

### Remaining runtime and deferred boundaries

- Actual source availability, API compatibility, complete target event publication, anchor-time capture and liquidity require a real future invocation. Unverified is not PASS; a missing external trigger is not a reason to rebuild a collector platform.
- Existing research source-time limitations (including unproven highest IIC2 revision / strict committed_at chain) remain explicit; O_t keeps the existing nonempty-observation research rule, not a newly invented coverage gate.
- Full E3/transport/payload recovery, production WORM/ACL, release/service identity and long-term operational acceptance remain deferred. No model changes, productionization, database writes, deployment, Paper/Live, orders/wallets/funds or Git writes are authorized.
- Development execution-count deviations and all failed attempts are retained in the current run's `governance_notes.md` and `data_tests`; do not replace their history with the final passing run.

## 13. Multi-city strategy validation V1 — 2026-09-05 partial closeout

Authority: `T00_MULTI_CITY_BEIJING_GUANGZHOU_EXPANSION_AND_FAST_VALIDATION_V1`.
`CURRENT_PHASE=MULTI_CITY_STRATEGY_VALIDATION_V1`; `BATCH_RESULT=PARTIAL_BLOCKED`.
Shanghai frozen history/protocol/model remains unchanged; Beijing/ZBAA and Guangzhou/ZGGG are independent TAF/METAR research candidates, not validated city models.

Current-stage blockers (all P1, CURRENT_STAGE_REQUIRED=YES, CURRENT_STAGE_BLOCKER=YES, DEFERRED_TO=NONE):

- P1-MC-01: `tools/research_multi_city_v1/population.py` accepts naive timestamps through host-local conversion; historical AS-OF interpretation is not fail-closed.
- P1-MC-02: that builder's candidate union omits observation-only dates. Intermediate population is not the maximum mechanically retained population; Evidence payload recovery has not completed with a valid execution result.
- P1-MC-03: `tools/research_multi_city_v1/model.py` drops AVAILABLE-but-missing-label rows from computation-failure accounting. It must not produce a positive claim from that malformed input.
- P1-MC-04: `tools/research_multi_city_v1/run_all_cities.py` calls undefined `_utc_text`; success/error paths fail with NameError and can leave log handles open, causing secondary WinError32 teardown errors. This is not a permission failure.

Validation gap: two pytest-style population functions were not executed by unittest; pytest is absent and was not installed. Independent combined result is 18 executed, 16 passed, 2 error cases / 4 error events, exit 1. Initial automated counters miscounted warning/teardown lines; raw unittest output and the separate QA correction are authoritative. Preserve the original counters as history.

The intermediate 42-date/24-AVAILABLE claims per city are PROVISIONAL, NOT_FROZEN. Both historical Fast Signals are NOT_EXECUTED, EARLY_SIGNAL=INCONCLUSIVE, and CROSS_CITY_SIGNAL=INSUFFICIENT_EVIDENCE. All three blind counts remain 0; forward/market setup is PARTIAL, not activated. One bounded correction cycle has stopped; no extra repair or real scoring is automatically authorized by this finding list.

Full E3, production audit/ACL/retention hardening, deployment and trading remain deferred/prohibited as previously recorded. Source databases, existing services, Shanghai V1, IIC2 and original datasets were not changed by this task. Run evidence: `data/strategy_analysis/wp03_multi_city_validation_v1/20260905T194807+0800/`.

## Formal dynamic window alignment — 2026-09-05

Final batch outcome: `PARTIAL_BLOCKED`. Independent synthetic suite: 53 discovered/executed/passed, 0 failures/errors/skips, exit 0 after the explicit QA-root/import-entry correction. This does not close the real Shanghai producer/consumer mismatch: frozen `daily.py` omits top-level city/station/execution_mode, while the updated `run_three_city_forward_v1.py` counter requires them. `P1-SHANGHAI-COUNTER-SCHEMA-INCOMPATIBILITY` is current-stage required and blocking. Preserve Shanghai V1; no further repair or capture performed. Targeted score-hash binding and corrupt/claim/missing-field retention tests passed, but `QA_ACCEPTANCE=BLOCKED_BY_SHANGHAI_SCHEMA`. Full evidence and stop status: `FORMAL_DYNAMIC_WINDOW_ALIGNMENT_AND_FORWARD_REPAIR_REPORT_V1.md` in the run below.

Authority: `T00_FORMAL_DYNAMIC_WINDOW_ALIGNMENT_AND_FORWARD_REPAIR_V1`. This is an append-only governance classification, not a rerun or amendment of any historical experiment or frozen candidate.

```text
FORMAL_STRATEGY_WINDOW=[07:00,16:00) Asia/Shanghai
FORMAL_STRATEGY_START=07:00
FORMAL_STRATEGY_END=16:00_EXCLUSIVE
FORMAL_AS_OF=t_ACTUAL_DECISION_TIME
FIXED_RESEARCH_BENCHMARK_ANCHOR=08:00 Asia/Shanghai
FIXED_BENCHMARK_CLASSIFICATION=FIXED_0800_RESEARCH_BENCHMARK_V1
FORMAL_DYNAMIC_OBJECT=FORMAL_DYNAMIC_ASOF_STRATEGY_V1
DYNAMIC_REEVALUATION_TRIGGER=UNRESOLVED_EVENT_TO_WEATHER_EVALUATION_MAPPING
FORMAL_DYNAMIC_FORWARD_READY=NO
REAL_CAPTURE_EXECUTED=NO
FORWARD_COLLECTION_RUNNING=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
PRODUCTION_READY=NO
```

IIC2 `shared_contracts.dynamic_window`, AK2 §2/§7 and the original control window agree on [07:00,16:00). Facts used at t must be visible no later than t, including the formal effective/observed/committed AS-OF predicates; source available/received times must never be bypassed with a later fact. Forecast-revision selection and historical training identity remain city/local-second specific. The fixed 08:00 benchmark cannot replace the full dynamic window or its time-specific training inputs.

AK2 §7 already freezes five event cause types, event identity/deduplication, and 30-second safety rechecks. With no new cause object/state change, such a recheck updates health only: no event, Decision or model call. It is not a model polling cadence. The remaining unresolved mapping is which cause/transition requires weather probability recomputation versus only market-side processing/invalidation; the associated scope window-ID derivation is not mechanically closed. Stop dynamic-runner implementation at this point; do not invent a 1/5/30-minute schedule or reopen frozen IIC2.

Shanghai, Beijing and Guangzhou V1 candidate files, populations, research quantization, predictions and historical results remain unchanged. Their POSITIVE signals (23/22/22 exploratory scoring days) and CONSISTENT_POSITIVE cross-city result belong to FIXED_0800_RESEARCH_BENCHMARK_V1, not confirmation of the whole dynamic strategy. Preserve the 08:00 benchmark for a future separately authorized dynamic comparison; no dynamic value-add is yet measured. Earlier provisional/blocked batch entries above remain historical records, not the latest three-city result.

This batch only aligns governance and repairs the existing benchmark runner's evidence counters and QA environment. Its 07:58-to-08:00 entry is not a formal dynamic strategy entry. No real capture, Decision, Edge, model tuning, production policy change, service, source-DB write or trading is authorized here. Evidence: `data/strategy_analysis/wp03_formal_dynamic_window_alignment_forward_repair_v1/20260905T225723+0800/`; read `time_authority_clarification.json` together with the initial time review, whose AS-OF/deduplication ambiguity claims are explicitly corrected.

## Current Master Critical Path — M1 closeout, 2026-09-06

Authority: `T00_M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT_V1`. This is the sole current master milestone and supersedes older current-state/authorization entries above, without changing historical reports, candidate freezes, IIC2, AK2 or CD4.

```text
CURRENT_PROJECT_OBJECTIVE=STRATEGY_VALIDATION
CURRENT_MASTER_MILESTONE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
CURRENT_MILESTONE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
CURRENT_PHASE=M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT
FORMAL_STRATEGY_WINDOW=[07:00,16:00) Asia/Shanghai
ASOF_MODE=ACTUAL_DECISION_TIME
EVENT_ACTION_MAPPING_FROZEN=YES
DYNAMIC_REEVALUATION_TRIGGER=EVENT_DRIVEN
PERIODIC_MODEL_RECOMPUTE=NO
FIXED_BENCHMARK=FIXED_0800_RESEARCH_BENCHMARK_V1
SHANGHAI_EARLY_SIGNAL=POSITIVE
BEIJING_EARLY_SIGNAL=POSITIVE
GUANGZHOU_EARLY_SIGNAL=POSITIVE
CROSS_CITY_SIGNAL=CONSISTENT_POSITIVE
EXISTING_EVIDENCE_SUFFICIENT_FOR_M1=NO
STOP_HISTORICAL_DYNAMIC_REPLAY=YES
FORWARD_SOURCEFACT_CAPTURE_REQUIRED=YES
QA_STATUS=PASS_92_OF_92_SYNTHETIC_RELATED_REGRESSION
LEGAL_DYNAMIC_WEATHER_SNAPSHOT_COUNT=0
M1_STATUS=BLOCKED_NEEDS_FORWARD_SOURCEFACT
FORMAL_DYNAMIC_FORWARD_READY=NO
REAL_CAPTURE_EXECUTED=NO
FORWARD_COLLECTION_RUNNING=NO
MODEL_TUNING_AUTHORIZED=NO
RESEARCH_LIVE_DATA_CAPTURE_AUTHORIZED_THIS_BATCH=NO
PREDICTIVE_SKILL_PROVEN=NO
POSITIVE_EDGE_PROVEN=NO
PROFITABILITY_PROVEN=NO
IMPLEMENTATION_ACCEPTED=NO
PRODUCTION_READY=NO
```

The user-fixed master path is M1 first legal dynamic weather snapshot -> M2 weather/market forward -> M3 time alignment/executable Edge -> M4 PAV/P_LCB/risk/Decision Shadow -> M5 forward strategy validation -> M6 production hardening. Only M1 is currently actionable; no automatic M2 entry or network/service/trading authorization follows from QA.

M1 engineering changes: source-specific mandatory effective/observed/committed validation, conditional received/available constraints, distinct WeatherLabel commit/maturity handling; actual evaluator trigger-fact membership/type/city/date/hash/time binding; saved snapshot verification before new events; append-only claim processing and terminal evidence distinguishing completed from interrupted attempts; explicit replay failure classes and actual saved-source snapshot requirement. These passed focused 21-case regression and independent related 92-case QA. They do not prove a real legal SourceFact or snapshot. An initial focused run had 20 passes and one fixture-URI guard environment error; only the test execution wrapper was corrected, and the failed log is retained.

The single bounded evidence review is closed. Existing inspected forecast/raw-payload associations, formal source commit visibility and mature label evidence cannot establish one legal dynamic snapshot; do not continue historical scans/recovery or substitute first_seen/received/mtime/frozen_at for committed time. Preserve all old 08:00 populations/results and the research-only quantization exception. No historical dynamic replay or benchmark rerun was executed in this M1 batch.

Finding routing is now mandatory:
- BLOCK_M1_NOW: absent provable source/revision/commit and mature city-local training evidence.
- FIX_BEFORE_M2: market duplicate-payload metadata identity; WeatherOL and TAF each need a legal source-path proof before their M2 use.
- FIX_BEFORE_BLIND_CONCLUSION: full blind counter scoring eligibility.
- DEFER_TO_PRODUCTION: production ACL/retention/release hardening and full E3.
- DOCUMENT_ONLY: preserved exploratory results and resolved historical failures.

CURRENT_UNIQUE_NEXT_CRITICAL_ACTION=separately authorize the minimum real forward SourceFact capture for M1, including genuine source/observed/commit identities and D+2 training-label evidence. No market capture, Edge, Cost, PAV, P_LCB, Decision, Shadow/Paper/Live, services, orders, wallets/funds, Production or Git writes. The active-observation SHM mtime changed during DATA reads while recorded bytes/SHA remained equal; attribution is unverified and no source SQL write is claimed.

Evidence root: `data/strategy_analysis/wp03_m1_first_legal_dynamic_weather_snapshot_v1/20260906T021642+0800/`; timestamp matrix and bounded review under `data_review/`, independent QA under `qa_review/`, final report `M1_FIRST_LEGAL_DYNAMIC_WEATHER_SNAPSHOT_REPORT_V1.md`. Completed batch; stop.

## 维护待办登记 — 2026-09-10

### PWM-METAR-WORKER-PROGRESS-001｜METAR缺少独立worker进度文件

- 登记授权：用户要求“把这个问题先记录到台账当中”；本次仅登记，不授权修复、测试、部署或重启。
- 状态：`MAINTENANCE_BACKLOG`（维护待办）；级别：`P2`（运行监控与容错风险）。`FINDING_VALID=YES`；`CURRENT_STAGE_REQUIRED=NO`；`CURRENT_STAGE_BLOCKER=NO`；`DEFERRED_TO=运行维护或生产加固阶段`；允许延期，不插入当前策略主线。
- 任务目标及影响：保留已核对的监控缺口与后续处理条件；本条不改变项目目标、当前里程碑、冻结验收标准或既有运行授权。
- 对象：`data/runtime/services/metar_collector.worker.json`，即业务进程应发布的独立进度文件；它不同于守护程序正常更新的 `metar_collector.json`，也不是METAR观测数据文件。
- 证据时点：2026-09-09 21:44:58（Asia/Shanghai）的现场状态记录为 `state=healthy`、`worker_pid=11260`、`guardian_pid=8924`、`heartbeat_age_seconds=4.2`、`worker_progress_reason=worker_progress_missing`、`restart_count_window=0`。同日用户确认看板METAR正常；日志21:07:49新增7条、21:35:28新增3条、21:49:05采集成功。上述为已读取的历史时点，9月10日本次登记未重新核验运行状态。
- 当前源码证据：`service_guardian.py` 的 `worker_status_path` 指向该文件；`read_worker_progress()` 在文件不存在时返回 `worker_progress_missing`，并校验存在文件的服务、当前PID和时间。已检查的 `metar_collector.py` 会写观测、站点状态及数据库心跳，未发现发布独立worker进度文件的逻辑。因此更支持“尚未提供独立进度通道”，不认定文件曾存在后丢失，缺失起始时间未证明。
- 正常情况影响：采集与入库逻辑不依赖该文件；数据库心跳正常时，缺文件不会单独触发重启。现有证据不支持METAR持续停采、观测缺失或看板异常，也不构成逐城历史完整性验收。
- 条件性风险：守护程序超过45秒启动宽限后，若数据库心跳不可读且没有有效worker进度，会返回 `heartbeat_missing`；若心跳年龄超过150秒且没有有效worker进度，会返回 `heartbeat_stale`，两者均进入重启流程。缺少该文件会减少一条独立于SQLite、绑定当前PID的活跃证据，增加数据库暂时不可读或心跳延迟时不必要重启的可能性。重复异常可能触及10分钟窗口第6次重启记录的熔断限制；本条不声称该后果已经发生。
- 历史归因限制：`data/runtime/logs/metar_collector_guardian.log` 中9月5日存在连续 `heartbeat_stale` 重启记录，但尚未证明由本文件缺失导致；不得将其写为本问题已造成的事故。运行进程实际加载版本未完整自证，源码行为分析不等于运行Release验收。
- 数据影响边界：文件缺失本身不删除或阻止保存观测。若实际发生长时间停采，才可能影响及时性和覆盖；代码每次查询过去6小时不能保证完整恢复，也不能把后来收到的报告当作当时已可见。14天滚动保留属于另一规则，不归因于本文件缺失。
- 后续处理条件：在安排运行维护/生产加固时评估；若出现可验证的错误重启、持续停采或样本损失，先核对因果关系与当前影响，再重新分类。修复前核对最新源码和运行身份，由后端/实现负责最小候选、QA独立验证；不能通过创建空文件或复制旧状态文件关闭问题。
- 未来关闭依据：当前进程可持续发布合法进度，守护程序正确区分正常心跳、数据库心跳不可读/陈旧但进程有进展、真实卡死、旧PID及无效/陈旧进度；采集语义保持正确。实际部署及现场确认按对应任务授权执行。本次无代码修改、业务测试、数据库访问、服务变更或Git提交。
- 证据入口：`service_guardian.py` 的 `SERVICE_SPECS`、`read_heartbeat()`、`read_worker_progress()`、`_reason()`、`_record_restart()`；`metar_collector.py` 的 `run_cycle()`、`fetch_reports()`；`data/runtime/services/metar_collector.json`；`data/runtime/logs/metar_collector.log`；`data/runtime/logs/metar_collector_guardian.log`。状态与日志为持续更新文件，以上历史摘录来自本T00任务2026-09-09只读核查工具输出，不声称已封印独立现场快照。
