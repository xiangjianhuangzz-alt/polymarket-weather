# T00｜新动态策略Architecture Kernel设计作者自检｜2026-09-02

状态：`AUTHOR_SELFCHECK_PASS_CANDIDATE_FROZEN_AWAITING_INDEPENDENT_AUDIT`

性质：作者级设计反例检查；不是独立审查、实现测试、SQLite执行验证、部署验证或组织验收

## 1. 自检对象

```text
任务合同：T00_V8_ArchitectureKernel任务合同_2026-09-02.md
任务合同SHA256：6739d6eec891679d084042b3f683d93605f0e12a95d338a401b94b2c350e208e

候选：T00_新动态策略ArchitectureKernel设计候选_2026-09-02.md
候选ID：T00-weather-strategy-architecture-kernel/ak1
候选Schema：architecture-kernel.v1
候选SHA256：b0ccc9d82e8c8bfec06836abaf6914a4c4c7fbcf932a59fb9ce54140d7485988

源路线裁决：T00_V8.2_R1独立终审FAIL后续路线决策审查_2026-09-02.md
源路线裁决SHA256：1f7e6bd451a6f1b9c9e335cbc83805268198afd95fde0ec2227489a95686d721

Git baseline：codex/handoff-baseline-20260809@13ca49c39ffe6cff4a75c23c3233af7cbd6cfaac
AS_OF：2026-09-02 Asia/Shanghai
```

本自检只判断候选正文是否为B01—B15分别给出唯一、失败关闭、可在完整替代设计中机械展开的规范约束。候选尚无JSON Schema、DDL、Python、XML、ACL脚本或真实文件系统实现，因此不能把设计反例的预期拒绝写成“已执行拒绝”。

## 2. 机械完整性检查

| 检查 | 结果 | 证据 |
|---|---|---|
| B01—B15是否连续且各有关闭规则 | PASS | 候选第10节矩阵恰有15项 |
| CE-K01—CE-K15是否一一对应 | PASS | 每个B项映射一个同号CE项 |
| 是否保留旧F/O/TX位置号为规范ID | PASS | 候选明确禁止位置号作为规范引用 |
| 是否存在第二套批准权威 | PASS | 仅`ApprovedConfigSet`最终文件；Registry只读 |
| 是否声称已实现或已部署 | PASS | 候选明确列为未证明边界 |
| 是否越界恢复Shadow、Paper、Live或资金 | PASS | 全部继续关闭且不属于Kernel |

这里的`PASS`仅表示文本结构满足本轮作者检查项，不代表对应未来实现已经通过。

## 3. CE-K01—CE-K15反例自检

| CE | 恶意或失败输入 | Kernel要求的结果 | 规范依据 | 作者结论 |
|---|---|---|---|---|
| CE-K01 | 两个文件都宣称拥有同一规则，或生成物出现Registry未登记字段 | Registry双向检查拒绝；生成/验收失败关闭 | 单一Canonical Registry、单owner、NORMATIVE/DERIVED规则 | DESIGN_PASS |
| CE-K02 | `ApprovedConfigSet`已存在，但任一城市Registry还需要写批准记录 | 不允许该架构；批准能力没有Registry写权限 | 单文件唯一批准提交点 | DESIGN_PASS |
| CE-K03 | 三Registry处于WAL并尝试用`ATTACH`跨库提交批准 | 不存在该事务；只能读取三库并no-replace发布一个文件 | 禁止`ATTACH`和跨库批准事务 | DESIGN_PASS |
| CE-K04 | 对Evidence、Book level或Decision执行`UPDATE`/`DELETE` | DDL必须由Registry生成双trigger并`RAISE(ABORT,'E_IMMUTABLE')` | 不可变对象固定集合 | DESIGN_PASS |
| CE-K05 | 向上海库写北京行，或上海Artifact引用北京Qualification | 写入前或同事务内拒绝并全回滚；系统fail-stop | DatabaseIdentity、复合FK、城市trigger、Repository城市绑定 | DESIGN_PASS |
| CE-K06 | 用`X001…X018`替代`M001…M018` | Schema拒绝 | 固定18个properties且`additionalProperties=false` | DESIGN_PASS |
| CE-K07 | `checks=[]`且`passed=true`，或漏一个PF/DV检查 | Schema/派生校验拒绝；`passed=false` | 固定PF001—PF016和DV001—DV008 | DESIGN_PASS |
| CE-K08 | 三个任务全部指向Evidence，或ACL遗漏父目录/DB文件 | fixed map或精确target inventory校验失败 | 三任务固定映射、10目录+10 DB文件目标 | DESIGN_PASS |
| CE-K09 | 错误模型给非真实bucket高`P_LCB`仍企图通过M007 | 产生正shortfall；单侧UCB可失败；参数缺失则资格阻断 | M007改为cluster-bootstrap经验shortfall上界 | DESIGN_PASS |
| CE-K10 | 30秒无新事实仍创建RuntimeEvent并增加bootstrap family | 仅健康核对，不创建evaluation event且不增加family | safe recheck与事实事件分离 | DESIGN_PASS |
| CE-K11 | 新事实出现后旧YES候选仍被Observer当作当前候选 | 同事务追加Invalidation并更新单例slot；slot/历史不一致则fail-stop | DecisionInvalidation + CurrentCandidateSlot | DESIGN_PASS |
| CE-K12 | CLI返回4—7并要求Guardian解释 | 合同拒绝；进程级仅允许0/2/3 | 唯一退出码集合 | DESIGN_PASS |
| CE-K13 | Worker、Observer或错误入口试图启动子进程 | 能力校验拒绝 | 仅Evidence Guardian和Runtime Guardian有固定spawn能力 | DESIGN_PASS |
| CE-K14 | 部署预检声称12个城市DB，或仅验证9个城市DB而漏system registry | 精确集合校验失败 | 10个DB、10目录、10 DB文件的闭合清单 | DESIGN_PASS |
| CE-K15 | 恢复逻辑引用`TX01/TX02`或混用`worker_health/evidence_health` | Registry/恢复Schema拒绝未知或位置型ID | 稳定事务、表、恢复状态名和`HALF_OPEN` | DESIGN_PASS |

## 4. 交叉不变量自检

### 4.1 批准与逐城独立

三城训练、Metrics、Qualification和Artifact继续位于各自Registry；全局对象只保存三份不可替换的逐城引用。批准发布不回写城市数据库，因此不存在“上海已批准、北京未批准”的跨库部分提交状态。Runtime必须逐项验证城市、database UID、artifact、qualification和payload hash，不能形成城市与模型引用的笛卡尔组合。

作者结论：`DESIGN_PASS`。文件系统断电持久性仍为明确未证明项，不得升级为部署可用。

### 4.2 历史不可变与当前状态

Decision和Invalidation均为append-only；可更新的CurrentCandidateSlot被明确登记为非Evidence运行态协调对象。slot只提供唯一当前指针，历史真相仍可重建；两者不一致时失败关闭，不允许自动修复或覆盖历史。

作者结论：`DESIGN_PASS`。未来DDL必须实际证明trigger、事务原子性、单例约束和恢复重建。

### 4.3 实时动态与统计独立单位

30秒是进程安全复查上限，不是模型整点锚。只有新事实、输入身份/新鲜度变化、系统故障变化或窗口边界变化才创建事件；评价次数不能冒充新的`city+target_date`独立样本。

作者结论：`DESIGN_PASS`。

### 4.4 部署可执行边界

Kernel已经固定任务类别、DB/ACL目标数、spawn owner、退出码和恢复名称，但未给出完整Windows任务XML、ACE rights、SID发现、安装命令、回滚和现场验收步骤。

作者结论：`DEFERRED_BY_SCOPE`，不是遗漏，也不能据此部署。

## 5. 尚未关闭且不得伪装关闭的事项

以下内容必须由后续独立Kernel审查或完整替代设计处理：

1. 独立审查是否确认B01—B15均已在规范层关闭；
2. Canonical Registry的最终机器可读Schema和生成器；
3. 每张表的完整DDL、trigger、FK、事务和迁移/初始化顺序；
4. M007的alpha、replicate、seed版本和资格阈值；
5. Windows目标文件系统对同卷no-replace发布及断电持久性的实证；
6. 具体ACL rights、owner、inheritance及当前HP SID的部署绑定；
7. 任务XML、安装/卸载、启动/停止、恢复、回滚和现场验收；
8. 完整文件、模块、类、函数、Schema字段、错误码和测试用例；
9. 任何实现、离线测试、Git集成、部署或激活。

## 6. 作者裁决

```text
AUTHOR_SELFCHECK_RESULT=PASS
AUTHOR_SELFCHECK_SCOPE=DESIGN_ONLY
INDEPENDENT_AUDIT_COMPLETED=NO
KERNEL_ACCEPTED=NO
COMPLETE_REPLACEMENT_DESIGN_AUTHORIZED=NO
IMPLEMENTATION_AUTHORIZED=NO
TEST_EXECUTION_AUTHORIZED=NO
GIT_WRITE_AUTHORIZED=NO
DEPLOYMENT_AUTHORIZED=NO
```

结论：作者级反例检查未发现需要在冻结前继续修订的B01—B15内部矛盾。该结论不能自我认证候选；下一步只有在用户独立授权后，才可对冻结候选执行Architecture Kernel独立审查。
