"""Fault-isolated guardian for exactly one runtime service.

This module intentionally cannot supervise more than one worker.  Each
guardian has its own OS lock and, on Windows, places its single child in a Job
Object configured with ``KILL_ON_JOB_CLOSE``.  A guardian failure can therefore
affect only its own worker and cannot cascade into another database writer.
"""
from __future__ import annotations

import argparse
import ctypes
import json
import logging
import os
import re
import signal
import sqlite3
import stat
import subprocess
import sys
import threading
import time
from contextlib import closing
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Callable

from db_paths import (
    OBSERVATIONS_DB,
    REALTIME_DB,
    RESEARCH_DB,
)
from runtime_instance_lock import (
    AlreadyRunningError,
    DUPLICATE_INSTANCE_EXIT,
    guardian_lock,
)
from runtime_logging import configure_runtime_logging
from runtime_environment import child_environment
from runtime_status import atomic_json, parse_utc
from runtime_control_contract import ResetRequestError, decode_reset_request


BASE = Path(__file__).resolve().parent
RUNTIME_DIR = BASE / "data" / "runtime"
SERVICE_STATUS_DIR = RUNTIME_DIR / "services"
BASE_PYTHON = Path(getattr(sys, "_base_executable", sys.executable))
VENV_SITE = BASE / ".venv" / "Lib" / "site-packages"
CHECK_SECONDS = 5
RESTART_WINDOW_SECONDS = 10 * 60
BACKOFF_SECONDS = (5, 10, 20, 40, 60)
COLLECTOR_PHASE_GRACE_SECONDS = 45
EXECUTABLE_QUOTE_FRESH_SECONDS = 20
WORKER_PROGRESS_CLOCK_AHEAD_SECONDS = 5
WORKER_PROGRESS_DEADLINE_GRACE_SECONDS = 10


@dataclass(frozen=True)
class ServiceSpec:
    name: str
    script: Path
    database: Path
    heartbeat_service: str
    stale_seconds: int
    grace_seconds: int
    restart_limit: int
    check_quotes: bool = False


@dataclass(frozen=True)
class WorkerProgress:
    state: str
    worker_pid: int
    updated_at: datetime
    age_seconds: float
    detail: str | None
    deadline_at: datetime | None


SERVICE_SPECS = {
    "collector": ServiceSpec(
        "collector", BASE / "collector.py", RESEARCH_DB, "collector", 8 * 60, 90, 5
    ),
    "realtime_stream": ServiceSpec(
        "realtime_stream", BASE / "realtime_stream.py", REALTIME_DB,
        "realtime_stream", 90, 45, 5, True
    ),
    "metar_collector": ServiceSpec(
        "metar_collector", BASE / "metar_collector.py", OBSERVATIONS_DB,
        "metar_collector", 150, 45, 5
    ),
}


def utc_now() -> datetime:
    return datetime.now(UTC)


def read_heartbeat(spec: ServiceSpec, *, now: datetime | None = None) -> tuple[float | None, str | None]:
    if not spec.database.exists():
        return None, None
    try:
        with closing(sqlite3.connect(f"file:{spec.database}?mode=ro", uri=True, timeout=2)) as db:
            row = db.execute(
                "SELECT updated_at,detail FROM service_heartbeats WHERE service=?",
                (spec.heartbeat_service,),
            ).fetchone()
    except sqlite3.Error as exc:
        logging.warning("%s heartbeat read failed: %s", spec.name, exc)
        return None, None
    stamp = parse_utc(row[0]) if row else None
    return (((now or utc_now()) - stamp).total_seconds(), row[1]) if stamp else (None, None)


def read_worker_progress(
    path: Path,
    *,
    service: str,
    expected_pid: int,
    now: datetime | None = None,
) -> tuple[WorkerProgress | None, str | None]:
    """Read process liveness independently from a possibly busy SQLite DB."""
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None, "worker_progress_missing"
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None, "worker_progress_unreadable"
    if payload.get("schema") != 1 or payload.get("service") != service:
        return None, "worker_progress_contract_invalid"
    try:
        worker_pid = int(payload.get("worker_pid"))
    except (TypeError, ValueError):
        return None, "worker_progress_contract_invalid"
    if worker_pid != int(expected_pid):
        return None, "worker_progress_pid_mismatch"
    updated_at = parse_utc(payload.get("updated_at"))
    if updated_at is None:
        return None, "worker_progress_contract_invalid"
    stamp_now = now or utc_now()
    age = (stamp_now - updated_at).total_seconds()
    if age < -WORKER_PROGRESS_CLOCK_AHEAD_SECONDS:
        return None, "worker_progress_time_ahead"
    deadline = parse_utc(payload.get("deadline_at"))
    return WorkerProgress(
        state=str(payload.get("state") or "unknown"),
        worker_pid=worker_pid,
        updated_at=updated_at,
        age_seconds=max(0.0, age),
        detail=(str(payload.get("detail")) if payload.get("detail") else None),
        deadline_at=deadline,
    ), None


def latest_quote_age(*, database: Path = REALTIME_DB, now: datetime | None = None) -> float | None:
    if not database.exists():
        return None
    try:
        with closing(sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=2)) as db:
            row = db.execute("SELECT MAX(captured_at) FROM latest_bbo").fetchone()
    except sqlite3.Error:
        return None
    stamp = parse_utc(row[0]) if row else None
    return ((now or utc_now()) - stamp).total_seconds() if stamp else None


def collector_health_reason(age_seconds: float | None, detail: str | None,
                            *, now: datetime | None = None) -> str | None:
    if age_seconds is None:
        return None
    stamp_now = now or utc_now()
    if detail and "state=running" in detail:
        phase_match = re.search(r"(?:^|;)\s*phase=([^;\s]+)", detail)
        deadline_match = re.search(r"(?:^|;)\s*deadline_at=([^;\s]+)", detail)
        deadline = parse_utc(deadline_match.group(1)) if deadline_match else None
        if deadline:
            if stamp_now > deadline + timedelta(seconds=COLLECTOR_PHASE_GRACE_SECONDS):
                phase = phase_match.group(1) if phase_match else "unknown"
                return f"phase_deadline_exceeded:{phase}"
            return None
    return f"heartbeat_stale:{int(age_seconds)}s" if age_seconds > SERVICE_SPECS["collector"].stale_seconds else None


def steady_status(spec: ServiceSpec, quote_age: float | None) -> tuple[str, str | None]:
    """Describe data freshness without turning it into a restart decision.

    A live quote worker can remain healthy while the provider or local network
    is unavailable.  Restarting that process does not make an external feed
    fresher and can instead open the local circuit breaker during a normal
    network handoff.  Quote freshness remains an observer/trading gate.
    """
    if not spec.check_quotes:
        return "healthy", None
    if quote_age is None:
        return "degraded_quote_stale", "quote_age_missing"
    if quote_age >= EXECUTABLE_QUOTE_FRESH_SECONDS:
        return "degraded_quote_stale", f"quote_stale:{int(quote_age)}s"
    return "healthy", None


class ChildContainment:
    """Own one child process and kill it when this containment object closes."""

    def __init__(self, child: subprocess.Popen) -> None:
        self.child = child
        self._job_handle: int | None = None
        if os.name == "nt":
            self._assign_windows_job()

    def _assign_windows_job(self) -> None:
        from ctypes import wintypes

        class IoCounters(ctypes.Structure):
            _fields_ = [
                ("ReadOperationCount", ctypes.c_ulonglong),
                ("WriteOperationCount", ctypes.c_ulonglong),
                ("OtherOperationCount", ctypes.c_ulonglong),
                ("ReadTransferCount", ctypes.c_ulonglong),
                ("WriteTransferCount", ctypes.c_ulonglong),
                ("OtherTransferCount", ctypes.c_ulonglong),
            ]

        class BasicLimitInformation(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", ctypes.c_longlong),
                ("PerJobUserTimeLimit", ctypes.c_longlong),
                ("LimitFlags", wintypes.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wintypes.DWORD),
                ("SchedulingClass", wintypes.DWORD),
            ]

        class ExtendedLimitInformation(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", BasicLimitInformation),
                ("IoInfo", IoCounters),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateJobObjectW.argtypes = (ctypes.c_void_p, wintypes.LPCWSTR)
        kernel32.CreateJobObjectW.restype = wintypes.HANDLE
        kernel32.SetInformationJobObject.argtypes = (
            wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD
        )
        kernel32.SetInformationJobObject.restype = wintypes.BOOL
        kernel32.AssignProcessToJobObject.argtypes = (wintypes.HANDLE, wintypes.HANDLE)
        kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel32.CloseHandle.restype = wintypes.BOOL

        job = kernel32.CreateJobObjectW(None, None)
        if not job:
            raise OSError(ctypes.get_last_error(), "CreateJobObjectW failed")
        information = ExtendedLimitInformation()
        information.BasicLimitInformation.LimitFlags = 0x00002000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        try:
            if not kernel32.SetInformationJobObject(
                job, 9, ctypes.byref(information), ctypes.sizeof(information)
            ):
                raise OSError(ctypes.get_last_error(), "SetInformationJobObject failed")
            if not kernel32.AssignProcessToJobObject(job, wintypes.HANDLE(int(self.child._handle))):
                raise OSError(ctypes.get_last_error(), "AssignProcessToJobObject failed")
        except BaseException:
            kernel32.CloseHandle(job)
            raise
        self._job_handle = int(job)

    def close(self) -> None:
        if self._job_handle is not None:
            from ctypes import wintypes

            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
            kernel32.CloseHandle(wintypes.HANDLE(self._job_handle))
            self._job_handle = None
        elif self.child.poll() is None:
            self.child.terminate()
        try:
            self.child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.child.kill()
            self.child.wait(timeout=10)


class ServiceGuardian:
    """Monitor and restart exactly one approved service."""

    def __init__(self, spec: ServiceSpec, *, status_dir: Path = SERVICE_STATUS_DIR,
                 control_dir: Path | None = None,
                 clock: Callable[[], datetime] = utc_now) -> None:
        self.spec = spec
        self.status_dir = Path(status_dir)
        self.control_dir = Path(control_dir) if control_dir is not None else RUNTIME_DIR / "control"
        self.clock = clock
        self.stop_event = threading.Event()
        self.child: subprocess.Popen | None = None
        self.containment: ChildContainment | None = None
        self.child_started_monotonic: float | None = None
        self.restart_times: list[float] = []
        self.halted_reason: str | None = None
        self.last_worker_progress: WorkerProgress | None = None
        self.last_worker_progress_reason: str | None = None
        self._load_breaker()

    @property
    def status_path(self) -> Path:
        return self.status_dir / f"{self.spec.name}.json"

    @property
    def breaker_path(self) -> Path:
        return self.status_dir / f"{self.spec.name}.breaker.json"

    @property
    def worker_status_path(self) -> Path:
        return self.status_dir / f"{self.spec.name}.worker.json"

    @property
    def reset_path(self) -> Path:
        return self.control_dir / f"{self.spec.name}.reset.json"

    def _load_breaker(self) -> None:
        try:
            payload = json.loads(self.breaker_path.read_text(encoding="utf-8"))
            now_epoch = time.time()
            self.restart_times = [
                float(stamp) for stamp in payload.get("restart_timestamps", [])
                if 0 <= now_epoch - float(stamp) <= RESTART_WINDOW_SECONDS
            ]
            self.halted_reason = payload.get("halted_reason") or None
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            self.restart_times = []
            self.halted_reason = None

    def _worker_environment(self) -> dict[str, str]:
        return child_environment(dotenv_path=BASE / ".env", pythonpath=VENV_SITE)

    def consume_reset_request(self) -> bool:
        if not self.reset_path.exists():
            return False
        try:
            before = self.reset_path.lstat()
            if not stat.S_ISREG(before.st_mode) or before.st_size <= 0 or before.st_size > 4096:
                raise ResetRequestError("reset request is not a bounded regular file")
            with self.reset_path.open("rb") as handle:
                opened = os.fstat(handle.fileno())
                if not stat.S_ISREG(opened.st_mode) or (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
                    raise ResetRequestError("reset request changed during open")
                raw = handle.read(4097)
            after = self.reset_path.stat()
            if (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) != (
                before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
            ):
                raise ResetRequestError("reset request changed during read")
            request = decode_reset_request(raw, expected_service=self.spec.name, now=self.clock())
        except (OSError, ResetRequestError) as exc:
            logging.warning("%s reset request rejected: %s", self.spec.name, type(exc).__name__)
            return False
        self.restart_times = []
        self.halted_reason = None
        try:
            atomic_json(self.breaker_path, {
                "service": self.spec.name,
                "updated_at": self.clock().isoformat(),
                "restart_count_window": 0,
                "restart_timestamps": [],
                "halted_reason": None,
                "last_reason": "manual_reset",
                "last_reset_request_id": request.request_id,
            })
        except OSError as exc:
            self.halted_reason = f"breaker_state_unwritable:{type(exc).__name__}"
            logging.error("%s reset cannot be persisted: %s", self.spec.name, exc)
            return False
        try:
            self.reset_path.unlink()
        except OSError as exc:
            self.halted_reason = f"reset_request_unconsumed:{type(exc).__name__}"
            logging.error("%s reset request could not be consumed: %s", self.spec.name, type(exc).__name__)
            return False
        logging.warning("%s circuit breaker reset by explicit request", self.spec.name)
        return True

    def spawn(self) -> None:
        # Never expose the previous child's progress as if it belonged to the
        # replacement process while the new worker is still starting.
        self.last_worker_progress = None
        self.last_worker_progress_reason = None
        try:
            self.worker_status_path.unlink(missing_ok=True)
        except OSError as exc:
            logging.warning("%s stale worker progress could not be removed: %s", self.spec.name, exc)
        child = subprocess.Popen(
            [str(BASE_PYTHON), str(self.spec.script)],
            cwd=BASE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=self._worker_environment(),
            creationflags=(
                getattr(subprocess, "CREATE_NO_WINDOW", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            ),
            close_fds=True,
        )
        try:
            containment = ChildContainment(child)
        except BaseException:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=10)
            raise
        self.child = child
        self.containment = containment
        self.child_started_monotonic = time.monotonic()
        logging.info("started %s pid=%s", self.spec.name, child.pid)

    def stop_child(self) -> None:
        containment, self.containment = self.containment, None
        child, self.child = self.child, None
        self.child_started_monotonic = None
        self.last_worker_progress = None
        self.last_worker_progress_reason = None
        if containment is not None:
            containment.close()
        elif child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=10)

    def _reason(self) -> tuple[str | None, float | None, str | None, float | None]:
        age, detail = read_heartbeat(self.spec, now=self.clock())
        quote_age = latest_quote_age(database=self.spec.database, now=self.clock()) if self.spec.check_quotes else None
        if self.child is None:
            return "not_running", age, detail, quote_age
        return_code = self.child.poll()
        if return_code is not None:
            reason = (
                "duplicate_writer_lock"
                if return_code == DUPLICATE_INSTANCE_EXIT
                else f"worker_exited:{return_code}"
            )
            return reason, age, detail, quote_age
        elapsed = time.monotonic() - (self.child_started_monotonic or time.monotonic())
        if elapsed <= self.spec.grace_seconds:
            return None, age, detail, quote_age
        progress, progress_reason = read_worker_progress(
            self.worker_status_path,
            service=self.spec.name,
            expected_pid=self.child.pid,
            now=self.clock(),
        )
        self.last_worker_progress = progress
        self.last_worker_progress_reason = progress_reason
        progress_detail = progress.detail if progress is not None else None
        if self.spec.check_quotes and (
            (detail and "writer=dead" in detail.lower())
            or (progress_detail and "writer=dead" in progress_detail.lower())
        ):
            return "quote_writer_dead", age, detail, quote_age
        progress_is_live = bool(
            progress is not None
            and (
                progress.age_seconds <= self.spec.stale_seconds
                or (
                    progress.deadline_at is not None
                    and self.clock()
                    <= progress.deadline_at
                    + timedelta(seconds=WORKER_PROGRESS_DEADLINE_GRACE_SECONDS)
                )
            )
        )
        if age is None:
            if progress_is_live:
                return None, age, detail, quote_age
            return "heartbeat_missing", age, detail, quote_age
        if self.spec.name == "collector":
            # Collector liveness is PID-scoped and independent from SQLite.
            # Trust a current worker's bounded phase before consulting the DB
            # heartbeat, which may still belong to the previous worker.
            collector_progress_live = bool(
                progress is not None
                and (
                    (
                        progress.deadline_at is not None
                        and self.clock()
                        <= progress.deadline_at
                        + timedelta(seconds=WORKER_PROGRESS_DEADLINE_GRACE_SECONDS)
                    )
                    or (
                        progress.deadline_at is None
                        and progress.age_seconds <= self.spec.stale_seconds
                    )
                )
            )
            if collector_progress_live:
                return None, age, detail, quote_age
            return collector_health_reason(age, detail, now=self.clock()), age, detail, quote_age
        if age is not None and age > self.spec.stale_seconds:
            if progress_is_live:
                return None, age, detail, quote_age
            return f"heartbeat_stale:{int(age)}s", age, detail, quote_age
        return None, age, detail, quote_age

    def _record_restart(self, reason: str) -> bool:
        now_epoch = time.time()
        self.restart_times = [
            stamp for stamp in self.restart_times
            if 0 <= now_epoch - stamp <= RESTART_WINDOW_SECONDS
        ]
        self.restart_times.append(now_epoch)
        if reason == "duplicate_writer_lock":
            self.halted_reason = reason
        elif len(self.restart_times) > self.spec.restart_limit:
            self.halted_reason = (
                f"circuit_breaker:{len(self.restart_times)} restarts/"
                f"{RESTART_WINDOW_SECONDS // 60}m; last={reason}"
            )
        try:
            atomic_json(self.breaker_path, {
                "service": self.spec.name,
                "updated_at": self.clock().isoformat(),
                "restart_count_window": len(self.restart_times),
                "restart_timestamps": self.restart_times,
                "halted_reason": self.halted_reason,
                "last_reason": reason,
            })
        except OSError as exc:
            self.halted_reason = f"breaker_state_unwritable:{type(exc).__name__}"
            logging.error("%s cannot persist breaker state; halting only this service: %s",
                          self.spec.name, exc)
        return self.halted_reason is None

    def write_status(self, state: str, *, reason: str | None = None,
                     heartbeat_age: float | None = None, detail: str | None = None,
                     quote_age: float | None = None) -> None:
        try:
            atomic_json(self.status_path, {
                "service": self.spec.name,
                "state": state,
                "guardian_pid": os.getpid(),
                "worker_pid": self.child.pid if self.child and self.child.poll() is None else None,
                "updated_at": self.clock().isoformat(),
                "heartbeat_age_seconds": round(heartbeat_age, 1) if heartbeat_age is not None else None,
                "heartbeat_detail": detail,
                "latest_quote_age_seconds": round(quote_age, 1) if quote_age is not None else None,
                "worker_progress_state": (
                    self.last_worker_progress.state if self.last_worker_progress else None
                ),
                "worker_progress_age_seconds": (
                    round(self.last_worker_progress.age_seconds, 1)
                    if self.last_worker_progress else None
                ),
                "worker_progress_reason": self.last_worker_progress_reason,
                "restart_count_window": len(self.restart_times),
                "reason": reason,
            })
        except OSError as exc:
            # Status reporting is diagnostic.  It must never kill this
            # guardian or its otherwise healthy writer.
            logging.warning("%s status update skipped: %s", self.spec.name, exc)

    def run(self) -> None:
        self.status_dir.mkdir(parents=True, exist_ok=True)
        try:
            while not self.stop_event.is_set():
                self.consume_reset_request()
                if self.halted_reason:
                    self.write_status("halted", reason=self.halted_reason)
                    self.stop_event.wait(CHECK_SECONDS)
                    continue
                if self.child is None:
                    self.spawn()
                    self.write_status("starting")
                reason, age, detail, quote_age = self._reason()
                if reason:
                    logging.warning("%s requires restart: %s", self.spec.name, reason)
                    self.stop_child()
                    if not self._record_restart(reason):
                        self.write_status("halted", reason=self.halted_reason,
                                          heartbeat_age=age, detail=detail, quote_age=quote_age)
                        continue
                    backoff = BACKOFF_SECONDS[min(len(self.restart_times) - 1, len(BACKOFF_SECONDS) - 1)]
                    self.write_status("restarting", reason=reason, heartbeat_age=age,
                                      detail=detail, quote_age=quote_age)
                    if self.stop_event.wait(backoff):
                        break
                    continue
                state, status_reason = steady_status(self.spec, quote_age)
                self.write_status(state, reason=status_reason, heartbeat_age=age,
                                  detail=detail, quote_age=quote_age)
                self.stop_event.wait(CHECK_SECONDS)
        finally:
            self.stop_child()
            self.write_status("stopped", reason="guardian_exit")


def install_signal_handlers(guardian: ServiceGuardian) -> None:
    def stop(_signum, _frame) -> None:
        guardian.stop_event.set()

    for signal_name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        candidate = getattr(signal, signal_name, None)
        if candidate is not None:
            signal.signal(candidate, stop)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one isolated runtime service guardian")
    parser.add_argument("--service", required=True, choices=sorted(SERVICE_SPECS))
    args = parser.parse_args()
    configure_runtime_logging(f"{args.service}_guardian")
    guardian = ServiceGuardian(SERVICE_SPECS[args.service])
    install_signal_handlers(guardian)
    try:
        with guardian_lock(args.service):
            guardian.run()
    except AlreadyRunningError:
        logging.error("%s guardian already active; refusing duplicate start", args.service)
        raise SystemExit(DUPLICATE_INSTANCE_EXIT)
    except BaseException:
        logging.exception("%s guardian fatal error", args.service)
        raise


if __name__ == "__main__":
    main()
